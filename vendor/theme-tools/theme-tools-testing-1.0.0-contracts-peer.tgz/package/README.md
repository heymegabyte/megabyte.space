# `@theme.tools/testing`

> **450-Item TDD Discipline & Ecosystem Conformance Kit** (core-workspace · layer: `foundations`)

450 TDD catalog obligations across 15 families, affected test selector (<300s CI budget), and release gate evaluator.

## Narrow Entry Points

- `@theme.tools/testing/contracts` — Pure TypeScript contracts, schemas, and event descriptors (zero DOM/Worker globals).
- `@theme.tools/testing/core` — Deterministic domain state machines and validation logic.
- `@theme.tools/testing/cloudflare` — Cloudflare Workers / Hono route descriptors and binding requirements (BrowserRendering).
- `@theme.tools/testing/react` — React 19 surface descriptors (`TestingOverviewDashboard`).
- `@theme.tools/testing/elements` — Custom Element registration (`<tt-testing-hud>`).
- `@theme.tools/testing/testing` — Deterministic conformance suite and test fixtures.
- `@theme-tools/testing/capability-evidence` — Portable capability reachability,
  honest Golden Path evidence dispositions, and deterministic pairwise-plus-boundary
  coverage generation. Consumers own their routes, personas, policies, and evidence;
  this entry point supplies only framework-neutral contracts and verification.
- `@theme-tools/testing/network-scenarios` — Versioned, framework-neutral
  success/failure/latency/retry/ordering scenario descriptors.
- `@theme-tools/testing/msw-scenarios` — MSW 2 adapters with deterministic
  ordered responses and observable call history.
- `@theme-tools/testing/lifecycle-model` — Deterministic finite-state exploration,
  invalid-transition enumeration, invariant paths, terminal-state checks, and
  replay expectations. Consumers may also declare actors and per-transition
  authorization policy to enumerate unauthorized actor/action attempts separately
  from invalid domain actions; actor policy remains optional and consumer-owned.
- `@theme-tools/testing/provider-contracts` — Redacted provider error envelopes,
  serializable success/failure fixtures, and consumer-schema evaluation.
- `@theme-tools/testing/hermetic-fixtures` — Deterministic execution-coordinate
  identifiers and failure-visible LIFO cleanup for parallel test fixtures.
- `@theme-tools/testing/trace-evidence` — Redacted browser/Worker/storage/workflow/provider
  evidence records, minimal trace carriers, deterministic collection, and
  at-most-once committed-effect assertions. It is not a vendor exporter and is
  not live-instrumentation evidence by itself.

## Capability evidence adoption

Build a `CapabilityEvidenceManifest` from source-inspected routes, navigation,
guards, flags, API/workflow dependencies, and executed artifacts. Parse it with
`CapabilityEvidenceManifestSchema`, then call
`verifyCapabilityEvidenceManifest()`. A live obligation cannot pass with local or
fixture evidence, and a user-facing capability cannot pass without an authorized
route/navigation affordance.

Use `generatePairwiseCoverage()` for ordered test dimensions and explicitly named
boundary cases. Its report publishes the exact pair denominator, covered pairs,
uncovered pairs, selected cases, and retained boundary identities; it does not
claim a mathematically minimal case set.

Network scenario descriptors remain separate from the MSW adapter so Worker and
schema consumers can import the contracts without interception code. Lifecycle
models remain consumer-owned: shared code explores and reports them but never
defines product policy. When a lifecycle declares `actors`, every transition must
declare at least one `allowedActors` entry drawn from that actor set; the report
then marks authorization coverage and enumerates every denied actor attempt.

The standard catalog includes `transientDisconnectRecovery` for proving that a
consumer retains last-known data during a connection loss and refreshes it after
the next successful response.

Provider contract fixtures accept consumer-owned Zod request and success schemas.
The canonical failure envelope retains retryability and request correlation while
rejecting secret-like detail keys; credentials and product payload policy remain
in the consumer.

Hermetic fixture identifiers include suite, test, project, worker, retry, and run
seed coordinates. Cleanup registries execute every action in reverse registration
order and report redacted failures rather than abandoning later cleanup.
