import { useEffect, useState, useCallback } from 'react';

// Client-side hook + types for the super-admin session. Fetches `/api/admin/auth/me`
// and caches the result for the lifetime of the component. Distinct from the
// crew (`/api/work/auth/me`) and customer (`/api/auth/client/me`) probes — the
// three are independent identity surfaces and must never share state.

export type AdminRole = 'super' | 'dispatcher' | 'support';

export interface AdminIdentity {
  readonly id: string;
  readonly role: AdminRole;
  readonly name: string;
}

export type AdminSessionState =
  | { readonly status: 'checking' }
  | { readonly status: 'anonymous' }
  | { readonly status: 'authenticated'; readonly admin: AdminIdentity };

interface MeResponse {
  authenticated?: boolean;
  admin?: AdminIdentity;
}

/**
 * Probe the admin session once on mount. Treats any network failure as
 * "anonymous" — never throws into the React render. Re-fetch by calling
 * `refresh()`; useful after a successful verify-code response.
 */
export function useAdminSession(): {
  readonly state: AdminSessionState;
  readonly refresh: () => Promise<void>;
} {
  const [state, setState] = useState<AdminSessionState>({ status: 'checking' });

  const probe = useCallback(async (): Promise<void> => {
    try {
      const res = await fetch('/api/admin/auth/me', { credentials: 'include' });
      if (!res.ok) {
        setState({ status: 'anonymous' });
        return;
      }
      const body = (await res.json().catch(() => ({}))) as MeResponse;
      if (body.authenticated && body.admin) {
        setState({ status: 'authenticated', admin: body.admin });
      } else {
        setState({ status: 'anonymous' });
      }
    } catch {
      setState({ status: 'anonymous' });
    }
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch('/api/admin/auth/me', { credentials: 'include' });
        if (cancelled) return;
        if (!res.ok) {
          setState({ status: 'anonymous' });
          return;
        }
        const body = (await res.json().catch(() => ({}))) as MeResponse;
        if (cancelled) return;
        if (body.authenticated && body.admin) {
          setState({ status: 'authenticated', admin: body.admin });
        } else {
          setState({ status: 'anonymous' });
        }
      } catch {
        if (!cancelled) setState({ status: 'anonymous' });
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  return { state, refresh: probe };
}

/**
 * Imperative logout — POST `/api/admin/auth/logout`, then hard-redirect to
 * `/admin/login`. Caller controls navigation only when the redirect target
 * differs; default is fine for the dashboard signout button.
 */
export async function adminLogout(redirect: string = '/admin/login'): Promise<void> {
  try {
    await fetch('/api/admin/auth/logout', {
      method: 'POST',
      credentials: 'include',
    });
  } catch {
    /* ignore — clearing local state matters more than the server ACK */
  }
  window.location.replace(redirect);
}
