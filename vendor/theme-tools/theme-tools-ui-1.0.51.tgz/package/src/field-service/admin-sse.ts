import { useEffect, useRef, useState } from 'react';

/**
 * useEventSource — auto-reconnecting EventSource hook for the SuperAdmin
 * live feed. The browser EventSource will retry on its own when the server
 * closes the connection cleanly, but the SuperAdmin SSE handler caps its
 * lifetime at 25min — so we additionally reopen on the `bye` event and
 * apply an exponential-backoff reopen when we hit `error`.
 *
 * Why not WebSocket? Cloudflare Workers does WS, but EventSource is
 * one-way + browser-managed-reconnect, which matches our broadcast
 * pattern with less plumbing. SSE flows through CORS the same as fetch.
 *
 * Generic `T` is the parsed shape of each `event: <name>` data frame —
 * the hook owns the JSON.parse + safe-handling so consumers stay typed.
 */

export type SseConnectionState = 'connecting' | 'open' | 'closed' | 'error';

export interface UseEventSourceOptions<T> {
  readonly url: string;
  readonly eventName?: string;
  readonly enabled?: boolean;
  readonly authToken?: string;
  readonly maxBufferedEvents?: number;
  readonly onEvent?: (event: T) => void;
}

export function useEventSource<T>(opts: UseEventSourceOptions<T>): {
  events: readonly T[];
  state: SseConnectionState;
  reconnect: () => void;
  clear: () => void;
} {
  const {
    url,
    eventName = 'admin_event',
    enabled = true,
    authToken,
    maxBufferedEvents = 200,
    onEvent,
  } = opts;
  const [events, setEvents] = useState<T[]>([]);
  const [state, setState] = useState<SseConnectionState>('closed');
  const esRef = useRef<EventSource | null>(null);
  const backoffRef = useRef<number>(1_000);
  const reconnectTimerRef = useRef<number | null>(null);
  const onEventRef = useRef<typeof onEvent>(onEvent);
  onEventRef.current = onEvent;

  useEffect(() => {
    if (!enabled || typeof window === 'undefined') {
      setState('closed');
      return;
    }
    let cancelled = false;

    function connect(): void {
      if (cancelled) return;
      setState('connecting');
      const full = authToken
        ? `${url}${url.includes('?') ? '&' : '?'}token=${encodeURIComponent(authToken)}`
        : url;
      const es = new EventSource(full, { withCredentials: true });
      esRef.current = es;
      es.onopen = () => {
        if (cancelled) return;
        setState('open');
        backoffRef.current = 1_000;
      };
      es.addEventListener(eventName, (ev: MessageEvent<string>) => {
        if (cancelled) return;
        try {
          const parsed = JSON.parse(ev.data) as T;
          setEvents((prev) => {
            const next = [parsed, ...prev];
            return next.length > maxBufferedEvents ? next.slice(0, maxBufferedEvents) : next;
          });
          onEventRef.current?.(parsed);
        } catch {
          /* ignore malformed payload */
        }
      });
      es.addEventListener('bye', () => {
        es.close();
        scheduleReconnect();
      });
      es.onerror = () => {
        if (cancelled) return;
        setState('error');
        es.close();
        scheduleReconnect();
      };
    }

    function scheduleReconnect(): void {
      if (cancelled) return;
      const delay = Math.min(backoffRef.current, 30_000);
      backoffRef.current = Math.min(backoffRef.current * 2, 30_000);
      if (reconnectTimerRef.current != null) window.clearTimeout(reconnectTimerRef.current);
      reconnectTimerRef.current = window.setTimeout(() => connect(), delay);
    }

    connect();

    return () => {
      cancelled = true;
      if (reconnectTimerRef.current != null) window.clearTimeout(reconnectTimerRef.current);
      if (esRef.current) {
        esRef.current.close();
        esRef.current = null;
      }
      setState('closed');
    };
  }, [url, eventName, enabled, authToken, maxBufferedEvents]);

  const reconnect = (): void => {
    if (esRef.current) {
      esRef.current.close();
      esRef.current = null;
    }
    backoffRef.current = 1_000;
    setState('closed');
    // Effect re-runs because enabled/url unchanged? Force a re-mount via state bump:
    setEvents((prev) => prev.slice());
  };

  const clear = (): void => setEvents([]);

  return { events, state, reconnect, clear };
}
