// Animation runtime: scroll-triggered reveals + count-up stats.
// Once-only, transform/opacity, prefers-reduced-motion safe, SSR-friendly.

const SELECTOR = '[data-animate]:not(.is-visible), .reveal:not(.is-visible)';
const COUNT_SELECTOR = '[data-count]:not([data-count-done]):not([data-count-running])';
const ROOT_MARGIN = '0px 0px -15% 0px';
const THRESHOLD = 0.18;
const PREFERS_REDUCED =
  typeof window !== 'undefined' &&
  window.matchMedia?.('(prefers-reduced-motion: reduce)').matches === true;

let io: IntersectionObserver | null = null;
let countIo: IntersectionObserver | null = null;
let mo: MutationObserver | null = null;

export function applyStagger(el: HTMLElement) {
  const parent = el.parentElement;
  if (!parent) return;
  const stagger = parent.getAttribute('data-stagger');
  if (!stagger) return;
  const step = Number(stagger);
  if (!Number.isFinite(step) || step <= 0) return;
  const siblings = Array.from(parent.children).filter(
    (c) =>
      c instanceof HTMLElement &&
      (c.hasAttribute('data-animate') || c.classList.contains('reveal')),
  ) as HTMLElement[];
  const idx = siblings.indexOf(el);
  if (idx < 0) return;
  const baseDelay = Number(el.getAttribute('data-delay') ?? '0');
  el.style.setProperty('--anim-delay', `${baseDelay + idx * step}ms`);
}

function applyDelay(el: HTMLElement) {
  if (el.style.getPropertyValue('--anim-delay')) return;
  const d = el.getAttribute('data-delay');
  if (d) el.style.setProperty('--anim-delay', `${Number(d) || 0}ms`);
}

function reveal(el: HTMLElement) {
  el.classList.add('is-visible');
  // Drop will-change after transition to free the compositor.
  const cleanup = () => {
    el.style.willChange = '';
    el.removeEventListener('transitionend', cleanup);
  };
  el.addEventListener('transitionend', cleanup, { once: true });
}

function easeOutCubic(t: number): number {
  return 1 - Math.pow(1 - t, 3);
}

function formatNumber(n: number, decimals: number, locale: string): string {
  return n.toLocaleString(locale, {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

/**
 * Write `text` into `el` WITHOUT detaching React's text node.
 *
 * `[data-count]` spans are rendered by React (e.g. Hero.tsx). `el.textContent =
 * x` REMOVES React's text-node child and inserts a fresh one this runtime owns;
 * React's fiber still points at the original node, so the next reconcile/unmount
 * calls `parentNode.removeChild(staleNode)` on a node whose parent is now null →
 * `TypeError: removeChild: parameter 1 is not of type 'Node'`, crashing React's
 * commit phase and unmounting the whole root (a BLANK homepage — the pass +80
 * prod incident). Mutating the EXISTING text node's `nodeValue` keeps React's
 * reference valid (no removeChild) and, as a `characterData` change, never trips
 * the `childList` MutationObserver below.
 */
export function setCountText(el: HTMLElement, text: string): void {
  const first = el.firstChild;
  if (first && first.nodeType === Node.TEXT_NODE && el.childNodes.length === 1) {
    first.nodeValue = text;
  } else {
    // No single text node to mutate (empty / mixed children) — create one once;
    // React holds no child fiber for these so this can't conflict.
    el.textContent = text;
  }
}

function animateCount(el: HTMLElement) {
  if (el.hasAttribute('data-count-running') || el.hasAttribute('data-count-done')) return;
  const targetRaw = el.getAttribute('data-count');
  if (!targetRaw) return;
  const target = Number(targetRaw);
  if (!Number.isFinite(target)) return;
  const duration = Number(el.getAttribute('data-count-duration') ?? '1400');
  const decimals = Number(el.getAttribute('data-count-decimals') ?? '0');
  const prefix = el.getAttribute('data-count-prefix') ?? '';
  const suffix = el.getAttribute('data-count-suffix') ?? '';
  const locale = el.getAttribute('data-count-locale') ?? 'en-US';

  if (PREFERS_REDUCED) {
    setCountText(el, `${prefix}${formatNumber(target, decimals, locale)}${suffix}`);
    el.setAttribute('data-count-done', '1');
    return;
  }

  el.setAttribute('data-count-running', '1');
  let start: number | null = null;
  let lastValue = 0;
  setCountText(el, `${prefix}${formatNumber(0, decimals, locale)}${suffix}`);
  const tick = (now: number) => {
    if (start === null) start = now;
    const t = Math.max(0, Math.min(1, (now - start) / duration));
    const next = Math.max(0, target * easeOutCubic(t));
    if (next >= lastValue) {
      lastValue = next;
      setCountText(el, `${prefix}${formatNumber(next, decimals, locale)}${suffix}`);
    }
    if (t < 1) requestAnimationFrame(tick);
    else {
      setCountText(el, `${prefix}${formatNumber(target, decimals, locale)}${suffix}`);
      el.setAttribute('data-count-done', '1');
      el.removeAttribute('data-count-running');
    }
  };
  requestAnimationFrame(tick);
}

function ensureObservers() {
  if (typeof IntersectionObserver === 'undefined') return;
  if (!io) {
    io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (!e.isIntersecting) continue;
          const el = e.target as HTMLElement;
          io!.unobserve(el);
          reveal(el);
        }
      },
      { rootMargin: ROOT_MARGIN, threshold: THRESHOLD },
    );
  }
  if (!countIo) {
    countIo = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (!e.isIntersecting) continue;
          const el = e.target as HTMLElement;
          countIo!.unobserve(el);
          animateCount(el);
        }
      },
      { rootMargin: ROOT_MARGIN, threshold: 0.5 },
    );
  }
}

function bindReveals() {
  if (!io) return;
  document.querySelectorAll<HTMLElement>(SELECTOR).forEach((el) => {
    if (PREFERS_REDUCED) {
      el.classList.add('is-visible');
      return;
    }
    applyStagger(el);
    applyDelay(el);
    el.style.willChange = 'opacity, transform';
    // Sticky/load-in elements (page chrome) animate immediately on mount,
    // not via scroll IO — they sit at viewport top with zero scroll travel.
    if (el.getAttribute('data-animate') === 'header-in') {
      requestAnimationFrame(() => reveal(el));
      return;
    }
    io!.observe(el);
  });
}

function bindCounters() {
  if (!countIo) return;
  document.querySelectorAll<HTMLElement>(COUNT_SELECTOR).forEach((el) => countIo!.observe(el));
}

export function attach() {
  if (typeof window === 'undefined' || typeof document === 'undefined') return;
  ensureObservers();
  bindReveals();
  bindCounters();
  if (mo) return;
  mo = new MutationObserver(() => {
    bindReveals();
    bindCounters();
  });
  mo.observe(document.body, { childList: true, subtree: true });
}
