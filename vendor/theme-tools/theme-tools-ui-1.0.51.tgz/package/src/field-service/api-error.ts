/**
 * Defensively unwrap a server error envelope into a human-readable string.
 *
 * Handles every shape the Brick Labor worker stack returns:
 *   - { error: "string" }                       — plain message (most routes)
 *   - { error: { message: "string" } }          — nested object (Hono onError envelope)
 *   - { error: { issues: [{ message }] } }      — Zod validation array
 *   - { message: "string" }                     — fallback shape
 *   - anything else → empty string (caller adds status-code default).
 *
 * Lives here instead of inline in QuickSchedulePopover so any /me-surface
 * caller (CalendarWorkspace save/delete, QuickSchedulePopover, AI optimizer,
 * SMS actions, install banner) gets the same friendly error UX without
 * accidentally rendering `[object Object]` when the server returns a nested
 * Hono onError envelope.
 *
 * Prior call-sites that did `new Error(j.error)` where `j.error` was an
 * object produced the user-visible "[object Object]" save error in the
 * calendar quick-create flow — this helper prevents the regression.
 */
export function extractErrorMessage(j: {
  error?: unknown;
  message?: unknown;
  details?: unknown;
}): string {
  const e = j.error;
  if (typeof e === 'string' && e.trim()) return e;
  if (e && typeof e === 'object') {
    const obj = e as { message?: unknown; issues?: unknown };
    if (typeof obj.message === 'string' && obj.message.trim()) return obj.message;
    if (Array.isArray(obj.issues) && obj.issues.length > 0) {
      const first = obj.issues[0] as { message?: unknown };
      if (typeof first.message === 'string' && first.message.trim()) return first.message;
    }
  }
  if (typeof j.message === 'string' && j.message.trim()) return j.message;
  return '';
}
