// Cross-component avatar live-reload bus.
//
// Problem: AvatarSection re-renders its own <img src="/api/work/upload/avatar/:id?v=..."/>
// with a fresh `?v={timestamp}` cache-buster on upload, but every OTHER mount
// of the avatar (Header bubble, WorkerDashboard tab, sibling profile pane)
// keeps showing the stale R2 object until full-page reload because it has its
// own state-local `bust`.
//
// Fix: a tiny context that holds `{ workerId, bust }` so every consumer can
// share one cache-buster. The setter (`bumpAvatar`) takes an optional
// workerId; uploaders call `bumpAvatar(worker.id)` after a successful
// POST/DELETE, every reader keys their <img src> off the same `bust`, the
// new R2 object lights up across the app in the next paint.
//
// `avatarUrl(workerId, bust)` is the canonical URL builder so the format
// stays in one place. Falls back to `null` if no workerId is known yet so
// the consumer can render initials instead.

import { createContext, useCallback, useContext, useMemo, useState } from 'react';
import type { ReactNode } from 'react';

interface AvatarState {
  /** Current worker/customer id whose avatar lives in the bus. `null` when anon. */
  workerId: string | null;
  /** Monotonic cache-buster appended as `?v={bust}`. Bumps on every upload. */
  bust: number;
  /** Set the worker id (login / first profile probe hydrates this). */
  setWorkerId: (id: string | null) => void;
  /** Bump the bust so every sibling <img> re-fetches. Pass an id to also set it. */
  bumpAvatar: (id?: string | null) => void;
  /** Build the canonical worker-avatar URL, or `null` if no id. */
  avatarUrl: (id?: string | null) => string | null;
}

const AvatarContext = createContext<AvatarState>({
  workerId: null,
  bust: 0,
  setWorkerId: () => {
    /* default no-op until provider mounts */
  },
  bumpAvatar: () => {
    /* default no-op until provider mounts */
  },
  avatarUrl: () => null,
});

interface AvatarProviderProps {
  children: ReactNode;
  initialWorkerId?: string | null;
}

export function AvatarProvider({ children, initialWorkerId = null }: AvatarProviderProps) {
  const [workerId, setWorkerIdState] = useState<string | null>(initialWorkerId);
  const [bust, setBust] = useState<number>(() => Date.now());

  const setWorkerId = useCallback((id: string | null) => {
    setWorkerIdState((prev) => (prev === id ? prev : id));
  }, []);

  const bumpAvatar = useCallback((id?: string | null) => {
    if (typeof id === 'string') setWorkerIdState(id);
    setBust(Date.now());
  }, []);

  const value = useMemo<AvatarState>(() => {
    const avatarUrl = (id?: string | null): string | null => {
      const wid = id ?? workerId;
      if (!wid) return null;
      return `/api/work/upload/avatar/${encodeURIComponent(wid)}?v=${bust}`;
    };
    return {
      workerId,
      bust,
      setWorkerId,
      bumpAvatar,
      avatarUrl,
    };
  }, [workerId, bust, setWorkerId, bumpAvatar]);

  return <AvatarContext.Provider value={value}>{children}</AvatarContext.Provider>;
}

/**
 * Read-write access to the shared avatar bust + worker id.
 *
 * Uploaders: call `bumpAvatar(worker.id)` after a successful upload or delete.
 * Readers: render `<img src={avatarUrl(workerId) ?? fallbackUrl} />` — the
 * `?v={bust}` cache-buster on the URL guarantees the browser refetches the
 * R2 object even though the path (worker id) is unchanged.
 */
export function useAvatar(): AvatarState {
  return useContext(AvatarContext);
}
