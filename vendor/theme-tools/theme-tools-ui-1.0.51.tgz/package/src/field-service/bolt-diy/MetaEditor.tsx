/**
 * bolt.diy _meta Editor — visual form for business.json fields.
 *
 * Edits pricing, services, hours, and contact. Updates JSON in real-time.
 * Requires a save endpoint (provided by projectsites.dev) or works
 * read-only for local viewing.
 */
import { useState, useEffect } from 'react';

interface BusinessMeta {
  name?: string;
  tagline?: string;
  contact?: {
    email?: string;
    phone?: { display?: string; tel?: string; sms?: string };
  };
  pricing?: {
    model?: string;
    hourly_rate_cents?: number;
    minimum_hours?: number;
    billing_increment_minutes?: number;
    crew_sizes?: number[];
    recurring_discounts?: Record<string, number>;
  };
  services?: Array<{ slug: string; title: string; category: string }>;
}

interface MetaEditorProps {
  /** API base for loading/saving _meta files */
  apiBase?: string;
  dark?: boolean;
}

export function MetaEditor({ apiBase, dark = true }: MetaEditorProps) {
  const [meta, setMeta] = useState<BusinessMeta | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!apiBase) {
      setLoading(false);
      return;
    }
    fetch(`${apiBase}/business.json`)
      .then(r => r.json())
      .then(data => { setMeta(data); setLoading(false); })
      .catch(() => setLoading(false));
  }, [apiBase]);

  const save = async () => {
    if (!apiBase || !meta) return;
    setSaving(true);
    setError(null);
    try {
      const res = await fetch(`${apiBase}/business.json`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(meta, null, 2),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setSaving(false);
    }
  };

  const update = (path: string, value: unknown) => {
    setMeta(prev => {
      if (!prev) return prev;
      const next = { ...prev };
      const keys = path.split('.');
      let target: Record<string, unknown> = next as unknown as Record<string, unknown>;
      for (let i = 0; i < keys.length - 1; i++) {
        if (!target[keys[i]]) target[keys[i]] = {};
        target = target[keys[i]] as Record<string, unknown>;
      }
      target[keys[keys.length - 1]] = value;
      return next;
    });
    setSaved(false);
  };

  const bg = dark ? '#060610' : '#fff';
  const fg = dark ? '#F5F5F5' : '#111';
  const accent = '#00E5FF';
  const mute = dark ? '#A0A0B0' : '#666';
  const card = dark ? '#0A0E14' : '#f5f5f5';
  const line = dark ? '#1E1E2E' : '#e0e0e0';
  const success = '#22c55e';

  if (loading) return <div style={{ color: mute, padding: 20, fontFamily: 'JetBrains Mono, monospace' }}>Loading _meta/business.json...</div>;
  if (!meta) return <div style={{ color: mute, padding: 20, fontFamily: 'JetBrains Mono, monospace' }}>No business.json loaded. Set apiBase to enable editing.</div>;

  return (
    <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 13, background: bg, color: fg, height: '100%', overflow: 'auto', padding: 16 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <h2 style={{ margin: 0, fontSize: 16, color: accent }}>_meta/business.json</h2>
        {apiBase && (
          <button onClick={save} disabled={saving} style={{ padding: '6px 16px', borderRadius: 4, border: `1px solid ${saved ? success : accent}`, background: 'transparent', color: saved ? success : accent, cursor: 'pointer', fontSize: 12, fontFamily: 'JetBrains Mono, monospace' }}>
            {saved ? '✓ Saved' : saving ? 'Saving...' : 'Save'}
          </button>
        )}
      </div>

      {error && <div style={{ color: '#ef4444', padding: 8, background: '#ef444410', borderRadius: 4, marginBottom: 12, fontSize: 12 }}>{error}</div>}

      {/* Brand */}
      <Section title="Brand">
        <Field label="Name" value={meta.name || ''} onChange={v => update('name', v)} mute={mute} fg={fg} card={card} line={line} />
        <Field label="Tagline" value={meta.tagline || ''} onChange={v => update('tagline', v)} mute={mute} fg={fg} card={card} line={line} />
      </Section>

      {/* Contact */}
      <Section title="Contact">
        <Field label="Email" value={meta.contact?.email || ''} onChange={v => update('contact.email', v)} mute={mute} fg={fg} card={card} line={line} />
        <Field label="Phone (display)" value={meta.contact?.phone?.display || ''} onChange={v => update('contact.phone.display', v)} mute={mute} fg={fg} card={card} line={line} />
        <Field label="Phone (tel)" value={meta.contact?.phone?.tel || ''} onChange={v => update('contact.phone.tel', v)} mute={mute} fg={fg} card={card} line={line} />
      </Section>

      {/* Pricing */}
      <Section title="Pricing">
        <Field label="Model" value={meta.pricing?.model || ''} onChange={v => update('pricing.model', v)} mute={mute} fg={fg} card={card} line={line} />
        <Field label="Hourly rate (cents)" value={String(meta.pricing?.hourly_rate_cents ?? 5000)} onChange={v => update('pricing.hourly_rate_cents', Number(v) || 5000)} mute={mute} fg={fg} card={card} line={line} />
        <Field label="Minimum hours" value={String(meta.pricing?.minimum_hours ?? 1)} onChange={v => update('pricing.minimum_hours', Number(v) || 1)} mute={mute} fg={fg} card={card} line={line} />
        <Field label="Billing increment (min)" value={String(meta.pricing?.billing_increment_minutes ?? 15)} onChange={v => update('pricing.billing_increment_minutes', Number(v) || 15)} mute={mute} fg={fg} card={card} line={line} />
      </Section>

      {/* Recurring Discounts */}
      <Section title="Recurring Discounts">
        {Object.entries(meta.pricing?.recurring_discounts ?? {}).map(([plan, pct]) => (
          <Field
            key={plan}
            label={`${plan} discount`}
            value={String(Math.round(pct * 100))}
            onChange={v => update(`pricing.recurring_discounts.${plan}`, (Number(v) || 0) / 100)}
            mute={mute} fg={fg} card={card} line={line}
            suffix="%"
          />
        ))}
      </Section>

      {/* Services */}
      <Section title="Services">
        {(meta.services ?? []).map((svc, i) => (
          <div key={svc.slug} style={{ display: 'flex', gap: 8, marginBottom: 6 }}>
            <input
              value={svc.title}
              onChange={e => update(`services.${i}.title`, e.target.value)}
              style={{ flex: 1, background: card, color: fg, border: `1px solid ${line}`, borderRadius: 4, padding: '4px 8px', fontSize: 12, fontFamily: 'JetBrains Mono, monospace' }}
              placeholder="Service title"
            />
            <span style={{ color: mute, fontSize: 11, paddingTop: 6 }}>{svc.slug}</span>
          </div>
        ))}
      </Section>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <fieldset style={{ border: '1px solid #1E1E2E', borderRadius: 8, padding: 12, marginBottom: 12 }}>
      <legend style={{ color: '#00E5FF', fontSize: 11, fontFamily: 'JetBrains Mono, monospace', textTransform: 'uppercase', letterSpacing: '0.1em' }}>{title}</legend>
      {children}
    </fieldset>
  );
}

function Field({ label, value, onChange, mute, fg, card, line, suffix }: {
  label: string; value: string; onChange: (v: string) => void;
  mute: string; fg: string; card: string; line: string; suffix?: string;
}) {
  return (
    <div style={{ marginBottom: 8 }}>
      <label style={{ display: 'block', fontSize: 10, color: mute, marginBottom: 3, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{label}</label>
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <input
          value={value}
          onChange={e => onChange(e.target.value)}
          style={{ flex: 1, background: card, color: fg, border: `1px solid ${line}`, borderRadius: 4, padding: '5px 8px', fontSize: 13, fontFamily: 'JetBrains Mono, monospace' }}
        />
        {suffix && <span style={{ marginLeft: 6, color: mute, fontSize: 12 }}>{suffix}</span>}
      </div>
    </div>
  );
}
