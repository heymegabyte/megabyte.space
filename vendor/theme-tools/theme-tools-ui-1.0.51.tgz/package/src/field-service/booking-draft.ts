/**
 * Pure helpers for the /book draft-restore affordance.
 *
 * The booking form silently restores a localStorage draft into its initial state
 * (see Booking.tsx — the `useState` initializers read `readDraft()`). Without a
 * visible affordance a returning visitor faces a half-filled — possibly weeks-stale,
 * past-dated — form with no explanation and no way to start over. These pure
 * predicates drive the "Picked up where you left off" banner + its "Start fresh"
 * reset, and are unit-tested in isolation (no DOM / localStorage).
 */

/** Days after which a saved draft is old enough that its date may be in the past. */
export const DRAFT_MAX_AGE_DAYS = 10;

const MS_PER_DAY = 86_400_000;

/** Minimal shape of the persisted booking draft this module reasons about. */
export interface RestorableDraft {
  readonly hours?: number;
  readonly crew?: number;
  readonly date?: string;
  readonly firstName?: string;
  readonly lastName?: string;
  readonly name?: string;
  readonly email?: string;
  readonly phone?: string;
  readonly address?: string;
  readonly notes?: string;
  readonly truckPicks?: readonly unknown[];
  readonly services?: readonly unknown[];
  readonly multiDates?: readonly string[];
  /** Wall-clock ms when the draft was last written. */
  readonly savedAt?: number;
}

const nonEmpty = (s: unknown): boolean => typeof s === 'string' && s.trim().length > 0;

/**
 * True when a restored draft carries enough meaningful, user-entered detail that a
 * returning visitor would notice the form is pre-filled.
 *
 * `source` / UTM / opt-in flags / numeric defaults are intentionally ignored — they
 * are set on every visit and would make the banner fire for a brand-new user.
 *
 * @param d - The restored draft (or null/undefined for "no draft").
 * @returns true if any user-entered field is present.
 * @example
 * hasRestorableDraft({ date: '2026-07-04' }) // → true
 * hasRestorableDraft({ source: 'web' })       // → false (source isn't user-entered)
 */
export function hasRestorableDraft(d: RestorableDraft | null | undefined): boolean {
  if (!d) return false;
  if (nonEmpty(d.date)) return true;
  if (nonEmpty(d.firstName) || nonEmpty(d.lastName) || nonEmpty(d.name)) return true;
  if (nonEmpty(d.email) || nonEmpty(d.phone)) return true;
  if (nonEmpty(d.address) || nonEmpty(d.notes)) return true;
  if (Array.isArray(d.truckPicks) && d.truckPicks.length > 0) return true;
  if (Array.isArray(d.services) && d.services.length > 0) return true;
  if (Array.isArray(d.multiDates) && d.multiDates.length > 0) return true;
  return false;
}

/**
 * Whole days between the draft's `savedAt` and `nowMs`, or `null` when no timestamp
 * was stored (legacy drafts written before timestamps existed).
 *
 * @param d - The restored draft.
 * @param nowMs - Current wall-clock time in ms (`Date.now()`).
 * @returns Age in whole days (≥0), or null when unknown.
 * @example
 * draftAgeDays({ savedAt: 0 }, 86_400_000) // → 1
 * draftAgeDays({}, 86_400_000)             // → null
 */
export function draftAgeDays(
  d: RestorableDraft | null | undefined,
  nowMs: number,
): number | null {
  const savedAt = d?.savedAt;
  if (typeof savedAt !== 'number' || !Number.isFinite(savedAt) || savedAt <= 0) return null;
  return Math.max(0, Math.floor((nowMs - savedAt) / MS_PER_DAY));
}

/**
 * True when a draft is old enough that its details (notably the chosen date) may be
 * out of date. A draft with no timestamp is treated as NOT stale — we give current
 * mid-session users the benefit of the doubt; the stale nudge only fires once we have
 * a real `savedAt` proving the draft is ≥ `maxAgeDays` old.
 *
 * @param d - The restored draft.
 * @param nowMs - Current wall-clock time in ms.
 * @param maxAgeDays - Staleness threshold in days (default `DRAFT_MAX_AGE_DAYS`).
 * @example
 * draftIsStale({ savedAt: 0 }, 11 * 86_400_000) // → true
 * draftIsStale({}, Date.now())                  // → false (unknown age)
 */
export function draftIsStale(
  d: RestorableDraft | null | undefined,
  nowMs: number,
  maxAgeDays: number = DRAFT_MAX_AGE_DAYS,
): boolean {
  const age = draftAgeDays(d, nowMs);
  if (age === null) return false;
  return age >= maxAgeDays;
}

/**
 * Banner copy for the restored-draft notice, stale-aware.
 *
 * @param stale - Result of {@link draftIsStale}.
 * @returns A short, helpful sentence for the affordance.
 */
export function restoredDraftMessage(stale: boolean): string {
  return stale
    ? 'We saved your earlier booking details — they may be out of date, so double-check your date and scope.'
    : 'Picked up where you left off — your earlier booking details are filled in.';
}
