/**
 * Command registry consumed by the unified Cmd+K palette
 * (see `cmd-k-rotator.tsx`).
 *
 * Wave 13D unified four prior surfaces into one: the legacy admin palette
 * (Wave 4F), Square actions (Wave 13A), customer-portal actions (Wave 13B),
 * worker-portal actions (Wave 13C), plus the global navigation jumpers
 * plus the global navigation jumpers. Chat-only slash commands stay in the
 * lazy AI surface so their validation schema does not inflate the critical
 * homepage bundle. Each command declares which context it belongs to so the palette can filter dynamically based on the page the
 * user is currently on (admin vs customer vs worker vs everyone).
 *
 * The registry is intentionally lightweight — no React imports, no DOM
 * access — so it can be evaluated in tests and on the worker side if we
 * ever surface commands to the AI chat as suggestions.
 */

/** Where a command is allowed to appear. */
export type CmdKContext = 'global' | 'admin' | 'customer' | 'worker';

/** Categorisation drives the section headers in the palette UI. */
export type CmdKCategory = 'Pages' | 'Customer' | 'Worker' | 'Admin' | 'AI' | 'Square' | 'Help';

export interface CmdKCommand {
  /** Stable id used for keying + recent-history tracking. */
  readonly id: string;
  /** Human title rendered in the palette row. */
  readonly title: string;
  /** Optional one-line hint shown to the right of the title. */
  readonly hint?: string;
  /** Group header. */
  readonly category: CmdKCategory;
  /** Filter — which surfaces may run this command. */
  readonly contexts: readonly CmdKContext[];
  /** Optional URL the palette navigates to. */
  readonly href?: string;
  /** Optional in-app handler (overrides href when present). */
  readonly run?: () => void;
  /** Keywords expanded during fuzzy search. */
  readonly keywords?: readonly string[];
}

/** Built-in palette commands grouped by spec-mandated waves. */
const STATIC_COMMANDS: readonly CmdKCommand[] = [
  // ── Pages ───────────────────────────────────────────────────────────
  {
    id: 'page:home',
    title: 'Go to homepage',
    hint: '/',
    category: 'Pages',
    contexts: ['global'],
    href: '/',
    keywords: ['home', 'index'],
  },
  {
    id: 'page:book',
    title: 'Book a crew',
    hint: '/book',
    category: 'Pages',
    contexts: ['global', 'customer'],
    href: '/book',
    keywords: ['booking', 'reserve', 'schedule'],
  },
  {
    id: 'page:pricing',
    title: 'See pricing',
    hint: '/#pricing',
    category: 'Pages',
    contexts: ['global'],
    href: '/#pricing',
  },
  {
    id: 'page:contact',
    title: 'Contact us',
    hint: '/#contact',
    category: 'Pages',
    contexts: ['global'],
    href: '/#contact',
  },
  {
    id: 'page:track',
    title: 'Track a booking',
    hint: '/track',
    category: 'Customer',
    contexts: ['global', 'customer'],
    href: '/me',
    keywords: ['tracking', 'status'],
  },
  {
    id: 'page:account',
    title: 'My account',
    hint: '/me',
    category: 'Customer',
    contexts: ['global', 'customer'],
    href: '/me',
  },
  {
    id: 'page:admin',
    title: 'Open mission control',
    hint: '/admin',
    category: 'Admin',
    contexts: ['admin'],
    href: '/admin',
  },
  {
    id: 'page:work-dashboard',
    title: 'Worker dashboard',
    hint: '/work/dashboard',
    category: 'Worker',
    contexts: ['worker', 'global'],
    href: '/work/dashboard',
  },

  // ── Customer actions (Wave 13B) ────────────────────────────────────
  {
    id: 'cust:rebook',
    title: 'Rebook last crew',
    hint: 'Repeat your last booking',
    category: 'Customer',
    contexts: ['customer'],
    href: '/me?action=rebook',
    keywords: ['repeat', 'again'],
  },
  {
    id: 'cust:view-photos',
    title: 'View job photos',
    hint: 'Before / after gallery',
    category: 'Customer',
    contexts: ['customer'],
    href: '/me?tab=photos',
    keywords: ['gallery', 'pictures'],
  },
  {
    id: 'cust:request-crew',
    title: 'Request a specific crew',
    category: 'Customer',
    contexts: ['customer'],
    href: '/me?action=request-crew',
  },

  // ── Worker actions (Wave 13C) ──────────────────────────────────────
  {
    id: 'work:claim-gig',
    title: 'Claim an open gig',
    hint: 'Browse + accept',
    category: 'Worker',
    contexts: ['worker'],
    href: '/work/dashboard#gigs',
    keywords: ['accept', 'pickup'],
  },
  {
    id: 'work:mark-on-the-way',
    title: 'Mark on-the-way',
    hint: 'Notify the customer',
    category: 'Worker',
    contexts: ['worker'],
    href: '/work/dashboard#today',
    keywords: ['eta', 'arriving'],
  },
  {
    id: 'work:payouts',
    title: 'Payout history',
    category: 'Worker',
    contexts: ['worker'],
    href: '/work/payouts',
  },

  // ── Admin actions (Wave 4F) ────────────────────────────────────────
  {
    id: 'admin:refund',
    title: 'Issue refund',
    hint: 'Square payment',
    category: 'Admin',
    contexts: ['admin'],
    href: '/admin#bookings',
    keywords: ['payment', 'square'],
  },
  {
    id: 'admin:sms-blast',
    title: 'Send SMS blast',
    hint: 'Twilio',
    category: 'Admin',
    contexts: ['admin'],
    href: '/admin#workers',
    keywords: ['twilio', 'message'],
  },
  {
    id: 'admin:force-dispatch',
    title: 'Force dispatch a gig',
    category: 'Admin',
    contexts: ['admin'],
    href: '/admin#bookings',
    keywords: ['assign', 'override'],
  },

  // ── Square (Wave 13A) ──────────────────────────────────────────────
  {
    id: 'sq:sync-customer',
    title: 'Sync customer to Square',
    category: 'Square',
    contexts: ['admin'],
    href: '/admin#customers',
    keywords: ['square', 'sync'],
  },
  {
    id: 'sq:lookup-payment',
    title: 'Look up Square payment',
    category: 'Square',
    contexts: ['admin'],
    href: '/admin#bookings',
    keywords: ['payment', 'lookup', 'square'],
  },
  {
    id: 'sq:view-receipt',
    title: 'View Square receipt',
    category: 'Square',
    contexts: ['admin', 'customer'],
    href: '/admin#bookings',
    keywords: ['receipt', 'square'],
  },
];

/** Canonical built-in command list. */
export const DEFAULT_COMMANDS: readonly CmdKCommand[] = STATIC_COMMANDS;

/** Pure filter: keep commands whose `contexts` array contains `ctx`. */
export function filterCommandsForContext(
  commands: readonly CmdKCommand[],
  ctx: CmdKContext,
): readonly CmdKCommand[] {
  return commands.filter((c) => c.contexts.includes(ctx) || c.contexts.includes('global'));
}

/** Fuzzy search: title + hint + keywords contain query (case-insensitive). */
export function searchCommands(
  commands: readonly CmdKCommand[],
  query: string,
): readonly CmdKCommand[] {
  const q = query.trim().toLowerCase();
  if (!q) return commands;
  return commands.filter((c) => {
    const haystack = `${c.title} ${c.hint ?? ''} ${(c.keywords ?? []).join(' ')}`.toLowerCase();
    return haystack.includes(q);
  });
}

/** Pure grouping by category, preserving original order within each group. */
export function groupCommands(
  commands: readonly CmdKCommand[],
): readonly { category: CmdKCategory; items: readonly CmdKCommand[] }[] {
  const order: CmdKCategory[] = ['Customer', 'Worker', 'Admin', 'Square', 'Pages', 'AI', 'Help'];
  const map = new Map<CmdKCategory, CmdKCommand[]>();
  for (const c of commands) {
    const bucket = map.get(c.category) ?? [];
    bucket.push(c);
    map.set(c.category, bucket);
  }
  return order
    .filter((k) => map.has(k))
    .map((category) => ({ category, items: map.get(category)! }));
}
