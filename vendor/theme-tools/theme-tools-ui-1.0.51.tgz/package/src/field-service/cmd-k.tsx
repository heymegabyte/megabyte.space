/**
 * Backwards-compat shim for the pre-Wave-13D global palette.
 *
 * The standalone `<CmdKPalette />` listener used to fight `<AiChat />`
 * and the admin palette for the same Cmd+K keystroke. Wave 13D unified
 * all three behind `<UnifiedCmdK />` (see `cmd-k-rotator.tsx`).
 *
 * This file re-exports the unified component under the legacy name so
 * existing `import { CmdKPalette } from './lib/cmd-k'` callers keep
 * working without an App.tsx edit.
 */

export {
  CmdKRotatorProvider,
  UnifiedCmdK as CmdKPalette,
  UnifiedCmdK,
  useCmdKState,
  advanceState,
  escState,
} from './cmd-k-rotator.js';
export type { CmdKState, CmdKRotatorApi, CmdKRotatorProviderProps } from './cmd-k-rotator.js';
