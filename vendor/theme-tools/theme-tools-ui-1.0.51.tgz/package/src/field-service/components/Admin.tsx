import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { lazy, Suspense, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { CrewSentimentCard } from './admin/CrewSentimentCard.js';
import { useCmdKState } from '../cmd-k-rotator.js';
import { useRovingTabs, type RovingRadioOptionProps } from '../use-roving-radio.js';
import { usd0, usd } from '@theme.tools/billing/field-service/money';

const AdminAiGrid = lazy(() => import('./AdminAiGrid.js'));

const TITLE = 'Admin — Brick Labor';
const KEY_STORAGE = 'bcl-admin-key-v1';

interface Booking {
  id: string;
  created_at: string;
  status: string;
  customer_name: string;
  customer_email: string;
  customer_phone: string | null;
  address: string;
  city: string;
  zip: string;
  preferred_date: string;
  preferred_time: string;
  hours: number;
  crew: number;
  total_cents: number;
  source: string | null;
  notes: string;
  notes_internal: string | null;
  paid_at: string | null;
  completed_at: string | null;
  canceled_at: string | null;
}

interface WorkerRow {
  id: string;
  status: string;
  tier: string;
  first_name: string;
  last_name: string;
  phone: string;
  email: string | null;
  city: string | null;
  state: string | null;
  can_drive: number;
  rating_avg: number | null;
  rating_count: number;
  jobs_completed: number;
  pending_docs: number;
  created_at: string;
}

interface WorkerDocRow {
  id: string;
  worker_id: string;
  kind: string;
  mime: string;
  size_bytes: number;
  status: string;
  license_number: string | null;
  license_state: string | null;
  license_expiry: string | null;
  expires_at: string | null;
  created_at: string;
  first_name: string;
  last_name: string;
  phone: string;
}

interface CustomerRow {
  email: string;
  name: string;
  phone: string | null;
  bookings: number;
  cents: number;
  last_seen: string;
  last_city: string | null;
  last_zip: string | null;
  completed_jobs: number;
  canceled_jobs: number;
}

interface OverviewData {
  ok: boolean;
  revenue: {
    today: { count: number; cents: number };
    week: { count: number; cents: number };
    month: { count: number; cents: number };
    ytd: { count: number; cents: number };
  };
  statusBreakdown: Array<{ status: string; n: number }>;
  upcomingToday: Array<Record<string, unknown>>;
  upcomingTomorrow: Array<Record<string, unknown>>;
  sparkBookings: Array<{ d: string; n: number; cents: number }>;
  workers: {
    verified: number;
    pending: number;
    applicant: number;
    pending_docs: number;
    open_gigs: number;
    holding_payouts: number;
    holding_cents: number;
    open_incidents: number;
  };
  topCustomers: Array<Record<string, unknown>>;
  recentActivity: Array<{
    id: string;
    created_at: string;
    entity_type: string;
    entity_id: string;
    action: string;
    detail: string | null;
  }>;
}

interface PulseData {
  ok: boolean;
  counts: {
    new_bookings_5m: number;
    open_gigs: number;
    pending_docs: number;
    holding_payouts: number;
    open_incidents: number;
    last_booking_at: string | null;
    last_audit_at: string | null;
  };
  ts: string;
}

const STATUSES: Array<string> = [
  'pending_payment',
  'pending_confirmation',
  'paid',
  'paid_in_full',
  'confirmed',
  'reminded',
  'in_progress',
  'en_route',
  'completed',
  'review_requested',
  'canceled',
  'error',
];

type Tab =
  | 'overview'
  | 'bookings'
  | 'payments'
  | 'calendar'
  | 'customers'
  | 'map'
  | 'workers'
  | 'docs'
  | 'payouts'
  | 'audit'
  | 'insights'
  | 'sms';

const TABS: Array<{ id: Tab; label: string; hint: string }> = [
  { id: 'overview', label: 'Overview', hint: 'KPIs, today/tomorrow, pulse' },
  { id: 'bookings', label: 'Bookings', hint: 'Manage jobs + bulk actions' },
  { id: 'payments', label: 'Payments', hint: 'Payment info + refunds + form submissions' },
  { id: 'calendar', label: 'Calendar', hint: '14+60 day forward grid' },
  { id: 'customers', label: 'Customers', hint: 'CLV sort + per-customer drawer' },
  { id: 'map', label: 'Map', hint: 'Geo view of jobs + workers' },
  { id: 'workers', label: 'Workers', hint: 'Crew roster + tier + can-drive' },
  { id: 'docs', label: 'Docs', hint: 'License/cert review queue' },
  { id: 'payouts', label: 'Payouts', hint: 'Holding queue (CashApp/Venmo/Zelle)' },
  { id: 'audit', label: 'Audit', hint: 'Recent actions feed' },
  { id: 'insights', label: 'AI Insights', hint: 'Workers AI memo on trends' },
  { id: 'sms', label: 'SMS · Quarterly nudge', hint: 'Seasonal text to opted-in past customers' },
];

export function Admin() {
  useThemeToolsSurface('admin');
  const [token, setToken] = useState(() => {
    try {
      return localStorage.getItem(KEY_STORAGE) || '';
    } catch {
      return '';
    }
  });
  const [draftToken, setDraftToken] = useState('');
  const [tab, setTab] = useState<Tab>(() => {
    try {
      const h = (window.location.hash || '').replace('#', '');
      const found = TABS.find((t) => t.id === h);
      return found?.id || 'overview';
    } catch {
      return 'overview';
    }
  });
  const [error, setError] = useState('');
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [pulse, setPulse] = useState<PulseData | null>(null);
  // ARIA roving-tabindex for the admin-sections tablist (axe-blind interaction gap).
  const sectionTab = useRovingTabs(TABS.length, (i) => setTab(TABS[i]!.id));

  useEffect(() => {
    document.title = TITLE;
    setMeta('robots', 'noindex,nofollow');
  }, []);

  useEffect(() => {
    if (!token) return;
    let cancelled = false;
    const tick = async () => {
      try {
        const res = await fetch('/admin/pulse', { headers: { Authorization: `Bearer ${token}` } });
        if (!res.ok || cancelled) return;
        const data = (await res.json()) as PulseData;
        if (!cancelled) setPulse(data);
      } catch {
        /* noop */
      }
    };
    void tick();
    const id = window.setInterval(tick, 30_000);
    return () => {
      cancelled = true;
      window.clearInterval(id);
    };
  }, [token]);

  // Wave 13D: Cmd+K is owned by the unified rotator. Admin no longer
  // listens for the keystroke locally — instead it registers a "Search
  // bookings, workers, gigs" command in the rotator's palette that opens
  // the rich admin search UI on demand, and still honors local Esc to
  // close that UI without advancing the rotator cycle.
  const cmdk = useCmdKState();
  useEffect(() => {
    const teardown = cmdk.registerCommands([
      {
        id: 'admin:search',
        title: 'Search bookings, workers, gigs',
        hint: 'Admin live search',
        category: 'Admin',
        contexts: ['admin'],
        keywords: ['search', 'find', 'lookup'],
        run: () => setPaletteOpen(true),
      },
    ]);
    return teardown;
  }, [cmdk]);

  useEffect(() => {
    if (!paletteOpen) return;
    function onEsc(e: KeyboardEvent) {
      if (e.key === 'Escape') setPaletteOpen(false);
    }
    window.addEventListener('keydown', onEsc);
    return () => window.removeEventListener('keydown', onEsc);
  }, [paletteOpen]);

  useEffect(() => {
    try {
      window.history.replaceState(null, '', `#${tab}`);
    } catch {
      /* noop */
    }
  }, [tab]);

  function saveToken(e: React.FormEvent) {
    e.preventDefault();
    if (!draftToken) return;
    try {
      localStorage.setItem(KEY_STORAGE, draftToken);
    } catch {
      /* noop */
    }
    setToken(draftToken);
    setDraftToken('');
  }

  function logout() {
    try {
      localStorage.removeItem(KEY_STORAGE);
    } catch {
      /* noop */
    }
    setToken('');
  }

  function handleUnauthorized() {
    try {
      localStorage.removeItem(KEY_STORAGE);
    } catch {
      /* noop */
    }
    setToken('');
    setError('Invalid key. Re-enter.');
  }

  if (!token) {
    return (
      <article className="pt-10 pb-20 sm:pt-14 sm:pb-28">
        <div className="container-pad max-w-md">
          <p className="eyebrow mb-3">Brian only · Bird's Eye · Super Admin</p>
          <h1 className="text-3xl font-extrabold mb-2">Mission Control</h1>
          <p className="text-brand-mute mb-6 text-sm">
            Paste the owner key (env var{' '}
            <code className="font-mono text-xs text-brand-ink">OWNER_INVOICE_KEY</code>). Stored
            only in this browser.
          </p>
          <form onSubmit={saveToken} className="space-y-3">
            <input
              type="password"
              value={draftToken}
              onChange={(e) => setDraftToken(e.target.value)}
              placeholder="OWNER_INVOICE_KEY"
              autoComplete="off"
              className="input w-full"
              required
            />
            <button type="submit" className="btn-primary w-full">
              Sign in
            </button>
            {error && (
              <p role="alert" className="text-sm text-red-400">
                {error}
              </p>
            )}
          </form>
        </div>
      </article>
    );
  }

  return (
    <article className="pt-6 pb-20 sm:pt-8 sm:pb-28">
      <div className="container-pad">
        <header className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="eyebrow mb-1 flex items-center gap-2 text-brand-accent">
              Brian only · Bird's Eye · Super Admin
              <PulseDot pulse={pulse} />
            </p>
            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight">Live Ops Surface</h1>
            {pulse && (
              <p className="text-xs text-brand-mute mt-1 font-mono">
                {pulse.counts.new_bookings_5m > 0 && (
                  <span className="text-brand-accent">+{pulse.counts.new_bookings_5m} new · </span>
                )}
                {pulse.counts.open_gigs} open gig{pulse.counts.open_gigs === 1 ? '' : 's'} ·{' '}
                {pulse.counts.pending_docs} doc{pulse.counts.pending_docs === 1 ? '' : 's'} ·{' '}
                {pulse.counts.holding_payouts} payout{pulse.counts.holding_payouts === 1 ? '' : 's'}{' '}
                held · {pulse.counts.open_incidents} incident
                {pulse.counts.open_incidents === 1 ? '' : 's'}
              </p>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setPaletteOpen(true)}
              className="rounded-lg border border-brand-line px-3 py-1.5 text-xs text-brand-mute hover:border-brand-accent hover:text-brand-accent transition-colors font-mono"
            >
              <span aria-hidden>⌘K</span> Search
            </button>
            <button onClick={logout} className="btn-secondary py-2 text-sm">
              Sign out
            </button>
          </div>
        </header>

        <nav
          className="mb-6 -mx-2 flex gap-1 overflow-x-auto rounded-2xl border border-brand-line bg-brand-card/40 px-2 py-1.5 backdrop-blur-sm"
          role="tablist"
          aria-label="Admin sections"
        >
          {TABS.map((t, i) => (
            <TabBtn
              key={t.id}
              active={tab === t.id}
              onClick={() => setTab(t.id)}
              hint={t.hint}
              roving={sectionTab(i, tab === t.id)}
            >
              {t.label}
            </TabBtn>
          ))}
        </nav>

        {tab === 'overview' && (
          <OverviewPanel token={token} onUnauthorized={handleUnauthorized} onJump={setTab} />
        )}
        {tab === 'bookings' && <BookingsPanel token={token} onUnauthorized={handleUnauthorized} />}
        {tab === 'payments' && <PaymentsPanel token={token} onUnauthorized={handleUnauthorized} />}
        {tab === 'calendar' && <CalendarPanel token={token} onUnauthorized={handleUnauthorized} />}
        {tab === 'customers' && (
          <CustomersPanel token={token} onUnauthorized={handleUnauthorized} />
        )}
        {tab === 'map' && <MapPanel token={token} onUnauthorized={handleUnauthorized} />}
        {tab === 'workers' && (
          <div className="space-y-6">
            <CrewSentimentCard token={token} onUnauthorized={handleUnauthorized} />
            <WorkersPanel token={token} onUnauthorized={handleUnauthorized} />
          </div>
        )}
        {tab === 'docs' && <DocReviewPanel token={token} onUnauthorized={handleUnauthorized} />}
        {tab === 'payouts' && <PayoutsPanel token={token} onUnauthorized={handleUnauthorized} />}
        {tab === 'audit' && <AuditPanel token={token} onUnauthorized={handleUnauthorized} />}
        {tab === 'insights' && <InsightsPanel token={token} onUnauthorized={handleUnauthorized} />}
        {tab === 'sms' && <QuarterlySmsPanel token={token} onUnauthorized={handleUnauthorized} />}

        {paletteOpen && (
          <CommandPalette
            token={token}
            onClose={() => setPaletteOpen(false)}
            onJump={(t) => {
              setTab(t);
              setPaletteOpen(false);
            }}
          />
        )}
      </div>
    </article>
  );
}

function PulseDot({ pulse }: { pulse: PulseData | null }) {
  if (!pulse) return null;
  const alert =
    pulse.counts.holding_payouts > 0 ||
    pulse.counts.pending_docs > 0 ||
    pulse.counts.open_incidents > 0;
  const cls = alert
    ? 'bg-amber-400 shadow-[0_0_10px_rgba(251,191,36,0.6)]'
    : 'bg-emerald-400 shadow-[0_0_10px_rgba(74,222,128,0.6)]';
  return (
    <span
      aria-label={alert ? 'attention required' : 'all clear'}
      className={`inline-block h-2 w-2 rounded-full ${cls} animate-pulse`}
    />
  );
}

function TabBtn({
  active,
  onClick,
  children,
  hint,
  roving,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
  hint?: string;
  roving?: RovingRadioOptionProps;
}) {
  return (
    <button
      type="button"
      role="tab"
      aria-selected={active}
      title={hint}
      onClick={onClick}
      {...roving}
      className={`rounded-xl px-3.5 py-1.5 text-sm font-semibold whitespace-nowrap transition motion-reduce:transition-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent ${
        active
          ? 'bg-brand-accent text-black shadow-glow'
          : 'text-brand-mute hover:text-brand-ink hover:bg-brand-line/30'
      }`}
    >
      {children}
    </button>
  );
}

// ─────────────────────────── Overview ────────────────────────────────────────
function OverviewPanel({
  token,
  onUnauthorized,
  onJump,
}: {
  token: string;
  onUnauthorized: () => void;
  onJump: (t: Tab) => void;
}) {
  const [data, setData] = useState<OverviewData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [aiQuery, setAiQuery] = useState('');
  const [aiAnswer, setAiAnswer] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [aiScope, setAiScope] = useState<'all' | 'bookings' | 'workers' | 'gigs'>('all');
  const [aiSnapshot, setAiSnapshot] = useState<{
    bookings?: Record<string, unknown>[];
    workers?: Record<string, unknown>[];
    gigs?: Record<string, unknown>[];
  } | null>(null);
  const [aiGridTab, setAiGridTab] = useState<'bookings' | 'workers' | 'gigs'>('bookings');
  const [aiHistory, setAiHistory] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('bcl_admin_ai_history') || '[]') as string[];
    } catch {
      return [];
    }
  });
  const [aiLastMs, setAiLastMs] = useState<number | null>(null);
  const aiInputRef = useRef<HTMLInputElement | null>(null);

  const PRESETS: {
    label: string;
    query: string;
    scope: 'all' | 'bookings' | 'workers' | 'gigs';
  }[] = [
    {
      label: 'Pending bookings today',
      query: 'List all bookings with status pending that were created or scheduled today',
      scope: 'bookings',
    },
    {
      label: 'Workers awaiting docs',
      query: 'Which workers have pending document verification or missing background checks?',
      scope: 'workers',
    },
    {
      label: 'Unfilled gigs this week',
      query: 'Show gigs where crew_filled < crew_needed and start_at is within the next 7 days',
      scope: 'gigs',
    },
    {
      label: 'Top Newark ZIPs',
      query: 'Which Newark ZIPs booked the most this month? Group by zip and show totals.',
      scope: 'bookings',
    },
    {
      label: 'Revenue today',
      query:
        'What is total revenue today and how does it compare to yesterday and the 7-day average?',
      scope: 'bookings',
    },
    {
      label: 'High-rated workers',
      query:
        'List active workers with rating_avg >= 4.7 and at least 5 completed jobs, sorted by rating',
      scope: 'workers',
    },
  ];

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      const target = e.target as HTMLElement | null;
      const tag = target?.tagName.toLowerCase();
      if (tag === 'input' || tag === 'textarea' || target?.isContentEditable) return;
      if (e.key === '/') {
        e.preventDefault();
        aiInputRef.current?.focus();
      }
    }
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/admin/overview', { headers: { Authorization: `Bearer ${token}` } });
      if (res.status === 401) {
        onUnauthorized();
        return;
      }
      const d = (await res.json()) as OverviewData;
      setData(d);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load.');
    } finally {
      setLoading(false);
    }
  }, [token, onUnauthorized]);

  useEffect(() => {
    void load();
  }, [load]);

  async function executeAiSearch(query: string, scope: typeof aiScope) {
    if (!query.trim()) return;
    setAiLoading(true);
    setAiAnswer('');
    setAiSnapshot(null);
    const t0 = performance.now();
    try {
      const res = await fetch('/admin/ai/search', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ query, scope }),
      });
      if (res.status === 401) {
        onUnauthorized();
        return;
      }
      const d = (await res.json()) as {
        ok: boolean;
        answer?: string;
        snapshot?: {
          bookings?: Record<string, unknown>[];
          workers?: Record<string, unknown>[];
          gigs?: Record<string, unknown>[];
        };
      };
      setAiAnswer(d.answer || 'No answer.');
      setAiSnapshot(d.snapshot ?? null);
      if (d.snapshot) {
        const order: Array<'bookings' | 'workers' | 'gigs'> = ['bookings', 'workers', 'gigs'];
        const first = order.find((k) => (d.snapshot?.[k]?.length ?? 0) > 0);
        if (first) setAiGridTab(first);
      }
      setAiHistory((prev) => {
        const next = [query, ...prev.filter((q) => q !== query)].slice(0, 8);
        try {
          localStorage.setItem('bcl_admin_ai_history', JSON.stringify(next));
        } catch {
          /* noop */
        }
        return next;
      });
    } catch (e) {
      setAiAnswer(`Error: ${e instanceof Error ? e.message : 'failed'}`);
    } finally {
      setAiLoading(false);
      setAiLastMs(Math.round(performance.now() - t0));
    }
  }

  async function runAiSearch(e: React.FormEvent) {
    e.preventDefault();
    await executeAiSearch(aiQuery, aiScope);
  }

  function runPreset(p: { query: string; scope: typeof aiScope }) {
    setAiQuery(p.query);
    setAiScope(p.scope);
    void executeAiSearch(p.query, p.scope);
  }

  function clearAiHistory() {
    setAiHistory([]);
    try {
      localStorage.removeItem('bcl_admin_ai_history');
    } catch {
      /* noop */
    }
  }

  const aiGridRows = useMemo(() => {
    if (!aiSnapshot) return [];
    return aiSnapshot[aiGridTab] ?? [];
  }, [aiSnapshot, aiGridTab]);

  function exportAiCsv() {
    if (aiGridRows.length === 0) return;
    const cols = Object.keys(aiGridRows[0]!);
    const esc = (v: unknown) => {
      const s =
        v === null || v === undefined ? '' : typeof v === 'object' ? JSON.stringify(v) : String(v);
      return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const csv = [
      cols.join(','),
      ...aiGridRows.map((r) => cols.map((c) => esc((r as Record<string, unknown>)[c])).join(',')),
    ].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bcl-ai-${aiGridTab}-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  if (loading && !data)
    return (
      <p className="text-brand-mute">
        <span className="spinner mr-2" /> Loading…
      </p>
    );
  if (error) return <p className="text-red-400">{error}</p>;
  if (!data) return null;

  return (
    <div className="space-y-6">
      <form
        onSubmit={runAiSearch}
        className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
      >
        <div className="mb-2 flex items-center justify-between">
          <label className="eyebrow">Ask the data</label>
          <span className="font-mono text-[10px] uppercase tracking-wider text-brand-mute">
            press <kbd className="rounded border border-brand-line px-1">/</kbd> to focus
          </span>
        </div>
        <div className="mb-3 flex flex-wrap gap-1.5">
          {PRESETS.map((p) => (
            <button
              key={p.label}
              type="button"
              onClick={() => runPreset(p)}
              disabled={aiLoading}
              className="rounded-full border border-brand-line bg-bg-primary px-3 py-1 text-[11px] text-brand-mute hover:border-brand-accent hover:text-brand-accent disabled:opacity-40"
            >
              {p.label}
            </button>
          ))}
        </div>
        <div className="flex flex-wrap gap-2">
          <select
            value={aiScope}
            onChange={(e) => setAiScope(e.target.value as typeof aiScope)}
            aria-label="Scope"
            className="input py-2 text-sm"
            style={{ maxWidth: 140 }}
          >
            <option value="all">All</option>
            <option value="bookings">Bookings</option>
            <option value="workers">Workers</option>
            <option value="gigs">Gigs</option>
          </select>
          <input
            ref={aiInputRef}
            type="text"
            value={aiQuery}
            onChange={(e) => setAiQuery(e.target.value)}
            placeholder="e.g. which Newark zip booked most this month?"
            className="input flex-1 py-2 text-sm"
            aria-label="Natural language search"
          />
          <button
            type="submit"
            disabled={aiLoading || !aiQuery.trim()}
            className="btn-primary py-2 text-sm disabled:opacity-50"
          >
            {aiLoading ? 'Thinking…' : 'Ask'}
          </button>
          {aiAnswer && !aiLoading && (
            <button
              type="button"
              onClick={() => void executeAiSearch(aiQuery, aiScope)}
              className="rounded-md border border-brand-line px-3 py-2 font-mono text-[10px] uppercase tracking-wider text-brand-mute hover:border-brand-accent hover:text-brand-accent"
              title="Re-run last query"
            >
              ↻ Refresh
            </button>
          )}
        </div>
        {aiHistory.length > 0 && (
          <div className="mt-3 flex flex-wrap items-center gap-1.5">
            <span className="font-mono text-[10px] uppercase tracking-wider text-brand-mute">
              Recent
            </span>
            {aiHistory.slice(0, 5).map((q, i) => (
              <button
                key={`${q}-${i}`}
                type="button"
                onClick={() => {
                  setAiQuery(q);
                  void executeAiSearch(q, aiScope);
                }}
                disabled={aiLoading}
                className="max-w-[280px] truncate rounded-md border border-brand-line px-2 py-0.5 text-[11px] text-brand-mute hover:border-brand-accent hover:text-brand-accent disabled:opacity-40"
                title={q}
              >
                {q.length > 48 ? `${q.slice(0, 48)}…` : q}
              </button>
            ))}
            <button
              type="button"
              onClick={clearAiHistory}
              className="ml-1 font-mono text-[10px] uppercase tracking-wider text-brand-mute hover:text-red-400"
            >
              Clear
            </button>
          </div>
        )}
        {aiAnswer && (
          <>
            <pre className="mt-3 whitespace-pre-wrap rounded-lg border border-brand-line bg-bg-primary p-3 text-sm text-brand-ink font-sans">
              {aiAnswer}
            </pre>
            <div className="mt-1.5 flex items-center justify-between text-[10px] font-mono uppercase tracking-wider text-brand-mute">
              <span>{aiLastMs !== null ? `${aiLastMs}ms` : ''}</span>
              <button
                type="button"
                onClick={() => {
                  void navigator.clipboard.writeText(aiAnswer);
                }}
                className="hover:text-brand-accent"
              >
                Copy answer
              </button>
            </div>
          </>
        )}

        {aiSnapshot && (
          <div className="mt-4 space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="eyebrow">Result set</span>
              {(['bookings', 'workers', 'gigs'] as const).map((kind) => {
                const n = aiSnapshot[kind]?.length ?? 0;
                if (n === 0) return null;
                return (
                  <button
                    key={kind}
                    type="button"
                    onClick={() => setAiGridTab(kind)}
                    className={`rounded-md border px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider ${
                      aiGridTab === kind
                        ? 'border-brand-accent text-brand-accent'
                        : 'border-brand-line text-brand-mute hover:border-brand-accent hover:text-brand-accent'
                    }`}
                  >
                    {kind} · {n}
                  </button>
                );
              })}
              {aiGridRows.length > 0 && (
                <button
                  type="button"
                  onClick={exportAiCsv}
                  className="ml-auto rounded-md border border-brand-line px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider text-brand-mute hover:border-brand-accent hover:text-brand-accent"
                >
                  Export CSV
                </button>
              )}
            </div>
            {aiGridRows.length === 0 ? (
              <p className="text-sm text-brand-mute">No rows in the {aiGridTab} snapshot.</p>
            ) : (
              <Suspense
                fallback={
                  <p className="text-sm text-brand-mute">
                    <span className="spinner mr-2" /> Loading grid…
                  </p>
                }
              >
                <AdminAiGrid rows={aiGridRows} kind={aiGridTab} />
              </Suspense>
            )}
          </div>
        )}
      </form>

      <section className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Kpi label="Today" cents={data.revenue.today.cents} count={data.revenue.today.count} />
        <Kpi label="7 days" cents={data.revenue.week.cents} count={data.revenue.week.count} />
        <Kpi label="30 days" cents={data.revenue.month.cents} count={data.revenue.month.count} />
        <Kpi label="YTD" cents={data.revenue.ytd.cents} count={data.revenue.ytd.count} />
      </section>

      <section className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <MiniStat label="Open gigs" value={data.workers.open_gigs} tone="info" />
        <MiniStat
          label="Docs pending"
          value={data.workers.pending_docs}
          tone={data.workers.pending_docs > 0 ? 'warn' : 'ok'}
          onClick={() => onJump('docs')}
        />
        <MiniStat
          label="Payouts held"
          value={data.workers.holding_payouts}
          extra={usd0(data.workers.holding_cents)}
          tone={data.workers.holding_payouts > 0 ? 'warn' : 'ok'}
          onClick={() => onJump('payouts')}
        />
        <MiniStat
          label="Open incidents"
          value={data.workers.open_incidents}
          tone={data.workers.open_incidents > 0 ? 'alert' : 'ok'}
        />
      </section>

      <section className="rounded-2xl border border-brand-line p-4">
        <h2 className="text-lg font-extrabold mb-2">30-day sparkline</h2>
        <Sparkline points={data.sparkBookings} />
      </section>

      <section className="grid lg:grid-cols-2 gap-4">
        <div className="rounded-2xl border border-brand-line p-4">
          <h2 className="text-lg font-extrabold mb-3">Today's jobs</h2>
          {data.upcomingToday.length === 0 ? (
            <p className="text-sm text-brand-mute">Nothing on the books today.</p>
          ) : (
            <ul className="space-y-2 text-sm">
              {data.upcomingToday.map((b) => {
                const row = b as Record<string, string | number>;
                return (
                  <li
                    key={row.id as string}
                    className="flex items-center justify-between gap-2 rounded-lg border border-brand-line px-3 py-2"
                  >
                    <div className="min-w-0">
                      <div className="font-semibold truncate">
                        {row.preferred_time} · {row.customer_name}
                      </div>
                      <div className="text-xs text-brand-mute truncate">
                        {row.address}, {row.city} · {row.hours}h · {row.crew} crew
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="font-mono text-brand-accent">
                        ${(Number(row.total_cents) / 100).toFixed(0)}
                      </div>
                      <div className="text-[10px] text-brand-mute uppercase">{row.status}</div>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
        <div className="rounded-2xl border border-brand-line p-4">
          <h2 className="text-lg font-extrabold mb-3">Tomorrow's jobs</h2>
          {data.upcomingTomorrow.length === 0 ? (
            <p className="text-sm text-brand-mute">Quiet tomorrow.</p>
          ) : (
            <ul className="space-y-2 text-sm">
              {data.upcomingTomorrow.map((b) => {
                const row = b as Record<string, string | number>;
                return (
                  <li
                    key={row.id as string}
                    className="flex items-center justify-between gap-2 rounded-lg border border-brand-line px-3 py-2"
                  >
                    <div className="min-w-0">
                      <div className="font-semibold truncate">
                        {row.preferred_time} · {row.customer_name}
                      </div>
                      <div className="text-xs text-brand-mute truncate">
                        {row.address}, {row.city} · {row.hours}h · {row.crew} crew
                      </div>
                    </div>
                    <div className="font-mono text-brand-accent shrink-0">
                      ${(Number(row.total_cents) / 100).toFixed(0)}
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </section>

      <section className="grid lg:grid-cols-2 gap-4">
        <div className="rounded-2xl border border-brand-line p-4">
          <h2 className="text-lg font-extrabold mb-3">Status breakdown (30d)</h2>
          {data.statusBreakdown.length === 0 ? (
            <p className="text-sm text-brand-mute">No bookings in window.</p>
          ) : (
            <ul className="space-y-1.5 text-sm">
              {data.statusBreakdown.map((s) => (
                <li key={s.status} className="flex items-center justify-between">
                  <span className="text-brand-mute">{s.status.replace(/_/g, ' ')}</span>
                  <span className="font-mono">{s.n}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="rounded-2xl border border-brand-line p-4">
          <h2 className="text-lg font-extrabold mb-3">Top customers</h2>
          {data.topCustomers.length === 0 ? (
            <p className="text-sm text-brand-mute">No customers yet.</p>
          ) : (
            <ul className="space-y-1.5 text-sm">
              {data.topCustomers.map((c) => {
                const row = c as Record<string, string | number>;
                return (
                  <li key={row.email as string} className="flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => onJump('customers')}
                      className="truncate text-left underline-hover"
                    >
                      {row.name || row.email}
                    </button>
                    <span className="font-mono text-brand-accent shrink-0">
                      ${(Number(row.cents) / 100).toFixed(0)}
                    </span>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </section>

      <section className="rounded-2xl border border-brand-line p-4">
        <header className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-extrabold">Recent activity</h2>
          <button
            onClick={() => onJump('audit')}
            className="text-xs text-brand-mute underline-hover"
          >
            All →
          </button>
        </header>
        {data.recentActivity.length === 0 ? (
          <p className="text-sm text-brand-mute">No recent activity.</p>
        ) : (
          <ul className="space-y-1 text-xs font-mono">
            {data.recentActivity.slice(0, 12).map((a) => (
              <li key={a.id} className="flex gap-3">
                <span className="text-brand-mute shrink-0">{formatRel(a.created_at)}</span>
                <span className="text-brand-accent shrink-0">{a.action}</span>
                <span className="text-brand-mute truncate">
                  {a.entity_type}/{a.entity_id.slice(0, 10)}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function Kpi({ label, cents, count }: { label: string; cents: number; count: number }) {
  return (
    <div className="rounded-2xl border border-brand-line bg-bg-elevated p-4">
      <p className="text-xs uppercase tracking-wider text-brand-mute">{label}</p>
      <p className="text-2xl font-extrabold text-brand-accent font-mono mt-1">
        ${(cents / 100).toFixed(0)}
      </p>
      <p className="text-xs text-brand-mute mt-1">
        {count} booking{count === 1 ? '' : 's'}
      </p>
    </div>
  );
}

function MiniStat({
  label,
  value,
  extra,
  tone,
  onClick,
}: {
  label: string;
  value: number;
  extra?: string;
  tone: 'ok' | 'info' | 'warn' | 'alert';
  onClick?: () => void;
}) {
  const cls =
    tone === 'alert'
      ? 'border-red-500/40 bg-red-500/10'
      : tone === 'warn'
        ? 'border-amber-500/40 bg-amber-500/10'
        : tone === 'info'
          ? 'border-brand-line bg-bg-elevated'
          : 'border-emerald-500/30 bg-emerald-500/5';
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={!onClick}
      className={`rounded-2xl border p-4 text-left transition-colors ${cls} ${onClick ? 'hover:border-brand-accent cursor-pointer' : 'cursor-default'}`}
    >
      <p className="text-xs uppercase tracking-wider text-brand-mute">{label}</p>
      <p className="text-2xl font-extrabold mt-1 font-mono">{value}</p>
      {extra && <p className="text-xs text-brand-mute mt-1">{extra}</p>}
    </button>
  );
}

function Sparkline({ points }: { points: Array<{ d: string; n: number; cents: number }> }) {
  if (!points.length) return <p className="text-sm text-brand-mute">No data.</p>;
  const max = Math.max(1, ...points.map((p) => p.cents));
  const W = 800;
  const H = 80;
  const step = points.length > 1 ? W / (points.length - 1) : W;
  const path = points
    .map((p, i) => {
      const x = i * step;
      const y = H - (p.cents / max) * H;
      return `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(' ');
  return (
    <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" className="w-full h-20">
      <path
        d={path}
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        className="text-brand-accent"
      />
      {points.map((p, i) => (
        <circle
          key={p.d}
          cx={i * step}
          cy={H - (p.cents / max) * H}
          r="2"
          className="fill-brand-accent"
        >
          <title>
            {p.d}: ${(p.cents / 100).toFixed(0)} ({p.n})
          </title>
        </circle>
      ))}
    </svg>
  );
}

// ─────────────────────────── Bookings ────────────────────────────────────────
function BookingsPanel({ token, onUnauthorized }: { token: string; onUnauthorized: () => void }) {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [bulkBusy, setBulkBusy] = useState(false);

  useEffect(() => {
    void load(token, filterStatus);
  }, [token, filterStatus]);

  async function load(t: string, status: string) {
    setLoading(true);
    setError('');
    try {
      const url = `/admin/bookings${status ? `?status=${encodeURIComponent(status)}` : ''}`;
      const res = await fetch(url, { headers: { Authorization: `Bearer ${t}` } });
      if (res.status === 401) {
        onUnauthorized();
        return;
      }
      const data = (await res.json()) as { ok: boolean; bookings: Booking[] };
      setBookings(data.bookings ?? []);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load.');
    } finally {
      setLoading(false);
    }
  }

  const filtered = useMemo(() => {
    if (!search.trim()) return bookings;
    const q = search.trim().toLowerCase();
    return bookings.filter(
      (b) =>
        b.customer_name.toLowerCase().includes(q) ||
        b.customer_email.toLowerCase().includes(q) ||
        (b.customer_phone || '').includes(q) ||
        b.address.toLowerCase().includes(q) ||
        b.city.toLowerCase().includes(q) ||
        b.id.toLowerCase().includes(q),
    );
  }, [bookings, search]);

  async function patchStatus(id: string, status: string) {
    const res = await fetch(`/admin/bookings/${id}`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    if (res.ok) void load(token, filterStatus);
  }

  async function bulkUpdate(status?: string, notes?: string) {
    if (selected.size === 0) return;
    setBulkBusy(true);
    try {
      const res = await fetch('/admin/bookings/bulk', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ids: Array.from(selected),
          ...(status ? { status } : {}),
          ...(notes != null ? { notes_internal: notes } : {}),
        }),
      });
      if (res.ok) {
        setSelected(new Set());
        void load(token, filterStatus);
      } else {
        const data = (await res.json().catch(() => ({}))) as { error?: string };
        alert(`Bulk update failed: ${data.error || res.statusText}`);
      }
    } finally {
      setBulkBusy(false);
    }
  }

  async function sendOnTheWay(id: string) {
    const eta = window.prompt('ETA in minutes?', '15');
    if (!eta) return;
    const minutes = Number(eta);
    if (!Number.isFinite(minutes) || minutes < 1 || minutes > 180) {
      alert('ETA must be 1–180 minutes.');
      return;
    }
    const res = await fetch(`/api/ontheway/${id}?eta=${minutes}`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = (await res.json().catch(() => ({}))) as {
      ok?: boolean;
      sentTo?: string;
      error?: string;
    };
    if (res.ok && data.ok) {
      alert(`Sent — ${data.sentTo}`);
      void load(token, filterStatus);
    } else alert(`Failed: ${data.error || res.statusText}`);
  }

  async function sendInvoice(id: string) {
    if (
      !confirm(
        'Send invoice now? This creates a Square payment link and texts/emails the customer.',
      )
    )
      return;
    const res = await fetch(`/api/booking-invoice/${id}`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = (await res.json().catch(() => ({}))) as {
      ok?: boolean;
      url?: string;
      error?: string;
    };
    if (res.ok && data.ok) {
      alert(`Invoice sent. Pay link: ${data.url}`);
      void load(token, filterStatus);
    } else alert(`Failed: ${data.error || res.statusText}`);
  }

  function toggleAll() {
    if (selected.size === filtered.length) setSelected(new Set());
    else setSelected(new Set(filtered.map((b) => b.id)));
  }

  return (
    <>
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Filter by name, email, phone, address, id…"
          className="input py-2 text-sm flex-1 min-w-[240px]"
          aria-label="Search bookings"
        />
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="input py-2 text-sm"
          aria-label="Filter by status"
        >
          <option value="">All statuses</option>
          {STATUSES.map((s) => (
            <option key={s} value={s}>
              {s.replace(/_/g, ' ')}
            </option>
          ))}
        </select>
        <a
          href="/admin/bookings.csv"
          onClick={(e) => {
            e.preventDefault();
            downloadCsv(token).catch(() => alert('CSV download failed'));
          }}
          className="btn-ghost py-2 text-sm"
        >
          Export CSV
        </a>
      </div>

      {selected.size > 0 && (
        <div className="mb-4 flex flex-wrap items-center gap-3 rounded-xl border border-brand-accent/40 bg-brand-accent/5 p-3">
          <span className="text-sm font-semibold text-brand-accent">{selected.size} selected</span>
          <select
            disabled={bulkBusy}
            onChange={(e) => {
              if (e.target.value) {
                void bulkUpdate(e.target.value);
                e.target.value = '';
              }
            }}
            className="input py-1.5 text-sm"
            aria-label="Bulk status change"
          >
            <option value="">Change status…</option>
            {STATUSES.map((s) => (
              <option key={s} value={s}>
                {s.replace(/_/g, ' ')}
              </option>
            ))}
          </select>
          <button
            type="button"
            disabled={bulkBusy}
            onClick={() => {
              const notes = window.prompt('Internal note for all selected? (blank to skip)');
              if (notes != null) void bulkUpdate(undefined, notes);
            }}
            className="btn-ghost py-1.5 text-sm"
          >
            Add note
          </button>
          <button
            type="button"
            onClick={() => setSelected(new Set())}
            className="text-xs text-brand-mute underline-hover"
          >
            Clear
          </button>
        </div>
      )}

      {loading && (
        <p className="text-brand-mute">
          <span className="spinner mr-2" /> Loading…
        </p>
      )}
      {error && <p className="text-red-400">{error}</p>}
      {!loading && filtered.length === 0 && <p className="text-brand-mute">No bookings match.</p>}

      {filtered.length > 0 && (
        <div className="overflow-x-auto rounded-xl border border-brand-line">
          <table className="w-full text-sm">
            <thead className="bg-bg-elevated text-left text-xs uppercase tracking-wider text-brand-mute">
              <tr>
                <th className="p-3 w-8">
                  <input
                    type="checkbox"
                    checked={selected.size > 0 && selected.size === filtered.length}
                    ref={(el) => {
                      if (el)
                        el.indeterminate = selected.size > 0 && selected.size < filtered.length;
                    }}
                    onChange={toggleAll}
                    aria-label="Select all"
                  />
                </th>
                <th className="p-3">When</th>
                <th className="p-3">Customer</th>
                <th className="p-3">Job</th>
                <th className="p-3">Total</th>
                <th className="p-3">Status</th>
                <th className="p-3">Source</th>
                <th className="p-3">Actions</th>
                <th className="p-3"></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((b) => (
                <tr
                  key={b.id}
                  className={`border-t border-brand-line align-top ${selected.has(b.id) ? 'bg-brand-accent/5' : ''}`}
                >
                  <td className="p-3">
                    <input
                      type="checkbox"
                      checked={selected.has(b.id)}
                      onChange={() => {
                        const next = new Set(selected);
                        if (next.has(b.id)) next.delete(b.id);
                        else next.add(b.id);
                        setSelected(next);
                      }}
                      aria-label={`Select ${b.id}`}
                    />
                  </td>
                  <td className="p-3 font-mono text-xs">
                    <div>{b.preferred_date}</div>
                    <div className="text-brand-mute">{b.preferred_time}</div>
                  </td>
                  <td className="p-3">
                    <div className="font-semibold">{b.customer_name}</div>
                    <div className="text-xs text-brand-mute">
                      <a href={`mailto:${b.customer_email}`} className="underline-hover">
                        {b.customer_email}
                      </a>
                    </div>
                    {b.customer_phone && (
                      <div className="text-xs text-brand-mute">
                        <a href={`tel:${b.customer_phone}`} className="underline-hover">
                          {b.customer_phone}
                        </a>
                      </div>
                    )}
                    {b.address && (
                      <div className="text-xs text-brand-mute">
                        <a
                          href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${b.address}, ${b.city} ${b.zip}`)}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="underline-hover"
                        >
                          {b.address}, {b.city} {b.zip}
                        </a>
                      </div>
                    )}
                  </td>
                  <td className="p-3 text-xs">
                    <div>
                      {b.hours}h · {b.crew} {b.crew === 1 ? 'person' : 'people'}
                    </div>
                    {b.notes && <div className="text-brand-mute mt-1 max-w-xs">"{b.notes}"</div>}
                  </td>
                  <td className="p-3 font-mono text-brand-accent">
                    ${(b.total_cents / 100).toFixed(2)}
                  </td>
                  <td className="p-3">
                    <select
                      value={b.status}
                      onChange={(e) => patchStatus(b.id, e.target.value)}
                      className="input py-1 text-xs"
                    >
                      {STATUSES.map((s) => (
                        <option key={s} value={s}>
                          {s.replace(/_/g, ' ')}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td className="p-3 text-xs text-brand-mute">{b.source || '—'}</td>
                  <td className="p-3">
                    <div className="flex flex-col gap-1">
                      {b.customer_phone && (
                        <button
                          type="button"
                          onClick={() => void sendOnTheWay(b.id)}
                          className="rounded-md border border-brand-accent/40 bg-brand-accent/10 px-2 py-1 text-[11px] font-mono text-brand-accent hover:bg-brand-accent hover:text-bg-primary transition-colors"
                        >
                          On the way →
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => void sendInvoice(b.id)}
                        className="rounded-md border border-brand-line px-2 py-1 text-[11px] font-mono text-brand-mute hover:border-brand-accent hover:text-brand-accent transition-colors"
                      >
                        Send invoice
                      </button>
                    </div>
                  </td>
                  <td className="p-3 text-xs font-mono text-brand-mute">{b.id.slice(0, 8)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}

// ─────────────────────────── Calendar ────────────────────────────────────────
function CalendarPanel({ token, onUnauthorized }: { token: string; onUnauthorized: () => void }) {
  const [rows, setRows] = useState<Array<Record<string, string | number>>>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      try {
        const res = await fetch('/admin/calendar', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.status === 401) {
          onUnauthorized();
          return;
        }
        const data = (await res.json()) as {
          ok: boolean;
          bookings: Array<Record<string, string | number>>;
        };
        if (!cancelled) setRows(data.bookings ?? []);
      } catch (e) {
        if (!cancelled) setError(e instanceof Error ? e.message : 'Failed.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [token, onUnauthorized]);

  const grouped = useMemo(() => {
    const map = new Map<string, Array<Record<string, string | number>>>();
    for (const r of rows) {
      const d = String(r.preferred_date);
      if (!map.has(d)) map.set(d, []);
      map.get(d)!.push(r);
    }
    return Array.from(map.entries()).sort(([a], [b]) => a.localeCompare(b));
  }, [rows]);

  if (loading)
    return (
      <p className="text-brand-mute">
        <span className="spinner mr-2" /> Loading…
      </p>
    );
  if (error) return <p className="text-red-400">{error}</p>;
  if (rows.length === 0) return <p className="text-brand-mute">No bookings in window.</p>;

  return (
    <div className="space-y-3">
      {grouped.map(([date, jobs]) => {
        const total = jobs.reduce((acc, j) => acc + Number(j.total_cents || 0), 0);
        return (
          <details key={date} open className="rounded-xl border border-brand-line bg-bg-elevated">
            <summary className="flex cursor-pointer items-center justify-between p-3">
              <div>
                <span className="font-semibold">{date}</span>
                <span className="ml-2 text-xs text-brand-mute">
                  {jobs.length} job{jobs.length === 1 ? '' : 's'}
                </span>
              </div>
              <span className="font-mono text-brand-accent">${(total / 100).toFixed(0)}</span>
            </summary>
            <ul className="border-t border-brand-line divide-y divide-brand-line">
              {jobs.map((j) => (
                <li
                  key={String(j.id)}
                  className="px-4 py-2 text-sm flex items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <div className="font-semibold truncate">
                      {j.preferred_time} · {j.customer_name}
                    </div>
                    <div className="text-xs text-brand-mute truncate">
                      {j.address}, {j.city} · {j.hours}h · {j.crew} crew ·{' '}
                      {String(j.status).replace(/_/g, ' ')}
                    </div>
                  </div>
                  <span className="font-mono text-brand-accent shrink-0">
                    ${(Number(j.total_cents) / 100).toFixed(0)}
                  </span>
                </li>
              ))}
            </ul>
          </details>
        );
      })}
    </div>
  );
}

// ─────────────────────────── Customers ───────────────────────────────────────
function CustomersPanel({ token, onUnauthorized }: { token: string; onUnauthorized: () => void }) {
  const [rows, setRows] = useState<CustomerRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [q, setQ] = useState('');
  const [sort, setSort] = useState<'cents' | 'recent' | 'count' | 'name'>('cents');
  const [openEmail, setOpenEmail] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const params = new URLSearchParams();
      if (q.trim()) params.set('q', q.trim());
      params.set('sort', sort);
      const res = await fetch(`/admin/customers?${params}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.status === 401) {
        onUnauthorized();
        return;
      }
      const data = (await res.json()) as { ok: boolean; customers: CustomerRow[] };
      setRows(data.customers ?? []);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load.');
    } finally {
      setLoading(false);
    }
  }, [token, onUnauthorized, q, sort]);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <>
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <input
          type="text"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search name, email, phone…"
          className="input py-2 text-sm flex-1 min-w-[240px]"
          aria-label="Search customers"
        />
        <select
          value={sort}
          onChange={(e) => setSort(e.target.value as typeof sort)}
          className="input py-2 text-sm"
          aria-label="Sort by"
        >
          <option value="cents">CLV (high → low)</option>
          <option value="count">Bookings count</option>
          <option value="recent">Most recent</option>
          <option value="name">Name (A → Z)</option>
        </select>
      </div>

      {loading && (
        <p className="text-brand-mute">
          <span className="spinner mr-2" /> Loading…
        </p>
      )}
      {error && <p className="text-red-400">{error}</p>}
      {!loading && rows.length === 0 && <p className="text-brand-mute">No customers match.</p>}

      {rows.length > 0 && (
        <div className="overflow-x-auto rounded-xl border border-brand-line">
          <table className="w-full text-sm">
            <thead className="bg-bg-elevated text-left text-xs uppercase tracking-wider text-brand-mute">
              <tr>
                <th className="p-3">Customer</th>
                <th className="p-3">CLV</th>
                <th className="p-3">Bookings</th>
                <th className="p-3">Completed</th>
                <th className="p-3">Canceled</th>
                <th className="p-3">Last seen</th>
                <th className="p-3">Last city</th>
                <th className="p-3"></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((c) => (
                <tr
                  key={c.email}
                  className="border-t border-brand-line align-top hover:bg-brand-accent/5"
                >
                  <td className="p-3">
                    <button
                      type="button"
                      onClick={() => setOpenEmail(c.email)}
                      className="font-semibold underline-hover text-left"
                    >
                      {c.name || c.email}
                    </button>
                    <div className="text-xs text-brand-mute">
                      <a href={`mailto:${c.email}`} className="underline-hover">
                        {c.email}
                      </a>
                    </div>
                    {c.phone && (
                      <div className="text-xs text-brand-mute">
                        <a href={`tel:${c.phone}`} className="underline-hover">
                          {c.phone}
                        </a>
                      </div>
                    )}
                  </td>
                  <td className="p-3 font-mono text-brand-accent">${(c.cents / 100).toFixed(0)}</td>
                  <td className="p-3 font-mono">{c.bookings}</td>
                  <td className="p-3 font-mono text-emerald-300">{c.completed_jobs}</td>
                  <td className="p-3 font-mono text-red-300">{c.canceled_jobs}</td>
                  <td className="p-3 text-xs text-brand-mute font-mono">
                    {formatRel(c.last_seen)}
                  </td>
                  <td className="p-3 text-xs text-brand-mute">{c.last_city || '—'}</td>
                  <td className="p-3 text-right">
                    <button
                      type="button"
                      onClick={() => setOpenEmail(c.email)}
                      className="text-xs text-brand-accent underline-hover"
                    >
                      Open →
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {openEmail && (
        <CustomerDrawer token={token} email={openEmail} onClose={() => setOpenEmail(null)} />
      )}
    </>
  );
}

interface CustomerDetail {
  ok: boolean;
  email: string;
  bookings: Array<Record<string, string | number>>;
  summary: {
    lifetimeCents: number;
    bookingCount: number;
    firstSeen: string | null;
    lastSeen: string | null;
  };
}

function CustomerDrawer({
  token,
  email,
  onClose,
}: {
  token: string;
  email: string;
  onClose: () => void;
}) {
  const [detail, setDetail] = useState<CustomerDetail | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(`/admin/customers/${encodeURIComponent(email)}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = (await res.json()) as CustomerDetail;
        if (!cancelled) setDetail(data);
      } catch (e) {
        if (!cancelled) setError(e instanceof Error ? e.message : 'Failed.');
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [token, email]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-stretch sm:justify-end"
      role="dialog"
      aria-modal="true"
    >
      <button
        type="button"
        aria-label="Close"
        onClick={onClose}
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
      />
      <div className="relative w-full sm:max-w-xl h-[85vh] sm:h-full bg-bg-primary border-l border-brand-line overflow-y-auto">
        <header className="sticky top-0 z-10 flex items-center justify-between gap-3 border-b border-brand-line bg-bg-primary p-4">
          <div className="min-w-0">
            <p className="eyebrow">Customer</p>
            <h2 className="text-lg font-extrabold truncate">{email}</h2>
          </div>
          <button onClick={onClose} className="btn-ghost py-1.5 text-sm">
            Close
          </button>
        </header>
        <div className="p-4 space-y-4">
          {error && <p className="text-sm text-red-400">{error}</p>}
          {!detail && !error && (
            <p className="text-sm text-brand-mute">
              <span className="spinner mr-2" /> Loading…
            </p>
          )}
          {detail && (
            <>
              <section className="grid grid-cols-3 gap-3">
                <div className="rounded-xl border border-brand-line p-3 text-center">
                  <p className="text-[10px] uppercase text-brand-mute">CLV</p>
                  <p className="font-mono text-brand-accent text-lg">
                    ${(detail.summary.lifetimeCents / 100).toFixed(0)}
                  </p>
                </div>
                <div className="rounded-xl border border-brand-line p-3 text-center">
                  <p className="text-[10px] uppercase text-brand-mute">Jobs</p>
                  <p className="font-mono text-lg">{detail.summary.bookingCount}</p>
                </div>
                <div className="rounded-xl border border-brand-line p-3 text-center">
                  <p className="text-[10px] uppercase text-brand-mute">Since</p>
                  <p className="font-mono text-xs">
                    {detail.summary.firstSeen?.slice(0, 10) || '—'}
                  </p>
                </div>
              </section>
              <section>
                <h3 className="text-sm font-extrabold mb-2">Booking history</h3>
                {detail.bookings.length === 0 ? (
                  <p className="text-sm text-brand-mute">None.</p>
                ) : (
                  <ul className="space-y-2">
                    {detail.bookings.map((b) => (
                      <li
                        key={String(b.id)}
                        className="rounded-lg border border-brand-line p-3 text-sm"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-mono text-xs">
                            {b.preferred_date} {b.preferred_time}
                          </span>
                          <span className="font-mono text-brand-accent">
                            ${(Number(b.total_cents) / 100).toFixed(0)}
                          </span>
                        </div>
                        <div className="text-xs text-brand-mute mt-1">
                          {b.address}, {b.city} · {b.hours}h · {b.crew} crew ·{' '}
                          <span className="uppercase">{b.status}</span>
                        </div>
                        {b.notes && (
                          <div className="text-xs text-brand-mute mt-1 italic">"{b.notes}"</div>
                        )}
                      </li>
                    ))}
                  </ul>
                )}
              </section>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────── Map (list-fallback) ─────────────────────────────
function MapPanel({ token, onUnauthorized }: { token: string; onUnauthorized: () => void }) {
  const [bookings, setBookings] = useState<Array<Record<string, string | number>>>([]);
  const [workers, setWorkers] = useState<Array<Record<string, string | number>>>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      try {
        const res = await fetch('/admin/map', { headers: { Authorization: `Bearer ${token}` } });
        if (res.status === 401) {
          onUnauthorized();
          return;
        }
        const data = (await res.json()) as {
          ok: boolean;
          bookings: Array<Record<string, string | number>>;
          workers: Array<Record<string, string | number>>;
        };
        if (!cancelled) {
          setBookings(data.bookings ?? []);
          setWorkers(data.workers ?? []);
        }
      } catch (e) {
        if (!cancelled) setError(e instanceof Error ? e.message : 'Failed.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [token, onUnauthorized]);

  if (loading)
    return (
      <p className="text-brand-mute">
        <span className="spinner mr-2" /> Loading…
      </p>
    );
  if (error) return <p className="text-red-400">{error}</p>;

  return (
    <div className="grid lg:grid-cols-2 gap-4">
      <section className="rounded-2xl border border-brand-line p-4">
        <h2 className="text-lg font-extrabold mb-3">Recent jobs ({bookings.length})</h2>
        {bookings.length === 0 ? (
          <p className="text-sm text-brand-mute">None.</p>
        ) : (
          <ul className="space-y-2 text-sm max-h-[600px] overflow-y-auto">
            {bookings.map((b) => (
              <li key={String(b.id)} className="rounded-lg border border-brand-line p-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-semibold truncate">{b.customer_name}</span>
                  <span className="font-mono text-brand-accent text-xs">
                    ${(Number(b.total_cents) / 100).toFixed(0)}
                  </span>
                </div>
                <a
                  href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${b.address}, ${b.city} ${b.zip}`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-brand-mute underline-hover"
                >
                  {b.address}, {b.city} {b.zip} →
                </a>
                <div className="text-[11px] text-brand-mute mt-1 uppercase">
                  {b.preferred_date} · {b.status}
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
      <section className="rounded-2xl border border-brand-line p-4">
        <h2 className="text-lg font-extrabold mb-3">Workers on map ({workers.length})</h2>
        {workers.length === 0 ? (
          <p className="text-sm text-brand-mute">No workers with location yet.</p>
        ) : (
          <ul className="space-y-2 text-sm max-h-[600px] overflow-y-auto">
            {workers.map((w) => (
              <li key={String(w.id)} className="rounded-lg border border-brand-line p-3">
                <div className="font-semibold">
                  {w.first_name} {w.last_name}
                </div>
                <div className="text-xs text-brand-mute">
                  {w.city} · tier {w.tier} · {w.can_drive ? 'can drive' : 'no drive'} · {w.lat},
                  {w.lng}
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

// ─────────────────────────── Workers (existing) ──────────────────────────────
function WorkersPanel({ token, onUnauthorized }: { token: string; onUnauthorized: () => void }) {
  const [workers, setWorkers] = useState<WorkerRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [filterStatus, setFilterStatus] = useState('');

  useEffect(() => {
    void load();
  }, [token, filterStatus]);

  async function load() {
    setLoading(true);
    setError('');
    try {
      const url = `/admin/workers${filterStatus ? `?status=${encodeURIComponent(filterStatus)}` : ''}`;
      const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
      if (res.status === 401) {
        onUnauthorized();
        return;
      }
      const data = (await res.json()) as { ok: boolean; workers: WorkerRow[] };
      setWorkers(data.workers ?? []);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load.');
    } finally {
      setLoading(false);
    }
  }

  async function flipWorker(id: string, body: Record<string, unknown>) {
    const res = await fetch(`/admin/workers/${id}`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (res.ok) void load();
  }

  return (
    <>
      <div className="mb-6 flex flex-wrap items-center gap-3">
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="input py-2 text-sm"
          aria-label="Filter workers"
        >
          <option value="">All workers</option>
          <option value="applied">Applied</option>
          <option value="approved">Approved</option>
          <option value="active">Active</option>
          <option value="paused">Paused</option>
          <option value="suspended">Suspended</option>
          <option value="terminated">Terminated</option>
        </select>
      </div>

      {loading && (
        <p className="text-brand-mute">
          <span className="spinner mr-2" /> Loading…
        </p>
      )}
      {error && <p className="text-red-400">{error}</p>}
      {!loading && workers.length === 0 && <p className="text-brand-mute">No workers.</p>}

      {workers.length > 0 && (
        <div className="overflow-x-auto rounded-xl border border-brand-line">
          <table className="w-full text-sm">
            <thead className="bg-bg-elevated text-left text-xs uppercase tracking-wider text-brand-mute">
              <tr>
                <th className="p-3">Name</th>
                <th className="p-3">Phone</th>
                <th className="p-3">Tier</th>
                <th className="p-3">Status</th>
                <th className="p-3">Jobs</th>
                <th className="p-3">Rating</th>
                <th className="p-3">Drive</th>
                <th className="p-3">Docs</th>
                <th className="p-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {workers.map((w) => (
                <tr key={w.id} className="border-t border-brand-line align-top">
                  <td className="p-3">
                    <div className="font-semibold">
                      {w.first_name} {w.last_name}
                    </div>
                    {w.email && <div className="text-xs text-brand-mute">{w.email}</div>}
                    {w.city && (
                      <div className="text-xs text-brand-mute">
                        {w.city}, {w.state}
                      </div>
                    )}
                  </td>
                  <td className="p-3 text-xs">
                    <a href={`tel:${w.phone}`} className="underline-hover">
                      {w.phone}
                    </a>
                  </td>
                  <td className="p-3 text-xs">
                    <select
                      value={w.tier}
                      onChange={(e) =>
                        flipWorker(w.id, { canDrive: w.can_drive === 1, tier: e.target.value })
                      }
                      className="input py-1 text-xs"
                    >
                      <option value="apprentice">apprentice</option>
                      <option value="pro">pro</option>
                      <option value="shift_lead">shift_lead</option>
                      <option value="master">master</option>
                    </select>
                  </td>
                  <td className="p-3 text-xs">
                    <select
                      value={w.status}
                      onChange={(e) =>
                        flipWorker(w.id, { canDrive: w.can_drive === 1, status: e.target.value })
                      }
                      className="input py-1 text-xs"
                    >
                      <option value="applied">applied</option>
                      <option value="approved">approved</option>
                      <option value="active">active</option>
                      <option value="paused">paused</option>
                      <option value="suspended">suspended</option>
                      <option value="terminated">terminated</option>
                    </select>
                  </td>
                  <td className="p-3 text-xs">{w.jobs_completed}</td>
                  <td className="p-3 text-xs">
                    {w.rating_avg ? `★ ${w.rating_avg.toFixed(2)} (${w.rating_count})` : '—'}
                  </td>
                  <td className="p-3 text-xs">
                    <button
                      type="button"
                      onClick={() => flipWorker(w.id, { canDrive: w.can_drive !== 1 })}
                      className={`rounded-md border px-2 py-1 text-[11px] ${w.can_drive ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300' : 'border-brand-line text-brand-mute hover:text-brand-ink'}`}
                    >
                      {w.can_drive ? '✓ can drive' : 'no'}
                    </button>
                  </td>
                  <td className="p-3 text-xs">
                    {w.pending_docs > 0 ? (
                      <span className="rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-200 px-2 py-0.5 text-[10px]">
                        {w.pending_docs} pending
                      </span>
                    ) : (
                      <span className="text-brand-mute">—</span>
                    )}
                  </td>
                  <td className="p-3 text-xs font-mono text-brand-mute">{w.id.slice(0, 8)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}

// ─────────────────────────── Docs (existing) ─────────────────────────────────
function DocReviewPanel({ token, onUnauthorized }: { token: string; onUnauthorized: () => void }) {
  const [docs, setDocs] = useState<WorkerDocRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showHistory, setShowHistory] = useState(false);

  useEffect(() => {
    void load();
  }, [token, showHistory]);

  async function load() {
    setLoading(true);
    setError('');
    try {
      const status = showHistory
        ? 'uploaded,auto_review,verified,rejected,expired'
        : 'uploaded,auto_review';
      const res = await fetch(`/admin/worker-docs?status=${status}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.status === 401) {
        onUnauthorized();
        return;
      }
      const data = (await res.json()) as { ok: boolean; documents: WorkerDocRow[] };
      setDocs(data.documents ?? []);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load.');
    } finally {
      setLoading(false);
    }
  }

  async function review(id: string, action: 'verify' | 'reject', reason?: string) {
    const res = await fetch(`/admin/worker-docs/${id}/review`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, reason }),
    });
    const data = (await res.json().catch(() => ({}))) as { driveBundleReady?: boolean };
    if (res.ok && data.driveBundleReady) {
      alert(
        'Worker has all 3 driving docs verified. Go to Workers tab → flip "can drive" if ready.',
      );
    }
    void load();
  }

  return (
    <>
      <div className="mb-6 flex flex-wrap items-center gap-3">
        <label className="flex items-center gap-2 text-sm text-brand-mute">
          <input
            type="checkbox"
            checked={showHistory}
            onChange={(e) => setShowHistory(e.target.checked)}
          />
          Show resolved
        </label>
        <button type="button" onClick={() => void load()} className="btn-ghost py-2 text-sm">
          Refresh
        </button>
      </div>

      {loading && (
        <p className="text-brand-mute">
          <span className="spinner mr-2" /> Loading…
        </p>
      )}
      {error && <p className="text-red-400">{error}</p>}
      {!loading && docs.length === 0 && (
        <p className="text-brand-mute">No documents waiting for review. Nice.</p>
      )}

      {docs.length > 0 && (
        <ul className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {docs.map((d) => (
            <DocCard key={d.id} doc={d} token={token} onReview={review} />
          ))}
        </ul>
      )}
    </>
  );
}

function DocCard({
  doc,
  token,
  onReview,
}: {
  doc: WorkerDocRow;
  token: string;
  onReview: (id: string, action: 'verify' | 'reject', reason?: string) => void;
}) {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  useEffect(() => {
    let revoke: string | null = null;
    let cancelled = false;
    (async () => {
      const res = await fetch(`/admin/worker-docs/${doc.id}/file`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok || cancelled) return;
      const blob = await res.blob();
      revoke = URL.createObjectURL(blob);
      if (!cancelled) setPreviewUrl(revoke);
    })();
    return () => {
      cancelled = true;
      if (revoke) URL.revokeObjectURL(revoke);
    };
  }, [doc.id, token]);

  const isImage = doc.mime.startsWith('image/');
  const isPending = doc.status === 'uploaded' || doc.status === 'auto_review';

  return (
    <li className="rounded-xl border border-brand-line bg-bg-elevated p-4">
      <header className="flex items-start justify-between gap-3 mb-3">
        <div>
          <h3 className="font-extrabold text-brand-ink">{labelKind(doc.kind)}</h3>
          <p className="text-xs text-brand-mute">
            {doc.first_name} {doc.last_name} ·{' '}
            <a href={`tel:${doc.phone}`} className="underline-hover">
              {doc.phone}
            </a>
          </p>
        </div>
        <span
          className={`rounded-full px-2 py-0.5 text-[10px] uppercase tracking-wider ${toneFor(doc.status)}`}
        >
          {doc.status}
        </span>
      </header>

      <div className="rounded-lg border border-brand-line bg-bg-primary p-2 mb-3 min-h-[180px] flex items-center justify-center">
        {!previewUrl && <span className="text-xs text-brand-mute">Loading preview…</span>}
        {previewUrl && isImage && (
          <img src={previewUrl} alt={labelKind(doc.kind)} className="max-h-72 rounded-md" />
        )}
        {previewUrl && !isImage && (
          <a
            href={previewUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-brand-accent underline-hover text-sm"
          >
            Open PDF →
          </a>
        )}
      </div>

      {(doc.license_number || doc.license_state || doc.license_expiry) && (
        <dl className="text-xs text-brand-mute mb-3 grid grid-cols-3 gap-2">
          {doc.license_number && (
            <div>
              <dt>License #</dt>
              <dd className="text-brand-ink font-mono">{doc.license_number}</dd>
            </div>
          )}
          {doc.license_state && (
            <div>
              <dt>State</dt>
              <dd className="text-brand-ink font-mono">{doc.license_state}</dd>
            </div>
          )}
          {doc.license_expiry && (
            <div>
              <dt>Expires</dt>
              <dd className="text-brand-ink font-mono">{doc.license_expiry}</dd>
            </div>
          )}
        </dl>
      )}

      {doc.expires_at && (
        <p className="text-xs text-brand-mute mb-3">
          Expires: <span className="text-brand-ink font-mono">{doc.expires_at.slice(0, 10)}</span>
        </p>
      )}

      {isPending && (
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => onReview(doc.id, 'verify')}
            className="rounded-md border border-emerald-500/40 bg-emerald-500/10 px-3 py-1.5 text-xs text-emerald-300 hover:bg-emerald-500 hover:text-bg-primary transition-colors"
          >
            ✓ Verify
          </button>
          <button
            type="button"
            onClick={() => {
              const reason = window.prompt('Rejection reason? (shown to worker)', 'blurry');
              if (reason) onReview(doc.id, 'reject', reason);
            }}
            className="rounded-md border border-red-500/40 bg-red-500/10 px-3 py-1.5 text-xs text-red-300 hover:bg-red-500 hover:text-bg-primary transition-colors"
          >
            ✕ Reject
          </button>
        </div>
      )}
    </li>
  );
}

// ─────────────────────────── Payouts (existing) ──────────────────────────────
interface HoldingPayout {
  id: string;
  worker_id: string;
  worker_name: string;
  worker_phone: string;
  amount_cents: number;
  method: string;
  status: string;
  instant_payout_method: string | null;
  instant_payout_handle: string | null;
  gig_claim_ids: string | null;
  created_at: string;
}

function PayoutsPanel({ token, onUnauthorized }: { token: string; onUnauthorized: () => void }) {
  const [rows, setRows] = useState<HoldingPayout[]>([]);
  const [loading, setLoading] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/admin/payouts/holding', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.status === 401) {
        onUnauthorized();
        return;
      }
      const data = (await res.json()) as { ok: boolean; payouts: HoldingPayout[] };
      setRows(data.payouts ?? []);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load.');
    } finally {
      setLoading(false);
    }
  }, [token, onUnauthorized]);

  useEffect(() => {
    void load();
  }, [load]);

  async function markPaid(id: string) {
    if (!confirm('Confirm payment was sent (Cash App / Venmo / Zelle)?')) return;
    setBusyId(id);
    setError('');
    try {
      const res = await fetch(`/admin/payouts/${id}/paid`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: '{}',
      });
      if (res.status === 401) {
        onUnauthorized();
        return;
      }
      if (!res.ok) {
        const data = (await res.json().catch(() => ({}))) as { error?: unknown };
        setError(
          typeof data.error === 'string' && data.error ? data.error : `Failed (${res.status})`,
        );
        return;
      }
      void load();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed.');
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="space-y-4">
      <header className="flex flex-wrap items-baseline justify-between gap-3">
        <div>
          <h2 className="text-xl font-extrabold text-brand-ink">Instant payouts — holding</h2>
          <p className="text-sm text-brand-mute">
            Workers requested cash-out off-cycle. Send via{' '}
            <a
              href="https://cash.app/login"
              target="_blank"
              rel="noopener"
              className="underline-hover"
            >
              Cash App
            </a>
            ,{' '}
            <a
              href="https://venmo.com/account/sign-in"
              target="_blank"
              rel="noopener"
              className="underline-hover"
            >
              Venmo
            </a>
            , or{' '}
            <a
              href="https://www.zellepay.com/"
              target="_blank"
              rel="noopener"
              className="underline-hover"
            >
              Zelle
            </a>
            , then click <strong>Mark paid</strong>.
          </p>
        </div>
        <button
          type="button"
          onClick={() => void load()}
          className="text-sm text-brand-mute underline-hover"
        >
          {loading ? 'Loading…' : 'Refresh'}
        </button>
      </header>
      {error && (
        <p role="alert" className="text-sm text-red-400">
          {error}
        </p>
      )}
      {rows.length === 0 && !loading ? (
        <p className="text-sm text-brand-mute">Nothing in holding — all caught up.</p>
      ) : (
        <ul className="divide-y divide-brand-line rounded-2xl border border-brand-line overflow-hidden">
          {rows.map((p) => {
            const claimCount = parseClaimCount(p.gig_claim_ids);
            return (
              <li key={p.id} id={`payout-${p.id}`} className="bg-brand-card px-4 py-3">
                <div className="flex flex-wrap items-baseline justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-sm font-extrabold text-brand-ink">
                      {p.worker_name}{' '}
                      <a
                        href={`tel:${p.worker_phone}`}
                        className="text-brand-mute font-normal underline-hover"
                      >
                        {p.worker_phone}
                      </a>
                    </p>
                    <p className="text-xs text-brand-mute">
                      {claimCount} job{claimCount === 1 ? '' : 's'} · requested{' '}
                      {formatRel(p.created_at)}
                    </p>
                    <p className="text-sm mt-1">
                      Send via{' '}
                      <span className="font-extrabold text-brand-ink">
                        {labelMethod(p.instant_payout_method)}
                      </span>
                      {p.instant_payout_handle && (
                        <>
                          {' to '}
                          <code className="rounded bg-brand-bg px-1.5 py-0.5 text-brand-accent font-mono text-xs">
                            {p.instant_payout_handle}
                          </code>{' '}
                          <CopyButton text={p.instant_payout_handle} />
                        </>
                      )}
                    </p>
                  </div>
                  <div className="flex flex-col items-end gap-2 shrink-0">
                    <p className="text-2xl font-extrabold text-emerald-300">
                      ${(p.amount_cents / 100).toFixed(2)}
                    </p>
                    <button
                      type="button"
                      disabled={busyId === p.id}
                      onClick={() => void markPaid(p.id)}
                      className="btn-primary py-1.5 text-xs disabled:opacity-50"
                    >
                      {busyId === p.id ? 'Marking…' : 'Mark paid'}
                    </button>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

// ─────────────────────────── Audit ───────────────────────────────────────────
function AuditPanel({ token, onUnauthorized }: { token: string; onUnauthorized: () => void }) {
  const [events, setEvents] = useState<
    Array<{
      id: string;
      created_at: string;
      entity_type: string;
      entity_id: string;
      action: string;
      detail: string | null;
    }>
  >([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [entity, setEntity] = useState('');
  const [action, setAction] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const params = new URLSearchParams();
      if (entity) params.set('entity', entity);
      if (action) params.set('action', action);
      params.set('limit', '200');
      const res = await fetch(`/admin/audit-feed?${params}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.status === 401) {
        onUnauthorized();
        return;
      }
      const data = (await res.json()) as { ok: boolean; events: typeof events };
      setEvents(data.events ?? []);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed.');
    } finally {
      setLoading(false);
    }
  }, [token, onUnauthorized, entity, action]);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <>
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <select
          value={entity}
          onChange={(e) => setEntity(e.target.value)}
          className="input py-2 text-sm"
          aria-label="Filter by entity"
        >
          <option value="">All entities</option>
          <option value="booking">Bookings</option>
          <option value="worker">Workers</option>
          <option value="gig">Gigs</option>
          <option value="payout">Payouts</option>
          <option value="concierge">Concierge</option>
          <option value="document">Documents</option>
        </select>
        <input
          type="text"
          value={action}
          onChange={(e) => setAction(e.target.value)}
          placeholder="Filter by action (substring)…"
          className="input py-2 text-sm flex-1 min-w-[200px]"
          aria-label="Filter by action"
        />
        <button type="button" onClick={() => void load()} className="btn-ghost py-2 text-sm">
          Refresh
        </button>
      </div>

      {loading && (
        <p className="text-brand-mute">
          <span className="spinner mr-2" /> Loading…
        </p>
      )}
      {error && <p className="text-red-400">{error}</p>}
      {!loading && events.length === 0 && <p className="text-brand-mute">No matching events.</p>}

      {events.length > 0 && (
        <ul className="space-y-1 rounded-2xl border border-brand-line p-3 bg-bg-elevated">
          {events.map((ev) => (
            <li
              key={ev.id}
              className="flex flex-wrap items-baseline gap-2 text-xs font-mono border-b border-brand-line/40 last:border-0 py-1.5"
            >
              <span className="text-brand-mute shrink-0 w-28">{formatRel(ev.created_at)}</span>
              <span className="text-brand-accent shrink-0">{ev.action}</span>
              <span className="text-brand-mute">
                {ev.entity_type}/<span className="text-brand-ink">{ev.entity_id.slice(0, 12)}</span>
              </span>
              {ev.detail && (
                <span className="text-brand-mute truncate max-w-md ml-auto">{ev.detail}</span>
              )}
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

// ─────────────────────────── AI Insights ─────────────────────────────────────
interface InsightsResult {
  ok: boolean;
  window: string;
  stats: Record<string, number>;
  byService: Array<{ services_csv: string; n: number; cents: number }>;
  byCity: Array<{ city: string; n: number; cents: number }>;
  insights: string;
}

function InsightsPanel({ token, onUnauthorized }: { token: string; onUnauthorized: () => void }) {
  const [window, setWindow] = useState<'today' | 'week' | 'month'>('week');
  const [data, setData] = useState<InsightsResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const run = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/admin/ai/insights', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ window }),
      });
      if (res.status === 401) {
        onUnauthorized();
        return;
      }
      const d = (await res.json()) as InsightsResult;
      setData(d);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed.');
    } finally {
      setLoading(false);
    }
  }, [token, onUnauthorized, window]);

  useEffect(() => {
    void run();
  }, [run]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <label className="text-sm text-brand-mute">Window:</label>
        <div className="flex gap-1">
          {(['today', 'week', 'month'] as const).map((w) => (
            <button
              key={w}
              type="button"
              onClick={() => setWindow(w)}
              className={`rounded-md border px-3 py-1.5 text-xs font-mono ${
                window === w
                  ? 'border-brand-accent bg-brand-accent/10 text-brand-accent'
                  : 'border-brand-line text-brand-mute hover:text-brand-ink'
              }`}
            >
              {w}
            </button>
          ))}
        </div>
        <button type="button" onClick={() => void run()} className="btn-ghost py-1.5 text-sm">
          Regenerate
        </button>
      </div>

      {loading && (
        <p className="text-brand-mute">
          <span className="spinner mr-2" /> Asking the model…
        </p>
      )}
      {error && <p className="text-red-400">{error}</p>}

      {data && (
        <>
          <section className="rounded-2xl border border-brand-accent/40 bg-brand-accent/5 p-4">
            <h2 className="text-lg font-extrabold mb-2">Ops memo</h2>
            <pre className="whitespace-pre-wrap text-sm font-sans text-brand-ink">
              {data.insights || 'No insights generated.'}
            </pre>
          </section>

          <section className="grid lg:grid-cols-3 gap-3">
            <div className="rounded-xl border border-brand-line p-4">
              <p className="text-xs uppercase text-brand-mute">Bookings</p>
              <p className="text-2xl font-extrabold font-mono">{data.stats.bookings ?? 0}</p>
            </div>
            <div className="rounded-xl border border-brand-line p-4">
              <p className="text-xs uppercase text-brand-mute">Revenue</p>
              <p className="text-2xl font-extrabold font-mono text-brand-accent">
                ${((data.stats.revenue_cents ?? 0) / 100).toFixed(0)}
              </p>
            </div>
            <div className="rounded-xl border border-brand-line p-4">
              <p className="text-xs uppercase text-brand-mute">Avg ticket</p>
              <p className="text-2xl font-extrabold font-mono">
                ${((data.stats.avg_ticket_cents ?? 0) / 100).toFixed(0)}
              </p>
            </div>
          </section>

          <section className="grid lg:grid-cols-2 gap-4">
            <div className="rounded-2xl border border-brand-line p-4">
              <h3 className="text-sm font-extrabold mb-2">By service</h3>
              <ul className="space-y-1 text-sm">
                {data.byService.map((s, i) => (
                  <li key={i} className="flex items-start justify-between gap-2">
                    <span className="flex flex-wrap gap-1" aria-label="Services">
                      {(s.services_csv ? s.services_csv.split(',') : ['(none)']).map((svc, j) => (
                        <span
                          key={j}
                          className="inline-flex items-center rounded-full bg-brand-accent/10 px-2 py-0.5 text-xs font-medium text-brand-accent transition-all duration-[333ms] hover:-translate-y-0.5 hover:bg-brand-accent/20 hover:shadow-sm"
                        >
                          {svc.trim()}
                        </span>
                      ))}
                    </span>
                    <span className="font-mono text-brand-accent shrink-0 whitespace-nowrap">
                      ${(s.cents / 100).toFixed(0)} ({s.n})
                    </span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="rounded-2xl border border-brand-line p-4">
              <h3 className="text-sm font-extrabold mb-2">By city</h3>
              <ul className="space-y-1 text-sm">
                {data.byCity.map((s, i) => (
                  <li key={i} className="flex items-center justify-between">
                    <span className="text-brand-mute truncate">{s.city || '(unknown)'}</span>
                    <span className="font-mono text-brand-accent shrink-0">
                      ${(s.cents / 100).toFixed(0)} ({s.n})
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </section>
        </>
      )}
    </div>
  );
}

// ─────────────────────────── ⌘K Command palette ──────────────────────────────
interface QuickSearchResults {
  bookings: Array<{
    id: string;
    customer_name: string;
    customer_email: string;
    preferred_date: string;
    status: string;
    total_cents: number;
  }>;
  workers: Array<{
    id: string;
    first_name: string;
    last_name: string;
    phone: string;
    status: string;
    tier: string;
  }>;
  gigs: Array<{
    id: string;
    status: string;
    booking_id: string;
    start_at: string;
    service_zip: string;
  }>;
}

function CommandPalette({
  token,
  onClose,
  onJump,
}: {
  token: string;
  onClose: () => void;
  onJump: (t: Tab) => void;
}) {
  const [q, setQ] = useState('');
  const [results, setResults] = useState<QuickSearchResults | null>(null);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  useEffect(() => {
    if (q.trim().length < 2) {
      setResults(null);
      return;
    }
    const handle = window.setTimeout(async () => {
      setLoading(true);
      try {
        const res = await fetch(`/admin/quick-search?q=${encodeURIComponent(q.trim())}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = (await res.json()) as { ok: boolean; results: QuickSearchResults };
        setResults(data.results || null);
      } finally {
        setLoading(false);
      }
    }, 220);
    return () => window.clearTimeout(handle);
  }, [q, token]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-[10vh] px-4"
      role="dialog"
      aria-modal="true"
      aria-label="Command palette"
    >
      <button
        type="button"
        aria-label="Close"
        onClick={onClose}
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
      />
      <div className="relative w-full max-w-2xl rounded-2xl border border-brand-line bg-bg-primary shadow-2xl overflow-hidden">
        <input
          ref={inputRef}
          type="text"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search bookings, workers, gigs… or jump to a tab"
          className="w-full bg-transparent px-4 py-4 text-base outline-none placeholder:text-brand-mute"
        />
        <div className="max-h-[60vh] overflow-y-auto border-t border-brand-line">
          {q.trim().length < 2 ? (
            <div className="p-4 space-y-2">
              <p className="text-xs uppercase tracking-wider text-brand-mute">Jump to</p>
              <ul className="space-y-1">
                {TABS.map((t) => (
                  <li key={t.id}>
                    <button
                      type="button"
                      onClick={() => onJump(t.id)}
                      className="w-full rounded-md px-3 py-2 text-left hover:bg-brand-accent/10 text-sm flex items-center justify-between"
                    >
                      <span className="font-semibold">{t.label}</span>
                      <span className="text-xs text-brand-mute">{t.hint}</span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ) : loading ? (
            <p className="p-6 text-sm text-brand-mute">
              <span className="spinner mr-2" /> Searching…
            </p>
          ) : results ? (
            <div className="divide-y divide-brand-line">
              {results.bookings.length > 0 && (
                <section className="p-3">
                  <p className="text-[10px] uppercase tracking-wider text-brand-mute mb-1 px-2">
                    Bookings ({results.bookings.length})
                  </p>
                  <ul>
                    {results.bookings.map((b) => (
                      <li key={b.id}>
                        <button
                          type="button"
                          onClick={() => onJump('bookings')}
                          className="w-full rounded-md px-2 py-1.5 text-left text-sm hover:bg-brand-accent/10 flex items-center justify-between gap-2"
                        >
                          <span className="truncate">
                            <span className="font-mono text-xs text-brand-mute mr-2">
                              {b.id.slice(0, 8)}
                            </span>
                            <span className="font-semibold">{b.customer_name}</span>
                            <span className="text-brand-mute text-xs ml-2">
                              {b.preferred_date} · {b.status}
                            </span>
                          </span>
                          <span className="font-mono text-brand-accent text-xs shrink-0">
                            ${(b.total_cents / 100).toFixed(0)}
                          </span>
                        </button>
                      </li>
                    ))}
                  </ul>
                </section>
              )}
              {results.workers.length > 0 && (
                <section className="p-3">
                  <p className="text-[10px] uppercase tracking-wider text-brand-mute mb-1 px-2">
                    Workers ({results.workers.length})
                  </p>
                  <ul>
                    {results.workers.map((w) => (
                      <li key={w.id}>
                        <button
                          type="button"
                          onClick={() => onJump('workers')}
                          className="w-full rounded-md px-2 py-1.5 text-left text-sm hover:bg-brand-accent/10 flex items-center justify-between gap-2"
                        >
                          <span className="truncate">
                            <span className="font-semibold">
                              {w.first_name} {w.last_name}
                            </span>
                            <span className="text-brand-mute text-xs ml-2">
                              {w.phone} · {w.tier} · {w.status}
                            </span>
                          </span>
                        </button>
                      </li>
                    ))}
                  </ul>
                </section>
              )}
              {results.gigs.length > 0 && (
                <section className="p-3">
                  <p className="text-[10px] uppercase tracking-wider text-brand-mute mb-1 px-2">
                    Gigs ({results.gigs.length})
                  </p>
                  <ul>
                    {results.gigs.map((g) => (
                      <li key={g.id}>
                        <button
                          type="button"
                          className="w-full rounded-md px-2 py-1.5 text-left text-sm hover:bg-brand-accent/10"
                        >
                          <span className="font-mono text-xs text-brand-mute mr-2">
                            {g.id.slice(0, 8)}
                          </span>
                          <span className="font-semibold">{g.status}</span>
                          <span className="text-brand-mute text-xs ml-2">
                            booking {g.booking_id.slice(0, 8)} · zip {g.service_zip}
                          </span>
                        </button>
                      </li>
                    ))}
                  </ul>
                </section>
              )}
              {results.bookings.length === 0 &&
                results.workers.length === 0 &&
                results.gigs.length === 0 && (
                  <p className="p-6 text-sm text-brand-mute text-center">No matches.</p>
                )}
            </div>
          ) : null}
        </div>
        <footer className="border-t border-brand-line px-4 py-2 text-[11px] text-brand-mute font-mono">
          <span className="mr-3">↵ Open</span>
          <span className="mr-3">esc Close</span>
          <span>⌘K Toggle</span>
        </footer>
      </div>
    </div>
  );
}

// ─────────────────────────── helpers ─────────────────────────────────────────
function labelKind(k: string): string {
  return k
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (m) => m.toUpperCase())
    .replace(/\bCdl\b/, 'CDL')
    .replace(/\bW9\b/, 'W-9')
    .replace(/\bOsha10\b/, 'OSHA 10')
    .replace(/\bEpa Rrp\b/, 'EPA RRP');
}

function toneFor(status: string): string {
  if (status === 'verified')
    return 'border border-emerald-500/30 bg-emerald-500/10 text-emerald-300';
  if (status === 'rejected' || status === 'expired')
    return 'border border-red-500/30 bg-red-500/10 text-red-300';
  return 'border border-amber-500/30 bg-amber-500/10 text-amber-200';
}

// ── Payments + Submissions back-office ────────────────────────────────────────

interface PaymentRow {
  id: string;
  created_at: string;
  status: string;
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  preferred_date: string;
  preferred_time: string;
  services_csv: string;
  hours: number;
  total_cents: number;
  square_payment_id: string | null;
  square_order_id: string | null;
  square_paid_at: string | null;
  paid_at: string | null;
  refunded: boolean;
  refunded_at: string | null;
  refund_amount_cents: number | null;
}

interface SubmissionItem {
  id: string;
  kind: 'contact' | 'quote';
  created_at: string;
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
  preferred_reply: string | null;
  media_json: string | null;
  value_cents: number | null;
  responded_at: string | null;
}

/** Lightweight top-right toast — auto-dismisses; used by the refund flow. */
function useToast() {
  const [toast, setToast] = useState<{ msg: string; tone: 'ok' | 'err' } | null>(null);
  const show = useCallback((msg: string, tone: 'ok' | 'err' = 'ok') => {
    setToast({ msg, tone });
    window.setTimeout(() => setToast(null), 4200);
  }, []);
  const node = toast ? (
    <div
      role="status"
      aria-live="polite"
      className={`fixed right-4 top-4 z-50 max-w-sm rounded-xl border px-4 py-3 text-sm shadow-lg backdrop-blur ${
        toast.tone === 'ok'
          ? 'border-emerald-500/40 bg-emerald-500/15 text-emerald-200'
          : 'border-red-500/40 bg-red-500/15 text-red-200'
      }`}
    >
      {toast.msg}
    </div>
  ) : null;
  return { show, node };
}

function PaymentsPanel({ token, onUnauthorized }: { token: string; onUnauthorized: () => void }) {
  const [rows, setRows] = useState<PaymentRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [refunding, setRefunding] = useState<Set<string>>(new Set());
  const { show, node: toastNode } = useToast();

  const load = useCallback(
    async (t: string) => {
      setLoading(true);
      setError('');
      try {
        const res = await fetch('/api/admin/payments?limit=300', {
          headers: { Authorization: `Bearer ${t}` },
        });
        if (res.status === 401 || res.status === 404) {
          onUnauthorized();
          return;
        }
        const data = (await res.json()) as { ok: boolean; payments?: PaymentRow[] };
        setRows(data.payments ?? []);
      } catch (e) {
        setError(e instanceof Error ? e.message : 'Failed to load payments.');
      } finally {
        setLoading(false);
      }
    },
    [onUnauthorized],
  );

  useEffect(() => {
    void load(token);
  }, [token, load]);

  const filtered = useMemo(() => {
    if (!search.trim()) return rows;
    const q = search.trim().toLowerCase();
    return rows.filter(
      (r) =>
        r.customer_name.toLowerCase().includes(q) ||
        r.customer_email.toLowerCase().includes(q) ||
        (r.customer_phone || '').includes(q) ||
        r.id.toLowerCase().includes(q) ||
        (r.square_payment_id || '').toLowerCase().includes(q) ||
        r.services_csv.toLowerCase().includes(q),
    );
  }, [rows, search]);

  const totals = useMemo(() => {
    let gross = 0;
    let refunded = 0;
    for (const r of rows) {
      gross += r.total_cents || 0;
      if (r.refunded) refunded += r.refund_amount_cents ?? r.total_cents ?? 0;
    }
    return { gross, refunded, net: gross - refunded, count: rows.length };
  }, [rows]);

  async function refund(row: PaymentRow) {
    if (row.refunded || !row.square_payment_id) return;
    const ok = window.confirm(
      `Refund ${usd(row.total_cents)} to ${row.customer_name} (${row.customer_email})?\n\n` +
        `Square payment ${row.square_payment_id}. This issues a real refund against ` +
        `the Square account and cannot be undone from here.`,
    );
    if (!ok) return;

    // Optimistic: flag the row refunded immediately; roll back on failure.
    setRefunding((s) => new Set(s).add(row.id));
    setRows((prev) =>
      prev.map((r) =>
        r.id === row.id
          ? {
              ...r,
              refunded: true,
              refunded_at: new Date().toISOString(),
              refund_amount_cents: r.total_cents,
            }
          : r,
      ),
    );

    try {
      const res = await fetch(`/api/admin/payments/${encodeURIComponent(row.id)}/refund`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason: 'Admin-issued refund' }),
      });
      const data = (await res.json().catch(() => ({}))) as {
        ok?: boolean;
        amountCents?: number;
        status?: string;
        error?: string;
      };
      if (res.ok && data.ok) {
        show(
          `Refunded ${usd(data.amountCents ?? row.total_cents)} — Square ${data.status ?? 'PENDING'}.`,
          'ok',
        );
        void load(token);
      } else {
        // Roll back the optimistic flip.
        setRows((prev) =>
          prev.map((r) =>
            r.id === row.id
              ? { ...r, refunded: false, refunded_at: null, refund_amount_cents: null }
              : r,
          ),
        );
        show(`Refund failed: ${data.error || res.statusText}`, 'err');
      }
    } catch (e) {
      setRows((prev) =>
        prev.map((r) =>
          r.id === row.id
            ? { ...r, refunded: false, refunded_at: null, refund_amount_cents: null }
            : r,
        ),
      );
      show(`Refund error: ${e instanceof Error ? e.message : 'network'}`, 'err');
    } finally {
      setRefunding((s) => {
        const next = new Set(s);
        next.delete(row.id);
        return next;
      });
    }
  }

  return (
    <>
      {toastNode}

      <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatTile label="Bookings" value={String(totals.count)} />
        <StatTile label="Gross" value={usd0(totals.gross)} />
        <StatTile label="Refunded" value={usd0(totals.refunded)} tone="warn" />
        <StatTile label="Net" value={usd0(totals.net)} tone="accent" />
      </div>

      <div className="mb-4 flex flex-wrap items-center gap-3">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Filter by name, email, phone, payment id, service…"
          className="input py-2 text-sm flex-1 min-w-[240px]"
          aria-label="Search payments"
        />
        <button type="button" onClick={() => void load(token)} className="btn-ghost py-2 text-sm">
          <span className="inline-block min-w-[9ch] text-center">
            {loading ? 'Refreshing…' : 'Refresh'}
          </span>
        </button>
      </div>

      {loading && rows.length === 0 && (
        <p className="text-brand-mute">
          <span className="spinner mr-2" /> Loading payments…
        </p>
      )}
      {error && <p className="text-red-400">{error}</p>}
      {!loading && filtered.length === 0 && <p className="text-brand-mute">No payments match.</p>}

      {filtered.length > 0 && (
        <div className="overflow-x-auto rounded-xl border border-brand-line">
          <table className="w-full text-sm">
            <thead className="bg-bg-elevated text-left text-xs uppercase tracking-wider text-brand-mute">
              <tr>
                <th className="p-3">Customer</th>
                <th className="p-3">Service</th>
                <th className="p-3">Date</th>
                <th className="p-3">Amount</th>
                <th className="p-3">Status</th>
                <th className="p-3">Payment</th>
                <th className="p-3">Refund</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((r) => {
                const busy = refunding.has(r.id);
                const canRefund = !r.refunded && Boolean(r.square_payment_id);
                return (
                  <tr key={r.id} className="border-t border-brand-line align-top">
                    <td className="p-3">
                      <div className="font-semibold">{r.customer_name}</div>
                      <div className="text-xs text-brand-mute">
                        <a href={`mailto:${r.customer_email}`} className="underline-hover">
                          {r.customer_email}
                        </a>
                      </div>
                      {r.customer_phone && (
                        <div className="text-xs text-brand-mute">
                          <a href={`tel:${r.customer_phone}`} className="underline-hover">
                            {r.customer_phone}
                          </a>
                        </div>
                      )}
                    </td>
                    <td className="p-3 text-xs">
                      <div className="max-w-xs">{r.services_csv || '—'}</div>
                      <div className="text-brand-mute mt-1">
                        {r.hours}h · {r.id.slice(0, 8)}
                      </div>
                    </td>
                    <td className="p-3 font-mono text-xs">
                      <div>{r.preferred_date}</div>
                      <div className="text-brand-mute">{r.preferred_time}</div>
                    </td>
                    <td className="p-3 font-mono text-brand-accent">{usd(r.total_cents)}</td>
                    <td className="p-3">
                      <span
                        className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-semibold ${paymentTone(r.status)}`}
                      >
                        {r.status.replace(/_/g, ' ')}
                      </span>
                    </td>
                    <td className="p-3 text-xs">
                      {r.square_payment_id ? (
                        <span className="font-mono text-brand-mute" title={r.square_payment_id}>
                          {r.square_payment_id.slice(0, 12)}…
                        </span>
                      ) : (
                        <span className="text-brand-mute">no capture</span>
                      )}
                    </td>
                    <td className="p-3">
                      {r.refunded ? (
                        <span className="inline-flex items-center rounded-full border border-amber-500/30 bg-amber-500/10 px-2 py-0.5 text-xs font-semibold text-amber-200">
                          Refunded
                          {r.refund_amount_cents ? ` · ${usd(r.refund_amount_cents)}` : ''}
                        </span>
                      ) : (
                        <button
                          type="button"
                          disabled={!canRefund || busy}
                          onClick={() => void refund(r)}
                          title={
                            r.square_payment_id
                              ? 'Issue a Square refund'
                              : 'No captured Square payment to refund'
                          }
                          className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                            canRefund && !busy
                              ? 'border border-red-500/40 bg-red-500/10 text-red-200 hover:bg-red-500/20'
                              : 'cursor-not-allowed border border-brand-line bg-brand-line/20 text-brand-mute opacity-60'
                          }`}
                        >
                          <span className="inline-block min-w-[8ch] text-center">
                            {busy ? 'Refunding…' : 'Refund'}
                          </span>
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      <SubmissionsSection token={token} onUnauthorized={onUnauthorized} />
    </>
  );
}

function StatTile({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone?: 'accent' | 'warn';
}) {
  const valueCls =
    tone === 'accent' ? 'text-brand-accent' : tone === 'warn' ? 'text-amber-300' : 'text-brand-ink';
  return (
    <div className="rounded-xl border border-brand-line bg-brand-card/40 p-3">
      <div className="text-xs uppercase tracking-wider text-brand-mute">{label}</div>
      <div className={`mt-1 font-mono text-lg font-semibold ${valueCls}`}>{value}</div>
    </div>
  );
}

function paymentTone(status: string): string {
  if (status === 'paid' || status === 'paid_in_full' || status === 'completed')
    return 'border border-emerald-500/30 bg-emerald-500/10 text-emerald-300';
  if (status === 'canceled' || status === 'error')
    return 'border border-red-500/30 bg-red-500/10 text-red-300';
  return 'border border-amber-500/30 bg-amber-500/10 text-amber-200';
}

function SubmissionsSection({
  token,
  onUnauthorized,
}: {
  token: string;
  onUnauthorized: () => void;
}) {
  const [items, setItems] = useState<SubmissionItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [kind, setKind] = useState<'' | 'contact' | 'quote'>('');
  const [detail, setDetail] = useState<SubmissionItem | null>(null);
  const kindOpts = [
    { id: '', label: 'All' },
    { id: 'contact', label: 'Contact' },
    { id: 'quote', label: 'Quotes' },
  ] as const;
  const kindTab = useRovingTabs(kindOpts.length, (i) => setKind(kindOpts[i]?.id ?? ''));

  const load = useCallback(
    async (t: string, k: string) => {
      setLoading(true);
      setError('');
      try {
        const url = `/api/admin/submissions?limit=300${k ? `&kind=${k}` : ''}`;
        const res = await fetch(url, { headers: { Authorization: `Bearer ${t}` } });
        if (res.status === 401 || res.status === 404) {
          onUnauthorized();
          return;
        }
        const data = (await res.json()) as { ok: boolean; submissions?: SubmissionItem[] };
        setItems(data.submissions ?? []);
      } catch (e) {
        setError(e instanceof Error ? e.message : 'Failed to load submissions.');
      } finally {
        setLoading(false);
      }
    },
    [onUnauthorized],
  );

  useEffect(() => {
    void load(token, kind);
  }, [token, kind, load]);

  return (
    <section className="mt-10">
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <h2 className="text-lg font-semibold text-brand-ink">Form submissions</h2>
        <div
          className="flex gap-1 rounded-lg border border-brand-line p-0.5"
          role="tablist"
          aria-label="Submission type"
        >
          {kindOpts.map((opt, idx) => (
            <button
              key={opt.id || 'all'}
              type="button"
              {...kindTab(idx, kind === opt.id)}
              onClick={() => setKind(opt.id)}
              className={`rounded-md px-3 py-1 text-xs font-semibold transition ${
                kind === opt.id
                  ? 'bg-brand-accent text-black'
                  : 'text-brand-mute hover:text-brand-ink'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
        <span className="text-xs text-brand-mute">{items.length} total</span>
      </div>

      {loading && items.length === 0 && (
        <p className="text-brand-mute">
          <span className="spinner mr-2" /> Loading submissions…
        </p>
      )}
      {error && <p className="text-red-400">{error}</p>}
      {!loading && items.length === 0 && <p className="text-brand-mute">No submissions yet.</p>}

      {items.length > 0 && (
        <div className="overflow-x-auto rounded-xl border border-brand-line">
          <table className="w-full text-sm">
            <thead className="bg-bg-elevated text-left text-xs uppercase tracking-wider text-brand-mute">
              <tr>
                <th className="p-3">When</th>
                <th className="p-3">Type</th>
                <th className="p-3">From</th>
                <th className="p-3">Summary</th>
                <th className="p-3"></th>
              </tr>
            </thead>
            <tbody>
              {items.map((s) => (
                <tr key={`${s.kind}-${s.id}`} className="border-t border-brand-line align-top">
                  <td className="p-3 font-mono text-xs text-brand-mute">
                    {new Date(s.created_at).toLocaleString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      hour: 'numeric',
                      minute: '2-digit',
                    })}
                  </td>
                  <td className="p-3">
                    <span
                      className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-semibold ${
                        s.kind === 'quote'
                          ? 'border border-brand-accent/30 bg-brand-accent/10 text-brand-accent'
                          : 'border border-brand-line bg-brand-line/20 text-brand-mute'
                      }`}
                    >
                      {s.kind}
                    </span>
                  </td>
                  <td className="p-3">
                    {s.name && <div className="font-semibold">{s.name}</div>}
                    <div className="text-xs text-brand-mute">
                      <a href={`mailto:${s.email}`} className="underline-hover">
                        {s.email}
                      </a>
                    </div>
                    {s.phone && <div className="text-xs text-brand-mute">{s.phone}</div>}
                  </td>
                  <td className="p-3 text-xs">
                    <div className="max-w-md truncate">
                      {s.subject || s.message.slice(0, 80) || '—'}
                    </div>
                    {s.value_cents != null && (
                      <div className="mt-1 font-mono text-brand-accent">{usd(s.value_cents)}</div>
                    )}
                  </td>
                  <td className="p-3">
                    <button
                      type="button"
                      onClick={() => setDetail(s)}
                      className="btn-ghost py-1 px-2 text-xs"
                    >
                      View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {detail && <SubmissionDetail item={detail} onClose={() => setDetail(null)} />}
    </section>
  );
}

function SubmissionDetail({ item, onClose }: { item: SubmissionItem; onClose: () => void }) {
  const media = useMemo(() => {
    if (!item.media_json) return [] as Array<{ kind: string; filename: string; link: string }>;
    try {
      return JSON.parse(item.media_json) as Array<{ kind: string; filename: string; link: string }>;
    } catch {
      return [];
    }
  }, [item.media_json]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Submission detail"
      onClick={onClose}
    >
      <div
        className="max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-2xl border border-brand-line bg-brand-card p-6 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-start justify-between gap-4">
          <div>
            <div className="text-xs uppercase tracking-wider text-brand-accent">{item.kind}</div>
            <h3 className="mt-1 text-lg font-semibold text-brand-ink">
              {item.subject || 'Submission'}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="inline-flex min-h-[24px] min-w-[24px] items-center justify-center rounded text-brand-mute hover:text-brand-ink"
            aria-label="Close"
          >
            ✕
          </button>
        </div>

        <dl className="space-y-3 text-sm">
          {item.name && (
            <div>
              <dt className="text-xs uppercase tracking-wider text-brand-mute">Name</dt>
              <dd className="text-brand-ink">{item.name}</dd>
            </div>
          )}
          <div>
            <dt className="text-xs uppercase tracking-wider text-brand-mute">Email</dt>
            <dd>
              <a href={`mailto:${item.email}`} className="text-brand-accent underline-hover">
                {item.email}
              </a>
            </dd>
          </div>
          {item.phone && (
            <div>
              <dt className="text-xs uppercase tracking-wider text-brand-mute">Phone</dt>
              <dd>
                <a href={`tel:${item.phone}`} className="text-brand-accent underline-hover">
                  {item.phone}
                </a>
              </dd>
            </div>
          )}
          {item.preferred_reply && (
            <div>
              <dt className="text-xs uppercase tracking-wider text-brand-mute">Preferred reply</dt>
              <dd className="text-brand-ink">{item.preferred_reply}</dd>
            </div>
          )}
          {item.value_cents != null && (
            <div>
              <dt className="text-xs uppercase tracking-wider text-brand-mute">Estimated value</dt>
              <dd className="font-mono text-brand-accent">{usd(item.value_cents)}</dd>
            </div>
          )}
          <div>
            <dt className="text-xs uppercase tracking-wider text-brand-mute">
              {item.kind === 'quote' ? 'Breakdown' : 'Message'}
            </dt>
            <dd className="whitespace-pre-wrap break-words rounded-lg border border-brand-line bg-bg-elevated p-3 text-brand-ink">
              {item.message || '—'}
            </dd>
          </div>
          {media.length > 0 && (
            <div>
              <dt className="text-xs uppercase tracking-wider text-brand-mute">Attachments</dt>
              <dd className="mt-1 space-y-1">
                {media.map((m, i) => (
                  <a
                    key={i}
                    href={m.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block text-brand-accent underline-hover"
                  >
                    {m.kind}: {m.filename}
                  </a>
                ))}
              </dd>
            </div>
          )}
          <div>
            <dt className="text-xs uppercase tracking-wider text-brand-mute">Received</dt>
            <dd className="font-mono text-xs text-brand-mute">
              {new Date(item.created_at).toLocaleString()}
            </dd>
          </div>
        </dl>
      </div>
    </div>
  );
}

async function downloadCsv(token: string) {
  const res = await fetch('/admin/bookings.csv', { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) throw new Error('csv failed');
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download =
    res.headers.get('content-disposition')?.match(/filename="?([^";]+)"?/)?.[1] || 'bookings.csv';
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function setMeta(name: string, content: string) {
  let el = document.querySelector<HTMLMetaElement>(`meta[name="${name}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute('name', name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text);
          setCopied(true);
          setTimeout(() => setCopied(false), 1500);
        } catch {
          /* ignore */
        }
      }}
      className="text-xs text-brand-mute underline-hover"
    >
      {copied ? 'Copied!' : 'Copy'}
    </button>
  );
}

function parseClaimCount(raw: string | null): number {
  if (!raw) return 0;
  try {
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr.length : 0;
  } catch {
    return 0;
  }
}

function labelMethod(m: string | null): string {
  if (m === 'cashapp') return 'Cash App';
  if (m === 'venmo') return 'Venmo';
  if (m === 'zelle') return 'Zelle';
  return m || 'manual';
}

function formatRel(iso: string): string {
  const then = new Date(iso).getTime();
  if (!Number.isFinite(then)) return iso;
  const diffMin = Math.round((Date.now() - then) / 60000);
  if (diffMin < 1) return 'just now';
  if (diffMin < 60) return `${diffMin}m ago`;
  if (diffMin < 1440) return `${Math.round(diffMin / 60)}h ago`;
  return `${Math.round(diffMin / 1440)}d ago`;
}

// ─────────────────── SMS · Quarterly nudge panel ────────────────────────────
// Send-script UI for the seasonal marketing batch. Three steps:
//   1. Pick a template (spring/summer/fall/winter) OR write a custom body.
//   2. Run dry-run → returns recipient count + rendered body + sample.
//   3. Confirm + send → background loop streams via Twilio at 30/min.
// Recipients come from POST /api/admin/sms/quarterly-nudge which filters on
// bookings.marketing_sms_opt_in = 1 AND last_booked > 90 days ago.

interface QuarterlyTemplateRow {
  id: 'spring' | 'summer' | 'fall' | 'winter';
  label: string;
  body: string;
  bytes: number;
}

interface DryRunResponse {
  ok: true;
  dryRun: true;
  template: string;
  body: string;
  bytes: number;
  recipientCount: number;
  sampleRecipients: Array<{ phone: string; name: string | null; lastBooked: string }>;
}

interface SendResponse {
  ok: true;
  dryRun: false;
  template: string;
  body: string;
  bytes: number;
  dispatched: number;
}

interface ScheduledRow {
  id: string;
  kind: string;
  status: string;
  send_after: string;
  sent_at: string | null;
  skip_reason: string | null;
  to_phone: string;
  booking_id: string | null;
  gig_id: string | null;
}

function QuarterlySmsPanel({
  token,
  onUnauthorized,
}: {
  token: string;
  onUnauthorized: () => void;
}) {
  const [templates, setTemplates] = useState<QuarterlyTemplateRow[]>([]);
  const [picked, setPicked] = useState<'spring' | 'summer' | 'fall' | 'winter' | 'custom'>(
    'spring',
  );
  const [customBody, setCustomBody] = useState('');
  const [dryRun, setDryRun] = useState<DryRunResponse | null>(null);
  const [sendResult, setSendResult] = useState<SendResponse | null>(null);
  const [recent, setRecent] = useState<ScheduledRow[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const loadTemplates = useCallback(async () => {
    const res = await fetch('/api/admin/sms/templates', {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (res.status === 401) {
      onUnauthorized();
      return;
    }
    const data = (await res.json()) as { ok: boolean; templates: QuarterlyTemplateRow[] };
    if (data.ok) setTemplates(data.templates);
  }, [token, onUnauthorized]);

  const loadRecent = useCallback(async () => {
    const res = await fetch('/api/admin/sms/recent', {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (res.status === 401) {
      onUnauthorized();
      return;
    }
    const data = (await res.json()) as { ok: boolean; scheduled: ScheduledRow[] };
    if (data.ok) setRecent(data.scheduled);
  }, [token, onUnauthorized]);

  useEffect(() => {
    void loadTemplates();
    void loadRecent();
  }, [loadTemplates, loadRecent]);

  const runDryRun = async () => {
    setBusy(true);
    setError('');
    setSendResult(null);
    try {
      const res = await fetch('/api/admin/sms/quarterly-nudge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          template: picked,
          customBody: picked === 'custom' ? customBody : undefined,
          dryRun: true,
        }),
      });
      if (res.status === 401) {
        onUnauthorized();
        return;
      }
      const data = (await res.json()) as DryRunResponse | { ok: false; error: string };
      if (!data.ok) {
        setError(data.error || 'dry-run failed');
        setDryRun(null);
      } else {
        setDryRun(data);
      }
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const send = async () => {
    if (!dryRun) return;
    if (!confirm(`Send to ${dryRun.recipientCount} recipients? This cannot be undone.`)) return;
    setBusy(true);
    setError('');
    try {
      const res = await fetch('/api/admin/sms/quarterly-nudge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          template: picked,
          customBody: picked === 'custom' ? customBody : undefined,
          dryRun: false,
        }),
      });
      if (res.status === 401) {
        onUnauthorized();
        return;
      }
      const data = (await res.json()) as SendResponse | { ok: false; error: string };
      if (!data.ok) {
        setError(data.error || 'send failed');
      } else {
        setSendResult(data);
        setDryRun(null);
        void loadRecent();
      }
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="space-y-6">
      <header>
        <h2 className="text-lg font-semibold text-brand-ink">SMS · Quarterly nudge</h2>
        <p className="text-sm text-brand-mute mt-1">
          Marketing-only batch to past customers who opted in + haven&apos;t booked in 90+ days.
          Twilio sends at 30/min. STOP is honored automatically.
        </p>
      </header>

      <div className="grid gap-2 sm:grid-cols-5">
        {templates.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setPicked(t.id)}
            className={`rounded-lg border px-3 py-2 text-left transition-colors ${
              picked === t.id
                ? 'border-brand-accent bg-brand-accent/10 text-brand-ink'
                : 'border-brand-line text-brand-mute hover:border-brand-accent'
            }`}
          >
            <div className="text-sm font-semibold">{t.label}</div>
            <div className="text-[10px] font-mono mt-0.5">{t.bytes}B / 160</div>
          </button>
        ))}
        <button
          type="button"
          onClick={() => setPicked('custom')}
          className={`rounded-lg border px-3 py-2 text-left transition-colors ${
            picked === 'custom'
              ? 'border-brand-accent bg-brand-accent/10 text-brand-ink'
              : 'border-brand-line text-brand-mute hover:border-brand-accent'
          }`}
        >
          <div className="text-sm font-semibold">Custom</div>
          <div className="text-[10px] font-mono mt-0.5">free-form</div>
        </button>
      </div>

      {picked === 'custom' ? (
        <div>
          <label htmlFor="sms-custom" className="block text-xs font-semibold text-brand-mute">
            Custom body ({customBody.length} chars — STOP trailer auto-appended)
          </label>
          <textarea
            id="sms-custom"
            value={customBody}
            onChange={(e) => setCustomBody(e.target.value)}
            rows={3}
            maxLength={320}
            placeholder="Type your message. Keep it under ~140 chars to leave room for the STOP trailer + URL."
            className="mt-1 w-full rounded-lg border border-brand-line bg-brand-bg p-2 text-sm text-brand-ink"
          />
        </div>
      ) : (
        <pre className="rounded-lg border border-brand-line bg-brand-bg p-3 text-xs text-brand-mute whitespace-pre-wrap font-mono">
          {templates.find((t) => t.id === picked)?.body || ''}
        </pre>
      )}

      <div className="flex gap-2">
        <button onClick={runDryRun} disabled={busy} className="btn-secondary text-sm">
          {busy ? 'Loading…' : 'Dry-run preview'}
        </button>
        <button
          onClick={send}
          disabled={busy || !dryRun || dryRun.recipientCount === 0}
          className="btn-primary text-sm"
        >
          Send to {dryRun?.recipientCount ?? '?'} recipients
        </button>
      </div>

      {error && <p className="text-sm text-red-400">Error: {error}</p>}

      {dryRun && (
        <div className="rounded-lg border border-brand-line bg-brand-bg p-3">
          <div className="text-sm text-brand-ink font-semibold">
            Dry-run · {dryRun.recipientCount} recipients · {dryRun.bytes}B body
          </div>
          <pre className="mt-2 text-xs text-brand-mute whitespace-pre-wrap font-mono">
            {dryRun.body}
          </pre>
          {dryRun.sampleRecipients.length > 0 && (
            <details className="mt-2">
              <summary className="text-xs text-brand-mute cursor-pointer">
                Sample first {dryRun.sampleRecipients.length}
              </summary>
              <ul className="mt-1 text-xs font-mono text-brand-mute space-y-0.5">
                {dryRun.sampleRecipients.map((r) => (
                  <li key={r.phone}>
                    {r.phone} · {r.name || '(no name)'} · last booked {r.lastBooked}
                  </li>
                ))}
              </ul>
            </details>
          )}
        </div>
      )}

      {sendResult && (
        <div className="rounded-lg border border-emerald-500/40 bg-emerald-500/10 p-3 text-sm text-emerald-300">
          Dispatched {sendResult.dispatched} messages — they&apos;ll trickle out at 30/min. Refresh
          the recent-sends list below in a few minutes.
        </div>
      )}

      <section>
        <header className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-semibold text-brand-ink">Recent scheduled SMS</h3>
          <button onClick={() => void loadRecent()} className="text-xs text-brand-accent">
            Refresh
          </button>
        </header>
        {recent.length === 0 ? (
          <p className="text-xs text-brand-mute">No recent SMS activity.</p>
        ) : (
          <table className="w-full text-xs">
            <thead>
              <tr className="text-left text-brand-mute border-b border-brand-line">
                <th className="py-1.5 pr-2">Kind</th>
                <th className="py-1.5 pr-2">Status</th>
                <th className="py-1.5 pr-2">Phone</th>
                <th className="py-1.5 pr-2">When</th>
                <th className="py-1.5 pr-2">Skip reason</th>
              </tr>
            </thead>
            <tbody>
              {recent.map((r) => (
                <tr key={r.id} className="border-b border-brand-line/30">
                  <td className="py-1.5 pr-2 font-mono">{r.kind}</td>
                  <td className="py-1.5 pr-2">{r.status}</td>
                  <td className="py-1.5 pr-2 font-mono">{r.to_phone}</td>
                  <td className="py-1.5 pr-2">{r.sent_at || r.send_after}</td>
                  <td className="py-1.5 pr-2 text-brand-mute">{r.skip_reason || ''}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </section>
  );
}
