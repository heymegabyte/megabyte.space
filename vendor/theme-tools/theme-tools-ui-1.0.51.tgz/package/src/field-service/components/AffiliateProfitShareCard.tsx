import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useCallback, useEffect, useState } from 'react';

interface AffiliateLink {
  type: 'customer' | 'crew';
  code: string;
  landingUrl: string;
  shortLink: string;
}

interface EarningsRow {
  bookingId: string;
  shareCents: number;
  grossCents: number;
  status: string;
  createdAt: string;
}

interface AffiliateEarnings {
  accruedCents: number;
  approvedCents: number;
  paidCents: number;
  lifetimeCents: number;
  rows: EarningsRow[];
}

type LoadState =
  | { kind: 'loading' }
  | { kind: 'error'; message: string }
  | { kind: 'ready'; link: AffiliateLink; earnings: AffiliateEarnings };

const money = (cents: number): string =>
  new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(cents / 100);

export function AffiliateProfitShareCard({ enabled }: { enabled: boolean }): JSX.Element | null {
  useThemeToolsSurface('affiliate-profit-share-card');
  const [state, setState] = useState<LoadState>({ kind: 'loading' });
  const [copied, setCopied] = useState(false);

  const load = useCallback(async () => {
    if (!enabled) return;
    setState({ kind: 'loading' });
    try {
      const [linkRes, earningsRes] = await Promise.all([
        fetch('/api/affiliate/link', { credentials: 'same-origin' }),
        fetch('/api/affiliate/earnings', { credentials: 'same-origin' }),
      ]);
      if (linkRes.status === 401 || earningsRes.status === 401) {
        throw new Error('Sign in to view your profit-share link.');
      }
      if (!linkRes.ok || !earningsRes.ok)
        throw new Error('Profit share is temporarily unavailable.');
      const linkBody = (await linkRes.json()) as { link?: AffiliateLink };
      const earningsBody = (await earningsRes.json()) as { earnings?: AffiliateEarnings };
      if (!linkBody.link || !earningsBody.earnings)
        throw new Error('Profit-share data was incomplete.');
      setState({ kind: 'ready', link: linkBody.link, earnings: earningsBody.earnings });
    } catch (error) {
      const raw = error instanceof Error ? error.message : '';
      setState({
        kind: 'error',
        message: raw.startsWith('Sign in') ? raw : 'Profit share is temporarily unavailable.',
      });
    }
  }, [enabled]);

  useEffect(() => {
    void load();
  }, [load]);

  if (!enabled) return null;

  return (
    <section
      data-testid="affiliate-profit-share-card"
      aria-labelledby="affiliate-profit-share-title"
      className="rounded-2xl border border-brand-line bg-brand-card p-5 sm:p-6"
    >
      <p className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
        Profit share
      </p>
      <h2 id="affiliate-profit-share-title" className="mt-1 text-xl font-bold text-brand-ink">
        Earn 5% on paid jobs you refer
      </h2>
      <p className="mt-2 text-sm text-brand-mute">
        Share your booking link. Eligible earnings are recorded after the referred job is paid and
        remain subject to approval before payout.
      </p>

      {state.kind === 'loading' && (
        <p data-testid="affiliate-loading" role="status" className="mt-5 text-sm text-brand-mute">
          Loading your link and earnings…
        </p>
      )}

      {state.kind === 'error' && (
        <div
          data-testid="affiliate-error"
          role="alert"
          className="mt-5 rounded-xl border border-red-400/40 bg-red-500/10 p-4 text-sm text-red-100"
        >
          <p>{state.message}</p>
          <button
            type="button"
            onClick={() => void load()}
            className="mt-2 min-h-11 underline font-semibold"
          >
            Try again
          </button>
        </div>
      )}

      {state.kind === 'ready' && (
        <div className="mt-5 space-y-5">
          <div className="grid gap-3 sm:grid-cols-4">
            {[
              ['Lifetime', state.earnings.lifetimeCents],
              ['Accrued', state.earnings.accruedCents],
              ['Approved', state.earnings.approvedCents],
              ['Paid', state.earnings.paidCents],
            ].map(([label, cents]) => (
              <div
                key={String(label)}
                className="rounded-xl border border-brand-line bg-brand-bg p-3"
              >
                <p className="text-xs text-brand-mute">{label}</p>
                <p className="mt-1 font-bold tabular-nums text-brand-ink">{money(Number(cents))}</p>
              </div>
            ))}
          </div>

          <div className="min-w-0 rounded-xl border border-brand-line bg-brand-bg p-4">
            <p className="text-xs text-brand-mute">Your referral code</p>
            <p
              data-testid="affiliate-code"
              className="mt-1 break-all font-mono font-bold text-brand-ink"
            >
              {state.link.code}
            </p>
            <a
              href={state.link.shortLink}
              className="mt-2 block break-all underline text-sm font-semibold text-brand-accent"
            >
              {state.link.shortLink}
            </a>
            <button
              type="button"
              data-testid="affiliate-copy"
              onClick={async () => {
                try {
                  await navigator.clipboard.writeText(state.link.shortLink);
                  setCopied(true);
                } catch {
                  setCopied(false);
                }
              }}
              className="mt-3 min-h-11 rounded-lg border border-brand-accent px-4 py-2 text-sm font-bold text-brand-accent"
            >
              {copied ? 'Link copied' : 'Copy link'}
            </button>
          </div>

          {state.earnings.rows.length === 0 ? (
            <p data-testid="affiliate-empty" className="text-sm text-brand-mute">
              No referred jobs have paid yet. Your link is ready to share.
            </p>
          ) : (
            <ul aria-label="Profit-share activity" className="space-y-2">
              {state.earnings.rows.map((row) => (
                <li
                  key={`${row.bookingId}-${row.createdAt}`}
                  className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-brand-line p-3 text-sm"
                >
                  <span className="text-brand-mute">
                    Job {row.bookingId.slice(0, 8)} · {row.status}
                  </span>
                  <strong className="text-brand-ink">{money(row.shareCents)}</strong>
                </li>
              ))}
            </ul>
          )}
          <button
            type="button"
            data-testid="affiliate-refresh"
            onClick={() => void load()}
            className="min-h-11 text-sm font-semibold text-brand-accent underline"
          >
            Refresh earnings
          </button>
        </div>
      )}
    </section>
  );
}
