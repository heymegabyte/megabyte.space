import { useThemeToolsSurface } from '../../field-service-primitives.js';
import {
  useCallback,
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
  type FormEvent,
  type JSX,
  type KeyboardEvent,
  type MouseEvent,
} from 'react';
import { findChatCommand, matchChatCommands, type AiChatCommandSpec } from '@theme.tools/agent-ui/field-service/ai-chat';
import { nextMenuIndex } from '@theme.tools/i18n-a11y/field-service/menu-keynav';
import { useBodyScrollLock, useFocusManagement, useTabTrap } from '../use-dialog-a11y.js';
import { useCmdKState } from '../cmd-k-rotator.js';
import { COMMAND_LISTBOX_ID, CommandMenu, commandOptionId } from './ai-chat/command-menu.js';
import { renderMarkdown, safeHref } from './ai-chat/markdown.js';
import type { StoredMessage } from '@theme.tools/agent-ui/field-service/storage';
import { dispatchAiChatWidgetAction, useAiChat, type UseAiChat } from '@theme.tools/agent-ui/field-service/use-ai-chat';
import { WidgetView } from './ai-chat/widgets.js';

/**
 * Brick Labor AI Chat — floating button + side panel that hosts a
 * conversational concierge for the entire site. Owns Cmd/Ctrl+K activation,
 * Esc dismissal, focus management, slash-command palette, message rendering
 * (markdown + widget cards), and the composer.
 *
 * State lives in `useAiChat`; this file is a thin presentation layer over it.
 */

const HOTKEY_HINT = isMac() ? '⌘K' : 'Ctrl+K';

export function AiChat(): JSX.Element {
  useThemeToolsSurface('ai-chat');
  const chat = useAiChat();
  const rotator = useCmdKState();
  const titleId = useId();
  const panelRef = useRef<HTMLDivElement>(null);
  const lastFocusRef = useRef<HTMLElement | null>(null);

  // Wave 13D: Cmd+K hotkey lives on the rotator now. The chat panel opens
  // when the rotator enters the `chat` state and closes otherwise. The
  // launcher button toggles the rotator instead of the chat directly.
  useRotatorSync(rotator.state, chat);
  useFocusManagement(chat.open, panelRef, lastFocusRef, 'textarea, [autofocus]');
  useBodyScrollLock(chat.open);

  const onToggle = () => {
    if (rotator.state === 'chat') {
      rotator.close();
    } else {
      // Capture synchronously before the composer's open effect can move focus
      // into the dialog. The shared hook preserves this external trigger.
      lastFocusRef.current = document.activeElement as HTMLElement | null;
      rotator.open('chat');
    }
  };

  return (
    <>
      <AiChatButton open={chat.open} onToggle={onToggle} status={chat.status} />
      <AiChatPanel chat={chat} titleId={titleId} panelRef={panelRef as React.RefObject<HTMLDivElement>} onClose={rotator.close} />
    </>
  );
}

/** Mirror rotator state into the chat's local open flag. */
function useRotatorSync(state: 'closed' | 'palette' | 'chat', chat: UseAiChat): void {
  useEffect(() => {
    const shouldBeOpen = state === 'chat';
    if (chat.open !== shouldBeOpen) chat.setOpen(shouldBeOpen);
  }, [state, chat]);
}

// ─────────────────────────────────────────────────────────────────────────────
// Floating launcher button
// ─────────────────────────────────────────────────────────────────────────────

function AiChatButton({
  open,
  onToggle,
  status,
}: {
  open: boolean;
  onToggle: () => void;
  status: UseAiChat['status'];
}): JSX.Element {
  const busy = status === 'thinking' || status === 'streaming';
  const [showTooltip, setShowTooltip] = useState(false);
  const tooltipText = busy ? 'Brick Labor AI is working…' : `Ask AI · ${HOTKEY_HINT}`;
  return (
    <div
      role="complementary"
      aria-label="AI assistant"
      // The persistent launcher is a top-level complementary landmark so
      // screen-reader users can jump straight to it via the landmark rotor
      // (it mounts at the App root, sibling to <main> — never nested, never
      // duplicated). When the panel is open the launcher is visually hidden
      // (opacity-0 pointer-events-none); mirror that in the a11y tree so the
      // landmark + its button leave the accessibility tree instead of lingering
      // as an announced-but-invisible control, and `inert` drops it from the tab
      // order. Symmetric with the panel's `inert`-when-closed below. React 18
      // types don't yet ship `inert`, hence the suppression.
      // @ts-expect-error — React 18 types don't yet ship `inert` typing.
      inert={open ? '' : undefined}
      aria-hidden={open || undefined}
      className="fixed bottom-6 right-6 z-[100]"
    >
      <button
        type="button"
        aria-label={open ? 'Close AI assistant' : 'Open AI assistant'}
        aria-expanded={open}
        aria-keyshortcuts={isMac() ? 'Meta+K' : 'Control+K'}
        aria-describedby="ai-chat-launcher-tip"
        onClick={onToggle}
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
        onFocus={() => setShowTooltip(true)}
        onBlur={() => setShowTooltip(false)}
        className={`flex h-14 w-14 items-center justify-center rounded-full border border-brand-line bg-bg-elevated/95 text-brand-accent shadow-2xl backdrop-blur transition-all duration-200 hover:scale-105 hover:border-brand-accent hover:bg-brand-accent hover:text-bg-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent focus-visible:ring-offset-2 focus-visible:ring-offset-bg-primary ${
          open ? 'scale-95 opacity-0 pointer-events-none' : 'scale-100 opacity-100'
        }`}
      >
        {busy ? <ThinkingDots /> : <HammerIcon />}
        <span className="sr-only">AI assistant — press {HOTKEY_HINT}</span>
        <span
          aria-hidden
          className="pointer-events-none absolute -top-1 -right-1 hidden h-3 w-3 animate-pulse rounded-full border border-bg-primary bg-emerald-400 motion-reduce:animate-none sm:block"
        />
      </button>
      <span
        id="ai-chat-launcher-tip"
        role="tooltip"
        className={`pointer-events-none absolute right-16 top-1/2 hidden -translate-y-1/2 whitespace-nowrap rounded-md border border-brand-line bg-bg-primary px-2.5 py-1 text-[11px] font-medium uppercase tracking-wider text-brand-ink shadow-lg transition-opacity duration-150 sm:block ${
          showTooltip && !open ? 'opacity-100' : 'opacity-0'
        }`}
      >
        {tooltipText}
      </span>
    </div>
  );
}

/** Hammer mark — extracted from the Brick Labor logo, used as the AI launcher. */
function HammerIcon(): JSX.Element {
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-6 w-6"
      fill="none"
      stroke="currentColor"
      strokeWidth={2.1}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d="m15 12-8.5 8.5a2.12 2.12 0 1 1-3-3L12 9" />
      <path d="M17.64 15 22 10.64" />
      <path d="m20.91 11.7-1.25-1.25c-.6-.6-.93-1.4-.93-2.25v-.86L16.01 4.6a5.56 5.56 0 0 0-3.94-1.64H9l.92.82A6.18 6.18 0 0 1 12 8.4v1.56l2 2h2.47l2.26 1.91" />
    </svg>
  );
}

function ThinkingDots(): JSX.Element {
  return (
    <span className="flex items-center gap-1" aria-label="Thinking">
      <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-current [animation-delay:-0.3s]" />
      <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-current [animation-delay:-0.15s]" />
      <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-current" />
    </span>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Side panel
// ─────────────────────────────────────────────────────────────────────────────

function AiChatPanel({
  chat,
  titleId,
  panelRef,
  onClose,
}: {
  chat: UseAiChat;
  titleId: string;
  panelRef: React.RefObject<HTMLDivElement>;
  onClose: () => void;
}): JSX.Element {
  // Use the `inert` attribute when closed — it hides the contents from the
  // a11y tree AND makes every focusable descendant unfocusable, satisfying
  // axe-core's `aria-hidden-focus` rule WITHOUT removing the wrapper from
  // the DOM (preserves the slide-out transition). `inert` is Baseline 2024,
  // works in every modern browser, gracefully ignored elsewhere.

  // APG dialog focus trap: the panel is `fixed inset-0` over the page, but the
  // page behind the backdrop stays focusable — so Tab from the last control
  // would silently escape the dialog. Keep Tab/Shift+Tab cycling inside the
  // panel (and yank back focus that has already escaped). axe-core can't see
  // this interaction gap; the trap math is unit-pinned in `shared/focus-trap`.
  const onPanelKeyDown = useTabTrap(panelRef);

  return (
    <div
      // @ts-expect-error — React 18 types don't yet ship `inert` typing.
      inert={!chat.open ? '' : undefined}
      className={`fixed inset-0 z-[110] overflow-hidden transition-opacity duration-200 ${
        chat.open ? 'opacity-100' : 'hidden pointer-events-none opacity-0'
      }`}
    >
      <div
        onClick={onClose}
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        aria-hidden
      />
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        onKeyDown={onPanelKeyDown}
        className={`absolute right-0 top-0 flex h-full w-full flex-col border-l border-brand-line bg-bg-primary shadow-2xl transition-transform duration-300 motion-reduce:transition-none sm:w-[440px] ${
          chat.open ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <AiChatHeader chat={chat} titleId={titleId} onClose={onClose} />
        <div className="border-b border-brand-line/60 px-4 py-1.5 font-mono text-[10px] uppercase tracking-wider text-brand-mute">
          Press {HOTKEY_HINT} to close · Esc to dismiss
        </div>
        <AiChatMessages chat={chat} />
        <AiChatComposer chat={chat} />
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Header — branding, status, settings, close
// ─────────────────────────────────────────────────────────────────────────────

function AiChatHeader({
  chat,
  titleId,
  onClose,
}: {
  chat: UseAiChat;
  titleId: string;
  onClose: () => void;
}): JSX.Element {
  const [menuOpen, setMenuOpen] = useState(false);
  const pageHint = usePageHint();

  return (
    <header className="flex items-start justify-between gap-2 border-b border-brand-line bg-bg-elevated/80 px-4 py-3 backdrop-blur">
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2.5">
          <span className="grid h-9 w-9 shrink-0 place-items-center overflow-hidden rounded-lg border border-brand-accent/30 bg-brand-accent/10 shadow-[0_0_18px_-6px_var(--brand-accent,#f0a020)]">
            <img
              src="/brand/bcl-logo-256.png"
              alt=""
              width={36}
              height={36}
              className="h-full w-full object-contain p-0.5"
              loading="lazy"
              decoding="async"
            />
          </span>
          <h2
            id={titleId}
            className="min-w-0 truncate font-display text-sm font-bold tracking-wide text-brand-ink"
          >
            Brick Labor
            <span className="ml-1.5 align-middle text-[10px] font-semibold uppercase tracking-wider text-brand-accent">
              AI Assistant
            </span>
          </h2>
        </div>
        <p className="mt-1 truncate text-[11px] text-brand-mute">
          <StatusBadge status={chat.status} /> · {pageHint}
        </p>
      </div>
      <div className="flex items-center gap-1">
        <IconButton
          label="New conversation"
          onClick={() => {
            chat.newConversation();
            setMenuOpen(false);
          }}
        >
          <PlusIcon />
        </IconButton>
        <IconButton
          label="Clear messages"
          onClick={() => {
            chat.clearConversation();
            setMenuOpen(false);
          }}
        >
          <BroomIcon />
        </IconButton>
        <IconButton label="Settings" onClick={() => setMenuOpen((p) => !p)} pressed={menuOpen}>
          <CogIcon />
        </IconButton>
        <IconButton label="Close" onClick={onClose}>
          <CloseIcon />
        </IconButton>
      </div>
      {menuOpen ? <SettingsMenu chat={chat} onClose={() => setMenuOpen(false)} /> : null}
    </header>
  );
}

function StatusBadge({ status }: { status: UseAiChat['status'] }): JSX.Element {
  const map = {
    idle: { color: 'bg-emerald-400', label: 'Ready' },
    thinking: { color: 'bg-amber-400', label: 'Thinking' },
    streaming: { color: 'bg-amber-400', label: 'Replying' },
    error: { color: 'bg-red-400', label: 'Error' },
  } as const;
  const cfg = map[status];
  return (
    <span className="inline-flex items-center gap-1">
      <span className={`inline-block h-1.5 w-1.5 rounded-full ${cfg.color}`} />
      {cfg.label}
    </span>
  );
}

function SettingsMenu({ chat, onClose }: { chat: UseAiChat; onClose: () => void }): JSX.Element {
  const [search, setSearch] = useState('');
  useEffect(() => {
    const onKey = (e: globalThis.KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        onClose();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return chat.history;
    return chat.history.filter((h) => h.title.toLowerCase().includes(q));
  }, [chat.history, search]);
  return (
    <div className="absolute right-3 top-16 z-10 w-64 rounded-xl border border-brand-line bg-bg-elevated p-3 shadow-2xl">
      <div className="mb-2 text-[10px] font-mono uppercase tracking-wider text-brand-mute">
        Settings
      </div>
      <SettingRow
        label="Compact density"
        checked={chat.settings.densityCompact}
        onChange={(v) => chat.updateSettings({ densityCompact: v })}
      />
      <SettingRow
        label="Sound on new reply"
        checked={chat.settings.soundEnabled}
        onChange={(v) => chat.updateSettings({ soundEnabled: v })}
      />
      <div className="mt-3 border-t border-brand-line/60 pt-2 text-[10px] uppercase tracking-wider text-brand-mute">
        Recent
      </div>
      {chat.history.length > 0 ? (
        <input
          type="search"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search chats…"
          aria-label="Search chat history"
          className="mt-1 w-full rounded-md border border-brand-line bg-bg-primary px-2 py-1 text-xs text-brand-ink placeholder:text-brand-mute focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
        />
      ) : null}
      {filtered.length === 0 ? (
        <div className="mt-1 text-xs text-brand-mute">
          {chat.history.length === 0 ? 'No saved chats yet.' : 'No matches.'}
        </div>
      ) : (
        <ul className="mt-1 max-h-48 space-y-1 overflow-y-auto">
          {filtered.map((h) => (
            <li key={h.sessionId} className="flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => {
                  chat.loadConversation(h.sessionId);
                  onClose();
                }}
                className="flex-1 truncate text-left text-xs text-brand-ink/90 hover:text-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
              >
                {h.title}
              </button>
              <button
                type="button"
                onClick={() => chat.deleteConversation(h.sessionId)}
                aria-label={`Delete ${h.title}`}
                className="text-brand-mute hover:text-red-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
              >
                <TrashIcon />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function SettingRow({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (value: boolean) => void;
}): JSX.Element {
  return (
    <label className="flex cursor-pointer items-center justify-between py-1.5 text-xs text-brand-ink/90">
      <span>{label}</span>
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="h-4 w-4 cursor-pointer accent-brand-accent"
      />
    </label>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Messages list
// ─────────────────────────────────────────────────────────────────────────────

function AiChatMessages({ chat }: { chat: UseAiChat }): JSX.Element {
  const scrollRef = useRef<HTMLDivElement>(null);
  const compact = chat.settings.densityCompact;
  const messages = chat.conversation.messages;

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    el.scrollTo({ top: el.scrollHeight, behavior: reduce ? 'auto' : 'smooth' });
  }, [messages.length, chat.status]);

  return (
    <div
      ref={scrollRef}
      className={`flex-1 overflow-y-auto px-3 py-4 ${compact ? 'space-y-2' : 'space-y-4'}`}
    >
      {messages.length === 0 ? <EmptyState chat={chat} /> : null}
      {messages.map((m, idx) => (
        <MessageBubble
          key={m.id}
          message={m}
          isLast={idx === messages.length - 1}
          chat={chat}
          compact={compact}
        />
      ))}
      {chat.status === 'thinking' ? <TypingIndicator /> : null}
      {chat.status === 'error' && chat.error ? (
        <ErrorBlock message={chat.error} onRetry={chat.retry} />
      ) : null}
    </div>
  );
}

function EmptyState({ chat }: { chat: UseAiChat }): JSX.Element {
  const suggested = useMemo(() => matchChatCommands('', 6), []);
  return (
    <div className="flex flex-col items-center px-2 py-6 text-center">
      <div className="grid h-12 w-12 place-items-center rounded-2xl border border-brand-line bg-brand-accent/10 text-brand-accent">
        <HammerIcon />
      </div>
      <h3 className="mt-3 text-lg font-bold text-brand-ink">How can we help?</h3>
      <p className="mt-1 max-w-xs text-xs text-brand-mute">
        Ask about pricing, book a crew, or use a slash command. Try {HOTKEY_HINT} anywhere on the
        site to reopen.
      </p>
      <div className="mt-4 flex w-full max-w-xs flex-wrap justify-center gap-1.5">
        {suggested.map((cmd) => (
          <button
            key={cmd.name}
            type="button"
            onClick={() => chat.sendMessage(`/${cmd.name}`)}
            className="rounded-full border border-brand-line bg-bg-elevated/60 px-3 py-1 text-xs text-brand-ink/90 transition-colors hover:border-brand-accent hover:text-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
          >
            /{cmd.name}
          </button>
        ))}
      </div>
    </div>
  );
}

function MessageBubble({
  message,
  isLast,
  chat,
  compact,
}: {
  message: StoredMessage;
  isLast: boolean;
  chat: UseAiChat;
  compact: boolean;
}): JSX.Element {
  const isUser = message.role === 'user';
  const padding = compact ? 'px-3 py-2' : 'px-3.5 py-2.5';
  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`max-w-[88%] ${isUser ? 'order-2' : ''}`}>
        <div
          className={`rounded-2xl border ${padding} text-sm shadow-sm ${
            isUser
              ? 'border-brand-accent/40 bg-brand-accent/10 text-brand-ink'
              : 'border-brand-line bg-bg-elevated/70 text-brand-ink'
          }`}
        >
          {renderMarkdown(message.content)}
          {message.widgets?.length ? (
            <div className="-mx-1 mt-1.5 space-y-1.5">
              {message.widgets.map((w, idx) => (
                <WidgetView
                  key={w.id || idx}
                  widget={w}
                  onAction={(label) => void dispatchAiChatWidgetAction(label, chat)}
                />
              ))}
            </div>
          ) : null}
        </div>
        {!isUser ? <MessageActions message={message} isLast={isLast} chat={chat} /> : null}
        {isUser ? <UserMessageActions message={message} chat={chat} /> : null}
        {!isUser && message.chips?.length ? (
          <div className="mt-2 flex flex-wrap gap-1.5">
            {message.chips.map((chip, idx) => (
              <ChipButton
                key={idx}
                label={chip.label}
                onClick={() => handleChipClick(chip, chat)}
              />
            ))}
          </div>
        ) : null}
      </div>
    </div>
  );
}

function handleChipClick(chip: { label: string; action?: string }, chat: UseAiChat): void {
  if (chip.action && chip.action.startsWith('/')) {
    void chat.sendMessage(chip.action);
    return;
  }
  if (chip.action) {
    const safe = safeHref(chip.action);
    if (safe) {
      window.location.href = safe;
      return;
    }
  }
  void chat.sendMessage(chip.label);
}

function ChipButton({ label, onClick }: { label: string; onClick: () => void }): JSX.Element {
  return (
    <button
      type="button"
      onClick={onClick}
      className="rounded-full border border-brand-line bg-bg-elevated/60 px-2.5 py-1 text-[11px] text-brand-ink/90 transition-colors hover:border-brand-accent hover:text-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
    >
      {label}
    </button>
  );
}

function MessageActions({
  message,
  isLast,
  chat,
}: {
  message: StoredMessage;
  isLast: boolean;
  chat: UseAiChat;
}): JSX.Element {
  const [copied, setCopied] = useState(false);
  const copy = async (e: MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    await chat.copyMessage(message.id);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1200);
  };
  return (
    <div className="mt-1.5 flex items-center gap-1.5 px-1 text-[10px] text-brand-mute">
      <button
        type="button"
        onClick={copy}
        className="inline-flex min-h-6 items-center px-1 hover:text-brand-accent"
        aria-label="Copy reply"
      >
        {copied ? 'Copied' : 'Copy'}
      </button>
      {isLast ? (
        <button
          type="button"
          onClick={() => chat.retry()}
          className="inline-flex min-h-6 items-center px-1 hover:text-brand-accent"
          aria-label="Regenerate"
        >
          Retry
        </button>
      ) : null}
      <button
        type="button"
        onClick={() => chat.setFeedback(message.id, message.feedback === 'up' ? undefined : 'up')}
        className={`inline-flex min-h-6 min-w-6 items-center justify-center hover:text-brand-accent ${message.feedback === 'up' ? 'text-emerald-400' : ''}`}
        aria-label="Helpful"
        aria-pressed={message.feedback === 'up'}
      >
        👍
      </button>
      <button
        type="button"
        onClick={() =>
          chat.setFeedback(message.id, message.feedback === 'down' ? undefined : 'down')
        }
        className={`inline-flex min-h-6 min-w-6 items-center justify-center hover:text-brand-accent ${message.feedback === 'down' ? 'text-red-400' : ''}`}
        aria-label="Not helpful"
        aria-pressed={message.feedback === 'down'}
      >
        👎
      </button>
    </div>
  );
}

function UserMessageActions({
  message,
  chat,
}: {
  message: StoredMessage;
  chat: UseAiChat;
}): JSX.Element {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(message.content);
  const editRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (editing) {
      editRef.current?.focus();
      editRef.current?.setSelectionRange(draft.length, draft.length);
    }
  }, [editing, draft.length]);

  if (editing) {
    return (
      <form
        onSubmit={(e) => {
          e.preventDefault();
          const next = draft.trim();
          if (!next || next === message.content) {
            setEditing(false);
            return;
          }
          setEditing(false);
          void chat.editMessage(message.id, next);
        }}
        className="mt-1.5 flex flex-col gap-1.5 px-1"
      >
        <textarea
          ref={editRef}
          id="ai-chat-edit-message"
          name="ai-chat-edit-message"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Escape') {
              e.preventDefault();
              setDraft(message.content);
              setEditing(false);
            }
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              e.currentTarget.form?.requestSubmit();
            }
          }}
          rows={2}
          className="w-full resize-none rounded-lg border border-brand-line bg-bg-elevated px-2 py-1.5 text-xs text-brand-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
          aria-label="Edit message"
        />
        <div className="flex gap-2 text-[10px]">
          <button
            type="submit"
            className="rounded-md border border-brand-accent/40 bg-brand-accent/10 px-2 py-1 font-semibold uppercase tracking-wider text-brand-accent hover:bg-brand-accent hover:text-bg-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
          >
            Resend
          </button>
          <button
            type="button"
            onClick={() => {
              setDraft(message.content);
              setEditing(false);
            }}
            className="rounded-md border border-brand-line px-2 py-1 uppercase tracking-wider text-brand-mute hover:text-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
          >
            Cancel
          </button>
        </div>
      </form>
    );
  }

  return (
    <div className="mt-1.5 flex items-center justify-end gap-2 px-1 text-[10px] text-brand-mute">
      <button
        type="button"
        onClick={() => {
          setDraft(message.content);
          setEditing(true);
        }}
        className="hover:text-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
        aria-label="Edit and resend"
      >
        Edit
      </button>
      <button
        type="button"
        onClick={() => chat.deleteMessage(message.id)}
        className="hover:text-red-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
        aria-label="Delete message"
      >
        Delete
      </button>
    </div>
  );
}

function TypingIndicator(): JSX.Element {
  return (
    <div className="flex items-center gap-2 px-2 text-xs text-brand-mute">
      <span className="flex items-center gap-1">
        <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-brand-mute [animation-delay:-0.3s]" />
        <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-brand-mute [animation-delay:-0.15s]" />
        <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-brand-mute" />
      </span>
      <span>Brick Labor AI is thinking…</span>
    </div>
  );
}

function ErrorBlock({ message, onRetry }: { message: string; onRetry: () => void }): JSX.Element {
  return (
    <div className="rounded-xl border border-red-500/40 bg-red-500/5 px-3 py-2.5 text-xs text-red-300">
      <div className="font-semibold">Something went wrong</div>
      <div className="mt-1 text-red-300/80">{message}</div>
      <button
        type="button"
        onClick={onRetry}
        className="mt-2 rounded-md border border-red-500/40 px-2 py-1 text-[11px] uppercase tracking-wider text-red-200 hover:bg-red-500/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-400"
      >
        Try again
      </button>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Composer + command palette
// ─────────────────────────────────────────────────────────────────────────────

function AiChatComposer({ chat }: { chat: UseAiChat }): JSX.Element {
  const rotator = useCmdKState();
  const [draft, setDraft] = useState('');
  const [paletteIndex, setPaletteIndex] = useState(0);
  // APG combobox: Escape dismisses the popup without closing the panel. This flag
  // suppresses the slash palette after an Escape until the next edit re-opens it.
  const [paletteDismissed, setPaletteDismissed] = useState(false);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const voice = useVoiceInput((transcript) => {
    setDraft((prev) => (prev ? `${prev.trimEnd()} ${transcript}` : transcript));
    setPaletteDismissed(false);
    inputRef.current?.focus();
  });

  const slashOpen = draft.trimStart().startsWith('/') && !paletteDismissed;
  const paletteQuery = slashOpen ? draft.trim() : '';
  const matches = useMemo(
    () => (slashOpen ? matchChatCommands(paletteQuery, 8) : []),
    [paletteQuery, slashOpen],
  );

  useEffect(() => {
    if (chat.open && inputRef.current) inputRef.current.focus();
  }, [chat.open]);

  useEffect(() => {
    if (paletteIndex >= matches.length) setPaletteIndex(0);
  }, [matches.length, paletteIndex]);

  const submit = useCallback(
    async (raw: string) => {
      const value = raw.trim();
      if (!value) return;
      setDraft('');
      setPaletteIndex(0);

      const directCommand = findChatCommand(value);
      if (directCommand?.href) {
        const href = safeHref(directCommand.href);
        if (href) {
          rotator.close();
          window.location.href = href;
          return;
        }
      }
      if (directCommand?.prompt && !valueHasArgs(value)) {
        setDraft(`${directCommand.prompt} `);
        return;
      }

      await chat.sendMessage(value);
    },
    [chat, rotator],
  );

  const selectCommand = useCallback(
    (cmd: AiChatCommandSpec) => {
      if (cmd.href) {
        const href = safeHref(cmd.href);
        if (href) {
          rotator.close();
          window.location.href = href;
          return;
        }
      }
      if (cmd.prompt) {
        setDraft(`${cmd.prompt} `);
        inputRef.current?.focus();
        return;
      }
      void submit(`/${cmd.name}`);
    },
    [rotator, submit],
  );

  const onKey = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (slashOpen && matches.length > 0) {
      // APG combobox: Escape dismisses the popup FIRST (keeping the textarea
      // focused + the draft intact). stopPropagation is essential — without it the
      // global cmd-k-rotator onEsc listener fires and closes the whole chat panel,
      // discarding the in-progress message. A second Escape (popup now hidden)
      // falls through to that listener and closes the panel, as expected.
      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        setPaletteDismissed(true);
        return;
      }
      // Single-source the roving nav (ArrowUp/Down + Home/End, wrapping) via the
      // shared nextMenuIndex helper — same math as the role="menu" dropdowns, so
      // the palette can't drift. Returns null for Tab/Enter (handled below).
      const navIdx = nextMenuIndex(paletteIndex, matches.length, e.key);
      if (navIdx !== null) {
        e.preventDefault();
        setPaletteIndex(navIdx);
        return;
      }
      if (e.key === 'Tab') {
        e.preventDefault();
        const cmd = matches[paletteIndex];
        if (cmd) setDraft(`/${cmd.name} `);
        return;
      }
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        const cmd = matches[paletteIndex];
        if (cmd) {
          selectCommand(cmd);
          return;
        }
      }
    }
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      void submit(draft);
    }
  };

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    void submit(draft);
  };

  const busy = chat.status === 'thinking' || chat.status === 'streaming';

  return (
    <form
      onSubmit={onSubmit}
      className="relative border-t border-brand-line bg-bg-elevated/80 px-3 py-3 backdrop-blur"
    >
      {slashOpen ? (
        <CommandMenu
          query={paletteQuery}
          activeIndex={paletteIndex}
          onActiveIndexChange={setPaletteIndex}
          onSelect={selectCommand}
        />
      ) : null}
      <div className="flex items-end gap-2 rounded-xl border border-brand-line bg-bg-primary px-3 py-2 focus-within:border-brand-accent">
        <textarea
          ref={inputRef}
          id="ai-chat-message"
          name="ai-chat-message"
          value={draft}
          onChange={(e) => {
            setDraft(e.target.value);
            setPaletteDismissed(false);
          }}
          onKeyDown={onKey}
          placeholder={
            voice.listening ? 'Listening… speak now' : 'Ask anything — or type / for commands'
          }
          rows={1}
          maxLength={2000}
          className="min-h-6 max-h-32 flex-1 resize-none border-0 bg-transparent text-sm text-brand-ink placeholder:text-brand-mute focus:outline-none"
          aria-label="Message"
          role="combobox"
          aria-haspopup="listbox"
          aria-autocomplete="list"
          aria-expanded={slashOpen && matches.length > 0}
          aria-controls={slashOpen && matches.length > 0 ? COMMAND_LISTBOX_ID : undefined}
          aria-activedescendant={
            slashOpen && matches.length > 0 ? commandOptionId(paletteIndex) : undefined
          }
        />
        {voice.supported ? (
          <button
            type="button"
            onClick={voice.toggle}
            aria-label={voice.listening ? 'Stop voice input' : 'Start voice input'}
            aria-pressed={voice.listening}
            className={`grid h-9 w-9 place-items-center rounded-lg border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent ${
              voice.listening
                ? 'border-red-400 text-red-400 animate-pulse motion-reduce:animate-none'
                : 'border-brand-line text-brand-ink/80 hover:border-brand-accent hover:text-brand-accent'
            }`}
          >
            <MicIcon />
          </button>
        ) : null}
        {busy ? (
          <button
            type="button"
            onClick={chat.stop}
            aria-label="Stop"
            className="grid h-9 w-9 place-items-center rounded-lg border border-brand-line text-brand-ink/80 hover:border-red-400 hover:text-red-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
          >
            <StopIcon />
          </button>
        ) : (
          <button
            type="submit"
            disabled={!draft.trim()}
            aria-label="Send"
            className="grid h-9 w-9 place-items-center rounded-lg bg-brand-accent text-bg-primary transition-opacity disabled:opacity-40 disabled:cursor-not-allowed enabled:hover:bg-brand-accent/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent focus-visible:ring-offset-2 focus-visible:ring-offset-bg-primary"
          >
            <SendIcon />
          </button>
        )}
      </div>
      <div className="mt-1.5 flex items-center justify-between px-1 text-[10px] text-brand-mute">
        <span>Enter to send · Shift+Enter for newline</span>
        <span>{draft.length}/2000</span>
      </div>
    </form>
  );
}

function valueHasArgs(value: string): boolean {
  const trimmed = value.trim();
  if (!trimmed.startsWith('/')) return true;
  return /\s/.test(trimmed);
}

// ─────────────────────────────────────────────────────────────────────────────
// Hooks — focus, body scroll lock, page hint
//
// Wave 13D removed the local Cmd+K and Esc listeners — the unified rotator
// in `lib/cmd-k-rotator.tsx` owns both keystrokes now. `<AiChat />` simply
// mirrors `rotator.state === 'chat'` into its open flag.
// ─────────────────────────────────────────────────────────────────────────────

interface VoiceInput {
  supported: boolean;
  listening: boolean;
  toggle: () => void;
}

function useVoiceInput(onTranscript: (text: string) => void): VoiceInput {
  const [supported, setSupported] = useState(false);
  const [listening, setListening] = useState(false);
  const recognitionRef = useRef<unknown>(null);
  const callbackRef = useRef(onTranscript);

  useEffect(() => {
    callbackRef.current = onTranscript;
  }, [onTranscript]);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const w = window as unknown as {
      SpeechRecognition?: new () => unknown;
      webkitSpeechRecognition?: new () => unknown;
    };
    const Ctor = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!Ctor) return;
    setSupported(true);
    return () => {
      const rec = recognitionRef.current as { stop?: () => void } | null;
      try {
        rec?.stop?.();
      } catch {
        // ignore
      }
      recognitionRef.current = null;
    };
  }, []);

  const toggle = useCallback(() => {
    if (typeof window === 'undefined') return;
    const w = window as unknown as {
      SpeechRecognition?: new () => unknown;
      webkitSpeechRecognition?: new () => unknown;
    };
    const Ctor = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!Ctor) return;
    const existing = recognitionRef.current as { stop?: () => void } | null;
    if (listening && existing) {
      try {
        existing.stop?.();
      } catch {
        // ignore
      }
      setListening(false);
      return;
    }
    const rec = new Ctor() as {
      continuous?: boolean;
      interimResults?: boolean;
      lang?: string;
      onresult?: (e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void;
      onerror?: () => void;
      onend?: () => void;
      start?: () => void;
      stop?: () => void;
    };
    rec.continuous = false;
    rec.interimResults = false;
    const pathLocale = window.location.pathname.startsWith('/es')
      ? 'es-US'
      : window.location.pathname.startsWith('/pt')
        ? 'pt-BR'
        : null;
    rec.lang = pathLocale || (typeof navigator !== 'undefined' && navigator.language) || 'en-US';
    rec.onresult = (event) => {
      const results = event.results;
      let transcript = '';
      for (let i = 0; i < results.length; i += 1) {
        const first = results[i]?.[0];
        if (first?.transcript) transcript += first.transcript;
      }
      const cleaned = transcript.trim();
      if (cleaned) callbackRef.current(cleaned);
    };
    rec.onerror = () => setListening(false);
    rec.onend = () => setListening(false);
    try {
      rec.start?.();
      recognitionRef.current = rec;
      setListening(true);
    } catch {
      setListening(false);
    }
  }, [listening]);

  return { supported, listening, toggle };
}

function usePageHint(): string {
  const [hint, setHint] = useState<string>(() =>
    describePath(typeof window === 'undefined' ? '/' : window.location.pathname),
  );
  useEffect(() => {
    const update = () => setHint(describePath(window.location.pathname));
    window.addEventListener('popstate', update);
    return () => window.removeEventListener('popstate', update);
  }, []);
  return hint;
}

function describePath(rawPath: string): string {
  const path = rawPath.replace(/^\/(es|pt)(?=\/|$)/, '') || '/';
  if (path === '/' || path === '') return 'Home';
  if (path.startsWith('/services/')) return `Service · ${path.split('/').filter(Boolean)[1] || ''}`;
  if (path === '/services') return 'All services';
  if (path === '/estimate') return 'Photo estimate';
  if (path.startsWith('/c/')) return `City · ${path.split('/').filter(Boolean)[1] || ''}`;
  if (path.startsWith('/blog/')) return 'Blog post';
  if (path === '/blog') return 'Blog';
  if (path.startsWith('/track/')) return 'Tracking a booking';
  if (path === '/me') return 'Account';
  if (path === '/admin') return 'Admin';
  if (path.startsWith('/work')) return 'Crew';
  return path;
}

// ─────────────────────────────────────────────────────────────────────────────
// Icons
// ─────────────────────────────────────────────────────────────────────────────

function IconButton({
  label,
  children,
  onClick,
  pressed,
}: {
  label: string;
  children: React.ReactNode;
  onClick: () => void;
  pressed?: boolean;
}): JSX.Element {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      aria-pressed={pressed}
      className={`grid h-8 w-8 place-items-center rounded-md text-brand-ink/80 transition-colors hover:bg-brand-line/40 hover:text-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent ${
        pressed ? 'bg-brand-line/40 text-brand-accent' : ''
      }`}
    >
      {children}
    </button>
  );
}

function PlusIcon(): JSX.Element {
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-4 w-4"
      fill="none"
      stroke="currentColor"
      strokeWidth={2.2}
      strokeLinecap="round"
      aria-hidden
    >
      <path d="M12 5v14M5 12h14" />
    </svg>
  );
}

function BroomIcon(): JSX.Element {
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-4 w-4"
      fill="none"
      stroke="currentColor"
      strokeWidth={2.2}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d="M14 4l6 6M3 21l4-4M9 11l4 4M11 9l8-8 4 4-8 8M9 11l-4 4 4 4 4-4" />
    </svg>
  );
}

function CogIcon(): JSX.Element {
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-4 w-4"
      fill="none"
      stroke="currentColor"
      strokeWidth={2.2}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
    </svg>
  );
}

function CloseIcon(): JSX.Element {
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-4 w-4"
      fill="none"
      stroke="currentColor"
      strokeWidth={2.2}
      strokeLinecap="round"
      aria-hidden
    >
      <path d="M18 6L6 18M6 6l12 12" />
    </svg>
  );
}

function TrashIcon(): JSX.Element {
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-3.5 w-3.5"
      fill="none"
      stroke="currentColor"
      strokeWidth={2.2}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
    </svg>
  );
}

function SendIcon(): JSX.Element {
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-4 w-4"
      fill="none"
      stroke="currentColor"
      strokeWidth={2.2}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" />
    </svg>
  );
}

function StopIcon(): JSX.Element {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor" aria-hidden>
      <rect x="6" y="6" width="12" height="12" rx="2" />
    </svg>
  );
}

function MicIcon(): JSX.Element {
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-4 w-4"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <rect x="9" y="3" width="6" height="12" rx="3" />
      <path d="M5 11a7 7 0 0 0 14 0" />
      <path d="M12 18v3" />
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Misc
// ─────────────────────────────────────────────────────────────────────────────

function isMac(): boolean {
  if (typeof navigator === 'undefined') return false;
  return /Mac|iPhone|iPad/.test(navigator.platform || '');
}
