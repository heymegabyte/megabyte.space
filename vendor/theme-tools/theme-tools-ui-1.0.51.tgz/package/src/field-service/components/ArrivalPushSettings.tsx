import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useCallback, useEffect, useState, type JSX } from 'react';
import { useFeatureFlag } from '../use-feature-flag.js';

/**
 * ArrivalPushSettings — toggle arrival-push notifications on/off and see
 * when the last notification was sent. Gated by `push_arrival_notifications`.
 *
 * Backend: GET/PATCH /api/arrival-push/preferences
 */
interface PrefsResponse {
  ok: boolean;
  enabled: boolean;
  lastNotifiedAt: string | null;
}

const TIME_FRESH_CUTOFF_MS = 60_000; // "just now" under 1 minute

/** Human-friendly relative time for the "last notification" label. */
function relativeTime(iso: string): string {
  const ms = Date.now() - new Date(iso).getTime();
  if (ms < TIME_FRESH_CUTOFF_MS) return 'just now';
  const days = Math.floor(ms / 86_400_000);
  if (days < 1) {
    const hours = Math.floor(ms / 3_600_000);
    if (hours < 1) {
      const minutes = Math.floor(ms / 60_000);
      return `${minutes} minute${minutes === 1 ? '' : 's'} ago`;
    }
    return `${hours} hour${hours === 1 ? '' : 's'} ago`;
  }
  if (days < 30) return `${days} day${days === 1 ? '' : 's'} ago`;
  const months = Math.floor(days / 30);
  return `${months} month${months === 1 ? '' : 's'} ago`;
}

export function ArrivalPushSettings(): JSX.Element | null {
  useThemeToolsSurface('arrival-push-settings');
  const enabled = useFeatureFlag('push_arrival_notifications');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [toggled, setToggled] = useState(false);
  const [lastNotifiedAt, setLastNotifiedAt] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const fetchPrefs = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/arrival-push/preferences', { credentials: 'same-origin' });
      if (!res.ok) throw new Error('Could not load preferences.');
      const j = (await res.json()) as PrefsResponse;
      setToggled(j.enabled);
      setLastNotifiedAt(j.lastNotifiedAt);
    } catch {
      setError('Could not load arrival-push preferences.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (enabled) void fetchPrefs();
  }, [enabled, fetchPrefs]);

  const handleToggle = useCallback(async () => {
    const next = !toggled;
    setToggled(next);
    setSaving(true);
    setError(null);
    try {
      const res = await fetch('/api/arrival-push/preferences', {
        method: 'PATCH',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled: next }),
      });
      if (!res.ok) throw new Error('Could not save preference.');
    } catch {
      setToggled(!next);
      setError('Could not save. Try again.');
    } finally {
      setSaving(false);
    }
  }, [toggled]);

  if (!enabled) return null;

  return (
    <section
      data-testid="arrival-push-settings"
      className="rounded-lg border border-brand-line bg-brand-card p-6"
      aria-labelledby="arrival-push-heading"
    >
      <h2 id="arrival-push-heading" className="text-lg font-semibold text-brand-ink mb-1">
        Arrival push notifications
      </h2>
      <p className="text-brand-mute text-sm mb-4">
        Get a push notification when your crew is about to arrive on site.
      </p>

      {loading ? (
        <div className="flex items-center justify-between gap-3 py-2" aria-busy="true">
          <span className="h-4 w-32 animate-pulse rounded bg-brand-line/40" />
          <span className="h-6 w-11 animate-pulse rounded-full bg-brand-line/40" />
        </div>
      ) : error ? null : (
        <>
          <label className="flex items-center justify-between gap-3 cursor-pointer">
            <span className="text-sm text-brand-ink">Enabled</span>
            <span className="relative inline-flex items-center">
              <input
                type="checkbox"
                className="sr-only peer"
                checked={toggled}
                disabled={saving}
                onChange={handleToggle}
                aria-label="Toggle arrival-push notifications"
              />
              <span
                aria-hidden="true"
                className="w-11 h-6 rounded-full peer-focus-visible:ring-2 peer-focus-visible:ring-brand-accent peer-focus-visible:ring-offset-2 peer-focus-visible:ring-offset-bg-primary bg-brand-line/60 peer-checked:bg-emerald-500/60 transition-colors after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:w-5 after:h-5 after:rounded-full after:bg-white after:transition-transform peer-checked:after:translate-x-5"
              />
            </span>
          </label>

          {lastNotifiedAt && (
            <p className="mt-3 text-xs text-brand-mute">
              Last notification:{' '}
              <time dateTime={lastNotifiedAt} className="text-brand-ink font-medium">
                {relativeTime(lastNotifiedAt)}
              </time>
            </p>
          )}
        </>
      )}

      {error && (
        <p className="mt-3 text-sm text-red-300" role="alert">
          {error}
        </p>
      )}
    </section>
  );
}
