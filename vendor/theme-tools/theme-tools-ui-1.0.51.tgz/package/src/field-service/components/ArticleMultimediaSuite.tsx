import { useState } from 'react';
import {
  ThemeToolsPageSurface,
  useThemeToolsSurface,
} from '../../field-service-primitives.js';

export interface ArticleMultimediaSuiteProps {
  readonly townName?: string;
  readonly state?: string;
  readonly isPowerWash?: boolean;
  readonly bookingUrl?: string;
  readonly hideFaq?: boolean;
}

interface SurfaceGuideItem {
  readonly id: string;
  readonly label: string;
  readonly neighborhoodLabel: string;
  readonly photoSrc: string;
  readonly photoAlt: string;
  readonly methodHeadline: string;
  readonly howWeClean: string;
  readonly whatWeAvoid: string;
  readonly typicalTimeAndCost: string;
}

interface WalkthroughStepCard {
  readonly stepNumber: string;
  readonly title: string;
  readonly windowLabel: string;
  readonly photoSrc: string;
  readonly summary: string;
  readonly audioSeekSeconds: number;
}

interface ScopeOption {
  readonly id: string;
  readonly label: string;
  readonly hoursLabel: string;
  readonly brickLaborUsd: number;
  readonly franchiseQuoteUsd: number;
  readonly diyRentalUsd: number;
  readonly coverageSummary: string;
}

interface GalleryPhotoItem {
  readonly id: string;
  readonly title: string;
  readonly neighborhoodLabel: string;
  readonly src: string;
  readonly alt: string;
  readonly psiLabel: string;
  readonly nozzleLabel: string;
  readonly dwellLabel: string;
  readonly caption: string;
}

interface PrepChecklistItem {
  readonly id: string;
  readonly title: string;
  readonly detail: string;
}

const SURFACE_ITEMS: readonly SurfaceGuideItem[] = [
  {
    id: 'brick',
    label: 'Historic Red Brick & Lime Mortar',
    neighborhoodLabel: 'Ironbound & Central Ward',
    photoSrc: '/cities/newark/local-1.jpg',
    photoAlt: 'Historic red-brick and limestone architecture in Newark, NJ',
    methodHeadline: 'Gentle Soft-Wash Soap Soak + Wide 40° Low-Pressure Rinse',
    howWeClean:
      'We pre-wet the brick, apply our biodegradable masonry soap for 5–8 minutes to loosen dark street soot and green moss, and rinse with a wide fan spray at low garden-hose pressure (450–500 PSI).',
    whatWeAvoid:
      'Never use narrow, high-pressure tips on pre-1940 lime mortar — high PSI carves out soft mortar joints and pits the baked clay face.',
    typicalTimeAndCost: '1 to 1.5 Hours ($50–$75 at $50/hr)',
  },
  {
    id: 'brownstone',
    label: 'Belleville Brownstone Stoops',
    neighborhoodLabel: 'James St Commons & Lincoln Park',
    photoSrc: '/cities/newark/local-4.jpg',
    photoAlt: 'A.D. 1888 Newark brownstone porch and masonry details',
    methodHeadline: 'pH-Neutral Stone Cleaner + Soft Bristle Brush + Gentle Rinse',
    howWeClean:
      'Historic Belleville brownstone is naturally porous and layered. We wash a free 2ft × 2ft step riser corner first using pH-neutral stone cleaner and a soft brush before rinsing gently.',
    whatWeAvoid:
      'Never use harsh acids, raw bleach mixes, or rotary turbo nozzles on brownstone steps or carved cheek walls.',
    typicalTimeAndCost: '1 Hour ($50 total · 1 worker × 1 hr)',
  },
  {
    id: 'bluestone',
    label: 'Shaded Bluestone & Paver Walkways',
    neighborhoodLabel: 'Forest Hill & Weequahic',
    photoSrc: '/guides/power-washing/dry-sweep.jpg',
    photoAlt: 'Sweeping and washing a shaded bluestone and paver patio',
    methodHeadline: 'Dry Sweep First + Angled Fan Pass Preserving Joint Sand',
    howWeClean:
      'After sweeping away oak leaves and acorns, we treat slippery green moss with plant-safe outdoor cleaner and rinse at a shallow angle across the stone slabs.',
    whatWeAvoid:
      'Never point a high-pressure jet straight down into paver joints — angled passes keep polymeric and bedding sand locked in place.',
    typicalTimeAndCost: '1.5 to 2 Hours ($75–$100 at $50/hr)',
  },
  {
    id: 'concrete',
    label: 'Poured Concrete Driveways & Aprons',
    neighborhoodLabel: 'Roseville & Vailsburg',
    photoSrc: '/guides/power-washing/surface-cleaner.jpg',
    photoAlt: 'Circular rotary surface cleaner washing a concrete driveway evenly',
    methodHeadline: '16-Inch Circular Rotary Surface Cleaner (Zero Wand Streaks)',
    howWeClean:
      'Our 4.0 GPM commercial washer drives a hovering circular surface cleaner that spins twin nozzles at a fixed height — delivering an even, streak-free brighten across every slab.',
    whatWeAvoid:
      'Never wave a narrow handheld wand across a full driveway — freehand wands leave permanent light-and-dark "zebra stripes" once dry.',
    typicalTimeAndCost: '1.5 to 2 Hours ($75–$100 for a 2-car driveway)',
  },
];

const WALKTHROUGH_STEPS: readonly WalkthroughStepCard[] = [
  {
    stepNumber: '01',
    title: 'Dry Sweep & Spigot Check',
    windowLabel: 'Minutes 00–05',
    photoSrc: '/guides/power-washing/dry-sweep.jpg',
    summary:
      'We push-broom loose leaves, acorns, and street grit off the patio or stoop first so water never turns dry dirt into mud splatter.',
    audioSeekSeconds: 0,
  },
  {
    stepNumber: '02',
    title: 'Pre-Wet Plants & Soap Dwell',
    windowLabel: 'Minutes 05–12',
    photoSrc: '/cities/newark/3.jpg',
    summary:
      'We water adjacent shrubs and grass with fresh tap water, then apply plant-safe outdoor soap for a 5–8 minute dwell so grime loosens gently.',
    audioSeekSeconds: 58,
  },
  {
    stepNumber: '03',
    title: 'Free 2ft × 2ft Sample Spot',
    windowLabel: 'Minutes 12–18',
    photoSrc: '/guides/power-washing/hero.jpg',
    summary:
      'We wash and squeegee a 2ft × 2ft test square right in front of you so you can inspect the clean contrast before approving the full wash.',
    audioSeekSeconds: 140,
  },
  {
    stepNumber: '04',
    title: 'Full Wash & Final Plant Rinse',
    windowLabel: 'Minutes 18–120',
    photoSrc: '/guides/power-washing/surface-cleaner.jpg',
    summary:
      'With your thumbs-up, we complete the rest of the driveway, stoop, or siding at a flat $50/hr per worker and rinse down every curb edge.',
    audioSeekSeconds: 224,
  },
];

const SCOPE_OPTIONS: readonly ScopeOption[] = [
  {
    id: '1hr',
    label: 'Front Stoop & Sidewalk (1 Hr)',
    hoursLabel: '1 Worker × 1 Hr · Free 2ft × 2ft Sample Included',
    brickLaborUsd: 50,
    franchiseQuoteUsd: 275,
    diyRentalUsd: 145,
    coverageSummary: 'Covers front brick or brownstone steps, front sidewalk strip, and small porch apron (~350–450 sq ft).',
  },
  {
    id: '2hr',
    label: '2-Car Driveway + Front Steps (2 Hrs)',
    hoursLabel: '1 Worker × 2 Hrs · Most Common Newark Visit',
    brickLaborUsd: 100,
    franchiseQuoteUsd: 420,
    diyRentalUsd: 165,
    coverageSummary: 'Covers a standard 2-car concrete driveway, front walkway, and porch steps (~650–900 sq ft).',
  },
  {
    id: '3hr',
    label: 'Driveway + Patio + Siding (3 Hrs)',
    hoursLabel: '1 Worker × 3 Hrs · Complete Exterior Refresh',
    brickLaborUsd: 150,
    franchiseQuoteUsd: 560,
    diyRentalUsd: 195,
    coverageSummary: 'Covers full driveway, backyard bluestone or paver patio, retaining wall, and first-floor siding.',
  },
];

const GALLERY_PHOTOS: readonly GalleryPhotoItem[] = [
  {
    id: 'sample-hero',
    title: 'Live 2ft × 2ft Sample Test Stripe on Weathered Concrete',
    neighborhoodLabel: 'Ironbound & Roseville · 07105 / 07107',
    src: '/guides/power-washing/hero.jpg',
    alt: 'Live 2ft by 2ft power washing sample test spot showing clean concrete next to weathered grime',
    psiLabel: '2,200 PSI Calibrated',
    nozzleLabel: '16" Rotary Deck',
    dwellLabel: '6-Min Soap Dwell',
    caption:
      'Every visit starts with a free 2ft × 2ft test square on the dirtiest section of your driveway or walkway so you see the exact dry finish before paying for a full wash.',
  },
  {
    id: 'brownstone-1888',
    title: 'A.D. 1888 Belleville Brownstone Porch & Carved Limestone Frieze',
    neighborhoodLabel: 'James St Commons · 07102',
    src: '/cities/newark/local-4.jpg',
    alt: 'Historic A.D. 1888 Newark brownstone stoop and carved masonry',
    psiLabel: '450 PSI Soft-Wash',
    nozzleLabel: '40° White Fan Tip',
    dwellLabel: '8-Min pH-Neutral Dwell',
    caption:
      'Sedimentary Belleville brownstone flakes if hit above 600 PSI. We use a pH-neutral stone surfactant and low-pressure fan rinse to lift soot without scarring the stone.',
  },
  {
    id: 'university-brick',
    title: 'Pre-1940 Red Clay Brick & Limestone Trim Along Dr. MLK Jr. Blvd',
    neighborhoodLabel: 'University Heights · 07102',
    src: '/cities/newark/local-1.jpg',
    alt: '19th-century Newark red brick rowhouse facade with white limestone trim',
    psiLabel: '500 PSI Soft-Wash',
    nozzleLabel: '40° Wide Rinse',
    dwellLabel: '8-Min Biodegradable Soap',
    caption:
      'Soft pre-war lime-and-sand mortar joints require gentle surfactant dwell rather than high water pressure, protecting historic mortar while restoring crisp terracotta color.',
  },
  {
    id: 'branch-brook-bluestone',
    title: 'Branch Brook Park Canopy & Shaded Forest Hill Bluestone Walkways',
    neighborhoodLabel: 'Forest Hill · 07104',
    src: '/cities/newark/3.jpg',
    alt: 'Olmsted Branch Brook Park tree canopy and historic Newark masonry border',
    psiLabel: '800–1,100 PSI',
    nozzleLabel: '25° Green Fan Tip',
    dwellLabel: '7-Min EPA Safer Choice',
    caption:
      'Dense oak and cherry blossom shade traps moisture and slippery green moss on bluestone slabs. We pre-wet nearby flowerbeds before lifting organic growth cleanly.',
  },
];

const PREP_CHECKLIST_ITEMS: readonly PrepChecklistItem[] = [
  {
    id: 'spigot',
    title: 'Turn on your outdoor water spigot',
    detail: 'Verify the indoor basement shut-off valve is open so our 4.0 GPM commercial hose has steady flow.',
  },
  {
    id: 'windows',
    title: 'Latch ground-floor windows & storm doors',
    detail: 'Make sure basement hopper windows, screen doors, and mail slots are tightly closed.',
  },
  {
    id: 'cars',
    title: 'Move vehicles 25 feet clear of the driveway apron',
    detail: 'Parking a short distance down the curb keeps road grit and rinse mist off your windshield.',
  },
  {
    id: 'pets',
    title: 'Keep pets indoors while hoses are pressurized',
    detail: 'High-flow hoses and surface spinners move quickly across steps, patios, and walkways.',
  },
  {
    id: 'test-spot',
    title: 'Pick your favorite 2ft × 2ft sample test corner',
    detail: 'Point out the most weathered spot on your stoop, patio, or driveway when our crew lead arrives.',
  },
];

/**
 * Open, Containerless Editorial Multimedia Flow for Articles & Guides
 * (`@theme.tools/ui/field-service/components/ArticleMultimediaSuite`).
 *
 * All content escapes tab panes and heavy nested card containers, flowing
 * directly into the surrounding article column with clean editorial headings.
 */
export function ArticleMultimediaSuite({
  townName = 'Newark',
  state = 'NJ',
  bookingUrl = 'https://bricklabor.com/book',
  hideFaq = false,
}: ArticleMultimediaSuiteProps) {
  const ttSurface = useThemeToolsSurface('article-multimedia-suite');
  const [splitPct, setSplitPct] = useState(52);
  const [checkedPrepIds, setCheckedPrepIds] = useState<readonly string[]>([
    'spigot',
    'test-spot',
  ]);

  const triggerAudioSeek = (seconds: number) => {
    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('bricklabor:podcast-seek', {
          detail: { seconds, autoPlay: true },
        }),
      );
      const playerEl = document.querySelector('[data-testid="atf-podcast-player"]');
      playerEl?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  const togglePrepItem = (id: string) => {
    setCheckedPrepIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id],
    );
  };

  const prepReadyPct = Math.round(
    (checkedPrepIds.length / PREP_CHECKLIST_ITEMS.length) * 100,
  );

  return (
    <ThemeToolsPageSurface
      surface="article-multimedia-suite"
      data-testid="article-multimedia-suite"
      className="my-12 space-y-14 not-prose"
      {...ttSurface.dataAttributes}
    >
      {/* 1. Open Editorial Key Takeaways Summary */}
      <section
        data-testid="tt-blog-key-takeaways"
        aria-label={`What every ${townName} homeowner should know before booking a wash`}
        className="border-t border-white/10 pt-10"
      >
        <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-[#f5f2ed]">
          At a Glance: Why {townName} Homeowners Start With a Free 2ft × 2ft Sample Spot
        </h3>
        <p className="mt-2 text-sm sm:text-base text-[#c5c0b8] max-w-3xl leading-relaxed">
          Instead of guessing what a pressure washer will do to your historic brick, brownstone stoop, or concrete driveway, you see a live test patch cleaned right in front of you before paying for a full wash.
        </p>

        <div className="mt-6 grid gap-6 sm:grid-cols-2">
          {[
            {
              num: '01',
              title: 'Free 2ft × 2ft sample patch washed first',
              body: `We wash and squeegee a 4-sq-ft test spot on your ${townName} stoop, walkway, or driveway so you verify the dry finish before approving the full job.`,
            },
            {
              num: '02',
              title: 'Flat $50/hr per worker — no $450+ package markups',
              body: '1-hour minimum, billed in exact 15-minute ($12.50) increments after hour 1. A typical 2-car driveway and front stoop takes 2 hours ($100 total).',
            },
            {
              num: '03',
              title: '500 PSI soft-wash on pre-1940 brick & brownstone',
              body: 'Soft Ironbound lime mortar and Belleville brownstone get biodegradable soap dwell and a gentle 40° fan rinse—never destructive 3,000 PSI.',
            },
            {
              num: '04',
              title: '$0 equipment or travel fee across Newark',
              body: `Our 4.0 GPM commercial washer, 16-inch rotary surface cleaner, hoses, and EPA Safer Choice plant-safe soaps arrive on the truck at $0 extra anywhere in ${townName}, ${state}.`,
            },
          ].map((item) => (
            <div key={item.num} className="border-l-2 border-[#ff6b1a]/60 pl-4">
              <span className="font-mono text-xs font-bold text-[#ff8a47]">
                {item.num}
              </span>
              <h4 className="mt-0.5 font-display text-base font-extrabold text-[#f5f2ed]">
                {item.title}
              </h4>
              <p className="mt-1 text-xs sm:text-sm text-[#c5c0b8] leading-relaxed">
                {item.body}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* 2. Open Full-Bleed Before / After Sample Spot Comparison Figure */}
      <section
        id="multimedia-before-after"
        data-testid="tt-multimedia-before-after-slider"
        aria-label={`Interactive ${townName} 2ft by 2ft sample spot photo comparison slider`}
        className="border-t border-white/10 pt-10"
      >
        <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-[#f5f2ed]">
          Side-by-Side Contrast: Weathered Surface vs. Cleaned 2ft × 2ft Sample Spot
        </h3>
        <p className="mt-2 text-sm sm:text-base text-[#c5c0b8] max-w-3xl leading-relaxed">
          Drag the divider across the photo below to see the exact transition line our crew creates during the complimentary 2ft × 2ft test wash.
        </p>

        <div className="mt-5 relative aspect-[16/9] w-full overflow-hidden rounded-2xl border border-white/12 bg-[#070a0f] select-none">
          <img
            src="/guides/power-washing/hero.jpg"
            alt={`Freshly washed 2ft by 2ft sample test stripe in ${townName}, ${state}`}
            width={1200}
            height={675}
            loading="lazy"
            className="h-full w-full object-cover brightness-110 contrast-105"
          />
          <span className="absolute right-3 top-3 rounded-full bg-[#080b10]/85 px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-wider text-emerald-300">
            After: Cleaned 2ft × 2ft Sample ($50/hr)
          </span>

          <div
            style={{ width: `${splitPct}%` }}
            className="absolute inset-y-0 left-0 overflow-hidden border-r-2 border-[#ff6b1a]"
          >
            <img
              src="/guides/power-washing/dry-sweep.jpg"
              alt={`Weathered unwashed masonry and concrete in ${townName}, ${state}`}
              width={1200}
              height={675}
              loading="lazy"
              className="h-full w-full max-w-none object-cover sepia-[0.18] brightness-75"
              style={{ width: '100%' }}
            />
            <span className="absolute left-3 top-3 rounded-full bg-[#080b10]/85 px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-wider text-[#c5c0b8]">
              Before: Unwashed Grime &amp; Moss
            </span>
          </div>
        </div>

        <div className="mt-3 flex items-center gap-3">
          <span className="font-mono text-xs text-[#9ba1ab]">Before</span>
          <input
            type="range"
            min={5}
            max={95}
            value={splitPct}
            onChange={(e) => setSplitPct(Number(e.target.value))}
            aria-label="Slide to compare before and after power washing test spot"
            className="h-1.5 flex-1 cursor-pointer appearance-none rounded-full bg-white/15 accent-[#ff6b1a]"
          />
          <span className="font-mono text-xs text-emerald-300">
            After ({splitPct}%)
          </span>
        </div>
      </section>

      {/* 3. Open 4-Surface Architectural Breakdown (Escaped from Tab Panes — All 4 Surfaces Visible) */}
      <section
        id="multimedia-surface-tabs"
        data-testid="tt-multimedia-surface-tabs"
        aria-label={`${townName} surface care guide across all four masonry and concrete types`}
        className="border-t border-white/10 pt-10"
      >
        <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-[#f5f2ed]">
          How We Match Water Pressure &amp; Soap to Every {townName} Surface
        </h3>
        <p className="mt-2 text-sm sm:text-base text-[#c5c0b8] max-w-3xl leading-relaxed">
          {townName}&apos;s historic brick rowhouses, Belleville brownstone stoops, shaded bluestone walkways, and poured concrete driveways each require a different pressure and nozzle setup. Here is how we treat all four:
        </p>

        <div className="mt-7 grid gap-x-8 gap-y-12 sm:grid-cols-2">
          {SURFACE_ITEMS.map((surface) => (
            <div
              key={surface.id}
              data-testid={`surface-tab-${surface.id}`}
              className="flex flex-col justify-between border-b border-white/10 pb-8"
            >
              <div>
                <div className="aspect-[16/10] w-full overflow-hidden rounded-2xl border border-white/10">
                  <img
                    src={surface.photoSrc}
                    alt={surface.photoAlt}
                    width={640}
                    height={400}
                    loading="lazy"
                    className="h-full w-full object-cover"
                  />
                </div>
                <div className="mt-4 flex flex-wrap items-center gap-2">
                  <span className="rounded-md bg-[#ff6b1a]/15 border border-[#ff6b1a]/30 px-2.5 py-0.5 font-mono text-[10px] font-bold uppercase tracking-wider text-[#ff985a]">
                    {surface.neighborhoodLabel}
                  </span>
                  <span className="rounded-md bg-emerald-500/12 border border-emerald-400/25 px-2.5 py-0.5 font-mono text-[11px] font-bold text-emerald-300">
                    {surface.typicalTimeAndCost}
                  </span>
                </div>
                <h4 className="mt-2.5 font-display text-lg font-extrabold text-[#f5f2ed] leading-snug">
                  {surface.label}: {surface.methodHeadline}
                </h4>
                <p className="mt-2.5 text-xs sm:text-sm text-[#c5c0b8] leading-relaxed">
                  <strong className="text-white">How we clean it:</strong> {surface.howWeClean}
                </p>
              </div>
              <p className="mt-4 border-l-2 border-amber-400/60 pl-3.5 text-xs text-amber-200/90 leading-relaxed">
                <strong>What we avoid:</strong> {surface.whatWeAvoid}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* 4. Open 4-Step On-Site Routine Flow */}
      <section
        id="multimedia-step-reel"
        data-testid="tt-multimedia-step-reel"
        aria-label="4-step on-site walkthrough with audio sync"
        className="border-t border-white/10 pt-10"
      >
        <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-[#f5f2ed]">
          What Happens During the First 20 Minutes at Your Curb
        </h3>
        <p className="mt-2 text-sm sm:text-base text-[#c5c0b8] max-w-3xl leading-relaxed">
          Every {townName} visit follows the same four-step sequence—from dry-sweeping loose leaves to rinsing your 2ft × 2ft test spot. You can also jump the audio player above directly to any step:
        </p>

        <div className="mt-7 grid gap-x-8 gap-y-10 sm:grid-cols-2">
          {WALKTHROUGH_STEPS.map((step) => (
            <div
              key={step.stepNumber}
              className="flex flex-col justify-between border-b border-white/10 pb-6"
            >
              <div>
                <div className="relative aspect-[16/10] w-full overflow-hidden rounded-2xl border border-white/10">
                  <img
                    src={step.photoSrc}
                    alt={step.title}
                    width={640}
                    height={400}
                    loading="lazy"
                    className="h-full w-full object-cover"
                  />
                  <span className="absolute left-3 top-3 rounded-full bg-[#080b10]/90 border border-[#ff6b1a]/40 px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-wider text-[#ff985a]">
                    Step {step.stepNumber} · {step.windowLabel}
                  </span>
                </div>
                <h4 className="mt-3.5 font-display text-lg font-extrabold text-[#f5f2ed] leading-snug">
                  {step.title}
                </h4>
                <p className="mt-2 text-xs sm:text-sm text-[#c5c0b8] leading-relaxed">
                  {step.summary}
                </p>
              </div>
              <button
                type="button"
                onClick={() => triggerAudioSeek(step.audioSeekSeconds)}
                data-testid={`step-audio-seek-${step.stepNumber}`}
                className="mt-4 inline-flex w-fit items-center gap-2 rounded-lg border border-[#ff6b1a]/35 bg-[#ff6b1a]/10 px-3 py-1.5 font-mono text-xs font-bold text-[#ff985a] hover:bg-[#ff6b1a] hover:text-[#080b10] transition"
              >
                <span>▶ Hear Step {step.stepNumber} in Audio Overview</span>
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* 5. Open Field Photography Essay (Escaped from Filmstrip Tabs — All 4 Photos Visible) */}
      <section
        id="multimedia-photo-gallery"
        data-testid="tt-multimedia-photo-gallery"
        aria-label={`${townName} masonry and field photography`}
        className="border-t border-white/10 pt-10"
      >
        <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-[#f5f2ed]">
          Local {townName} Masonry &amp; Concrete Calibration Examples
        </h3>
        <p className="mt-2 text-sm sm:text-base text-[#c5c0b8] max-w-3xl leading-relaxed">
          From A.D. 1888 Belleville brownstone porches near James Street to shaded Forest Hill bluestone walkways bordering Branch Brook Park, here are the exact PSI and surfactant settings we use across {townName}:
        </p>

        <div className="mt-7 grid gap-x-8 gap-y-12 sm:grid-cols-2">
          {GALLERY_PHOTOS.map((photo) => (
            <figure
              key={photo.id}
              data-testid={`gallery-thumb-${photo.id}`}
              className="space-y-3.5"
            >
              <div className="relative aspect-[16/10] w-full overflow-hidden rounded-2xl border border-white/10">
                <img
                  src={photo.src}
                  alt={photo.alt}
                  width={720}
                  height={450}
                  loading="lazy"
                  className="h-full w-full object-cover"
                />
                <span className="absolute left-3.5 top-3.5 rounded-full bg-[#080b10]/85 px-3 py-1 font-mono text-[10px] font-bold text-[#ff985a]">
                  {photo.neighborhoodLabel}
                </span>
              </div>
              <figcaption className="space-y-2">
                <div className="flex flex-wrap items-center gap-1.5 font-mono text-[11px]">
                  <span className="rounded-md bg-emerald-500/12 border border-emerald-400/25 px-2 py-0.5 font-bold text-emerald-300">
                    {photo.psiLabel}
                  </span>
                  <span className="rounded-md bg-[#ff6b1a]/12 border border-[#ff6b1a]/25 px-2 py-0.5 text-[#ff985a]">
                    {photo.nozzleLabel}
                  </span>
                  <span className="rounded-md bg-cyan-500/12 border border-cyan-400/25 px-2 py-0.5 text-cyan-300">
                    {photo.dwellLabel}
                  </span>
                </div>
                <h4 className="font-display text-base sm:text-lg font-extrabold text-[#f5f2ed] leading-snug">
                  {photo.title}
                </h4>
                <p className="text-xs sm:text-sm text-[#c5c0b8] leading-relaxed">
                  {photo.caption}
                </p>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      {/* 6. Open Side-by-Side $50/hr Cost vs. Package Quote Comparison (Escaped from Scope Tabs) */}
      <section
        id="multimedia-scope-picker"
        data-testid="tt-multimedia-scope-picker"
        aria-label="Hourly cost versus flat-rate franchise comparison"
        className="border-t border-white/10 pt-10"
      >
        <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-[#f5f2ed]">
          Transparent $50/hr Pricing vs. Flat-Rate Franchise Quotes
        </h3>
        <p className="mt-2 text-sm sm:text-base text-[#c5c0b8] max-w-3xl leading-relaxed">
          Because we bill a flat $50/hr per worker (1-hour minimum, $12.50 per 15-minute increment after hour 1, $0 equipment or travel fee), homeowners save 65% to 75% compared to per-square-foot package quotes:
        </p>

        <div className="mt-7 grid gap-8 sm:grid-cols-3">
          {SCOPE_OPTIONS.map((opt) => {
            const saved = opt.franchiseQuoteUsd - opt.brickLaborUsd;
            return (
              <div
                key={opt.id}
                data-testid={`scope-option-${opt.id}`}
                className="flex flex-col justify-between border-l-2 border-[#ff6b1a]/70 pl-5 pr-2 py-1.5"
              >
                <div>
                  <span className="inline-block rounded-md bg-emerald-500/12 border border-emerald-400/25 px-2.5 py-0.5 font-mono text-[11px] font-bold text-emerald-300">
                    Save ${saved} vs. Flat-Rate
                  </span>
                  <h4 className="mt-2 font-display text-lg font-extrabold text-[#f5f2ed] leading-snug">
                    {opt.label}
                  </h4>
                  <p className="mt-1 font-mono text-xs text-[#9ba1ab]">
                    {opt.hoursLabel}
                  </p>
                  <p className="mt-2.5 text-xs sm:text-sm text-[#c5c0b8] leading-relaxed">
                    {opt.coverageSummary}
                  </p>
                </div>

                <dl className="mt-5 space-y-2 border-t border-white/10 pt-3.5 font-mono text-xs">
                  <div className="flex items-baseline justify-between gap-3 text-emerald-300 font-bold">
                    <dt>Brick Labor ($50/hr)</dt>
                    <dd className="shrink-0">${opt.brickLaborUsd}</dd>
                  </div>
                  <div className="flex items-baseline justify-between gap-3 text-[#9ba1ab]">
                    <dt>DIY Rental + Soap</dt>
                    <dd className="shrink-0">${opt.diyRentalUsd}</dd>
                  </div>
                  <div className="flex items-baseline justify-between gap-3 text-rose-300/90 line-through">
                    <dt>Franchise Package</dt>
                    <dd className="shrink-0">${opt.franchiseQuoteUsd}</dd>
                  </div>
                </dl>
              </div>
            );
          })}
        </div>

        <div className="mt-8 flex flex-col sm:flex-row sm:items-center justify-between gap-5 rounded-2xl border border-white/10 bg-white/[0.025] px-6 py-5">
          <p className="text-xs sm:text-sm text-[#c5c0b8] leading-relaxed max-w-xl">
            Need ongoing storefront or multi-family sidewalk care? Standing recurring plans automatically discount our $50/hr rate: <strong className="text-white">Daily (-12% · $44/hr)</strong>, <strong className="text-white">Weekly (-8% · $46/hr)</strong>, <strong className="text-white">Biweekly (-5% · $47.50/hr)</strong>, and <strong className="text-white">Monthly (-3% · $48.50/hr)</strong>.
          </p>
          <a
            href={bookingUrl}
            className="shrink-0 rounded-xl bg-[#ff6b1a] px-5 py-2.5 font-mono text-xs font-extrabold uppercase tracking-wider text-[#080b10] hover:bg-[#ff823d] transition text-center"
          >
            Book Your $50/hr Crew →
          </a>
        </div>
      </section>

      {/* 7. Open 5-Minute Homeowner Prep Checklist & Field Notes */}
      <section
        id="multimedia-prep-checklist"
        data-testid="tt-multimedia-prep-checklist"
        aria-label="5-minute homeowner preparation checklist"
        className="border-t border-white/10 pt-10"
      >
        <div className="flex flex-wrap items-baseline justify-between gap-3">
          <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-[#f5f2ed]">
            5-Minute Homeowner Prep Checklist Before We Arrive
          </h3>
          <span className="font-mono text-xs font-bold text-emerald-300">
            {checkedPrepIds.length} of {PREP_CHECKLIST_ITEMS.length} Checked ({prepReadyPct}%)
          </span>
        </div>

        <div className="mt-4 divide-y divide-white/10">
          {PREP_CHECKLIST_ITEMS.map((item) => {
            const checked = checkedPrepIds.includes(item.id);
            return (
              <button
                key={item.id}
                type="button"
                role="checkbox"
                aria-checked={checked}
                data-testid={`prep-check-${item.id}`}
                onClick={() => togglePrepItem(item.id)}
                className="flex w-full items-start gap-3.5 py-3.5 text-left transition hover:text-white"
              >
                <span
                  className={`mt-0.5 inline-flex h-5 w-5 shrink-0 items-center justify-center rounded border font-mono text-xs font-extrabold ${
                    checked
                      ? 'border-emerald-400 bg-emerald-500 text-[#06100c]'
                      : 'border-white/30 bg-transparent text-transparent'
                  }`}
                >
                  ✓
                </span>
                <div>
                  <span className="font-display text-sm sm:text-base font-extrabold text-[#f5f2ed] block">
                    {item.title}
                  </span>
                  <span className="mt-0.5 text-xs sm:text-sm text-[#9ba1ab] block">
                    {item.detail}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Open Field Notes Trio */}
        <div
          data-testid="tt-blog-callout-cards"
          className="mt-8 grid gap-6 md:grid-cols-3 border-t border-white/10 pt-6"
        >
          <div className="border-l-2 border-emerald-400/60 pl-3.5">
            <h4 className="font-display text-sm font-extrabold text-[#f5f2ed]">
              Plant &amp; Hydrangea Protection
            </h4>
            <p className="mt-1 text-xs text-[#c5c0b8] leading-relaxed">
              Soaking leaves and topsoil with fresh tap water before applying EPA Safer Choice outdoor soap ensures roots never absorb wash runoff.
            </p>
          </div>
          <div className="border-l-2 border-amber-400/60 pl-3.5">
            <h4 className="font-display text-sm font-extrabold text-[#f5f2ed]">
              Pre-1940 Lime Mortar Caution
            </h4>
            <p className="mt-1 text-xs text-[#c5c0b8] leading-relaxed">
              Pre-war Newark rowhouses use soft lime-and-sand mortar. High water pressure carves out joints and forces moisture behind the brick wythe.
            </p>
          </div>
          <div className="border-l-2 border-[#ff6b1a]/60 pl-3.5">
            <h4 className="font-display text-sm font-extrabold text-[#f5f2ed]">
              Standing Storefront Plans
            </h4>
            <p className="mt-1 text-xs text-[#c5c0b8] leading-relaxed">
              Keep Ferry St, Broad St, or multi-family sidewalks spotless year-round with Daily (-12%), Weekly (-8%), Biweekly (-5%), or Monthly (-3%) plans.
            </p>
          </div>
        </div>
      </section>

      {/* 8. Open Comprehensive 8-Question FAQ Flow (Without Any Meta/Container Chrome) */}
      {!hideFaq && (
        <section
          id="multimedia-faq-accordion"
          data-testid="tt-comprehensive-faq-accordion"
          aria-label={`Frequently Asked Questions about ${townName} Power Washing and Free Sample Spot`}
          className="border-t border-white/10 pt-10"
        >
          <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-[#f5f2ed]">
            Frequently Asked Questions
          </h3>
          <p className="mt-2 text-sm sm:text-base text-[#c5c0b8] max-w-3xl leading-relaxed">
            Common questions from {townName} homeowners and storefront operators about our free 2ft × 2ft sample spot, historic brick soft-washing, rotary driveway cleaning, and $50/hr billing:
          </p>

          <div className="mt-6 divide-y divide-white/10">
            {[
              {
                q: `How does the free 2ft × 2ft sample test spot work on ${townName} power-washing visits?`,
                a: `Before we wash your full driveway, front steps, brick porch, or siding, our technician washes a complimentary 4-square-foot (2ft × 2ft) sample test spot on a low-visibility corner using our EPA Safer Choice outdoor cleaning soap and the exact water pressure calibrated for your material. You inspect the clean, squeegeed patch side-by-side against the unwashed surface in person before authorizing the rest of the job at our flat $50/hr per-worker rate.`,
              },
              {
                q: `How do you soft-wash historic Ironbound (07105) red brick rowhouses without etching pre-1940 lime mortar?`,
                a: `Pre-war ${townName} rowhouses in the Ironbound, University Heights, and Central Ward use soft lime-and-sand mortar that erodes if hit with 3,000+ PSI. We apply a biodegradable masonry surfactant for a timed 5–8 minute dwell to loosen diesel soot, black algae, and green moss chemically, then rinse with a wide 40° white fan tip at a gentle 450–500 PSI so the brick brightens while every mortar joint stays 100% intact.`,
              },
              {
                q: `How much does $50/hr pressure washing in ${townName} (07102–07114) cost compared to $380–$620 flat-rate quotes?`,
                a: `Brick Labor charges a flat $50/hr per crew member with a 1-hour minimum and exact 15-minute ($12.50) billing increments after hour 1—with $0 equipment rental fee and $0 travel fee anywhere in ${townName}. A front stoop and sidewalk apron typically takes 1 hour ($50 total), a standard two-car concrete driveway plus front steps takes 1.5 to 2 hours ($75 to $100 total), and a full driveway, backyard patio, and first-floor siding wash takes about 3 hours ($150 total).`,
              },
              {
                q: `How do you clean mossy Forest Hill bluestone walkways and Belleville brownstone stoops safely?`,
                a: `Shaded bluestone walkways near Branch Brook Park in Forest Hill (07104) and porous A.D. 1888 Belleville brownstone steps in James Street Commons and Lincoln Park (07102) require low-pressure surface care. We dry-sweep loose oak leaves and acorns first, treat slippery green moss with pH-neutral stone cleaner, and rinse at a shallow fan angle (450–900 PSI) that lifts organic growth without flaking layered brownstone or blowing polymeric sand out of paver joints.`,
              },
              {
                q: `How do you prevent wand "zebra stripes" on concrete driveways in Roseville, Vailsburg, and Weequahic?`,
                a: `Waving a narrow handheld wand across a wide concrete driveway leaves permanent light-and-dark "zebra stripes" once the slab dries. Our crew brings a 4.0 GPM commercial pressure washer paired with a hovering 16-inch circular rotary surface cleaner that spins twin nozzles at a fixed height and speed—washing concrete driveways and sidewalk aprons evenly from edge to edge with zero streaking.`,
              },
              {
                q: `Do you offer commercial storefront sidewalk demo washes and recurring hourly discounts in ${townName}?`,
                a: `Yes. Retail storefronts, restaurants, and multi-family landlords along Ferry Street, Broad Street, Market Street, and Halsey Street can request the same free 2ft × 2ft sidewalk demo patch to see chewing-gum stain, grease, and algae removal firsthand. Property owners who sign up for standing recurring maintenance save automatically on our $50/hr rate: Daily (-12% at $44/hr), Weekly (-8% at $46/hr), Biweekly (-5% at $47.50/hr), and Monthly (-3% at $48.50/hr).`,
              },
              {
                q: `Are your power-washing soaps safe for hydrangeas, boxwoods, lawn edges, and pets?`,
                a: `Yes. Before applying any cleaner, our crew thoroughly pre-wets your nearby hydrangeas, boxwoods, flowerbeds, and grass with fresh tap water so leaves and roots never absorb wash runoff. We use EPA Safer Choice biodegradable outdoor surfactants rather than harsh raw bleach or muriatic acid, and we give all surrounding foliage a final fresh-water rinse before wrapping up.`,
              },
              {
                q: `What is the 5-minute homeowner prep checklist before the ${townName} power-washing crew arrives?`,
                a: `Before your arrival window, just complete five quick steps: (1) turn on your outdoor water spigot at the indoor basement shut-off valve, (2) close and latch ground-floor windows and storm doors, (3) move vehicles 25 feet clear of the driveway apron, (4) keep pets indoors while hoses are pressurized, and (5) pick out the dirtiest 2ft × 2ft corner you want us to wash first as your free sample test spot.`,
              },
            ].map((faq, idx) => (
              <details
                key={faq.q}
                data-testid="faq-accordion-item"
                open={idx < 2}
                className="group py-4"
              >
                <summary className="flex cursor-pointer list-none items-start justify-between gap-4 font-display text-base sm:text-lg font-extrabold text-[#f5f2ed] hover:text-[#ff8a47] transition">
                  <span>{faq.q}</span>
                  <span className="mt-1 shrink-0 font-mono text-xs text-[#ff8a47] transition-transform group-open:rotate-180">
                    ▼
                  </span>
                </summary>
                <p className="mt-2.5 text-sm sm:text-base text-[#c5c0b8] leading-relaxed">
                  {faq.a}
                </p>
              </details>
            ))}
          </div>
        </section>
      )}
    </ThemeToolsPageSurface>
  );
}

export default ArticleMultimediaSuite;
