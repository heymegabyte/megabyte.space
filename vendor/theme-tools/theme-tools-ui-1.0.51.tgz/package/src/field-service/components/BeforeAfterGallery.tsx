import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { type JSX } from 'react';

interface PhotoPair {
  before: string;
  after: string;
  jobType: string;
  description?: string;
}

interface Props {
  pairs: PhotoPair[];
}

const FALLBACK_BEFORE = 'https://placehold.co/600x400/060610/FF6B1A?text=Before';
const FALLBACK_AFTER = 'https://placehold.co/600x400/060610/FF6B1A?text=After';

export const DEFAULT_PAIRS: PhotoPair[] = [
  {
    before: FALLBACK_BEFORE,
    after: FALLBACK_AFTER,
    jobType: 'Moving',
    description: '3-bedroom apartment packed and relocated in one day — furniture wrapped, no scratches.',
  },
  {
    before: FALLBACK_BEFORE,
    after: FALLBACK_AFTER,
    jobType: 'Cleanout',
    description: 'Basement hoarding cleared, sanitized, and ready for new flooring.',
  },
  {
    before: FALLBACK_BEFORE,
    after: FALLBACK_AFTER,
    jobType: 'Hauling',
    description: 'Two truckloads of construction debris hauled away before final inspection.',
  },
  {
    before: FALLBACK_BEFORE,
    after: FALLBACK_AFTER,
    jobType: 'Yard Work',
    description: 'Overgrown 1/4-acre lot tamed, pruned, and mulched in a single weekend.',
  },
  {
    before: FALLBACK_BEFORE,
    after: FALLBACK_AFTER,
    jobType: 'Junk Removal',
    description: 'Foreclosure contents — 12 rooms of furniture, appliances, and misc. hauled in 6 hours.',
  },
  {
    before: FALLBACK_BEFORE,
    after: FALLBACK_AFTER,
    jobType: 'Packing',
    description: 'Full-service packing for a 4-bedroom colonial — dishes, art, and antiques bubble-wrapped.',
  },
];

const pairId = (i: number) => `bag-${i}`;

/**
 * Before/after photo comparison gallery organized by job type.
 *
 * Shows each pair as a card with the "before" photo always visible and the
 * "after" photo overlaid with a CSS clip-path that clips to the right half.
 * On hover (or tap on touch devices) the clip-path expands to reveal the full
 * "after" photo — no JS drag needed. A subtle divider line marks the seam.
 *
 * Reduced-motion users see the full after image with no clip animation.
 */
export function BeforeAfterGallery({ pairs }: Props): JSX.Element | null {
  useThemeToolsSurface('before-after-gallery');
  if (!pairs.length) return null;

  return (
    <section data-testid="before-after-gallery" className="py-16 px-4">
      <div className="text-center mb-10">
        <span className="text-[11px] uppercase tracking-widest text-[var(--brand-accent)] font-semibold">
          Proof in photos
        </span>
        <h2 className="text-2xl md:text-3xl font-bold mt-2 text-[var(--brand-ink)]">
          See the Difference
        </h2>
        <p className="text-[var(--brand-mute)] mt-2 max-w-xl mx-auto">
          Real jobs from real Newark properties — before and after our crew stepped in.
          <span className="block mt-1 text-xs text-[var(--brand-mute)]">Hover or tap any card to reveal the full after photo.</span>
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
        {pairs.map((pair, i) => (
          <article
            key={pairId(i)}
            className="group relative overflow-hidden rounded-xl bg-[var(--bg-elevated)] border border-[var(--brand-line)]"
          >
            {/* Comparison area — before always visible, after clipped */}
            <div className="relative aspect-[4/3] overflow-hidden bg-[var(--bg-primary)]">
              {/* Before — always rendered, bottom layer */}
              <img
                src={pair.before}
                alt={`${pair.jobType} — before`}
                className="absolute inset-0 w-full h-full object-cover"
                width={600}
                height={400}
                loading={i === 0 ? 'eager' : 'lazy'}
                decoding="async"
              />

              {/* After — top layer, clipped to right half, revealed on hover */}
              <div
                className="
                  absolute inset-0 w-full h-full
                  [clip-path:inset(0_50%_0_0)]
                  group-hover:[clip-path:inset(0)]
                  motion-reduce:![clip-path:inset(0)]
                  transition-[clip-path] duration-700 ease-in-out
                  will-change-[clip-path]
                  z-10
                "
              >
                <img
                  src={pair.after}
                  alt={`${pair.jobType} — after`}
                  className="w-full h-full object-cover"
                  width={600}
                  height={400}
                  loading="lazy"
                  decoding="async"
                />

                {/* Vertical divider — visible at rest, fades on reveal */}
                <div
                  className="
                    absolute top-0 left-1/2 -translate-x-1/2 w-px h-full
                    bg-white/60
                    group-hover:opacity-0
                    motion-reduce:opacity-0
                    transition-opacity duration-500
                  "
                  aria-hidden
                />
              </div>

              {/* Labels */}
              <span
                className="
                  absolute top-2 left-2 z-20
                  bg-[var(--bg-primary)]/80 backdrop-blur-sm
                  px-2.5 py-1 rounded
                  text-[11px] font-semibold uppercase tracking-wider
                  text-[var(--brand-mute)]
                  pointer-events-none
                "
              >
                Before
              </span>
              <span
                className="
                  absolute top-2 right-2 z-20
                  bg-[var(--brand-accent)]/80 backdrop-blur-sm
                  px-2.5 py-1 rounded
                  text-[11px] font-semibold uppercase tracking-wider
                  text-white
                  pointer-events-none
                "
              >
                After
              </span>
            </div>

            {/* Footer */}
            <div className="p-3">
              <span className="text-[11px] uppercase tracking-widest text-[var(--brand-accent)] font-semibold">
                {pair.jobType}
              </span>
              {pair.description && (
                <p className="text-sm text-[var(--brand-mute)] mt-1 leading-relaxed">
                  {pair.description}
                </p>
              )}
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
