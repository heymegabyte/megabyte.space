import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect, useMemo, useState } from 'react';
import { BLOG_POSTS, BLOG_CATEGORIES } from '../data/blog-posts.js';
import blogAudioManifest from '../data/blog-audio.js';
import { SERVICES, serviceHeroImage } from '../data/services.js';
import { listedPosts, blogResultsAnnouncement } from '@theme.tools/seo-geo/field-service/blog-visibility';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { useRovingTabs } from '../use-roving-radio.js';
import { PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';

const BLOG_AUDIO = blogAudioManifest as Record<string, { src: string } | undefined>;

function formatDate(iso: string): string {
  const d = new Date(iso + 'T12:00:00');
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export function BlogIndex() {
  const surfaceProps = useThemeToolsSurface('blog-index');
  const [category, setCategory] = useState<string>('all');

  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const lp = (path: string): string => localizedPath(locale, path);

  // The category filter is a custom role="tablist". Roving-tabindex keyboard nav
  // (arrow/Home/End move selection + focus, single tab stop) — axe-core can't
  // detect the missing pattern, so the onClick-only version shipped green.
  const CATEGORIES = ['all', ...BLOG_CATEGORIES] as string[];
  const catTabs = useRovingTabs(CATEGORIES.length, (i) => setCategory(CATEGORIES[i] ?? 'all'));

  useEffect(() => {
    const prev = document.title;
    document.title = 'Newark Labor Blog — Field Notes from the Crew · Brick Labor';
    return () => {
      document.title = prev;
    };
  }, []);

  const posts = useMemo(() => {
    const sorted = listedPosts(BLOG_POSTS).sort((a, b) => (a.date < b.date ? 1 : -1));
    return category === 'all' ? sorted : sorted.filter((p) => p.category === category);
  }, [category]);

  // SR feedback when a filter tab changes the list. A custom role="tablist" that
  // re-renders its panel gives screen-reader users no signal that the results
  // changed — axe can't catch the missing announcement. A polite live region
  // narrates the new count + active filter on every category switch (pure +
  // unit-locked in src/shared/blog-visibility — the e2e covers the live wiring).
  const resultsLabel = blogResultsAnnouncement(posts.length, category);

  return (
    <section
      className="section relative overflow-hidden"
      data-theme-tools-surface={surfaceProps['data-theme-tools-surface']}
      data-theme-tools-pricing-model={surfaceProps['data-theme-tools-pricing-model']}
    >
      <div
        className="pointer-events-none absolute inset-0 -z-10 grid-pattern opacity-50"
        aria-hidden="true"
      />
      <div
        className="bcl-hero-glow pointer-events-none absolute -top-32 -right-32 -z-10 h-[420px] w-[420px] rounded-full bg-brand-accent/12 blur-3xl"
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-px bg-gradient-to-r from-transparent via-brand-accent/40 to-transparent"
        aria-hidden="true"
      />

      <div className="container-pad">
        <nav aria-label="Breadcrumb" className="mb-6 text-sm text-brand-mute" data-animate="fade-up">
          <a href={lp('/')} className="underline-hover">
            Home
          </a>
          <span className="mx-2">/</span>
          <span className="text-brand-ink">Blog</span>
        </nav>

        <div className="mb-12 max-w-3xl" data-animate="fade-up" data-delay="80">
          <p className="eyebrow mb-3">Field notes · Newark crew</p>
          <h1 className="text-4xl sm:text-6xl font-extrabold leading-[1.05]">
            Notes from the <span className="text-gradient">Newark crew.</span>
          </h1>
          <p className="mt-5 text-lg text-brand-mute">
            How we run jobs, why we run them this way, and what it earns the customer.{' '}
            <a href={lp('/services/power-washing')} className="text-brand-accent underline-hover">
              Power washing
            </a>
            ,{' '}
            <a href={lp('/services/hauling')} className="text-brand-accent underline-hover">
              hauling
            </a>
            ,{' '}
            <a href={lp('/services/lawn-care')} className="text-brand-accent underline-hover">
              lawn care
            </a>
            ,{' '}
            <a href={lp('/services/light-repairs')} className="text-brand-accent underline-hover">
              light repairs
            </a>{' '}
            — the actual craft.
          </p>
          <p className="mt-4 text-sm text-brand-mute">
            New? Start with the{' '}
            <a
              href={lp('/blog/fifty-dollar-hour-per-person-philosophy')}
              className="text-brand-accent underline-hover"
            >
              $50/hr philosophy post
            </a>
            , then jump to{' '}
            <a href={lp('/book')} className="text-brand-accent underline-hover">
              booking
            </a>
            ,
            <a href={lp('/#pricing')} className="text-brand-accent underline-hover ml-1">
              pricing
            </a>
            , or
            <a href={lp('/#faq')} className="text-brand-accent underline-hover ml-1">
              FAQ
            </a>
            .
          </p>
        </div>

        <div
          role="tablist"
          aria-label="Filter posts by category"
          className="mb-8 flex flex-wrap gap-2"
          data-animate="fade-up"
        >
          {CATEGORIES.map((c, idx) => {
            const active = c === category;
            return (
              <button
                key={c}
                id={`blog-tab-${c}`}
                type="button"
                role="tab"
                aria-selected={active}
                aria-controls="blog-posts-panel"
                onClick={() => setCategory(c)}
                {...catTabs(idx, active)}
                className={`rounded-full border px-4 py-1.5 text-sm font-mono transition-colors focus-visible:outline-2 focus-visible:outline-brand-accent focus-visible:outline-offset-2 active:scale-95 ${
                  active
                    ? 'border-brand-accent bg-brand-accent text-bg-primary font-bold shadow-[0_6px_18px_-4px_rgba(255,107,26,0.45)]'
                    : 'border-brand-line bg-bg-elevated text-brand-mute hover:border-brand-accent hover:text-brand-accent'
                }`}
              >
                {c === 'all' ? 'All posts' : c}
              </button>
            );
          })}
        </div>

        <p className="sr-only" role="status" aria-live="polite">
          {resultsLabel}
        </p>

        <ul
          id="blog-posts-panel"
          role="tabpanel"
          aria-labelledby={`blog-tab-${category}`}
          className="grid gap-6 md:grid-cols-2"
        >
          {posts.map((p) => {
            const hasAudio = Boolean(BLOG_AUDIO[p.slug]);
            return (
              <li key={p.slug} className="card-hover group flex flex-col justify-between">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="rounded-full border border-brand-accent/35 bg-brand-accent/10 px-2.5 py-0.5 font-mono text-[11px] uppercase tracking-widest text-brand-accent">
                      {p.category}
                    </span>
                    <span className="font-mono text-xs text-brand-mute">· {p.readMinutes}</span>
                    {hasAudio && (
                      <span className="ml-auto inline-flex items-center gap-1 rounded-full border border-brand-line bg-bg-primary/80 px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-brand-ink">
                        <span aria-hidden="true">🎙️</span> Audio
                      </span>
                    )}
                  </div>
                  <h2 className="mt-3.5 font-display text-2xl font-extrabold leading-tight">
                    <a
                      href={lp(`/blog/${p.slug}`)}
                      className="text-brand-ink underline-hover transition-colors group-hover:text-brand-accent"
                    >
                      {p.title}
                    </a>
                  </h2>
                  <p className="mt-3 text-brand-mute leading-relaxed">{p.excerpt}</p>
                  {p.tags && p.tags.length > 0 && (
                    <ul className="mt-4 flex flex-wrap gap-1.5" aria-label="Post tags">
                      {p.tags.slice(0, 3).map((tag) => (
                        <li
                          key={tag}
                          className="rounded-md border border-brand-line bg-bg-primary/60 px-2 py-0.5 font-mono text-[11px] text-brand-mute"
                        >
                          #{tag}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
                <div className="mt-6 flex items-center justify-between border-t border-brand-line pt-4 text-xs text-brand-mute">
                  <span>
                    {p.author} · {formatDate(p.date)}
                  </span>
                  <a
                    href={lp(`/blog/${p.slug}`)}
                    className="btn-arrow inline-flex items-center gap-1 font-mono font-semibold text-brand-accent underline-hover"
                  >
                    Read <span data-btn-arrow aria-hidden="true">→</span>
                  </a>
                </div>
              </li>
            );
          })}
        </ul>

        <section className="mt-20">
          <div className="max-w-2xl">
            <p className="eyebrow mb-2">Service hubs</p>
            <h2 className="font-display text-2xl sm:text-3xl font-extrabold">Browse by service</h2>
            <p className="mt-2 text-brand-mute">
              Every service hub has its own pricing table, gear list, FAQ, and city matrix —{' '}
              <a href={lp('/#pricing')} className="text-brand-accent underline-hover">
                flat $50/hr per person
              </a>{' '}
              across the board.
            </p>
          </div>
          <ul className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {SERVICES.map((s) => (
              <li
                key={s.slug}
                className="group overflow-hidden rounded-2xl border border-brand-line bg-bg-elevated transition-all duration-[333ms] hover:-translate-y-1 hover:border-brand-accent/60 hover:shadow-[0_18px_50px_-20px_rgba(255,107,26,0.45)]"
              >
                <a href={lp(`/services/${s.slug}`)} className="block">
                    <div className="relative aspect-[16/10] overflow-hidden bg-bg-primary">
                      <picture>
                        <source srcSet={serviceHeroImage(s).avif} type="image/avif" />
                        <source srcSet={serviceHeroImage(s).webp} type="image/webp" />
                        <img
                          src={serviceHeroImage(s).jpg}
                          alt={`${s.name} — Newark crew`}
                          loading="lazy"
                          decoding="async"
                          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                        />
                      </picture>
                      <div
                        className="absolute inset-0 bg-gradient-to-t from-bg-primary via-bg-primary/40 to-transparent"
                        aria-hidden
                      />
                      <span className="absolute left-3 top-3 rounded-full bg-bg-primary/80 px-2.5 py-1 font-mono text-[10px] uppercase tracking-widest text-brand-accent backdrop-blur-sm">
                        $50/hr
                      </span>
                    </div>
                    <div className="p-4">
                      <p className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
                        Service hub
                      </p>
                      <h3 className="mt-1.5 font-display text-base font-bold text-brand-ink group-hover:text-brand-accent">
                        {s.name}
                      </h3>
                      <p className="mt-1.5 text-xs leading-snug text-brand-mute">{s.ogTagline}</p>
                    </div>
                  </a>
                </li>
              ))}
          </ul>
        </section>

        <div className="mt-16 rail-card">
          <p className="eyebrow mb-2">Flat $50/hr per person</p>
          <h2 className="font-display text-2xl sm:text-3xl font-extrabold">
            Need a crew, not a blog post?
          </h2>
          <p className="mt-2 max-w-2xl text-brand-mute">
            Same flat{' '}
            <a href={lp('/#pricing')} className="text-brand-accent underline-hover">
              $50/hr per person
            </a>{' '}
            across{' '}
            <a href={lp('/c/newark')} className="text-brand-accent underline-hover">
              Newark
            </a>
            ,{' '}
            <a href={lp('/c/jersey-city')} className="text-brand-accent underline-hover">
              Jersey City
            </a>
            ,{' '}
            <a href={lp('/c/paterson')} className="text-brand-accent underline-hover">
              Paterson
            </a>
            , and every NJ + NYC city on the{' '}
            <a href={lp('/#coverage')} className="text-brand-accent underline-hover">
              coverage map
            </a>
            . Book online or call{' '}
            <a href={PHONE_TEL_HREF} className="text-brand-accent underline-hover">
              (855) 82LABOR
            </a>
            .
          </p>
          <div className="mt-5 flex flex-wrap gap-3">
            <a href={lp('/book')} className="btn-primary btn-arrow">
              Book a crew <span data-btn-arrow aria-hidden="true">→</span>
            </a>
            <a href={lp('/#contact')} className="btn-ghost">
              Custom quote
            </a>
            <a href={lp('/#testimonials')} className="btn-ghost">
              Read reviews
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
