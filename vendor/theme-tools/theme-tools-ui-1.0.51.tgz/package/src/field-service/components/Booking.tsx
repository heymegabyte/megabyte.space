import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { evaluateBuildingCoiReadiness } from '@theme.tools/scheduling/field-service-domain-advisors';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { bookingSubmitError } from '../submit-error.js';
import { useBookingPricing, computePricing } from '@theme.tools/billing/field-service/use-booking-pricing';
import { usePlacesSession } from '../use-places-session.js';
import { FUNNEL, track } from '../analytics.js';
import { UHAUL_TRUCKS, MAX_TRUCK_QTY, rentalById } from '@theme.tools/scheduling/field-service/rentals';
import type { TruckPick } from '@theme.tools/scheduling/field-service/rentals';
import { assessRentalRisk, rentalAcksSatisfied } from '@theme.tools/scheduling/field-service/rental-risk';
import type { AiQuoteStructured } from '@theme.tools/agent-ui/field-service/ai-quote-prompt';
import { availabilityOutcome } from '@theme.tools/scheduling/field-service/availability';
import { parseRebookPrefill } from '@theme.tools/crm/field-service/rebook-prefill';
import { normalizeToBookingTile, resolveServiceAlias } from '@theme.tools/seo-geo/field-service/service-slug-aliases';
import { initialMultiDates } from '@theme.tools/scheduling/field-service/booking-date-sync';
import { nyToday } from '@theme.tools/scheduling/field-service/ny-time';
import { fmtMoney } from '@theme.tools/billing/field-service/booking-pricing';
import { usd0, fairMarketRange } from '@theme.tools/billing/field-service/money';
import { confirmCtaLabel, effectivePayMode } from '@theme.tools/billing/field-service/pay-cta';
import { quotePriceChange } from '@theme.tools/billing/field-service/quote-price-change';
import {
  discountForPlan,
  isRecurringPlan,
  RECURRING_PLANS,
  recurringChargeCents,
  type RecurringPlan,
} from '@theme.tools/scheduling/field-service/recurring';
import {
  type Weekday,
  type SubFrequency,
  WEEKDAY_LETTERS,
  WEEKDAY_SHORT,
  FREQUENCY_LABELS,
  weekdayOf,
  isStartMismatch,
  firstServiceDate,
  planForWeekdays,
  summarizeWeekdays,
  subscriptionVisits,
  visitsPerPeriod,
  firstPeriodVisitCount,
  periodNoun,
  isDateBasedFrequency,
} from '@theme.tools/scheduling/field-service/recurring-schedule';
import { charCounterState, type CharCounterTone } from '@theme.tools/i18n-a11y/field-service/char-counter';
import { summarizeScope } from '@theme.tools/crm/field-service/scope-summary';
import {
  bookingIcsDataUri,
  bookingGoogleCalUrl,
  bookingIcsFilename,
  bookingIcsTitle,
} from '@theme.tools/scheduling/field-service/booking-ics';
import {
  comboboxOptionId,
  comboboxActiveDescendant,
  comboboxNextActiveIndex,
} from '@theme.tools/i18n-a11y/field-service/combobox-a11y';
import {
  depositSplit,
  paymentAuthorization,
  paymentTrustStrip,
} from '@theme.tools/billing/field-service/deposit-policy';
import { getDubId } from '../dub.js';
import {
  DRAFT_MAX_AGE_DAYS,
  draftIsStale,
  hasRestorableDraft,
  restoredDraftMessage,
} from '../booking-draft.js';
import { bundleBySlug, type Bundle } from '@theme.tools/billing/field-service/bundles';
import { isValidCouponFormat, normalizeCouponCode } from '@theme.tools/billing/field-service/coupons';
import { premiumReasonLabel } from '@theme.tools/billing/field-service/premium-reason';
import {
  isSunday,
  isAfterHoursSlot,
} from '@theme.tools/scheduling/field-service/after-hours';
import { CancellationPolicy } from './CancellationPolicy.js';
import { AddressMap } from './AddressMap.js';
import { SameDayPricingCard } from './SameDayPricingCard.js';
import { SurgeAwareDatePeek } from './booking/SurgeAwareDatePeek.js';
import { SuccessCheck } from './SuccessCheck.js';
import { PostBookingUpsell } from './booking/PostBookingUpsell.js';
import { SurgeExplainerModal } from './SurgeExplainerModal.js';
import { OneTapRebook } from './booking/OneTapRebook.js';
import { ContactLock } from './booking/ContactLock.js';
import { BnplToggle } from './booking/BnplToggle.js';
import { DepositPicker } from './booking/DepositPicker.js';
import { SmsConsentDisclosure } from './SmsConsentDisclosure.js';
import { TurnstileWidget } from './TurnstileWidget.js';
import { CustomerOnboardingVideo } from './customer/CustomerOnboardingVideo.js';
import { ApplePayGooglePayButtons } from './booking/ApplePayGooglePayButtons.js';
import { QuoteOptimizer } from './booking/QuoteOptimizer.js';
import { useFeatureFlag } from '../use-feature-flag.js';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import {
  billingMinimumNote,
  paymentReassuranceNote,
  bookingConfirmCopy,
  estimateCopy,
  recurringTotalLabel,
  surgeReasonLabel,
  serviceSectionLabels,
} from '@theme.tools/billing/field-service/estimate-copy';
import { bookingFormCopy, type ServiceTileId } from '@theme.tools/i18n-a11y/field-service/booking-form-copy';
import { parsePaymentReturn } from '@theme.tools/billing/field-service/payment-return';
import { PROHIBITED_ITEMS, PROHIBITED_ACK_LINE } from '@theme.tools/crm/field-service/prohibited-items';
import { useRovingRadio } from '../use-roving-radio.js';
import { PHONE_TEL_HREF, PHONE_SMS_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';

/**
 * Locale-aware internal href for the booking form. The form mounts on the
 * homepage AND every /c/:slug city page (incl. their /es + /pt mirrors), so its
 * internal SPA links (`/track/:id`, `/me`, `/quote`, `/terms`) must carry
 * the URL's locale prefix or a Spanish/Portuguese visitor who books from a
 * mirror page leaks onto the English route at the post-booking click. Reads the
 * locale at render (SSR → 'en'); same source as the chrome + city-page hrefs.
 */
function lpHref(path: string): string {
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  return localizedPath(locale, path);
}

interface Slot {
  startAt: string;
  localTime: string;
}

type Step = 'schedule' | 'details' | 'ai-review' | 'confirm' | 'success';
interface AiMsg {
  role: 'user' | 'assistant';
  content: string;
}

// Newark business day (NOT UTC) so the calendar's earliest day + the same-day
// rush highlight match the server charge — UTC rolls forward an evening early.
const TODAY_YMD = nyToday();
const MIN_DATE = TODAY_YMD;
const MAX_DATE = (() => {
  const d = new Date();
  d.setDate(d.getDate() + 60);
  return d.toISOString().slice(0, 10);
})();

const VALID_SERVICES = [
  'power-wash',
  'lawn',
  'haul',
  'repairs',
  'cleanout',
  'seasonal',
  'other',
] as const;
type Service = (typeof VALID_SERVICES)[number];

const MAX_CREW = 50;
type CrewSize = number;
const isValidCrew = (n: number) => Number.isInteger(n) && n >= 1 && n <= MAX_CREW;

/** Brand-token tones for the live scope char-counter — shared shape with RateCrew. */
const NOTES_COUNTER_TONE_CLASS: Record<CharCounterTone, string> = {
  ok: 'text-brand-mute',
  warn: 'text-amber-400',
  limit: 'text-red-300',
};

type PaymentMode = 'deposit' | 'full' | 'later';

// RecurringPlan + its discount figures live once in src/shared/recurring.ts
// (imported above). The /book form reads discountForPlan() at the estimate so
// its discount can never drift from /recurring or from the worker that charges.
// Multi-day mode auto-locks to 'custom'.

interface ServiceTile {
  id: Service;
  label: string;
  sub: string;
  image?: string;
}
const SERVICE_TILES: ServiceTile[] = [
  { id: 'power-wash', label: 'Power wash', sub: 'Driveways, decks, siding', image: '/services/power-washing.webp' },
  { id: 'lawn', label: 'Lawn / yard', sub: 'Mow, edge, leaves', image: '/services/lawn-care.webp' },
  { id: 'haul', label: 'Hauling', sub: 'Junk, debris, donations', image: '/services/hauling.webp' },
  { id: 'repairs', label: 'Light repairs', sub: 'Fences, drywall, fixtures', image: '/services/light-repairs.webp' },
  { id: 'cleanout', label: 'Cleanout', sub: 'Move-out, estate, garage', image: '/services/cleanout.webp' },
  { id: 'seasonal', label: 'Seasonal', sub: 'Gutters, snow, leaves', image: '/services/seasonal.webp' },
];

const REFERRAL_DISCOUNT = 25;

function isToday(dateStr: string): boolean {
  return Boolean(dateStr) && dateStr === TODAY_YMD;
}

const DRAFT_KEY = 'bcl-booking-draft-v1';
const IDEMPOTENCY_KEY = 'bcl-booking-idempotency-v1';

function ymdLocal(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${dd}`;
}

function startOfMonth(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), 1);
}

interface CalendarProps {
  value: string;
  onChange: (s: string) => void;
  minDate: string;
  maxDate: string;
  multiSelect?: boolean;
  selectedDates?: string[];
  onToggleDate?: (s: string) => void;
  recurringPreview?: 'daily' | 'weekly' | 'biweekly' | 'monthly' | null;
  /** Exact subscription visit dates (YYYY-MM-DD) — shaded as "contract days". */
  contractDates?: readonly string[];
}

function Calendar({
  value,
  onChange,
  minDate,
  maxDate,
  multiSelect = false,
  selectedDates = [],
  onToggleDate,
  recurringPreview = null,
  contractDates = [],
}: CalendarProps) {
  const contractSet = new Set(contractDates);
  const initialMonth = (() => {
    const seed = value || minDate;
    return startOfMonth(new Date(seed + 'T12:00:00'));
  })();
  const [month, setMonth] = useState<Date>(initialMonth);
  const today = nyToday();
  const monthLabel = month.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  const startSunday = new Date(month);
  startSunday.setDate(month.getDate() - month.getDay());

  const selectedSet = new Set(selectedDates);
  const anchorDate = value || selectedDates[0] || '';
  const anchorTime = anchorDate ? new Date(anchorDate + 'T12:00:00').getTime() : 0;
  const DAY_MS = 86400000;

  function isPreviewMatch(ymd: string, dt: Date): boolean {
    if (!recurringPreview || !anchorDate) return false;
    if (ymd === anchorDate) return false;
    const cellTime = new Date(ymd + 'T12:00:00').getTime();
    if (cellTime <= anchorTime) return false;
    const diffDays = Math.round((cellTime - anchorTime) / DAY_MS);
    if (recurringPreview === 'daily')
      return dt.getDay() !== 0 && dt.getDay() !== 6 && diffDays >= 1;
    if (recurringPreview === 'weekly') return diffDays % 7 === 0;
    if (recurringPreview === 'biweekly') return diffDays % 14 === 0;
    if (recurringPreview === 'monthly') {
      const anchorDay = new Date(anchorDate + 'T12:00:00').getDate();
      return dt.getDate() === anchorDay;
    }
    return false;
  }

  const cells = Array.from({ length: 42 }, (_, i) => {
    const d = new Date(startSunday);
    d.setDate(startSunday.getDate() + i);
    const ymd = ymdLocal(d);
    const inMonth = d.getMonth() === month.getMonth();
    const sun = d.getDay() === 0;
    const disabled = ymd < minDate || ymd > maxDate;
    const isAnchor = multiSelect ? selectedSet.has(ymd) : ymd === value;
    // Contract days: weekdays the subscription crew comes. The start-date cell is
    // a "mismatch" when it isn't one of those weekdays (first visit will wait).
    // Contract days = the exact subscription visit dates (frequency-aware, already
    // capped by END AFTER + starting at/after the start date). The start-date cell
    // that isn't itself a visit is a mismatch (first visit waits).
    const isContract = contractSet.has(ymd);
    const isMismatchStart = isAnchor && contractSet.size > 0 && !contractSet.has(ymd);
    return {
      date: d,
      key: ymd,
      inMonth,
      isSunday: sun,
      disabled,
      isSelected: isAnchor,
      isToday: ymd === today,
      isSameDay: ymd === today && !disabled,
      isPreview: !isAnchor && isPreviewMatch(ymd, d),
      isContract: !isAnchor && isContract,
      isMismatchStart,
    };
  });

  const prevMonth = startOfMonth(new Date(month.getFullYear(), month.getMonth() - 1, 1));
  const nextMonth = startOfMonth(new Date(month.getFullYear(), month.getMonth() + 1, 1));
  const minMonth = startOfMonth(new Date(minDate + 'T12:00:00'));
  const maxMonth = startOfMonth(new Date(maxDate + 'T12:00:00'));
  const prevEnabled = prevMonth >= minMonth;
  const nextEnabled = nextMonth <= maxMonth;

  return (
    <div className="rounded-lg border border-brand-line bg-bg-primary p-3">
      <div className="flex items-center justify-between mb-2">
        <button
          type="button"
          onClick={() => prevEnabled && setMonth(prevMonth)}
          disabled={!prevEnabled}
          aria-label="Previous month"
          className="rounded-md border border-brand-line px-2 py-1 text-sm text-brand-mute hover:border-brand-accent hover:text-brand-accent disabled:opacity-30 disabled:cursor-not-allowed"
        >
          ←
        </button>
        <div className="font-display text-sm font-bold text-brand-ink">{monthLabel}</div>
        <button
          type="button"
          onClick={() => nextEnabled && setMonth(nextMonth)}
          disabled={!nextEnabled}
          aria-label="Next month"
          className="rounded-md border border-brand-line px-2 py-1 text-sm text-brand-mute hover:border-brand-accent hover:text-brand-accent disabled:opacity-30 disabled:cursor-not-allowed"
        >
          →
        </button>
      </div>
      <div className="grid grid-cols-7 gap-0.5 text-center text-[10px] font-mono uppercase tracking-wider text-brand-mute mb-1">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
          <div key={d}>{d.slice(0, 1)}</div>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-0.5">
        {cells.map((cell) => (
          <button
            key={cell.key}
            type="button"
            disabled={cell.disabled}
            onClick={() => {
              if (multiSelect && onToggleDate) {
                onToggleDate(cell.key);
              } else {
                onChange(cell.key);
              }
            }}
            aria-label={cell.date.toDateString()}
            aria-pressed={cell.isSelected}
            className={`relative h-8 rounded-md text-xs font-mono transition-colors flex items-center justify-center ${!cell.inMonth ? 'opacity-80 ' : ''}${
              cell.disabled
                ? 'text-brand-mute cursor-not-allowed'
                : cell.isMismatchStart
                  ? 'bg-amber-400/80 text-bg-primary font-bold ring-2 ring-amber-400/50'
                  : cell.isSelected
                    ? 'bg-brand-accent text-bg-primary font-bold ring-2 ring-brand-accent/40'
                    : cell.isPreview
                      ? 'bg-brand-accent/15 text-brand-accent hover:bg-brand-accent/25'
                      : cell.isContract
                        ? 'bg-brand-accent/10 text-brand-accent ring-1 ring-inset ring-brand-accent/30 hover:bg-brand-accent/20'
                        : cell.isToday
                          ? 'border border-brand-accent text-brand-accent hover:bg-brand-accent/10'
                          : cell.isSunday
                            ? 'text-amber-300/90 hover:bg-amber-400/10 hover:text-amber-200'
                            : cell.inMonth
                              ? 'text-brand-ink hover:bg-brand-accent/10 hover:text-brand-accent'
                              : 'text-brand-mute hover:bg-brand-accent/5 hover:text-brand-accent'
            }`}
            title={
              cell.isMismatchStart
                ? 'Start date isn’t a selected weekday — the first visit waits for the next one'
                : cell.isContract
                  ? 'Contract day — your crew comes this weekday'
                  : cell.isPreview
                    ? 'Preview — toggle to add this day to your booking'
                    : cell.isSunday && !cell.disabled
                      ? 'Sunday — premium hours (+ $15/hr/person)'
                      : cell.isSameDay
                        ? 'Today — same-day priority (+ $75)'
                        : undefined
            }
          >
            {cell.date.getDate()}
            {cell.isSunday && !cell.disabled && !cell.isSelected && (
              <span
                aria-hidden
                className="absolute right-1 top-1 h-1 w-1 rounded-full bg-amber-400"
              />
            )}
            {cell.isSameDay && !cell.isSelected && (
              <span
                aria-hidden
                className="absolute left-1 top-1 h-1 w-1 rounded-full bg-brand-accent"
              />
            )}
          </button>
        ))}
      </div>
      <p className="mt-2 text-[11px] text-brand-mute text-center">
        Same-day + Sundays open with a premium. Book up to 60 days out.
      </p>
      <div className="mt-2 flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-[10px] text-brand-mute">
        <span className="inline-flex items-center gap-1"><span aria-hidden className="h-2.5 w-2.5 rounded-sm bg-brand-accent" /> Selected</span>
        {contractDates.length > 0 && (
          <>
            <span className="inline-flex items-center gap-1"><span aria-hidden className="h-2.5 w-2.5 rounded-sm bg-brand-accent/20 ring-1 ring-inset ring-brand-accent/40" /> Visit day</span>
            <span className="inline-flex items-center gap-1"><span aria-hidden className="h-2.5 w-2.5 rounded-sm bg-amber-400/80" /> Start waits</span>
          </>
        )}
        <span className="inline-flex items-center gap-1"><span aria-hidden className="h-2.5 w-2.5 rounded-sm border border-brand-accent" /> Today</span>
        <span className="inline-flex items-center gap-1"><span aria-hidden className="h-1.5 w-1.5 rounded-full bg-amber-400" /> Sun premium</span>
      </div>
    </div>
  );
}

function maskPhone(raw: string): string {
  let all = raw.replace(/\D/g, '');
  /*
   * Drop a leading US country code so "+1 201-998-1595" (OSM / pasted E.164)
   * masks to (201) 998-1595, not (120) 199-8159. US area codes never start
   * with 1, so an 11-digit value beginning with 1 is always country-code + NANP.
   */
  if (all.length === 11 && all.startsWith('1')) all = all.slice(1);
  const digits = all.slice(0, 10);
  if (digits.length === 0) return '';
  if (digits.length < 4) return `(${digits}`;
  if (digits.length < 7) return `(${digits.slice(0, 3)}) ${digits.slice(3)}`;
  return `(${digits.slice(0, 3)}) ${digits.slice(3, 6)}-${digits.slice(6)}`;
}

/**
 * Humanize the list of fields a business pick auto-filled into a sentence
 * fragment, e.g. ['address','phone','email'] → "Address, phone & email".
 */
function formatFilledFields(fields: string[]): string {
  const labels = fields.map((f, i) => (i === 0 ? f.charAt(0).toUpperCase() + f.slice(1) : f));
  if (labels.length === 1) return labels[0] ?? '';
  if (labels.length === 2) return `${labels[0]} & ${labels[1]}`;
  return `${labels.slice(0, -1).join(', ')} & ${labels[labels.length - 1]}`;
}

interface Draft {
  hours?: number;
  crew?: CrewSize;
  date?: string;
  selectedSlot?: Slot | null;
  firstName?: string;
  lastName?: string;
  name?: string;
  email?: string;
  phone?: string;
  businessName?: string;
  address?: string;
  city?: string;
  zip?: string;
  placeId?: string;
  notes?: string;
  smsOptIn?: boolean;
  emailOptIn?: boolean;
  marketingSmsOptIn?: boolean;
  acknowledged?: boolean;
  source?: string;
  paymentMode?: PaymentMode;
  truckPicks?: TruckPick[];
  services?: Service[];
  recurringPlan?: RecurringPlan;
  referralCode?: string;
  extras?: string[];
  multiDayMode?: boolean;
  multiDates?: string[];
  multiPerHours?: Record<string, number>;
  multiPerCrew?: Record<string, number>;
  multiPerTime?: Record<string, string>;
  multiPerTruck?: Record<string, string>;
  /** Wall-clock ms of the last write — drives the stale-draft nudge. */
  savedAt?: number;
  recurringEndAfter?: number;
  recurringAutoPause?: boolean;
}

const PER_DAY_DEFAULT_HOURS = 4;
const PER_DAY_DEFAULT_CREW = 2;

interface PlaceSuggestion {
  placeId: string;
  primary: string;
  secondary: string;
}

interface PlaceDetailsResult {
  ok: boolean;
  message?: string;
  place?: {
    id: string;
    formatted: string;
    street: string;
    city: string;
    state: string;
    zip: string;
    lat?: number;
    lng?: number;
    name?: string;
    phone?: string;
    email?: string;
    website?: string;
    isBusiness?: boolean;
  };
}

function readDraft(): Draft {
  try {
    const raw = localStorage.getItem(DRAFT_KEY);
    return raw ? (JSON.parse(raw) as Draft) : {};
  } catch {
    return {};
  }
}

function saveDraft(d: Draft) {
  try {
    localStorage.setItem(DRAFT_KEY, JSON.stringify({ ...d, savedAt: Date.now() }));
  } catch {
    /* quota / private */
  }
}

function clearDraft() {
  try {
    localStorage.removeItem(DRAFT_KEY);
  } catch {
    /* noop */
  }
}

function getOrCreateIdempotencyKey(): string {
  try {
    const k = localStorage.getItem(IDEMPOTENCY_KEY);
    if (k) return k;
    const fresh = crypto.randomUUID();
    localStorage.setItem(IDEMPOTENCY_KEY, fresh);
    return fresh;
  } catch {
    return crypto.randomUUID();
  }
}

function rotateIdempotencyKey() {
  try {
    localStorage.removeItem(IDEMPOTENCY_KEY);
  } catch {
    /* noop */
  }
}

function isCrewSize(n: unknown): n is CrewSize {
  return typeof n === 'number' && isValidCrew(n);
}

function sanitizeTruckPicks(raw: unknown): TruckPick[] {
  if (!Array.isArray(raw)) return [];
  const seen = new Map<string, number>();
  for (const entry of raw) {
    if (!entry || typeof entry !== 'object') continue;
    const e = entry as { id?: unknown; qty?: unknown };
    if (typeof e.id !== 'string') continue;
    if (!rentalById(e.id)) continue;
    const qty = Math.max(1, Math.min(MAX_TRUCK_QTY, Math.round(Number(e.qty) || 1)));
    seen.set(e.id, Math.min(MAX_TRUCK_QTY, (seen.get(e.id) ?? 0) + qty));
  }
  return Array.from(seen, ([id, qty]) => ({ id, qty }));
}

interface QuotePrefillData {
  hours?: number;
  crew?: CrewSize;
  notes?: string;
  zip?: string;
  city?: string;
  firstName?: string;
  lastName?: string;
  name?: string;
  email?: string;
  phone?: string;
  businessName?: string;
  address?: string;
  placeId?: string;
  preferredDate?: string;
  preferredTime?: string;
  startAt?: string;
  paymentMode?: PaymentMode;
  truckPicks?: TruckPick[];
  services?: Service[];
  recurringPlan?: RecurringPlan;
  referralCode?: string;
  extras?: string[];
  /** Set when hydrating from a shared /quote/:id link — lands the recipient on
   *  the Confirm step (#4) with every earlier step pre-filled + back-navigable. */
  fromQuote?: boolean;
  /** The exact price the saved quote quoted, carried so the Confirm step can
   *  disclose when the live recompute (surge/same-day) diverges from it. */
  quotedTotalCents?: number;
}

function sanitizeServices(raw: unknown): Service[] {
  if (!Array.isArray(raw)) return [];
  const out: Service[] = [];
  for (const s of raw) {
    if (typeof s === 'string') {
      const normalized = (normalizeToBookingTile(s) ?? s) as Service;
      if (
        (VALID_SERVICES as readonly string[]).includes(normalized) &&
        !out.includes(normalized)
      ) {
        out.push(normalized);
      }
    }
  }
  return out;
}

interface ExtraOption {
  id: string;
  label: string;
  flatCents?: number;
  defaultOn?: boolean;
}

const EXTRAS: ExtraOption[] = [];

function sanitizeExtras(_raw: unknown): string[] {
  return [];
}

function readQuotePrefill(): QuotePrefillData {
  if (typeof window === 'undefined') return {};
  // URL-param prefill — the one-tap-rebook endpoint, the booking-abandon-recovery
  // 1-click link, and the public /track "Book this crew again" CTA all land on
  // `/book?service=&crew=&hours=&address=` (see src/shared/rebook-prefill.ts).
  // The form historically read ONLY `service`; crew/hours/address were dropped,
  // so a returning customer got the default scope instead of their prior one.
  // sessionStorage prefill (the AI quote flow) is more specific, so it overlays
  // (wins) on top of the URL base where both set the same field.
  const fromUrl = parseRebookPrefill(window.location.search);
  const urlBase: QuotePrefillData = {};
  if (typeof fromUrl.crew === 'number' && isCrewSize(fromUrl.crew)) urlBase.crew = fromUrl.crew;
  if (typeof fromUrl.hours === 'number') urlBase.hours = fromUrl.hours;
  if (fromUrl.address) urlBase.address = fromUrl.address;
  if (fromUrl.date) urlBase.preferredDate = fromUrl.date;
  if (fromUrl.time) urlBase.preferredTime = fromUrl.time;
  if (fromUrl.notes) urlBase.notes = fromUrl.notes;
  try {
    const raw = sessionStorage.getItem('bcl-quote-prefill');
    if (!raw) return urlBase;
    sessionStorage.removeItem('bcl-quote-prefill');
    const parsed = JSON.parse(raw) as Record<string, unknown>;
    const out: QuotePrefillData = {};
    if (typeof parsed.hours === 'number' && parsed.hours > 0 && parsed.hours <= 12)
      out.hours = parsed.hours;
    if (isCrewSize(parsed.crew)) out.crew = parsed.crew as CrewSize;
    if (typeof parsed.notes === 'string') out.notes = parsed.notes;
    if (typeof parsed.zip === 'string') out.zip = parsed.zip;
    if (typeof parsed.city === 'string') out.city = parsed.city;
    if (typeof parsed.firstName === 'string') out.firstName = parsed.firstName;
    if (typeof parsed.lastName === 'string') out.lastName = parsed.lastName;
    if (typeof parsed.name === 'string') out.name = parsed.name;
    if (typeof parsed.email === 'string') out.email = parsed.email;
    if (typeof parsed.phone === 'string') out.phone = parsed.phone;
    if (typeof parsed.businessName === 'string') out.businessName = parsed.businessName;
    if (typeof parsed.address === 'string') out.address = parsed.address;
    if (typeof parsed.placeId === 'string') out.placeId = parsed.placeId;
    if (typeof parsed.preferredDate === 'string') out.preferredDate = parsed.preferredDate;
    if (typeof parsed.preferredTime === 'string') out.preferredTime = parsed.preferredTime;
    if (typeof parsed.startAt === 'string') out.startAt = parsed.startAt;
    if (
      parsed.paymentMode === 'deposit' ||
      parsed.paymentMode === 'full' ||
      parsed.paymentMode === 'later'
    ) {
      out.paymentMode = parsed.paymentMode;
    }
    const rentals = parsed.rentals as { trucks?: unknown; truck?: unknown } | null | undefined;
    if (rentals && typeof rentals === 'object') {
      if (Array.isArray(rentals.trucks)) {
        out.truckPicks = sanitizeTruckPicks(rentals.trucks);
      } else if (typeof rentals.truck === 'string') {
        out.truckPicks = sanitizeTruckPicks([{ id: rentals.truck, qty: 1 }]);
      }
    }
    if (Array.isArray(parsed.services)) out.services = sanitizeServices(parsed.services);
    if (isRecurringPlan(parsed.recurringPlan)) out.recurringPlan = parsed.recurringPlan;
    if (typeof parsed.referralCode === 'string')
      out.referralCode = parsed.referralCode.slice(0, 16).toUpperCase();
    if (Array.isArray(parsed.extras)) out.extras = sanitizeExtras(parsed.extras);
    if (parsed.fromQuote === true) out.fromQuote = true;
    if (
      typeof parsed.quotedTotalCents === 'number' &&
      Number.isFinite(parsed.quotedTotalCents) &&
      parsed.quotedTotalCents > 0
    ) {
      out.quotedTotalCents = parsed.quotedTotalCents;
    }
    return { ...urlBase, ...out };
  } catch {
    return urlBase;
  }
}

export function Booking() {
  // §book-standalone-meta (2026-05-25) — when this component is mounted on
  // the dedicated /book route (vs the homepage #book section), set a
  // bookmark-friendly title + meta description + canonical so the URL is
  // shareable and rankable as its own page. The homepage mount inherits
  // the homepage title.
  useEffect(() => {
    if (typeof window === 'undefined') return;
    // fire-130: match /book across locales (stripLocalePrefix) — the old `pathname !== '/book'`
    // guard SKIPPED /es/book + /pt/book, leaving es/pt customers with the English shell <title>/
    // meta even though the form body is localized. Set the LOCALIZED title + description + a
    // self-referential locale canonical (en → /book exactly as before).
    const { locale, path } = stripLocalePrefix(window.location.pathname);
    if (path !== '/book' && path !== '/book/') return;
    const copy = bookingFormCopy(locale);
    document.title = copy.metaTitle;
    const meta = document.querySelector('meta[name="description"]');
    if (meta) meta.setAttribute('content', copy.metaDescription);
    const canonical = document.querySelector('link[rel="canonical"]');
    if (canonical) canonical.setAttribute('href', `https://bricklabor.com${localizedPath(locale, '/book')}`);
  }, []);

  const draft = useRef<Draft>(typeof window !== 'undefined' ? readDraft() : {});
  const quotePrefill = useRef(readQuotePrefill());
  const params =
    typeof window !== 'undefined'
      ? new URLSearchParams(window.location.search)
      : new URLSearchParams();
  const rawServiceParam = params.get('service');
  const resolvedPrefillService = resolveServiceAlias(rawServiceParam);
  const prefilledService = (resolvedPrefillService?.bookingTile ??
    (rawServiceParam && (VALID_SERVICES as readonly string[]).includes(rawServiceParam)
      ? (rawServiceParam as Service)
      : null)) as Service | null;
  const utmSource =
    params.get('utm_source') || params.get('source') || draft.current.source || 'web';

  // Square redirects the customer back to `/book?booking=<id>&status=paid`
  // after checkout. Detect that ONCE at render so the success screen paints on
  // first frame — never a flash of the empty form to someone who just paid.
  const paymentReturn = useRef(
    typeof window !== 'undefined' ? parsePaymentReturn(window.location.search) : undefined,
  );

  const [step, setStep] = useState<Step>(() => {
    if (paymentReturn.current) return 'success';
    // A shared quote link (/quote/:id → prefill) lands the recipient straight on
    // the Confirm step (#4): the gorgeous full-scope summary + 1-click pay, with
    // every earlier step (#1-#3) pre-filled + back-navigable via the step nav.
    // Falls back to "Your info" for older prefills that predate the marker.
    const q = quotePrefill.current;
    if (q.fromQuote) return 'confirm';
    if (q.name && q.email && q.preferredDate) return 'details';
    return 'schedule';
  });
  // First-time customers get a short welcome walkthrough on the confirmation
  // screen (returning customers have already seen it). Pure client one-shot —
  // no backend; the `<VideoPlayer>` inside still records watch % server-side.
  const [showWelcome] = useState<boolean>(() => {
    try {
      return !localStorage.getItem('bcl_welcome_seen');
    } catch {
      return false;
    }
  });
  // Restored-draft affordance: the form silently rehydrates a saved draft into the
  // inputs above. Tell the returning visitor, flag a stale (possibly past-dated)
  // draft, and give a one-click "Start fresh" reset.
  const [showRestoredDraft, setShowRestoredDraft] = useState(
    () => !paymentReturn.current && hasRestorableDraft(draft.current),
  );
  const restoredDraftStale = useRef(
    typeof window !== 'undefined'
      ? draftIsStale(draft.current, Date.now(), DRAFT_MAX_AGE_DAYS)
      : false,
  );
  // §magic-link prefill — set true once a signed /book?ml=<token> link has been
  // verified server-side and its params hydrated into the form (banner below).
  const [magicPrefilled, setMagicPrefilled] = useState(false);
  const startFresh = () => {
    clearDraft();
    rotateIdempotencyKey();
    try {
      track('booking_draft_start_fresh', {});
    } catch {
      /* analytics best-effort */
    }
    if (typeof window !== 'undefined') window.location.reload();
  };
  const [bookingId, setBookingId] = useState<string>(
    () => paymentReturn.current?.bookingId ?? '',
  );
  const [bookingIds, setBookingIds] = useState<string[]>([]);
  const [hours, setHours] = useState(quotePrefill.current.hours ?? draft.current.hours ?? 2);
  const [crew, setCrew] = useState<CrewSize>(
    quotePrefill.current.crew ?? (isCrewSize(draft.current.crew) ? draft.current.crew : 1),
  );
  // The scalar active date the form opens with (prefill wins over draft, like every
  // other prefilled field). Shared with the multiDates seed below so the one-time
  // calendar highlights this exact day — date ↔ multiDates must move together.
  const initialSingleDate = quotePrefill.current.preferredDate ?? draft.current.date ?? '';
  const [date, setDate] = useState(initialSingleDate);
  // "Why this price?" surge transparency modal (flag-gated surge_explainer_modal).
  // Opened from the SameDayPricingCard's "Why?" affordance — no sticker shock.
  const [surgeWhyOpen, setSurgeWhyOpen] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState<Slot | null>(
    quotePrefill.current.startAt && quotePrefill.current.preferredTime
      ? { startAt: quotePrefill.current.startAt, localTime: quotePrefill.current.preferredTime }
      : (draft.current.selectedSlot ?? null),
  );
  const [slots, setSlots] = useState<Slot[]>([]);
  const [slotsLoading, setSlotsLoading] = useState(false);
  const [slotsError, setSlotsError] = useState('');
  const [multiDayMode, setMultiDayMode] = useState<boolean>(draft.current.multiDayMode ?? false);
  // Seed the one-time calendar's selection from the active date so a prefilled /
  // draft-restored day is highlighted (and clears the multiDates>=1 submit gate).
  // A real multi-day draft set still wins. See ./booking-date-sync.
  const [multiDates, setMultiDates] = useState<string[]>(
    initialMultiDates(initialSingleDate, draft.current.multiDates),
  );
  const [multiPerHours, setMultiPerHours] = useState<Record<string, number>>(() => {
    const raw = draft.current.multiPerHours;
    if (!raw || typeof raw !== 'object') return {};
    const out: Record<string, number> = {};
    for (const [k, v] of Object.entries(raw)) {
      if (typeof k === 'string' && typeof v === 'number' && v >= 1 && v <= 12)
        out[k] = Math.round(v);
    }
    return out;
  });
  const [multiPerCrew, setMultiPerCrew] = useState<Record<string, number>>(() => {
    const raw = draft.current.multiPerCrew;
    if (!raw || typeof raw !== 'object') return {};
    const out: Record<string, number> = {};
    for (const [k, v] of Object.entries(raw)) {
      if (typeof k === 'string' && typeof v === 'number' && v >= 1 && v <= MAX_CREW)
        out[k] = Math.round(v);
    }
    return out;
  });

  // Per-day start times for multi-day mode. Key = ISO date string, value = time string.
  // If only the first day's time is set, subsequent days inherit it (same start time).
  const [multiPerTime, setMultiPerTime] = useState<Record<string, string>>(() => {
    const raw = draft.current.multiPerTime;
    if (!raw || typeof raw !== 'object') return {};
    const out: Record<string, string> = {};
    for (const [k, v] of Object.entries(raw)) {
      if (typeof k === 'string' && typeof v === 'string' && v) out[k] = v;
    }
    return out;
  });

  // Per-day U-Haul selection for multi-day mode. Key = ISO date, value = truck id (or '' for none).
  const [multiPerTruck, setMultiPerTruck] = useState<Record<string, string>>(() => {
    const raw = draft.current.multiPerTruck;
    if (!raw || typeof raw !== 'object') return {};
    const out: Record<string, string> = {};
    for (const [k, v] of Object.entries(raw)) {
      if (typeof k === 'string' && typeof v === 'string') out[k] = v;
    }
    return out;
  });

  // Select a SINGLE booking date everywhere consistently. The one-time calendar highlights
  // `multiDates` (multiSelect mode), NOT `date`, so every date-switch path must set BOTH +
  // clear the now-stale slot + seed that day's per-day defaults. Centralizing the bundle
  // here means a new date-switch caller cannot re-introduce the SWITCH-TOMORROW-CALENDAR-SYNC
  // desync (fires 16-18). Callers keep their own analytics `track()`. The prefill paths are
  // now covered too: INIT seeds multiDates via ./booking-date-sync `initialMultiDates`, and the
  // async magic-link effect routes through this helper (fire-29) — no unrouted single-date path.
  const selectSingleDate = (iso: string): void => {
    setDate(iso);
    setSelectedSlot(null);
    setMultiDates([iso]);
    setMultiPerHours((prev) =>
      prev[iso] !== undefined ? prev : { ...prev, [iso]: PER_DAY_DEFAULT_HOURS },
    );
    setMultiPerCrew((prev) =>
      prev[iso] !== undefined ? prev : { ...prev, [iso]: PER_DAY_DEFAULT_CREW },
    );
  };

  const initialName = quotePrefill.current.name ?? draft.current.name ?? '';
  const initialNameParts = initialName.trim().split(/\s+/);
  const [firstName, setFirstName] = useState(
    quotePrefill.current.firstName ?? draft.current.firstName ?? initialNameParts[0] ?? '',
  );
  const [lastName, setLastName] = useState(
    quotePrefill.current.lastName ??
      draft.current.lastName ??
      (initialNameParts.length > 1 ? initialNameParts.slice(1).join(' ') : ''),
  );
  const name = [firstName.trim(), lastName.trim()].filter(Boolean).join(' ');
  const [email, setEmail] = useState(quotePrefill.current.email ?? draft.current.email ?? '');
  const [phone, setPhone] = useState(quotePrefill.current.phone ?? draft.current.phone ?? '');
  const [businessName, setBusinessName] = useState(
    quotePrefill.current.businessName ?? draft.current.businessName ?? '',
  );
  const [address, setAddress] = useState(
    quotePrefill.current.address ?? draft.current.address ?? '',
  );
  const [city, setCity] = useState(quotePrefill.current.city ?? draft.current.city ?? '');
  const [zip, setZip] = useState(quotePrefill.current.zip ?? draft.current.zip ?? '');
  const [placeId, setPlaceId] = useState(
    quotePrefill.current.placeId ?? draft.current.placeId ?? '',
  );
  const [addressQuery, setAddressQuery] = useState(() => {
    const qp = quotePrefill.current;
    if (qp.address || qp.city || qp.zip)
      return [qp.address, qp.city, qp.zip].filter(Boolean).join(', ');
    const d = draft.current;
    return [d.address, d.city, d.zip].filter(Boolean).join(', ');
  });
  const [addressSuggestions, setAddressSuggestions] = useState<PlaceSuggestion[]>([]);
  const [addressLoading, setAddressLoading] = useState(false);
  const [addressError, setAddressError] = useState('');
  const [autocompleteDisabled, setAutocompleteDisabled] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [addressFocused, setAddressFocused] = useState(false);
  const [activeSuggestion, setActiveSuggestion] = useState(-1);
  const { ensure: ensureSession, rotate: rotatePlacesSession } = usePlacesSession();

  const [businessSuggestions, setBusinessSuggestions] = useState<PlaceSuggestion[]>([]);
  const [businessLoading, setBusinessLoading] = useState(false);
  const [businessError, setBusinessError] = useState('');
  const [showBusinessSuggestions, setShowBusinessSuggestions] = useState(false);
  const [businessFocused, setBusinessFocused] = useState(false);
  const [activeBusinessSuggestion, setActiveBusinessSuggestion] = useState(-1);
  // Which contact fields the last business pick auto-filled — drives the
  // "prefilled from the business listing" confirmation hint.
  const [businessFilled, setBusinessFilled] = useState<string[]>([]);
  const businessSelectedRef = useRef('');
  const { ensure: ensureBusinessSession, rotate: rotateBusinessSession } = usePlacesSession();
  const [notes, setNotes] = useState(() => {
    if (quotePrefill.current.notes) return quotePrefill.current.notes;
    if (draft.current.notes) return draft.current.notes;
    if (resolvedPrefillService?.defaultNote) return resolvedPrefillService.defaultNote;
    if (prefilledService && VALID_SERVICES.includes(prefilledService)) {
      const map: Record<Service, string> = {
        'power-wash': 'Power washing — let us know what surfaces.',
        lawn: 'Lawn / yard care — what needs doing?',
        haul: 'Hauling — what are we taking out?',
        repairs: 'Light repairs — describe what broke.',
        cleanout: 'Move-out / property cleanout — what rooms?',
        seasonal: 'Seasonal — leaves, gutters, snow, etc.',
        other: '',
      };
      return map[prefilledService] || '';
    }
    return '';
  });
  const [smsOptIn, setSmsOptIn] = useState(draft.current.smsOptIn ?? true);
  const [emailOptIn, setEmailOptIn] = useState(draft.current.emailOptIn ?? true);
  // Marketing SMS = seasonal/quarterly nudges. TCPA-separate from smsOptIn —
  // default OFF, customer must affirmatively check the box.
  const [marketingSmsOptIn, setMarketingSmsOptIn] = useState(
    draft.current.marketingSmsOptIn ?? false,
  );
  const [acknowledged, setAcknowledged] = useState(draft.current.acknowledged ?? false);
  const [paymentMode, setPaymentMode] = useState<PaymentMode>(
    quotePrefill.current.paymentMode ?? draft.current.paymentMode ?? 'deposit',
  );
  const [truckPicks, setTruckPicks] = useState<TruckPick[]>(
    quotePrefill.current.truckPicks ?? draft.current.truckPicks ?? [],
  );
  // U-Haul truck pictures stay hidden behind an "Add U-Haul" button until the
  // customer opts in — the rental is a minority add-on, so the default view is a
  // single compact CTA, not a wall of truck photos. Auto-open if a truck was
  // prefilled (rebook/quote link) so the existing pick is visible.
  const [showUhaul, setShowUhaul] = useState<boolean>(
    (quotePrefill.current.truckPicks ?? draft.current.truckPicks ?? []).length > 0,
  );
  // Inline "edit the schedule details" popover on the subscription visit chart —
  // lets the customer tweak workers/hours/start-time without leaving the schedule.
  const [scheduleEditOpen, setScheduleEditOpen] = useState(false);
  // ARIA roving-tabindex keyboard contract for the two custom money-path
  // radiogroups (axe-blind interaction gap — see use-roving-radio). Payment order
  // is deposit/full/later; truck index 0 = "No truck", 1..N = UHAUL_TRUCKS.
  const paymentRadio = useRovingRadio(3, (i) =>
    setPaymentMode((['deposit', 'full', 'later'] as PaymentMode[])[i] ?? 'deposit'),
  );
  // §uhaul-risk — renting a $30k+ box truck with no held deposit + no accepted
  // terms is uninsured liability. assessRentalRisk (shared, deterministic) turns
  // the selection into the security deposit we disclose + the terms the customer
  // must tick before the booking is valid. UI-only this slice: no charge change.
  const [services, setServices] = useState<Service[]>(() => {
    const fromPrefill = quotePrefill.current.services;
    if (fromPrefill && fromPrefill.length) return fromPrefill;
    if (draft.current.services && draft.current.services.length) return draft.current.services;
    if (prefilledService && (VALID_SERVICES as readonly string[]).includes(prefilledService)) {
      return [prefilledService];
    }
    return [];
  });
  // Services are OPTIONAL — the tiles stay hidden behind a "Tell us what you need"
  // button (same opt-in pattern as U-Haul). The button doubles as a multi-faceted
  // advertisement: it names the breadth of work we do so customers discover we
  // handle far more than the one job they arrived for. Auto-open if prefilled.
  const [showServices, setShowServices] = useState<boolean>(
    (quotePrefill.current.services?.length ?? 0) > 0 ||
      (draft.current.services?.length ?? 0) > 0 ||
      Boolean(prefilledService),
  );
  // §bundle (2026-05-24) — city pages link to /book?bundle=<slug>. When
  // the URL carries a known bundle slug, lock the form into prepay mode at
  // a fixed total. The estimate sidebar shows the bundle name + price
  // instead of the per-day meter math; the server validates the bundle
  // matches before charging. The user can click "× change" to clear the
  // bundle and unlock the form.
  const [bundle, setBundle] = useState<Bundle | null>(() => {
    if (typeof window === 'undefined') return null;
    const slug = new URLSearchParams(window.location.search).get('bundle');
    if (!slug) return null;
    return bundleBySlug(slug) ?? null;
  });
  const clearBundle = useCallback(() => {
    setBundle(null);
    if (typeof window === 'undefined') return;
    const url = new URL(window.location.href);
    url.searchParams.delete('bundle');
    window.history.replaceState(null, '', url.toString());
    track('bundle_unlocked');
  }, []);

  const [recurringPlan, setRecurringPlan] = useState<RecurringPlan>(
    quotePrefill.current.recurringPlan ?? draft.current.recurringPlan ?? 'one-time',
  );
  const [recurringEndAfter, setRecurringEndAfter] = useState<number>(draft.current.recurringEndAfter ?? 0);
  // Auto-reschedule when the crew is unavailable is always assumed (no UI toggle).
  const recurringAutoPause = true;
  // Subscription scheduler (2026-09-25 redesign): a subscription is defined by the
  // WEEKDAYS the crew comes each week + a start date (the calendar `date`) + a start
  // time. `subMode` = the customer chose Subscription (vs One-time). recurringPlan is
  // DERIVED from the weekday set (planForWeekdays: 7→daily, 1-6→weekly) for pricing.
  const [subMode, setSubMode] = useState<boolean>(
    (quotePrefill.current.recurringPlan ?? draft.current.recurringPlan ?? 'one-time') !== 'one-time',
  );
  const [subscriptionWeekdays, setSubscriptionWeekdays] = useState<Weekday[]>([]);
  const [subscriptionStartTime, setSubscriptionStartTime] = useState<string>('8:00 AM');
  const [subFrequency, setSubFrequency] = useState<SubFrequency>('weekly');
  // Per-visit overrides for the "Your schedule" chart: each line (keyed by its ISO
  // date) may override the global crew / hours / start-time — a customer who needs a
  // bigger crew or a different time on ONE visit sets it right on that row. A missing
  // key means the row inherits the globals (crew / hours / subscriptionStartTime).
  const [subVisitOverrides, setSubVisitOverrides] = useState<
    Record<string, { crew: CrewSize; hours: number; startTime: string }>
  >({});
  // The schedule row currently open for inline editing (its ISO date), or null.
  const [editingVisitIso, setEditingVisitIso] = useState<string | null>(null);
  const recurringFlag = useFeatureFlag('recurring_subscriptions');
  const postBookingUpsellFlag = useFeatureFlag('post_booking_upsell');
  const contactLockFlag = useFeatureFlag('contact_lock_quote_gate');
  const bnplToggleFlag = useFeatureFlag('bnpl_toggle');
  const depositPickerFlag = useFeatureFlag('deposit_picker');
  const appleGooglePayFlag = useFeatureFlag('apple_google_pay_express');
  const aiQuoteOptimizerFlag = useFeatureFlag('ai_quote_optimizer');
  // Contact-lock gate: when ON, a first-time visitor who has picked a service
  // (so there's a real estimate to tease) but hasn't identified themselves sees
  // a tiny name/email/phone gate above the form. Unlocking pre-fills the form
  // contact fields + captures the lead, then never shows again this session.
  const [quoteUnlocked, setQuoteUnlocked] = useState(false);
  const [referralCode, setReferralCode] = useState<string>(
    (
      // URL `?ref=BCL-XXXX` wins (idea #4 neighbor-referral landing pages
      // deep-link to /book?ref=...). Fall through to quote prefill + draft.
      params.get('ref') ??
      quotePrefill.current.referralCode ??
      draft.current.referralCode ??
      ''
    ).toUpperCase(),
  );
  // Referral field mirrors the coupon field's collapsed-by-default state: hidden
  // behind a "Have a referral code? +" toggle, auto-expanded only when a code
  // already arrived (URL ?ref / prefill / draft) so it's never lost.
  const [referralExpanded, setReferralExpanded] = useState<boolean>(() =>
    Boolean(params.get('ref') || quotePrefill.current.referralCode || draft.current.referralCode),
  );
  // §coupon (2026-05-25) — first-booking coupon issued by city-page
  // email capture. URL ?coupon=<CODE> auto-fills + expands. Worker is the
  // source of truth on value/expiry/min-spend — we optimistically render
  // $25 off (the only kind we issue today) once format validates; if the
  // server rejects on submit, couponServerError surfaces in the panel
  // and the booking still goes through at full price.
  const [couponCode, setCouponCode] = useState<string>(() => {
    const fromUrl = (params.get('coupon') || '').trim().toUpperCase();
    return fromUrl;
  });
  const [couponExpanded, setCouponExpanded] = useState<boolean>(() =>
    Boolean(params.get('coupon')),
  );
  const [couponServerError, setCouponServerError] = useState<string>('');
  const COUPON_ASSUMED_CENTS = 2500;
  const couponFormatOk = isValidCouponFormat(couponCode);
  const couponOff = couponFormatOk ? COUPON_ASSUMED_CENTS / 100 : 0;

  const [extras, setExtras] = useState<string[]>(() => {
    const fromPrefill = quotePrefill.current.extras;
    if (fromPrefill && fromPrefill.length) return fromPrefill;
    if (draft.current.extras && draft.current.extras.length) return draft.current.extras;
    return EXTRAS.filter((x) => x.defaultOn).map((x) => x.id);
  });
  const [submitting, setSubmitting] = useState(false);
  // Cloudflare Turnstile token (P0-2). Empty until the widget mints one; the worker
  // soft-opens an empty token until TURNSTILE_SITE_KEY is live, then fail-closes.
  const [turnstileToken, setTurnstileToken] = useState('');
  const [submitError, setSubmitError] = useState('');
  const [validationErrors, setValidationErrors] = useState<
    { field: string; label: string; message: string }[]
  >([]);
  const [quoteSaving, setQuoteSaving] = useState(false);
  const [quoteUrl, setQuoteUrl] = useState('');
  const [quoteCopied, setQuoteCopied] = useState(false);
  // fire-152 — success-screen "Copy link" feedback (the clipboard write was silent before).
  const [trackLinkCopied, setTrackLinkCopied] = useState(false);
  const [quoteError, setQuoteError] = useState('');
  const [aiSessionId, setAiSessionId] = useState('');
  const [aiTranscript, setAiTranscript] = useState<AiMsg[]>([]);
  const [aiInput, setAiInput] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState('');
  const [aiQuote, setAiQuote] = useState<AiQuoteStructured | null>(null);
  // Real web-researched fair-market band from POST /api/ai/fair-market (Tavily web
  // research + Workers AI synthesis) — replaces the old total×1.2 guess.
  const [fairMarket, setFairMarket] = useState<{
    comparison: {
      marketLowCents: number;
      marketHighCents: number;
      ourPositioning: 'cheaper' | 'competitive' | 'premium';
      honestNote: string;
      hiringTips: string[];
    };
    sources: { title: string; url: string }[];
    researched: boolean;
  } | null>(null);
  const fairMarketSigRef = useRef('');
  // Last job signature the concierge has quoted against — drives the live
  // auto-refresh so the chat never shows a quote stale vs the current form.
  const conciergeSyncSigRef = useRef('');
  const aiSeededRef = useRef(false);
  const [scopeImproveBusy, setScopeImproveBusy] = useState(false);
  const [scopeImproveError, setScopeImproveError] = useState('');
  const [scopeOriginalBeforeImprove, setScopeOriginalBeforeImprove] = useState<string | null>(null);

  interface ReviewQuestion {
    id: string;
    question: string;
    helper?: string;
    multi?: boolean;
    inputType?: 'choice' | 'text' | 'textarea';
    placeholder?: string;
    minChars?: number;
    options: Array<{ id: string; label: string; upsellCents?: number }>;
  }
  const [reviewQuestions, setReviewQuestions] = useState<ReviewQuestion[]>([]);
  const [reviewAnswers, setReviewAnswers] = useState<Record<string, string[]>>({});
  const [reviewText, setReviewText] = useState<Record<string, string>>({});
  const [reviewLoading, setReviewLoading] = useState(false);
  const [reviewError, setReviewError] = useState('');
  const [reviewMoreLoading, setReviewMoreLoading] = useState(false);
  const reviewSeededRef = useRef(false);
  const [showQuoteChat, setShowQuoteChat] = useState(false);
  // Keep the concierge chat pinned to its newest message — the scrollbar stays at
  // the bottom as the conversation grows, so the latest reply is always in view.
  const aiChatScrollRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = aiChatScrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [aiTranscript, aiLoading, showQuoteChat]);

  const loadReviewQuestions = async (more = false): Promise<void> => {
    if (more) setReviewMoreLoading(true);
    else setReviewLoading(true);
    setReviewError('');
    try {
      const res = await fetch('/api/ai-assist/review-questions', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          scope: notes,
          services,
          hours,
          crew,
          city,
          zip,
          alreadyAnsweredIds: more ? reviewQuestions.map((q) => q.id) : [],
          count: 4,
        }),
      });
      const data = (await res.json()) as {
        ok?: boolean;
        questions?: ReviewQuestion[];
        error?: string;
      };
      if (!res.ok || !data.ok || !data.questions) throw new Error(data.error || 'questions_failed');
      if (more) {
        setReviewQuestions((prev) => [...prev, ...data.questions!]);
      } else {
        setReviewQuestions(data.questions);
      }
      track(more ? 'ai_review_questions_more' : 'ai_review_questions_loaded', {
        count: data.questions.length,
      });
    } catch (err) {
      // Fail-soft: AI review is optional (endpoint may be down, e.g. model budget). Observe via
      // analytics, NOT console.error — a console error on the money path trips the first-party
      // console gate (feedback_failsoft_drop_observe_not_throw). The booking continues regardless.
      track('ai_review_questions_failed', { reason: err instanceof Error ? err.message : 'unknown' });
      setReviewError('Could not load questions. Continue without them — your booking still works.');
    } finally {
      setReviewLoading(false);
      setReviewMoreLoading(false);
    }
  };

  const toggleReviewAnswer = (qid: string, optId: string, multi: boolean): void => {
    setReviewAnswers((prev) => {
      const current = prev[qid] ?? [];
      if (multi) {
        const next = current.includes(optId)
          ? current.filter((x) => x !== optId)
          : [...current, optId];
        return { ...prev, [qid]: next };
      }
      return { ...prev, [qid]: [optId] };
    });
    track('ai_review_answered', { qid, optId, multi });
  };

  const isTextAnswerValid = useCallback(
    (q: ReviewQuestion): boolean => {
      if (q.inputType !== 'text' && q.inputType !== 'textarea') return false;
      const raw = (reviewText[q.id] ?? '').trim();
      const min = Math.max(3, q.minChars ?? (q.inputType === 'textarea' ? 20 : 3));
      return raw.length >= min;
    },
    [reviewText],
  );

  // AI-Info clarifier questions NEVER upsell — they only help the crew show up
  // ready. Answering them adds $0 to the price (Brian directive 2026-09-27). Kept
  // as a constant 0 so every consumer (pricing + display) is upsell-free.
  const reviewUpsellCents = 0;

  const reviewAnsweredCount = useMemo(() => {
    return reviewQuestions.filter((q) => {
      if (q.inputType === 'text' || q.inputType === 'textarea') return isTextAnswerValid(q);
      return (reviewAnswers[q.id]?.length ?? 0) > 0;
    }).length;
  }, [reviewQuestions, reviewAnswers, isTextAnswerValid]);

  // AI-summarized job instructions for the Confirm review. The deterministic
  // shared summarizer is the INSTANT floor (no network, always sensible); when
  // the Confirm step is reached we upgrade it via the free Workers-AI route
  // (/api/ai-assist/summarize-scope), which itself falls back to the same floor.
  // Never blocks the money path — a failed/slow call just keeps the floor.
  const notesFloor = useMemo(() => summarizeScope(notes), [notes]);
  const [notesSummary, setNotesSummary] = useState('');
  const notesSummarizedRef = useRef('');
  useEffect(() => {
    // Keep the floor visible the instant notes change (and if the AI hasn't run
    // for this exact text yet), so the section is never empty or stale.
    if (notesSummarizedRef.current !== notes.trim()) setNotesSummary(notesFloor);
  }, [notes, notesFloor]);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const trimmed = notes.trim();
    if (step !== 'confirm' || trimmed.length < 4) return;
    if (notesSummarizedRef.current === trimmed) return; // already summarized this text
    const ctrl = new AbortController();
    const t = window.setTimeout(async () => {
      try {
        const res = await fetch('/api/ai-assist/summarize-scope', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ scope: trimmed.slice(0, 4000) }),
          signal: ctrl.signal,
        });
        if (!res.ok) return; // fail-soft: keep the deterministic floor
        const data = (await res.json()) as { ok?: boolean; summary?: string };
        const s = (data.summary ?? '').trim();
        if (s) {
          notesSummarizedRef.current = trimmed;
          setNotesSummary(s);
        }
      } catch {
        // aborted or offline — the floor already renders, nothing to do.
      }
    }, 350);
    return () => {
      ctrl.abort();
      window.clearTimeout(t);
    };
  }, [step, notes]);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const flat: Array<{ id: string; question: string; answer: string }> = [];
    for (const q of reviewQuestions) {
      if (q.inputType === 'text' || q.inputType === 'textarea') {
        const v = (reviewText[q.id] ?? '').trim();
        if (v) flat.push({ id: q.id, question: q.question, answer: v });
      } else {
        const picked = reviewAnswers[q.id] ?? [];
        if (!picked.length) continue;
        const labels = picked
          .map((optId) => q.options.find((o) => o.id === optId)?.label)
          .filter((l): l is string => Boolean(l));
        if (labels.length) flat.push({ id: q.id, question: q.question, answer: labels.join(', ') });
      }
    }
    try {
      localStorage.setItem('bcl-ai-review-v1', JSON.stringify(flat));
    } catch {
      /* noop */
    }
  }, [reviewQuestions, reviewAnswers, reviewText]);

  const improveScope = async (): Promise<void> => {
    const trimmed = notes.trim();
    if (trimmed.length < 4 || scopeImproveBusy) return;
    setScopeImproveBusy(true);
    setScopeImproveError('');
    try {
      const res = await fetch('/api/ai-assist/improve-scope', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ scope: trimmed }),
      });
      const data = (await res.json()) as { ok?: boolean; improved?: string; error?: string };
      if (!res.ok || !data.ok || !data.improved) {
        throw new Error(data.error || `improve_failed_${res.status}`);
      }
      setScopeOriginalBeforeImprove(notes);
      setNotes(data.improved);
      track('ai_scope_improved', { length: data.improved.length });
    } catch (err) {
      // Error tracked via Sentry — no browser console output
      setScopeImproveError(
        (err as Error).message?.startsWith('improve_failed_')
          ? 'AI rewrite failed. Try again.'
          : 'AI rewrite failed. Try again.',
      );
    } finally {
      setScopeImproveBusy(false);
    }
  };

  const undoScopeImprove = (): void => {
    if (scopeOriginalBeforeImprove === null) return;
    setNotes(scopeOriginalBeforeImprove);
    setScopeOriginalBeforeImprove(null);
    setScopeImproveError('');
  };

  const rentalLines = useMemo(() => {
    const lines: { id: string; label: string; qty: number; price: number }[] = [];
    // Single-day truck picks
    for (const pick of truckPicks) {
      const t = rentalById(pick.id);
      if (!t) continue;
      lines.push({
        id: t.id,
        label: pick.qty > 1 ? `${t.label} × ${pick.qty}` : t.label,
        qty: pick.qty,
        price: (t.priceCents * pick.qty) / 100,
      });
    }
    // Multi-day per-date truck picks
    if (multiDates.length > 1) {
      for (const d of multiDates) {
        const truckId = multiPerTruck[d];
        if (!truckId) continue;
        const t = rentalById(truckId);
        if (!t) continue;
        const label = new Date(d + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
        lines.push({ id: t.id, label: `${t.label} — ${label}`, qty: 1, price: t.priceCents / 100 });
      }
    }
    return lines;
  }, [truckPicks, multiDates, multiPerTruck]);
  const rentalsTotal = useMemo(
    () => rentalLines.reduce((sum, l) => sum + l.price, 0),
    [rentalLines],
  );
  const rentalRisk = useMemo(
    () => assessRentalRisk({ trucks: truckPicks }),
    [truckPicks],
  );
  const pricing = useBookingPricing({
    hours, crew, recurringPlan, services, date, selectedSlot, extras,
    referralCode, rentalsTotal, multiDayMode, multiDates,
    multiPerHours, multiPerCrew,
  });
  const total = pricing.total;
  // Precise charge cents — the amount the customer SEES in the summary
  // (`fmtMoney(pricing.subtotalCents)`) AND the amount the worker charges (it recomputes the same
  // `computeBookingPricing`). `total` above is rounded WHOLE DOLLARS for the headline only; a
  // `total * 100` cents payload re-introduces the ≤50¢ rounding gap booking-pricing.ts eliminated,
  // making a client price surface / wallet charge disagree with the summary. Every cents payload +
  // charge-path uses this precise integer-cents value, never `total * 100`.
  const chargeCents = pricing.subtotalCents;
  // Canonical per-day pricer for the "Pick the cheapest day" strip — runs the
  // EXACT same computePricing the big estimate uses, varying only the date and
  // forcing a single-day, no-slot (daytime) baseline. Picking a peek day clears
  // the slot (onPickDate → setSelectedSlot(null)), so the estimate then recomputes
  // to this identical number → the strip dollar can never disagree with the
  // estimate. Same-day rush (+$75), Sunday premium (+$15/hr/person), bundle/
  // recurring/referral discounts, rentals, and demand surge are ALL included.
  const priceForDate = useCallback(
    (iso: string): { totalCents: number; multiplier: number } => {
      const p = computePricing({
        hours, crew, recurringPlan, services,
        date: iso, selectedSlot: null, extras, referralCode,
        rentalsTotal,
        multiDayMode: false, multiDates: [], multiPerHours: {}, multiPerCrew: {},
      });
      return { totalCents: p.subtotalCents, multiplier: p.surgeMultiplier };
    },
    [hours, crew, recurringPlan, services, extras, referralCode, rentalsTotal],
  );
  // U-Haul is a One-time-only add-on. Entering Subscription mode (or multi-day)
  // cancels a selected truck + collapses the picker, so a stale rental can never
  // ride along on a subscription (or linger in its hidden estimate).
  useEffect(() => {
    if (subMode || multiDayMode) {
      setTruckPicks((prev) => (prev.length ? [] : prev));
      setShowUhaul(false);
    }
  }, [subMode, multiDayMode]);
  // recurringPlan is DERIVED from the chosen weekdays while in subscription mode
  // (7 days → daily/12%, 1–6 → weekly/8%, 0 → one-time until a day is picked), so
  // the existing discount + charge path (discountForPlan) needs no change.
  useEffect(() => {
    if (!subMode) return;
    let plan: RecurringPlan;
    if (subFrequency === 'monthly' || subFrequency === 'yearly') plan = 'monthly';
    else if (subFrequency === 'biweekly') plan = 'biweekly';
    else plan = subscriptionWeekdays.length ? planForWeekdays(subscriptionWeekdays) : 'one-time';
    setRecurringPlan(plan);
    // Funnel event lives beside the real plan change so it can never drift off
    // the user interaction. Discount is derived (never a literal) so the reported
    // margin always equals what the worker charges.
    track(FUNNEL.recurringSelected, {
      plan,
      discountPct: discountForPlan(plan),
      recurring: plan !== 'one-time',
    });
  }, [subMode, subFrequency, subscriptionWeekdays]);
  const enterSubscription = useCallback(() => {
    setSubMode(true);
    setSubscriptionWeekdays((prev) => (prev.length ? prev : date ? [weekdayOf(date)] : []));
  }, [date]);
  const exitSubscription = useCallback(() => {
    setSubMode(false);
    setSubscriptionWeekdays([]);
    setRecurringPlan('one-time');
    track(FUNNEL.recurringSelected, {
      plan: 'one-time',
      discountPct: discountForPlan('one-time'),
      recurring: false,
    });
  }, []);
  const toggleWeekday = useCallback((wd: Weekday) => {
    setSubscriptionWeekdays((prev) =>
      prev.includes(wd) ? prev.filter((d) => d !== wd) : [...prev, wd].sort((a, b) => a - b),
    );
  }, []);
  // Start-date ↔ weekday mismatch: the picked start date's weekday isn't in the
  // contract set, so the FIRST visit waits until the next matching weekday.
  const subStartMismatch =
    subMode &&
    Boolean(date) &&
    !isDateBasedFrequency(subFrequency) &&
    isStartMismatch(date, subscriptionWeekdays);
  const subFirstVisit = subStartMismatch ? firstServiceDate(date, subscriptionWeekdays) : date;
  // How many visits to generate: the END AFTER count when set, else enough to
  // blanket the 60-day calendar window.
  const subCap = recurringEndAfter > 0 ? recurringEndAfter : 60;
  // All subscription visit dates (weekday + frequency aware), capped by END AFTER —
  // drives the calendar shading, the visit chart, and the per-period pricing.
  const subVisitDates = useMemo(
    () =>
      subMode && date && (isDateBasedFrequency(subFrequency) || subscriptionWeekdays.length > 0)
        ? subscriptionVisits(date, subscriptionWeekdays, subFrequency, subCap)
        : [],
    [subMode, date, subscriptionWeekdays, subFrequency, subCap],
  );
  // Chart shows the first 14 visits, never more than END AFTER.
  const subChartVisits = subVisitDates.slice(
    0,
    recurringEndAfter > 0 ? Math.min(recurringEndAfter, 14) : 14,
  );
  // Per-visit effective values: an override on that row wins, else the global default.
  const visitCrew = (iso: string): CrewSize => subVisitOverrides[iso]?.crew ?? crew;
  const visitHours = (iso: string): number => subVisitOverrides[iso]?.hours ?? hours;
  const visitStart = (iso: string): string => subVisitOverrides[iso]?.startTime ?? subscriptionStartTime;
  const visitIsCustom = (iso: string): boolean => {
    const o = subVisitOverrides[iso];
    if (!o) return false;
    return o.crew !== crew || o.hours !== hours || o.startTime !== subscriptionStartTime;
  };
  // Set one field on one visit, seeding the other two from the current effective values.
  const setVisitField = (
    iso: string,
    patch: Partial<{ crew: CrewSize; hours: number; startTime: string }>,
  ) =>
    setSubVisitOverrides((prev) => ({
      ...prev,
      [iso]: {
        crew: prev[iso]?.crew ?? crew,
        hours: prev[iso]?.hours ?? hours,
        startTime: prev[iso]?.startTime ?? subscriptionStartTime,
        ...patch,
      },
    }));
  // Drop a row's override so it snaps back to the global default.
  const resetVisit = (iso: string) =>
    setSubVisitOverrides((prev) => {
      const next = { ...prev };
      delete next[iso];
      return next;
    });
  const subVisitsPerPeriod = visitsPerPeriod(subscriptionWeekdays, subFrequency);
  const subFirstPeriodVisits =
    subMode && date ? firstPeriodVisitCount(date, subscriptionWeekdays, subFrequency) : 0;
  // Subscription pricing: one visit's cost (already recurring-discounted) × visits
  // per period. If the start lands mid-period, the first charge is pro-rated to the
  // visits that actually fall in that first week/fortnight.
  // Precise integer-cents breakdown from `chargeCents` (= pricing.subtotalCents, the per-visit charge
  // the customer sees on the single-visit summary) — NEVER the headline's rounded whole-dollars `total`,
  // which showed "$48/visit" beside a "$47.50" single visit (fire-59; same quote==charge class as fire-58).
  const subCharge = recurringChargeCents(chargeCents, subVisitsPerPeriod, subFirstPeriodVisits);
  const subPerVisitCents = subCharge.perVisitCents;
  const subPerPeriodCents = subCharge.perPeriodCents;
  const subFirstChargeCents = subCharge.firstChargeCents;
  const subProrated = subCharge.prorated;
  // Single-day (One-time) start-time slot picker. Rendered COMPACT in the right
  // column beside the calendar on desktop, and full-width below on mobile (where
  // the right column is hidden) — one source, two placements.
  const renderStartTime = (compact: boolean) => (
    <div>
      <p className={compact ? 'text-[10px] font-mono uppercase tracking-widest text-brand-accent mb-1.5' : 'label mb-3'}>
        Start time
      </p>
      {slotsLoading && (
        <p className="text-sm text-brand-mute">
          <span className="spinner mr-2" /> Loading available times…
        </p>
      )}
      {slotsError && <p role="alert" className="text-sm text-red-400 bcl-field-error">{slotsError}</p>}
      {!slotsLoading && !slotsError && slots.length === 0 && date && (
        <p className="text-xs text-brand-mute">
          No availability on this date — try another day or{' '}
          <a href={lpHref('/contact')} className="text-brand-accent underline-hover">message us</a>.
        </p>
      )}
      {!slotsLoading && slots.length > 0 && (
        <div className={compact ? 'grid grid-cols-3 gap-1.5' : 'grid grid-cols-3 sm:grid-cols-4 gap-2'}>
          {slots.map((slot) => {
            const isPremium = isAfterHoursSlot(slot, date) || isSunday(date);
            const active = selectedSlot?.startAt === slot.startAt;
            return (
              <button
                key={slot.startAt}
                type="button"
                onClick={() => setSelectedSlot(slot)}
                aria-pressed={active}
                title={isPremium ? 'Premium hours — +$15/hr per person' : undefined}
                className={`relative rounded-lg border ${compact ? 'px-1.5 py-1 text-[11px]' : 'px-3 py-2 text-sm'} font-mono transition-colors ${
                  active
                    ? 'border-brand-accent bg-brand-accent text-bg-primary font-bold'
                    : isPremium
                      ? 'border-amber-400/40 text-amber-200/90 hover:border-amber-400 hover:bg-amber-400/10'
                      : 'border-brand-line hover:border-brand-accent text-brand-mute hover:text-brand-ink'
                }`}
              >
                {slot.localTime}
                {isPremium && !active && (
                  <span aria-hidden className="absolute right-0.5 top-0.5 h-1 w-1 rounded-full bg-amber-400" />
                )}
              </button>
            );
          })}
        </div>
      )}
      {selectedSlot && isAfterHoursSlot(selectedSlot, date) && !isSunday(date) && (
        <p className="mt-2 text-[11px] text-amber-200/90">
          After-hours pick — adds <strong className="text-amber-300">+$15/hr per person</strong>. Standard hours are 8a — 5p.
        </p>
      )}
    </div>
  );
  // Standing-crew (recurring/subscription) scheduler. Rendered in the right
  // column beside the calendar on desktop, and full-width below on mobile
  // (where that column is hidden) — one source, two placements.
  const renderRecurring = () => (
    <div data-testid="recurring-frequency" className="space-y-3">
      {/* Section label for the One-time/Subscription toggle GROUP (the buttons are self-labeled via
          their text + aria-pressed). Was a <label> whose htmlFor pointed at a nonexistent id — an
          orphaned association the fire-69 dual-mount would have doubled; made a plain <p>. */}
      <p className="label">
        How often?{' '}
        <span className="text-brand-mute font-normal">
          (save up to 12% on recurring service)
        </span>
      </p>
      {/* Two same-size controls: One-time · Subscription. Choosing
          Subscription reveals the 3 inputs below (start date · weekdays
          · start time). recurringPlan is derived from the weekday set. */}
      <div className="grid grid-cols-2 gap-2">
        <button
          type="button"
          aria-pressed={!subMode}
          onClick={() => {
            exitSubscription();
          }}
          className={`rounded-lg border px-3 py-2.5 text-center font-mono text-xs font-bold transition-all ${
            !subMode
              ? 'border-brand-accent bg-brand-accent/15 text-brand-accent shadow-[0_0_12px_rgba(255,107,26,0.15)]'
              : 'border-brand-line bg-bg-primary text-brand-ink hover:border-brand-accent/50'
          }`}
        >
          One-time
        </button>
        <button
          type="button"
          aria-pressed={subMode}
          onClick={() => {
            enterSubscription();
          }}
          className={`rounded-lg border px-3 py-2.5 text-center font-mono text-xs font-bold transition-all ${
            subMode
              ? 'border-brand-accent bg-brand-accent/15 text-brand-accent shadow-[0_0_12px_rgba(255,107,26,0.15)]'
              : 'border-brand-line bg-bg-primary text-brand-ink hover:border-brand-accent/50'
          }`}
        >
          Subscription
        </button>
      </div>
      {subMode && (
        <div className="space-y-3 rounded-lg border border-brand-accent/30 bg-brand-accent/5 p-3">
          {/* 1 · Start date — driven by the calendar on the left */}
          <div>
            <p className="text-[10px] font-mono uppercase tracking-widest text-brand-mute mb-1">1 · Start date</p>
            {date ? (
              <p className="text-xs font-mono text-brand-ink">
                {new Date(date + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}
              </p>
            ) : (
              <p className="text-xs text-brand-accent">← Pick your start date on the calendar.</p>
            )}
          </div>
          {/* 2 · How often */}
          <div>
            <p className="text-[10px] font-mono uppercase tracking-widest text-brand-mute mb-1">2 · How often?</p>
            <div className="grid grid-cols-2 gap-1.5">
              {(['weekly', 'biweekly', 'monthly', 'yearly'] as SubFrequency[]).map((f) => {
                const on = subFrequency === f;
                return (
                  <button
                    key={f}
                    type="button"
                    aria-pressed={on}
                    onClick={() => setSubFrequency(f)}
                    className={`rounded-md border px-2 py-1.5 font-mono text-[11px] font-bold transition-all ${
                      on
                        ? 'border-brand-accent bg-brand-accent/15 text-brand-accent'
                        : 'border-brand-line bg-bg-primary text-brand-mute hover:border-brand-accent/60 hover:text-brand-ink'
                    }`}
                  >
                    {FREQUENCY_LABELS[f]}
                  </button>
                );
              })}
            </div>
          </div>
          {/* 3 · Which days — weekly/biweekly only (monthly/yearly repeat on the start date, no picker) */}
          {!isDateBasedFrequency(subFrequency) && (
            <div>
              <p className="text-[10px] font-mono uppercase tracking-widest text-brand-mute mb-1">3 · Which days?</p>
              <div className="grid grid-cols-7 gap-1" role="group" aria-label="Subscription weekdays">
                {WEEKDAY_LETTERS.map((letter, wd) => {
                  const on = subscriptionWeekdays.includes(wd as Weekday);
                  return (
                    <button
                      key={wd}
                      type="button"
                      aria-pressed={on}
                      aria-label={WEEKDAY_SHORT[wd]}
                      onClick={() => toggleWeekday(wd as Weekday)}
                      className={`h-8 rounded-md border font-mono text-xs font-bold transition-all ${
                        on
                          ? 'border-brand-accent bg-brand-accent text-bg-primary shadow-[0_0_10px_rgba(255,107,26,0.25)]'
                          : 'border-brand-line bg-bg-primary text-brand-mute hover:border-brand-accent/60 hover:text-brand-ink'
                      }`}
                    >
                      {letter}
                    </button>
                  );
                })}
              </div>
              <p className="mt-1 text-[10px] text-brand-mute">
                {summarizeWeekdays(subscriptionWeekdays)}
                {subscriptionWeekdays.length > 0 ? ` · save ${discountForPlan(planForWeekdays(subscriptionWeekdays))}%` : ' — pick at least one day'}
              </p>
            </div>
          )}
          {/* Start time — step 3 for monthly/yearly (no weekday picker), step 4 otherwise */}
          <div>
            <p className="text-[10px] font-mono uppercase tracking-widest text-brand-mute mb-1">{isDateBasedFrequency(subFrequency) ? '3' : '4'} · Start time</p>
            <select
              value={subscriptionStartTime}
              onChange={(e) => setSubscriptionStartTime(e.target.value)}
              aria-label="Subscription start time"
              className="w-full rounded-md border border-brand-line bg-bg-primary px-2 py-1.5 text-xs font-mono text-brand-ink focus:border-brand-accent focus:outline-none"
            >
              {['7:00 AM','8:00 AM','9:00 AM','10:00 AM','11:00 AM','12:00 PM','1:00 PM','2:00 PM','3:00 PM','4:00 PM','5:00 PM','6:00 PM'].map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>
          {subVisitDates.length > 0 && (
            <>
              <div className="rounded-md border border-brand-accent/30 bg-brand-accent/10 p-2.5 text-[11px] leading-snug text-brand-ink">
                <p>
                  <span className="text-brand-accent font-bold">⚡ ${fmtMoney(subPerPeriodCents)} / {periodNoun(subFrequency)}</span>
                  {subVisitsPerPeriod > 1 ? ` · ${subVisitsPerPeriod} visits × $${fmtMoney(subPerVisitCents)}` : ''}. Same crew, locked rate — pause, skip, or cancel anytime.
                </p>
                {subProrated && (
                  <p className="mt-1 text-amber-200">
                    First charge pro-rated to <strong>${fmtMoney(subFirstChargeCents)}</strong> ({subFirstPeriodVisits} visit{subFirstPeriodVisits === 1 ? '' : 's'} this first {periodNoun(subFrequency)}).
                  </p>
                )}
              </div>
              {subStartMismatch && (
                <div className="rounded-md border border-amber-400/50 bg-amber-400/10 px-2.5 py-2 text-[11px] leading-snug text-amber-200">
                  ⚠ Your start date lands on a day you didn’t select, so the first visit waits until{' '}
                  <strong>{new Date(subFirstVisit + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}</strong>. Weekly + bi-weekly subscriptions run by day-of-week — pick a start date on one of your chosen weekdays to clear this note.
                </div>
              )}
              <div className="rounded-md border border-brand-line/60 bg-bg-primary/60 px-2 py-1.5">
                <p className="text-[10px] font-mono uppercase tracking-widest text-brand-mute mb-1">End after</p>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    aria-label="Fewer visits"
                    disabled={recurringEndAfter <= 0}
                    onClick={() => setRecurringEndAfter(Math.max(0, recurringEndAfter - 1))}
                    className="h-7 w-7 shrink-0 rounded border border-brand-line font-mono text-brand-ink hover:border-brand-accent disabled:opacity-30"
                  >
                    −
                  </button>
                  <input
                    type="number"
                    inputMode="numeric"
                    min={0}
                    max={520}
                    step={1}
                    value={recurringEndAfter || ''}
                    placeholder="0"
                    onChange={(e) => setRecurringEndAfter(Math.max(0, Math.min(520, Math.floor(Number(e.target.value) || 0))))}
                    aria-label="Number of visits before this subscription ends (0 = no end date)"
                    className="min-w-0 flex-1 rounded border border-brand-line bg-bg-primary px-2 py-1 text-center text-xs font-mono font-bold text-brand-accent focus:border-brand-accent focus:outline-none"
                  />
                  <button
                    type="button"
                    aria-label="More visits"
                    disabled={recurringEndAfter >= 520}
                    onClick={() => setRecurringEndAfter(Math.min(520, recurringEndAfter + 1))}
                    className="h-7 w-7 shrink-0 rounded border border-brand-line font-mono text-brand-ink hover:border-brand-accent disabled:opacity-30"
                  >
                    +
                  </button>
                </div>
                <p className="mt-1 text-[10px] text-brand-mute">
                  {recurringEndAfter > 0 ? `Ends after ${recurringEndAfter} visit${recurringEndAfter === 1 ? '' : 's'}` : 'No end date — runs until you cancel'}
                </p>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
  // Flat-$50 deposit split with the REAL remainder — so the payment step never
  // promises "rest billed after" on the $50-minimum job (deposit == whole job).
  const depositPlan = depositSplit(pricing.subtotalCents);
  // SPEC § "Consent UI": the customer must explicitly authorize what is charged
  // and WHEN before the booking is placed. Mode-adaptive, shared with the worker.
  // fire-87: a multi-day booking charges $0 today (submit ignores paymentMode), so the legal consent
  // ("I authorize … to charge $X now") and the trust strip ("$X charged now") must read the TRUE mode
  // — 'later' for multi-day — or they'd promise a charge that never happens. Same SSOT the CTA uses.
  const effectivePaymentMode = effectivePayMode(multiDayMode && multiDates.length >= 1, paymentMode);
  const paymentAuth = paymentAuthorization(effectivePaymentMode, pricing.subtotalCents);
  const paymentTrust = paymentTrustStrip(effectivePaymentMode, pricing.subtotalCents);
  // SPEC § "Booking payment policy": a high-risk job MAY require a refundable
  // deposit at booking. Disclose it at the price reveal (not at checkout) using
  // the SAME deterministic engine the saved-quote page uses, so the form, the
  // shared quote, and the worker route can never disagree on the amount/reasons.
  // (`first_time_customer` + `same_day_emergency` stay with the worker — no auth
  // Booking locale from the `/es|/pt` URL prefix (createRoot replaces the
  // prerendered shell, so reading window at render carries no hydration risk).
  // Drives the estimate-sidebar line labels + surge pills so a Spanish/
  // Portuguese visitor reads the price reveal in their own language.
  const bookingLocale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const estCopy = estimateCopy(bookingLocale);
  const confirmCopy = bookingConfirmCopy(bookingLocale);
  const formCopy = bookingFormCopy(bookingLocale);
  const sectionRef = useRef<HTMLDivElement>(null);
  const initialPaymentRef = useRef(true);
  const startedRef = useRef(false);

  useEffect(() => {
    if (startedRef.current) return;
    startedRef.current = true;
    track(FUNNEL.bookingStarted, { source: utmSource });
  }, [utmSource]);

  useEffect(() => {
    const handler = () => {
      const prefill = readQuotePrefill();
      if (prefill.hours !== undefined) setHours(prefill.hours);
      if (prefill.crew !== undefined) {
        setCrew(prefill.crew);
      }
      if (prefill.notes !== undefined) setNotes(prefill.notes);
      if (prefill.truckPicks !== undefined) setTruckPicks(prefill.truckPicks);
      if (prefill.paymentMode !== undefined) setPaymentMode(prefill.paymentMode);
      if (prefill.services !== undefined) setServices(prefill.services);
      if (prefill.recurringPlan !== undefined) setRecurringPlan(prefill.recurringPlan);
      if (prefill.referralCode !== undefined) setReferralCode(prefill.referralCode);
      if (prefill.extras !== undefined) setExtras(prefill.extras);
    };
    window.addEventListener('bcl-prefill-quote', handler);
    return () => window.removeEventListener('bcl-prefill-quote', handler);
  }, []);

  // §bundle-prefill (2026-05-24) — once on mount when a bundle is locked,
  // seed services/hours/crew from the bundle definition so the form looks
  // pre-filled. User can still change individual fields (which won't
  // un-lock the bundle on its own — they have to click × to clear).
  useEffect(() => {
    if (!bundle) return;
    setServices(
      bundle.services.filter((s) => (VALID_SERVICES as readonly string[]).includes(s)) as Service[],
    );
    setHours(bundle.hoursNum);
    if (isValidCrew(bundle.crew)) setCrew(bundle.crew);
    track('bundle_prefill', { slug: bundle.slug, priceCents: bundle.priceCents });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bundle?.slug]);

  // §magic-link prefill (magic_links flag) — a signed `/book?ml=<token>` URL
  // (minted by an operator or the SMS classifier) carries the customer's
  // intended services + contact + scope. Verify server-side, then hydrate the
  // form so the returning visitor lands on a pre-filled booking — a live
  // money-path conversion nudge. Fails quiet (404 = flag off, 429 = throttled).
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const ml = new URLSearchParams(window.location.search).get('ml');
    if (!ml || ml.length < 20) return;
    let cancelled = false;
    void (async () => {
      try {
        const res = await fetch(`/api/magic-links/verify?ml=${encodeURIComponent(ml)}`);
        if (!res.ok) return;
        const data = (await res.json()) as {
          ok: boolean;
          params?: {
            services?: string[];
            preferredDate?: string;
            customerName?: string;
            customerPhone?: string;
            customerEmail?: string;
            referralCode?: string;
            citySlug?: string;
            crewSize?: number;
            hours?: number;
          };
        };
        if (cancelled || !data.ok || !data.params) return;
        const p = data.params;
        if (Array.isArray(p.services) && p.services.length) {
          const valid = p.services.filter((s) =>
            (VALID_SERVICES as readonly string[]).includes(s),
          ) as Service[];
          if (valid.length) setServices(valid);
        }
        // Route through selectSingleDate so the magic-link date is mirrored into
        // multiDates (calendar highlight + submit gate), not just the scalar `date`.
        if (p.preferredDate) selectSingleDate(p.preferredDate);
        if (typeof p.hours === 'number') setHours(p.hours);
        if (typeof p.crewSize === 'number' && isValidCrew(p.crewSize)) {
          setCrew(p.crewSize as CrewSize);
        }
        if (p.customerName) {
          const [first, ...rest] = p.customerName.trim().split(/\s+/);
          if (first) setFirstName(first);
          if (rest.length) setLastName(rest.join(' '));
        }
        if (p.customerEmail) setEmail(p.customerEmail);
        if (p.customerPhone) setPhone(p.customerPhone);
        if (p.citySlug) setCity(p.citySlug.replace(/-/g, ' '));
        if (p.referralCode) setReferralCode(p.referralCode);
        setMagicPrefilled(true);
        track('magic_link_prefill', { services: p.services?.length ?? 0 });
      } catch {
        /* network best-effort — never block the booking form */
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (date) track(FUNNEL.datePicked, { date, hours, crew });
  }, [date, hours, crew]);

  useEffect(() => {
    if (!multiDayMode) return;
    if (multiDates.length >= 2 && recurringPlan !== 'custom') setRecurringPlan('custom');
  }, [multiDayMode, multiDates.length, recurringPlan]);

  useEffect(() => {
    if (selectedSlot) track(FUNNEL.slotPicked, { date, slot: selectedSlot.localTime });
  }, [selectedSlot, date]);

  useEffect(() => {
    if (initialPaymentRef.current) {
      initialPaymentRef.current = false;
      return;
    }
    rotateIdempotencyKey();
  }, [paymentMode]);

  useEffect(() => {
    if (step !== 'success' || !sectionRef.current) return;
    const top = sectionRef.current.getBoundingClientRect().top + window.scrollY - 80;
    window.scrollTo({ top, behavior: 'smooth' });
  }, [step]);

  // Once the welcome walkthrough has been surfaced on a confirmation screen,
  // mark it seen so it never reappears for this browser.
  useEffect(() => {
    if (step !== 'success' || !showWelcome) return;
    try {
      localStorage.setItem('bcl_welcome_seen', '1');
    } catch {
      /* private mode — fine; it just shows again next time */
    }
  }, [step, showWelcome]);

  useEffect(() => {
    if (validationErrors.length === 0) return;
    const fresh = validateForm();
    const freshKeys = new Set(fresh.map((e) => `${e.field}:${e.label}`));
    const pruned = validationErrors.filter((e) => freshKeys.has(`${e.field}:${e.label}`));
    if (pruned.length !== validationErrors.length) {
      setValidationErrors(pruned);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [firstName, lastName, email, phone, address, city, zip, date, acknowledged]);

  // Compact signature of the job the concierge should reflect. Any change here
  // (services / crew / hours / date / rentals / extras / recurring / total) means
  // the concierge's last quote is stale and must refresh.
  const conciergeSig = [
    services.join(','),
    crew,
    hours,
    date,
    selectedSlot?.startAt ?? '',
    truckPicks.map((t) => `${t.id}:${t.qty}`).join(','),
    extras.join(','),
    recurringPlan,
    total,
  ].join('|');

  useEffect(() => {
    if (step !== 'ai-review' || reviewSeededRef.current) return;
    reviewSeededRef.current = true;
    aiSeededRef.current = true;
    // Baseline the sync signature so the live auto-refresh below only fires on
    // GENUINE post-seed changes, never the initial seed.
    conciergeSyncSigRef.current = conciergeSig;
    track(FUNNEL.detailsOpened, { stage: 'ai-review', totalCents: chargeCents });
    void loadReviewQuestions(false);
    void postToAi('Here is my job from the form — please give me your fair, fixed quote.');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step]);

  // Keep the concierge LIVE: when the job changes anywhere in the form while the
  // chat is open + has already answered, silently re-quote off the new state
  // (debounced 1.5s so a burst of edits collapses to one refresh). postToAi
  // re-reads buildAiSeedMessage() at send time, so the re-quote is always current.
  useEffect(() => {
    if (!showQuoteChat || !reviewSeededRef.current || aiLoading) return;
    if (!aiTranscript.some((m) => m.role === 'assistant')) return;
    if (conciergeSyncSigRef.current === conciergeSig) return;
    const t = window.setTimeout(() => {
      conciergeSyncSigRef.current = conciergeSig;
      void postToAi('↻ I updated my job details above — please re-check my quote.');
    }, 1500);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [conciergeSig, showQuoteChat, aiLoading]);

  // Fetch the REAL web-researched fair-market band once the AI-review step opens
  // (once per distinct job). POSTs the job to /api/ai/fair-market → Tavily research
  // + Workers AI. Fail-soft: on any error the widget falls back to its heuristic.
  useEffect(() => {
    if (step !== 'ai-review' || !services.length || total <= 0) return;
    const sig = `${services.join(',')}|${hours}|${crew}|${city}|${total}`;
    if (fairMarketSigRef.current === sig) return;
    fairMarketSigRef.current = sig;
    const description =
      `${services.join(', ')} labor — ${hours} hour${hours === 1 ? '' : 's'}, ` +
      `${crew} crew member${crew === 1 ? '' : 's'} in ${city || 'Newark NJ'}.` +
      (notes ? ` ${notes.slice(0, 200)}` : '');
    let cancelled = false;
    fetch('/api/ai/fair-market', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        description: description.slice(0, 800),
        city: city || 'Newark',
        ourQuoteCents: chargeCents,
      }),
    })
      .then(async (r) => {
        const j = (await r.json()) as {
          ok?: boolean;
          comparison?: NonNullable<typeof fairMarket>['comparison'];
          sources?: { title: string; url: string }[];
          researched?: boolean;
        } | null;
        if (!cancelled && j?.ok && j.comparison) {
          setFairMarket({
            comparison: j.comparison,
            sources: (j.sources ?? []).slice(0, 4),
            researched: Boolean(j.researched),
          });
        }
      })
      .catch(() => {
        /* fail-soft — widget uses its heuristic fallback */
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step, services, hours, crew, city, total, notes]);

  useEffect(() => {
    saveDraft({
      hours,
      crew,
      date,
      selectedSlot,
      firstName,
      lastName,
      name,
      email,
      phone,
      businessName,
      address,
      city,
      zip,
      placeId,
      notes,
      smsOptIn,
      emailOptIn,
      marketingSmsOptIn,
      acknowledged,
      paymentMode,
      source: utmSource,
      truckPicks,
      services,
      recurringPlan,
      referralCode,
      extras,
      multiDayMode,
      multiDates,
      multiPerHours,
      multiPerCrew,
    });
  }, [
    hours,
    crew,
    date,
    selectedSlot,
    firstName,
    lastName,
    name,
    email,
    phone,
    businessName,
    address,
    city,
    zip,
    placeId,
    notes,
    smsOptIn,
    emailOptIn,
    marketingSmsOptIn,
    acknowledged,
    paymentMode,
    utmSource,
    truckPicks,
    services,
    recurringPlan,
    referralCode,
    extras,
    multiDayMode,
    multiDates,
    multiPerHours,
    multiPerCrew,
  ]);

  useEffect(() => {
    const onFill = (ev: Event) => {
      const detail = (ev as CustomEvent<{ name?: string; value?: string }>).detail;
      const name = detail?.name;
      const value = String(detail?.value ?? '');
      if (!name) return;
      switch (name) {
        case 'firstName':
          setFirstName(value);
          break;
        case 'lastName':
          setLastName(value);
          break;
        case 'email':
          setEmail(value);
          break;
        case 'phone':
          setPhone(value);
          break;
        case 'businessName':
          setBusinessName(value);
          break;
        case 'address':
          setAddress(value);
          break;
        case 'city':
          setCity(value);
          break;
        case 'zip':
          setZip(value);
          break;
        case 'notes':
          setNotes(value);
          break;
        case 'hours': {
          const n = Math.max(2, Math.min(60, Number.parseInt(value, 10) || 0));
          if (n > 0) setHours(n);
          break;
        }
        case 'crew': {
          const n = Math.max(1, Math.min(50, Number.parseInt(value, 10) || 0));
          if (n > 0) setCrew(n);
          break;
        }
        default:
          break;
      }
    };
    const onStep = (ev: Event) => {
      const detail = (ev as CustomEvent<{ step?: string }>).detail;
      const next = detail?.step;
      if (next === 'schedule' || next === 'details' || next === 'ai-review') {
        setStep(next);
        if (sectionRef.current) {
          const top = sectionRef.current.getBoundingClientRect().top + window.scrollY - 80;
          window.scrollTo({ top, behavior: 'smooth' });
        }
      }
    };
    window.addEventListener('bcl-concierge-fill', onFill as EventListener);
    window.addEventListener('bcl-concierge-step', onStep as EventListener);
    return () => {
      window.removeEventListener('bcl-concierge-fill', onFill as EventListener);
      window.removeEventListener('bcl-concierge-step', onStep as EventListener);
    };
  }, []);

  useEffect(() => {
    const SERVICE_ALIAS: Record<string, Service> = {
      'power-wash': 'power-wash',
      'power-washing': 'power-wash',
      powerwash: 'power-wash',
      lawn: 'lawn',
      yard: 'lawn',
      haul: 'haul',
      hauling: 'haul',
      repairs: 'repairs',
      'light-repairs': 'repairs',
      repair: 'repairs',
      cleanout: 'cleanout',
      cleanouts: 'cleanout',
      seasonal: 'seasonal',
      other: 'other',
    };
    const VALID_RECURRING: RecurringPlan[] = [
      'one-time',
      'daily',
      'weekly',
      'biweekly',
      'monthly',
      'custom',
    ];

    const onMutate = (ev: Event) => {
      const detail = (ev as CustomEvent<{ kind?: string; value?: unknown }>).detail;
      const kind = detail?.kind;
      const value = detail?.value;
      if (!kind) return;
      switch (kind) {
        case 'hours': {
          const n = Math.max(2, Math.min(40, Number.parseInt(String(value), 10) || 0));
          if (n > 0) setHours(n);
          break;
        }
        case 'crew': {
          const n = Math.max(1, Math.min(MAX_CREW, Number.parseInt(String(value), 10) || 0));
          if (isValidCrew(n)) setCrew(n);
          break;
        }
        case 'add-service': {
          const raw = String(value || '')
            .trim()
            .toLowerCase();
          const svc = SERVICE_ALIAS[raw];
          if (svc) setServices((prev) => (prev.includes(svc) ? prev : [...prev, svc]));
          break;
        }
        case 'remove-service': {
          const raw = String(value || '')
            .trim()
            .toLowerCase();
          const svc = SERVICE_ALIAS[raw];
          if (svc) setServices((prev) => prev.filter((s) => s !== svc));
          break;
        }
        case 'add-extra': {
          const id = String(value || '')
            .trim()
            .toLowerCase();
          if (/^[a-z0-9-]{2,40}$/.test(id))
            setExtras((prev) => (prev.includes(id) ? prev : [...prev, id]));
          break;
        }
        case 'remove-extra': {
          const id = String(value || '')
            .trim()
            .toLowerCase();
          if (id) setExtras((prev) => prev.filter((x) => x !== id));
          break;
        }
        case 'referral': {
          const code = String(value || '')
            .trim()
            .toUpperCase();
          if (/^BCL-[A-Z0-9]{4,16}$/.test(code)) setReferralCode(code);
          break;
        }
        case 'recurring': {
          const raw = String(value || '')
            .trim()
            .toLowerCase();
          const normalized = raw === 'none' ? 'one-time' : raw;
          if ((VALID_RECURRING as string[]).includes(normalized)) {
            setRecurringPlan(normalized as RecurringPlan);
          }
          break;
        }
        default:
          break;
      }
    };
    window.addEventListener('bcl-booking-mutate', onMutate as EventListener);
    return () => window.removeEventListener('bcl-booking-mutate', onMutate as EventListener);
  }, []);

  useEffect(() => {
    if (!date) {
      setSlots([]);
      setSelectedSlot(null);
      return;
    }
    setSlotsLoading(true);
    setSlotsError('');
    fetch(`/api/square-availability?date=${date}&hours=${hours}`)
      .then(async (r) =>
        availabilityOutcome<Slot>(
          r.ok,
          (await r.json().catch(() => null)) as { ok?: boolean; slots?: Slot[] } | null,
        ),
      )
      .then((outcome) => {
        if (!outcome.ok) {
          // A non-ok status or {ok:false} body is a SERVER error, not "no times" —
          // show the retry message instead of a lying-empty "No availability".
          setSlots([]);
          setSlotsError('Could not load times. Try a different date or call us.');
          return;
        }
        setSlots(outcome.slots);
        if (selectedSlot && !outcome.slots.some((s) => s.startAt === selectedSlot.startAt)) {
          setSelectedSlot(null);
        }
      })
      .catch(() => setSlotsError('Could not load times. Try a different date or call us.'))
      .finally(() => setSlotsLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [date, hours]);

  useEffect(() => {
    const q = addressQuery.trim();
    if (autocompleteDisabled) return;
    if (q.length < 3) {
      setAddressSuggestions([]);
      setAddressLoading(false);
      return;
    }
    if (q === [address, city, zip].filter(Boolean).join(', ')) {
      // user just selected — don't re-query against the formatted result
      return;
    }
    let cancelled = false;
    setAddressLoading(true);
    setAddressError('');
    const t = setTimeout(() => {
      fetch(
        `/api/places/autocomplete?q=${encodeURIComponent(q)}&session=${encodeURIComponent(ensureSession())}`,
      )
        .then(async (r) => {
          const json = (await r.json()) as {
            ok: boolean;
            suggestions?: PlaceSuggestion[];
            message?: string;
            disabled?: boolean;
          };
          if (cancelled) return;
          if (json.disabled) {
            setAutocompleteDisabled(true);
            setAddressSuggestions([]);
            return;
          }
          if (!json.ok) {
            setAddressSuggestions([]);
            if (json.message === 'rate-limited')
              setAddressError('Too many lookups — try again in a moment.');
            return;
          }
          setAddressSuggestions(json.suggestions ?? []);
        })
        .catch(() => {
          if (cancelled) return;
          setAddressSuggestions([]);
        })
        .finally(() => {
          if (!cancelled) setAddressLoading(false);
        });
    }, 220);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [addressQuery, autocompleteDisabled]);

  async function selectSuggestion(s: PlaceSuggestion) {
    setShowSuggestions(false);
    setAddressLoading(true);
    setAddressError('');
    try {
      const res = await fetch(
        `/api/places/details?place_id=${encodeURIComponent(s.placeId)}&session=${encodeURIComponent(ensureSession())}`,
      );
      const json = (await res.json()) as PlaceDetailsResult;
      if (!json.ok || !json.place) throw new Error(json.message || 'lookup-failed');
      const p = json.place;
      setAddress(p.street);
      setCity(p.city);
      setZip(p.zip);
      setPlaceId(p.id);
      const formatted =
        p.formatted || [p.street, p.city, p.state, p.zip].filter(Boolean).join(', ');
      setAddressQuery(formatted);
      setAddressSuggestions([]);
      // rotate session — Google bills one autocomplete+details per session
      rotatePlacesSession();
    } catch {
      setAddressError("Couldn't load that address. Try another or type it in.");
    } finally {
      setAddressLoading(false);
    }
  }

  useEffect(() => {
    const q = businessName.trim();
    if (autocompleteDisabled) return;
    if (q.length < 3) {
      setBusinessSuggestions([]);
      setBusinessLoading(false);
      return;
    }
    if (q === businessSelectedRef.current) {
      // user just picked this — don't re-query
      return;
    }
    let cancelled = false;
    setBusinessLoading(true);
    setBusinessError('');
    const t = setTimeout(() => {
      fetch(
        `/api/places/autocomplete?q=${encodeURIComponent(q)}&mode=business&session=${encodeURIComponent(ensureBusinessSession())}`,
      )
        .then(async (r) => {
          const json = (await r.json()) as {
            ok: boolean;
            suggestions?: PlaceSuggestion[];
            message?: string;
            disabled?: boolean;
          };
          if (cancelled) return;
          if (json.disabled) {
            setAutocompleteDisabled(true);
            setBusinessSuggestions([]);
            return;
          }
          if (!json.ok) {
            setBusinessSuggestions([]);
            if (json.message === 'rate-limited')
              setBusinessError('Too many lookups — try again in a moment.');
            return;
          }
          setBusinessSuggestions(json.suggestions ?? []);
        })
        .catch(() => {
          if (cancelled) return;
          setBusinessSuggestions([]);
        })
        .finally(() => {
          if (!cancelled) setBusinessLoading(false);
        });
    }, 220);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [businessName, autocompleteDisabled]);

  async function selectBusinessSuggestion(s: PlaceSuggestion) {
    setShowBusinessSuggestions(false);
    setBusinessLoading(true);
    setBusinessError('');
    try {
      const res = await fetch(
        `/api/places/details?place_id=${encodeURIComponent(s.placeId)}&session=${encodeURIComponent(ensureBusinessSession())}`,
      );
      const json = (await res.json()) as PlaceDetailsResult;
      if (!json.ok || !json.place) throw new Error(json.message || 'lookup-failed');
      const p = json.place;
      const pickedName = p.name || s.primary;
      businessSelectedRef.current = pickedName;
      setBusinessName(pickedName);
      setBusinessSuggestions([]);
      if (p.street) setAddress(p.street);
      if (p.city) setCity(p.city);
      if (p.zip) setZip(p.zip);
      if (p.id) setPlaceId(p.id);
      // Best-effort auto-fill contact from the business listing — only when the
      // field is empty, so we never clobber what the customer already typed.
      const filled: string[] = [];
      if (p.street || p.city || p.zip) filled.push('address');
      if (p.phone && !phone) {
        setPhone(maskPhone(p.phone));
        filled.push('phone');
      }
      if (p.email && !email && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(p.email.trim())) {
        setEmail(p.email.trim());
        filled.push('email');
      }
      setBusinessFilled(filled);
      const formatted =
        p.formatted || [p.street, p.city, p.state, p.zip].filter(Boolean).join(', ');
      if (formatted) setAddressQuery(formatted);
      // rotate session
      rotateBusinessSession();
    } catch {
      setBusinessError("Couldn't load that business. Try another or type it in.");
    } finally {
      setBusinessLoading(false);
    }
  }

  async function handleSaveQuote() {
    // Always generate a shareable link — no service picked just defaults to
    // 'other' (the body-builder below handles it), so the quote carries every
    // detail the customer HAS entered and never dead-ends on an empty scope.
    setQuoteSaving(true);
    setQuoteError('');
    setQuoteUrl('');
    try {
      const quoteServices: Service[] = services.length
        ? services
        : prefilledService && VALID_SERVICES.includes(prefilledService)
          ? [prefilledService]
          : ['other'];
      const res = await fetch('/api/quote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          services: quoteServices,
          hours,
          crew,
          zip: zip.slice(0, 10),
          city: city.slice(0, 120),
          notes: notes.slice(0, 1000),
          name: name.slice(0, 120),
          email: email.slice(0, 200),
          phone: phone.slice(0, 30),
          businessName: businessName.slice(0, 200),
          address: address.slice(0, 200),
          placeId: placeId.slice(0, 200),
          preferredDate: date,
          preferredTime: selectedSlot?.localTime ?? '',
          startAt: selectedSlot?.startAt ?? '',
          paymentMode,
          rentals: { trucks: truckPicks },
          rentalAcks: ([] as string[]),
          recurringPlan,
          recurringEndAfter: recurringEndAfter || undefined,
          recurringAutoPause,
          referralCode: pricing.referralValid ? referralCode.trim().toUpperCase() : undefined,
          extras,
          pricingBreakdown: {
            hourlyRate: pricing.hourlyRate,
            baseLabor: pricing.baseLabor,
            laborAfterDisc: pricing.laborAfterDisc,
            recurringDisc: pricing.recurringDisc,
            bundleDisc: pricing.bundleDisc,
            rush: pricing.rush,
            afterHours: pricing.afterHours,
            extrasFlat: pricing.extrasFlat,
            referralOff: pricing.referralOff,
            surge: pricing.surge,
            surgeMultiplier: pricing.surgeMultiplier,
            total: pricing.total,
          },
          // Full-state blob so a shared quote reopens the ENTIRE form — the AI
          // scope answers, concierge session, fair-market research, and recurring
          // options — not just the priced scope. Round-tripped via /api/quote.
          formState: {
            reviewAnswers,
            reviewText,
            fairMarket,
            aiSessionId: aiSessionId || undefined,
            recurringEndAfter: recurringEndAfter || undefined,
            recurringAutoPause,
          },
        }),
      });
      const data = (await res.json()) as { ok?: boolean; url?: string; message?: string };
      if (!data.ok || !data.url) throw new Error(data.message || 'save_failed');
      setQuoteUrl(data.url);
      track(FUNNEL.quoteSaved, { hours, crew, totalCents: chargeCents });
      try {
        await navigator.clipboard.writeText(data.url);
        setQuoteCopied(true);
        track(FUNNEL.quoteShared, { url: data.url });
        window.setTimeout(() => setQuoteCopied(false), 2500);
      } catch {
        /* clipboard blocked */
      }
    } catch {
      setQuoteError("Couldn't save quote. Try again.");
    } finally {
      setQuoteSaving(false);
    }
  }

  function buildAiSeedMessage(): string {
    const trucksList = truckPicks.length
      ? truckPicks.map((p) => `${p.qty}× ${rentalById(p.id)?.label || p.id}`).join(', ')
      : 'none';
    const extrasList =
      EXTRAS.filter((x) => extras.includes(x.id))
        .map((x) => x.label)
        .join(', ') || 'none';
    const serviceList = services.length ? services.join(', ') : 'unspecified';
    const addressLine = [address, city, zip].filter(Boolean).join(', ') || 'not provided';
    return [
      `Job summary from the booking form — confirm scope, ask a clarifying question if anything is unclear, then output the <quote> block with your fair fixed estimate.`,
      ``,
      `- Services: ${serviceList}`,
      `- Crew: ${crew} ${crew === 1 ? 'person' : 'people'}`,
      `- Hours requested: ${hours}h`,
      `- Date: ${date || 'TBD'} at ${selectedSlot?.localTime || 'TBD'}`,
      `- Address: ${addressLine}`,
      `- U-Hauls requested: ${trucksList}`,
      `- Extras: ${extrasList}`,
      `- Recurring plan: ${recurringPlan}`,
      `- Customer notes: ${notes || '(none)'}`,
      `- Form's computed total: $${total}`,
      ``,
      `Verify the math is fair given Newark market rates. Compare to the form total and call out any discrepancy.`,
    ].join('\n');
  }

  async function postToAi(userMessage: string) {
    setAiLoading(true);
    setAiError('');
    const next = [...aiTranscript, { role: 'user' as const, content: userMessage }];
    setAiTranscript(next);
    try {
      // ALWAYS lead the payload with a FRESH snapshot of the current form so the
      // concierge answers with LIVE state — even when the user edits crew / hours /
      // services / date / rentals / extras anywhere in the form after the chat was
      // seeded. buildAiSeedMessage() re-reads state at send time; the snapshot is
      // kept OUT of the visible transcript so the conversation stays clean.
      const liveContext = { role: 'user' as const, content: buildAiSeedMessage() };
      const res = await fetch('/api/ai-quote/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId: aiSessionId || undefined,
          messages: [liveContext, ...next.slice(-9)],
        }),
      });
      const data = (await res.json()) as {
        ok: boolean;
        sessionId?: string;
        reply?: string;
        quote?: AiQuoteStructured | null;
        error?: string;
      };
      if (!data.ok || typeof data.reply !== 'string') {
        throw new Error(data.error || 'AI quote failed.');
      }
      if (data.sessionId) setAiSessionId(data.sessionId);
      setAiTranscript([...next, { role: 'assistant', content: data.reply }]);
      if (data.quote) setAiQuote(data.quote);
    } catch (err) {
      setAiError(err instanceof Error ? err.message : 'AI quote failed.');
    } finally {
      setAiLoading(false);
    }
  }

  // Concierge-as-editor: parse the customer's message for a common booking change
  // (hours / crew) and apply it directly to the form state, returning a plain-text
  // confirmation. Returns null when there's no editable intent → falls through to
  // the AI concierge. The estimate + schedule update automatically off the state.
  function tryLocalBookingEdit(qRaw: string): string | null {
    const q = qRaw.toLowerCase();
    const clampH = (n: number) => Math.max(1, Math.min(12, n));
    const clampC = (n: number) => Math.max(1, Math.min(MAX_CREW, n));

    // "make it 3 hours" / "set it to 4 hours"
    let m = q.match(/(?:make it|change (?:it )?to|set (?:it )?to|do|book)\s*(\d{1,2})\s*(?:hour|hr)/);
    if (m && m[1]) {
      const n = clampH(parseInt(m[1], 10));
      if (n !== hours) {
        setHours(n);
        return `Done — updated to ${n} hour${n === 1 ? '' : 's'}. Your estimate on the left just updated.`;
      }
      return `You're already booked for ${hours} hours.`;
    }
    // add an hour ("can you make it one more hour?")
    if (/(one more hour|another hour|an? extra hour|add (?:a|an|one)? ?hour|one additional hour)/.test(q)) {
      const n = clampH(hours + 1);
      if (n !== hours) {
        setHours(n);
        return `You got it — bumped it to ${n} hours. Your estimate on the left just updated.`;
      }
      return `It's already at the 12-hour max I can set here.`;
    }
    // remove an hour
    if (/(one less hour|an hour less|one fewer hour|remove (?:a|an|one)? ?hour|drop (?:a|an)? ?hour|shorter by an hour)/.test(q)) {
      const n = clampH(hours - 1);
      if (n !== hours) {
        setHours(n);
        return `Done — dropped it to ${n} hour${n === 1 ? '' : 's'}. Estimate updated.`;
      }
      return `It's already at the 1-hour minimum.`;
    }
    // "make it 3 workers/people/pros"
    m = q.match(/(?:make it|change (?:it )?to|set (?:it )?to)\s*(\d{1,2})\s*(?:worker|person|people|pro|crew)/);
    if (m && m[1]) {
      const n = clampC(parseInt(m[1], 10));
      if (n !== crew) {
        setCrew(n as CrewSize);
        return `Done — set the crew to ${n} ${n === 1 ? 'person' : 'people'}. Estimate updated.`;
      }
      return `You're already set for a crew of ${crew}.`;
    }
    // add a worker
    if (/(one more (?:worker|person|pro|hand)|another (?:worker|person|pro|hand)|add (?:a|an|one)? ?(?:worker|person|pro|hand)|extra (?:worker|person|pro|hand))/.test(q)) {
      const n = clampC(crew + 1);
      if (n !== crew) {
        setCrew(n as CrewSize);
        return `Added a pro — the crew is now ${n}. Estimate updated.`;
      }
      return `That's already the largest crew I can add here.`;
    }
    // remove a worker
    if (/(one less (?:worker|person|pro)|remove (?:a|an|one)? ?(?:worker|person|pro)|drop (?:a|an)? ?(?:worker|person|pro)|one fewer (?:worker|person))/.test(q)) {
      const n = clampC(crew - 1);
      if (n !== crew) {
        setCrew(n as CrewSize);
        return `Done — the crew is now ${n} ${n === 1 ? 'person' : 'people'}. Estimate updated.`;
      }
      return `It's already a solo pro — that's the minimum.`;
    }
    return null;
  }

  function handleAskAi() {
    const q = aiInput.trim();
    if (!q || aiLoading) return;
    setAiInput('');
    const edit = tryLocalBookingEdit(q);
    if (edit) {
      setAiTranscript((t) => [
        ...t,
        { role: 'user', content: q },
        { role: 'assistant', content: edit },
      ]);
      return;
    }
    void postToAi(q);
  }

  function validateForm(): { field: string; label: string; message: string }[] {
    const errs: { field: string; label: string; message: string }[] = [];
    const firstTrim = firstName.trim();
    const lastTrim = lastName.trim();
    const emailTrim = email.trim();
    const phoneDigits = phone.replace(/\D/g, '');
    const addressTrim = address.trim();
    const cityTrim = city.trim();
    const zipTrim = zip.trim();
    if (!firstTrim || firstTrim.length < 2) {
      errs.push({
        field: 'bk-first-name',
        label: 'First name',
        message:
          'Add your first name (at least 2 characters) so the crew knows who to ask for on arrival.',
      });
    }
    if (!lastTrim || lastTrim.length < 2) {
      errs.push({
        field: 'bk-last-name',
        label: 'Last name',
        message:
          'Add your last name (at least 2 characters) — used for the booking confirmation and invoice.',
      });
    }
    if (!emailTrim || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(emailTrim)) {
      errs.push({
        field: 'bk-email',
        label: 'Email',
        message:
          'Add a working email — we send the confirmation, calendar invite, and receipt there.',
      });
    }
    if (phoneDigits.length < 10) {
      errs.push({
        field: 'bk-phone',
        label: 'Phone',
        message: 'Add a 10-digit US phone number — the crew texts updates day-of and en route.',
      });
    }
    if (!addressTrim || addressTrim.length < 4) {
      errs.push({
        field: 'bk-address',
        label: 'Address',
        message: 'Add the street address — we need it for routing and the dispatch ticket.',
      });
    }
    if (!cityTrim) {
      errs.push({
        field: 'bk-address',
        label: 'City',
        message: 'Pick a suggestion from the address dropdown so city auto-fills correctly.',
      });
    }
    if (zipTrim && !/^\d{5}(-\d{4})?$/.test(zipTrim)) {
      errs.push({
        field: 'bk-address',
        label: 'ZIP',
        message: 'ZIP looks off — should be 5 digits (or 5+4 like 07102-1234).',
      });
    }
    if (multiDayMode) {
      if (multiDates.length < 1) {
        errs.push({
          field: 'bk-date-label',
          label: 'Multi-day dates',
          message:
            'Pick at least one date on the calendar — multi-day mode is on. Toggle it off if you only want one day.',
        });
      } else {
        const bad = multiDates.filter((d) => {
          const dh = multiPerHours[d] ?? PER_DAY_DEFAULT_HOURS;
          const dc = multiPerCrew[d] ?? PER_DAY_DEFAULT_CREW;
          return dh <= 0 || dc < 1;
        });
        if (bad.length > 0) {
          errs.push({
            field: 'bk-date-label',
            label: 'Per-day crew + hours',
            message:
              'Each picked day needs at least 1 hour and 1 crew member. Adjust the per-day controls.',
          });
        }
      }
    } else if (!date) {
      errs.push({
        field: 'bk-date-label',
        label: 'Date',
        message: 'Pick a date on the calendar — every job needs a target day.',
      });
    }
    if (!acknowledged) {
      errs.push({
        field: 'bk-acknowledge',
        label: 'Acknowledgement',
        message:
          'Tick the acknowledgement box — confirms you understand the flat $50/hr-per-person rate and the deposit terms.',
      });
    }
    if (truckPicks.length > 0 && !rentalAcksSatisfied(rentalRisk, ([] as string[]))) {
      errs.push({
        field: 'rental-risk-disclosure',
        label: 'Rental terms',
        message:
          'Accept every U-Haul rental term — a truck rental needs the deposit + damage, fuel, mileage, and return terms acknowledged before we can dispatch.',
      });
    }
    return errs;
  }

  function summarizeTopErrors(errs: { field: string; label: string; message: string }[]): string {
    if (errs.length === 0) return '';
    const labels = errs.slice(0, 3).map((e) => e.label.toLowerCase());
    const [a, b, c] = labels;
    const first = errs[0];
    if (errs.length === 1 && first) {
      return `${first.label} needs a fix before we can book the crew.`;
    }
    if (errs.length === 2 && a && b) {
      return `${capitalize(a)} and ${b} need attention before we can dispatch.`;
    }
    if (errs.length === 3 && a && b && c) {
      return `${capitalize(a)}, ${b}, and ${c} need attention before we can dispatch the crew.`;
    }
    if (a && b && c) {
      const extra = errs.length - 3;
      return `${capitalize(a)}, ${b}, ${c}, and ${extra} more field${extra === 1 ? '' : 's'} need attention before we can dispatch the crew.`;
    }
    return 'Some fields need attention before we can dispatch the crew.';
  }

  function capitalize(s: string): string {
    if (s.length === 0) return s;
    return s.charAt(0).toUpperCase() + s.slice(1);
  }

  function scrollToField(fieldId: string) {
    if (typeof document === 'undefined') return;
    const el = document.getElementById(fieldId);
    if (!el) return;
    const headerOffset = 96;
    const rect = el.getBoundingClientRect();
    const top = rect.top + window.scrollY - headerOffset;
    window.scrollTo({ top, behavior: 'smooth' });
    if (typeof el.focus === 'function') {
      try {
        el.focus({ preventScroll: true });
      } catch {
        /* noop */
      }
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const errs = validateForm();
    const firstErr = errs[0];
    if (errs.length > 0 && firstErr) {
      setValidationErrors(errs);
      setSubmitError('');
      scrollToField(firstErr.field);
      return;
    }
    setValidationErrors([]);
    setSubmitting(true);
    setSubmitError('');
    try {
      const extrasLabels = EXTRAS.filter((x) => extras.includes(x.id)).map((x) => x.label);
      const upsellNote: string[] = [];
      if (extrasLabels.length) upsellNote.push(`Extras requested: ${extrasLabels.join(', ')}.`);
      if (recurringPlan !== 'one-time') upsellNote.push(`Recurring plan: ${recurringPlan}.`);
      if (subMode) {
        // Record the FULL final subscription state so the operator + charge have
        // the exact schedule the customer confirmed (edit-popover changes included).
        const cadence = isDateBasedFrequency(subFrequency)
          ? `${FREQUENCY_LABELS[subFrequency]} on the ${new Date((date || subFirstVisit) + 'T12:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}`
          : `${FREQUENCY_LABELS[subFrequency]} — ${summarizeWeekdays(subscriptionWeekdays)}`;
        const price =
          subVisitsPerPeriod > 1
            ? `$${fmtMoney(subPerPeriodCents)}/${periodNoun(subFrequency)}`
            : `$${fmtMoney(subPerVisitCents)}/visit`;
        upsellNote.push(
          `Subscription: ${cadence}; ${crew} worker${crew === 1 ? '' : 's'} × ${hours}h at ${subscriptionStartTime}; starts ${subFirstVisit || date}; ${recurringEndAfter > 0 ? `${recurringEndAfter} visits` : 'ongoing'}; ${price}${subProrated ? ` (first charge pro-rated $${fmtMoney(subFirstChargeCents)})` : ''}.`,
        );
        // Record any per-visit customizations the customer set on the schedule chart
        // so the crew sees exactly what changed on which visit (final confirmed state).
        const customVisits = Object.entries(subVisitOverrides)
          .filter(([iso]) => visitIsCustom(iso))
          .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
          .map(([iso, o]) => {
            const opts: Intl.DateTimeFormatOptions =
              subFrequency === 'yearly'
                ? { month: 'short', day: 'numeric', year: 'numeric' }
                : { month: 'short', day: 'numeric' };
            const label = new Date(iso + 'T12:00:00').toLocaleDateString('en-US', opts);
            const idx = subVisitDates.indexOf(iso);
            return `${idx >= 0 ? `#${idx + 1} ` : ''}${label}: ${o.crew} worker${o.crew === 1 ? '' : 's'} × ${o.hours}h at ${o.startTime}`;
          });
        if (customVisits.length) {
          upsellNote.push(`Custom visits — ${customVisits.join('; ')}.`);
        }
      }
      if (services.length) upsellNote.push(`Services: ${services.join(', ')}.`);
      if (pricing.rush > 0) upsellNote.push(`Same-day priority +$${pricing.rush}.`);
      if (pricing.afterHours > 0)
        upsellNote.push(`${pricing.premiumReason} +$${pricing.afterHours}.`);
      if (pricing.referralValid)
        upsellNote.push(
          `Referral code ${referralCode.trim().toUpperCase()} −$${pricing.referralOff}.`,
        );
      const reviewQA: string[] = [];
      for (const q of reviewQuestions) {
        if (q.inputType === 'text' || q.inputType === 'textarea') {
          const raw = (reviewText[q.id] ?? '').trim();
          if (!raw) continue;
          reviewQA.push(`Q: ${q.question}\nA: ${raw}`);
          continue;
        }
        const picked = reviewAnswers[q.id] ?? [];
        if (!picked.length) continue;
        const labels = q.options.filter((o) => picked.includes(o.id)).map((o) => o.label);
        if (!labels.length) continue;
        reviewQA.push(`Q: ${q.question}\nA: ${labels.join(', ')}`);
      }
      if (reviewUpsellCents > 0)
        upsellNote.push(`AI review upsells +$${Math.round(reviewUpsellCents / 100)}.`);
      const reviewBlock = reviewQA.length ? `\n\n— AI Review —\n${reviewQA.join('\n')}` : '';
      const notesWithUpsells =
        upsellNote.length || reviewBlock
          ? `${notes ? notes + '\n\n' : ''}${upsellNote.join(' ')}${reviewBlock}`
          : notes;
      const submitServices: Service[] = services.length
        ? services
        : prefilledService && VALID_SERVICES.includes(prefilledService)
          ? [prefilledService]
          : [];

      const isMultiDay = multiDayMode && multiDates.length >= 1;
      const baseIdem = getOrCreateIdempotencyKey();

      function buildPayload(
        dayDate: string,
        dayHours: number,
        dayCrew: number,
        idemSuffix: string,
      ) {
        return {
          name,
          email,
          phone,
          businessName,
          address,
          city,
          zip,
          // OSM place ids are base64-encoded features (can exceed the server's
          // 200-char cap → 400). Clamp defensively; the value is only a lookup ref.
          placeId: placeId.slice(0, 200),
          notes: notesWithUpsells,
          preferredDate: dayDate,
          preferredTime: subMode
            ? subscriptionStartTime
            : dayDate === date
              ? (selectedSlot?.localTime ?? 'flexible')
              : 'flexible',
          startAt: subMode ? '' : dayDate === date ? (selectedSlot?.startAt ?? '') : '',
          hours: dayHours,
          crew: dayCrew,
          services: submitServices,
          source: utmSource.slice(0, 40),
          paymentMode: isMultiDay ? 'none' : paymentMode === 'later' ? 'none' : paymentMode,
          prepay: !isMultiDay && paymentMode === 'full',
          smsOptIn,
          emailOptIn,
          marketingSmsOptIn,
          turnstileToken,
          rentals: { trucks: truckPicks },
          rentalAcks: ([] as string[]),
          idempotencyKey: idemSuffix ? `${baseIdem}:${idemSuffix}` : baseIdem,
          dubId: getDubId() || undefined,
          // Customer's booking locale (from the `/es|/pt` URL prefix) so the
          // confirmation email + its /track link land an es/pt customer
          // in-language. SSR → 'en'; same source as the chrome + city hrefs.
          locale:
            typeof window === 'undefined'
              ? 'en'
              : stripLocalePrefix(window.location.pathname).locale,
          recurringPlan,
          recurringEndAfter: recurringEndAfter || undefined,
          recurringAutoPause,
          referralCode: pricing.referralValid ? referralCode.trim().toUpperCase() : undefined,
          couponCode: couponFormatOk ? normalizeCouponCode(couponCode) : undefined,
          extras,
          // §bundle — server validates the slug + price against canonical
          // BUNDLES in src/shared/bundles.mjs and locks payment_mode = 'full'.
          bundleSlug: bundle?.slug,
          totalCents: bundle ? bundle.priceCents : chargeCents,
          pricingBreakdown: {
            hourlyRate: pricing.hourlyRate,
            baseLabor: pricing.baseLabor,
            laborAfterDisc: pricing.laborAfterDisc,
            recurringDisc: pricing.recurringDisc,
            bundleDisc: pricing.bundleDisc,
            rush: pricing.rush,
            afterHours: pricing.afterHours,
            extrasFlat: pricing.extrasFlat,
            referralOff: pricing.referralOff,
            surge: pricing.surge,
            surgeMultiplier: pricing.surgeMultiplier,
            total: pricing.total,
          },
        };
      }

      if (isMultiDay) {
        const sortedDates = [...multiDates].sort();
        const results = await Promise.all(
          sortedDates.map(async (d) => {
            const dh = multiPerHours[d] ?? PER_DAY_DEFAULT_HOURS;
            const dc = multiPerCrew[d] ?? PER_DAY_DEFAULT_CREW;
            let r: Response;
            try {
              r = await fetch('/api/booking', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(buildPayload(d, dh, dc, d)),
              });
            } catch {
              // A network throw on ONE date must not reject the whole Promise.all
              // (which would mask the per-date outcome + orphan any dates that DID
              // succeed). Resolve this leg as failed with an honest message.
              return { date: d, ok: false, message: bookingSubmitError(0, null), bookingId: undefined };
            }
            // Guard res.ok + non-JSON (CF-edge 5xx returns HTML → r.json() throws).
            const j = (await r.json().catch(() => null)) as {
              ok?: boolean;
              message?: string;
              bookingId?: string;
              error?: string;
              requestId?: string;
            } | null;
            if (!r.ok || !j?.ok) {
              return { date: d, ok: false, message: bookingSubmitError(r.status, j), bookingId: undefined };
            }
            return { date: d, ok: true, message: j.message, bookingId: j.bookingId };
          }),
        );
        const failed = results.filter((r) => !r.ok);
        if (failed.length > 0) {
          throw new Error(
            failed[0]?.message ??
              `${failed.length} of ${results.length} day(s) failed — try again or call (855) 82LABOR.`,
          );
        }
        const ids = results.map((r) => r.bookingId).filter((id): id is string => Boolean(id));
        track(FUNNEL.submitted, {
          hours: multiDates.reduce((s, d) => s + (multiPerHours[d] ?? PER_DAY_DEFAULT_HOURS), 0),
          crew,
          totalCents: chargeCents,
          paymentMode: 'later',
          source: utmSource,
          multiDayCount: sortedDates.length,
        });
        setBookingIds(ids);
        setBookingId(ids[0] ?? '');
        try {
          localStorage.removeItem(DRAFT_KEY);
        } catch {
          /* noop */
        }
        rotateIdempotencyKey();
        setStep('success');
      } else {
        const res = await fetch('/api/booking', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(buildPayload(date, hours, crew, '')),
        });
        // Guard res.ok + non-JSON: a CF-edge 5xx returns HTML (res.json() throws),
        // and the worker's 500 envelope is {error, requestId} (no `message`/`ok`).
        // bookingSubmitError surfaces the real reason + requestId instead of a
        // generic "Something went wrong" (which also dropped the support ref id).
        const data = (await res.json().catch(() => null)) as {
          ok?: boolean;
          message?: string;
          checkoutUrl?: string;
          bookingId?: string;
          couponError?: string;
          couponApplied?: { code: string; offCents: number };
          error?: string;
          requestId?: string;
        } | null;
        if (!res.ok || !data?.ok) throw new Error(bookingSubmitError(res.status, data));
        // Soft-warn: booking still went through. Surfaces in the coupon
        // fieldset rather than blocking the success view.
        setCouponServerError(data.couponError ?? '');
        track(FUNNEL.submitted, {
          hours,
          crew,
          totalCents: chargeCents,
          paymentMode,
          source: utmSource,
        });
        if (data.bookingId) {
          setBookingId(data.bookingId);
          setBookingIds([data.bookingId]);
        }
        if (data.checkoutUrl) {
          // Revenue conversion signal — carry the GA4/PostHog-standard shape
          // (`value` in major units + `currency` + `transaction_id`) so revenue
          // analytics attribute the dollar amount, not just a bare count. Keep
          // `totalCents`/`paymentMode` for the existing operator funnel reports.
          track(FUNNEL.paid, {
            value: total,
            currency: 'USD',
            transaction_id: data.bookingId,
            totalCents: chargeCents,
            paymentMode,
          });
          window.location.href = data.checkoutUrl;
          return;
        }
        try {
          localStorage.removeItem(DRAFT_KEY);
        } catch {
          /* noop */
        }
        rotateIdempotencyKey();
        setStep('success');
      }
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : 'Something went wrong');
    } finally {
      setSubmitting(false);
    }
  }

  const bookingSurfaceProps = useThemeToolsSurface('booking-flow', [
    '@theme.tools/ui',
    '@theme.tools/scheduling',
    '@theme.tools/forms',
    '@theme.tools/billing',
  ]);
  const bookingStandardPricing = evaluateHourlyLaborPricingStandard({
    crewSize: crew,
    hours,
    cadence: 'one-time',
  });
  const bookingCoiReadiness = evaluateBuildingCoiReadiness({
    buildingType: 'walkup',
  });

  return (
    <section
      id="book"
      data-testid="booking-form"
      className="section"
      ref={sectionRef}
      data-theme-tools-surface={bookingSurfaceProps['data-theme-tools-surface']}
      data-theme-tools-pricing-model={bookingSurfaceProps['data-theme-tools-pricing-model']}
      data-theme-tools-packages={bookingSurfaceProps['data-theme-tools-packages']}
      data-standard-rate-cents={bookingStandardPricing.hourlyRatePerPersonCents}
      data-coi-required={bookingCoiReadiness.requiresCoi ? '1' : '0'}
      data-booking-step={step}
      data-bcl-hours={hours}
      data-bcl-crew={crew}
      data-bcl-total-cents={chargeCents}
      data-bcl-total-dollars={pricing.total}
      data-bcl-services={services.join(',')}
      data-bcl-rush-cents={pricing.rush * 100}
      data-bcl-after-hours-cents={pricing.afterHours * 100}
      data-bcl-surge-cents={pricing.surge * 100}
      data-bcl-surge-multiplier={pricing.surgeMultiplier}
      data-bcl-surge-reasons={pricing.surgeReasons.map((r) => r.kind).join(',')}
      data-bcl-referral-valid={pricing.referralValid ? '1' : '0'}
      data-bcl-recurring-disc-pct={pricing.recurringDisc}
      data-bcl-bundle-disc-pct={pricing.bundleDisc}
      data-bcl-payment-mode={paymentMode}
      data-bcl-recurring={recurringPlan}
    >
      <div className="container-pad">
        <div className="mb-12 max-w-3xl" data-animate="fade-up">
          <p className="eyebrow mb-3">{formCopy.eyebrow}</p>
          <h1 className="text-[clamp(2rem,6vw,3.25rem)] font-extrabold leading-[1.05] [text-wrap:balance]">
            {formCopy.headlineMain} <span className="text-gradient">{formCopy.headlineAccent}</span>
          </h1>
          <p className="mt-4 text-[clamp(1rem,2.2vw,1.2rem)] text-brand-mute [text-wrap:pretty]">
            {formCopy.lede}
          </p>
        </div>

        <div className="mb-6 max-w-3xl">
          <CancellationPolicy
            dateTime={
              selectedSlot?.startAt ||
              (date && selectedSlot?.localTime
                ? `${date}T${selectedSlot.localTime}`
                : date || undefined)
            }
          />
        </div>

        {/* Returning-customer one-tap rebook — flag-gated (one_tap_rebook),
            renders null when off OR when the typed email isn't a recognized
            returning customer with a saved card. Fed the live form email so
            "Book again, one tap" surfaces the moment a known customer types
            their address; only fetches on a complete valid email (no
            per-keystroke calls). */}
        <div className="mb-6 max-w-3xl">
          <OneTapRebook
            customerEmail={
              /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim()) ? email.trim() : ''
            }
            onRebooked={(id) => {
              window.location.href = lpHref(`/track/${id}`);
            }}
          />
        </div>

        {/* Contact-lock quote gate — flag-gated (contact_lock_quote_gate),
            default OFF → renders null (represented, not active). When ON it
            shows ONLY before the customer has identified themselves and only
            once a service is picked (so there's a real estimate to blur behind
            the gate). Unlocking pre-fills the form contact fields + fires the
            lead-capture analytics event, then hides for the session. Pure
            display — no backend. */}
        {contactLockFlag && !quoteUnlocked && step !== 'success' && services.length > 0 && (
          <div className="mb-6 max-w-3xl">
            <ContactLock
              initial={{ firstName, lastName, email, phone }}
              previewTotalCents={chargeCents}
              onUnlock={(v) => {
                setFirstName(v.firstName);
                setLastName(v.lastName);
                setEmail(v.email);
                setPhone(v.phone);
                setQuoteUnlocked(true);
              }}
            />
          </div>
        )}

        {step === 'success' ? (
          <div className="card max-w-2xl mx-auto space-y-6 py-10 px-6 bk-success-pop">
            {paymentReturn.current && (
              <div
                role="status"
                className="flex items-center gap-2 rounded-lg border border-green-500/40 bg-green-500/10 px-4 py-3 text-sm font-semibold text-green-300"
              >
                <span aria-hidden>💳</span>
                {confirmCopy.paymentReceived(paymentReturn.current.fullyPaid)}
              </div>
            )}
            <div className="text-center space-y-3">
              <div className="flex justify-center">
                <SuccessCheck
                  size={72}
                  label={confirmCopy.bookedTitle}
                  className="drop-shadow-[0_0_18px_rgba(74,222,128,0.35)]"
                />
              </div>
              <h3 className="text-2xl font-extrabold">
                {bookingIds.length > 1
                  ? confirmCopy.bookedTitleDays(bookingIds.length)
                  : confirmCopy.bookedTitle}
              </h3>
              <p className="text-brand-mute">
                {bookingIds.length > 1
                  ? confirmCopy.bodyMulti(bookingIds.length)
                  : confirmCopy.bodySingle}
              </p>
            </div>

            {/* Apple Pay / Google Pay express checkout — flag-gated
                (apple_google_pay_express), default OFF → renders null. When ON
                it shows the native wallet button on supported devices (iOS Safari
                Apple Pay, Chrome Google Pay) for totals >= $50. Two-tap booking
                completion via Stripe PaymentRequest API. */}
            {appleGooglePayFlag && bookingId && (
              <ApplePayGooglePayButtons
                bookingId={bookingId}
                totalCents={chargeCents}
                customerEmail={email}
              />
            )}

            {bookingIds.length > 1 && (
              <div className="rounded-lg border border-brand-line bg-bg-primary/40 p-4 space-y-2">
                <p className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
                  {confirmCopy.allBookings(bookingIds.length)}
                </p>
                <ul className="space-y-1 text-sm">
                  {bookingIds.map((id, idx) => (
                    <li key={id} className="flex items-center gap-2 font-mono text-xs">
                      <span className="text-brand-mute">
                        {confirmCopy.dayLabel} {idx + 1}
                      </span>
                      <a
                        href={lpHref(`/track/${id}`)}
                        className="text-brand-accent underline-hover break-all"
                      >
                        /track/{id}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="rounded-lg border border-brand-accent/40 bg-brand-accent/5 p-5 space-y-3">
              <p className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
                {confirmCopy.statusHeading}
              </p>
              <ol className="space-y-2 text-sm text-brand-ink list-decimal pl-5">
                <li>
                  <strong>{confirmCopy.liveTrackingTitle(bookingIds.length > 1)}</strong> —{' '}
                  {confirmCopy.bookmark(bookingIds.length > 1)}:{' '}
                  {bookingId ? (
                    <a
                      href={lpHref(`/track/${bookingId}`)}
                      className="text-brand-accent underline-hover font-mono break-all"
                    >
                      /track/{bookingId}
                    </a>
                  ) : (
                    <span className="text-brand-mute font-mono">/track/&lt;id&gt;</span>
                  )}
                  {confirmCopy.trackDesc}
                </li>
                <li>
                  <strong>{confirmCopy.yourDashboard}</strong> —{' '}
                  <a href={lpHref('/me')} className="text-brand-accent underline-hover">
                    /me
                  </a>{' '}
                  {confirmCopy.dashboardDesc}
                </li>
                <li>
                  <strong>{confirmCopy.smsReply}</strong> — {confirmCopy.smsReplyPre}{' '}
                  <a href={PHONE_SMS_HREF} className="text-brand-accent underline-hover">
                    (855) 82LABOR
                  </a>{' '}
                  {confirmCopy.smsReplyPost}
                </li>
              </ol>
              {bookingId && (
                <div className="flex flex-wrap gap-2 pt-2">
                  <a
                    href={lpHref(`/track/${bookingId}`)}
                    className="inline-flex items-center gap-2 rounded-md border border-brand-accent bg-brand-accent px-3.5 py-1.5 text-bg-primary font-mono text-[11px] uppercase tracking-wider hover:bg-brand-accent/90"
                  >
                    {confirmCopy.trackThisGig}
                  </a>
                  <a
                    href={lpHref('/me')}
                    className="inline-flex items-center gap-2 rounded-md border border-brand-line px-3.5 py-1.5 text-brand-ink font-mono text-[11px] uppercase tracking-wider hover:border-brand-accent hover:text-brand-accent"
                  >
                    {confirmCopy.myDashboard}
                  </a>
                  <button
                    type="button"
                    onClick={async () => {
                      try {
                        const url = `${window.location.origin}/track/${bookingId}`;
                        await navigator.clipboard.writeText(url);
                        // Claim "copied" only when the write actually succeeded (WCAG 4.1.3).
                        setTrackLinkCopied(true);
                        window.setTimeout(() => setTrackLinkCopied(false), 2500);
                      } catch {
                        /* clipboard blocked (private mode / no permission) — leave label unchanged */
                      }
                    }}
                    data-testid="confirm-copy-link"
                    className="inline-flex items-center gap-2 rounded-md border border-brand-line px-3.5 py-1.5 text-brand-mute font-mono text-[11px] uppercase tracking-wider hover:border-brand-accent hover:text-brand-accent"
                  >
                    {trackLinkCopied ? confirmCopy.linkCopied : confirmCopy.copyLink}
                  </button>
                  <span className="sr-only" role="status" aria-live="polite">
                    {trackLinkCopied ? confirmCopy.linkCopied : ''}
                  </span>
                </div>
              )}
            </div>

            {postBookingUpsellFlag && bookingId ? (
              <PostBookingUpsell
                bookingId={bookingId}
                crew={crew}
                existingServices={services}
              />
            ) : null}

            {showWelcome ? <CustomerOnboardingVideo /> : null}

            <p className="text-center text-sm text-brand-mute">
              {confirmCopy.questionsCall}{' '}
              <a href={PHONE_TEL_HREF} className="text-brand-accent underline-hover">
                (855) 82LABOR
              </a>{' '}
              {confirmCopy.questionsOr}{' '}
              <a href={lpHref('/contact')} className="text-brand-accent underline-hover">
                {confirmCopy.sendMessage}
              </a>
              .
            </p>
          </div>
        ) : (
          <div className="grid lg:grid-cols-3 gap-6">
            <aside className="card space-y-5 lg:sticky lg:top-24 self-start">
              <div>
                <div className="font-mono text-xs uppercase tracking-widest text-brand-accent">
                  {estCopy.estimate}
                </div>
                <div className="mt-2 flex items-baseline gap-1">
                  <span className="font-display text-5xl font-extrabold">
                    ${fmtMoney(pricing.subtotalCents)}
                  </span>
                  <span className="text-brand-mute">{subMode && subVisitDates.length > 0 ? '/ visit' : estCopy.est}</span>
                </div>
                {subMode && subVisitDates.length > 0 && (
                  <div className="mt-1.5 space-y-0.5 text-xs">
                    <div className="font-mono">
                      <span className="font-bold text-brand-accent">${fmtMoney(subPerPeriodCents)}</span>
                      <span className="text-brand-mute"> / {periodNoun(subFrequency)}</span>
                      {subVisitsPerPeriod > 1 && (
                        <span className="text-brand-mute"> · {subVisitsPerPeriod} visits</span>
                      )}
                    </div>
                    <div className="text-[11px] text-brand-mute">
                      {subProrated ? (
                        <>
                          First charge (pro-rated):{' '}
                          <span className="font-mono font-bold text-brand-ink">${fmtMoney(subFirstChargeCents)}</span>{' '}
                          — {subFirstPeriodVisits} visit{subFirstPeriodVisits === 1 ? '' : 's'} this first {periodNoun(subFrequency)}.
                        </>
                      ) : (
                        <>First charge: <span className="font-mono font-bold text-brand-ink">${fmtMoney(subFirstChargeCents)}</span>.</>
                      )}
                    </div>
                  </div>
                )}
                <div className="mt-3 space-y-1 rounded-md border border-brand-line bg-bg-primary/60 px-3 py-2 text-xs font-mono">
                  {pricing.isMulti ? (
                    <>
                      {pricing.perDay.map((p) => {
                        const dt = new Date(p.date + 'T12:00:00');
                        const label = dt.toLocaleDateString(
                          bookingLocale === 'es' ? 'es-US' : bookingLocale === 'pt' ? 'pt-BR' : 'en-US',
                          { weekday: 'short', month: 'short', day: 'numeric' },
                        );
                        return (
                          <div key={p.date} className="flex justify-between text-brand-mute">
                            <span className="truncate pr-2">
                              {label} · {p.crew} {estCopy.crew} × {p.hours}h
                            </span>
                            <span>${fmtMoney(p.cents)}</span>
                          </div>
                        );
                      })}
                      <div className="flex justify-between border-t border-brand-line/40 pt-1 text-brand-ink/80">
                        <span>
                          {estCopy.laborSubtotal} · {pricing.perDay.length}{' '}
                          {pricing.perDay.length === 1 ? estCopy.day : estCopy.days}
                        </span>
                        <span>${fmtMoney(pricing.baseLaborCents)}</span>
                      </div>
                    </>
                  ) : services.length >= 2 ? (
                    <>
                      {serviceSectionLabels(
                        services,
                        Object.fromEntries(SERVICE_TILES.map((t) => [t.id, t.label])),
                        bookingLocale,
                      ).map(({ id, label }) => (
                        <div key={id} className="flex justify-between text-brand-mute">
                          <span className="truncate pr-2">{label}</span>
                          <span className="shrink-0 text-brand-ink/60 text-xs self-center">
                            {hours}h × {crew}
                          </span>
                        </div>
                      ))}
                      <div className="flex justify-between border-t border-brand-line/30 pt-1 text-brand-mute">
                        <span>
                          {estCopy.labor} · ${pricing.hourlyRate}/hr
                        </span>
                        <span>${fmtMoney(pricing.baseLaborCents)}</span>
                      </div>
                    </>
                  ) : (
                    <div className="flex justify-between text-brand-mute">
                      <span>
                        {estCopy.labor} · {hours}h × {crew} × ${pricing.hourlyRate}
                      </span>
                      <span>${fmtMoney(pricing.baseLaborCents)}</span>
                    </div>
                  )}
                  {pricing.bundleDisc > 0 && pricing.recurringDisc > 0 ? (
                    // Both levers stack — itemize each so the customer sees exactly
                    // how much the multi-service bundle vs the recurring contract
                    // each save them (the recurring row makes the standing-discount
                    // upsell value concrete). The two rows sum to the charged saving.
                    <>
                      <div className="flex justify-between text-emerald-300/90">
                        <span>
                          − {pricing.bundleDisc}% {estCopy.discBundle}
                        </span>
                        <span>−${fmtMoney(pricing.bundleSavedCents)}</span>
                      </div>
                      <div className="flex justify-between text-emerald-300/90">
                        <span>
                          − {pricing.recurringDisc}% {estCopy.discRecurring}
                        </span>
                        <span>−${fmtMoney(pricing.recurringSavedCents)}</span>
                      </div>
                    </>
                  ) : pricing.totalDiscPct > 0 ? (
                    <div className="flex justify-between text-emerald-300/90">
                      <span>
                        − {pricing.totalDiscPct}%{' '}
                        {pricing.bundleDisc > 0 ? estCopy.discBundle : estCopy.discRecurring}
                      </span>
                      <span>−${fmtMoney(pricing.laborSavedCents)}</span>
                    </div>
                  ) : null}
                  {rentalLines.map((l) => (
                    <div key={l.id} className="flex justify-between text-brand-mute">
                      <span className="truncate pr-2">{l.label}</span>
                      <span>${l.price}/day</span>
                    </div>
                  ))}
                  {pricing.rush > 0 && (
                    <div className="flex justify-between text-amber-300/90">
                      <span>{estCopy.sameDayPriority}</span>
                      <span>+${fmtMoney(pricing.rushCents)}</span>
                    </div>
                  )}
                  {pricing.afterHours > 0 && (
                    <div className="flex justify-between text-amber-300/90">
                      <span>
                        {premiumReasonLabel(
                          {
                            isSunday: pricing.premiumIsSunday,
                            isSlotAfterHours: pricing.premiumIsAfterHours,
                          },
                          bookingLocale,
                        )}
                      </span>
                      <span>+${fmtMoney(pricing.afterHoursCents)}</span>
                    </div>
                  )}
                  {pricing.extrasFlat > 0 && (
                    <div className="flex justify-between text-brand-mute">
                      <span>{estCopy.addOns}</span>
                      <span>+${fmtMoney(pricing.extrasFlatCents)}</span>
                    </div>
                  )}
                  {pricing.referralOff > 0 && (
                    <div className="flex justify-between text-emerald-300/90">
                      <span>
                        {estCopy.referral} {referralCode.trim().toUpperCase()}
                      </span>
                      <span>−${fmtMoney(pricing.referralOffCents)}</span>
                    </div>
                  )}
                  {pricing.surge > 0 && (
                    <div className="flex justify-between text-amber-300/90 my-1.5">
                      <span>
                        {estCopy.demandSurge} +{Math.round((pricing.surgeMultiplier - 1) * 100)}%
                        {pricing.surgeReasons.length > 0 && (
                          <span
                            className="ml-2 inline-flex flex-wrap gap-1 align-middle lg:ml-0 lg:mt-[5px] lg:mb-[5px] lg:flex"
                            aria-label={estCopy.surgeReasonsAria}
                          >
                            {pricing.surgeReasons.map((r) => (
                              <span
                                key={r.kind}
                                className="rounded-full border border-amber-300/30 bg-amber-300/10 px-2 py-0.5 text-[10px] font-medium text-amber-200 transition-colors duration-[333ms] hover:bg-amber-300/20"
                              >
                                {surgeReasonLabel(r, bookingLocale)}
                              </span>
                            ))}
                          </span>
                        )}
                      </span>
                      <span>+${fmtMoney(pricing.surgeAddedCents)}</span>
                    </div>
                  )}
                  {pricing.surgeSkip && !multiDayMode && (
                    // One-tap "skip the surge" — the nudge USED to be a static
                    // note that told the customer a cheaper day exists but made
                    // them hunt the calendar for it. It now APPLIES the cheaper
                    // date on tap (the suggestion already carries preferredDate),
                    // dropping the surge for them. setDate refetches that day's
                    // slots + clears the now-stale slot via the [date,hours]
                    // effect, so they just re-pick a time. CX + revenue: less
                    // friction to take the cheaper slot smooths supply AND lifts
                    // conversion. Single-day only — multi-day pricing never uses
                    // the single-date surge, so the nudge is irrelevant there.
                    <button
                      type="button"
                      onClick={() => {
                        const next = pricing.surgeSkip!.preferredDate;
                        track('surge_skip_applied', {
                          from: date,
                          to: next,
                          savedCents: pricing.surgeSkip!.savedCents,
                        });
                        selectSingleDate(next); // setDate + clear slot + mirror multiDates + seed
                      }}
                      data-bcl-surge-skip={pricing.surgeSkip.preferredDate}
                      data-bcl-surge-skip-apply=""
                      className="group my-1.5 flex w-full items-start gap-2 rounded-lg border border-emerald-400/25 bg-emerald-400/10 px-3 py-2 text-left text-emerald-200 transition-all duration-[333ms] hover:-translate-y-0.5 hover:border-emerald-400/50 hover:bg-emerald-400/15 hover:shadow-[0_4px_16px_-6px_rgba(16,185,129,0.5)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/70 focus-visible:ring-offset-2 focus-visible:ring-offset-bg-primary motion-reduce:transition-none motion-reduce:hover:translate-y-0"
                      aria-label={`Apply cheaper date — book ${pricing.surgeSkip.label} to skip the surge and save $${fmtMoney(pricing.surgeSkip.savedCents)}`}
                    >
                      <span
                        aria-hidden="true"
                        className="mt-0.5 shrink-0 text-emerald-300 transition-transform duration-[333ms] group-hover:translate-x-0.5 motion-reduce:transition-none"
                      >
                        ↘
                      </span>
                      <span className="text-[11px] leading-snug">
                        Book{' '}
                        <span className="font-semibold text-emerald-100">
                          {pricing.surgeSkip.label}
                        </span>{' '}
                        to skip the surge and save{' '}
                        <span className="font-semibold text-emerald-100">
                          ${fmtMoney(pricing.surgeSkip.savedCents)}
                        </span>
                        .{' '}
                        <span className="font-semibold text-emerald-100 underline decoration-emerald-400/40 underline-offset-2 group-hover:decoration-emerald-300">
                          Tap to apply →
                        </span>
                      </span>
                    </button>
                  )}
                  {(() => {
                    // §book-canonical hotfix (2026-05-29) — when `date` is
                    // empty (initial state, no draft / prefill), parsing an
                    // empty `date` yields Invalid Date and `.toISOString()`
                    // throws RangeError. Skip the card entirely until the
                    // customer picks a valid YYYY-MM-DD.
                    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return null;
                    // "Tomorrow" for a calendar date is timezone-independent —
                    // anchor at midnight UTC + bump one UTC day, never a fixed
                    // Eastern offset (the DST clock-bomb class gated by
                    // scripts/validate-no-fixed-et-offset.mjs).
                    const parsed = new Date(`${date}T00:00:00Z`);
                    if (Number.isNaN(parsed.getTime())) return null;
                    const tomorrow = new Date(parsed);
                    tomorrow.setUTCDate(tomorrow.getUTCDate() + 1);
                    const tomorrowIso = tomorrow.toISOString().slice(0, 10);
                    return (
                      <>
                        <SameDayPricingCard
                          context={{
                            preferredDate: date,
                            preferredTime: selectedSlot?.localTime,
                            startAt: selectedSlot?.startAt,
                            services,
                          }}
                          subtotalDollars={pricing.preSurge}
                          tomorrowIso={tomorrowIso}
                          onSwitchToTomorrow={() => {
                            // selectSingleDate: setDate + clear slot + mirror multiDates + seed
                            // (the one-time calendar highlights multiDates, not date).
                            selectSingleDate(tomorrowIso);
                            track('booking_switched_to_tomorrow', {
                              from_date: date,
                              to_date: tomorrowIso,
                              savings_cents: pricing.surgeAddedCents,
                            });
                          }}
                          onOpenWhy={() => {
                            setSurgeWhyOpen(true);
                            track('surge_why_opened', { date });
                          }}
                        />
                        <SurgeExplainerModal
                          open={surgeWhyOpen}
                          onClose={() => setSurgeWhyOpen(false)}
                          context={{
                            preferredDate: date,
                            preferredTime: selectedSlot?.localTime,
                            startAt: selectedSlot?.startAt,
                            services,
                          }}
                        />
                      </>
                    );
                  })()}

                  <div className="flex justify-between border-t border-brand-line pt-1 text-brand-ink">
                    <span>{recurringTotalLabel(recurringPlan, bookingLocale)}</span>
                    <span>${fmtMoney(pricing.subtotalCents)}</span>
                  </div>
                </div>
                <p className="mt-1 text-xs text-brand-mute">
                  ${pricing.hourlyRate}
                  {estCopy.perHourPerPerson}
                </p>
                {/* Bill-shock guard: the hourly model has a 1-hour minimum then
                    15-min blocks — surface it at the price reveal so a quick-job
                    customer isn't surprised by the first-hour charge. Block price
                    is derived from the same rate (rate/4) so it can't drift. */}
                <p
                  data-bcl-billing-minimum=""
                  className="mt-2 flex items-start gap-2 rounded-md border border-brand-line/60 bg-bg-primary/40 px-3.5 py-2.5 text-[11px] leading-relaxed text-brand-mute transition-colors duration-[333ms] hover:border-brand-accent/40 hover:text-brand-ink/80"
                >
                  <span aria-hidden="true" className="mt-px shrink-0 text-brand-accent">
                    ⏱
                  </span>
                  <span>{billingMinimumNote(pricing.hourlyRate, bookingLocale)}</span>
                </p>
                {/* Payment-reassurance at the price reveal: the card is saved but
                    NOT charged at booking — charge happens only after the customer
                    confirms the job is done OR the 24h dispute window closes clean.
                    Removing "will I be charged now?" friction is the #1 final-step
                    abandonment driver on a pay-after-service model. */}
                <p
                  data-bcl-payment-reassurance=""
                  className="mt-2 flex items-start gap-2 rounded-md border border-brand-line/60 bg-bg-primary/40 px-3.5 py-2.5 text-[11px] leading-relaxed text-brand-mute transition-colors duration-[333ms] hover:border-brand-accent/40 hover:text-brand-ink/80"
                >
                  <span aria-hidden="true" className="mt-px shrink-0 text-brand-accent">
                    🔒
                  </span>
                  <span>{paymentReassuranceNote(bookingLocale)}</span>
                </p>
              </div>

              <ul className="space-y-2 border-t border-brand-line pt-4 text-sm text-brand-mute">
                <li className="flex gap-2">
                  <span className="text-brand-accent" aria-hidden>
                    ✓
                  </span>{' '}
                  {estCopy.trustEmail}
                </li>
                <li className="flex gap-2">
                  <span className="text-brand-accent" aria-hidden>
                    ✓
                  </span>{' '}
                  {estCopy.trustCalendar}
                </li>
                <li className="flex gap-2">
                  <span className="text-brand-accent" aria-hidden>
                    ✓
                  </span>{' '}
                  {estCopy.trustSms}
                </li>
                <li className="flex gap-2">
                  <span className="text-brand-accent" aria-hidden>
                    ✓
                  </span>{' '}
                  {estCopy.trustDeposit}
                </li>
                <li className="flex gap-2">
                  <span className="text-brand-accent" aria-hidden>
                    ✓
                  </span>{' '}
                  {estCopy.trustCancel}
                </li>
              </ul>

              <p className="text-[11px] text-brand-mute leading-relaxed border-t border-brand-line pt-4">
                Rush job or weekend emergency?{' '}
                <a href={lpHref('/contact')} className="text-brand-accent underline-hover">
                  Send a message
                </a>{' '}
                or call{' '}
                <a href={PHONE_TEL_HREF} className="text-brand-accent underline-hover">
                  (855) 82LABOR
                </a>
                .
              </p>
            </aside>

            <form id="book-form" onSubmit={handleSubmit} className="card lg:col-span-2 space-y-6">
              {bundle && (
                <div
                  role="status"
                  aria-live="polite"
                  className="flex items-center justify-between gap-3 rounded-lg border border-brand-accent/50 bg-brand-accent/10 px-4 py-3"
                  data-bcl-bundle={bundle.slug}
                >
                  <div className="min-w-0">
                    <p className="font-mono text-[10px] uppercase tracking-widest text-brand-accent">
                      Bundle locked
                    </p>
                    <p className="text-sm font-bold text-brand-ink truncate">
                      {bundle.title} · ${(bundle.priceCents / 100).toFixed(0)} prepaid
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={clearBundle}
                    className="shrink-0 rounded-md border border-brand-line bg-bg-primary px-3 py-1.5 text-[11px] font-mono text-brand-mute hover:border-brand-accent hover:text-brand-accent"
                    aria-label="Clear bundle and unlock the form"
                  >
                    × change
                  </button>
                </div>
              )}
              {step === 'schedule' && magicPrefilled && (
                <div
                  data-testid="booking-magic-prefill"
                  role="status"
                  className="flex flex-wrap items-center gap-x-3 gap-y-2 rounded-lg border border-brand-accent/40 bg-brand-accent/5 px-3 py-2.5 text-xs text-brand-ink transition-all duration-[333ms]"
                >
                  <span aria-hidden className="text-brand-accent">
                    ✦
                  </span>
                  <span className="flex-1 min-w-[12rem] leading-snug">
                    We pre-filled your booking from your link. Review the details and pick a time —
                    everything's editable.
                  </span>
                </div>
              )}
              {step === 'schedule' && showRestoredDraft && (
                <div
                  data-testid="booking-draft-restored"
                  role="status"
                  className="flex flex-wrap items-center gap-x-3 gap-y-2 rounded-lg border border-brand-accent/40 bg-brand-accent/5 px-3 py-2.5 text-xs text-brand-ink transition-all duration-[333ms]"
                >
                  <span aria-hidden className="text-brand-accent">
                    ↻
                  </span>
                  <span className="flex-1 min-w-[12rem] leading-snug">
                    {restoredDraftMessage(restoredDraftStale.current)}
                  </span>
                  <button
                    type="button"
                    onClick={startFresh}
                    className="rounded-full border border-brand-accent px-3 py-1 font-mono text-[11px] uppercase tracking-widest text-brand-accent transition-all duration-[333ms] hover:-translate-y-0.5 hover:bg-brand-accent hover:text-bg-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-accent"
                  >
                    Start fresh
                  </button>
                  <button
                    type="button"
                    aria-label="Dismiss restored draft notice"
                    onClick={() => setShowRestoredDraft(false)}
                    className="rounded-full px-2 py-1 text-brand-mute transition-colors duration-[333ms] hover:text-brand-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-accent"
                  >
                    ✕
                  </button>
                </div>
              )}
              {/* Clickable step nav — jump to any step to review/edit how the
                  form was filled. Gorgeous black+cyan pills: active glows, done
                  fills cyan + ✓, all are real buttons (≥40px tap target, focus
                  ring, aria-current). 'success' hides this (its own view). */}
              <nav aria-label="Booking steps" className="flex w-full flex-wrap items-stretch gap-2.5 sm:gap-3">
                {(() => {
                  const stages: { id: Step; label: string }[] = [
                    { id: 'schedule', label: 'Schedule' },
                    { id: 'details', label: 'Your info' },
                    { id: 'ai-review', label: 'AI Info' },
                    { id: 'confirm', label: 'Confirm' },
                  ];
                  const order: Record<string, number> = {
                    schedule: 0,
                    details: 1,
                    'ai-review': 2,
                    confirm: 3,
                  };
                  const currentIdx = order[step] ?? 0;
                  return stages.map((s, i) => {
                    const active = s.id === step;
                    const done = i < currentIdx;
                    return (
                      <button
                        key={s.id}
                        type="button"
                        onClick={() => setStep(s.id)}
                        aria-current={active ? 'step' : undefined}
                        data-testid={`booking-step-nav-${s.id}`}
                        className={`group flex min-h-[58px] flex-1 basis-[8rem] items-center justify-center gap-2.5 rounded-2xl border px-4 py-3 text-sm font-semibold tracking-tight transition-all duration-[333ms] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent focus-visible:ring-offset-2 focus-visible:ring-offset-bg-primary sm:flex-none sm:basis-auto sm:text-[15px] motion-reduce:transition-none motion-reduce:hover:transform-none ${
                          active
                            ? 'border-brand-accent bg-gradient-to-b from-brand-accent/20 to-brand-accent/[0.08] text-brand-ink shadow-[0_0_0_1px_rgba(255,107,26,0.45),0_12px_32px_-12px_rgba(255,107,26,0.7)]'
                            : done
                              ? 'border-brand-accent/50 bg-brand-accent/[0.08] text-brand-ink hover:-translate-y-0.5 hover:border-brand-accent hover:shadow-[0_10px_28px_-14px_rgba(255,107,26,0.55)]'
                              : 'border-brand-line text-brand-mute hover:-translate-y-0.5 hover:border-brand-accent/60 hover:text-brand-ink hover:shadow-[0_10px_28px_-16px_rgba(255,107,26,0.45)]'
                        }`}
                      >
                        <span
                          aria-hidden
                          className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full font-mono text-sm font-bold transition-colors ${
                            active
                              ? 'bg-brand-accent text-bg-primary shadow-[0_0_14px_-2px_rgba(255,107,26,0.75)]'
                              : done
                                ? 'bg-brand-accent/85 text-bg-primary'
                                : 'border border-brand-line text-brand-mute group-hover:border-brand-accent/60'
                          }`}
                        >
                          {done ? '✓' : i + 1}
                        </span>
                        {s.label}
                      </button>
                    );
                  });
                })()}
              </nav>

              {step === 'schedule' && (
                <>
                  <div key="step-schedule" data-testid="booking-step-schedule" className="bcl-step-enter">
                    <p className="label">
                      {formCopy.servicesPrompt}{' '}
                      <span className="text-brand-mute font-normal">{formCopy.servicesHint}</span>
                    </p>
                    {!showServices && services.length === 0 ? (
                      <button
                        type="button"
                        onClick={() => setShowServices(true)}
                        data-bcl-cta="add-services"
                        className="mt-3 w-full rounded-lg border border-dashed border-brand-line bg-bg-primary px-4 py-3.5 text-left transition-all hover:border-brand-accent hover:shadow-[0_0_20px_rgba(255,107,26,0.12)] group"
                      >
                        <span className="block font-mono text-sm font-bold text-brand-ink group-hover:text-brand-accent transition-colors">
                          + Tell us what you need{' '}
                          <span className="text-brand-mute font-normal">(optional)</span>
                        </span>
                        <span className="mt-1 block text-[11px] leading-relaxed text-brand-mute">
                          Power washing · lawn &amp; yard · hauling · junk &amp; cleanouts · light
                          repairs · moving help · seasonal — we handle far more than most folks
                          expect. Pick any that fit, or just book the crew and tell us on-site.
                        </span>
                      </button>
                    ) : (
                    <>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {SERVICE_TILES.map((tile) => {
                        const active = services.includes(tile.id);
                        const tileCopy = formCopy.tiles[tile.id as ServiceTileId] ?? {
                          label: tile.label,
                          sub: tile.sub,
                        };
                        return (
                          <button
                            key={tile.id}
                            type="button"
                            aria-pressed={active}
                            onClick={() =>
                              setServices((prev) =>
                                prev.includes(tile.id)
                                  ? prev.filter((s) => s !== tile.id)
                                  : [...prev, tile.id],
                              )
                            }
                            className={`group/tile text-left rounded-lg border overflow-hidden transition-all duration-200 hover:-translate-y-0.5 active:translate-y-0 active:scale-[0.99] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent focus-visible:ring-offset-2 focus-visible:ring-offset-bg-primary motion-reduce:transition-none motion-reduce:hover:translate-y-0 ${
                              active
                                ? 'border-brand-accent bg-brand-accent/10 shadow-[0_8px_24px_-12px_rgba(255,107,26,0.55)] ring-1 ring-brand-accent/40'
                                : 'border-brand-line bg-bg-primary hover:border-brand-accent/60 hover:shadow-[0_10px_26px_-16px_rgba(255,107,26,0.5)]'
                            }`}
                          >
                            {tile.image && (
                              <div className="aspect-[1600/621] w-full overflow-hidden bg-bg-muted">
                                <img
                                  src={tile.image}
                                  alt=""
                                  loading="lazy"
                                  decoding="async"
                                  className="h-full w-full object-cover transition-transform duration-300 group-hover/tile:scale-105 motion-reduce:transition-none motion-reduce:group-hover/tile:scale-100"
                                />
                              </div>
                            )}
                            <div className="px-3 py-2">
                              <div
                                className={`font-mono text-sm font-bold ${active ? 'text-brand-accent' : 'text-brand-ink'}`}
                              >
                                {tileCopy.label}
                              </div>
                              <div className="text-[11px] mt-0.5 text-brand-mute">{tileCopy.sub}</div>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                    {services.length >= 2 && (
                      <p className="mt-2 text-[11px] text-emerald-300/90 font-mono">
                        ✓ Bundle discount unlocked — 10% off labor.
                      </p>
                    )}
                    {services.length === 0 && (
                      <button
                        type="button"
                        onClick={() => setShowServices(false)}
                        className="mt-2 text-[11px] text-brand-mute underline-hover hover:text-brand-ink"
                      >
                        Never mind — I’ll tell you on-site
                      </button>
                    )}
                    </>
                    )}
                  </div>

                  {/* Single-day workers + hours picker — right after "What needs
                      doing?" so the customer sizes the crew and the duration up
                      front, before choosing a day + time. Multi-day mode sets crew
                      + hours per date below, so this only shows single-day. */}
                  {!multiDayMode && (
                    <div className="rounded-lg border border-brand-line bg-bg-elevated/40 p-4 space-y-3">
                      <div className="grid gap-3 sm:grid-cols-2">
                        <div className="space-y-2">
                          <p className="label px-1">How many workers?</p>
                          <div className="flex items-stretch gap-0 rounded-lg border border-brand-line overflow-hidden">
                            <button
                              type="button"
                              onClick={() => setCrew(Math.max(1, crew - 1) as CrewSize)}
                              disabled={crew <= 1}
                              aria-label="Decrease crew"
                              className="w-12 flex items-center justify-center bg-bg-primary font-mono text-lg font-bold text-brand-ink hover:bg-brand-accent/10 hover:text-brand-accent disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                            >
                              −
                            </button>
                            <div className="flex-1 flex items-center justify-center bg-bg-primary/60 px-4 py-3">
                              <span className="font-mono text-2xl font-extrabold text-brand-accent">{crew}</span>
                              <span className="ml-2 text-xs text-brand-mute font-mono">
                                {crew === 1 ? 'worker' : 'workers'}
                              </span>
                            </div>
                            <button
                              type="button"
                              onClick={() => setCrew(Math.min(MAX_CREW, crew + 1) as CrewSize)}
                              disabled={crew >= MAX_CREW}
                              aria-label="Increase crew"
                              className="w-12 flex items-center justify-center bg-bg-primary font-mono text-lg font-bold text-brand-ink hover:bg-brand-accent/10 hover:text-brand-accent disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                            >
                              +
                            </button>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <p className="label px-1">How many hours?</p>
                          <div className="flex items-stretch gap-0 rounded-lg border border-brand-line overflow-hidden">
                            <button
                              type="button"
                              onClick={() => setHours(Math.max(1, hours - 1))}
                              disabled={hours <= 1}
                              aria-label="Decrease hours"
                              className="w-12 flex items-center justify-center bg-bg-primary font-mono text-lg font-bold text-brand-ink hover:bg-brand-accent/10 hover:text-brand-accent disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                            >
                              −
                            </button>
                            <div className="flex-1 flex items-center justify-center bg-bg-primary/60 px-4 py-3">
                              <span className="font-mono text-2xl font-extrabold text-brand-accent">{hours}</span>
                              <span className="ml-2 text-xs text-brand-mute font-mono">
                                {hours === 1 ? 'hour' : 'hours'}
                              </span>
                            </div>
                            <button
                              type="button"
                              onClick={() => setHours(Math.min(12, hours + 1))}
                              disabled={hours >= 12}
                              aria-label="Increase hours"
                              className="w-12 flex items-center justify-center bg-bg-primary font-mono text-lg font-bold text-brand-ink hover:bg-brand-accent/10 hover:text-brand-accent disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                            >
                              +
                            </button>
                          </div>
                        </div>
                      </div>
                      <p className="text-[11px] text-brand-mute leading-relaxed">
                        ${pricing.hourlyRate}/hr per worker · 1-hr minimum · 15-min blocks after
                      </p>
                    </div>
                  )}

                  <div>
                    <p id="bk-date-label" className="label flex items-center justify-between">
                      <span>
                        Date{' '}
                        <span className="text-brand-mute font-normal">
                          (
                          {multiDayMode ? 'click to add/remove days' : 'Mon — Sun, Sundays premium'}
                          )
                        </span>
                      </span>
                      {!multiDayMode && date && (
                        <span className="font-mono text-brand-accent text-xs">
                          {new Date(date + 'T12:00:00').toLocaleDateString('en-US', {
                            weekday: 'short',
                            month: 'short',
                            day: 'numeric',
                          })}
                        </span>
                      )}
                      {multiDayMode && multiDates.length > 0 && (
                        <span className="font-mono text-brand-accent text-xs">
                          {multiDates.length} day{multiDates.length === 1 ? '' : 's'} picked
                        </span>
                      )}
                    </p>


                    {/* Pick the cheapest day — full-width, single-day only, before calendar */}
                    {!multiDayMode && (
                      <div className="mb-3">
                        <SurgeAwareDatePeek
                          hoursEstimate={hours}
                          selectedDate={date}
                          crewSize={crew}
                          hourlyRateCents={pricing.hourlyRate * 100}
                          priceForDate={priceForDate}
                          onPickDate={(iso) => {
                            track('surge_peek_picked', { from: date, to: iso, hours, crew });
                            selectSingleDate(iso); // setDate + clear slot + mirror multiDates + seed
                          }}
                        />
                      </div>
                    )}

                    <div className="grid gap-4 lg:grid-cols-2 lg:items-start">
                      <div className="min-w-0">
                        <Calendar
                          value={date}
                          onChange={(d) => {
                            // Subscription: the calendar is a single-select START-DATE picker —
                            // a click sets the first potential start date (no multi-day build).
                            if (subMode) {
                              setDate(d);
                              setSelectedSlot(null);
                              return;
                            }
                            setDate(d);
                            if (!multiDates.includes(d)) {
                              setMultiDates((prev) => {
                                const next = [...prev, d].sort();
                                if (next.length > 1) setMultiDayMode(true);
                                return next;
                              });
                              setMultiPerHours((prev) =>
                                prev[d] !== undefined
                                  ? prev
                                  : { ...prev, [d]: PER_DAY_DEFAULT_HOURS },
                              );
                              setMultiPerCrew((prev) =>
                                prev[d] !== undefined
                                  ? prev
                                  : { ...prev, [d]: PER_DAY_DEFAULT_CREW },
                              );
                            }
                          }}
                          minDate={MIN_DATE}
                          maxDate={MAX_DATE}
                          multiSelect={!subMode}
                          selectedDates={multiDates}
                          onToggleDate={(d) => {
                            const wasSelected = multiDates.includes(d);
                            setMultiDates((prev) => {
                              if (prev.includes(d)) {
                                const next = prev.filter((x) => x !== d);
                                if (date === d) setDate(next[0] ?? '');
                                // Auto-detect: 0-1 dates = single-day, >1 = multi-day
                                if (next.length <= 1) setMultiDayMode(false);
                                return next;
                              }
                              const next = [...prev, d].sort();
                              if (!date) setDate(d);
                              if (next.length > 1) setMultiDayMode(true);
                              return next;
                            });
                            setMultiPerHours((prev) => {
                              if (wasSelected) {
                                const { [d]: _drop, ...rest } = prev;
                                return rest;
                              }
                              return prev[d] !== undefined
                                ? prev
                                : { ...prev, [d]: PER_DAY_DEFAULT_HOURS };
                            });
                            setMultiPerCrew((prev) => {
                              if (wasSelected) {
                                const { [d]: _drop, ...rest } = prev;
                                return rest;
                              }
                              return prev[d] !== undefined
                                ? prev
                                : { ...prev, [d]: PER_DAY_DEFAULT_CREW };
                            });
                          }}
                          recurringPreview={null}
                          contractDates={subMode ? subVisitDates : []}
                        />
                        {date && isToday(date) && (
                          <p className="mt-2 rounded-md border border-amber-400/40 bg-amber-400/5 px-3 py-2 text-[11px] text-amber-200/90">
                            Same-day priority adds <strong className="text-amber-300">$75</strong> —
                            we re-route a crew to you within hours.
                          </p>
                        )}
                        {date && isSunday(date) && (
                          <p className="mt-2 rounded-md border border-amber-400/40 bg-amber-400/5 px-3 py-2 text-[11px] text-amber-200/90">
                            Sunday premium adds{' '}
                            <strong className="text-amber-300">+$15/hr per person</strong>. Mon–Sat
                            is the standard rate.
                          </p>
                        )}
                        {/* Subscription visit chart — floats under the calendar (left
                            column); each visit is a single compact line. */}
                        {subMode && subChartVisits.length > 0 && (
                          <div className="relative mt-3 rounded-lg border border-brand-line bg-gradient-to-br from-brand-accent/[0.06] to-transparent p-3">
                            <div className="mb-1.5 flex flex-wrap items-baseline justify-between gap-x-2 gap-y-0.5">
                              <p className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
                                Your schedule · next {subChartVisits.length}
                              </p>
                              <span className="flex items-center gap-1.5 font-mono text-[10px] text-brand-mute">
                                {FREQUENCY_LABELS[subFrequency]} · {crew} {crew === 1 ? 'worker' : 'workers'} · {hours}h · {subscriptionStartTime}
                                <button
                                  type="button"
                                  onClick={() => setScheduleEditOpen((v) => !v)}
                                  aria-label="Edit schedule details"
                                  aria-expanded={scheduleEditOpen}
                                  className="ml-0.5 inline-flex h-5 w-5 items-center justify-center rounded border border-brand-line text-brand-mute transition-colors hover:border-brand-accent hover:text-brand-accent"
                                >
                                  ✎
                                </button>
                              </span>
                            </div>
                            {scheduleEditOpen && (
                              <div className="absolute right-2 top-9 z-20 w-56 space-y-2.5 rounded-lg border border-brand-accent/50 bg-bg-elevated p-3 shadow-[0_8px_30px_rgba(0,0,0,0.5)]">
                                <div className="flex items-center justify-between">
                                  <p className="font-mono text-[10px] uppercase tracking-widest text-brand-accent">Edit each visit</p>
                                  <button type="button" onClick={() => setScheduleEditOpen(false)} aria-label="Close" className="inline-flex min-h-[24px] min-w-[24px] items-center justify-center rounded text-brand-mute hover:text-brand-ink">✕</button>
                                </div>
                                <div className="flex items-center justify-between gap-2">
                                  <span className="text-[11px] text-brand-mute">Workers</span>
                                  <div className="flex items-center gap-1">
                                    <button type="button" aria-label="Fewer workers" disabled={crew <= 1} onClick={() => setCrew(Math.max(1, crew - 1) as CrewSize)} className="h-6 w-6 rounded border border-brand-line font-mono text-brand-ink hover:border-brand-accent disabled:opacity-30">−</button>
                                    <span className="w-8 text-center font-mono text-sm font-bold text-brand-accent">{crew}</span>
                                    <button type="button" aria-label="More workers" disabled={crew >= MAX_CREW} onClick={() => setCrew(Math.min(MAX_CREW, crew + 1) as CrewSize)} className="h-6 w-6 rounded border border-brand-line font-mono text-brand-ink hover:border-brand-accent disabled:opacity-30">+</button>
                                  </div>
                                </div>
                                <div className="flex items-center justify-between gap-2">
                                  <span className="text-[11px] text-brand-mute">Hours</span>
                                  <div className="flex items-center gap-1">
                                    <button type="button" aria-label="Fewer hours" disabled={hours <= 1} onClick={() => setHours(Math.max(1, hours - 1))} className="h-6 w-6 rounded border border-brand-line font-mono text-brand-ink hover:border-brand-accent disabled:opacity-30">−</button>
                                    <span className="w-8 text-center font-mono text-sm font-bold text-brand-accent">{hours}</span>
                                    <button type="button" aria-label="More hours" disabled={hours >= 12} onClick={() => setHours(Math.min(12, hours + 1))} className="h-6 w-6 rounded border border-brand-line font-mono text-brand-ink hover:border-brand-accent disabled:opacity-30">+</button>
                                  </div>
                                </div>
                                <div className="flex items-center justify-between gap-2">
                                  <span className="text-[11px] text-brand-mute">Start</span>
                                  <select value={subscriptionStartTime} onChange={(e) => setSubscriptionStartTime(e.target.value)} aria-label="Start time" className="rounded-md border border-brand-line bg-bg-primary px-2 py-1 text-xs font-mono text-brand-ink focus:border-brand-accent focus:outline-none">
                                    {['7:00 AM','8:00 AM','9:00 AM','10:00 AM','11:00 AM','12:00 PM','1:00 PM','2:00 PM','3:00 PM','4:00 PM','5:00 PM','6:00 PM'].map((t) => (<option key={t} value={t}>{t}</option>))}
                                  </select>
                                </div>
                                <p className="text-[10px] text-brand-mute">Applies to every visit · saved with your booking.</p>
                              </div>
                            )}
                            <ol className="divide-y divide-brand-line/40">
                              {subChartVisits.map((iso, i) => {
                                const d = new Date(iso + 'T12:00:00');
                                return (
                                  <li key={iso} className="py-1 font-mono text-[11px] leading-none">
                                    <div className="flex items-center gap-2">
                                      <span className={`w-7 shrink-0 ${i === 0 ? 'font-bold text-brand-accent' : 'text-brand-mute'}`}>#{i + 1}</span>
                                      <span className="flex-1 truncate text-brand-ink">
                                        {d.toLocaleDateString(
                                          'en-US',
                                          subFrequency === 'yearly'
                                            ? { month: 'short', day: 'numeric', year: 'numeric' }
                                            : { weekday: 'short', month: 'short', day: 'numeric' },
                                        )}
                                        {visitIsCustom(iso) && (
                                          <span className="ml-1 align-middle text-[9px] text-brand-accent" title="Customized visit">●</span>
                                        )}
                                      </span>
                                      <span className="text-brand-accent">{visitCrew(iso)} {visitCrew(iso) === 1 ? 'wkr' : 'wkrs'}</span>
                                      <span className="text-brand-mute">{visitHours(iso)}h</span>
                                      <span className="hidden text-brand-mute sm:inline">{visitStart(iso)}</span>
                                      <button
                                        type="button"
                                        aria-label={`Edit visit ${i + 1}`}
                                        aria-expanded={editingVisitIso === iso}
                                        onClick={() => setEditingVisitIso(editingVisitIso === iso ? null : iso)}
                                        className={`shrink-0 rounded px-1 text-[11px] transition-colors ${editingVisitIso === iso ? 'text-brand-accent' : 'text-brand-mute hover:text-brand-accent'}`}
                                      >
                                        ✎
                                      </button>
                                    </div>
                                    {editingVisitIso === iso && (
                                      <div className="mt-1.5 space-y-2 rounded-md border border-brand-accent/40 bg-bg-elevated/70 p-2">
                                        <div className="flex items-center justify-between gap-2">
                                          <span className="text-[10px] uppercase tracking-widest text-brand-mute">Workers</span>
                                          <div className="flex items-center gap-1">
                                            <button type="button" aria-label="Fewer workers" disabled={visitCrew(iso) <= 1} onClick={() => setVisitField(iso, { crew: Math.max(1, visitCrew(iso) - 1) as CrewSize })} className="h-6 w-6 rounded border border-brand-line font-mono text-brand-ink hover:border-brand-accent disabled:opacity-30">−</button>
                                            <span className="w-8 text-center font-mono text-sm font-bold text-brand-accent">{visitCrew(iso)}</span>
                                            <button type="button" aria-label="More workers" disabled={visitCrew(iso) >= MAX_CREW} onClick={() => setVisitField(iso, { crew: Math.min(MAX_CREW, visitCrew(iso) + 1) as CrewSize })} className="h-6 w-6 rounded border border-brand-line font-mono text-brand-ink hover:border-brand-accent disabled:opacity-30">+</button>
                                          </div>
                                        </div>
                                        <div className="flex items-center justify-between gap-2">
                                          <span className="text-[10px] uppercase tracking-widest text-brand-mute">Hours</span>
                                          <div className="flex items-center gap-1">
                                            <button type="button" aria-label="Fewer hours" disabled={visitHours(iso) <= 1} onClick={() => setVisitField(iso, { hours: Math.max(1, visitHours(iso) - 1) })} className="h-6 w-6 rounded border border-brand-line font-mono text-brand-ink hover:border-brand-accent disabled:opacity-30">−</button>
                                            <span className="w-8 text-center font-mono text-sm font-bold text-brand-accent">{visitHours(iso)}</span>
                                            <button type="button" aria-label="More hours" disabled={visitHours(iso) >= 12} onClick={() => setVisitField(iso, { hours: Math.min(12, visitHours(iso) + 1) })} className="h-6 w-6 rounded border border-brand-line font-mono text-brand-ink hover:border-brand-accent disabled:opacity-30">+</button>
                                          </div>
                                        </div>
                                        <div className="flex items-center justify-between gap-2">
                                          <span className="text-[10px] uppercase tracking-widest text-brand-mute">Start</span>
                                          <select value={visitStart(iso)} onChange={(e) => setVisitField(iso, { startTime: e.target.value })} aria-label={`Start time for visit ${i + 1}`} className="rounded-md border border-brand-line bg-bg-primary px-2 py-1 text-xs font-mono text-brand-ink focus:border-brand-accent focus:outline-none">
                                            {['7:00 AM','8:00 AM','9:00 AM','10:00 AM','11:00 AM','12:00 PM','1:00 PM','2:00 PM','3:00 PM','4:00 PM','5:00 PM','6:00 PM'].map((t) => (<option key={t} value={t}>{t}</option>))}
                                          </select>
                                        </div>
                                        <div className="flex items-center justify-between gap-2 pt-0.5">
                                          <button type="button" onClick={() => resetVisit(iso)} disabled={!visitIsCustom(iso)} className="text-[10px] text-brand-mute underline decoration-dotted hover:text-brand-accent disabled:opacity-30">Reset to default</button>
                                          <button type="button" onClick={() => setEditingVisitIso(null)} className="rounded border border-brand-accent/50 px-2 py-0.5 text-[10px] font-bold text-brand-accent hover:bg-brand-accent/10">Done</button>
                                        </div>
                                      </div>
                                    )}
                                  </li>
                                );
                              })}
                            </ol>
                            <p className="mt-1.5 text-[10px] text-brand-mute">
                              {recurringEndAfter > 0
                                ? `Ends after ${recurringEndAfter} visit${recurringEndAfter === 1 ? '' : 's'}.`
                                : 'Runs until you pause or cancel — manage anytime from your dashboard.'}
                            </p>
                          </div>
                        )}
                        {/* One-time visit summary — mirrors the subscription "Your schedule"
                            card so a single-day booking gets the same at-a-glance
                            confirmation. Edit via the calendar/time picker + Workers/Hours
                            controls above. */}
                        {!subMode && !multiDayMode && date && selectedSlot && (
                          <div className="relative mt-3 rounded-lg border border-brand-line bg-gradient-to-br from-brand-accent/[0.06] to-transparent p-3">
                            <div className="mb-1.5 flex flex-wrap items-baseline justify-between gap-x-2 gap-y-0.5">
                              <p className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
                                Your schedule
                              </p>
                              <span className="font-mono text-[10px] text-brand-mute">
                                One-time · {crew} {crew === 1 ? 'worker' : 'workers'} · {hours}h
                              </span>
                            </div>
                            <ol>
                              <li className="flex items-center gap-2 py-1 font-mono text-[11px] leading-none">
                                <span className="w-7 shrink-0 font-bold text-brand-accent">#1</span>
                                <span className="flex-1 truncate text-brand-ink">
                                  {new Date(date + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
                                </span>
                                <span className="text-brand-accent">{crew} {crew === 1 ? 'wkr' : 'wkrs'}</span>
                                <span className="text-brand-mute">{hours}h</span>
                                <span className="hidden text-brand-mute sm:inline">{selectedSlot.localTime}</span>
                              </li>
                            </ol>
                            <p className="mt-1.5 text-[10px] text-brand-mute">
                              One visit — change the day or time on the calendar, workers/hours above.
                            </p>
                          </div>
                        )}
                      </div>

                      <div className="min-w-0">
                        {multiDayMode && multiDates.length > 0 ? (
                          <div className="rounded-lg border border-brand-line bg-bg-primary/70 p-3 space-y-3">
                            <p className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
                              {multiDates.length} day{multiDates.length === 1 ? '' : 's'} · total{' '}
                              {multiDates.reduce(
                                (sum, d) => sum + (multiPerHours[d] ?? PER_DAY_DEFAULT_HOURS),
                                0,
                              )}
                              h labor
                            </p>
                            <ul className="space-y-2">
                              {multiDates.map((d, idx) => {
                                const dt = new Date(d + 'T12:00:00');
                                const label = dt.toLocaleDateString('en-US', {
                                  weekday: 'long',
                                  month: 'short',
                                  day: 'numeric',
                                });
                                const dayHours = multiPerHours[d] ?? PER_DAY_DEFAULT_HOURS;
                                const dayCrew = multiPerCrew[d] ?? PER_DAY_DEFAULT_CREW;
                                const sunday = dt.getDay() === 0;
                                const firstDayTime = multiDates[0] ? multiPerTime[multiDates[0]] : undefined;
                                return (
                                  <li
                                    key={d}
                                    className="rounded-md border border-brand-line/60 bg-bg-elevated/40 px-3 py-2.5 space-y-2"
                                  >
                                    <div className="flex items-center justify-between gap-2">
                                      <div className="flex items-center gap-2 font-mono text-xs text-brand-ink">
                                        <span className="truncate">{label}</span>
                                        {sunday && (
                                          <span className="rounded-sm bg-amber-400/15 px-1.5 py-0.5 text-[10px] text-amber-200">
                                            +Sun
                                          </span>
                                        )}
                                      </div>
                                      <button
                                        type="button"
                                        onClick={() => {
                                          setMultiDates((prev) => prev.filter((x) => x !== d));
                                          setMultiPerHours((prev) => {
                                            const { [d]: _drop, ...rest } = prev;
                                            return rest;
                                          });
                                          setMultiPerCrew((prev) => {
                                            const { [d]: _drop, ...rest } = prev;
                                            return rest;
                                          });
                                          if (date === d) {
                                            const remaining = multiDates.filter((x) => x !== d);
                                            setDate(remaining[0] ?? '');
                                          }
                                        }}
                                        aria-label={`Remove ${label}`}
                                        className="inline-flex min-h-[24px] items-center rounded-md border border-brand-line px-2 py-0.5 text-[11px] font-mono text-brand-mute transition-colors hover:border-red-400 hover:text-red-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
                                      >
                                        Remove
                                      </button>
                                    </div>
                                    <div className="grid grid-cols-2 gap-2">
                                      <div className="rounded-md border border-brand-line/60 bg-bg-primary/60 px-2 py-1.5">
                                        <div className="flex items-center justify-between text-[10px] font-mono uppercase tracking-widest text-brand-mute">
                                          <span>Hours</span>
                                          <span className="text-brand-accent">{dayHours}h</span>
                                        </div>
                                        <div className="mt-1 flex items-center gap-1">
                                          <button
                                            type="button"
                                            onClick={() =>
                                              setMultiPerHours((prev) => ({
                                                ...prev,
                                                [d]: Math.max(1, dayHours - 1),
                                              }))
                                            }
                                            disabled={dayHours <= 1}
                                            aria-label={`Decrease hours for ${label}`}
                                            className="h-7 w-7 rounded-md border border-brand-line font-mono text-sm text-brand-ink hover:border-brand-accent hover:text-brand-accent disabled:opacity-30 disabled:cursor-not-allowed"
                                          >
                                            −
                                          </button>
                                          <div className="flex-1 text-center font-mono text-sm text-brand-ink">
                                            {dayHours}
                                          </div>
                                          <button
                                            type="button"
                                            onClick={() =>
                                              setMultiPerHours((prev) => ({
                                                ...prev,
                                                [d]: Math.min(12, dayHours + 1),
                                              }))
                                            }
                                            disabled={dayHours >= 12}
                                            aria-label={`Increase hours for ${label}`}
                                            className="h-7 w-7 rounded-md border border-brand-line font-mono text-sm text-brand-ink hover:border-brand-accent hover:text-brand-accent disabled:opacity-30 disabled:cursor-not-allowed"
                                          >
                                            +
                                          </button>
                                        </div>
                                      </div>
                                      <div className="rounded-md border border-brand-line/60 bg-bg-primary/60 px-2 py-1.5">
                                        <div className="flex items-center justify-between text-[10px] font-mono uppercase tracking-widest text-brand-mute">
                                          <span>Crew</span>
                                          <span className="text-brand-accent">
                                            {dayCrew} {dayCrew === 1 ? 'person' : 'people'}
                                          </span>
                                        </div>
                                        <div className="mt-1 flex items-center gap-1">
                                          <button
                                            type="button"
                                            onClick={() =>
                                              setMultiPerCrew((prev) => ({
                                                ...prev,
                                                [d]: Math.max(1, dayCrew - 1),
                                              }))
                                            }
                                            disabled={dayCrew <= 1}
                                            aria-label={`Decrease crew for ${label}`}
                                            className="h-7 w-7 rounded-md border border-brand-line font-mono text-sm text-brand-ink hover:border-brand-accent hover:text-brand-accent disabled:opacity-30 disabled:cursor-not-allowed"
                                          >
                                            −
                                          </button>
                                          <div className="flex-1 text-center font-mono text-sm text-brand-ink">
                                            {dayCrew}
                                          </div>
                                          <button
                                            type="button"
                                            onClick={() =>
                                              setMultiPerCrew((prev) => ({
                                                ...prev,
                                                [d]: Math.min(MAX_CREW, dayCrew + 1),
                                              }))
                                            }
                                            disabled={dayCrew >= MAX_CREW}
                                            aria-label={`Increase crew for ${label}`}
                                            className="h-7 w-7 rounded-md border border-brand-line font-mono text-sm text-brand-ink hover:border-brand-accent hover:text-brand-accent disabled:opacity-30 disabled:cursor-not-allowed"
                                          >
                                            +
                                          </button>
                                        </div>
                                      </div>
                                    </div>
                                    {/* Per-day start time — inherits from first day if unset */}
                                    {slots.length > 0 && (
                                      <div className="rounded-md border border-brand-line/60 bg-bg-primary/60 px-2 py-1.5">
                                        <div className="flex items-center justify-between text-[10px] font-mono uppercase tracking-widest text-brand-mute">
                                          <span>Start time</span>
                                          <span className="text-brand-accent text-[10px]">
                                            {multiPerTime[d] || (idx > 0 && firstDayTime ? '(same as Day 1)' : 'flexible')}
                                          </span>
                                        </div>
                                        <select
                                          value={multiPerTime[d] || ''}
                                          onChange={(e) => {
                                            const val = e.target.value;
                                            setMultiPerTime((prev) => {
                                              if (!val) { const { [d]: _drop, ...rest } = prev; return rest; }
                                              return { ...prev, [d]: val };
                                            });
                                          }}
                                          aria-label={`Start time for ${label}`}
                                          className="mt-1 w-full rounded-md border border-brand-line bg-bg-primary px-2 py-1 text-xs font-mono text-brand-ink focus:border-brand-accent focus:outline-none"
                                        >
                                          <option value="">
                                            {idx === 0 ? 'Flexible time' : firstDayTime ? `Same as Day 1 (${firstDayTime})` : 'Flexible time'}
                                          </option>
                                          {slots.map((s) => (
                                            <option key={s.localTime} value={s.localTime}>
                                              {s.localTime}
                                            </option>
                                          ))}
                                        </select>
                                      </div>
                                    )}
                                    {/* Per-day U-Haul pick — compact dropdown */}
                                    <div className="rounded-md border border-brand-line/60 bg-bg-primary/60 px-2 py-1.5">
                                      <div className="flex items-center justify-between text-[10px] font-mono uppercase tracking-widest text-brand-mute">
                                        <span>U-Haul</span>
                                      </div>
                                      <select
                                        value={multiPerTruck[d] ?? ''}
                                        onChange={(e) => {
                                          setMultiPerTruck((prev) => {
                                            if (!e.target.value) { const { [d]: _drop, ...rest } = prev; return rest; }
                                            return { ...prev, [d]: e.target.value };
                                          });
                                        }}
                                        className="mt-1 w-full rounded-md border border-brand-line bg-bg-primary px-2 py-1 text-xs font-mono text-brand-ink focus:border-brand-accent focus:outline-none"
                                      >
                                        <option value="">No truck</option>
                                        {UHAUL_TRUCKS.map((t) => (
                                          <option key={t.id} value={t.id}>
                                            {t.label} — ${(t.priceCents / 100).toFixed(0)}/day
                                          </option>
                                        ))}
                                      </select>
                                    </div>
                                    <p className="text-[10px] font-mono text-brand-mute">
                                      {dayCrew} crew × {dayHours}h = ${dayCrew * dayHours * 50}
                                    </p>
                                  </li>
                                );
                              })}
                            </ul>
                            <p className="text-[11px] text-brand-mute">
                              Each day books separately with its own crew size and hours. Each day
                              is flexible-time unless you also pick a slot below.
                            </p>
                          </div>
                        ) : date ? (
                          <div className="hidden lg:flex h-full flex-col justify-center gap-4 rounded-lg border border-dashed border-brand-line/60 bg-bg-primary/30 p-4">
                            <p className="font-mono text-[11px] uppercase tracking-widest text-brand-mute text-center">
                              {multiDates.length > 1 ? 'Multi-Day Job' : 'Single-day job'}
                            </p>
                            {recurringFlag && renderRecurring()}
                            {!subMode && date && renderStartTime(true)}
                          </div>
                        ) : (
                          <div className="hidden lg:flex h-full min-h-[200px] flex-col items-center justify-center rounded-lg border border-dashed border-brand-line/60 bg-bg-primary/30 p-4 text-center">
                            <p className="font-mono text-[11px] uppercase tracking-widest text-brand-mute">
                              {multiDates.length > 1 ? 'Multi-Day Job' : 'Single-day job'}
                            </p>
                            <p className="mt-2 text-xs text-brand-mute leading-snug">
                              {multiDates.length > 1 ? `${multiDates.length} days selected. Adjust hours and crew per day below.` : 'Tap a date on the calendar to set crew + hours. Tap additional dates for multi-day booking.'}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* One-time start time — full-width on MOBILE only; on desktop it
                      renders compact in the right column beside the calendar (below). */}
                  {date && !multiDayMode && !subMode && (
                    <div className="lg:hidden">{renderStartTime(false)}</div>
                  )}

                  {/* Standing-crew scheduler — full-width on MOBILE only; on desktop it
                      renders in the right column beside the calendar (above). */}
                  {date && !multiDayMode && recurringFlag && (
                    <div className="lg:hidden">{renderRecurring()}</div>
                  )}

                  {/* U-Haul truck rental — single-day + One-time only. Hidden behind an
                      "Add U-Haul" button until the customer opts in; fully hidden for any
                      recurring cadence (daily/weekly/bi-weekly/monthly) and in multi-day mode. */}
                  {!multiDayMode && !subMode && (
                  <div data-testid="booking-uhaul">
                    {!showUhaul && truckPicks.length === 0 ? (
                      <button
                        type="button"
                        onClick={() => setShowUhaul(true)}
                        data-bcl-cta="add-uhaul"
                        className="mt-3 w-full rounded-lg border border-dashed border-brand-line bg-bg-primary px-4 py-3.5 text-left transition-all hover:border-brand-accent hover:shadow-[0_0_20px_rgba(255,107,26,0.12)] group"
                      >
                        <span className="block font-mono text-sm font-bold text-brand-ink group-hover:text-brand-accent transition-colors">
                          + Add a U-Haul{' '}
                          <span className="text-brand-mute font-normal">(optional)</span>
                        </span>
                        <span className="mt-1 block text-[11px] leading-relaxed text-brand-mute">
                          Flat daily rate per truck — we handle the reservation, pickup, mileage,
                          fuel top-up, and return. Pick a size below, or skip it and just book the crew.
                        </span>
                      </button>
                    ) : (
                    <>
                    <p className="mb-4 text-[11px] text-brand-mute leading-relaxed">
                      One round number per truck, per day. Covers reservation, mileage, fuel top-up, and crew handling.
                    </p>
                    <div className="space-y-3">
                      {/* Grid stays open; the picked tile shows a gorgeous selected state
                          (accent ring + glow + ✓ badge). Click a tile to select, click it
                          again to unselect — single-select (choosing one replaces any other).
                          The estimate + cheapest-day prices update via rentalsTotal. */}
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        {UHAUL_TRUCKS.map((t) => {
                          const active = truckPicks[0]?.id === t.id;
                          return (
                            <button
                              key={t.id}
                              type="button"
                              aria-pressed={active}
                              aria-label={`${active ? 'Unselect' : 'Select'} ${t.label} — $${(t.priceCents / 100).toFixed(0)} per day`}
                              onClick={() => setTruckPicks(active ? [] : [{ id: t.id, qty: 1 }])}
                              className={`relative flex flex-col items-center gap-1 rounded-lg border overflow-hidden text-center transition-all duration-300 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent ${
                                active
                                  ? 'border-brand-accent bg-brand-accent/10 ring-1 ring-brand-accent/50 shadow-[0_0_24px_rgba(255,107,26,0.28)]'
                                  : 'border-brand-line bg-bg-primary hover:border-brand-accent hover:shadow-[0_0_20px_rgba(255,107,26,0.15)]'
                              }`}
                            >
                              <div className="relative w-full overflow-hidden">
                                {t.image ? (
                                  <img
                                    src={t.image}
                                    alt={t.label}
                                    loading="lazy"
                                    className={`w-full aspect-[1600/621] object-cover transition-transform duration-300 ${active ? 'scale-[1.03]' : 'group-hover:scale-[1.02]'}`}
                                  />
                                ) : (
                                  <div className="w-full aspect-[1600/621] bg-bg-muted flex items-center justify-center text-2xl">
                                    🚚
                                  </div>
                                )}
                                {active && (
                                  <span
                                    aria-hidden
                                    className="absolute right-1.5 top-1.5 inline-flex h-6 w-6 items-center justify-center rounded-full bg-brand-accent text-bg-primary text-sm font-bold shadow-[0_2px_8px_rgba(0,0,0,0.45)]"
                                  >
                                    ✓
                                  </span>
                                )}
                              </div>
                              <div className="p-2 flex flex-col items-center gap-0.5">
                                <span className={`font-mono text-xs font-bold transition-colors ${active ? 'text-brand-accent' : 'text-brand-ink group-hover:text-brand-accent'}`}>{t.label}</span>
                                <span className="text-[10px] text-brand-accent font-mono">${(t.priceCents / 100).toFixed(0)}/day</span>
                                <span className="text-[10px] text-brand-mute leading-tight">{t.sub}</span>
                                <span className="text-[9px] text-brand-mute/70 italic">Insurance included</span>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                      {truckPicks.length > 0 ? (
                        <div className="flex items-center gap-2 rounded-md border border-brand-accent/40 bg-brand-accent/10 px-3 py-2 text-[11px] font-mono text-brand-accent">
                          <span aria-hidden>✓</span>
                          <span>
                            {rentalById(truckPicks[0]?.id ?? '')?.label ?? ''} added —{' '}
                            ${((rentalById(truckPicks[0]?.id ?? '')?.priceCents ?? 0) / 100).toFixed(0)}/day in your estimate.
                          </span>
                          <button
                            type="button"
                            onClick={() => setTruckPicks([])}
                            className="ml-auto text-brand-mute underline-hover hover:text-red-400"
                          >
                            Clear
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setShowUhaul(false)}
                          className="text-[11px] text-brand-mute underline-hover hover:text-brand-ink"
                        >
                          Never mind — hide U-Haul
                        </button>
                      )}
                    </div>
                    </>
                    )}
                  </div>
                  )}

                  {(() => {
                    // Pure-OR Continue validation — single-day vs multi-day branches
                    // are mutually exclusive, never gated by both. Root cause of the
                    // prior bug: `!date || !selectedSlot` blocked multi-day because
                    // multi-day flows never pick a slot (each day is flexible-time).
                    // Subscription bundles its own start time (no availability slot), so it
                    // is ready on start-date + ≥1 weekday. One-time single-day still needs a slot.
                    const subReady =
                      subMode &&
                      Boolean(date) &&
                      (isDateBasedFrequency(subFrequency) || subscriptionWeekdays.length > 0);
                    const singleDayReady = !multiDayMode && !subMode && Boolean(date) && Boolean(selectedSlot);
                    const multiDayReady =
                      multiDayMode &&
                      multiDates.length >= 1 &&
                      multiDates.every((d) => {
                        const dh = multiPerHours[d] ?? PER_DAY_DEFAULT_HOURS;
                        const dc = multiPerCrew[d] ?? PER_DAY_DEFAULT_CREW;
                        return dh > 0 && dc >= 1;
                      });
                    const canContinue = multiDayMode ? multiDayReady : subMode ? subReady : singleDayReady;
                    const continueHint = multiDayMode
                      ? multiDates.length === 0
                        ? 'Pick at least one day on the calendar.'
                        : multiDates.length === 1
                          ? 'Add a second day or uncheck "Pick multiple days".'
                          : ''
                      : subMode
                        ? !date
                          ? 'Pick a start date on the calendar.'
                          : !isDateBasedFrequency(subFrequency) && subscriptionWeekdays.length === 0
                            ? 'Pick at least one weekday for your subscription.'
                            : ''
                        : !date
                          ? 'Pick a date on the calendar.'
                          : !selectedSlot
                            ? 'Pick a start time below.'
                            : '';
                    return (
                      <>
                        <button
                          type="button"
                          data-testid="booking-schedule-continue"
                          disabled={!canContinue}
                          onClick={() => {
                            track(FUNNEL.detailsOpened, {
                              date,
                              hours,
                              crew,
                              totalCents: chargeCents,
                            });
                            setStep('details');
                            // Scroll back to the top of the booking form so the customer
                            // starts the details step at the top, not mid-scroll.
                            requestAnimationFrame(() => {
                              if (sectionRef.current) {
                                const top =
                                  sectionRef.current.getBoundingClientRect().top + window.scrollY - 80;
                                window.scrollTo({ top, behavior: 'smooth' });
                              }
                            });
                          }}
                          className="btn-primary btn-arrow w-full disabled:opacity-40 disabled:cursor-not-allowed"
                        >
                          Continue <span data-btn-arrow aria-hidden>→</span>
                        </button>
                        {!canContinue && continueHint && (
                          <p className="mt-2 text-center text-[11px] text-brand-mute font-mono">
                            {continueHint}
                          </p>
                        )}
                      </>
                    );
                  })()}
                </>
              )}

              {step === 'details' && (
                <div key="step-details" className="bcl-step-enter space-y-6">
                  {/* AI Quote Optimizer — flag-gated (ai_quote_optimizer),
                      default OFF → renders null. When ON, calls POST /api/ai/quote-optimizer
                      with the selected services/hours/zip/urgency and surfaces 6 ranked
                      crew-size × hours × truck combos as a picker card. Additive — does
                      not control booking state; host wires onPick to set crew/hours/truck. */}
                  {aiQuoteOptimizerFlag && services.length > 0 && hours > 0 && (
                    <QuoteOptimizer
                      services={services}
                      estimatedHours={hours}
                      zip={zip}
                      city={city}
                      urgency={
                        !date ? 'flexible'
                        : date === nyToday() ? 'same_day'
                        : date === (() => { const d = new Date(nyToday()); d.setDate(d.getDate() + 1); return d.toISOString().slice(0, 10); })() ? 'next_day'
                        : new Date(date).getTime() - new Date(nyToday()).getTime() < 7 * 86400000 ? 'this_week'
                        : 'flexible'
                      }
                      truckNeeded={truckPicks.length > 0}
                      onPick={(combo) => {
                        if (combo.crewSize) setCrew(combo.crewSize as 1 | 2 | 3 | 4);
                        if (combo.hours) setHours(combo.hours);
                      }}
                    />
                  )}

                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="bk-first-name" className="label">
                        First name
                      </label>
                      <input
                        id="bk-first-name"
                        type="text"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        autoComplete="given-name"
                        placeholder="First"
                        required
                        minLength={1}
                        maxLength={60}
                        className="input w-full"
                      />
                    </div>
                    <div>
                      <label htmlFor="bk-last-name" className="label">
                        Last name
                      </label>
                      <input
                        id="bk-last-name"
                        type="text"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        autoComplete="family-name"
                        placeholder="Last"
                        required
                        minLength={1}
                        maxLength={60}
                        className="input w-full"
                      />
                    </div>
                    <div>
                      <label htmlFor="bk-email" className="label">
                        Email
                      </label>
                      <input
                        id="bk-email"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        autoComplete="email"
                        placeholder="you@example.com"
                        required
                        maxLength={160}
                        className="input w-full"
                      />
                    </div>
                    <div>
                      <label htmlFor="bk-phone" className="label">
                        Phone
                      </label>
                      <input
                        id="bk-phone"
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(maskPhone(e.target.value))}
                        autoComplete="tel"
                        inputMode="tel"
                        placeholder="(201) 555-0100"
                        maxLength={16}
                        className="input w-full"
                      />
                    </div>
                    {/* Contact preferences + SMS consent — full-width row below both
                        Email and Phone. All three are opt-in checkboxes; the TCPA
                        disclosure sits with them at the point of consent. */}
                    <div className="sm:col-span-2 space-y-2.5 rounded-lg border border-brand-line bg-bg-elevated/40 p-4">
                      <label className="flex cursor-pointer items-start gap-2.5">
                        <input
                          type="checkbox"
                          checked={emailOptIn}
                          onChange={(e) => setEmailOptIn(e.target.checked)}
                          className="mt-0.5 h-4 w-4 shrink-0 accent-brand-accent"
                        />
                        <span className="text-xs leading-snug text-brand-mute">
                          Monthly newsletter — seasonal tips + off-peak deals, one email max.
                        </span>
                      </label>
                      <label className="flex cursor-pointer items-start gap-2.5">
                        <input
                          type="checkbox"
                          checked={smsOptIn}
                          onChange={(e) => setSmsOptIn(e.target.checked)}
                          className="mt-0.5 h-4 w-4 shrink-0 accent-brand-accent"
                        />
                        <span className="text-xs leading-snug text-brand-mute">
                          Day-before SMS reminder — reply STOP anytime.
                        </span>
                      </label>
                      <label className="flex cursor-pointer items-start gap-2.5">
                        <input
                          type="checkbox"
                          checked={marketingSmsOptIn}
                          onChange={(e) => setMarketingSmsOptIn(e.target.checked)}
                          className="mt-0.5 h-4 w-4 shrink-0 accent-brand-accent"
                        />
                        <span className="text-xs leading-snug text-brand-mute">
                          Send me seasonal tips + off-peak deals by text (1-2/quarter, opt out
                          anytime).
                        </span>
                      </label>
                      <SmsConsentDisclosure className="mt-1" />
                    </div>
                    <div className="sm:col-span-2 relative">
                      <label
                        htmlFor="bk-business"
                        className="label flex items-center justify-between"
                      >
                        <span>
                          Business name{' '}
                          <span className="text-brand-mute font-normal">
                            (optional — commercial, landlord, restaurant)
                          </span>
                        </span>
                        {businessLoading && (
                          <span className="text-brand-mute font-normal text-xs">
                            <span className="spinner mr-1" />
                            searching…
                          </span>
                        )}
                      </label>
                      <input
                        id="bk-business"
                        type="text"
                        role="combobox"
                        aria-expanded={showBusinessSuggestions && businessSuggestions.length > 0}
                        aria-autocomplete="list"
                        aria-controls="bk-business-list"
                        aria-activedescendant={comboboxActiveDescendant(
                          'bk-business-list',
                          showBusinessSuggestions ? activeBusinessSuggestion : -1,
                        )}
                        value={businessName}
                        onChange={(e) => {
                          setBusinessName(e.target.value);
                          setShowBusinessSuggestions(true);
                          setActiveBusinessSuggestion(-1);
                          if (
                            businessSelectedRef.current &&
                            e.target.value !== businessSelectedRef.current
                          ) {
                            businessSelectedRef.current = '';
                            setBusinessFilled([]);
                          }
                        }}
                        onFocus={() => {
                          setShowBusinessSuggestions(true);
                          setBusinessFocused(true);
                        }}
                        onBlur={() => {
                          setTimeout(() => {
                            setShowBusinessSuggestions(false);
                            setBusinessFocused(false);
                            setActiveBusinessSuggestion(-1);
                          }, 150);
                        }}
                        onKeyDown={(e) => {
                          if (!businessSuggestions.length) return;
                          // ARIA editable-combobox keynav (Arrow/Home/End, wrapping)
                          // via the shared reducer — Home/End were the missing keys.
                          const navIdx = comboboxNextActiveIndex(
                            e.key,
                            activeBusinessSuggestion,
                            businessSuggestions.length,
                          );
                          if (navIdx !== null) {
                            e.preventDefault();
                            setShowBusinessSuggestions(true);
                            setActiveBusinessSuggestion(navIdx);
                          } else if (e.key === 'Enter' && activeBusinessSuggestion >= 0) {
                            e.preventDefault();
                            const pick = businessSuggestions[activeBusinessSuggestion];
                            if (pick) selectBusinessSuggestion(pick);
                          } else if (e.key === 'Escape') {
                            setShowBusinessSuggestions(false);
                            setActiveBusinessSuggestion(-1);
                          }
                        }}
                        autoComplete="organization"
                        placeholder={
                          autocompleteDisabled
                            ? "Acme Realty, Joe's Diner, etc."
                            : 'Start typing — pick from the list'
                        }
                        maxLength={160}
                        className="input w-full"
                      />
                      {businessFocused &&
                        showBusinessSuggestions &&
                        businessSuggestions.length > 0 && (
                          <ul
                            id="bk-business-list"
                            role="listbox"
                            className="absolute z-20 mt-1 w-full max-h-72 overflow-auto rounded-lg border border-brand-line bg-bg-elevated shadow-lg"
                          >
                            {businessSuggestions.map((s, i) => {
                              const active = i === activeBusinessSuggestion;
                              return (
                                <li
                                  key={s.placeId}
                                  id={comboboxOptionId('bk-business-list', i)}
                                  role="option"
                                  aria-selected={active}
                                >
                                  <button
                                    type="button"
                                    onMouseDown={(e) => e.preventDefault()}
                                    onMouseEnter={() => setActiveBusinessSuggestion(i)}
                                    onClick={() => selectBusinessSuggestion(s)}
                                    className={`flex w-full flex-col items-start gap-0.5 px-3 py-2 text-left text-sm transition-colors ${
                                      active
                                        ? 'bg-brand-accent/15 text-brand-ink'
                                        : 'hover:bg-brand-accent/10 focus:bg-brand-accent/10 focus:outline-none'
                                    }`}
                                  >
                                    <span className="text-brand-ink">{s.primary}</span>
                                    {s.secondary && (
                                      <span className="text-xs text-brand-mute">{s.secondary}</span>
                                    )}
                                  </button>
                                </li>
                              );
                            })}
                          </ul>
                        )}
                      {businessError && (
                        <p role="alert" className="mt-1 text-[11px] text-red-400 bcl-field-error">{businessError}</p>
                      )}
                      {!autocompleteDisabled &&
                        businessName &&
                        businessSelectedRef.current === businessName &&
                        businessFilled.length > 0 && (
                          <p className="mt-1 text-[11px] text-brand-accent font-mono">
                            ✓ {formatFilledFields(businessFilled)} auto-filled from the business
                            listing — edit if needed
                          </p>
                        )}
                    </div>
                    <div className="sm:col-span-2 relative">
                      <label
                        htmlFor="bk-address"
                        className="label flex items-center justify-between"
                      >
                        <span>Job address</span>
                        {addressLoading && (
                          <span className="text-brand-mute font-normal text-xs">
                            <span className="spinner mr-1" />
                            looking up…
                          </span>
                        )}
                      </label>
                      <input
                        id="bk-address"
                        type="text"
                        role="combobox"
                        aria-expanded={showSuggestions && addressSuggestions.length > 0}
                        aria-autocomplete="list"
                        aria-controls="bk-address-list"
                        aria-activedescendant={comboboxActiveDescendant(
                          'bk-address-list',
                          showSuggestions ? activeSuggestion : -1,
                        )}
                        value={addressQuery}
                        onChange={(e) => {
                          setAddressQuery(e.target.value);
                          setShowSuggestions(true);
                          setActiveSuggestion(-1);
                          if (placeId) setPlaceId('');
                        }}
                        onFocus={() => {
                          setShowSuggestions(true);
                          setAddressFocused(true);
                        }}
                        onBlur={() => {
                          setTimeout(() => {
                            setShowSuggestions(false);
                            setAddressFocused(false);
                            setActiveSuggestion(-1);
                          }, 150);
                        }}
                        onKeyDown={(e) => {
                          if (!addressSuggestions.length) return;
                          // ARIA editable-combobox keynav (Arrow/Home/End, wrapping)
                          // via the shared reducer — Home/End were the missing keys.
                          const navIdx = comboboxNextActiveIndex(
                            e.key,
                            activeSuggestion,
                            addressSuggestions.length,
                          );
                          if (navIdx !== null) {
                            e.preventDefault();
                            setShowSuggestions(true);
                            setActiveSuggestion(navIdx);
                          } else if (e.key === 'Enter' && activeSuggestion >= 0) {
                            e.preventDefault();
                            const pick = addressSuggestions[activeSuggestion];
                            if (pick) selectSuggestion(pick);
                          } else if (e.key === 'Escape') {
                            setShowSuggestions(false);
                            setActiveSuggestion(-1);
                          }
                        }}
                        autoComplete="street-address"
                        placeholder={
                          autocompleteDisabled
                            ? '123 Main St, Newark, NJ 07102'
                            : 'Start typing — pick your address'
                        }
                        maxLength={240}
                        className="input w-full"
                        required
                      />
                      {addressFocused && showSuggestions && addressSuggestions.length > 0 && (
                        <ul
                          id="bk-address-list"
                          role="listbox"
                          className="absolute z-20 mt-1 w-full max-h-72 overflow-auto rounded-lg border border-brand-line bg-bg-elevated shadow-lg"
                        >
                          {addressSuggestions.map((s, i) => {
                            const active = i === activeSuggestion;
                            return (
                              <li
                                key={s.placeId}
                                id={comboboxOptionId('bk-address-list', i)}
                                role="option"
                                aria-selected={active}
                              >
                                <button
                                  type="button"
                                  onMouseDown={(e) => e.preventDefault()}
                                  onMouseEnter={() => setActiveSuggestion(i)}
                                  onClick={() => selectSuggestion(s)}
                                  className={`flex w-full flex-col items-start gap-0.5 px-3 py-2 text-left text-sm transition-colors ${
                                    active
                                      ? 'bg-brand-accent/15 text-brand-ink'
                                      : 'hover:bg-brand-accent/10 focus:bg-brand-accent/10 focus:outline-none'
                                  }`}
                                >
                                  <span className="text-brand-ink">{s.primary}</span>
                                  {s.secondary && (
                                    <span className="text-xs text-brand-mute">{s.secondary}</span>
                                  )}
                                </button>
                              </li>
                            );
                          })}
                        </ul>
                      )}
                      {autocompleteDisabled && (
                        <p className="mt-1 text-[11px] text-brand-mute">
                          Address search offline — type the full street address, city, and ZIP.
                        </p>
                      )}
                      {addressError && (
                        <p role="alert" className="mt-1 text-[11px] text-red-400 bcl-field-error">{addressError}</p>
                      )}
                      {!autocompleteDisabled &&
                        addressQuery.length >= 3 &&
                        address &&
                        city &&
                        zip && (
                          <p className="mt-1 text-[11px] text-brand-accent font-mono">
                            ✓ {address}, {city} {zip}
                          </p>
                        )}
                    </div>
                    <div className="sm:col-span-2">
                      <div className="mb-2 flex flex-wrap items-center justify-between gap-3">
                        <label htmlFor="bk-notes" className="label mb-0">
                          What needs doing?{' '}
                          <span className="text-brand-mute font-normal">(optional)</span>
                        </label>
                        <button
                          type="button"
                          onClick={improveScope}
                          disabled={notes.trim().length < 4 || scopeImproveBusy}
                          className="ml-auto inline-flex items-center gap-1.5 rounded-md border border-brand-accent/40 bg-brand-accent/10 px-3 py-1.5 font-mono text-[11px] uppercase tracking-widest text-brand-accent transition-colors hover:border-brand-accent hover:bg-brand-accent/20 disabled:opacity-40 disabled:cursor-not-allowed"
                          aria-label="Use AI to improve scope wording"
                          title="Reformat scope into a tight crew-readable list"
                        >
                          {scopeImproveBusy ? (
                            <span className="flex items-center gap-1.5">
                              <span className="spinner" /> improving…
                            </span>
                          ) : (
                            <>✨ AI Improve</>
                          )}
                        </button>
                      </div>
                      <textarea
                        id="bk-notes"
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        placeholder="Power wash driveway + back patio, about 1,500 sq ft…"
                        rows={3}
                        maxLength={2000}
                        aria-describedby="bk-notes-count"
                        className="input w-full resize-none"
                      />
                      {(() => {
                        const cc = charCounterState(notes.length, 2000);
                        return (
                          <span
                            id="bk-notes-count"
                            data-testid="bk-notes-char-count"
                            aria-live="polite"
                            className={`mt-1 block text-right text-xs tabular-nums transition-colors duration-[333ms] ${NOTES_COUNTER_TONE_CLASS[cc.tone]}`}
                          >
                            {formCopy.charsLeft.replace('{n}', String(cc.remaining))}
                          </span>
                        );
                      })()}
                      {scopeImproveError && (
                        <p role="alert" className="mt-1 text-[11px] text-red-400 bcl-field-error">{scopeImproveError}</p>
                      )}
                      {scopeOriginalBeforeImprove !== null &&
                        !scopeImproveBusy &&
                        !scopeImproveError && (
                          <p className="mt-1 text-[11px] text-brand-mute">
                            AI rewrote your scope.{' '}
                            <button
                              type="button"
                              onClick={undoScopeImprove}
                              className="text-brand-accent underline-hover"
                            >
                              Undo
                            </button>
                          </p>
                        )}
                    </div>
                  </div>


                  <fieldset
                    className={`rounded-lg transition-colors ${
                      referralExpanded
                        ? 'space-y-2 border border-brand-line bg-bg-elevated/40 p-4'
                        : 'border border-transparent'
                    }`}
                  >
                    <legend className="label px-1">
                      <button
                        type="button"
                        onClick={() => setReferralExpanded((v) => !v)}
                        className="flex items-center gap-1 text-left hover:text-brand-accent"
                        aria-expanded={referralExpanded}
                        aria-controls="bk-referral-panel"
                      >
                        Have a referral code?{' '}
                        <span className="text-brand-mute font-normal">
                          (friends save ${REFERRAL_DISCOUNT}) {referralExpanded ? '−' : '+'}
                        </span>
                      </button>
                    </legend>
                    {referralExpanded && (
                      <div id="bk-referral-panel" className="space-y-2">
                        <input
                          id="bk-referral"
                          type="text"
                          value={referralCode}
                          onChange={(e) => setReferralCode(e.target.value.toUpperCase().slice(0, 16))}
                          placeholder="BCL-FRIEND"
                          maxLength={16}
                          className="input w-full font-mono uppercase tracking-wider"
                          autoComplete="off"
                          spellCheck={false}
                        />
                        {referralCode.trim() && (
                          <p
                            className={`text-[11px] font-mono ${pricing.referralValid ? 'text-emerald-300' : 'text-brand-mute'}`}
                          >
                            {pricing.referralValid
                              ? `✓ Code accepted — $${REFERRAL_DISCOUNT} off today.`
                              : 'Codes are 3 — 12 letters/numbers/dashes. Check your invite link.'}
                          </p>
                        )}
                      </div>
                    )}
                  </fieldset>

                  {/* §coupon — first-booking $25 off codes minted from
                      city-page email capture (see CityEmailCapture). Worker
                      validates value/expiry/min-spend on submit; we optimistically
                      surface the discount once format checks. */}
                  <fieldset
                    className={`rounded-lg transition-colors ${
                      couponExpanded
                        ? 'space-y-2 border border-brand-line bg-bg-elevated/40 p-4'
                        : 'border border-transparent'
                    }`}
                  >
                    <legend className="label px-1">
                      <button
                        type="button"
                        onClick={() => setCouponExpanded((v) => !v)}
                        className="flex items-center gap-1 text-left hover:text-brand-accent"
                        aria-expanded={couponExpanded}
                        aria-controls="bk-coupon-panel"
                      >
                        Have a coupon?{' '}
                        <span className="text-brand-mute font-normal">
                          {couponExpanded ? '−' : '+'}
                        </span>
                      </button>
                    </legend>
                    {couponExpanded && (
                      <div id="bk-coupon-panel" className="space-y-2">
                        <input
                          id="bk-coupon"
                          type="text"
                          value={couponCode}
                          onChange={(e) => {
                            setCouponCode(e.target.value.toUpperCase().slice(0, 14));
                            setCouponServerError('');
                          }}
                          placeholder="BCL-XXXX-XXXX"
                          maxLength={14}
                          className="input w-full font-mono uppercase tracking-wider"
                          autoComplete="off"
                          spellCheck={false}
                          data-bcl-coupon-input
                        />
                        {couponCode.trim() && (
                          <p
                            className={`text-[11px] font-mono ${
                              couponServerError
                                ? 'text-amber-300'
                                : couponFormatOk
                                  ? 'text-emerald-300'
                                  : 'text-brand-mute'
                            }`}
                            data-bcl-coupon-status
                          >
                            {couponServerError
                              ? couponServerError
                              : couponFormatOk
                                ? `✓ Code applied — $${couponOff} off when min $100 reached.`
                                : 'Format is BCL-XXXX-XXXX. Check the email we sent.'}
                          </p>
                        )}
                      </div>
                    )}
                  </fieldset>

                  {multiDayMode && multiDates.length >= 1 ? (
                    <fieldset className="space-y-2" data-testid="payment-multiday-note">
                      <legend className="label mb-2">Payment</legend>
                      <p className="text-[11px] text-brand-mute">
                        Multi-day jobs are <strong>$0 today</strong> — we keep a pre-authorized card on
                        file and charge it after each day's crew finishes, for the actual time worked
                        (1-hour minimum). Cancel any day free up to 24h before.
                      </p>
                    </fieldset>
                  ) : (
                  <fieldset className="space-y-2">
                    <legend className="label mb-2">Payment</legend>
                    <div role="radiogroup" className="grid sm:grid-cols-3 gap-2">
                      {(
                        [
                          {
                            id: 'deposit',
                            title: `$${fmtMoney(depositPlan.depositCents)} deposit`,
                            sub: depositPlan.coversFullJob
                              ? 'Lock slot. Covers the full job.'
                              : `Lock slot. $${fmtMoney(depositPlan.restCents)} after.`,
                            // Genuine lowest-friction, pro-customer default: hold the slot now,
                            // pay the balance only AFTER the crew finishes. Not a dark pattern —
                            // it defers most of the charge. Hide the nudge on the $50-min job
                            // where deposit == full so the badge can't mislead.
                            badge: depositPlan.coversFullJob ? undefined : 'Recommended',
                          },
                          {
                            id: 'full',
                            title: `Pay $${fmtMoney(pricing.subtotalCents)} now`,
                            sub: 'Full prepay via Square.',
                          },
                          { id: 'later', title: 'Pay after the job', sub: 'Pre-authorized card on file — $0 today.' },
                        ] as Array<{
                          id: PaymentMode;
                          title: string;
                          sub: string;
                          badge?: string;
                        }>
                      ).map((opt, payIdx) => {
                        const active = paymentMode === opt.id;
                        return (
                          <button
                            key={opt.id}
                            type="button"
                            role="radio"
                            aria-checked={active}
                            onClick={() => setPaymentMode(opt.id)}
                            {...paymentRadio(payIdx, active)}
                            className={`relative text-left rounded-lg border px-3 py-3 transition-colors duration-[333ms] ${
                              active
                                ? 'border-brand-accent bg-brand-accent/10 text-brand-ink'
                                : 'border-brand-line bg-bg-elevated/40 text-brand-mute hover:border-brand-accent hover:text-brand-ink'
                            }`}
                          >
                            {opt.badge && (
                              <span
                                data-testid="payment-recommended-badge"
                                className="absolute -top-2 right-2 rounded-full bg-brand-accent px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-bg-primary shadow-sm"
                              >
                                {opt.badge}
                              </span>
                            )}
                            <div
                              className={`font-mono text-sm font-bold ${active ? 'text-brand-accent' : ''}`}
                            >
                              {opt.title}
                            </div>
                            <div className="text-[11px] mt-0.5">{opt.sub}</div>
                          </button>
                        );
                      })}
                    </div>
                    <p className="text-[11px] text-brand-mute">
                      {paymentMode === 'deposit' &&
                        (depositPlan.coversFullJob ? (
                          <>
                            We'll bounce you to Square to pay ${fmtMoney(depositPlan.depositCents)}{' '}
                            right after Confirm — that covers the full job, nothing billed after.
                          </>
                        ) : (
                          <>
                            We'll bounce you to Square to pay the ${fmtMoney(depositPlan.depositCents)}{' '}
                            deposit right after Confirm. ${fmtMoney(depositPlan.restCents)} billed
                            after the job.
                          </>
                        ))}
                      {paymentMode === 'full' && (
                        <>
                          We'll bounce you to Square to pay ${fmtMoney(pricing.subtotalCents)} in
                          full right after Confirm.
                        </>
                      )}
                      {paymentMode === 'later' && (
                        <>
                          We keep a <strong>pre-authorized card on file</strong> — <strong>$0 charged
                          today</strong>. We only charge it after the crew finishes, for the actual
                          time worked (1-hour minimum). Cancel free up to 24h before.
                        </>
                      )}
                    </p>
                  </fieldset>
                  )}

                  {/* BNPL toggle — flag-gated dark launch (migration 0149).
                      When ON + total >= $500, surfaces Klarna/Afterpay tab.
                      Below $500 the component self-hides silently. */}
                  {bnplToggleFlag && (
                    <BnplToggle
                      mode="card"
                      onChange={() => {}}
                      totalCents={pricing.subtotalCents}
                    />
                  )}

                  {/* DepositPicker — flag-gated dark launch (migration 0149).
                      Styled two-row deposit picker (partial vs full) alternate
                      to the native radiogroup above. */}
                  {depositPickerFlag && (
                    <DepositPicker
                      value={paymentMode === 'deposit' ? 'partial' : 'full'}
                      onChange={() => {}}
                      totalCents={pricing.subtotalCents}
                    />
                  )}

                  {/* SPEC § "Consent UI" — explicit, mode-adaptive payment
                      authorization the customer must see and agree to BEFORE the
                      booking is placed. Same shared copy the worker would render. */}
                  <div
                    data-bcl-payment-authorization
                    className={`rounded-lg border p-3 transition-colors duration-[333ms] ${
                      paymentAuth.authorizesCharge
                        ? 'border-brand-accent/40 bg-brand-accent/[0.05]'
                        : 'border-brand-line bg-bg-elevated/40'
                    }`}
                  >
                    <p className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
                      {paymentAuth.heading}
                    </p>
                    <p className="mt-1.5 text-[13px] text-brand-ink leading-relaxed">
                      {paymentAuth.consent}
                    </p>
                  </div>

                  {/* Hazardous-material exclusion (P1-19) — disclosed at point of
                      sale as a liability shield AND an honesty surface. The list
                      is single-sourced from src/shared/prohibited-items.ts so it
                      can never drift from what the crew enforces in the field. */}
                  <div
                    data-bcl-prohibited-items
                    className="rounded-lg border border-brand-line bg-bg-elevated/40 p-4"
                  >
                    <p className="font-mono text-[11px] uppercase tracking-widest text-brand-mute">
                      What the crew can&rsquo;t take
                    </p>
                    <p className="mt-1.5 text-[13px] text-brand-ink leading-relaxed">
                      We&rsquo;re casual hourly labor — not a licensed hazmat or abatement
                      hauler. If your job has any of these, we&rsquo;ll point you to the right
                      licensed vendor:
                    </p>
                    <ul className="mt-2.5 grid gap-2 sm:grid-cols-2">
                      {PROHIBITED_ITEMS.map((item) => (
                        <li key={item.id} className="flex items-start gap-2 text-xs leading-snug">
                          <span aria-hidden="true" className="mt-0.5 text-brand-accent">
                            ✕
                          </span>
                          <span className="text-brand-mute">
                            <span className="text-brand-ink font-medium">{item.label}</span>{' '}
                            <span className="text-brand-mute/80">— {item.examples}.</span>{' '}
                            <span className="text-brand-mute/70">{item.reason}.</span>
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <label className="flex items-start gap-3 cursor-pointer rounded-lg border border-brand-line bg-bg-elevated/40 p-3 transition-colors duration-[333ms] hover:border-brand-accent/50">
                    <input
                      id="bk-acknowledge"
                      type="checkbox"
                      checked={acknowledged}
                      onChange={(e) => setAcknowledged(e.target.checked)}
                      required
                      className="accent-brand-accent w-4 h-4 mt-0.5"
                    />
                    <span className="text-sm text-brand-mute leading-relaxed">
                      I understand Brick Labor is casual help, not a licensed contractor
                      {paymentAuth.authorizesCharge
                        ? ', and I authorize the payment above'
                        : ''}
                      . {PROHIBITED_ACK_LINE} See the{' '}
                      <a href={lpHref('/terms')} className="text-brand-accent underline-hover">
                        Terms
                      </a>
                      .
                    </span>
                  </label>

                  <div className="rounded-lg border border-brand-accent/40 bg-brand-accent/[0.04] p-4">
                    <p className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
                      What happens after you book
                    </p>
                    <ul className="mt-2 space-y-1.5 text-xs text-brand-ink leading-relaxed">
                      <li>
                        <span className="text-brand-accent">•</span> Email + calendar invite hit
                        your inbox immediately.
                      </li>
                      <li>
                        <span className="text-brand-accent">•</span> Day-before reminder text from
                        the dispatcher.
                      </li>
                      <li>
                        <span className="text-brand-accent">•</span> Morning-of text from the crew
                        leader before they roll.
                      </li>
                      <li>
                        <span className="text-brand-accent">•</span> Anything goes sideways? Call or
                        text{' '}
                        <a
                          href={PHONE_TEL_HREF}
                          className="text-brand-accent underline-hover font-mono"
                        >
                          (855) 82LABOR
                        </a>{' '}
                        — 100% satisfaction guaranteed, automatic refund.
                      </li>
                    </ul>
                  </div>

                  <div className="flex gap-3">
                    <button
                      type="button"
                      onClick={() => setStep('schedule')}
                      className="btn-secondary flex-1"
                    >
                      ← Back
                    </button>
                    <button
                      type="button"
                      disabled={!name || !email || !acknowledged}
                      onClick={() => {
                        track(FUNNEL.detailsOpened, {
                          stage: 'ai-review-handoff',
                          totalCents: chargeCents,
                        });
                        setStep('ai-review');
                      }}
                      className="btn-primary btn-arrow flex-[2] disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      Continue · Fair-price check <span data-btn-arrow aria-hidden>→</span>
                    </button>
                  </div>
                </div>
              )}

              {step === 'ai-review' && (
                <div key="step-ai-review" className="bcl-step-enter space-y-6">
                  <div className="rounded-lg border border-brand-accent/40 bg-brand-accent/[0.04] p-4">
                    <p className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
                      AI scope review
                    </p>
                    <h3 className="mt-1 font-display text-lg font-bold text-brand-ink">
                      A few quick clarifiers — all optional.
                    </h3>
                    <p className="mt-1 text-sm text-brand-mute">
                      Our AI read your job and pulled a few tap-to-answer questions that help the crew
                      show up ready. Answer any that fit — skip the rest, your booking still works.
                    </p>
                  </div>

                  {reviewLoading && (
                    <div className="rounded-lg border border-brand-line bg-bg-primary/40 p-4 text-sm text-brand-mute">
                      <span className="spinner mr-2" /> Reading your job + drafting clarifiers…
                    </div>
                  )}

                  {reviewError && !reviewLoading && (
                    <div className="rounded-lg border border-amber-400/40 bg-amber-400/[0.04] p-3 text-sm text-amber-200">
                      {reviewError}
                    </div>
                  )}

                  {!reviewLoading && reviewQuestions.length > 0 && (
                    <div className="space-y-4">
                      {reviewQuestions.map((q, qIdx) => {
                        const picked = reviewAnswers[q.id] ?? [];
                        const isOpenEnded = q.inputType === 'text' || q.inputType === 'textarea';
                        const textValue = reviewText[q.id] ?? '';
                        const minChars = Math.max(
                          3,
                          q.minChars ?? (q.inputType === 'textarea' ? 20 : 3),
                        );
                        const validText = isOpenEnded && textValue.trim().length >= minChars;
                        return (
                          <div
                            key={q.id}
                            className="rounded-xl border border-brand-line bg-bg-elevated/40 p-4 ai-question-card"
                            style={{
                              animation: `aiQuestionIn 360ms cubic-bezier(0.2, 0.8, 0.2, 1) ${qIdx * 80}ms both`,
                            }}
                          >
                            <div className="flex items-start justify-between gap-3">
                              <div className="min-w-0">
                                <p className="font-display text-base font-bold text-brand-ink leading-snug">
                                  <span className="font-mono text-xs text-brand-accent mr-2">
                                    {String(qIdx + 1).padStart(2, '0')}
                                  </span>
                                  {q.question}
                                </p>
                                {q.helper && (
                                  <p className="mt-1 text-[11px] text-brand-mute leading-relaxed">
                                    {q.helper}
                                  </p>
                                )}
                              </div>
                              {q.multi && q.inputType !== 'text' && q.inputType !== 'textarea' && (
                                <span className="shrink-0 rounded-md bg-brand-accent/15 px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider text-brand-accent">
                                  pick any
                                </span>
                              )}
                              {isOpenEnded && (
                                <span
                                  className={`shrink-0 inline-flex h-6 w-6 items-center justify-center rounded-full border transition-all duration-200 ${
                                    validText
                                      ? 'border-emerald-400 bg-emerald-400/15 text-emerald-300 shadow-[0_0_0_2px_rgba(52,211,153,0.18)]'
                                      : 'border-brand-line bg-bg-primary/40 text-brand-mute'
                                  }`}
                                  aria-label={validText ? 'Answer accepted' : 'Open-ended answer'}
                                  title={
                                    validText
                                      ? 'Answer accepted'
                                      : `Type at least ${minChars} characters`
                                  }
                                >
                                  {validText ? (
                                    <svg
                                      viewBox="0 0 16 16"
                                      className="h-3.5 w-3.5"
                                      fill="none"
                                      stroke="currentColor"
                                      strokeWidth={2.6}
                                      strokeLinecap="round"
                                      strokeLinejoin="round"
                                      aria-hidden
                                    >
                                      <path d="M3 8.5l3 3 7-7" />
                                    </svg>
                                  ) : (
                                    <svg
                                      viewBox="0 0 16 16"
                                      className="h-3 w-3"
                                      fill="none"
                                      stroke="currentColor"
                                      strokeWidth={2.4}
                                      strokeLinecap="round"
                                      strokeLinejoin="round"
                                      aria-hidden
                                    >
                                      <path d="M3 12V4M3 4h7M3 8h6" />
                                    </svg>
                                  )}
                                </span>
                              )}
                            </div>
                            {isOpenEnded ? (
                              <div className="mt-3">
                                {q.inputType === 'textarea' ? (
                                  <textarea
                                    id={`ai-q-${q.id}`}
                                    name={`ai-q-${q.id}`}
                                    value={textValue}
                                    onChange={(e) => {
                                      const v = e.target.value.slice(0, 1500);
                                      setReviewText((prev) => ({ ...prev, [q.id]: v }));
                                    }}
                                    onBlur={() => {
                                      if (validText)
                                        track('ai_review_answered_text', {
                                          qid: q.id,
                                          chars: textValue.trim().length,
                                        });
                                    }}
                                    rows={3}
                                    maxLength={1500}
                                    placeholder={
                                      q.placeholder ?? 'Add detail — sentences are fine.'
                                    }
                                    className={`w-full resize-y rounded-lg border bg-bg-primary/40 px-3 py-2.5 text-sm text-brand-ink placeholder:text-brand-mute focus:outline-none transition-colors ${
                                      validText
                                        ? 'border-emerald-400/60 focus:border-emerald-400'
                                        : 'border-brand-line focus:border-brand-accent'
                                    }`}
                                  />
                                ) : (
                                  <input
                                    id={`ai-q-${q.id}`}
                                    name={`ai-q-${q.id}`}
                                    type="text"
                                    value={textValue}
                                    onChange={(e) => {
                                      const v = e.target.value.slice(0, 280);
                                      setReviewText((prev) => ({ ...prev, [q.id]: v }));
                                    }}
                                    onBlur={() => {
                                      if (validText)
                                        track('ai_review_answered_text', {
                                          qid: q.id,
                                          chars: textValue.trim().length,
                                        });
                                    }}
                                    maxLength={280}
                                    placeholder={q.placeholder ?? 'Type your answer…'}
                                    className={`w-full rounded-lg border bg-bg-primary/40 px-3 py-2.5 text-sm text-brand-ink placeholder:text-brand-mute focus:outline-none transition-colors ${
                                      validText
                                        ? 'border-emerald-400/60 focus:border-emerald-400'
                                        : 'border-brand-line focus:border-brand-accent'
                                    }`}
                                  />
                                )}
                                <div className="mt-1.5 flex items-center justify-between gap-2">
                                  <p
                                    className={`font-mono text-[10px] uppercase tracking-wider ${
                                      validText ? 'text-emerald-300' : 'text-brand-mute'
                                    }`}
                                  >
                                    {validText ? '✓ Looks good' : `Type at least ${minChars} chars`}
                                  </p>
                                  <p className="font-mono text-[10px] text-brand-mute">
                                    {textValue.trim().length}/
                                    {q.inputType === 'textarea' ? 1500 : 280}
                                  </p>
                                </div>
                              </div>
                            ) : (
                              <div className="mt-3 grid gap-2 sm:grid-cols-2">
                                {q.options.map((opt, oIdx) => {
                                  const active = picked.includes(opt.id);
                                  // AI-Info questions never upsell — no "+$" badge, ever.
                                  const upsell = '';
                                  return (
                                    <button
                                      key={opt.id}
                                      type="button"
                                      onClick={() => toggleReviewAnswer(q.id, opt.id, !!q.multi)}
                                      aria-pressed={active}
                                      className={`text-left rounded-lg border px-3 py-2.5 text-sm transition-all duration-200 ${
                                        active
                                          ? 'border-brand-accent bg-brand-accent/15 text-brand-ink shadow-[0_0_0_1px_rgba(255,107,26,0.4)]'
                                          : 'border-brand-line bg-bg-primary/40 text-brand-mute hover:border-brand-accent/60 hover:text-brand-ink'
                                      }`}
                                      style={{ animationDelay: `${oIdx * 40}ms` }}
                                    >
                                      <span className="flex items-center justify-between gap-2">
                                        <span className="flex items-center gap-2 min-w-0">
                                          <span
                                            aria-hidden
                                            className={`shrink-0 inline-flex h-4 w-4 items-center justify-center rounded-full border transition-all ${
                                              active
                                                ? 'border-brand-accent bg-brand-accent text-bg-primary'
                                                : 'border-brand-line'
                                            }`}
                                          >
                                            {active && (
                                              <svg
                                                viewBox="0 0 16 16"
                                                className="h-3 w-3"
                                                fill="none"
                                                stroke="currentColor"
                                                strokeWidth={2.4}
                                                strokeLinecap="round"
                                                strokeLinejoin="round"
                                              >
                                                <path d="M3 8.5l3 3 7-7" />
                                              </svg>
                                            )}
                                          </span>
                                          <span className="truncate">{opt.label}</span>
                                        </span>
                                        {upsell && (
                                          <span
                                            className={`shrink-0 font-mono text-[11px] ${active ? 'text-brand-accent' : 'text-brand-mute'}`}
                                          >
                                            {upsell}
                                          </span>
                                        )}
                                      </span>
                                    </button>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        );
                      })}

                      <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-brand-line bg-bg-primary/40 px-4 py-3">
                        <p className="text-xs text-brand-mute font-mono">
                          {reviewAnsweredCount}/{reviewQuestions.length} answered
                          {reviewUpsellCents > 0 && (
                            <>
                              {' '}
                              · upsell{' '}
                              <span className="text-brand-accent">
                                +${Math.round(reviewUpsellCents / 100)}
                              </span>
                            </>
                          )}
                        </p>
                        {reviewAnsweredCount >= reviewQuestions.length && (
                          <button
                            type="button"
                            onClick={() => void loadReviewQuestions(true)}
                            disabled={reviewMoreLoading || reviewQuestions.length >= 8}
                            className="rounded-md border border-brand-accent/40 bg-brand-accent/10 px-3 py-1.5 font-mono text-[11px] uppercase tracking-widest text-brand-accent hover:bg-brand-accent/20 disabled:opacity-40 disabled:cursor-not-allowed"
                          >
                            {reviewMoreLoading ? (
                              <span className="flex items-center gap-1.5">
                                <span className="spinner" /> generating…
                              </span>
                            ) : reviewQuestions.length >= 8 ? (
                              <>Plenty — confirm below ↓</>
                            ) : (
                              <>+ Load more questions</>
                            )}
                          </button>
                        )}
                      </div>
                    </div>
                  )}

                  {total > 0 &&
                    (() => {
                      // The AI price comparison shows whenever the always-on web research
                      // (Tavily + Workers AI, fetched when the AI Info step opens) returns a
                      // fair-market band OR the concierge produced a structured quote — so it
                      // is reliably present on the AI Info step even before the concierge
                      // finishes its clarifiers. The market rate is an INDEPENDENT number
                      // (researched band midpoint, else the median of the AI's competitor
                      // benchmarks), NOT our own quote — our flat price sits UNDER the market.
                      const benchTotals = (aiQuote?.competitorBenchmarks ?? [])
                        .map((c) => c.totalCents)
                        .filter((n) => n > 0)
                        .sort((a, b) => a - b);
                      const medianBenchCents = benchTotals.length
                        ? (benchTotals[Math.floor((benchTotals.length - 1) / 2)] ?? 0)
                        : 0;
                      // Primary source = the real web-researched band midpoint
                      // (Tavily + Workers AI). Fallbacks: AI-review benchmarks, then premium.
                      const fmLowC = fairMarket?.comparison.marketLowCents ?? 0;
                      const fmHighC = fairMarket?.comparison.marketHighCents ?? 0;
                      const fmMidC = fmLowC && fmHighC ? Math.round((fmLowC + fmHighC) / 2) : 0;
                      // A researched band is only usable as the headline "market" number
                      // when it's at least ~our price. A band BELOW our flat rate means the
                      // research returned an hourly rate (not a job total) — showing "$50 vs
                      // $409" would falsely read as us being expensive, inverting the whole
                      // point. Fall back to the competitor-benchmark median / premium heuristic.
                      const researchedUsable = Boolean(fmMidC && fmMidC >= Math.round(total * 100 * 0.9));
                      const fairMarketCents =
                        (researchedUsable ? fmMidC : 0) ||
                        medianBenchCents ||
                        Math.round(total * 100 * 1.2);
                      const aiTotal = Math.max(total, Math.round(fairMarketCents / 100));
                      const saves = aiTotal - total; // > 0 → you pay LESS than the market rate
                      const beats = saves >= 0;
                      const researched = Boolean(
                        fairMarket?.researched && fairMarket.sources.length,
                      );
                      return (
                        <div className="relative overflow-hidden rounded-2xl border border-emerald-400/40 bg-gradient-to-br from-emerald-400/[0.08] via-bg-elevated/40 to-transparent p-4 shadow-[0_10px_40px_-16px_rgba(52,211,153,0.35)]">
                          <div
                            className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full bg-emerald-400/10 blur-2xl"
                            aria-hidden
                          />
                          <div className="flex items-center gap-2">
                            <span
                              className="flex h-6 w-6 items-center justify-center rounded-md bg-emerald-400/15 text-emerald-300"
                              aria-hidden
                            >
                              <svg viewBox="0 0 16 16" className="h-3.5 w-3.5" fill="currentColor">
                                <path d="M8 1l2 4 4 .5-3 3 .8 4L8 14.6 4.2 12.5 5 8.5 2 5.5 6 5z" />
                              </svg>
                            </span>
                            <p className="font-mono text-[11px] uppercase tracking-widest text-emerald-300">
                              AI fair-market check
                            </p>
                          </div>
                          <p className="mt-1.5 text-xs leading-relaxed text-brand-mute">
                            {researched
                              ? 'We ran live web research on current north-Jersey rates for this exact job — here’s how Brick Labor compares.'
                              : 'We passed your full job to AI for an independent fair-market rate — here’s how Brick Labor compares.'}
                          </p>
                          <div className="mt-3 grid grid-cols-2 gap-2">
                            <div className="rounded-lg border border-brand-line/60 bg-bg-primary/40 p-3">
                              <p className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
                                AI fair market
                              </p>
                              <p className="mt-0.5 font-display text-2xl font-bold text-brand-mute line-through decoration-brand-mute/40">
                                {researchedUsable && fmLowC && fmHighC
                                  ? fairMarketRange(fmLowC, fmHighC)
                                  : usd0(aiTotal * 100)}
                              </p>
                            </div>
                            <div className="rounded-lg border border-emerald-400/40 bg-emerald-400/[0.06] p-3">
                              <p className="font-mono text-[10px] uppercase tracking-widest text-emerald-300">
                                You pay
                              </p>
                              <p className="mt-0.5 font-display text-2xl font-extrabold text-brand-ink">
                                {usd0(total * 100)}
                              </p>
                            </div>
                          </div>
                          {beats && saves > 0 ? (
                            <div className="mt-3 flex items-center gap-3 rounded-xl border border-emerald-400/40 bg-gradient-to-br from-emerald-400/25 via-emerald-400/[0.08] to-transparent px-4 py-3 shadow-[0_10px_30px_-14px_rgba(52,211,153,0.5)]">
                              <div className="flex h-16 w-16 shrink-0 flex-col items-center justify-center rounded-full border border-emerald-400/50 bg-emerald-400/15 text-emerald-100">
                                <span className="font-display text-2xl font-extrabold leading-none">
                                  {Math.round((saves / aiTotal) * 100)}%
                                </span>
                                <span className="font-mono text-[8px] uppercase tracking-widest text-emerald-300">
                                  you save
                                </span>
                              </div>
                              <div className="min-w-0">
                                <p className="text-sm font-bold text-emerald-100">
                                  You save {usd0(saves * 100)} vs the fair-market rate.
                                </p>
                                <p className="mt-0.5 text-xs leading-relaxed text-emerald-200/80">
                                  Brick Labor’s flat $50/hr per person lands{' '}
                                  {Math.round((saves / aiTotal) * 100)}% under what this exact job
                                  costs elsewhere — same scope, no surge, no hidden fees.
                                </p>
                              </div>
                            </div>
                          ) : (
                            <div
                              className={`mt-3 flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold ${
                                beats
                                  ? 'bg-emerald-400/15 text-emerald-200'
                                  : 'bg-amber-400/10 text-amber-200'
                              }`}
                            >
                              {beats ? (
                                <span>✓ Right at the AI’s fair rate — a fair, honest quote.</span>
                              ) : (
                                <span>{`↑ AI reads the scope ${usd0(Math.abs(saves) * 100)} higher — may need a bit more time or crew.`}</span>
                              )}
                            </div>
                          )}
                          <p className="mt-2 font-mono text-[10px] leading-relaxed text-brand-mute">
                            {aiQuote
                              ? `${aiQuote.hours}h × ${aiQuote.crew}p · ${Math.round(aiQuote.confidence * 100)}% confidence · ${aiQuote.summary}`
                              : `${crew} pro${crew === 1 ? '' : 's'} × ${hours}h · independent market rate for this exact job`}
                          </p>
                          {researched && (
                            <div className="mt-2 border-t border-emerald-400/15 pt-2">
                              {fairMarket?.comparison.honestNote && (
                                <p className="text-[11px] leading-relaxed text-brand-mute">
                                  {fairMarket.comparison.honestNote}
                                </p>
                              )}
                              <p className="mt-1.5 font-mono text-[10px] uppercase tracking-widest text-emerald-300/80">
                                ⚲ Researched {fairMarket?.sources.length} live source
                                {fairMarket?.sources.length === 1 ? '' : 's'}
                              </p>
                              <div className="mt-1 flex flex-wrap gap-x-3 gap-y-0.5">
                                {fairMarket?.sources.map((s, i) => (
                                  <a
                                    key={i}
                                    href={s.url}
                                    target="_blank"
                                    rel="noopener noreferrer nofollow"
                                    className="max-w-[220px] truncate text-[10px] text-brand-accent/80 underline decoration-brand-accent/30 hover:text-brand-accent"
                                  >
                                    {s.title || s.url}
                                  </a>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })()}

                  <div className="rounded-lg border border-brand-line bg-bg-primary/40 px-4 py-3">
                    <button
                      type="button"
                      onClick={() => setShowQuoteChat((v) => !v)}
                      className="flex w-full items-center justify-between gap-3 text-left"
                      aria-expanded={showQuoteChat}
                    >
                      <span className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
                        {showQuoteChat
                          ? '− Hide concierge chat'
                          : '+ Open concierge chat (free-text Q&A)'}
                      </span>
                      <span className="text-[11px] text-brand-mute">
                        {aiTranscript.length} message{aiTranscript.length === 1 ? '' : 's'}
                      </span>
                    </button>
                    {showQuoteChat && (
                      <div className="mt-3 space-y-3">
                        <div
                          ref={aiChatScrollRef}
                          className="scroll-smooth space-y-3 max-h-80 overflow-y-auto rounded-xl border border-brand-line bg-gradient-to-b from-bg-primary/60 to-bg-primary/20 p-3.5"
                          aria-live="polite"
                        >
                          {aiTranscript.length === 0 && !aiLoading && (
                            <p className="text-sm text-brand-mute italic">
                              Concierge is reading your job…
                            </p>
                          )}
                          {aiTranscript.map((m, i) => {
                            // The first user message is the machine-built job summary — show a
                            // tidy "sent" chip instead of the raw prompt block.
                            if (
                              m.role === 'user' &&
                              m.content.startsWith('Job summary from the booking form')
                            ) {
                              return (
                                <div key={i} className="flex justify-end">
                                  <span className="inline-flex items-center gap-1.5 rounded-full border border-brand-accent/30 bg-brand-accent/10 px-3 py-1 font-mono text-[11px] text-brand-accent">
                                    ✓ Sent the crew your job details
                                  </span>
                                </div>
                              );
                            }
                            if (m.role === 'user') {
                              return (
                                <div key={i} className="flex justify-end">
                                  <div className="inline-block max-w-[85%] whitespace-pre-wrap rounded-2xl rounded-tr-md bg-gradient-to-br from-brand-accent to-[#e85d10] px-3.5 py-2 text-sm font-semibold leading-relaxed text-bg-primary shadow-[0_8px_24px_-10px_rgba(255,107,26,0.5)]">
                                    {m.content}
                                  </div>
                                </div>
                              );
                            }
                            return (
                              <div key={i} className="flex items-start gap-2.5">
                                <span
                                  className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-brand-accent/40 bg-gradient-to-br from-brand-accent/25 to-brand-accent/5 font-mono text-[10px] font-bold text-brand-accent shadow-[0_0_12px_-4px_rgba(255,107,26,0.5)]"
                                  aria-hidden
                                >
                                  BL
                                </span>
                                <div className="inline-block max-w-[88%] whitespace-pre-wrap rounded-2xl rounded-tl-md border border-white/10 bg-bg-elevated/70 px-3.5 py-2.5 text-sm leading-relaxed text-brand-ink ring-1 ring-inset ring-brand-accent/[0.06] backdrop-blur-md">
                                  {m.content}
                                </div>
                              </div>
                            );
                          })}
                          {aiLoading && (
                            <div className="flex items-center gap-2 text-sm text-brand-mute">
                              <span className="spinner" /> Concierge is thinking…
                            </div>
                          )}
                          {aiError && (
                            <p role="alert" className="text-sm text-red-400">
                              {aiError}
                            </p>
                          )}
                        </div>
                        <div className="flex gap-2">
                          <input
                            id="bk-ai-input"
                            type="text"
                            value={aiInput}
                            onChange={(e) => setAiInput(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                e.preventDefault();
                                handleAskAi();
                              }
                            }}
                            placeholder="e.g., Will two pickups beat the 15-footer?"
                            maxLength={500}
                            className="input flex-1"
                            disabled={aiLoading}
                          />
                          <button
                            type="button"
                            onClick={handleAskAi}
                            disabled={aiLoading || !aiInput.trim()}
                            aria-busy={aiLoading}
                            className="btn-secondary px-4 disabled:opacity-40 disabled:cursor-not-allowed"
                          >
                            Ask
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  {validationErrors.length > 0 && (
                    <div
                      role="alert"
                      aria-live="polite"
                      className="rounded-xl border border-red-400/40 bg-red-400/[0.06] p-4 bk-error-slide"
                    >
                      <p className="font-mono text-[11px] uppercase tracking-widest text-red-300">
                        Fix{' '}
                        {validationErrors.length === 1
                          ? '1 thing'
                          : `${validationErrors.length} things`}{' '}
                        before you book
                      </p>
                      <p className="mt-1 font-display text-base font-bold text-brand-ink">
                        {summarizeTopErrors(validationErrors)}
                      </p>
                      <ul className="mt-3 space-y-2">
                        {validationErrors.slice(0, 3).map((err) => (
                          <li key={`${err.field}-${err.label}`} className="text-sm text-brand-mute">
                            <button
                              type="button"
                              onClick={() => scrollToField(err.field)}
                              className="text-red-300 underline-hover font-mono mr-2"
                            >
                              {err.label} →
                            </button>
                            {err.message}
                          </li>
                        ))}
                      </ul>
                      {validationErrors.length > 3 && (
                        <p className="mt-2 text-xs text-brand-mute italic">
                          And {validationErrors.length - 3} more — scroll up after fixing these.
                        </p>
                      )}
                    </div>
                  )}

                  {submitError && (
                    <p role="alert" className="text-sm text-red-400">
                      {submitError}
                    </p>
                  )}

                  <div
                    data-bcl-payment-trust={paymentMode}
                    className="rounded-xl border border-emerald-400/25 bg-emerald-400/[0.05] px-4 py-3 bk-trust-in"
                  >
                    <p className="flex items-center gap-2 text-sm font-semibold text-emerald-200">
                      <svg
                        viewBox="0 0 16 16"
                        className="h-4 w-4 shrink-0"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth={2}
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden
                      >
                        <path d="M8 1.5l5 2v4c0 3.2-2.1 5.5-5 7-2.9-1.5-5-3.8-5-7v-4l5-2z" />
                        <path d="M5.5 8l1.8 1.8L10.8 6.2" />
                      </svg>
                      {paymentTrust.security}
                    </p>
                    <p className="mt-1 pl-6 text-sm text-brand-mute">{paymentTrust.charge}</p>
                  </div>

                  {/* Cloudflare Turnstile (P0-2) — TRANSPARENT (interaction-only) on the AI
                      review page: the challenge stays invisible unless Cloudflare needs a
                      genuine interaction. Renders null until VITE_TURNSTILE_SITE_KEY is live. */}
                  <TurnstileWidget
                    onToken={setTurnstileToken}
                    action="booking"
                    appearance="interaction-only"
                    className="mt-1 flex justify-center"
                  />

                  <div className="flex gap-3">
                    <button
                      type="button"
                      onClick={() => setStep('details')}
                      className="btn-secondary flex-1"
                    >
                      ← Edit details
                    </button>
                    <button
                      type="button"
                      onClick={() => setStep('confirm')}
                      className="btn-primary btn-arrow flex-[2]"
                      data-testid="ai-review-to-confirm"
                    >
                      Review &amp; confirm <span data-btn-arrow aria-hidden>→</span>
                    </button>
                  </div>
                </div>
              )}

              {step === 'confirm' && (
                <div key="step-confirm" className="bcl-step-enter">
                  {(() => {
                    const SVC: Record<string, string> = {
                      'power-wash': 'Power washing',
                      lawn: 'Lawn / yard work',
                      haul: 'Hauling / dump runs',
                      repairs: 'Light repairs',
                      cleanout: 'Garage / basement cleanouts',
                      seasonal: 'Seasonal (leaves, snow, gutters)',
                      other: 'Other',
                    };
                    const dueTodayCents =
                      paymentMode === 'deposit'
                        ? depositPlan.depositCents
                        : paymentMode === 'full'
                          ? pricing.subtotalCents
                          : 0;
                    const balanceCents = Math.max(0, pricing.subtotalCents - dueTodayCents);
                    const recPlan = RECURRING_PLANS.find((p) => p.id === recurringPlan);
                    const recDiscount = discountForPlan(recurringPlan);
                    const isRecurring = recurringPlan !== 'one-time' && recDiscount > 0;
                    const answeredQ = reviewQuestions.filter(
                      (q) =>
                        (reviewAnswers[q.id]?.length ?? 0) > 0 ||
                        (reviewText[q.id]?.trim().length ?? 0) > 0,
                    );
                    const addr = [address, city, zip].filter(Boolean).join(', ');
                    // Linkable summary fields — everything the customer entered
                    // becomes a real, on-brand, keyboard-focusable link so the
                    // Confirm review is tap-to-act (call, email, open map, read
                    // a service/policy page) rather than dead text.
                    const telDigits = phone.replace(/[^\d+]/g, '');
                    const telUrl = telDigits ? `tel:${telDigits}` : '';
                    const mailUrl = email.trim() ? `mailto:${email.trim()}` : '';
                    const mapsUrl = addr
                      ? `https://maps.google.com/maps?q=${encodeURIComponent(addr)}`
                      : '';
                    // Booking service keys → /services/<catalog-slug> hub pages.
                    const SVC_SLUG: Record<string, string> = {
                      'power-wash': 'power-washing',
                      lawn: 'lawn-care',
                      haul: 'hauling',
                      repairs: 'light-repairs',
                      cleanout: 'apartment-cleanout',
                    };
                    // Shared link primitive — brand-accent, underline-on-hover,
                    // visible focus ring, 24px+ tap target via inline-flex.
                    const linkCls =
                      'inline-flex min-h-[24px] items-center gap-1 rounded font-semibold text-brand-accent underline decoration-brand-accent/40 decoration-1 underline-offset-2 transition-colors hover:decoration-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent';
                    const dateLabel = (() => {
                      const d = date ? new Date(`${date}T12:00:00`) : null;
                      return d && !Number.isNaN(d.getTime())
                        ? d.toLocaleDateString('en-US', {
                            weekday: 'short',
                            month: 'short',
                            day: 'numeric',
                          })
                        : '';
                    })();
                    // Client-side calendar event from live form state — Confirm is
                    // pre-payment (no booking id yet), so we hand the customer a
                    // downloadable .ics they can add now. Reuses the shared RFC 5545
                    // builder (mirrors the worker's ics.ts shape).
                    const icsInput = {
                      date,
                      startAt: selectedSlot?.startAt,
                      localTime: selectedSlot?.localTime,
                      hours,
                      services: services.map((s) => SVC[s] ?? s),
                      crew,
                      address: addr,
                      notes: notesSummary || notesFloor || notes.trim(),
                      cadence: isRecurring && recPlan ? recPlan.label : undefined,
                    };
                    // Two robust "add to calendar" paths, both real hrefs (provable
                    // in the DOM, reliable on mobile — no programmatic Blob click):
                    // the date tile is an <a download> for the .ics; a sibling link
                    // opens the Google Calendar event template.
                    const icsDataUrl = bookingIcsDataUri(icsInput);
                    const icsFilename = bookingIcsFilename(icsInput);
                    const gcalUrl = bookingGoogleCalUrl(icsInput);
                    const onAddToCal = (via: 'ics' | 'google') =>
                      track(FUNNEL.quoteSaved, { hours, crew, ics: 1, via });
                    // Small on-brand section icons for the summary eyebrows.
                    const secIcon = (d: string) => (
                      <svg
                        viewBox="0 0 24 24"
                        className="h-3.5 w-3.5 shrink-0"
                        fill="currentColor"
                        aria-hidden
                      >
                        <path d={d} />
                      </svg>
                    );
                    const IC_CAL =
                      'M7 2v2H5a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-2V2h-2v2H9V2H7zM5 8h14v11H5V8z';
                    const IC_USER =
                      'M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10zm0 2c-4.4 0-8 2.7-8 6v2h16v-2c0-3.3-3.6-6-8-6z';
                    const IC_BOX =
                      'M12 2 3 7v10l9 5 9-5V7l-9-5zm0 2.3L18.5 8 12 11.7 5.5 8 12 4.3zM5 9.9l6 3.4v6.4l-6-3.3V9.9zm14 0v6.5l-6 3.3v-6.4l6-3.4z';
                    const IC_SPARK = 'M12 2l1.8 4.8L18 8l-4.2 1.2L12 14l-1.8-4.8L6 8l4.2-1.2L12 2z';
                    const IC_CASH =
                      'M3 6h18a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1zm2 2v8h14V8H5zm7 1.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5z';
                    // Anticipated upcoming visits for a recurring cadence (client-side date math).
                    const upcomingDates: string[] = (() => {
                      if (!isRecurring || !date) return [];
                      const start = new Date(`${date}T12:00:00`);
                      if (Number.isNaN(start.getTime())) return [];
                      const out: string[] = [];
                      const stepDays =
                        recurringPlan === 'daily'
                          ? 1
                          : recurringPlan === 'weekly'
                            ? 7
                            : recurringPlan === 'biweekly'
                              ? 14
                              : 0;
                      for (let i = 1; i <= 4; i++) {
                        const d = new Date(start);
                        if (recurringPlan === 'monthly') d.setMonth(d.getMonth() + i);
                        else d.setDate(d.getDate() + stepDays * i);
                        out.push(d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
                      }
                      return out;
                    })();
                    // Proactive validation — what's still missing before the customer can pay,
                    // each mapped to the step to jump back to.
                    // De-dupe by field so two errors pointing at the SAME input
                    // (e.g. missing Address + missing City both target bk-address)
                    // collapse to one row with one "Fix →" link.
                    const missing = validateForm().filter(
                      (e, i, arr) => arr.findIndex((x) => x.field === e.field) === i,
                    );
                    const stepForField = (f: string): Step =>
                      f === 'bk-date-label' || f === 'rental-risk-disclosure'
                        ? 'schedule'
                        : f === 'bk-acknowledge'
                          ? 'ai-review'
                          : 'details';
                    // Sections of the ONE executive summary — borderless, compact padded
                    // rows separated by hairline dividers (not four standalone boxes).
                    // Each summary section is now a self-contained panel (subtle
                    // border + inset surface) so the two-column grid reads as
                    // balanced cards instead of hairline-divided full-width rows.
                    const panelCls =
                      'flex flex-col rounded-xl border border-brand-line/70 bg-bg-primary/30 p-4';
                    const eyebrowCls =
                      'font-mono text-[11px] uppercase tracking-widest text-brand-accent';
                    const editBtnCls =
                      'text-[11px] font-medium text-brand-mute underline-offset-2 hover:text-brand-accent hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent rounded';
                    return (
                      <div className="space-y-5" data-testid="booking-step-confirm">
                        {/* ONE cohesive executive summary — the whole form's status in a
                            single gorgeous card: an executive headline band (job + total) then
                            hairline-divided sections (schedule · your info · scope · AI info ·
                            the money), each with an inline Edit jump-link. Replaces the old
                            four-box grid so the Confirm step reads as one considered document. */}
                        <div className="overflow-hidden rounded-2xl border border-brand-line bg-bg-elevated/60 shadow-[0_18px_48px_-30px_rgba(0,0,0,0.75)]">
                          <div className="relative overflow-hidden border-b border-brand-line/60 bg-gradient-to-br from-brand-accent/[0.12] via-brand-accent/[0.04] to-transparent p-5">
                            <div
                              className="pointer-events-none absolute inset-x-0 top-0 h-0.5 bg-gradient-to-r from-transparent via-brand-accent to-transparent"
                              aria-hidden
                            />
                            <div
                              className="pointer-events-none absolute -right-12 -top-12 h-40 w-40 rounded-full bg-brand-accent/10 blur-3xl"
                              aria-hidden
                            />
                            <p className={eyebrowCls}>Step 4 · Confirm your quote</p>
                            <div className="mt-2 flex flex-wrap items-end justify-between gap-x-6 gap-y-2">
                              <div className="min-w-0">
                                <div className="flex flex-wrap items-center gap-2">
                                  <h3 className="font-display text-2xl font-bold leading-tight text-brand-ink">
                                    {services.length
                                      ? services.map((s) => SVC[s] ?? s).join(' + ')
                                      : 'Your Brick Labor job'}
                                  </h3>
                                  {missing.length === 0 ? (
                                    <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-emerald-400/40 bg-emerald-400/10 px-2 py-0.5 text-[11px] font-semibold text-emerald-200">
                                      ✓ Ready to book
                                    </span>
                                  ) : (
                                    <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-amber-400/40 bg-amber-400/10 px-2 py-0.5 text-[11px] font-semibold text-amber-100">
                                      {missing.length} to finish
                                    </span>
                                  )}
                                </div>
                                <p className="mt-1 text-sm text-brand-mute">
                                  {crew} {crew === 1 ? 'pro' : 'pros'} × {hours}h
                                  {dateLabel ? ` · ${dateLabel}` : ''}
                                  {selectedSlot?.localTime ? ` at ${selectedSlot.localTime}` : ''}
                                  {isRecurring && recPlan ? ` · ${recPlan.label.toLowerCase()}` : ''}
                                </p>
                              </div>
                              <div className="shrink-0 text-right">
                                <p className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
                                  {isRecurring ? 'Per visit' : 'Estimated total'}
                                </p>
                                <p className="font-display text-3xl font-extrabold leading-none text-brand-ink">
                                  ${fmtMoney(pricing.subtotalCents)}
                                </p>
                                {isRecurring && recPlan ? (
                                  <p className="mt-0.5 font-mono text-[10px] font-semibold uppercase tracking-widest text-brand-accent">
                                    {recPlan.label} · {recDiscount}% off
                                  </p>
                                ) : null}
                              </div>
                            </div>
                            {/* Saved-quote money-truth disclosure: when a REOPENED
                                /quote/:id recomputes (surge/same-day) to a different
                                price than it was quoted, DISCLOSE it here rather than
                                silently charge more. Inert for normal bookings
                                (gated on fromQuote && changed). */}
                            {(() => {
                              const chg = quotePriceChange(
                                quotePrefill.current.quotedTotalCents,
                                chargeCents,
                              );
                              if (!quotePrefill.current.fromQuote || !chg?.changed) return null;
                              return (
                                <div
                                  role="status"
                                  data-testid="quote-price-change-notice"
                                  className="mt-3 rounded-lg border border-brand-accent/40 bg-brand-accent/[0.08] px-3 py-2 text-xs text-brand-accent"
                                >
                                  Heads up — the price changed since your saved quote:{' '}
                                  <span className="text-brand-mute line-through">
                                    ${fmtMoney(chg.quotedCents)}
                                  </span>{' '}
                                  → <strong>${fmtMoney(chg.currentCents)}</strong>
                                  {chg.higher
                                    ? ' — same-day/surge pricing now applies. Book an earlier date to lock a lower rate.'
                                    : ' — you’re paying less than quoted.'}
                                </div>
                              );
                            })()}
                          </div>

                          {/* Two-column executive summary — a balanced grid that
                              fills the width on desktop (Schedule ↔ Your info,
                              Scope ↔ AI Info) and collapses to one column on
                              mobile. Every field the customer entered is a real,
                              on-brand, keyboard-focusable link. */}
                          <div className="space-y-3 p-4 sm:p-5">
                            <div className="grid items-start gap-3 sm:grid-cols-2">
                            {/* Left column: Schedule, then Job instructions
                                immediately below it (A1). */}
                            <div className="space-y-3">
                            {/* Schedule */}
                            <div className={panelCls}>
                              <div className="flex items-center justify-between">
                                <p className={`${eyebrowCls} inline-flex items-center gap-1.5`}>
                                  {secIcon(IC_CAL)}Schedule
                                </p>
                                <button
                                  type="button"
                                  className={editBtnCls}
                                  onClick={() => setStep('schedule')}
                                >
                                  Edit
                                </button>
                              </div>
                              {/* Gorgeous calendar date-tile — a real button that
                                  downloads a .ics for THIS booking. Month cap + big
                                  day + weekday, on brand; hover/active lift + orange
                                  focus ring; keyboard-operable + reduced-motion safe. */}
                              {(() => {
                                const d = date ? new Date(`${date}T12:00:00`) : null;
                                const ok = d !== null && !Number.isNaN(d.getTime());
                                const mon = ok
                                  ? d.toLocaleDateString('en-US', { month: 'short' }).toUpperCase()
                                  : '—';
                                const day = ok ? d.getDate() : '?';
                                const wd = ok
                                  ? d.toLocaleDateString('en-US', { weekday: 'long' })
                                  : 'Date to be decided';
                                const tileCls =
                                  'group mt-2 flex w-full items-center gap-3 rounded-xl border border-brand-line bg-bg-primary/40 p-2.5 text-left transition-all duration-200 hover:-translate-y-0.5 hover:border-brand-accent/60 hover:bg-brand-accent/[0.06] hover:shadow-[0_10px_24px_-12px_rgba(255,107,26,0.55)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent focus-visible:ring-offset-2 focus-visible:ring-offset-bg-primary active:translate-y-0 active:scale-[0.99] motion-reduce:transition-none motion-reduce:hover:translate-y-0 motion-reduce:active:scale-100';
                                const tileInner = (
                                  <>
                                    <div className="flex h-14 w-14 shrink-0 flex-col items-center justify-center overflow-hidden rounded-lg border border-brand-accent/40 bg-bg-elevated shadow-[0_6px_16px_-8px_rgba(255,107,26,0.5)] transition-transform duration-200 group-hover:scale-105 motion-reduce:transition-none motion-reduce:group-hover:scale-100">
                                      <span className="w-full bg-brand-accent py-0.5 text-center font-mono text-[9px] font-bold uppercase tracking-widest text-bg-primary">
                                        {mon}
                                      </span>
                                      <span className="mt-1 font-display text-xl font-extrabold leading-none text-brand-ink">
                                        {day}
                                      </span>
                                    </div>
                                    <div className="min-w-0 flex-1">
                                      <p className="text-sm font-semibold text-brand-ink">{wd}</p>
                                      <p className="text-xs text-brand-mute">
                                        {selectedSlot?.localTime
                                          ? `Arrives ${selectedSlot.localTime}`
                                          : 'Flexible arrival window'}
                                        {isRecurring && recPlan ? ` · ${recPlan.label} cadence` : ''}
                                      </p>
                                    </div>
                                    <svg
                                      viewBox="0 0 24 24"
                                      className="h-4 w-4 shrink-0 text-brand-mute transition-colors duration-200 group-hover:text-brand-accent motion-reduce:transition-none"
                                      fill="none"
                                      stroke="currentColor"
                                      strokeWidth={2.2}
                                      strokeLinecap="round"
                                      strokeLinejoin="round"
                                      aria-hidden
                                    >
                                      <path d="M12 3v12m0 0l-4-4m4 4l4-4M5 21h14" />
                                    </svg>
                                  </>
                                );
                                return (
                                  <>
                                    {ok && icsDataUrl ? (
                                      <a
                                        href={icsDataUrl}
                                        download={icsFilename}
                                        onClick={() => onAddToCal('ics')}
                                        data-testid="confirm-add-to-calendar"
                                        aria-label={`Download a calendar file (.ics) for ${bookingIcsTitle(icsInput)} on ${dateLabel || wd}`}
                                        className={tileCls}
                                      >
                                        {tileInner}
                                      </a>
                                    ) : (
                                      <div
                                        data-testid="confirm-add-to-calendar-disabled"
                                        aria-hidden
                                        className={`${tileCls} cursor-not-allowed opacity-60 hover:translate-y-0 hover:border-brand-line hover:bg-bg-primary/40 hover:shadow-none`}
                                      >
                                        {tileInner}
                                      </div>
                                    )}
                                    {ok && (
                                      <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 pl-1">
                                        <span className="inline-flex items-center gap-1.5 text-[11px] font-medium text-brand-mute">
                                          <svg
                                            viewBox="0 0 24 24"
                                            className="h-3 w-3 shrink-0 text-brand-accent"
                                            fill="none"
                                            stroke="currentColor"
                                            strokeWidth={2.2}
                                            strokeLinecap="round"
                                            strokeLinejoin="round"
                                            aria-hidden
                                          >
                                            <rect x="3" y="4" width="18" height="17" rx="2" />
                                            <path d="M8 2v4M16 2v4M3 10h18M12 14v4M10 16h4" />
                                          </svg>
                                          Tap the date to download a .ics
                                        </span>
                                        {gcalUrl && (
                                          <a
                                            href={gcalUrl}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            onClick={() => onAddToCal('google')}
                                            data-testid="confirm-add-to-google-cal"
                                            aria-label="Add this job to Google Calendar (opens in a new tab)"
                                            className="inline-flex items-center gap-1 rounded text-[11px] font-semibold text-brand-accent underline decoration-brand-accent/40 decoration-1 underline-offset-2 transition-colors hover:decoration-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
                                          >
                                            <svg
                                              viewBox="0 0 24 24"
                                              className="h-3 w-3 shrink-0"
                                              fill="currentColor"
                                              aria-hidden
                                            >
                                              <path d="M7 2v2H5a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-2V2h-2v2H9V2H7zM5 8h14v11H5V8z" />
                                            </svg>
                                            Add to Google Calendar
                                          </a>
                                        )}
                                      </div>
                                    )}
                                  </>
                                );
                              })()}
                              {services.length > 0 && (
                                <div className="mt-2 flex flex-wrap gap-1.5">
                                  {services.map((s) =>
                                    SVC_SLUG[s] ? (
                                      <a
                                        key={s}
                                        href={lpHref(`/services/${SVC_SLUG[s]}`)}
                                        aria-label={`View ${SVC[s] ?? s} service details`}
                                        className="inline-flex min-h-[24px] items-center rounded-full border border-brand-accent/30 bg-brand-accent/15 px-2.5 py-0.5 text-xs font-medium text-brand-accent transition-all duration-150 hover:-translate-y-px hover:border-brand-accent hover:bg-brand-accent/25 hover:shadow-[0_4px_12px_-6px_rgba(255,107,26,0.6)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent motion-reduce:transition-none motion-reduce:hover:translate-y-0"
                                      >
                                        {SVC[s] ?? s}
                                      </a>
                                    ) : (
                                      <span
                                        key={s}
                                        className="rounded-full border border-brand-accent/30 bg-brand-accent/15 px-2 py-0.5 text-xs font-medium text-brand-accent"
                                      >
                                        {SVC[s] ?? s}
                                      </span>
                                    ),
                                  )}
                                </div>
                              )}
                            </div>

                            {/* Job instructions — moved to sit immediately below the
                                Schedule container (A1). AI-summarized, LEFT-aligned. */}
                            {notes.trim() && (
                              <section className={panelCls} aria-label="AI-summarized job instructions">
                                <div className="flex items-start justify-between gap-2">
                                  <p
                                    className={`${eyebrowCls} inline-flex flex-wrap items-center gap-x-2 gap-y-1`}
                                  >
                                    <span className="inline-flex items-center gap-1.5">
                                      {secIcon(IC_SPARK)}Job instructions
                                    </span>
                                    <span className="rounded-full border border-brand-accent/30 bg-brand-accent/10 px-1.5 py-px text-[9px] font-semibold tracking-wide text-brand-accent">
                                      AI summary
                                    </span>
                                  </p>
                                  <button
                                    type="button"
                                    className={`${editBtnCls} shrink-0`}
                                    onClick={() => setStep('details')}
                                  >
                                    Edit
                                  </button>
                                </div>
                                {/* Left-accent rail + left-aligned condensed text —
                                    reads as a quoted, dispatcher-ready brief. */}
                                <p className="mt-2 border-l-2 border-brand-accent/50 pl-3 text-left text-sm leading-relaxed text-brand-ink">
                                  {notesSummary || notesFloor || notes.trim()}
                                </p>
                              </section>
                            )}
                            </div>

                            {/* Contact — every value is a live link where possible */}
                            <div className={panelCls}>
                              <div className="flex items-center justify-between">
                                <p className={`${eyebrowCls} inline-flex items-center gap-1.5`}>
                                  {secIcon(IC_USER)}Your info
                                </p>
                                <button
                                  type="button"
                                  className={editBtnCls}
                                  onClick={() => setStep('details')}
                                >
                                  Edit
                                </button>
                              </div>
                              <dl className="mt-2 space-y-1.5 text-sm">
                                <div className="flex items-baseline justify-between gap-3">
                                  <dt className="text-brand-mute">Name</dt>
                                  <dd className="text-right font-semibold text-brand-ink">
                                    {name || '—'}
                                  </dd>
                                </div>
                                <div className="flex items-baseline justify-between gap-3">
                                  <dt className="text-brand-mute">Email</dt>
                                  <dd className="min-w-0 text-right">
                                    {mailUrl ? (
                                      <a
                                        href={mailUrl}
                                        aria-label={`Email ${email}`}
                                        className={`${linkCls} max-w-full justify-end break-all`}
                                      >
                                        {email}
                                      </a>
                                    ) : (
                                      <span className="font-semibold text-brand-ink">—</span>
                                    )}
                                  </dd>
                                </div>
                                <div className="flex items-baseline justify-between gap-3">
                                  <dt className="text-brand-mute">Phone</dt>
                                  <dd className="text-right">
                                    {telUrl ? (
                                      <a
                                        href={telUrl}
                                        aria-label={`Call ${phone}`}
                                        className={`${linkCls} justify-end`}
                                      >
                                        {phone}
                                      </a>
                                    ) : (
                                      <span className="font-semibold text-brand-ink">—</span>
                                    )}
                                  </dd>
                                </div>
                                {businessName && (
                                  <div className="flex items-baseline justify-between gap-3">
                                    <dt className="text-brand-mute">Business</dt>
                                    <dd className="text-right font-semibold text-brand-ink">
                                      {businessName}
                                    </dd>
                                  </div>
                                )}
                                {addr && (
                                  <div className="flex items-baseline justify-between gap-3">
                                    <dt className="shrink-0 text-brand-mute">Address</dt>
                                    <dd className="min-w-0 text-right">
                                      <a
                                        href={mapsUrl}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        aria-label={`Open ${addr} in Google Maps (opens in a new tab)`}
                                        className={`${linkCls} max-w-full justify-end text-right`}
                                      >
                                        <span className="min-w-0">{addr}</span>
                                        <svg
                                          viewBox="0 0 24 24"
                                          className="h-3 w-3 shrink-0"
                                          fill="none"
                                          stroke="currentColor"
                                          strokeWidth={2.2}
                                          strokeLinecap="round"
                                          strokeLinejoin="round"
                                          aria-hidden
                                        >
                                          <path d="M14 4h6v6M20 4l-8 8M10 5H5a1 1 0 0 0-1 1v13a1 1 0 0 0 1 1h13a1 1 0 0 0 1-1v-5" />
                                        </svg>
                                      </a>
                                    </dd>
                                  </div>
                                )}
                              </dl>
                              {addr && (
                                <AddressMap address={addr} className="mt-3" heightClass="h-40" />
                              )}
                            </div>
                            </div>

                            <div className="grid items-start gap-3 sm:grid-cols-2">
                            {/* Scope — spans full width when there's no AI Info panel beside it */}
                            <div
                              className={`${panelCls} ${
                                answeredQ.length > 0 || fairMarket?.researched
                                  ? ''
                                  : 'sm:col-span-2'
                              }`}
                            >
                              <div className="flex items-center justify-between">
                                <p className={`${eyebrowCls} inline-flex items-center gap-1.5`}>
                                  {secIcon(IC_BOX)}Scope
                                </p>
                                <button
                                  type="button"
                                  className={editBtnCls}
                                  onClick={() => setStep('schedule')}
                                >
                                  Edit
                                </button>
                              </div>
                              <div className="mt-2 grid grid-cols-2 gap-2">
                                <div className="rounded-lg border border-brand-line/60 bg-bg-primary/40 p-2.5 text-center">
                                  <p className="font-mono text-[9px] uppercase tracking-widest text-brand-mute">
                                    Crew
                                  </p>
                                  <p className="mt-0.5 font-display text-base font-extrabold leading-none text-brand-ink">
                                    {crew} {crew === 1 ? 'pro' : 'pros'}
                                  </p>
                                </div>
                                <div className="rounded-lg border border-brand-line/60 bg-bg-primary/40 p-2.5 text-center">
                                  <p className="font-mono text-[9px] uppercase tracking-widest text-brand-mute">
                                    Hours
                                  </p>
                                  <p className="mt-0.5 font-display text-base font-extrabold leading-none text-brand-ink">
                                    {hours}h
                                  </p>
                                </div>
                              </div>
                              <dl className="mt-2 space-y-1.5 text-sm">
                                {truckPicks.length > 0 && (
                                  <div className="flex items-start justify-between gap-3">
                                    <dt className="shrink-0 text-brand-mute">U-Haul</dt>
                                    <dd className="text-right font-semibold text-brand-ink">
                                      {truckPicks
                                        .map((p) => `${p.qty}× ${rentalById(p.id)?.label || p.id}`)
                                        .join(', ')}
                                    </dd>
                                  </div>
                                )}
                                {isRecurring && (
                                  <div className="flex justify-between gap-3">
                                    <dt className="text-brand-mute">Recurring</dt>
                                    <dd className="text-right font-semibold text-brand-accent">
                                      {recPlan?.label} · {recDiscount}% off
                                    </dd>
                                  </div>
                                )}
                                {extras.length > 0 && (
                                  <div className="flex items-start justify-between gap-3">
                                    <dt className="shrink-0 text-brand-mute">Add-ons</dt>
                                    <dd className="flex flex-wrap justify-end gap-1.5">
                                      {extras.map((x) => (
                                        <span
                                          key={x}
                                          className="rounded-full border border-brand-line px-2 py-0.5 text-xs text-brand-ink"
                                        >
                                          {x.replace(/-/g, ' ')}
                                        </span>
                                      ))}
                                    </dd>
                                  </div>
                                )}
                                <div className="flex items-baseline justify-between gap-3 border-t border-brand-line/30 pt-1.5">
                                  <dt className="text-brand-mute">Service area</dt>
                                  <dd className="text-right">
                                    <a
                                      href={lpHref('/c/newark')}
                                      aria-label="View Brick Labor Newark service area"
                                      className={`${linkCls} justify-end`}
                                    >
                                      Newark, NJ
                                    </a>
                                  </dd>
                                </div>
                              </dl>
                            </div>

                            {/* AI Info — only when the customer answered clarifiers or a
                                researched fair-market band exists (hidden on a bare share link). */}
                            {answeredQ.length > 0 || fairMarket?.researched ? (
                              <div className={panelCls}>
                                <div className="flex items-center justify-between">
                                  <p className={`${eyebrowCls} inline-flex items-center gap-1.5`}>
                                    {secIcon(IC_SPARK)}AI Info
                                  </p>
                                  <button
                                    type="button"
                                    className={editBtnCls}
                                    onClick={() => setStep('ai-review')}
                                  >
                                    Edit
                                  </button>
                                </div>
                                <dl className="mt-2 space-y-1.5 text-sm">
                                  {answeredQ.map((q) => {
                                    const picked = reviewAnswers[q.id] ?? [];
                                    const txt = (reviewText[q.id] ?? '').trim();
                                    const val = picked.length ? picked.join(', ') : txt;
                                    return (
                                      <div
                                        key={q.id}
                                        className="flex items-start justify-between gap-3"
                                      >
                                        <dt className="shrink-0 text-brand-mute">{q.question}</dt>
                                        <dd className="text-right font-semibold text-brand-ink">
                                          {val}
                                        </dd>
                                      </div>
                                    );
                                  })}
                                  {fairMarket?.researched && (
                                    <div className="flex items-center justify-between gap-3 border-t border-brand-line/40 pt-1.5">
                                      <dt className="text-brand-mute">Fair-market rate</dt>
                                      <dd className="text-right font-semibold text-brand-ink">
                                        {fairMarketRange(
                                          fairMarket.comparison.marketLowCents,
                                          fairMarket.comparison.marketHighCents,
                                        )}
                                      </dd>
                                    </div>
                                  )}
                                </dl>
                              </div>
                            ) : null}
                            </div>
                            {/* The money — the final section of the one summary */}
                            <div
                              className="bg-brand-accent/[0.05] p-5"
                              data-testid="confirm-price-summary"
                            >
                              <p className={`${eyebrowCls} inline-flex items-center gap-1.5`}>
                                {secIcon(IC_CASH)}The money
                              </p>
                              {/* Money at a glance — three stat tiles, due-today highlighted */}
                              <div className="mt-2 grid grid-cols-3 gap-2">
                                <div className="rounded-lg border border-brand-line/60 bg-bg-primary/40 p-2.5 text-center">
                                  <p className="font-mono text-[9px] uppercase tracking-widest text-brand-mute">
                                    Total
                                  </p>
                                  <p className="mt-0.5 font-display text-lg font-extrabold leading-none text-brand-ink">
                                    ${fmtMoney(pricing.subtotalCents)}
                                  </p>
                                </div>
                                <div className="rounded-lg border border-brand-accent/50 bg-brand-accent/[0.12] p-2.5 text-center shadow-[0_6px_16px_-8px_rgba(255,107,26,0.5)]">
                                  <p className="font-mono text-[9px] uppercase tracking-widest text-brand-accent">
                                    Due today
                                  </p>
                                  <p className="mt-0.5 font-display text-lg font-extrabold leading-none text-brand-ink">
                                    ${fmtMoney(dueTodayCents)}
                                  </p>
                                </div>
                                <div className="rounded-lg border border-brand-line/60 bg-bg-primary/40 p-2.5 text-center">
                                  <p className="font-mono text-[9px] uppercase tracking-widest text-brand-mute">
                                    Balance
                                  </p>
                                  <p className="mt-0.5 font-display text-lg font-extrabold leading-none text-brand-ink">
                                    ${fmtMoney(balanceCents)}
                                  </p>
                                </div>
                              </div>
                              <dl className="mt-2.5 space-y-1.5 text-sm">
                                <div className="flex items-start justify-between gap-3">
                                  <dt className="text-brand-mute">Payment</dt>
                                  <dd className="text-right font-semibold text-brand-ink">
                                    {paymentMode === 'deposit'
                                      ? 'Refundable deposit now · balance billed as the crew works'
                                      : paymentMode === 'full'
                                        ? 'Paid in full today'
                                        : '$0 today · card on file'}
                                    {pricing.surgeMultiplier > 1
                                      ? ` · incl. ${Math.round((pricing.surgeMultiplier - 1) * 100)}% demand`
                                      : ''}
                                  </dd>
                                </div>
                                {isRecurring && (
                                  <div className="flex justify-between gap-3">
                                    <dt className="text-brand-mute">Going forward</dt>
                                    <dd className="text-right font-semibold text-brand-accent">
                                      {recPlan?.label} rate · {recDiscount}% standing discount
                                    </dd>
                                  </div>
                                )}
                                <div className="flex items-start justify-between gap-3 border-t border-brand-line/30 pt-1.5">
                                  <dt className="shrink-0 text-brand-mute">Cadence</dt>
                                  <dd className="text-right font-semibold text-brand-ink">
                                    {isRecurring
                                      ? `${recPlan?.label} · $${fmtMoney(pricing.subtotalCents)} per visit`
                                      : `One-time job · $${fmtMoney(pricing.subtotalCents)} total`}
                                  </dd>
                                </div>
                                {upcomingDates.length > 0 && (
                                  <div className="flex flex-col gap-1.5 border-t border-brand-line/30 pt-2">
                                    <dt className="text-brand-mute">Upcoming visits</dt>
                                    <dd className="flex flex-wrap gap-1.5">
                                      {[dateLabel || date, ...upcomingDates].map((d, i) => (
                                        <span
                                          key={`${d}:${i}`}
                                          className={`rounded-md border px-2 py-0.5 text-[11px] font-semibold ${
                                            i === 0
                                              ? 'border-brand-accent/50 bg-brand-accent/15 text-brand-accent'
                                              : 'border-brand-line text-brand-ink'
                                          }`}
                                        >
                                          {d}
                                        </span>
                                      ))}
                                      <span className="self-center text-[11px] text-brand-mute">
                                        …ongoing
                                      </span>
                                    </dd>
                                  </div>
                                )}
                              </dl>
                              <p className="mt-3 text-xs leading-relaxed text-brand-mute">
                                Prices are estimates for the hours shown. You are billed for actual
                                crew time at $50/hr per person, 1-hour minimum, then 15-minute
                                blocks. The crew texts you before exceeding the booked hours — you
                                always approve overages first.
                              </p>
                            </div>
                          </div>
                        </div>

                        {/* Proactive validation — every missing required field, printed
                            ahead of time, each with a button that jumps straight back to the
                            step + field that needs it. Also the messaging when Pay is clicked. */}
                        {missing.length > 0 && (
                          <div
                            className="rounded-xl border border-amber-400/40 bg-amber-400/[0.06] p-4"
                            data-testid="confirm-validation"
                          >
                            <p className="flex items-center gap-2 text-sm font-semibold text-amber-100">
                              <span aria-hidden>⚠</span>
                              {missing.length} thing{missing.length === 1 ? '' : 's'} to finish before
                              you can pay
                            </p>
                            <ul className="mt-2.5 space-y-2">
                              {missing.map((e) => (
                                <li
                                  key={`${e.field}:${e.label}`}
                                  className="flex flex-wrap items-start justify-between gap-2 rounded-lg bg-bg-primary/40 px-3 py-2"
                                >
                                  <span className="min-w-0 flex-1 text-sm text-amber-100/90">
                                    <span className="font-semibold text-amber-100">{e.label}:</span>{' '}
                                    {e.message}
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setStep(stepForField(e.field));
                                      window.setTimeout(() => scrollToField(e.field), 90);
                                    }}
                                    className="shrink-0 rounded-md border border-amber-400/50 px-3 py-1 text-xs font-bold text-amber-100 transition-colors hover:bg-amber-400/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400"
                                  >
                                    Fix {e.label} →
                                  </button>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}

                        {submitError && (
                          <p role="alert" className="text-sm text-red-400">
                            {submitError}
                          </p>
                        )}

                        <div
                          data-bcl-payment-trust={paymentMode}
                          className="rounded-xl border border-emerald-400/25 bg-emerald-400/[0.05] px-4 py-3"
                        >
                          <p className="flex items-center gap-2 text-sm font-semibold text-emerald-200">
                            <svg
                              viewBox="0 0 16 16"
                              className="h-4 w-4 shrink-0"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth={2}
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              aria-hidden
                            >
                              <path d="M8 1.5l5 2v4c0 3.2-2.1 5.5-5 7-2.9-1.5-5-3.8-5-7v-4l5-2z" />
                              <path d="M5.5 8l1.8 1.8L10.8 6.2" />
                            </svg>
                            {paymentTrust.security}
                          </p>
                          <p className="mt-1 pl-6 text-sm text-brand-mute">{paymentTrust.charge}</p>
                        </div>

                        <TurnstileWidget
                          onToken={setTurnstileToken}
                          action="booking"
                          appearance="interaction-only"
                          className="mt-1 flex justify-center"
                        />

                        <div className="flex gap-3">
                          <button
                            type="button"
                            onClick={() => setStep('ai-review')}
                            className="btn-secondary flex-1"
                          >
                            ← Back to AI Info
                          </button>
                          <button
                            type="submit"
                            disabled={submitting}
                            aria-busy={submitting}
                            data-testid="confirm-pay"
                            className="btn-primary flex-[2] disabled:cursor-not-allowed disabled:opacity-40"
                          >
                            {submitting ? (
                              <>
                                <span className="spinner mr-2" /> Booking…
                              </>
                            ) : (
                              confirmCtaLabel({
                                // multi-day submit ignores paymentMode (always $0 today, no Square) —
                                // keep the label honest via the shared SSOT (src/shared/pay-cta.ts).
                                multiDay: multiDayMode && multiDates.length >= 1,
                                mode: paymentMode,
                                depositCents: depositPlan.depositCents,
                                subtotalCents: pricing.subtotalCents,
                                fmt: fmtMoney,
                              })
                            )}
                          </button>
                        </div>

                        {/* Save & share the full quote — the link reopens /book on THIS
                            Confirm step with every field pre-filled for whoever opens it. */}
                        <div className="rounded-xl border border-brand-line bg-bg-primary/40 p-4">
                          {/* Desktop: text left, button floats right on the same row.
                              Wrapped (mobile/narrow): button drops below, stays LEFT.
                              Button is min-width-locked to the longest label so it
                              never resizes across Saving… / Link copied ✓ (A3). */}
                          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                            <div className="min-w-0">
                              <p className="text-sm font-semibold text-brand-ink">
                                Not ready to pay?
                              </p>
                              <p className="text-xs text-brand-mute">
                                Save this quote + share a link that reopens the whole form, filled
                                out, right here on Confirm.
                              </p>
                            </div>
                            <button
                              type="button"
                              onClick={handleSaveQuote}
                              disabled={quoteSaving}
                              aria-busy={quoteSaving}
                              data-testid="confirm-save-share"
                              className="btn-secondary shrink-0 self-start disabled:opacity-40 sm:ml-auto sm:self-auto"
                            >
                              <span className="inline-block min-w-[22ch] text-center">
                                {quoteSaving
                                  ? 'Saving…'
                                  : quoteCopied
                                    ? 'Link copied ✓'
                                    : 'Save & share this quote'}
                              </span>
                            </button>
                          </div>
                          {quoteUrl && (
                            <p className="mt-3 break-all rounded-lg border border-brand-accent/30 bg-brand-accent/[0.06] px-3 py-2 text-xs text-brand-accent">
                              {quoteUrl}
                            </p>
                          )}
                          {quoteError && (
                            <p role="alert" className="mt-2 text-xs text-red-400 bcl-field-error">{quoteError}</p>
                          )}
                          {/* WCAG 4.1.3 — the save/copy SUCCESS was announced to nobody (only
                              quoteError had role=alert). Announce the saved + copied state to SR,
                              claiming "copied" only when the clipboard write actually succeeded. */}
                          <span className="sr-only" role="status" aria-live="polite">
                            {quoteCopied
                              ? 'Quote saved — share link copied to clipboard.'
                              : quoteUrl
                                ? 'Quote saved. Copy your share link below.'
                                : ''}
                          </span>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              )}
            </form>
          </div>
        )}
      </div>
    </section>
  );
}
