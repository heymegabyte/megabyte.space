import { useThemeToolsSurface } from '../../field-service-primitives.js';
/**
 * CancellationPolicy.tsx — Wave 27 funnel CRO #21 (honest cancel policy).
 *
 * Renders the refund-band schedule visibly above the booking submit button
 * so customers don't get blindsided by "no refund" surprises. The band
 * boundaries are tied to the chosen `dateTime` prop:
 *   100% refund — more than 24 hours out
 *    50% refund — between 2 and 24 hours out
 *     0% refund — less than 2 hours out (within prep window)
 *
 * Live countdown to the next band so the visitor can see exactly when they'd
 * lose 50% / 100% of their refund. Gated behind `honest_cancel_policy`.
 */

import { useEffect, useState } from 'react';
import { useFeatureFlag } from '../use-feature-flag.js';

interface Props {
  /** ISO datetime of the booking (e.g. `2026-06-01T14:00:00`). */
  readonly dateTime?: string;
}

interface Band {
  label: string;
  refundPct: number;
  // Number of seconds AHEAD of dateTime at which this band applies (inclusive).
  startsSecondsBefore: number;
}

const BANDS: Band[] = [
  { label: 'Full refund', refundPct: 100, startsSecondsBefore: 24 * 3600 },
  { label: '50% refund', refundPct: 50, startsSecondsBefore: 2 * 3600 },
  { label: 'No refund', refundPct: 0, startsSecondsBefore: 0 },
];

export function CancellationPolicy({ dateTime }: Props): JSX.Element | null {
  useThemeToolsSurface('cancellation-policy');
  const enabled = useFeatureFlag('honest_cancel_policy');
  const [now, setNow] = useState<number>(() => Date.now());

  useEffect(() => {
    if (!enabled) return;
    const id = setInterval(() => setNow(Date.now()), 30_000);
    return () => clearInterval(id);
  }, [enabled]);

  if (!enabled) return null;

  const bookingMs = dateTime ? Date.parse(dateTime) : NaN;
  const hasBooking = Number.isFinite(bookingMs);
  const secondsTo = hasBooking ? Math.max(0, (bookingMs - now) / 1000) : Number.POSITIVE_INFINITY;

  // Pick the current band (the first whose startsSecondsBefore is ≥ secondsTo,
  // walking from the longest window down).
  let currentIdx = BANDS.length - 1;
  for (let i = 0; i < BANDS.length; i++) {
    if (secondsTo >= BANDS[i]!.startsSecondsBefore) {
      currentIdx = i;
      break;
    }
  }
  const current = BANDS[currentIdx]!;
  const next = BANDS[currentIdx + 1];

  let countdown = '';
  if (next && hasBooking) {
    const dropsAtSeconds = next.startsSecondsBefore;
    const dropsInSec = Math.max(0, secondsTo - dropsAtSeconds);
    countdown = formatCountdown(dropsInSec);
  }

  return (
    <div
      data-bcl-cancel-policy
      className="rounded-xl border border-brand-line bg-bg-primary/40 p-4"
    >
      <p className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
        Cancellation policy
      </p>
      <p className="mt-1 text-sm text-brand-ink">
        <strong>{current.label}</strong>
        {hasBooking && next ? (
          <>
            {' '}
            — drops to <strong>{next.label}</strong> in{' '}
            <span className="font-mono text-brand-accent">{countdown}</span>
          </>
        ) : null}
      </p>
      <ul className="mt-2 space-y-1 text-xs text-brand-mute">
        {BANDS.map((b) => (
          <li key={b.label}>
            <span className="font-mono">{describeWindow(b)}</span> — {b.label}
          </li>
        ))}
      </ul>
      <p className="mt-2 text-[11px] text-brand-mute">
        No service-fee penalty if we have to cancel for weather or crew safety.
      </p>
    </div>
  );
}

function describeWindow(b: Band): string {
  if (b.startsSecondsBefore >= 24 * 3600) return '>24 hours out';
  if (b.startsSecondsBefore >= 2 * 3600) return '2–24 hours out';
  return '<2 hours out';
}

function formatCountdown(sec: number): string {
  if (!Number.isFinite(sec) || sec <= 0) return 'now';
  const hours = Math.floor(sec / 3600);
  const mins = Math.floor((sec % 3600) / 60);
  if (hours >= 24) {
    const days = Math.floor(hours / 24);
    const h = hours % 24;
    return `${days}d ${h}h`;
  }
  if (hours > 0) return `${hours}h ${mins}m`;
  return `${mins}m`;
}
