import { useThemeToolsSurface } from '../../field-service-primitives.js';
// Cancellation policy explainer at /policy/cancellation. The headline: no
// cancellation fee. Cancel up to 24h before service for a full refund. Under
// 24h we hold the deposit toward your next slot — never pocketed. Comparison
// vs Bellhop's $200 non-refundable for context.

import { useEffect } from 'react';
import { PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';

interface PolicyComparisonRow {
  scenario: string;
  bcl: string;
  bellhop: string;
  taskrabbit: string;
  bclWin: boolean;
}

const COMPARISON: PolicyComparisonRow[] = [
  {
    scenario: 'Cancel >24 hours before service',
    bcl: 'Full refund. Zero fee.',
    bellhop: '$200 cancellation fee. Non-refundable deposit.',
    taskrabbit: 'Full refund if >24h. Tasker must release.',
    bclWin: true,
  },
  {
    scenario: 'Cancel 6–24 hours before service',
    bcl: 'Deposit held toward your next slot. No cash loss.',
    bellhop: '$200 + 50% of estimated job cost.',
    taskrabbit: '$10 cancellation fee.',
    bclWin: true,
  },
  {
    scenario: 'Cancel inside 6 hours / day-of',
    bcl: 'Deposit held; we offer same-week reschedule.',
    bellhop: '$200 + full job cost. Non-refundable.',
    taskrabbit: 'Full hourly minimum charged.',
    bclWin: true,
  },
  {
    scenario: 'Crew no-show (our fault)',
    bcl: 'Full refund + $50 inconvenience credit.',
    bellhop: 'Refund only. No credit.',
    taskrabbit: 'Refund only.',
    bclWin: true,
  },
  {
    scenario: 'Weather cancellation',
    bcl: 'Free reschedule. No fee, no deposit hold.',
    bellhop: 'Reschedule fee applies.',
    taskrabbit: 'Tasker decides.',
    bclWin: true,
  },
];

export function CancellationPolicyPage() {
  useThemeToolsSurface('cancellation-policy-page');
  useEffect(() => {
    document.title = 'No Cancellation Fees · Free Rebooking · Brick Labor NJ';
    return () => {
      document.title = 'Brick Labor · $50/hr Property Crew Newark NJ';
    };
  }, []);

  return (
    <main className="section">
      <div className="container-pad max-w-4xl">
        <p className="eyebrow mb-3">Policy</p>
        <h1 className="text-4xl sm:text-5xl font-extrabold">
          No cancellation fee. <span className="text-gradient">Ever.</span>
        </h1>
        <p className="mt-4 text-lg text-brand-mute">
          Cancel up to 24 hours before service — full refund, zero questions. Under 24 hours, we
          hold your deposit toward your next slot. The deposit never disappears into our pocket. You
          either get the work or you keep the credit.
        </p>

        <section className="mt-10 rounded-xl border border-brand-line bg-bg-elevated/40 p-5 sm:p-6">
          <h2 className="font-display text-2xl font-bold">The rules in three sentences</h2>
          <ul className="mt-4 space-y-3 text-sm text-brand-ink">
            <li className="flex gap-3">
              <span aria-hidden className="text-brand-accent">
                →
              </span>
              <span>
                <strong>More than 24 hours before service:</strong> Full refund. We don't even ask
                why.
              </span>
            </li>
            <li className="flex gap-3">
              <span aria-hidden className="text-brand-accent">
                →
              </span>
              <span>
                <strong>Inside 24 hours:</strong> Your deposit (typically $50) is held as credit
                toward your next booking — good for 12 months. If you reschedule within that window,
                the credit applies and you owe nothing extra for the cancel.
              </span>
            </li>
            <li className="flex gap-3">
              <span aria-hidden className="text-brand-accent">
                →
              </span>
              <span>
                <strong>Weather, illness, or emergency:</strong> Reach out — we waive the deposit
                hold. We've all been there.{' '}
                <a href="mailto:hey@bricklabor.com" className="text-brand-accent underline-hover">
                  hey@bricklabor.com
                </a>{' '}
                or{' '}
                <a href={PHONE_TEL_HREF} className="text-brand-accent underline-hover">
                  (855) 82LABOR
                </a>
                .
              </span>
            </li>
          </ul>
        </section>

        <section className="mt-10">
          <h2 className="font-display text-2xl font-bold text-brand-ink">How we compare</h2>
          <p className="mt-1 text-sm text-brand-mute">
            Numbers below come from each platform's published policy as of the current quarter. We
            re-check when their site copy changes.
          </p>
          <div className="mt-5 overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-xs uppercase tracking-wider text-brand-mute">
                <tr className="border-b border-brand-line">
                  <th className="py-2 pr-3">Scenario</th>
                  <th className="py-2 pr-3">Brick Labor</th>
                  <th className="py-2 pr-3">Bellhop</th>
                  <th className="py-2 pr-3">TaskRabbit</th>
                </tr>
              </thead>
              <tbody>
                {COMPARISON.map((row) => (
                  <tr key={row.scenario} className="border-b border-brand-line/50 align-top">
                    <td className="py-3 pr-3 font-medium text-brand-ink">{row.scenario}</td>
                    <td
                      className={`py-3 pr-3 ${row.bclWin ? 'text-brand-accent' : 'text-brand-ink'}`}
                    >
                      {row.bcl}
                    </td>
                    <td className="py-3 pr-3 text-brand-mute">{row.bellhop}</td>
                    <td className="py-3 pr-3 text-brand-mute">{row.taskrabbit}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section className="mt-10 rounded-xl border border-brand-accent/40 bg-brand-accent/5 p-5 sm:p-6">
          <h2 className="font-display text-2xl font-bold text-brand-ink">
            Why we don't charge a cancel fee
          </h2>
          <p className="mt-2 text-sm text-brand-mute">
            A cancellation fee says "we'd rather collect $200 from you than have you back as a
            customer." That's a bad trade. Our flat-rate model already prices in a small slack for
            natural cancel rate; charging individual customers for it would be greedy. Cancel,
            reschedule, change crew size — we'd rather see you booked again next month than punish a
            one-off.
          </p>
          <p className="mt-3 text-sm text-brand-mute">
            Read the rest of our policies:{' '}
            <a href="/terms" className="text-brand-accent underline-hover">
              terms of service
            </a>{' '}
            ·{' '}
            <a href="/privacy" className="text-brand-accent underline-hover">
              privacy
            </a>{' '}
            ·{' '}
            <a href="/take-rate" className="text-brand-accent underline-hover">
              what crew keeps
            </a>
            .
          </p>
        </section>
      </div>
    </main>
  );
}
