import { useThemeToolsSurface } from '../../field-service-primitives.js';
/**
 * City-page conversion components: sticky mobile CTA bar, inline email-capture
 * card, and the bundle prepay tiles. Each component is intentionally
 * self-contained so it can drop into any /c/<slug> route without prop drilling
 * and so the SSR shells in scripts/build-city-pages.mjs can mirror the markup
 * byte-for-byte.
 *
 * Conversion attribute convention: every CTA carries `data-bcl-action="<name>"`
 * + `data-bcl-city="<slug>"` so PostHog autocapture and GA4 enhanced
 * measurement both pick the same event without bespoke wiring.
 */
import { useEffect, useState, type FormEvent } from 'react';
import { PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';
import { isValidEmail } from '@theme.tools/notifications/field-service/email-format';
import type { City } from '../data/cities.js';
import { BUNDLES, bundleSavings, formatPrice } from '@theme.tools/billing/field-service/bundles';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { bundlesCopy } from '@theme.tools/i18n-a11y/field-service/bundles-copy';

interface CityProps {
  city: City;
}

/**
 * Floating bottom CTA bar — mobile only, fades in after the user scrolls
 * past the hero (250 px). Single tap to call, single tap to book. The
 * heaviest revenue lever per kilobyte on the page.
 */
export function StickyMobileCta({ city }: CityProps) {
  useThemeToolsSurface('city-conversion');
  // Keep a mirror-locale visitor in /es · /pt: localize the booking href.
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const lp = (p: string) => (p.startsWith('/') ? localizedPath(locale, p) : p);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 250);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  // A11y: when the CTA is off-screen (translateY(100%)) we ALSO want it out of
  // the tab order. Setting `aria-hidden` alone isn't enough — axe-core flags
  // any aria-hidden subtree that contains tabbable descendants (`aria-hidden-
  // focus`, WCAG 4.1.2). Drop tabindex=-1 + inert when hidden; restore on
  // visible. Keeps the slide-in animation while staying a11y-clean.
  return (
    <div
      className={`fixed inset-x-0 bottom-0 z-30 transition-transform duration-300 sm:hidden ${
        visible ? 'translate-y-0' : 'translate-y-full'
      }`}
      data-bcl-surface="sticky-cta"
      data-bcl-city={city.slug}
      aria-hidden={!visible}
      {...(!visible ? { inert: '' as unknown as boolean } : {})}
    >
      <div className="border-t border-brand-line bg-bg-primary/95 backdrop-blur-md shadow-[0_-8px_24px_-12px_rgba(0,0,0,0.55)]">
        <div className="flex gap-2 px-3 py-3">
          <a
            href={PHONE_TEL_HREF}
            data-bcl-action="phone_click"
            data-bcl-city={city.slug}
            data-bcl-surface="sticky-cta"
            className="flex-1 inline-flex items-center justify-center gap-2 rounded-lg border border-brand-line bg-bg-elevated px-4 py-3 text-sm font-bold text-brand-ink min-h-[44px]"
            tabIndex={visible ? 0 : -1}
          >
            <svg
              viewBox="0 0 24 24"
              className="h-4 w-4"
              fill="none"
              stroke="currentColor"
              strokeWidth={2}
              aria-hidden
            >
              <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.86 19.86 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.86 19.86 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.37 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.33 1.85.57 2.81.7A2 2 0 0 1 22 16.92z" />
            </svg>
            Call now
          </a>
          <a
            href={lp('/book')}
            data-bcl-action="booking_click"
            data-bcl-city={city.slug}
            data-bcl-surface="sticky-cta"
            className="flex-1 inline-flex items-center justify-center rounded-lg bg-brand-accent px-4 py-3 text-sm font-extrabold text-bg-primary min-h-[44px]"
            tabIndex={visible ? 0 : -1}
          >
            Book {city.name} crew →
          </a>
        </div>
      </div>
    </div>
  );
}

/**
 * Inline "Get $25 off your first {city} job" email capture. Posts to the
 * existing /api/subscribe route with source="city-<slug>" so Listmonk + the
 * admin dashboard can attribute first-touch by city.
 */
export function CityEmailCapture({ city }: CityProps) {
  const [email, setEmail] = useState('');
  const [state, setState] = useState<'idle' | 'sending' | 'ok' | 'err'>('idle');
  const [msg, setMsg] = useState('');

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!email || state === 'sending') return;
    // `noValidate` on the form means the browser won't check type="email"; do a
    // client-side format check so an invalid address gets instant feedback
    // instead of a round-trip to /api/subscribe (the server still re-validates).
    if (!isValidEmail(email)) {
      setState('err');
      setMsg('Enter a valid email address.');
      return;
    }
    setState('sending');
    setMsg('');
    try {
      const r = await fetch('/api/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          source: `city-${city.slug}`,
        }),
      });
      const body = (await r.json().catch(() => ({}))) as { ok?: boolean; message?: string };
      if (r.ok && body.ok) {
        setState('ok');
        setMsg(body.message || `You're in. Watch for your $25-off code, ${city.name} edition.`);
      } else {
        setState('err');
        setMsg(body.message || 'Could not save right now. Try again in a minute.');
      }
    } catch {
      setState('err');
      setMsg('Network hiccup. Try again.');
    }
  }

  return (
    <section
      id="city-email"
      className="section-tight scroll-mt-24"
      aria-label={`${city.name} email capture`}
    >
      <div className="container-pad max-w-3xl">
        <div
          className="rounded-2xl border border-brand-line bg-gradient-to-br from-brand-accent/10 to-transparent p-6 sm:p-8"
          data-bcl-surface="city-email"
          data-bcl-city={city.slug}
        >
          <p className="eyebrow mb-3">{city.name} first-timer perk</p>
          <h2 className="font-display text-2xl sm:text-3xl font-extrabold">
            Get <span className="text-brand-accent">$25 off</span> your first {city.name} job.
          </h2>
          <p className="mt-3 text-brand-mute leading-relaxed">
            One email per month, max. {city.name} pricing tips, seasonal reminders, and a single
            $25-off code that lands in your inbox right now.
          </p>
          <form className="mt-5 flex flex-col gap-3 sm:flex-row" onSubmit={onSubmit} noValidate>
            <label htmlFor={`city-email-${city.slug}`} className="sr-only">
              Email address
            </label>
            <input
              id={`city-email-${city.slug}`}
              type="email"
              required
              autoComplete="email"
              inputMode="email"
              spellCheck={false}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@email.com"
              className="flex-1 rounded-lg border border-brand-line bg-bg-primary px-4 py-3 text-base text-brand-ink placeholder:text-brand-mute focus:outline-none focus:ring-2 focus:ring-brand-accent"
              disabled={state === 'sending' || state === 'ok'}
            />
            <button
              type="submit"
              data-bcl-action="email_capture_submit"
              data-bcl-city={city.slug}
              data-bcl-surface="city-email"
              className="rounded-lg bg-brand-accent px-5 py-3 text-base font-extrabold text-bg-primary disabled:opacity-60 min-h-[44px]"
              disabled={state === 'sending' || state === 'ok'}
            >
              {state === 'sending' ? 'Sending…' : state === 'ok' ? 'Sent ✓' : 'Send my code →'}
            </button>
          </form>
          {msg && (
            <p
              role="status"
              className={`mt-4 text-sm ${state === 'ok' ? 'text-brand-accent' : 'text-brand-mute'}`}
            >
              {msg}
            </p>
          )}
          <p className="mt-5 text-[11px] text-brand-mute font-mono">
            No spam. Unsubscribe in one click. Code applies to your first {city.name} booking only —
            minimum 2-hour job.
          </p>
        </div>
      </div>
    </section>
  );
}

/**
 * Prepay bundle tiles. Each tile shows price, what's included, and what the
 * same scope would cost on the $50/hr meter — putting the "you save $X" line
 * front-and-center so the bundle reads as a discount instead of a markup.
 */
/**
 * BundlesBlock — three prepay-package cards. Renders on:
 *   - city pages (`/c/<slug>`) with city-specific eyebrow + analytics tag
 *   - the standalone `/bundles` page (city omitted, generic eyebrow)
 *   - the homepage between Services + Pricing (city omitted, generic eyebrow)
 *
 * CTA target — every card links to `/book?bundle=<slug>` (the standalone
 * /book route, query params thread through). The booking form reads the
 * slug on mount and locks the form into prepay mode at the bundle price.
 */
export function BundlesBlock({ city }: { city?: City }) {
  // `/c/<slug>` city pages are English-only (not mirror-prerendered); the
  // generic homepage + `/bundles` variants serve the `/es` + `/pt` mirrors, so
  // read the locale from the path and zip in-language copy on by index/slug.
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  // Keep a mirror-locale visitor in /es · /pt: localize internal `/` hrefs;
  // leave mailto:/tel:/external + static-asset paths bare.
  const lp = (p: string) => (p.startsWith('/') ? localizedPath(locale, p) : p);
  const c = bundlesCopy(locale);
  const eyebrow = city ? `${city.name} prepay packages` : c.eyebrow;
  // City pages keep the city-interpolated English lead; the generic variant uses
  // the fully-localized lead from the copy module.
  const lead = city
    ? `The hourly meter is great for one-off odd jobs. For the three patterns we book most in ${city.name}, bundle pricing saves you the call-back loop AND beats the meter on price.`
    : c.lead;
  return (
    <section
      id="bundles"
      className="section-tight scroll-mt-24"
      aria-label={city ? `${city.name} prepay packages` : c.eyebrow}
    >
      <div className="container-pad">
        <div className="mb-8 max-w-3xl" data-animate="fade-up">
          <p className="eyebrow mb-3">{eyebrow}</p>
          <h2 className="text-3xl sm:text-4xl font-extrabold">
            {c.titlePre}
            <span className="text-gradient">{c.titleAccent}</span>
          </h2>
          <p className="mt-4 text-lg text-brand-mute">{lead}</p>
        </div>
        <ul
          className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3"
          data-stagger="100"
          data-bcl-surface="bundles"
          {...(city ? { 'data-bcl-city': city.slug } : {})}
        >
          {BUNDLES.map((b) => {
            const savings = bundleSavings(b);
            // Localized strings zip on by slug; price/slug/metered figures stay
            // locale-invariant. Falls back to the English bundle, then to the
            // raw `bundles.mjs` data so a missing key never blanks a card.
            const bc = c.bundles[b.slug] ?? bundlesCopy('en').bundles[b.slug];
            return (
              <li
                key={b.slug}
                data-animate="fade-up"
                className="flex flex-col rounded-2xl border border-brand-line bg-bg-elevated p-6 transition-colors hover:border-brand-accent"
              >
                <p className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
                  {bc?.hours ?? b.hours}
                </p>
                <h3 className="mt-2 font-display text-xl font-extrabold text-brand-ink">
                  {bc?.title ?? b.title}
                </h3>
                <p className="mt-2 text-sm text-brand-mute leading-relaxed">
                  {bc?.tagline ?? b.tagline}
                </p>
                <div className="mt-5 flex items-baseline gap-3">
                  <span className="font-display text-4xl font-extrabold text-brand-accent">
                    {formatPrice(b.priceCents)}
                  </span>
                  <span className="text-sm text-brand-mute line-through">
                    {formatPrice(b.meteredEquivalentCents)}
                  </span>
                </div>
                {savings > 0 && (
                  <p className="mt-1 text-xs font-mono text-brand-accent">
                    {c.save} {formatPrice(savings)} {c.vsMeter}
                  </p>
                )}
                <ul className="mt-5 space-y-2 text-sm text-brand-ink">
                  {(bc?.inclusions ?? b.inclusions).map((inc) => (
                    <li key={inc} className="flex items-start gap-2">
                      <span
                        aria-hidden
                        className="mt-1.5 inline-block h-1.5 w-1.5 flex-none rounded-full bg-brand-accent"
                      />
                      <span>{inc}</span>
                    </li>
                  ))}
                </ul>
                <p className="mt-5 text-xs text-brand-mute font-mono border-t border-brand-line pt-4">
                  {c.bestForLabel} {bc?.bestFor ?? b.bestFor}
                </p>
                <a
                  href={lp(`/book?bundle=${b.slug}`)}
                  data-bcl-action="bundle_click"
                  data-bcl-bundle={b.slug}
                  {...(city ? { 'data-bcl-city': city.slug } : {})}
                  data-bcl-surface="bundles"
                  data-bcl-price-cents={b.priceCents}
                  className="mt-6 inline-flex items-center justify-center rounded-lg bg-brand-accent px-4 py-2.5 text-sm font-extrabold text-bg-primary min-h-[44px]"
                >
                  {bc?.bookCta ?? `Book this ${b.title.split(' ')[0]} →`}
                </a>
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
