import { lazy, Suspense, useEffect, useMemo, type ReactNode } from 'react';
import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { evaluateCurbAndParkingClearance } from '@theme.tools/scheduling/field-service/theme-tools-field-service-bridge';
import {
  CITIES,
  distanceFromNewarkMiles,
  getCityBySlug,
  isDestinationCity,
  nearestCities,
  type City,
} from '../data/cities.js';
import { areaContext, isHomeBase } from '../data/area-context.js';
import { cityContent, type CityContent } from '../data/city-content.js';
import { getCityImage, cityImageSrc, getCityGallery } from '../data/city-images.js';
import { getCityCopy } from '../data/city-copy.js';
import { getCityHero, getCityLocalImages } from '../data/city-credits.js';
import { BLOG_POSTS } from '../data/blog-posts.js';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { cityPageCopy, fillCity, type CityPageCopy } from '@theme.tools/i18n-a11y/field-service/city-page-copy';
import { EeatStrip, JsonLd, faqPage, homeServicesBusiness, personBrian, useSoleFaqPage } from './seo/index.js';
import { DashboardCallout } from './DashboardCallout.js';
import { PerZipPricing } from './PerZipPricing.js';
import { MovePhotoGallery } from './MovePhotoGallery.js';
import { BundlesBlock, CityEmailCapture, StickyMobileCta } from './CityConversion.js';
import { CityHeroImage } from './CityHeroImage.js';
import { PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';
import { buildLongFormPageAuthorityDossier } from '@theme.tools/seo-geo/field-service/matrix-3d-engine';
import { FieldServicePodcastPlayer } from './FieldServicePodcastPlayer.js';
import { TerritoryDualLayerMap } from './TerritoryDualLayerMap.js';
import { AuthorityDossierTail, IdeogramInfographicDeck } from './IdeogramInfographicDeck.js';

// City pages mount the booking widget far below the fold — keep it in the
// lazy chunk so the initial city render stays slim.
const Booking = lazy(() => import('./Booking.js').then((m) => ({ default: m.Booking })));

interface Props {
  slug: string;
}

/**
 * Structural-only service rows — slug + icon glyph. The visitor-facing copy
 * (title, blurb, example chips) is read per-locale from `city-page-copy` so the
 * `/es/c/*` + `/pt/c/*` cards render in-language. The card slug keys into
 * `copy.services[slug]`; the icon stays here (locale-invariant SVG).
 */
const SERVICE_ROWS: ReadonlyArray<{ slug: string; icon: string }> = [
  { slug: 'power-washing', icon: 'wash' },
  { slug: 'lawn-care', icon: 'lawn' },
  { slug: 'hauling', icon: 'haul' },
  { slug: 'light-repairs', icon: 'tool' },
];

const ICONS: Record<string, JSX.Element> = {
  wash: <path d="M12 2v6m0 0c-3 3-6 6-6 9a6 6 0 0 0 12 0c0-3-3-6-6-9zm-3 11h6" />,
  lawn: <path d="M3 20h18M5 20V8m7 12V4m7 16v-9" />,
  haul: (
    <path d="M3 17h13V6H3v11zm13-7h4l2 4v3h-6m-7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm10 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4z" />
  ),
  tool: <path d="M14 6l4 4M5 19l8-8m1-3a3 3 0 1 0 4 4l-1 1 3 3-3 3-3-3 1-1a3 3 0 0 0-4-4z" />,
};

export function CityPage({ slug }: Props) {
  const city = useMemo(() => getCityBySlug(slug), [slug]);

  // SSR/prerender is locale-stamped per route; on the client we read the URL so
  // a /es or /pt city page renders its chrome in-language after hydration.
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const copy = cityPageCopy(locale);
  /** Keep a /es|/pt visitor inside their locale when clicking internal links. */
  const lp = (path: string): string => localizedPath(locale, path);

  // The city FAQPage below (inside #root) is canonical; strip the stale
  // prerendered <head> FAQPage so Google sees exactly one (@id-less) node.
  useSoleFaqPage();

  useEffect(() => {
    if (!city) return;
    const c = cityPageCopy(stripLocalePrefix(window.location.pathname).locale);
    const dist = Math.round(distanceFromNewarkMiles(city));
    const distAwayLabel = fillCity(isHomeBase(dist) ? c.distAwayHome : c.distAway, { dist });
    const vars = { city: city.name, state: city.state, dist, distAwayLabel };
    document.title = isDestinationCity(city)
      ? `Power Washing in ${city.name}, ${city.state} — Brick Labor Travels Here`
      : fillCity(c.metaTitle, vars);
    setMeta(
      'description',
      isDestinationCity(city)
        ? `Brick Labor travels to ${city.name}, ${city.state} for scheduled power-washing — brick rowhouses, marble stoops, sidewalks, and siding. Booked ahead, quoted per job.`
        : fillCity(c.metaDescription, vars),
    );
    setLink(
      'canonical',
      `https://bricklabor.com${localizedPath(stripLocalePrefix(window.location.pathname).locale, `/c/${city.slug}`)}`,
    );
  }, [city]);

  if (!city) return <NotFound />;

  const cityDossier = buildLongFormPageAuthorityDossier({
    modifierSlug: '3-movers-4-hours-walkup-brigade',
    workTypeSlug: 'moving-labor',
    town: {
      slug: city.slug,
      name: city.name,
      county: city.county,
      state: city.state,
      lat: city.lat,
      lng: city.lng,
    },
    canonicalPath: `/c/${city.slug}`,
    prefilledBookingPath: `/book?city=${encodeURIComponent(city.slug)}`,
  });

  const distance = Math.round(distanceFromNewarkMiles(city));
  /** Newark itself: render home-base phrasing, never a literal "0 mi". */
  const homeBase = isHomeBase(distance);
  /** Far service area we travel to (e.g. Washington DC) — suppress Newark-metro
   * proximity framing (nearby cities, same-day dispatch) so nothing reads false. */
  const destination = isDestinationCity(city);
  const distAwayLabel = fillCity(homeBase ? copy.distAwayHome : copy.distAway, { dist: distance });
  const distFromLabel = fillCity(homeBase ? copy.distFromHome : copy.distFrom, { dist: distance });
  /** Common interpolation vars for `fillCity` across this render. */
  const v = {
    city: city.name,
    state: city.state,
    county: city.county,
    dist: distance,
    distAwayLabel,
    distFromLabel,
    pop: city.population.toLocaleString(),
    count: CITIES.length,
  };
  const f = (tpl: string): string => fillCity(tpl, v);
  const nearby = nearestCities(city, 5);
  const ctx = areaContext(city);
  const content = cityContent(city);
  const cityCopy = getCityCopy(city.slug);
  const heroCommons = getCityHero(city.slug);
  const localPhotos = getCityLocalImages(city.slug);
  const img = getCityImage(city.slug);
  // Prefer the Commons-sourced hero when present; otherwise fall back to the
  // legacy Unsplash/Pexels jpg already shipped at /cities/<slug>.jpg.
  const imgSrc = heroCommons?.src ?? cityImageSrc(city.slug);
  const gallery = getCityGallery(city.slug);
  const relatedPosts = useMemo(() => {
    const cityLower = city.name.toLowerCase();
    const matches = BLOG_POSTS.filter((p) => {
      const haystack = `${p.title} ${p.excerpt} ${p.body.slice(0, 4000)}`.toLowerCase();
      return haystack.includes(cityLower);
    });
    return (
      matches.length >= 3
        ? matches
        : [...matches, ...BLOG_POSTS.filter((p) => !matches.includes(p))]
    ).slice(0, 6);
  }, [city]);

  const surfaceProps = useThemeToolsSurface(`city-${slug}`, [
    '@theme.tools/ui',
    '@theme.tools/scheduling',
    '@theme.tools/seo-geo',
  ]);
  const curbEvaluation = evaluateCurbAndParkingClearance({
    categorySlug: 'moving-labor',
    cityOrMunicipality: city.name,
  });

  return (
    <>
      {/* CLS budget: images reserve space via width/height + aspect-ratio, map container has fixed min-height. See docs/cwv-city-pages-2026-06.md */}
      <section
        className="relative overflow-hidden"
        data-theme-tools-surface={surfaceProps['data-theme-tools-surface']}
        data-theme-tools-pricing-model={surfaceProps['data-theme-tools-pricing-model']}
        data-curb-permit-lead-hours={curbEvaluation.permitLeadTimeHours}
      >
        {/* CLS budget: hero image reserves space via width/height. See docs/cwv-city-pages-2026-06.md */}
        <div className="absolute inset-0 pointer-events-none" aria-hidden>
          <CityHeroImage src={imgSrc} className="absolute inset-0 h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-bg-primary via-bg-primary/85 to-bg-primary/30" />
          <div className="absolute inset-0 bg-gradient-to-t from-bg-primary via-bg-primary/40 to-transparent" />
          <div className="absolute inset-0 grid-pattern opacity-40" />
          <div className="absolute -top-40 -right-40 h-[500px] w-[500px] rounded-full bg-brand-accent/15 blur-3xl animate-pulse-slow" />
        </div>

        <div className="container-pad relative pt-16 pb-20 sm:pt-24 sm:pb-28">
          <nav aria-label="Breadcrumb" className="mb-6 text-sm text-brand-mute">
            <a href={lp('/')} className="underline-hover">
              {copy.crumbHome}
            </a>
            <span className="mx-2">/</span>
            <a href={lp('/#coverage')} className="underline-hover">
              {copy.crumbArea}
            </a>
            <span className="mx-2">/</span>
            <span className="text-brand-ink">
              {city.name}, {city.state}
            </span>
          </nav>

          <p className="eyebrow mb-5" data-animate="fade-up" data-delay="0">
            {f(copy.eyebrow)}
          </p>
          <h1
            className="text-5xl sm:text-7xl font-extrabold leading-[1.02] max-w-4xl"
            data-animate="fade-up"
            data-delay="120"
          >
            {destination ? 'Power washing in' : copy.heroTitlePre}{' '}
            <span className="text-gradient">
              {city.name}, {city.state}
            </span>
            .
          </h1>
          <p
            className="mt-6 text-lg sm:text-xl text-brand-mute max-w-2xl"
            data-animate="fade-up"
            data-delay="240"
          >
            {destination ? (
              <>
                Brick Labor travels to{' '}
                <a
                  href={lp('/services/power-washing')}
                  className="text-brand-accent underline-hover"
                >
                  {city.name}
                </a>{' '}
                for scheduled power-washing projects — brick rowhouses, marble stoops, sidewalks,
                and siding. Booked ahead, quoted per job.
              </>
            ) : (
              <>
                {copy.ledeIntro}{' '}
                <a
                  href={lp('/services/power-washing')}
                  className="text-brand-accent underline-hover"
                >
                  {copy.lnkPowerWashing}
                </a>
                ,{' '}
                <a href={lp('/services/lawn-care')} className="text-brand-accent underline-hover">
                  {copy.lnkLawnCare}
                </a>
                ,{' '}
                <a href={lp('/services/hauling')} className="text-brand-accent underline-hover">
                  {copy.lnkHauling}
                </a>
                , {copy.ledeAnd}{' '}
                <a
                  href={lp('/services/light-repairs')}
                  className="text-brand-accent underline-hover"
                >
                  {copy.lnkLightRepairs}
                </a>{' '}
                {f(copy.ledeIn)} <strong className="text-brand-ink">{copy.ledeRate}</strong>.{' '}
                {copy.ledeSuffix}
              </>
            )}
          </p>

          <div
            className="relative z-10 mt-9 flex flex-col sm:flex-row gap-3"
            data-animate="fade-up"
            data-delay="360"
          >
            <a
              href={lp('/book')}
              data-bcl-action="booking_click"
              data-bcl-city={city.slug}
              data-bcl-surface="hero"
              className="btn-primary text-base relative z-10"
            >
              {f(copy.ctaBookCrew)}
            </a>
            <a
              href={PHONE_TEL_HREF}
              data-bcl-action="phone_click"
              data-bcl-city={city.slug}
              data-bcl-surface="hero"
              className="btn-ghost text-base relative z-10"
            >
              {copy.ctaCall}
            </a>
          </div>

          <ul
            className="mt-12 grid grid-cols-2 sm:grid-cols-4 gap-x-4 gap-y-5 text-sm"
            data-stagger="80"
          >
            <li data-animate="fade-up">
              <div className="font-display text-3xl font-extrabold text-brand-accent">
                {destination ? (
                  <span>Travel</span>
                ) : (
                  <span data-count="50" data-count-prefix="$" data-count-suffix="/hr">
                    $50/hr
                  </span>
                )}
              </div>
              <div className="text-brand-mute">
                {destination ? 'scheduled projects' : copy.statRateLabel}
              </div>
            </li>
            <li data-animate="fade-up">
              <div className="font-display text-3xl font-extrabold text-brand-accent">
                {homeBase ? (
                  <span>Newark</span>
                ) : (
                  <span data-count={distance} data-count-suffix=" mi">
                    {distance} mi
                  </span>
                )}
              </div>
              <div className="text-brand-mute">
                {homeBase ? copy.statDistHomeLabel : copy.statDistLabel}
              </div>
            </li>
            <li data-animate="fade-up">
              <div className="font-display text-3xl font-extrabold text-brand-accent">
                {city.county}
              </div>
              <div className="text-brand-mute">{f(copy.statCountyLabel)}</div>
            </li>
            <li data-animate="fade-up">
              <div className="font-display text-3xl font-extrabold text-brand-accent">
                {formatPop(city.population)}
              </div>
              <div className="text-brand-mute">{copy.statPopLabel}</div>
            </li>
          </ul>

          {img && (
            <p className="mt-10 text-[11px] font-mono text-brand-mute">
              {copy.photoLabel}{' '}
              <a
                href={img.photographerUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="underline-hover text-brand-mute hover:text-brand-accent"
              >
                {img.photographer}
              </a>{' '}
              · {img.source}
            </p>
          )}
        </div>
      </section>

      <EeatStrip variant="city" cityName={city.name} />

      <div className="container-pad pt-8">
        <FieldServicePodcastPlayer
          episode={cityDossier.podcast}
          bookingUrl="https://bricklabor.com/book"
        />
        <TerritoryDualLayerMap
          town={cityDossier.townHeritage}
          workTypeName="Moving, Hauling, Power Washing & Yard Labor"
          modifierTitle={`${city.name} Hourly Property Crew ($50/hr)`}
          bookingUrl="https://bricklabor.com/book"
        />
        <IdeogramInfographicDeck
          town={cityDossier.townHeritage}
          crewPhotos={cityDossier.crewScenarioPhotos}
          infographics={cityDossier.ideogramInfographics}
          bookingUrl="https://bricklabor.com/book"
        />
      </div>

      {city.zip && !destination && (
        <section className="section-tight">
          <PerZipPricing zip={city.zip} />
        </section>
      )}

      <section className="section-tight">
        <div className="container-pad">
          <div className="grid lg:grid-cols-[1.4fr_1fr] gap-10 lg:gap-14 items-start">
            <div data-animate="slide-right">
              <p className="eyebrow mb-3">{copy.ctxEyebrow}</p>
              <h2 className="text-3xl sm:text-4xl font-extrabold mb-5">{ctx.headline}</h2>
              <p className="text-lg text-brand-mute leading-relaxed">{ctx.body}</p>
              <p className="mt-5 font-mono text-sm text-brand-mute border-l-2 border-brand-accent pl-4">
                {ctx.commute}
              </p>
            </div>
            <figure
              data-animate="image-reveal"
              data-delay="200"
              className="relative overflow-hidden rounded-2xl border border-brand-line bg-bg-elevated"
            >
              <img
                src={imgSrc}
                alt={img?.alt ?? `${city.name}, ${city.state}`}
                loading="lazy"
                decoding="async"
                width={1200}
                height={900}
                className="aspect-[4/3] w-full object-cover"
              />
              <figcaption className="px-4 py-3 text-xs text-brand-mute font-mono">
                {city.name}, {city.state}
                {img && (
                  <>
                    {' · '}
                    <a
                      href={img.photographerUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="underline-hover hover:text-brand-accent"
                    >
                      {img.photographer}
                    </a>
                  </>
                )}
              </figcaption>
            </figure>
          </div>
        </div>
      </section>

      {cityCopy && cityCopy.about.length > 0 && (
        <section id="about-city" className="section-tight scroll-mt-24">
          <div className="container-pad max-w-4xl">
            <div className="mb-7" data-animate="fade-up">
              <p className="eyebrow mb-3">{f(copy.aboutEyebrow)}</p>
              <h2 className="text-3xl sm:text-4xl font-extrabold">
                {city.name}, {city.state} —{' '}
                <span className="text-gradient">{f(copy.aboutHeadStat)}</span>
              </h2>
            </div>
            <div className="space-y-5" data-stagger="120">
              {cityCopy.about.map((para, i) => (
                <p
                  key={i}
                  data-animate="fade-up"
                  className="text-lg text-brand-mute leading-relaxed"
                >
                  {para}
                </p>
              ))}
            </div>
          </div>
        </section>
      )}

      {localPhotos.length > 0 && (
        <section id="local-photos" className="section-tight scroll-mt-24">
          <div className="container-pad">
            <div className="mb-8 max-w-3xl" data-animate="fade-up">
              <p className="eyebrow mb-3">{f(copy.photosEyebrow)}</p>
              <h2 className="text-3xl sm:text-4xl font-extrabold">
                {copy.photosHead1} <span className="text-gradient">{copy.photosHead2}</span>
              </h2>
              <p className="mt-4 text-lg text-brand-mute">{f(copy.photosLede)}</p>
            </div>
            <ul className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3" data-stagger="80">
              {localPhotos.map((p, i) => (
                <li
                  key={p.src}
                  data-animate="fade-up"
                  className="group relative overflow-hidden rounded-xl border border-brand-line bg-bg-elevated"
                >
                  <img
                    src={p.src}
                    alt={`${city.name}, ${city.state} — ${cleanTitle(p.credit.title)}`}
                    loading={i < 2 ? 'eager' : 'lazy'}
                    decoding="async"
                    width={1200}
                    height={800}
                    className="aspect-[3/2] w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="px-3 py-2.5 text-[11px] font-mono text-brand-mute">
                    <a
                      href={p.credit.sourceUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="underline-hover hover:text-brand-accent"
                    >
                      {truncate(p.credit.author, 40)}
                    </a>
                    {' · '}
                    <span className="text-brand-mute">{p.credit.license}</span>
                    {p.credit.year ? ` · ${p.credit.year}` : ''}
                  </div>
                </li>
              ))}
            </ul>
            <p className="mt-5 text-xs text-brand-mute">
              {copy.photosFoot1}{' '}
              <a
                href="https://commons.wikimedia.org/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-brand-accent underline-hover"
              >
                Wikimedia Commons
              </a>
              {copy.photosFoot2}
            </p>
          </div>
        </section>
      )}

      {cityCopy && cityCopy.neighborhoods.length > 0 && (
        <section
          id="local-neighborhoods"
          className="section-tight scroll-mt-24"
          aria-label={`${city.name} neighborhoods`}
        >
          <div className="container-pad">
            <div className="mb-6 max-w-3xl" data-animate="fade-up">
              <p className="eyebrow mb-3">{f(copy.nbhdEyebrow)}</p>
              <h2 className="text-3xl sm:text-4xl font-extrabold">
                {copy.nbhdHead1} <span className="text-gradient">{copy.nbhdHead2}</span>
              </h2>
            </div>
            <ul className="flex flex-wrap gap-2 text-sm" data-stagger="50">
              {cityCopy.neighborhoods.map((n) => (
                <li
                  key={n}
                  data-animate="fade-up"
                  className="inline-flex min-h-[24px] items-center rounded-full border border-brand-line bg-bg-elevated px-3 py-1.5 text-brand-ink transition-all duration-[333ms] hover:-translate-y-0.5 hover:border-brand-accent hover:text-white"
                >
                  {n}
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}

      {cityCopy?.parking && (
        <section
          id="local-parking"
          className="section-tight scroll-mt-24"
          aria-label={`${city.name} parking and access notes`}
        >
          <div className="container-pad max-w-4xl">
            <div className="rounded-2xl border-l-4 border-brand-accent bg-bg-elevated p-6 sm:p-7">
              <p className="eyebrow mb-3">{f(copy.parkingEyebrow)}</p>
              <p className="text-lg text-brand-mute leading-relaxed">{cityCopy.parking}</p>
            </div>
          </div>
        </section>
      )}

      <section
        id="reviews"
        className="section-tight scroll-mt-24"
        aria-label={`${city.name} customer reviews`}
      >
        <div className="container-pad max-w-3xl">
          <div className="rounded-2xl border border-dashed border-brand-line bg-bg-elevated p-6 sm:p-7 text-center">
            <p className="eyebrow mb-3">{f(copy.reviewsEyebrow)}</p>
            <h2 className="text-2xl sm:text-3xl font-extrabold">{f(copy.reviewsHead)}</h2>
            <p className="mt-3 text-brand-mute">
              {f(copy.reviewsBody)}{' '}
              <a href={lp('/r')} className="text-brand-accent underline-hover">
                {copy.reviewsSeeLive}
              </a>{' '}
              {copy.reviewsOr}{' '}
              <a href={lp('/book')} className="text-brand-accent underline-hover">
                {f(copy.reviewsBookFirst)}
              </a>
              .
            </p>
          </div>
        </div>
      </section>

      {gallery.length > 0 && (
        <section id="gallery" className="section-tight scroll-mt-24">
          <div className="container-pad">
            <div className="mb-8 max-w-3xl" data-animate="fade-up">
              <p className="eyebrow mb-3">{f(copy.galleryEyebrow)}</p>
              <h2 className="text-3xl sm:text-4xl font-extrabold">
                {copy.galleryHead1} <span className="text-gradient">{copy.galleryHead2}</span>
              </h2>
              <p className="mt-4 text-lg text-brand-mute">{f(copy.galleryLede)}</p>
            </div>
            <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4" data-stagger="60">
              {gallery.map((g, i) => (
                <li
                  key={`${g.src}-${i}`}
                  data-animate="fade-up"
                  className="group relative overflow-hidden rounded-xl border border-brand-line bg-bg-elevated"
                >
                  <img
                    src={g.src}
                    alt={g.alt || `${city.name}, ${city.state} street view`}
                    loading="lazy"
                    decoding="async"
                    width={800}
                    height={600}
                    className="aspect-[4/3] w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg-primary/85 via-bg-primary/30 to-transparent p-3">
                    <a
                      href={g.photographerUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="pointer-events-auto font-mono text-[10px] uppercase tracking-widest text-brand-mute underline-hover hover:text-brand-accent"
                    >
                      {g.photographer} · {g.source}
                    </a>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}

      {content.neighborhoods.length > 0 && (
        <section id="neighborhoods" className="section-tight scroll-mt-24">
          <div className="container-pad">
            <div className="mb-8 max-w-3xl" data-animate="fade-up">
              <p className="eyebrow mb-3">{f(copy.coverageEyebrow)}</p>
              <h2 className="text-3xl sm:text-4xl font-extrabold">
                {f(copy.coverageHead1)} <span className="text-gradient">{copy.coverageHead2}</span>
              </h2>
              <p className="mt-4 text-lg text-brand-mute">
                {destination
                  ? `From ${content.neighborhoods[0] ?? city.name} to ${content.neighborhoods[content.neighborhoods.length - 1] ?? city.name}, we bring the full power-washing rig to the District's brick and stone. Scheduled projects, quoted per job.`
                  : fillCity(copy.coverageLede, {
                      ...v,
                      first: content.neighborhoods[0] ?? city.name,
                      last: content.neighborhoods[content.neighborhoods.length - 1] ?? city.name,
                    })}
              </p>
            </div>
            <ul className="flex flex-wrap gap-2 text-sm" data-stagger="50">
              {content.neighborhoods.map((n) => (
                <li
                  key={n}
                  data-animate="fade-up"
                  className="inline-flex min-h-[24px] items-center rounded-full border border-brand-line bg-bg-elevated px-3 py-1.5 text-brand-mute transition-all duration-[333ms] hover:-translate-y-0.5 hover:border-brand-accent hover:text-brand-ink"
                >
                  {n}
                </li>
              ))}
            </ul>
            {content.landmarks.length > 0 && (
              <div className="mt-7">
                <p className="font-mono text-xs text-brand-mute mb-2">{copy.landmarksLabel}</p>
                <ul
                  aria-label={copy.landmarksLabel}
                  className="flex flex-wrap gap-1.5"
                  data-stagger="50"
                >
                  {content.landmarks.map((lm) => (
                    <li
                      key={lm}
                      data-animate="fade-up"
                      className="rounded-full border border-brand-line bg-bg-elevated px-2.5 py-0.5 font-mono text-xs text-brand-mute transition-all duration-[333ms] hover:-translate-y-0.5 hover:border-brand-accent hover:text-brand-ink"
                    >
                      {lm}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </section>
      )}

      <section id="jobs" className="section-tight scroll-mt-24">
        <div className="container-pad">
          <div className="grid lg:grid-cols-[1.4fr_1fr] gap-10 lg:gap-14 items-start">
            <div data-animate="slide-right">
              <p className="eyebrow mb-3">{copy.jobsEyebrow}</p>
              <h2 className="text-3xl sm:text-4xl font-extrabold mb-5">
                {f(copy.jobsHead1)} <span className="text-gradient">{f(copy.jobsHead2)}</span>
              </h2>
              <p className="text-lg text-brand-mute leading-relaxed">{content.jobsParagraph}</p>
              <p className="mt-5 text-base text-brand-mute leading-relaxed">{content.homeStock}</p>
            </div>
            <aside
              data-animate="fade-up"
              data-delay="120"
              className="rounded-2xl border border-brand-line bg-bg-elevated p-6"
            >
              <p className="eyebrow mb-4">{f(copy.jobsAsideLabel)}</p>
              <ul className="space-y-2.5">
                {content.jobs.map((job) => (
                  <li key={job} className="flex items-start gap-2.5 text-sm">
                    <span
                      aria-hidden
                      className="mt-1 inline-block h-1.5 w-1.5 flex-none rounded-full bg-brand-accent"
                    />
                    <span className="text-brand-ink">{job}</span>
                  </li>
                ))}
              </ul>
              <p className="mt-5 font-mono text-xs text-brand-mute border-t border-brand-line pt-4">
                {content.transit}
              </p>
            </aside>
          </div>
        </div>
      </section>

      <section id="seasonal" className="section-tight scroll-mt-24">
        <div className="container-pad">
          <div className="mb-8 max-w-3xl" data-animate="fade-up">
            <p className="eyebrow mb-3">{copy.seasonalEyebrow}</p>
            <h2 className="text-3xl sm:text-4xl font-extrabold">
              {copy.seasonalHead1} <span className="text-gradient">{copy.seasonalHead2}</span>
            </h2>
          </div>
          <div className="grid sm:grid-cols-2 gap-5" data-stagger="100">
            <div
              data-animate="fade-up"
              className="rounded-2xl border border-brand-line bg-bg-elevated p-6"
            >
              <h3 className="font-display text-lg font-bold mb-3">{copy.seasonalCard1}</h3>
              <p className="text-brand-mute leading-relaxed">{content.seasonal}</p>
            </div>
            <div
              data-animate="fade-up"
              className="rounded-2xl border border-brand-line bg-bg-elevated p-6"
            >
              <h3 className="font-display text-lg font-bold mb-3">{copy.seasonalCard2}</h3>
              <p className="text-brand-mute leading-relaxed">{content.access}</p>
            </div>
          </div>
        </div>
      </section>

      <section id="services" className="section-tight scroll-mt-24">
        <div className="container-pad">
          <div className="mb-10 max-w-3xl" data-animate="fade-up">
            <p className="eyebrow mb-3">{f(copy.servicesEyebrow)}</p>
            <h2 className="text-3xl sm:text-4xl font-extrabold">
              {copy.servicesHead1} <span className="text-gradient">{copy.servicesHead2}</span>
            </h2>
          </div>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4" data-stagger="80">
            {SERVICE_ROWS.map((s) => {
              const sc = copy.services[s.slug];
              if (!sc) return null;
              return (
                <a
                  key={s.slug}
                  href={lp(`/c/${city.slug}/${s.slug}`)}
                  className="card-hover group block focus:outline-none focus:ring-2 focus:ring-brand-accent focus:ring-offset-2 focus:ring-offset-bg-primary"
                  data-animate="fade-up"
                  data-card="service"
                  aria-label={fillCity(copy.serviceAria, { ...v, title: sc.title })}
                >
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-brand-accent/15 text-brand-accent mb-4">
                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth={1.8}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-6 w-6"
                      aria-hidden
                    >
                      {ICONS[s.icon]}
                    </svg>
                  </div>
                  <h3 className="font-display text-lg font-bold group-hover:text-brand-accent transition-colors">
                    {sc.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-brand-mute">{sc.desc}</p>
                  <ul className="mt-4 flex flex-wrap gap-1.5">
                    {sc.examples.map((ex) => (
                      <li
                        key={ex}
                        className="rounded-md border border-brand-line bg-bg-primary px-2 py-0.5 font-mono text-[11px] text-brand-mute"
                      >
                        {ex}
                      </li>
                    ))}
                  </ul>
                  <p className="mt-4 font-mono text-[11px] uppercase tracking-widest text-brand-accent">
                    {sc.title.split(' ')[0]} {f(copy.serviceCtaIn)}
                  </p>
                </a>
              );
            })}
          </div>
        </div>
      </section>

      {/* Fixed-price NJ service bundles ("Locked rate — no travel fee") are false for a
          quoted-per-job travel destination — skip for destination cities. */}
      {!destination && <BundlesBlock city={city} />}

      {/* "Real moves in {city}" gallery implies moving-labor service — skip for
          power-washing-only travel destinations. */}
      {!destination && (
        <section className="section-tight">
          <div className="container-pad max-w-5xl">
            <MovePhotoGallery neighborhood={city.name} heading={f(copy.movesHeading)} />
          </div>
        </section>
      )}

      {!destination && (
        <section id="pricing" className="section-tight scroll-mt-24">
          <div className="container-pad max-w-4xl">
            <div data-animate="fade-up">
              <p className="eyebrow mb-3">{f(copy.pricingEyebrow)}</p>
              <h2 className="text-3xl sm:text-4xl font-extrabold mb-5">{copy.pricingHead}</h2>
              <p className="text-lg text-brand-mute">{f(copy.pricingLede)}</p>
              <ul className="mt-7 grid grid-cols-1 sm:grid-cols-2 gap-3" data-stagger="80">
                {['$100', '$300', '$400', '$900'].map((price, i) => (
                  <li
                    key={price}
                    data-animate="fade-up"
                    className="flex items-center justify-between rounded-lg border border-brand-line bg-bg-elevated px-4 py-3"
                  >
                    <span className="font-mono text-sm text-brand-mute">
                      {copy.pricingCombos[i]}
                    </span>
                    <span className="font-display text-xl font-extrabold text-brand-accent">
                      {price}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>
      )}

      <Suspense
        fallback={
          <div
            role="status"
            aria-busy="true"
            className="mx-auto my-8 w-full max-w-4xl animate-pulse rounded-lg border border-brand-line/40 bg-bg-elevated/30"
            style={{ minHeight: '600px' }}
          >
            <span className="sr-only">Loading booking widget…</span>
          </div>
        }
      >
        <Booking />
      </Suspense>

      {!destination && (
        <section id="nearby" className="section-tight scroll-mt-24">
          <div className="container-pad">
            <div className="mb-8 max-w-3xl" data-animate="fade-up">
              <p className="eyebrow mb-3">{copy.nearbyEyebrow}</p>
              <h2 className="text-3xl sm:text-4xl font-extrabold">{f(copy.nearbyHead)}</h2>
              <p className="mt-3 text-brand-mute">{copy.nearbyLede}</p>
            </div>
            <ul className="flex flex-wrap gap-2 text-sm" data-animate="fade-up" data-delay="120">
              {nearby.map((c) => (
                <li key={c.slug}>
                  <a
                    href={lp(`/c/${c.slug}`)}
                    className="inline-flex min-h-[24px] items-center rounded-full border border-brand-line bg-bg-elevated px-3 py-1.5 text-brand-mute transition-all duration-[333ms] hover:-translate-y-0.5 hover:border-brand-accent hover:text-brand-accent"
                  >
                    {c.name}, {c.state}
                  </a>
                </li>
              ))}
              <li>
                <a
                  href={lp('/#coverage')}
                  className="rounded-md border border-brand-accent bg-brand-accent/10 px-3 py-1.5 text-brand-accent hover:bg-brand-accent hover:text-bg-primary transition-colors"
                >
                  {f(copy.nearbySeeAll)}
                </a>
              </li>
            </ul>
          </div>
        </section>
      )}

      <section id="reading" className="section-tight scroll-mt-24">
        <div className="container-pad">
          <div className="mb-8 max-w-3xl" data-animate="fade-up">
            <p className="eyebrow mb-3">{copy.readingEyebrow}</p>
            <h2 className="text-3xl sm:text-4xl font-extrabold">
              {f(copy.readingHead1)} <span className="text-gradient">{copy.readingHead2}</span>
            </h2>
            <p className="mt-3 text-brand-mute">
              {copy.readingLede1}{' '}
              <a href={lp('/blog')} className="text-brand-accent underline-hover">
                {copy.readingArchive}
              </a>
              {copy.readingLede2}
            </p>
          </div>
          <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3" data-stagger="80">
            {relatedPosts.map((p) => (
              <li key={p.slug} className="card" data-animate="fade-up">
                <p className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
                  {p.category} · {p.readMinutes}
                </p>
                <h3 className="mt-2 font-display text-base font-bold leading-snug">
                  <a
                    href={lp(`/blog/${p.slug}`)}
                    className="text-brand-ink underline-hover hover:text-brand-accent"
                  >
                    {p.title}
                  </a>
                </h3>
                <p className="mt-2 text-xs text-brand-mute line-clamp-3">{p.excerpt}</p>
              </li>
            ))}
          </ul>
          <p className="mt-6 text-sm text-brand-mute">
            {copy.crossRefsLabel}{' '}
            <a href={lp('/sources')} className="text-brand-accent underline-hover">
              {copy.crossCite}
            </a>{' '}
            ·{' '}
            <a href={lp('/#about')} className="text-brand-accent underline-hover">
              {copy.crossMeetBrian}
            </a>{' '}
            ·{' '}
            <a href={lp('/#testimonials')} className="text-brand-accent underline-hover">
              {copy.crossReviews}
            </a>{' '}
            ·{' '}
            <a href={lp('/#pricing')} className="text-brand-accent underline-hover">
              {copy.crossPricing}
            </a>
            .
          </p>
        </div>
      </section>

      <CityEmailCapture city={city} />

      <section id="faq" className="section-tight scroll-mt-24">
        <div className="container-pad">
          <div className="mb-12 max-w-3xl" data-animate="fade-up">
            <p className="eyebrow mb-3">{copy.faqEyebrow}</p>
            <h2 className="text-3xl sm:text-4xl font-extrabold">
              {f(copy.faqHead1)} <span className="text-gradient">{copy.faqHead2}</span>
            </h2>
            <p className="mt-4 text-lg text-brand-mute">
              {f(copy.faqLede)}{' '}
              <a href={PHONE_TEL_HREF} className="text-brand-accent underline-hover">
                {copy.faqJustCall}
              </a>
              .
            </p>
          </div>
          <div className="grid gap-3 max-w-3xl" data-stagger="60">
            {(cityCopy?.faq ?? []).map((item) => (
              <details key={`local-${item.q}`} className="faq-item" data-animate="fade-up">
                <summary>
                  <span>{item.q}</span>
                </summary>
                <div className="faq-body">{item.a}</div>
              </details>
            ))}
            {faqs(city, distance, content, copy).map((item) => (
              <details key={item.q} className="faq-item" data-animate="fade-up">
                <summary>
                  <span>{item.q}</span>
                </summary>
                <div className="faq-body">{item.a}</div>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className="section-tight">
        <div className="container-pad">
          <div
            data-animate="scale-in"
            className="relative overflow-hidden rounded-2xl border border-brand-line bg-bg-elevated"
          >
            <img
              src={imgSrc}
              alt=""
              aria-hidden
              width={1200}
              height={900}
              loading="lazy"
              decoding="async"
              className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-30"
            />
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-bg-primary via-bg-primary/90 to-bg-primary/40" />
            <div className="relative z-10 px-6 py-12 sm:px-12 sm:py-16 max-w-3xl">
              <p className="eyebrow mb-3">{copy.finalEyebrow}</p>
              <h2 className="text-3xl sm:text-4xl font-extrabold">{f(copy.finalHead)}</h2>
              <p className="mt-4 text-lg text-brand-mute">
                {destination
                  ? `Tell us the ${city.name} project — surfaces, area, and access — and we'll confirm the date, scope, and price, then bring the crew to you.`
                  : f(copy.finalLede)}
              </p>
              <div className="relative z-10 mt-7 flex flex-col sm:flex-row gap-3">
                <a
                  href={lp('/book')}
                  data-bcl-action="booking_click"
                  data-bcl-city={city.slug}
                  data-bcl-surface="footer-cta"
                  className="btn-primary text-base relative z-10"
                >
                  {copy.finalBook}
                </a>
                <a
                  href={PHONE_TEL_HREF}
                  data-bcl-action="phone_click"
                  data-bcl-city={city.slug}
                  data-bcl-surface="footer-cta"
                  className="btn-ghost text-base relative z-10"
                >
                  {copy.ctaCall}
                </a>
              </div>
            </div>
          </div>
          <DashboardCallout
            source={`city-${city.slug}`}
            context={`a ${city.name} crew`}
            className="mt-8"
          />
        </div>
      </section>

      <AuthorityDossierTail dossier={cityDossier} />

      <StickyMobileCta city={city} />

      <JsonLd
        data={homeServicesBusiness({
          id: `https://bricklabor.com/c/${city.slug}#org`,
          url: `https://bricklabor.com/c/${city.slug}`,
          name: `Brick Labor — ${city.name}, ${city.state}`,
          description: destination
            ? `Brick Labor travels to ${city.name}, ${city.state} for scheduled power-washing projects — the same crew and least-aggressive-effective-method process, booked ahead.`
            : `Newark-based hourly property crew serving ${city.name}, ${city.state} at $50/hr per person.`,
          areaServed: [{ type: 'City', name: `${city.name}, ${city.state}` }],
          includeAddress: false,
          geo: { latitude: city.lat, longitude: city.lng },
          parentOrgId: 'https://bricklabor.com/#org',
        })}
      />
      <JsonLd
        data={faqPage(
          faqs(city, distance, content, copy).map((f) => ({
            q: f.q,
            a: typeof f.a === 'string' ? f.a : reactNodeToText(f.a),
          })),
        )}
      />
      <JsonLd data={personBrian()} />
    </>
  );
}

/** Best-effort flatten of inline ReactNode FAQ answers to plain text. */
function reactNodeToText(node: ReactNode): string {
  if (node === null || node === undefined || typeof node === 'boolean') return '';
  if (typeof node === 'string' || typeof node === 'number') return String(node);
  if (Array.isArray(node)) return node.map(reactNodeToText).join('');
  if (typeof node === 'object' && 'props' in node) {
    const props = (node as { props?: { children?: ReactNode } }).props;
    return reactNodeToText(props?.children);
  }
  return '';
}

function cleanTitle(title: string): string {
  return title
    .replace(/^File:/, '')
    .replace(/\.(jpe?g|png)$/i, '')
    .replace(/_/g, ' ');
}

function truncate(s: string, n: number): string {
  if (s.length <= n) return s;
  return s.slice(0, n - 1).trimEnd() + '…';
}

function faqs(
  city: City,
  distance: number,
  content: CityContent,
  copy: CityPageCopy,
): Array<{ q: string; a: ReactNode }> {
  const neighborhoodList = content.neighborhoods.length
    ? content.neighborhoods.slice(0, 4).join(', ')
    : `every part of ${city.name}`;
  const topJobs = content.jobs.length
    ? content.jobs.slice(0, 3).join(', ').toLowerCase()
    : 'standard property work';
  // Data-woven FAQ items stay inline — their answers embed per-city
  // `city-content` prose (transit/jobs/seasonal/access), the bigger per-city
  // translation frontier, so they render English on es/pt for now.
  const woven: Array<{ q: string; a: ReactNode }> = [
    {
      q: `Which ${city.name} neighborhoods do you serve?`,
      a: (
        <>
          All of them — {neighborhoodList}
          {content.neighborhoods.length > 4 ? ', and the rest' : ''}.{' '}
          {isDestinationCity(city)
            ? 'Power washing here is scheduled project work, quoted per job before we travel.'
            : 'Same flat $50/hr rate citywide, no zone surcharge, no minimum-distance pricing scam.'}{' '}
          {content.transit}
        </>
      ),
    },
    {
      q: `What kind of jobs do you do most in ${city.name}?`,
      a: (
        <>
          The pattern here: {topJobs}. {content.jobsParagraph} Pick what you need from the
          four-service list above; we bring the gear and the crew.
        </>
      ),
    },
    {
      q: `When's the best time to book a ${city.name} crew?`,
      a: (
        <>
          {content.seasonal} Book early for spring rinse and fall leaf cleanup — calendar fills 1–2
          weeks ahead in peak season.
        </>
      ),
    },
    {
      q: `How do you handle parking in ${city.name}?`,
      a: <>{content.access} Tell us at booking and we plan around it.</>,
    },
    {
      q: isDestinationCity(city)
        ? `How does travel to ${city.name} work?`
        : isHomeBase(distance)
          ? `Is there a travel fee within Newark?`
          : `Is there a travel fee from Newark to ${city.name}?`,
      a: isDestinationCity(city) ? (
        <>
          {city.name} is about {distance} mi from our Newark base, so power washing here is booked
          as a scheduled project — we confirm the date, scope, and price up front, travel included,
          before the crew rolls. No same-day dispatch, no surprise line items.
        </>
      ) : (
        <>
          No travel fee. Same flat $50/hr per person inside our NJ + NYC coverage area. {city.name}{' '}
          is{' '}
          <strong className="text-brand-ink">
            {isHomeBase(distance) ? 'our home base' : `${distance} mi from Newark`}
          </strong>{' '}
          — already covered. We eat the gas, you pay only for hands on the job.
        </>
      ),
    },
  ];
  // Content-free FAQ items come from the locale bundle (en/es/pt), so a Spanish
  // or Portuguese visitor reads payment/gear/rain/insured/cancel answers in
  // their own language — the highest-value objection-handling block.
  const universal = copy.faqItems
    // The same-day / weekend-slot answer ("same-day is often available") is a
    // local same-day-dispatch claim — false for a scheduled travel city like DC.
    .filter((it) => !isDestinationCity(city) || !/same-day|same day|weekend slot/i.test(it.q))
    .map((it) => ({
      q: fillCity(it.q, { city: city.name }),
      a: fillCity(it.a, { city: city.name }) as ReactNode,
    }));
  return [...woven, ...universal];
}

function formatPop(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${Math.round(n / 1_000)}K`;
  return String(n);
}

function setMeta(name: string, content: string) {
  let el = document.querySelector<HTMLMetaElement>(`meta[name="${name}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute('name', name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function setLink(rel: string, href: string) {
  let el = document.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', rel);
    document.head.appendChild(el);
  }
  el.setAttribute('href', href);
}

function NotFound() {
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const lp = (path: string): string => localizedPath(locale, path);
  return (
    <article className="section">
      <div className="container-pad max-w-xl">
        <p className="eyebrow mb-3">404</p>
        <h1 className="text-3xl font-extrabold">City not found</h1>
        <p className="mt-3 text-brand-mute">
          We couldn't find that city. Check the{' '}
          <a href={lp('/#coverage')} className="text-brand-accent underline-hover">
            full service area
          </a>{' '}
          or head{' '}
          <a href={lp('/')} className="text-brand-accent underline-hover">
            home
          </a>
          .
        </p>
      </div>
    </article>
  );
}
