import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect, useState } from 'react';
import { PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';

// Wave 2B — public claims-board page rendered at /claims.
// Fetches /api/claims-board for fully anonymized aggregate stats:
//   open/closed claim counts, median response time, resolution rate,
//   per-crew safety scores (slugs only — no names).
// No PII ever leaves the worker; the page is safe to index.

const TITLE = 'Claims Board — Brick Labor';
const DESC =
  'Live, anonymized snapshot of every claim filed against Brick Labor crews: open count, resolution rate, median response time, and per-crew safety scores.';

interface CrewSafetyScore {
  crewSlug: string;
  score: number;
  jobsAnalyzed: number;
}

interface BoardPayload {
  openCount: number;
  closedCount: number;
  medianResponseHours: number | null;
  resolutionRatePct: number;
  perCrewSafetyScores: CrewSafetyScore[];
  asOf: string;
}

export function ClaimsBoard() {
  useThemeToolsSurface('claims-board');
  const [board, setBoard] = useState<BoardPayload | null>(null);
  const [error, setError] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    document.title = TITLE;
    setMeta('description', DESC);
    setLink('canonical', 'https://bricklabor.com/claims');
  }, []);

  useEffect(() => {
    let stopped = false;
    const controller = new AbortController();
    fetch('/api/claims-board', {
      headers: { Accept: 'application/json' },
      signal: controller.signal,
    })
      .then(async (res) => {
        if (stopped) return;
        if (!res.ok) {
          setError('Claims board is briefly unavailable. Check back in a moment.');
          return;
        }
        const json = (await res.json()) as { ok?: boolean; board?: BoardPayload };
        if (!json.ok || !json.board) {
          setError('Claims board returned an unexpected response.');
          return;
        }
        setBoard(json.board);
      })
      .catch(() => {
        if (!stopped && !controller.signal.aborted) setError('Network issue loading the claims board.');
      })
      .finally(() => {
        if (!stopped) setLoading(false);
      });
    return () => {
      stopped = true;
      controller.abort();
    };
  }, []);

  return (
    <article className="section" data-testid="claims-board">
      <div className="container-pad max-w-4xl">
        <p className="eyebrow mb-3">Public dashboard</p>
        <h1 className="text-4xl sm:text-5xl font-extrabold mb-3">Claims board</h1>
        <p className="text-brand-mute text-base mb-8 max-w-2xl">
          Every claim filed against a Brick Labor crew — open, closed, and how long it took us
          to respond. Fully anonymized. Refreshes when the page loads.
        </p>

        {loading && <p className="text-brand-mute" role="status">Loading…</p>}

        {error && (
          <div role="alert" className="rounded-lg border border-red-500/40 bg-red-500/10 p-4 text-red-200">
            {error}
          </div>
        )}

        {board && (
          <div className="space-y-10">
            <section
              aria-label="Headline metrics"
              className="grid grid-cols-2 lg:grid-cols-4 gap-3"
            >
              <Metric label="Open claims" value={board.openCount.toString()} tone="amber" />
              <Metric label="Closed claims" value={board.closedCount.toString()} tone="emerald" />
              <Metric
                label="Median response"
                value={
                  board.medianResponseHours === null
                    ? '—'
                    : `${board.medianResponseHours.toFixed(1)}h`
                }
                tone="accent"
              />
              <Metric label="Resolution rate" value={`${board.resolutionRatePct}%`} tone="accent" />
            </section>

            <section aria-label="Per-crew safety scores">
              <h2 className="text-2xl font-extrabold text-brand-ink mb-3">Crew safety scores</h2>
              <p className="text-brand-mute text-sm mb-4 max-w-2xl">
                Scored 0–100 based on no-show rate and severe-incident rate over completed gigs.
                Crews are shown by anonymized slug — names never leave our servers.
              </p>
              {board.perCrewSafetyScores.length === 0 ? (
                <p className="text-brand-mute text-sm">
                  No crew has enough completed gigs to score yet — minimum 3 jobs required.
                </p>
              ) : (
                <ul className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {board.perCrewSafetyScores.map((score) => (
                    <li
                      key={score.crewSlug}
                      data-testid="crew-safety-row"
                      className="rounded-lg border border-brand-line bg-brand-card p-4 flex items-center justify-between gap-4"
                    >
                      <div>
                        <p className="font-mono text-xs uppercase tracking-wider text-brand-accent">
                          {score.crewSlug}
                        </p>
                        <p className="text-brand-mute text-xs mt-1">
                          {score.jobsAnalyzed} job{score.jobsAnalyzed === 1 ? '' : 's'}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className={`text-3xl font-extrabold ${scoreColor(score.score)}`}>
                          {score.score}
                        </p>
                        <p className="text-brand-mute text-xs">/ 100</p>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </section>

            <section
              aria-label="How this works"
              className="rounded-lg border border-brand-line bg-bg-elevated/40 p-5 text-sm text-brand-mute space-y-2"
            >
              <h2 className="font-display font-bold text-brand-ink mb-1">How this works</h2>
              <p>
                Customers and crew can file a claim through the{' '}
                <a href="/track" className="text-brand-accent underline-hover">
                  booking tracker
                </a>{' '}
                or by texting the owner at{' '}
                <a href={PHONE_TEL_HREF} className="text-brand-accent underline-hover">
                  (855) 82LABOR
                </a>
                . Every claim lands in our incidents queue and gets a written response from
                ownership.
              </p>
              <p>
                Read the{' '}
                <a href="/terms" className="text-brand-accent underline-hover">
                  damage protection terms
                </a>
                ,{' '}
                <a href="/tcpa" className="text-brand-accent underline-hover">
                  SMS policy
                </a>
                , and{' '}
                <a href="/privacy" className="text-brand-accent underline-hover">
                  privacy policy
                </a>{' '}
                for the full picture.
              </p>
              <p className="text-brand-mute/80 text-xs">
                Snapshot generated {formatDateTime(board.asOf)}.
              </p>
            </section>
          </div>
        )}
      </div>
    </article>
  );
}

function Metric({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone: 'amber' | 'emerald' | 'accent';
}) {
  const toneClass =
    tone === 'amber'
      ? 'border-amber-500/40 bg-amber-500/5 text-amber-200'
      : tone === 'emerald'
        ? 'border-emerald-500/40 bg-emerald-500/5 text-emerald-200'
        : 'border-brand-accent/40 bg-brand-accent/5 text-brand-accent';
  return (
    <div className={`rounded-lg border p-4 ${toneClass}`}>
      <p className="text-xs uppercase tracking-wider opacity-80">{label}</p>
      <p className="text-3xl font-extrabold mt-1">{value}</p>
    </div>
  );
}

function scoreColor(score: number): string {
  if (score >= 90) return 'text-emerald-300';
  if (score >= 75) return 'text-amber-200';
  return 'text-red-300';
}

function formatDateTime(iso: string): string {
  const dt = new Date(iso);
  if (Number.isNaN(dt.getTime())) return iso;
  return dt.toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  });
}

function setMeta(name: string, content: string) {
  let el = document.querySelector<HTMLMetaElement>(`meta[name="${name}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute('name', name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function setLink(rel: string, href: string) {
  let el = document.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', rel);
    document.head.appendChild(el);
  }
  el.setAttribute('href', href);
}
