import { useEffect, useState } from 'react';
import {
  ThemeToolsPageSurface,
  useThemeToolsSurface,
} from '../../field-service-primitives.js';
import type { PageReferenceCitation } from '@theme.tools/seo-geo/field-service/matrix-3d-engine';

export interface CollapsibleCitationsDrawerProps {
  readonly references: readonly PageReferenceCitation[];
  readonly townName?: string;
  readonly defaultOpen?: boolean;
  readonly bookingUrl?: string;
}

type CitationCategory = 'all' | 'local' | 'care' | 'pricing';

function classifyCitation(ref: PageReferenceCitation): Exclude<CitationCategory, 'all'> {
  const hay = `${ref.code} ${ref.sourceTitle} ${ref.publisherOrInstitution}`.toLowerCase();
  if (hay.includes('wiki') || hay.includes('census') || hay.includes('muni')) {
    return 'local';
  }
  if (hay.includes('dca') || hay.includes('bcl') || hay.includes('dfseo') || hay.includes('rate')) {
    return 'pricing';
  }
  return 'care';
}

function categoryBadgeLabel(cat: Exclude<CitationCategory, 'all'>): {
  readonly label: string;
  readonly className: string;
} {
  switch (cat) {
    case 'local':
      return {
        label: 'Local & Architectural',
        className: 'border-sky-400/35 bg-sky-400/10 text-sky-300',
      };
    case 'pricing':
      return {
        label: 'Pricing & Consumer Standard',
        className: 'border-emerald-400/35 bg-emerald-400/10 text-emerald-300',
      };
    case 'care':
      return {
        label: 'Surface Care & Safety',
        className: 'border-brand-accent/40 bg-brand-accent/12 text-brand-accent',
      };
  }
}

/**
 * Universal Collapsed-by-Default Citations & Reference Bibliography Drawer
 * (`@theme.tools/ui/field-service/components/CollapsibleCitationsDrawer`).
 *
 * Designed to appear at the bottom of every content-rich landing page, city guide,
 * and blog article. Loads collapsed by default for a clean editorial flow, and
 * expands into a magazine-grade interactive table of verified references.
 */
export function CollapsibleCitationsDrawer({
  references,
  townName = 'Newark',
  defaultOpen = false,
  bookingUrl = 'https://bricklabor.com/book',
}: CollapsibleCitationsDrawerProps) {
  const ttSurface = useThemeToolsSurface('collapsible-citations-drawer');
  const [isOpen, setIsOpen] = useState(defaultOpen);
  const [filter, setFilter] = useState<CitationCategory>('all');

  // Auto-open when visitor navigates to #references or #ref-<n>
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const checkHash = () => {
      const h = window.location.hash;
      if (h === '#references' || /^#ref-\d+$/.test(h)) {
        setIsOpen(true);
      }
    };
    checkHash();
    window.addEventListener('hashchange', checkHash);
    return () => window.removeEventListener('hashchange', checkHash);
  }, []);

  const filteredRefs = references.filter((r) =>
    filter === 'all' ? true : classifyCitation(r) === filter,
  );

  return (
    <ThemeToolsPageSurface
      surface="collapsible-citations-drawer"
      id="references"
      className="my-10"
      {...ttSurface.dataAttributes}
    >
      <details
        data-testid="collapsible-citations-drawer"
        open={isOpen}
        onToggle={(e) => setIsOpen((e.currentTarget as HTMLDetailsElement).open)}
        className="group overflow-hidden rounded-2xl border border-white/12 bg-[#0d121a] shadow-[0_24px_60px_-28px_rgba(0,0,0,0.85)] transition-all duration-300 hover:border-brand-accent/50"
      >
        <summary
          data-testid="collapsible-citations-summary"
          className="flex cursor-pointer list-none flex-col sm:flex-row sm:items-center justify-between gap-4 px-6 py-5 sm:px-8 sm:py-6 select-none"
        >
          <div className="flex flex-1 min-w-0 items-start sm:items-center gap-4">
            <span className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl border border-brand-accent/40 bg-brand-accent/12 font-mono text-xs font-extrabold text-brand-accent shadow-inner">
              [1–{references.length}]
            </span>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-mono text-[11px] uppercase tracking-[0.18em] text-brand-accent">
                  VERIFIED EDITORIAL BIBLIOGRAPHY · {townName.toUpperCase()} GUIDE
                </span>
                <span className="tt-badge tt-badge--emerald text-[10px]">
                  ✓ Fact-Checked
                </span>
              </div>
              <h2 className="mt-1 font-display text-lg sm:text-xl font-extrabold text-brand-ink">
                Sources, References &amp; Editorial Citations ({references.length})
              </h2>
              <p className="mt-0.5 text-xs sm:text-sm text-brand-mute leading-relaxed">
                Collapsed by default — click to view the {references.length} primary municipal, historical masonry, safety, and pricing sources cited in this guide.
              </p>
            </div>
          </div>

          <div className="flex shrink-0 items-center gap-3">
            <span className="hidden sm:inline-flex items-center gap-1.5 rounded-full border border-brand-line bg-bg-primary/80 px-3 py-1.5 font-mono text-[11px] text-brand-mute">
              <span>{references.length} Primary Sources</span>
            </span>
            <span className="inline-flex items-center gap-2 rounded-full border border-brand-accent/40 bg-brand-accent/15 px-4 py-2 font-mono text-xs font-bold text-brand-accent transition-transform">
              <span>{isOpen ? 'Hide Sources' : 'View Citations'}</span>
              <span
                aria-hidden="true"
                className={`inline-block transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}
              >
                ▼
              </span>
            </span>
          </div>
        </summary>

        <div
          data-testid="page-reference-chart"
          aria-label="Cited Sources and Reference Chart"
          className="border-t border-brand-line bg-bg-primary/60 px-6 py-6 sm:px-8 sm:py-8 space-y-6"
        >
          {/* Top Filter Bar & Trust Summary */}
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-2" role="tablist" aria-label="Filter citations by category">
              {(
                [
                  { id: 'all', label: `All Sources (${references.length})` },
                  { id: 'local', label: 'Local & Architecture' },
                  { id: 'care', label: 'Surface Care & Safety' },
                  { id: 'pricing', label: 'Pricing & Consumer' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  role="tab"
                  aria-selected={filter === tab.id}
                  onClick={() => setFilter(tab.id)}
                  className={`rounded-full border px-3.5 py-1.5 font-mono text-xs font-semibold transition-all ${
                    filter === tab.id
                      ? 'border-brand-accent bg-brand-accent text-bg-primary shadow-sm'
                      : 'border-brand-line bg-bg-elevated text-brand-mute hover:border-brand-accent/50 hover:text-brand-ink'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <a
              href={bookingUrl}
              data-testid="reference-chart-book-cta"
              className="tt-btn tt-btn--primary rounded-xl bg-brand-accent px-4 py-2 font-mono text-xs font-extrabold uppercase tracking-wider text-bg-primary hover:opacity-90"
            >
              Book {townName} Crew ($50/hr) →
            </a>
          </div>

          {/* Gorgeous Reference Table */}
          <div className="overflow-x-auto rounded-2xl border border-brand-line bg-bg-elevated/90 shadow-inner">
            <table className="w-full border-collapse text-left text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-brand-line bg-bg-primary/70 font-mono text-[11px] uppercase tracking-wider text-brand-mute">
                  <th className="py-3.5 pl-4 pr-3">Ref</th>
                  <th className="py-3.5 px-3">Source &amp; Category</th>
                  <th className="py-3.5 px-3">Publisher / Institution</th>
                  <th className="py-3.5 px-3">What This Source Verifies</th>
                  <th className="py-3.5 pl-3 pr-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-brand-line/60">
                {references.map((ref) => {
                  const cat = classifyCitation(ref);
                  const badge = categoryBadgeLabel(cat);
                  const isVisible = filter === 'all' || filter === cat;
                  return (
                    <tr
                      key={ref.code}
                      id={`ref-${ref.index}`}
                      data-testid="reference-chart-row"
                      style={isVisible ? undefined : { display: 'none' }}
                      className="group/row transition-colors hover:bg-brand-accent/[0.06]"
                    >
                      <td className="py-4 pl-4 pr-3 align-top whitespace-nowrap">
                        <span className="inline-flex h-7 w-9 items-center justify-center rounded-lg border border-brand-accent/40 bg-brand-accent/15 font-mono text-xs font-extrabold text-brand-accent">
                          [{ref.index}]
                        </span>
                      </td>
                      <td className="py-4 px-3 align-top">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <span
                            className={`inline-flex items-center rounded-full border px-2 py-0.5 font-mono text-[10px] font-semibold ${badge.className}`}
                          >
                            {badge.label}
                          </span>
                          <span className="font-mono text-[10px] text-brand-mute">
                            {ref.publicationYear} · Verified {ref.verificationDate}
                          </span>
                        </div>
                        <p className="font-display text-sm font-bold text-brand-ink leading-snug">
                          {ref.sourceTitle}
                        </p>
                      </td>
                      <td className="py-4 px-3 align-top text-xs text-brand-mute">
                        <span className="font-semibold text-brand-ink/90 block">
                          {ref.publisherOrInstitution}
                        </span>
                        <span className="font-mono text-[10px] text-brand-mute/80">
                          Code: {ref.code}
                        </span>
                      </td>
                      <td className="py-4 px-3 align-top text-xs sm:text-sm text-brand-mute leading-relaxed max-w-md">
                        {ref.domainFactCited}
                      </td>
                      <td className="py-4 pl-3 pr-4 align-top text-right whitespace-nowrap">
                        <a
                          href={ref.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 rounded-xl border border-brand-line bg-bg-primary px-3 py-1.5 font-mono text-xs font-bold text-brand-accent transition-colors hover:border-brand-accent hover:bg-brand-accent hover:text-bg-primary"
                        >
                          <span>Source</span>
                          <span aria-hidden="true">↗</span>
                        </a>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono text-brand-mute pt-1">
            <span>
              All facts, municipal codes, and pricing benchmarks are reviewed quarterly by Brick Labor Newark Operations.
            </span>
            <a href="/sources" className="text-brand-accent hover:underline">
              Explore Full Brick Labor Research Library →
            </a>
          </div>
        </div>
      </details>
    </ThemeToolsPageSurface>
  );
}

export default CollapsibleCitationsDrawer;
