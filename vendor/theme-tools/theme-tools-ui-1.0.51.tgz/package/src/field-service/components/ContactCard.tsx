import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useState, type FormEvent } from 'react';
import {
  PHONE_TEL_HREF,
  PHONE_SMS_HREF,
  PHONE_WA_HREF,
  PHONE_DISPLAY,
} from '@theme.tools/i18n-a11y/field-service/contact-phone';

// Compact contact card for the /contact page. The reach-us methods (call, text,
// email, WhatsApp, Instagram, Facebook) are tight icon chips + logo buttons in a
// single wrapping row, plus a small three-field message form (→ /api/contact,
// mailto fallback). Self-contained — renders below the chat without touching it.

const EMAIL = 'hey@bricklabor.com';
const IG_URL = 'https://instagram.com/brickcitylabor';
const FB_URL = 'https://facebook.com/brickcitylabor';

type Status = 'idle' | 'sending' | 'sent' | 'error';

const CHIP =
  'group inline-flex items-center gap-1.5 rounded-full border border-brand-line bg-bg-primary/50 px-2.5 py-1.5 text-[13px] font-semibold text-brand-ink transition-all duration-200 hover:-translate-y-0.5 hover:border-brand-accent hover:bg-brand-accent/10 hover:text-brand-accent hover:shadow-[0_6px_16px_-8px_rgba(255,107,26,0.5)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent motion-reduce:hover:transform-none';
const ICON_CHIP =
  'inline-flex h-[38px] w-[38px] items-center justify-center rounded-full border border-brand-line text-brand-mute transition-all duration-200 hover:-translate-y-0.5 hover:border-brand-accent hover:bg-brand-accent/10 hover:text-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent motion-reduce:hover:transform-none';

export function ContactCard() {
  useThemeToolsSurface('contact-card');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState<Status>('idle');

  const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim());
  const canSend = name.trim().length >= 2 && emailValid && message.trim().length >= 4;

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!canSend) {
      setStatus('error');
      return;
    }
    setStatus('sending');
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          email: email.trim(),
          message: message.trim(),
          source: 'contact-card',
        }),
      });
      if (!res.ok) throw new Error('failed');
      setStatus('sent');
      setName('');
      setEmail('');
      setMessage('');
    } catch {
      const subject = encodeURIComponent(`Website message from ${name.trim() || 'a customer'}`);
      const body = encodeURIComponent(`${message.trim()}\n\n— ${name.trim()} (${email.trim()})`);
      window.location.href = `mailto:${EMAIL}?subject=${subject}&body=${body}`;
      setStatus('idle');
    }
  };

  return (
    <section
      aria-label="Contact Brick Labor"
      data-testid="contact-card"
      className="card relative mt-4 overflow-hidden !p-4"
    >
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-0.5 bg-gradient-to-r from-transparent via-brand-accent/70 to-transparent"
        aria-hidden
      />
      <div
        className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full bg-brand-accent/10 blur-3xl"
        aria-hidden
      />
      <p className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
        Reach us directly
      </p>
      <p className="mt-1 text-sm text-brand-mute">
        Call or text <span className="font-semibold text-brand-ink">{PHONE_DISPLAY}</span> — or drop
        a quick note, we reply same day.
      </p>

      {/* Compact reach-us chips — one tight wrapping row */}
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <a href={PHONE_TEL_HREF} className={CHIP} data-bcl-cta="contact-card-call">
          <svg viewBox="0 0 24 24" className="h-4 w-4 text-brand-accent" fill="currentColor" aria-hidden>
            <path d="M6.6 10.8c1.4 2.8 3.8 5.2 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.2.4 2.4.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1C10.6 21 3 13.4 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.4 0 .8-.3 1l-2.2 2.2z" />
          </svg>
          Call
        </a>
        <a href={PHONE_SMS_HREF} className={CHIP} data-bcl-cta="contact-card-text">
          <svg viewBox="0 0 24 24" className="h-4 w-4 text-brand-accent" fill="currentColor" aria-hidden>
            <path d="M4 4h16a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1H8l-4 4V5a1 1 0 0 1 1-1zm3 5v2h10V9H7zm0 3.5V14h7v-1.5H7z" />
          </svg>
          Text
        </a>
        <a href={`mailto:${EMAIL}`} className={CHIP} data-bcl-cta="contact-card-email">
          <svg viewBox="0 0 24 24" className="h-4 w-4 text-brand-accent" fill="currentColor" aria-hidden>
            <path d="M3 5h18a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1zm9 7L4.5 7h15L12 12zm0 2.2L4 8.8V17h16V8.8l-8 5.4z" />
          </svg>
          Email
        </a>
        <a
          href={PHONE_WA_HREF}
          target="_blank"
          rel="noopener noreferrer"
          className={CHIP}
          data-bcl-cta="contact-card-whatsapp"
        >
          <svg viewBox="0 0 24 24" className="h-4 w-4 text-brand-accent" fill="currentColor" aria-hidden>
            <path d="M12 2a10 10 0 0 0-8.6 15l-1.3 4.7 4.8-1.3A10 10 0 1 0 12 2zm5.8 14.2c-.2.7-1.2 1.3-1.7 1.3-.4.1-1 .1-1.6-.1-.4-.1-.9-.3-1.5-.6-2.6-1.1-4.3-3.8-4.4-4-.1-.2-1-1.4-1-2.6s.6-1.8.9-2.1c.2-.2.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 1.9c.1.2.1.3 0 .5l-.4.6-.3.3c-.1.1-.2.3-.1.5.1.2.6 1 1.4 1.7 1 .8 1.7 1 1.9 1.1.2.1.4.1.5-.1l.7-.8c.2-.2.4-.2.6-.1l1.8.9c.2.1.4.2.5.3.1.2.1.7-.1 1.5z" />
          </svg>
          WhatsApp
        </a>
        <span className="mx-0.5 h-5 w-px bg-brand-line" aria-hidden />
        <a
          href={IG_URL}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Brick Labor on Instagram"
          data-bcl-cta="contact-card-instagram"
          className={ICON_CHIP}
        >
          <svg viewBox="0 0 24 24" className="h-[18px] w-[18px]" fill="currentColor" aria-hidden>
            <path d="M12 2.2c3.2 0 3.6 0 4.9.1 1.2.1 1.8.3 2.2.4.6.2 1 .5 1.4.9.4.4.7.8.9 1.4.2.4.4 1 .4 2.2.1 1.3.1 1.7.1 4.9s0 3.6-.1 4.9c-.1 1.2-.3 1.8-.4 2.2-.2.6-.5 1-.9 1.4-.4.4-.8.7-1.4.9-.4.2-1 .4-2.2.4-1.3.1-1.7.1-4.9.1s-3.6 0-4.9-.1c-1.2-.1-1.8-.3-2.2-.4a3.6 3.6 0 0 1-1.4-.9 3.6 3.6 0 0 1-.9-1.4c-.2-.4-.4-1-.4-2.2C2.2 15.6 2.2 15.2 2.2 12s0-3.6.1-4.9c.1-1.2.3-1.8.4-2.2.2-.6.5-1 .9-1.4.4-.4.8-.7 1.4-.9.4-.2 1-.4 2.2-.4C8.4 2.2 8.8 2.2 12 2.2zm0 1.8c-3.1 0-3.5 0-4.7.1-1.1.1-1.7.2-2.1.4-.5.2-.9.4-1.3.8-.4.4-.6.8-.8 1.3-.2.4-.3 1-.4 2.1C2.6 9.5 2.6 9.9 2.6 12s0 2.5.1 3.3c.1 1.1.2 1.7.4 2.1.2.5.4.9.8 1.3.4.4.8.6 1.3.8.4.2 1 .3 2.1.4 1.2.1 1.6.1 4.7.1s3.5 0 4.7-.1c1.1-.1 1.7-.2 2.1-.4.5-.2.9-.4 1.3-.8.4-.4.6-.8.8-1.3.2-.4.3-1 .4-2.1.1-1.2.1-1.6.1-4.7s0-2.5-.1-3.3c-.1-1.1-.2-1.7-.4-2.1a3.5 3.5 0 0 0-.8-1.3 3.5 3.5 0 0 0-1.3-.8c-.4-.2-1-.3-2.1-.4C15.5 4 15.1 4 12 4zm0 3.1a4.9 4.9 0 1 1 0 9.8 4.9 4.9 0 0 1 0-9.8zm0 8.1a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4zm6.3-8.3a1.15 1.15 0 1 1-2.3 0 1.15 1.15 0 0 1 2.3 0z" />
          </svg>
        </a>
        <a
          href={FB_URL}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Brick Labor on Facebook"
          data-bcl-cta="contact-card-facebook"
          className={ICON_CHIP}
        >
          <svg viewBox="0 0 24 24" className="h-[18px] w-[18px]" fill="currentColor" aria-hidden>
            <path d="M13.5 21v-8h2.7l.4-3.1h-3.1V7.9c0-.9.3-1.5 1.6-1.5h1.7V3.6c-.3 0-1.3-.1-2.5-.1-2.4 0-4.1 1.5-4.1 4.2v2.3H7.4V13h2.3v8h3.8z" />
          </svg>
        </a>
      </div>

      <form onSubmit={submit} className="mt-3.5 space-y-2 border-t border-brand-line/70 pt-3.5" noValidate>
        <p className="text-sm font-semibold text-brand-ink">Send a quick message</p>
        <div className="grid gap-2.5 sm:grid-cols-2">
          <input
            className="input !min-h-[40px] !py-1.5 !text-sm"
            placeholder="Your name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            aria-label="Your name"
            autoComplete="name"
          />
          <input
            className="input !min-h-[40px] !py-1.5 !text-sm"
            placeholder="you@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            aria-label="Your email"
            type="email"
            autoComplete="email"
            inputMode="email"
          />
        </div>
        <textarea
          className="input !min-h-[56px] !py-1.5 !text-sm"
          placeholder="What do you need done? (a sentence is plenty)"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          aria-label="Your message"
          rows={3}
        />
        <div className="flex flex-wrap items-center gap-3">
          <button
            type="submit"
            disabled={status === 'sending'}
            data-testid="contact-card-submit"
            className="btn-primary !py-2 !text-sm disabled:opacity-50"
          >
            {status === 'sending' ? 'Sending…' : status === 'sent' ? 'Sent ✓' : 'Send message'}
          </button>
          {status === 'sent' && (
            <span role="status" className="text-xs text-emerald-300">
              Got it — we’ll reply to your email same day.
            </span>
          )}
          {status === 'error' && (
            <span role="alert" className="text-xs text-red-300">
              Add your name, a valid email, and a short message.
            </span>
          )}
        </div>
      </form>
    </section>
  );
}
