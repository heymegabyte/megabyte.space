import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useState, useRef, useCallback, useEffect, useId } from 'react';
import { TurnstileWidget } from './TurnstileWidget.js';
import { useMicrophone } from '../use-microphone.js';
import { MicVisualizer } from './contact/MicVisualizer.js';
import { ContactCard } from './ContactCard.js';

/* ── Types ──────────────────────────────────────────────────────────────── */

type ReplyMethod = 'call' | 'text' | 'email';

type Service =
  | 'Power washing'
  | 'Lawn & yard'
  | 'Hauling'
  | 'Junk & cleanout'
  | 'Light repairs'
  | 'Moving help'
  | 'Something else';

type Timeline = 'ASAP' | 'This week' | 'This month' | 'Just exploring';

type StepId =
  | 'service'
  | 'location'
  | 'photos'
  | 'timeline'
  | 'estimate'
  | 'contact'
  | 'turnstile';

interface MediaItem {
  kind: 'photo';
  filename: string;
  dataUrl: string;
}

interface PhotoPreview {
  id: string;
  objectUrl: string;
  filename: string;
  file: File;
}

interface SuccessPayload {
  ok: true;
  id: string;
}

/* ── Constants ──────────────────────────────────────────────────────────── */

const MAX_BYTES = 20 * 1024 * 1024;

const STEPS: readonly StepId[] = [
  'service',
  'location',
  'photos',
  'timeline',
  'estimate',
  'contact',
  'turnstile',
] as const;

const SERVICES: readonly Service[] = [
  'Power washing',
  'Lawn & yard',
  'Hauling',
  'Junk & cleanout',
  'Light repairs',
  'Moving help',
  'Something else',
] as const;

const TIMELINES: readonly Timeline[] = [
  'ASAP',
  'This week',
  'This month',
  'Just exploring',
] as const;

const REPLY_OPTS: readonly { id: ReplyMethod; label: string; icon: string }[] = [
  { id: 'text', label: 'Text', icon: '💬' },
  { id: 'call', label: 'Call', icon: '📞' },
  { id: 'email', label: 'Email', icon: '✉️' },
] as const;

// Rough ballpark estimate ranges by service
const ESTIMATES: Record<Service, string> = {
  'Power washing': '$180–$500',
  'Lawn & yard': '$120–$350',
  Hauling: '$150–$400',
  'Junk & cleanout': '$200–$600',
  'Light repairs': '$100–$300',
  'Moving help': '$200–$500',
  'Something else': '$100–$500',
};

/* ── Helpers ────────────────────────────────────────────────────────────── */

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

function buildTranscript(opts: {
  readonly service: Service | '';
  readonly location: string;
  readonly timeline: Timeline | '';
  readonly photoCount: number;
  readonly name: string;
  readonly phone: string;
  readonly preferredReply: ReplyMethod;
}): string {
  const parts: string[] = [];
  if (opts.service) parts.push(`Service needed: ${opts.service}`);
  if (opts.location) parts.push(`Location: ${opts.location}`);
  if (opts.photoCount > 0) parts.push(`Photos attached: ${opts.photoCount}`);
  if (opts.timeline) parts.push(`Timeline: ${opts.timeline}`);
  if (opts.name) parts.push(`Name: ${opts.name}`);
  if (opts.phone) parts.push(`Phone: ${opts.phone}`);
  parts.push(`Preferred contact: ${opts.preferredReply}`);
  return parts.join('\n');
}

/* ── Sub-components ─────────────────────────────────────────────────────── */

function TypingIndicator() {
  return (
    <div className="flex items-center gap-1.5 px-4 py-3" aria-label="Assistant is typing" role="status">
      {([0, 1, 2] as const).map((i) => (
        <span
          key={i}
          className="inline-block h-2 w-2 rounded-full bg-brand-accent shadow-[0_0_8px_rgba(255,107,26,0.6)]"
          style={{
            animation: 'bcl-bounce 1.2s ease-in-out infinite',
            animationDelay: `${i * 0.2}s`,
          }}
          aria-hidden="true"
        />
      ))}
    </div>
  );
}

interface AssistantBubbleProps {
  readonly children: React.ReactNode;
  readonly animate?: boolean;
}

function AssistantBubble({ children, animate = true }: AssistantBubbleProps) {
  return (
    <div
      className="flex max-w-[85%] items-start gap-3"
      style={animate ? { animation: 'bcl-bubble-in 0.45s cubic-bezier(0.22,1,0.36,1) both' } : undefined}
    >
      <div
        className="relative shrink-0 flex h-9 w-9 items-center justify-center rounded-full border border-brand-accent/50 bg-gradient-to-br from-brand-accent/25 to-brand-accent/5 font-mono text-[11px] font-bold text-brand-accent shadow-[0_0_16px_-4px_rgba(255,107,26,0.5)]"
        aria-hidden="true"
      >
        BL
      </div>
      <div className="rounded-2xl rounded-tl-md border border-white/10 bg-bg-elevated/60 px-4 py-3 shadow-[0_10px_34px_-14px_rgba(0,0,0,0.7)] ring-1 ring-inset ring-brand-accent/[0.06] backdrop-blur-xl">
        {children}
      </div>
    </div>
  );
}

interface UserBubbleProps {
  readonly children: React.ReactNode;
}

function UserBubble({ children }: UserBubbleProps) {
  return (
    <div
      className="flex justify-end"
      style={{ animation: 'bcl-bubble-in-r 0.4s cubic-bezier(0.22,1,0.36,1) both' }}
    >
      <div className="max-w-[80%] rounded-2xl rounded-tr-md bg-gradient-to-br from-brand-accent to-[#e85d10] px-4 py-3 font-display font-semibold text-bg-primary shadow-[0_10px_30px_-10px_rgba(255,107,26,0.55)] ring-1 ring-inset ring-white/20">
        {children}
      </div>
    </div>
  );
}

interface ChipProps {
  readonly label: string;
  readonly selected?: boolean;
  readonly onClick: () => void;
  readonly icon?: string;
}

function Chip({ label, selected = false, onClick, icon }: ChipProps) {
  return (
    <button
      type="button"
      aria-pressed={selected}
      onClick={onClick}
      className={`group inline-flex min-h-[44px] items-center gap-2 rounded-full border px-4 py-2.5 text-sm font-display font-semibold transition-all duration-300 ease-out will-change-transform hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent focus-visible:ring-offset-2 focus-visible:ring-offset-bg-primary active:translate-y-0 ${
        selected
          ? 'border-brand-accent bg-gradient-to-br from-brand-accent/25 to-brand-accent/10 text-brand-accent shadow-[0_6px_20px_-6px_rgba(255,107,26,0.55)] ring-1 ring-inset ring-brand-accent/30'
          : 'border-brand-line bg-bg-elevated/50 text-brand-ink backdrop-blur-sm hover:border-brand-accent/60 hover:bg-brand-accent/5 hover:text-brand-accent hover:shadow-[0_6px_20px_-10px_rgba(255,107,26,0.4)]'
      }`}
    >
      {icon !== undefined && (
        <span aria-hidden="true" className="text-base transition-transform duration-300 group-hover:scale-110">
          {icon}
        </span>
      )}
      {label}
    </button>
  );
}

interface ProgressBarProps {
  readonly step: number;
  readonly total: number;
}

function ProgressBar({ step, total }: ProgressBarProps) {
  const pct = Math.round((step / total) * 100);
  return (
    <div
      className="relative h-1 w-full overflow-hidden bg-brand-line/50"
      role="progressbar"
      aria-valuenow={pct}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={`Step ${step} of ${total}`}
    >
      <div
        className="relative h-full rounded-r-full bg-gradient-to-r from-[#e85d10] via-brand-accent to-[#ff9a5a] transition-[width] duration-700 ease-out"
        style={{ width: `${Math.max(pct, 4)}%` }}
      >
        {/* moving shine */}
        <span
          aria-hidden="true"
          className="absolute inset-0 opacity-60"
          style={{
            background:
              'linear-gradient(100deg, transparent 20%, rgba(255,255,255,0.55) 50%, transparent 80%)',
            backgroundSize: '220% 100%',
            animation: 'bcl-shimmer 2.4s linear infinite',
          }}
        />
      </div>
    </div>
  );
}

function CSSKeyframes() {
  return (
    <style>{`
      @keyframes bcl-bubble-in {
        from { opacity: 0; transform: translateY(12px) scale(0.96); filter: blur(2px); }
        to   { opacity: 1; transform: none; filter: none; }
      }
      @keyframes bcl-bubble-in-r {
        from { opacity: 0; transform: translateY(12px) scale(0.96); filter: blur(2px); }
        to   { opacity: 1; transform: none; filter: none; }
      }
      @keyframes bcl-bounce {
        0%, 80%, 100% { transform: translateY(0);    opacity: 0.45; }
        40%           { transform: translateY(-6px); opacity: 1;   }
      }
      @keyframes bcl-pulse {
        0%, 100% { opacity: 0.25; transform: scale(1) translateX(-50%); }
        50%      { opacity: 0.40; transform: scale(1.05) translateX(-48%); }
      }
      @keyframes bcl-aurora {
        0%   { transform: translate(-52%, -6%) rotate(0deg) scale(1);    opacity: 0.22; }
        50%  { transform: translate(-48%, 4%) rotate(8deg) scale(1.14);  opacity: 0.34; }
        100% { transform: translate(-52%, -6%) rotate(0deg) scale(1);    opacity: 0.22; }
      }
      @keyframes bcl-aurora-2 {
        0%   { transform: translate(-46%, 8%) scale(1);    opacity: 0.14; }
        50%  { transform: translate(-54%, -6%) scale(1.18); opacity: 0.24; }
        100% { transform: translate(-46%, 8%) scale(1);    opacity: 0.14; }
      }
      @keyframes bcl-shimmer {
        from { background-position: -160% 0; }
        to   { background-position: 260% 0; }
      }
      @keyframes bcl-rise {
        from { opacity: 0; transform: translateY(14px); }
        to   { opacity: 1; transform: none; }
      }
      @keyframes bcl-count-glow {
        0%, 100% { text-shadow: 0 0 0 rgba(255,107,26,0); }
        50%      { text-shadow: 0 0 24px rgba(255,107,26,0.5); }
      }
      @media (prefers-reduced-motion: reduce) {
        [style*="bcl-bubble-in"],
        [style*="bcl-bubble-in-r"],
        [style*="bcl-pulse"],
        [style*="bcl-aurora"],
        [style*="bcl-shimmer"],
        [style*="bcl-rise"],
        [style*="bcl-count-glow"] {
          animation: none !important;
          transition: none !important;
          filter: none !important;
        }
        [style*="bcl-bounce"] {
          animation: none !important;
        }
      }
    `}</style>
  );
}

/* ── Main component ─────────────────────────────────────────────────────── */

export function ContactPage() {
  useThemeToolsSurface('contact-page');
  // Step state machine
  const [stepIndex, setStepIndex] = useState(0);
  const [showTyping, setShowTyping] = useState(false);
  const [revealedSteps, setRevealedSteps] = useState<readonly number[]>([0]);

  // Collected answers
  const [service, setService] = useState<Service | ''>('');
  const [location, setLocation] = useState('');
  const [timeline, setTimeline] = useState<Timeline | ''>('');
  const [photos, setPhotos] = useState<readonly PhotoPreview[]>([]);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [preferredReply, setPreferredReply] = useState<ReplyMethod>('text');
  const [turnstileToken, setTurnstileToken] = useState('');

  // UI state
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [sizeError, setSizeError] = useState('');
  const [success, setSuccess] = useState<SuccessPayload | undefined>(undefined);
  const [dragging, setDragging] = useState(false);
  const [locationInput, setLocationInput] = useState('');

  // Refs
  const fileInputRef = useRef<HTMLInputElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const nameInputRef = useRef<HTMLInputElement>(null);

  // Voice input — dictation flows into whichever free-text field was last focused
  // (defaults to the location field, the first one the flow asks for).
  const voiceTargetRef = useRef<'location' | 'name' | 'email' | 'phone'>('location');
  const appendVoice = useCallback((text: string) => {
    const t = text.trim();
    if (!t) return;
    const join = (prev: string) => (prev ? `${prev} ${t}` : t);
    // If ANY editable input/textarea is focused — the chat fields OR the
    // standalone contact form below (or any future input) — type the transcript
    // straight into THAT element via the native value setter + an input event so
    // React's controlled onChange picks it up. The mic button uses
    // onMouseDown-preventDefault so focus stays on the field while you talk.
    const el = document.activeElement as HTMLInputElement | HTMLTextAreaElement | null;
    if (
      el &&
      (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') &&
      !el.disabled &&
      !el.readOnly
    ) {
      const isEmail =
        el.getAttribute('type') === 'email' || el.getAttribute('inputmode') === 'email';
      const sep = isEmail ? '' : el.value ? ' ' : '';
      const proto =
        el instanceof HTMLTextAreaElement
          ? HTMLTextAreaElement.prototype
          : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
      if (setter) {
        setter.call(el, `${el.value}${sep}${t}`);
        el.dispatchEvent(new Event('input', { bubbles: true }));
        return;
      }
    }
    // Fallback: the chat's last-touched field (mic tapped with nothing focused).
    switch (voiceTargetRef.current) {
      case 'name':
        setName(join);
        break;
      case 'email':
        setEmail((prev) => (prev ? `${prev}${t}` : t)); // emails have no spaces
        break;
      case 'phone':
        setPhone(join);
        break;
      default:
        setLocationInput(join);
    }
  }, []);
  const mic = useMicrophone(appendVoice);

  const messageListId = useId();

  const currentStep: StepId = STEPS[stepIndex] ?? 'service';
  const totalSteps = STEPS.length;

  // Scroll to bottom when new content appears
  useEffect(() => {
    const timer = setTimeout(() => {
      bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 50);
    return () => clearTimeout(timer);
  }, [revealedSteps, showTyping]);

  // Revoke object URLs on unmount
  useEffect(() => {
    const captured = photos;
    return () => {
      captured.forEach((p) => URL.revokeObjectURL(p.objectUrl));
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const advance = useCallback((nextIdx: number) => {
    setShowTyping(true);
    setTimeout(() => {
      setShowTyping(false);
      setStepIndex(nextIdx);
      setRevealedSteps((prev) => (prev.includes(nextIdx) ? prev : [...prev, nextIdx]));
    }, 650);
  }, []);

  const handleService = (svc: Service) => {
    setService(svc);
    advance(1);
  };

  const handleLocation = () => {
    const val = locationInput.trim();
    if (!val) return;
    setLocation(val);
    advance(2);
  };

  const handlePhotos = (skip: boolean = false) => {
    if (!skip && photos.length === 0) return;
    advance(3);
  };

  const handleTimeline = (tl: Timeline) => {
    setTimeline(tl);
    advance(4);
  };

  const handleEstimate = () => {
    advance(5);
    setTimeout(() => nameInputRef.current?.focus(), 800);
  };

  const handleContact = () => {
    if (!name.trim() || !email.trim()) return;
    advance(6);
  };

  const addFiles = useCallback(
    (files: FileList | File[]) => {
      const list = Array.from(files) as File[];
      const imageFiles = list.filter((f) => f.type.startsWith('image/'));
      const existingSize = photos.reduce((acc, p) => acc + p.file.size, 0);
      const newSize = imageFiles.reduce((acc, f) => acc + f.size, 0);
      if (existingSize + newSize > MAX_BYTES) {
        setSizeError('Total photos exceed 20 MB. Remove some and try again.');
        return;
      }
      setSizeError('');
      setPhotos((prev) => [
        ...prev,
        ...imageFiles.map((f): PhotoPreview => ({
          id: crypto.randomUUID(),
          objectUrl: URL.createObjectURL(f),
          filename: f.name,
          file: f,
        })),
      ]);
    },
    [photos],
  );

  const removePhoto = (id: string) => {
    setPhotos((prev) => {
      const entry = prev.find((p) => p.id === id);
      if (entry) URL.revokeObjectURL(entry.objectUrl);
      return prev.filter((p) => p.id !== id);
    });
  };

  const handleSubmit = async () => {
    if (!turnstileToken) return;
    setErrorMsg('');
    setSizeError('');

    let media: MediaItem[] = [];
    try {
      media = await Promise.all(
        photos.map(async (p): Promise<MediaItem> => ({
          kind: 'photo',
          filename: p.filename,
          dataUrl: await fileToDataUrl(p.file),
        })),
      );
    } catch {
      setErrorMsg('Could not encode photos. Remove large files and try again.');
      return;
    }

    setSubmitting(true);

    const transcript = buildTranscript({
      service,
      location,
      timeline,
      photoCount: photos.length,
      name,
      phone,
      preferredReply,
    });

    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          email,
          phone,
          subject: 'Custom quote request (chat)',
          message: transcript,
          preferredReply,
          media,
          turnstileToken,
        }),
      });
      const data = (await res.json()) as { ok: boolean; message?: string; id?: string };
      if (res.ok && data.ok && data.id) {
        setSuccess({ ok: true, id: data.id });
      } else {
        setErrorMsg(data.message ?? 'Something went wrong — try again or call (855) 82LABOR.');
      }
    } catch {
      setErrorMsg('Network hiccup. Try again or call (855) 82LABOR.');
    } finally {
      setSubmitting(false);
    }
  };

  // ── Success screen ────────────────────────────────────────────────────────

  if (success) {
    return (
      <div
        data-testid="contact-page"
        className="relative flex flex-1 items-center justify-center overflow-hidden bg-bg-primary px-4"
      >
        <div
          className="pointer-events-none absolute inset-0"
          style={{
            background:
              'radial-gradient(ellipse 80% 60% at 50% 40%, rgba(255,107,26,0.12) 0%, transparent 70%)',
          }}
          aria-hidden="true"
        />
        <div
          className="relative z-10 max-w-lg w-full rounded-2xl border border-brand-accent/30 bg-bg-elevated/80 p-10 text-center shadow-[0_32px_80px_-20px_rgba(255,107,26,0.25)] backdrop-blur-xl"
          style={{ animation: 'bcl-bubble-in 0.45s cubic-bezier(0.22,1,0.36,1) both' }}
        >
          <AssistantBubble animate={false}>
            <p className="text-brand-ink text-sm leading-relaxed text-left">
              You're all set! A real person will reply via{' '}
              <strong className="text-brand-accent">{preferredReply}</strong> within the hour — usually way faster.
            </p>
          </AssistantBubble>

          <div className="mt-6 mb-2 flex items-center justify-center gap-2">
            <span className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
              Reference
            </span>
            <code className="font-mono text-xs text-brand-accent">{success.id.slice(0, 8)}</code>
          </div>

          <button
            type="button"
            data-bcl-cta="link-account"
            onClick={() =>
              window.location.assign(
                '/login?as=customer&next=%2Fcontact&link_contact=' +
                  encodeURIComponent(success.id),
              )
            }
            className="btn-primary w-full mt-6 text-base"
          >
            Link with account →
          </button>
          <p className="mt-3 text-[11px] text-brand-mute leading-relaxed">
            Linking lets you track this request, view updates, and rebook — all in one place.
          </p>
        </div>
        <CSSKeyframes />
      </div>
    );
  }

  // ── Chat UI ───────────────────────────────────────────────────────────────

  // Suppress unused-variable warning — currentStep is used for screen reader context
  void currentStep;

  return (
    <div
      data-testid="contact-page"
      className="relative flex flex-1 flex-col bg-bg-primary overflow-x-hidden"
    >
      {/* Cinematic backdrop — twin drifting aurora blooms, a faint engineering
          grid, film grain, and a vignette. All non-interactive + reduced-motion
          aware. This is the HBO-dark canvas the chat floats on. */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
        {/* warm aurora (top) */}
        <div
          className="absolute -top-40 left-1/2 h-[560px] w-[900px] rounded-full blur-[8px]"
          style={{
            background:
              'radial-gradient(ellipse at center, rgba(255,107,26,0.30) 0%, rgba(255,107,26,0.10) 38%, transparent 68%)',
            animation: 'bcl-aurora 16s ease-in-out infinite',
          }}
        />
        {/* cool aurora (lower, offset) for depth */}
        <div
          className="absolute top-1/3 left-1/2 h-[520px] w-[820px] rounded-full blur-[10px]"
          style={{
            background:
              'radial-gradient(ellipse at center, rgba(80,170,227,0.16) 0%, rgba(124,58,237,0.10) 42%, transparent 70%)',
            animation: 'bcl-aurora-2 22s ease-in-out infinite',
          }}
        />
        {/* engineering grid */}
        <div
          className="absolute inset-0 opacity-[0.035]"
          style={{
            backgroundImage:
              'linear-gradient(rgba(255,107,26,0.6) 1px, transparent 1px), linear-gradient(90deg, rgba(255,107,26,0.6) 1px, transparent 1px)',
            backgroundSize: '54px 54px',
            maskImage: 'radial-gradient(ellipse 100% 80% at 50% 30%, #000 40%, transparent 100%)',
            WebkitMaskImage: 'radial-gradient(ellipse 100% 80% at 50% 30%, #000 40%, transparent 100%)',
          }}
        />
        {/* film grain */}
        <div
          className="absolute inset-0 opacity-[0.05] mix-blend-overlay"
          style={{
            backgroundImage:
              "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E\")",
          }}
        />
        {/* vignette */}
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(ellipse 120% 90% at 50% 0%, transparent 55%, rgba(0,0,0,0.45) 100%)',
          }}
        />
      </div>

      {/* Voice visualizer — Web Audio frequency bloom behind the chat while the
          mic is live (low opacity, non-interactive, honors reduced-motion). */}
      <MicVisualizer analyser={mic.analyser} active={mic.active} />

      {/* Slim progress line — the redundant top bar (brand chip + Book CTA) was
          removed; the site navbar already carries branding + the Book action. */}
      <div className="sticky top-0 z-20">
        <ProgressBar step={stepIndex + 1} total={totalSteps} />
      </div>

      {/* ── Message list ─────────────────────────────────────────────────── */}
      {/* No inner overflow: the page itself grows with the chat so the minimal
          site footer sits at the viewport bottom, then scrolls off as messages fill. */}
      <div
        className="relative z-10 flex-1 px-4 py-6"
        id={messageListId}
        role="log"
        aria-live="polite"
        aria-label="Chat with Brick Labor"
      >
        <div className="mx-auto max-w-2xl space-y-5">

          {/* Page heading — the single visible page title for /contact (SEO +
              document structure). The chat below is the interactive form. */}
          <h1 className="text-center font-display text-[clamp(1.75rem,6vw,2.5rem)] font-black leading-tight text-brand-ink">
            Contact{' '}
            <span className="bg-gradient-to-r from-[#ff9a5a] via-brand-accent to-[#e85d10] bg-clip-text text-transparent">
              Brick Labor
            </span>
          </h1>

          {/* Live-presence pill + trust ticker — a human is on the other end,
              right now. Presence + reply-time is the #1 lead-gen trust lever. */}
          <div
            className="flex flex-col items-center gap-2"
            style={{ animation: 'bcl-bubble-in 0.4s 0.1s cubic-bezier(0.22,1,0.36,1) both' }}
          >
            <span className="inline-flex items-center gap-2 rounded-full border border-emerald-400/30 bg-emerald-400/10 px-3 py-1 font-mono text-[11px] text-emerald-300 backdrop-blur-sm">
              <span className="relative flex h-2 w-2" aria-hidden="true">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
              </span>
              Brian’s crew is online · replies in ~12 min
            </span>
            <div className="flex flex-wrap items-center justify-center gap-x-2 gap-y-1 font-mono text-[11px] text-brand-mute">
              <span>
                <span className="font-bold text-brand-ink">300+</span> Newark jobs this month
              </span>
              <span className="text-brand-accent" aria-hidden="true">·</span>
              <span>
                <span className="font-bold text-brand-ink">4.9★</span> avg rating
              </span>
              <span className="text-brand-accent" aria-hidden="true">·</span>
              <span>
                <span className="font-bold text-brand-ink">100%</span> satisfaction
              </span>
            </div>
          </div>

          {/* ── STEP 0 — service ─────────────────────────────────────────── */}
          {revealedSteps.includes(0) && (
            <>
              <AssistantBubble>
                <p className="text-brand-ink text-sm leading-relaxed mb-1 font-display font-semibold">
                  Hey! What do you need help with?
                </p>
                <p className="text-brand-mute text-xs">Tap the one that fits — we handle the rest.</p>
              </AssistantBubble>

              {stepIndex === 0 && (
                <div
                  className="flex flex-wrap gap-2 pl-11"
                  role="group"
                  aria-label="Service options"
                  style={{ animation: 'bcl-bubble-in 0.4s 0.15s cubic-bezier(0.22,1,0.36,1) both' }}
                >
                  {SERVICES.map((svc) => (
                    <Chip
                      key={svc}
                      label={svc}
                      selected={service === svc}
                      onClick={() => handleService(svc)}
                    />
                  ))}
                </div>
              )}
              {service !== '' && stepIndex > 0 && <UserBubble>{service}</UserBubble>}
            </>
          )}

          {/* ── STEP 1 — location ────────────────────────────────────────── */}
          {revealedSteps.includes(1) && (
            <>
              <AssistantBubble>
                <p className="text-brand-ink text-sm leading-relaxed">
                  Where's the job? A ZIP code or intersection works great.
                </p>
              </AssistantBubble>

              {stepIndex === 1 && (
                <div
                  className="pl-11"
                  style={{ animation: 'bcl-bubble-in 0.35s 0.05s cubic-bezier(0.22,1,0.36,1) both' }}
                >
                  <label className="sr-only" htmlFor="bcl-location-input">
                    Location
                  </label>
                  <div className="flex gap-2">
                    <input
                      id="bcl-location-input"
                      type="text"
                      autoComplete="postal-code"
                      value={locationInput}
                      onChange={(e) => setLocationInput(e.target.value)}
                      onFocus={() => (voiceTargetRef.current = 'location')}
                      onKeyDown={(e) => { if (e.key === 'Enter') handleLocation(); }}
                      placeholder="e.g. 07104 or Downtown Newark"
                      className="input flex-1"
                      aria-required="true"
                    />
                    <button
                      type="button"
                      onClick={handleLocation}
                      disabled={!locationInput.trim()}
                      className="btn-primary min-h-[44px] px-5 disabled:opacity-40"
                    >
                      →
                    </button>
                  </div>
                </div>
              )}
              {location !== '' && stepIndex > 1 && <UserBubble>{location}</UserBubble>}
            </>
          )}

          {/* ── STEP 2 — photos ──────────────────────────────────────────── */}
          {revealedSteps.includes(2) && (
            <>
              <AssistantBubble>
                <p className="text-brand-ink text-sm leading-relaxed mb-1 font-display font-semibold">
                  Snap a couple photos — it gets you a real number, fast.
                </p>
                <p className="text-brand-mute text-xs">No photos? No problem — tap Skip to continue.</p>
              </AssistantBubble>

              {stepIndex === 2 && (
                <div
                  className="pl-11 space-y-3"
                  style={{ animation: 'bcl-bubble-in 0.35s 0.05s cubic-bezier(0.22,1,0.36,1) both' }}
                >
                  <div
                    role="button"
                    tabIndex={0}
                    aria-label="Upload photos — drag and drop or click to browse"
                    className={`relative flex min-h-[100px] cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent ${
                      dragging
                        ? 'border-brand-accent bg-brand-accent/10'
                        : 'border-brand-line bg-bg-elevated/40 hover:border-brand-accent/60 hover:bg-brand-accent/5'
                    }`}
                    onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
                    onDragLeave={() => setDragging(false)}
                    onDrop={(e) => {
                      e.preventDefault();
                      setDragging(false);
                      addFiles(e.dataTransfer.files);
                    }}
                    onClick={() => fileInputRef.current?.click()}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') fileInputRef.current?.click();
                    }}
                  >
                    <span className="text-2xl" aria-hidden="true">📷</span>
                    <span className="font-display text-sm font-semibold text-brand-ink">
                      Drop photos or click to browse
                    </span>
                    <span className="text-xs text-brand-mute">JPG · PNG · HEIC · WEBP</span>
                  </div>

                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    accept="image/*"
                    className="sr-only"
                    aria-label="Photo file input"
                    onChange={(e) => {
                      if (e.target.files) addFiles(e.target.files);
                      e.target.value = '';
                    }}
                  />

                  {sizeError !== '' && (
                    <p role="alert" className="text-xs text-red-400 px-1">{sizeError}</p>
                  )}

                  {photos.length > 0 && (
                    <div className="grid grid-cols-4 gap-2" role="list" aria-label="Attached photos">
                      {photos.map((p) => (
                        <div
                          key={p.id}
                          role="listitem"
                          className="relative group rounded-lg overflow-hidden border border-brand-line aspect-square bg-bg-primary"
                        >
                          <img
                            src={p.objectUrl}
                            alt={p.filename}
                            className="h-full w-full object-cover"
                          />
                          <button
                            type="button"
                            aria-label={`Remove ${p.filename}`}
                            onClick={() => removePhoto(p.id)}
                            className="absolute top-1 right-1 flex h-6 w-6 items-center justify-center rounded-full bg-bg-primary/80 text-brand-ink text-xs opacity-0 group-hover:opacity-100 focus-visible:opacity-100 transition-opacity focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
                          >
                            ✕
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="flex gap-2 flex-wrap">
                    {photos.length > 0 && (
                      <button
                        type="button"
                        onClick={() => handlePhotos(false)}
                        className="btn-primary min-h-[44px]"
                      >
                        Use {photos.length} photo{photos.length !== 1 ? 's' : ''} →
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => handlePhotos(true)}
                      className="btn-ghost min-h-[44px]"
                    >
                      Skip photos
                    </button>
                  </div>
                </div>
              )}
              {stepIndex > 2 && (
                <UserBubble>
                  {photos.length > 0
                    ? `${photos.length} photo${photos.length !== 1 ? 's' : ''} attached`
                    : 'Skipped photos'}
                </UserBubble>
              )}
            </>
          )}

          {/* ── STEP 3 — timeline ────────────────────────────────────────── */}
          {revealedSteps.includes(3) && (
            <>
              <AssistantBubble>
                <p className="text-brand-ink text-sm leading-relaxed">
                  When do you need it?
                </p>
              </AssistantBubble>

              {stepIndex === 3 && (
                <div
                  className="flex flex-wrap gap-2 pl-11"
                  role="group"
                  aria-label="Timeline options"
                  style={{ animation: 'bcl-bubble-in 0.35s 0.05s cubic-bezier(0.22,1,0.36,1) both' }}
                >
                  {TIMELINES.map((tl) => (
                    <Chip
                      key={tl}
                      label={tl}
                      selected={timeline === tl}
                      onClick={() => handleTimeline(tl)}
                    />
                  ))}
                </div>
              )}
              {timeline !== '' && stepIndex > 3 && <UserBubble>{timeline}</UserBubble>}
            </>
          )}

          {/* ── STEP 4 — estimate ────────────────────────────────────────── */}
          {revealedSteps.includes(4) && service !== '' && (
            <>
              <AssistantBubble>
                <p className="mb-2 font-mono text-[10px] uppercase tracking-[0.2em] text-brand-accent">
                  Instant ballpark
                </p>
                <p
                  className="bg-gradient-to-r from-[#ff9a5a] via-brand-accent to-[#e85d10] bg-clip-text font-display text-[2.15rem] font-black leading-none text-transparent"
                  style={{ animation: 'bcl-count-glow 2.8s ease-in-out infinite' }}
                >
                  {ESTIMATES[service]}
                </p>
                <p className="mt-2 text-xs leading-relaxed text-brand-mute">
                  Typical {service.toLowerCase()} around Newark. Flat $50/hr per pro — no trip fees,
                  no surprises. Your exact quote comes back fast once we see the details.
                </p>
                <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 font-mono text-[11px] text-brand-mute">
                  <span className="inline-flex items-center gap-1.5">
                    <span
                      className="h-1.5 w-1.5 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.7)]"
                      aria-hidden="true"
                    />
                    Real person replies within the hour
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <span aria-hidden="true">★</span> 4.9 avg · 300+ Newark jobs
                  </span>
                </div>
              </AssistantBubble>

              {stepIndex === 4 && (
                <div
                  className="pl-11"
                  style={{ animation: 'bcl-bubble-in 0.35s 0.05s cubic-bezier(0.22,1,0.36,1) both' }}
                >
                  <button
                    type="button"
                    onClick={handleEstimate}
                    className="btn-primary min-h-[44px]"
                  >
                    Get my real quote →
                  </button>
                </div>
              )}
            </>
          )}

          {/* ── STEP 5 — contact ─────────────────────────────────────────── */}
          {revealedSteps.includes(5) && (
            <>
              <AssistantBubble>
                <p className="text-brand-ink text-sm leading-relaxed mb-1 font-display font-semibold">
                  Where should we send your quote?
                </p>
                <p className="text-brand-mute text-xs">We'll reach out your way — no spam, ever.</p>
              </AssistantBubble>

              {stepIndex === 5 && (
                <div
                  className="pl-11 space-y-4"
                  style={{ animation: 'bcl-bubble-in 0.35s 0.05s cubic-bezier(0.22,1,0.36,1) both' }}
                >
                  <div className="grid sm:grid-cols-2 gap-3">
                    <div>
                      <label className="label" htmlFor="bcl-name">
                        Full name <span className="text-brand-accent">*</span>
                      </label>
                      <input
                        id="bcl-name"
                        ref={nameInputRef}
                        type="text"
                        required
                        autoComplete="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        onFocus={() => (voiceTargetRef.current = 'name')}
                        className="input"
                        aria-required="true"
                      />
                    </div>
                    <div>
                      <label className="label" htmlFor="bcl-email">
                        Email <span className="text-brand-accent">*</span>
                      </label>
                      <input
                        id="bcl-email"
                        type="email"
                        required
                        autoComplete="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        onFocus={() => (voiceTargetRef.current = 'email')}
                        onKeyDown={(e) => { if (e.key === 'Enter') handleContact(); }}
                        className="input"
                        aria-required="true"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="label" htmlFor="bcl-phone">
                      Phone <span className="text-brand-mute font-normal">(optional)</span>
                    </label>
                    <input
                      id="bcl-phone"
                      type="tel"
                      autoComplete="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      onFocus={() => (voiceTargetRef.current = 'phone')}
                      className="input"
                    />
                  </div>

                  <fieldset>
                    <legend className="label mb-2">How should we reach you?</legend>
                    <div className="flex flex-wrap gap-2" role="group" aria-label="Preferred reply channel">
                      {REPLY_OPTS.map((opt) => (
                        <Chip
                          key={opt.id}
                          label={opt.label}
                          icon={opt.icon}
                          selected={preferredReply === opt.id}
                          onClick={() => setPreferredReply(opt.id)}
                        />
                      ))}
                    </div>
                  </fieldset>

                  <button
                    type="button"
                    onClick={handleContact}
                    disabled={!name.trim() || !email.trim()}
                    className="btn-primary min-h-[44px] w-full sm:w-auto disabled:opacity-40"
                  >
                    Almost done →
                  </button>
                </div>
              )}
              {stepIndex > 5 && name !== '' && (
                <UserBubble>
                  {name} · {email} · via {preferredReply}
                </UserBubble>
              )}
            </>
          )}

          {/* ── STEP 6 — turnstile + submit ──────────────────────────────── */}
          {revealedSteps.includes(6) && (
            <>
              <AssistantBubble>
                <p className="text-brand-ink text-sm leading-relaxed">
                  One last thing — prove you're human and we're good to go!
                </p>
              </AssistantBubble>

              <div
                className="pl-11 space-y-4"
                style={{ animation: 'bcl-bubble-in 0.35s 0.05s cubic-bezier(0.22,1,0.36,1) both' }}
              >
                <div className="flex justify-start">
                  <TurnstileWidget onToken={setTurnstileToken} action="contact" />
                </div>

                {errorMsg !== '' && (
                  <p role="alert" className="rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-400">
                    {errorMsg}
                  </p>
                )}

                <button
                  type="button"
                  data-bcl-cta="contact-submit"
                  disabled={submitting || !turnstileToken}
                  onClick={handleSubmit}
                  className="btn-primary min-h-[44px] w-full text-base disabled:opacity-40"
                  aria-busy={submitting}
                >
                  {submitting ? (
                    <span className="flex items-center justify-center gap-2">
                      <span className="spinner" aria-hidden="true" /> Sending…
                    </span>
                  ) : (
                    'Send my quote request →'
                  )}
                </button>
                <p className="text-[11px] text-brand-mute">
                  Goes to{' '}
                  <a
                    href="mailto:hey@bricklabor.com"
                    className="text-brand-accent hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent rounded"
                  >
                    hey@bricklabor.com
                  </a>
                  . Typical reply in under an hour.
                </p>
              </div>
            </>
          )}

          {/* Typing indicator */}
          {showTyping && (
            <AssistantBubble animate={false}>
              <TypingIndicator />
            </AssistantBubble>
          )}

          <div ref={bottomRef} aria-hidden="true" />
        </div>
      </div>

      {/* Always-visible quick contact — reach us directly without walking the chat
          wizard: every method (call / text / email / WhatsApp / Instagram / Facebook)
          with logos + a compact message form, in one card below the conversation. */}
      <div className="mx-auto w-full max-w-2xl px-4 pb-8">
        <ContactCard />
      </div>

      {/* ── Voice bar ────────────────────────────────────────────────────── */}
      {/* First-class mic: tap to talk, the Web Audio bars bloom behind the chat,
          and (Chrome/Safari) speech is typed into the field you last touched.
          Sticky so it stays reachable while the chat scrolls; the minimal site
          footer settles just beneath it at the end of the page. */}
      {mic.supported && (
        <div className="sticky bottom-0 z-20 border-t border-brand-line/60 bg-bg-primary/85 px-4 py-3 backdrop-blur-sm">
          <div className="mx-auto flex max-w-2xl items-center gap-3">
            <button
              type="button"
              onMouseDown={(e) => e.preventDefault()}
              onClick={mic.toggle}
              aria-pressed={mic.active}
              aria-label={mic.active ? 'Stop microphone' : 'Talk to fill in your answers by voice'}
              className={`relative flex h-12 w-12 shrink-0 items-center justify-center rounded-full border transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent ${
                mic.active
                  ? 'border-brand-accent bg-brand-accent text-bg-primary shadow-[0_0_0_6px_rgba(255,107,26,0.18)]'
                  : 'border-brand-line bg-bg-elevated text-brand-accent hover:border-brand-accent'
              }`}
            >
              {mic.active && (
                <span
                  className="absolute inset-0 rounded-full border border-brand-accent/60"
                  style={{ animation: 'bcl-pulse 1.4s ease-in-out infinite' }}
                  aria-hidden="true"
                />
              )}
              <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor" aria-hidden="true">
                <path d="M12 15a3 3 0 0 0 3-3V6a3 3 0 1 0-6 0v6a3 3 0 0 0 3 3Z" />
                <path d="M19 11a1 1 0 1 0-2 0 5 5 0 0 1-10 0 1 1 0 1 0-2 0 7 7 0 0 0 6 6.92V21a1 1 0 1 0 2 0v-3.08A7 7 0 0 0 19 11Z" />
              </svg>
            </button>
            <div className="min-w-0 flex-1">
              {mic.active ? (
                <p className="truncate text-sm text-brand-ink" aria-live="polite">
                  {mic.interim || (
                    <span className="text-brand-mute">Listening… speak your answer.</span>
                  )}
                </p>
              ) : (
                <p className="text-sm text-brand-mute">
                  <span className="font-semibold text-brand-ink">Tap to talk.</span>{' '}
                  {mic.speechSupported
                    ? 'We’ll type it into the box you’re on.'
                    : 'The bars react to your voice — dictation needs Chrome or Safari.'}
                </p>
              )}
              {mic.error && <p className="mt-0.5 text-xs text-red-400">{mic.error}</p>}
            </div>
          </div>
        </div>
      )}

      <CSSKeyframes />
    </div>
  );
}
