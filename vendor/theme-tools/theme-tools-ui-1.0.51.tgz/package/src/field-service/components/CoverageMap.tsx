import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { lazy, Suspense, useEffect, useRef, useState } from 'react';
import { CITIES } from '../data/cities.js';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { coverageMapCopy, type CoverageMapCopy } from '@theme.tools/i18n-a11y/field-service/coverage-map-copy';

const MapInner = lazy(() => import('./MapInner.js').then((m) => ({ default: m.MapInner })));

const NJ_COUNT = CITIES.filter((c) => c.state === 'NJ').length;
const NY_COUNT = CITIES.filter((c) => c.state === 'NY').length;
const PRIMARY_CITIES = CITIES.filter((c) => c.primary).slice(0, 6);
const FEATURED_CITIES = CITIES.filter((c) => !c.primary).slice(0, 8);

const SERVICE_LINKS: Array<{
  slug: string;
  label: string;
  blurb: string;
  accent: string;
  iconAccent: string;
  Icon: () => JSX.Element;
}> = [
  {
    slug: 'power-washing',
    label: 'Power washing',
    blurb: 'Driveways, siding, decks, patios.',
    accent: 'from-cyan-400/25 via-brand-accent/10 to-transparent',
    iconAccent: 'text-cyan-300',
    Icon: () => (
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="h-5 w-5"
      >
        <path d="M3 12h6l2-2v8" />
        <path d="M11 14l4-2 6 4v4H11z" />
        <path d="M15 12V4" />
        <circle cx="15" cy="4" r="1.5" />
      </svg>
    ),
  },
  {
    slug: 'lawn-care',
    label: 'Lawn & yard care',
    blurb: 'Mow, edge, hedge, haul clippings.',
    accent: 'from-lime-400/25 via-emerald-500/10 to-transparent',
    iconAccent: 'text-lime-300',
    Icon: () => (
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="h-5 w-5"
      >
        <path d="M3 21h18" />
        <path d="M5 21V11l7-5 7 5v10" />
        <path d="M9 21v-6h6v6" />
      </svg>
    ),
  },
  {
    slug: 'hauling',
    label: 'Hauling & junk',
    blurb: 'Truck + 2 guys. Dump runs same day.',
    accent: 'from-amber-400/25 via-orange-500/10 to-transparent',
    iconAccent: 'text-amber-300',
    Icon: () => (
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="h-5 w-5"
      >
        <path d="M1 17h13V5H1z" />
        <path d="M14 9h4l3 4v4h-7" />
        <circle cx="6" cy="19" r="2" />
        <circle cx="17" cy="19" r="2" />
      </svg>
    ),
  },
  {
    slug: 'light-repairs',
    label: 'Light repairs',
    blurb: 'Patch, hang, swap, tighten.',
    accent: 'from-purple-400/25 via-pink-500/10 to-transparent',
    iconAccent: 'text-purple-300',
    Icon: () => (
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="h-5 w-5"
      >
        <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0L21 6a4 4 0 0 0-5-5l-3 3a1 1 0 0 0 0 1.4l1.7 1.7" />
        <path d="M16 7L4 19a2 2 0 1 0 3 3l12-12" />
      </svg>
    ),
  },
];

interface CountyLink {
  county: string;
  citySlug: string;
  cityName: string;
  count: number;
}

const NJ_COUNTY_LINKS: CountyLink[] = [
  { county: 'Essex', citySlug: 'newark', cityName: 'Newark', count: 17 },
  { county: 'Hudson', citySlug: 'jersey-city', cityName: 'Jersey City', count: 7 },
  { county: 'Bergen', citySlug: 'hackensack', cityName: 'Hackensack', count: 6 },
  { county: 'Union', citySlug: 'elizabeth', cityName: 'Elizabeth', count: 10 },
  { county: 'Passaic', citySlug: 'paterson', cityName: 'Paterson', count: 4 },
  { county: 'Middlesex', citySlug: 'edison', cityName: 'Edison', count: 1 },
];

const NYC_BORO_LINKS: Array<{ name: string; slug: string }> = [
  { name: 'Manhattan', slug: 'manhattan' },
  { name: 'Brooklyn', slug: 'brooklyn' },
  { name: 'Queens', slug: 'queens' },
  { name: 'Bronx', slug: 'the-bronx' },
  { name: 'Staten Island', slug: 'staten-island' },
];

/** Interpolate `{key}` placeholders in a localized template string. */
function fill(tpl: string, vars: Record<string, string | number>): string {
  return tpl.replace(/\{(\w+)\}/g, (_m, k) => String(vars[k] ?? ''));
}

function MapFrameGate({ origin = 'home', copy }: { origin?: string; copy: CoverageMapCopy }) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (ready) return;
    const node = ref.current;
    if (!node) return;
    if (typeof IntersectionObserver === 'undefined') {
      setReady(true);
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            setReady(true);
            io.disconnect();
            return;
          }
        }
      },
      { rootMargin: '400px 0px' },
    );
    io.observe(node);
    return () => io.disconnect();
  }, [ready]);

  return (
    <div
      ref={ref}
      className="absolute inset-0"
      // role="group" — the Google Maps JS widget injects interactive zoom + pan
      // controls directly into this container. role="img" would violate WCAG
      // 4.1.2 (nested-interactive); role="application" would seize the screen
      // reader's keyboard mode across the whole wrapper (incl. the boot
      // skeleton) — both wrong. role="group" is a structural (non-widget) role
      // that DOES support an accessible name and permits interactive children,
      // so the localized label is actually exposed without hijacking AT keys.
      // (A bare <div aria-label> drops the name — "generic" supports no name.)
      // The outer <section aria-label="Coverage area map"> stays the landmark.
      role="group"
      aria-label={fill(copy.mapAria, { origin })}
      // §scroll-trap fix — touch-action: pan-y guarantees vertical scroll on
      // mobile/trackpad swipes ALWAYS passes through the map container, even
      // if the Maps JS gestureHandling: 'cooperative' overlay misses the
      // event. Pair with the cooperative mode so desktop wheel + mobile
      // single-finger pan never traps page scroll.
      style={{ touchAction: 'pan-y' }}
    >
      {ready ? (
        <Suspense fallback={<MapBootSkeleton copy={copy} />}>
          <MapInner />
        </Suspense>
      ) : (
        <MapBootSkeleton copy={copy} />
      )}
    </div>
  );
}

function MapBootSkeleton({ copy }: { copy: CoverageMapCopy }) {
  return (
    <div className="absolute inset-0 grid place-items-center bg-bg-elevated/60 text-brand-mute font-mono text-sm">
      <div className="flex items-center gap-3">
        <span className="inline-block h-2 w-2 rounded-full bg-brand-accent animate-pulse" />
        {copy.bootSkeleton}
      </div>
    </div>
  );
}

interface CoverageMapProps {
  origin?: string;
  highlightCity?: { name: string; state: string };
}

export function CoverageMap({ origin = 'home', highlightCity }: CoverageMapProps) {
  useThemeToolsSurface('coverage-map');
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const copy = coverageMapCopy(locale);
  // Keep a mirror-locale visitor in /es · /pt — the coverage copy is localized;
  // localize every city/service/book href too so a "Reserva tu zona" click
  // doesn't drop them onto the English route. /sitemap.xml + mailto stay bare.
  const lp = (path: string) => localizedPath(locale, path);
  const TOTAL = NJ_COUNT + NY_COUNT;

  // Two-part heading (base ink + gradient accent). The city variant prefixes
  // the locale-invariant "{city}, {state} " before the localized clause.
  // Destination highlights (state ≠ NJ/NY, e.g. Washington DC) are scheduled
  // travel stops — never claim they sit "inside our daily run" or share the flat
  // $50/hr rate. See CLAUDE.md § business model.
  const destHighlight =
    !!highlightCity && highlightCity.state !== 'NJ' && highlightCity.state !== 'NY';
  const headingPart = highlightCity
    ? destHighlight
      ? copy.headingCityDest
      : copy.headingCity
    : copy.headingGeneric;
  const headingPrefix = highlightCity ? `${highlightCity.name}, ${highlightCity.state} ` : '';

  const lede = highlightCity
    ? destHighlight
      ? fill(copy.ledeCityDest, { total: TOTAL })
      : fill(copy.ledeCity, { city: highlightCity.name, total: TOTAL })
    : fill(copy.ledeGeneric, { nj: NJ_COUNT, ny: NY_COUNT });

  return (
    <section
      id="coverage"
      data-coverage-map
      aria-label="Coverage area map"
      className="relative scroll-mt-24 py-20 sm:py-28 overflow-hidden"
    >
      <div className="absolute inset-0 -z-10 grid-pattern opacity-50" aria-hidden="true" />
      <div
        className="absolute inset-x-0 top-0 -z-10 h-px bg-gradient-to-r from-transparent via-brand-accent/40 to-transparent"
        aria-hidden="true"
      />

      <div className="container-pad mb-10 sm:mb-14">
        <div className="max-w-3xl">
          <p className="eyebrow mb-3">{copy.eyebrow}</p>
          <h2 className="text-4xl sm:text-5xl font-extrabold leading-[1.05]">
            {headingPrefix}
            {headingPart.pre} <span className="text-gradient">{headingPart.accent}</span>
          </h2>
          <p className="mt-4 text-lg text-brand-mute">{lede}</p>
        </div>
      </div>

      <div
        className="relative w-screen left-1/2 right-1/2 -ml-[50vw] -mr-[50vw] mb-12 sm:mb-16"
        data-animate="fade-up"
      >
        <div className="relative mx-auto max-w-[1600px] px-4 sm:px-6 lg:px-10">
          <div className="relative overflow-hidden rounded-2xl border border-brand-line bg-bg-elevated shadow-[0_30px_80px_-30px_rgba(255,107,26,0.35)]">
            {/* CLS budget: map container reserves space via aspect-ratio + min-height before Maps JS loads. See docs/cwv-city-pages-2026-06.md */}
            <div className="relative aspect-[16/9] sm:aspect-[21/9] min-h-[360px] sm:min-h-[480px] lg:min-h-[560px]">
              <MapFrameGate origin={origin} copy={copy} />

              <div className="pointer-events-none absolute inset-0" aria-hidden="true">
                <div className="absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-bg-primary/70 via-bg-primary/10 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-bg-primary/85 via-bg-primary/20 to-transparent" />
                <div className="absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-bg-primary/55 to-transparent" />
                <div className="absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-bg-primary/55 to-transparent" />
              </div>

              <CornerBrackets />

              <div className="pointer-events-none absolute left-4 top-4 sm:left-6 sm:top-6">
                <div className="flex items-center gap-2 rounded-full border border-brand-accent/40 bg-bg-primary/85 px-3.5 py-1.5 backdrop-blur-md">
                  <span className="relative inline-flex h-2 w-2">
                    <span className="absolute inset-0 animate-ping rounded-full bg-brand-accent/60" />
                    <span className="relative inline-flex h-2 w-2 rounded-full bg-brand-accent" />
                  </span>
                  <span className="font-mono text-[11px] uppercase tracking-[0.18em] text-brand-ink">
                    {fill(copy.badgeCities, { total: TOTAL })}
                  </span>
                </div>
              </div>

              <div className="pointer-events-none absolute right-4 top-4 sm:right-6 sm:top-6">
                <div className="flex items-center gap-2 rounded-full border border-brand-line bg-bg-primary/80 px-3 py-1.5 backdrop-blur-md">
                  <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-brand-mute">
                    {copy.homeBase}
                  </span>
                  <span className="font-mono text-[11px] font-bold text-brand-accent">
                    Newark, NJ 07102
                  </span>
                </div>
              </div>

              <div className="pointer-events-none absolute bottom-4 left-4 right-4 sm:bottom-6 sm:left-6 sm:right-6 flex flex-wrap items-end justify-between gap-4">
                <ul className="flex flex-wrap items-center gap-x-4 gap-y-2 rounded-xl border border-brand-line bg-bg-primary/85 px-4 py-2.5 backdrop-blur-md">
                  <li className="flex items-center gap-2 text-xs">
                    <span
                      className="inline-block h-3 w-3 rounded-full border-2 border-brand-accent bg-brand-accent shadow-[0_0_12px_rgba(255,107,26,0.7)]"
                      aria-hidden
                    />
                    <span className="font-mono uppercase tracking-wider text-brand-ink">
                      {copy.homeBase}
                    </span>
                  </li>
                  <li className="flex items-center gap-2 text-xs">
                    <span
                      className="inline-block h-3 w-3 rounded-full bg-brand-accent"
                      aria-hidden
                    />
                    <span className="font-mono uppercase tracking-wider text-brand-mute">
                      {fill(copy.legendNjCity, { nj: NJ_COUNT })}
                    </span>
                  </li>
                  <li className="flex items-center gap-2 text-xs">
                    <span className="inline-block h-3 w-3 rounded-full bg-cyan-400" aria-hidden />
                    <span className="font-mono uppercase tracking-wider text-brand-mute">
                      {fill(copy.legendNycBorough, { ny: NY_COUNT })}
                    </span>
                  </li>
                </ul>

                <a
                  href={lp('/book')}
                  className="pointer-events-auto inline-flex items-center gap-2 rounded-full border border-brand-accent bg-brand-accent px-5 py-2.5 font-display font-bold text-bg-primary shadow-[0_8px_24px_rgba(255,107,26,0.45)] transition-transform hover:-translate-y-0.5"
                >
                  {copy.bookYourArea}
                  <span aria-hidden>→</span>
                </a>
              </div>
            </div>

            <CityTicker cities={[...PRIMARY_CITIES, ...FEATURED_CITIES]} />
          </div>
        </div>
      </div>

      <div className="container-pad" data-animate="fade-up" data-delay="120">
        <div className="grid gap-6 lg:grid-cols-3">
          <article className="group relative overflow-hidden rounded-2xl border border-brand-line bg-bg-elevated p-6 transition-shadow hover:shadow-[0_24px_60px_-30px_rgba(255,107,26,0.45)]">
            <div
              className="pointer-events-none absolute inset-0 -z-10 opacity-0 transition-opacity duration-500 group-hover:opacity-100"
              aria-hidden
            >
              <div className="absolute -top-10 -right-10 h-40 w-40 rounded-full bg-brand-accent/15 blur-3xl" />
            </div>
            <div className="mb-5 flex items-center justify-between">
              <p className="eyebrow">{copy.popularCities}</p>
              <span className="rounded-full border border-brand-accent/40 bg-brand-accent/10 px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-brand-accent">
                {fill(copy.totalBadge, { total: TOTAL })}
              </span>
            </div>
            <ul className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
              {[...PRIMARY_CITIES, ...FEATURED_CITIES].slice(0, 12).map((c) => (
                <li key={c.slug}>
                  <a
                    href={lp(`/c/${c.slug}`)}
                    className="group/card relative block aspect-[4/3] overflow-hidden rounded-lg border border-brand-line transition-all hover:-translate-y-0.5 hover:border-brand-accent hover:shadow-[0_10px_30px_-12px_rgba(255,107,26,0.55)]"
                    aria-label={fill(copy.cityCardAria, { city: c.name, state: c.state })}
                  >
                    <img
                      src={`/cities/${c.slug}.jpg`}
                      alt=""
                      loading="lazy"
                      decoding="async"
                      width={400}
                      height={300}
                      className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover/card:scale-[1.08]"
                    />
                    <div
                      className="absolute inset-0 bg-gradient-to-t from-bg-primary via-bg-primary/40 to-transparent"
                      aria-hidden
                    />
                    {c.primary && (
                      <span className="absolute left-2 top-2 rounded-full border border-brand-accent/50 bg-brand-accent/20 px-2 py-0.5 font-mono text-[9px] uppercase tracking-wider text-brand-accent backdrop-blur-sm">
                        {copy.primaryBadge}
                      </span>
                    )}
                    <span
                      className={`absolute right-2 top-2 inline-block h-2 w-2 rounded-full ${
                        c.state === 'NY'
                          ? 'bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.7)]'
                          : 'bg-brand-accent shadow-[0_0_8px_rgba(255,107,26,0.7)]'
                      }`}
                      aria-hidden
                    />
                    <div className="absolute inset-x-2 bottom-2">
                      <div className="font-display text-xs font-bold leading-tight text-brand-ink">
                        {c.name}
                      </div>
                      <div className="font-mono text-[9px] uppercase tracking-wider text-brand-mute">
                        {c.county} · {c.state}
                      </div>
                    </div>
                  </a>
                </li>
              ))}
            </ul>
            <p className="mt-4 rounded-lg border border-brand-line bg-bg-elevated/40 px-4 py-3 text-xs text-brand-mute leading-relaxed">
              <span className="font-mono uppercase tracking-wider text-brand-accent">
                Travel area
              </span>{' '}
              — beyond the NJ + NYC metro, we also travel to{' '}
              <a href={lp('/c/washington-dc')} className="text-brand-accent underline-hover">
                Washington, D.C.
              </a>{' '}
              for scheduled power-washing projects.
            </p>
            <div className="mt-5 flex items-center justify-between gap-3">
              <p className="text-xs text-brand-mute">
                <a href={lp('/c/newark')} className="text-brand-accent underline-hover">
                  Newark
                </a>
                ,{' '}
                <a href={lp('/c/jersey-city')} className="text-brand-accent underline-hover">
                  Jersey City
                </a>
                ,{' '}
                <a href={lp('/c/hoboken')} className="text-brand-accent underline-hover">
                  Hoboken
                </a>{' '}
                {fill(copy.moreCities, { n: TOTAL - 3 })}
              </p>
              <a
                href="/sitemap.xml"
                className="inline-flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-brand-accent underline-hover"
              >
                {copy.allCities}
                <span aria-hidden>→</span>
              </a>
            </div>
          </article>

          <article className="group relative overflow-hidden rounded-2xl border border-brand-line bg-bg-elevated p-6 transition-shadow hover:shadow-[0_24px_60px_-30px_rgba(255,107,26,0.45)]">
            <div className="mb-5 flex items-center justify-between">
              <p className="eyebrow">{copy.byService}</p>
              <span className="font-mono text-[10px] uppercase tracking-wider text-brand-mute">
                {copy.flatRate}
              </span>
            </div>
            <ul className="space-y-2.5">
              {SERVICE_LINKS.map((s) => (
                <li key={s.slug}>
                  <a
                    href={lp(`/services/${s.slug}`)}
                    className={`group/svc relative flex items-center gap-3 overflow-hidden rounded-xl border border-brand-line bg-gradient-to-r ${s.accent} px-4 py-3.5 transition-all hover:-translate-y-0.5 hover:border-brand-accent hover:shadow-[0_10px_30px_-12px_rgba(255,107,26,0.45)]`}
                  >
                    <span
                      className={`relative grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-brand-line bg-bg-primary/80 ${s.iconAccent} transition-colors group-hover/svc:border-brand-accent`}
                    >
                      <s.Icon />
                    </span>
                    <span className="relative flex-1 min-w-0">
                      <span className="block font-display text-sm font-bold leading-tight text-brand-ink">
                        {copy.services[s.slug]?.label ?? s.label}
                      </span>
                      <span className="block truncate font-mono text-[10px] uppercase tracking-wider text-brand-mute transition-colors group-hover/svc:text-brand-ink">
                        {copy.services[s.slug]?.blurb ?? s.blurb}
                      </span>
                    </span>
                    <span className="relative font-mono text-[11px] text-brand-mute transition-all group-hover/svc:translate-x-0.5 group-hover/svc:text-brand-accent">
                      →
                    </span>
                  </a>
                </li>
              ))}
            </ul>
            <p className="mt-5 text-xs text-brand-mute">
              {copy.serviceHubPre}{' '}
              <a href={lp('/c/newark')} className="text-brand-accent underline-hover">
                Newark
              </a>
              ,{' '}
              <a href={lp('/c/jersey-city')} className="text-brand-accent underline-hover">
                Jersey City
              </a>
              ,{' '}
              <a href={lp('/c/hoboken')} className="text-brand-accent underline-hover">
                Hoboken
              </a>
              {copy.serviceHubPost}
            </p>
          </article>

          <article className="group relative overflow-hidden rounded-2xl border border-brand-line bg-bg-elevated p-6 transition-shadow hover:shadow-[0_24px_60px_-30px_rgba(255,107,26,0.45)]">
            <div className="pointer-events-none absolute inset-0 -z-10" aria-hidden>
              <div className="absolute top-0 right-0 h-32 w-32 rounded-full bg-brand-accent/5 blur-2xl" />
              <div className="absolute bottom-0 left-0 h-32 w-32 rounded-full bg-cyan-500/5 blur-2xl" />
            </div>
            <div className="mb-5 flex items-center justify-between">
              <p className="eyebrow">{copy.byRegion}</p>
              <span className="font-mono text-[10px] uppercase tracking-wider text-brand-mute">
                {copy.njNyc}
              </span>
            </div>

            <div className="mb-5">
              <h3 className="mb-2.5 flex items-center gap-2 font-mono text-[10px] uppercase tracking-wider text-brand-mute">
                <span className="h-1.5 w-1.5 rounded-full bg-brand-accent" aria-hidden />
                {copy.njCountiesHeading}
              </h3>
              <ul className="grid grid-cols-2 gap-1.5">
                {NJ_COUNTY_LINKS.map((c) => (
                  <li key={c.county}>
                    <a
                      href={lp(`/c/${c.citySlug}`)}
                      className="group/chip flex items-center justify-between rounded-lg border border-brand-line bg-bg-primary px-2.5 py-1.5 font-mono text-[11px] text-brand-ink transition-all hover:-translate-y-0.5 hover:border-brand-accent hover:bg-brand-accent/10 hover:text-brand-accent"
                      aria-label={fill(copy.countyAria, {
                        county: c.county,
                        city: c.cityName,
                        count: c.count,
                        unit: c.count === 1 ? copy.cityUnitSingular : copy.cityUnitPlural,
                      })}
                    >
                      <span className="font-bold tracking-tight">{c.county}</span>
                      <span className="font-mono text-[9px] text-brand-mute transition-colors group-hover/chip:text-brand-accent">
                        {c.count}×
                      </span>
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="mb-2.5 flex items-center gap-2 font-mono text-[10px] uppercase tracking-wider text-brand-mute">
                <span className="h-1.5 w-1.5 rounded-full bg-cyan-400" aria-hidden />
                {copy.nycBoroughsHeading}
              </h3>
              <ul className="flex flex-wrap gap-1.5">
                {NYC_BORO_LINKS.map((b) => (
                  <li key={b.slug}>
                    <a
                      href={lp(`/c/${b.slug}`)}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-cyan-400/30 bg-bg-primary px-2.5 py-1.5 font-mono text-[11px] text-cyan-300 transition-all hover:-translate-y-0.5 hover:border-cyan-300 hover:bg-cyan-400/10"
                      aria-label={fill(copy.boroughAria, { name: b.name })}
                    >
                      <span className="h-1 w-1 rounded-full bg-cyan-400" aria-hidden />
                      {b.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            <p className="mt-5 text-xs text-brand-mute">
              {copy.outsidePre}{' '}
              <a href="mailto:hey@bricklabor.com" className="text-brand-accent underline-hover">
                hey@bricklabor.com
              </a>
              {copy.outsidePost}
            </p>
          </article>
        </div>
      </div>
    </section>
  );
}

function CornerBrackets() {
  const cls = 'absolute h-6 w-6 border-brand-accent/70';
  return (
    <div className="pointer-events-none absolute inset-2 sm:inset-4" aria-hidden="true">
      <span className={`${cls} top-0 left-0 border-l-2 border-t-2 rounded-tl-md`} />
      <span className={`${cls} top-0 right-0 border-r-2 border-t-2 rounded-tr-md`} />
      <span className={`${cls} bottom-0 left-0 border-l-2 border-b-2 rounded-bl-md`} />
      <span className={`${cls} bottom-0 right-0 border-r-2 border-b-2 rounded-br-md`} />
    </div>
  );
}

function CityTicker({ cities }: { cities: typeof CITIES }) {
  const items = [...cities, ...cities];
  return (
    <div
      className="relative overflow-hidden border-t border-brand-line bg-bg-primary/70 backdrop-blur-md"
      aria-hidden="true"
    >
      <div className="bcl-marquee flex w-max items-center gap-8 px-6 py-3 font-mono text-[11px] uppercase tracking-[0.16em] text-brand-mute">
        {items.map((c, i) => (
          <span key={`${c.slug}-${i}`} className="inline-flex items-center gap-2 whitespace-nowrap">
            <span
              className={`inline-block h-1.5 w-1.5 rounded-full ${
                c.primary
                  ? 'bg-brand-accent'
                  : c.state === 'NY'
                    ? 'bg-cyan-400'
                    : 'bg-brand-mute/60'
              }`}
            />
            <span className="text-brand-ink">{c.name}</span>
            <span className="text-brand-mute">·</span>
            <span>{c.state}</span>
          </span>
        ))}
      </div>
    </div>
  );
}
