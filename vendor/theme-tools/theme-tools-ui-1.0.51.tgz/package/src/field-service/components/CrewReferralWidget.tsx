import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useCallback, useEffect, useState } from 'react';
import { CREW_REFERRAL_QUALIFYING_GIGS, formatCrewBonus } from '@theme.tools/billing/field-service/crew-referral';

// Advertised crew-referral economics derive from the canonical shared module
// (src/shared/crew-referral.ts) — the SAME constants routes/crew-referrals.ts seeds
// + Stripe Connect pays, so the marketing copy can never drift from the payout.
const BONUS = formatCrewBonus();
const GIGS = CREW_REFERRAL_QUALIFYING_GIGS;
const TITLE = `Crew referrals — earn ${BONUS}/crew · Brick Labor`;
const DESC = `Refer a crew member to Brick Labor. After they complete ${GIGS} gigs, ${BONUS} lands on your next payout via Stripe Connect.`;

interface Referral {
  id: string;
  code: string;
  referrer_worker_id: string;
  referred_worker_id: string | null;
  qualifying_gigs_completed: number;
  qualifying_threshold: number;
  payout_cents: number;
  status: 'pending' | 'signed_up' | 'qualified' | 'paid' | 'void';
  signed_up_at: string | null;
  qualified_at: string | null;
  paid_at: string | null;
  payout_id: string | null;
  created_at: string;
  referredFirstName?: string | null;
}

interface ListResponse {
  ok: boolean;
  referrals: Referral[];
  totals: {
    pending: number;
    signedUp: number;
    qualified: number;
    paid: number;
    totalPaidCents: number;
  };
}

type LoadState =
  | { kind: 'loading' }
  | { kind: 'anonymous' }
  | { kind: 'error'; message: string }
  | { kind: 'ready'; data: ListResponse };

/**
 * /work/refer — crew-refers-crew bonus widget. Workers (cookie bcl_work_sid)
 * mint a single share code; every signed-up referee's gig count is shown so
 * the referrer can see progress toward the $100 threshold.
 */
export function CrewReferralWidget(): JSX.Element {
  useThemeToolsSurface('crew-referral-widget');
  useEffect(() => {
    document.title = TITLE;
    setMeta('description', DESC);
    setLink('canonical', 'https://bricklabor.com/work/refer');
    setMeta('robots', 'noindex,nofollow', 'name');
  }, []);

  const [state, setState] = useState<LoadState>({ kind: 'loading' });
  const [copied, setCopied] = useState(false);

  const load = useCallback(async () => {
    try {
      const res = await fetch('/api/work/refer', {
        credentials: 'include',
        headers: { accept: 'application/json' },
      });
      if (res.status === 401) {
        setState({ kind: 'anonymous' });
        return;
      }
      if (!res.ok) {
        setState({ kind: 'error', message: `Couldn't load referrals (HTTP ${res.status}).` });
        return;
      }
      let data = (await res.json()) as ListResponse;
      if (data.referrals.length === 0) {
        const mintRes = await fetch('/api/work/refer/mint', {
          method: 'POST',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json' },
          body: '{}',
        });
        if (mintRes.ok) {
          const reload = await fetch('/api/work/refer', {
            credentials: 'include',
            headers: { accept: 'application/json' },
          });
          if (reload.ok) data = (await reload.json()) as ListResponse;
        }
      }
      setState({ kind: 'ready', data });
    } catch (err) {
      // Error tracked via Sentry
      setState({ kind: 'error', message: 'Network hiccup. Try again in a minute.' });
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const active =
    state.kind === 'ready'
      ? (state.data.referrals.find((r) => r.status !== 'void' && !r.referred_worker_id) ??
        state.data.referrals[0])
      : undefined;
  const referrerId = active?.referrer_worker_id ?? '';
  const shareLink = active
    ? `https://bricklabor.com/work?ref=${encodeURIComponent(referrerId)}&code=${encodeURIComponent(active.code)}`
    : '';

  async function copyCode() {
    if (!active) return;
    try {
      await navigator.clipboard.writeText(active.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  }

  return (
    <article className="section">
      <div className="container-pad max-w-4xl">
        <p className="eyebrow mb-3">Crew · referrals</p>
        <h1 className="text-4xl sm:text-5xl font-extrabold">
          Bring a crew member. Earn <span className="text-brand-accent">{BONUS}</span>.
        </h1>
        <p className="mt-4 text-lg text-brand-mute max-w-2xl">
          Share your code with someone who'd be a fit. After they complete {GIGS} gigs, {BONUS}{' '}
          lands on your next Stripe Connect payout.
        </p>

        {state.kind === 'loading' && (
          <p className="mt-8 text-brand-mute" role="status">
            Loading your referrals…
          </p>
        )}

        {state.kind === 'error' && (
          <div
            role="alert"
            className="mt-8 rounded-lg border border-brand-err/40 bg-brand-err/10 p-4 text-sm text-brand-err"
          >
            {state.message}
          </div>
        )}

        {state.kind === 'anonymous' && (
          <div className="mt-8 card max-w-xl">
            <h2 className="text-xl font-extrabold">Crew login required</h2>
            <p className="mt-2 text-brand-mute">
              Sign in as a crew member to grab your referral code.
            </p>
            <a href="/login?as=crew&next=%2Fwork%2Frefer" className="btn-primary mt-4 inline-block">
              Sign in →
            </a>
          </div>
        )}

        {state.kind === 'ready' && active && (
          <>
            <section className="mt-8 grid gap-4 sm:grid-cols-4">
              <Stat label="Signed up" value={String(state.data.totals.signedUp)} />
              <Stat label="Qualified" value={String(state.data.totals.qualified)} />
              <Stat label="Paid" value={String(state.data.totals.paid)} />
              <Stat label="Earned" value={formatDollars(state.data.totals.totalPaidCents)} accent />
            </section>

            <section className="mt-8 card">
              <h2 className="text-xl font-extrabold">Your code</h2>
              <p className="mt-2 text-brand-mute">
                Send it to anyone who'd be a strong crew member. We screen them; you get credit
                after they complete {GIGS} gigs.
              </p>
              <div className="mt-4 flex flex-wrap items-center gap-3">
                <code className="rounded-lg border border-brand-accent/40 bg-brand-accent/5 px-4 py-2 text-2xl font-extrabold tracking-wider text-brand-accent">
                  {active.code}
                </code>
                <button type="button" onClick={copyCode} className="btn-secondary">
                  {copied ? 'Copied ✓' : 'Copy code'}
                </button>
                <a
                  href={`sms:?&body=${encodeURIComponent(
                    `Yo — Brick Labor is hiring crew. Apply with my code ${active.code}: ${shareLink}`,
                  )}`}
                  className="btn-secondary"
                >
                  Share via SMS
                </a>
              </div>
              <p className="mt-3 text-sm text-brand-mute break-all">
                Direct link:{' '}
                <a href={shareLink} className="text-brand-accent underline-hover">
                  {shareLink}
                </a>
              </p>
            </section>

            <section className="mt-8">
              <h2 className="text-xl font-extrabold">Your referrals</h2>
              {state.data.referrals.filter((r) => r.referred_worker_id).length === 0 ? (
                <p className="mt-3 text-brand-mute">
                  Nobody's signed up yet. Share your code and check back.
                </p>
              ) : (
                <ul className="mt-3 space-y-2">
                  {state.data.referrals
                    .filter((r) => r.referred_worker_id)
                    .map((r) => (
                      <li
                        key={r.id}
                        className="rounded-lg border border-brand-line bg-bg-elevated/40 p-4"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-3">
                          <p className="font-semibold text-brand-ink">
                            Referred: {r.referredFirstName || 'crew member'} —{' '}
                            {r.qualifying_gigs_completed} of {r.qualifying_threshold} gigs done
                          </p>
                          <StatusBadge status={r.status} />
                        </div>
                        <div
                          className="mt-3 h-2 w-full rounded-full bg-brand-line"
                          role="progressbar"
                          aria-valuemin={0}
                          aria-valuemax={r.qualifying_threshold}
                          aria-valuenow={Math.min(
                            r.qualifying_gigs_completed,
                            r.qualifying_threshold,
                          )}
                          aria-label={`Progress: ${r.qualifying_gigs_completed} of ${r.qualifying_threshold} gigs`}
                        >
                          <div
                            className="h-2 rounded-full bg-brand-accent transition-all"
                            style={{
                              width: `${Math.min(
                                100,
                                Math.round(
                                  (r.qualifying_gigs_completed / r.qualifying_threshold) * 100,
                                ),
                              )}%`,
                            }}
                          />
                        </div>
                        <p className="mt-2 text-[12px] text-brand-mute">
                          {r.status === 'paid'
                            ? `Paid ${formatDollars(r.payout_cents)} on ${formatDate(r.paid_at)}`
                            : r.status === 'qualified'
                              ? `Qualified ${formatDate(r.qualified_at)} — queued for next payout`
                              : r.status === 'signed_up'
                                ? `Signed up ${formatDate(r.signed_up_at)} — keep cheering`
                                : 'Pending'}
                        </p>
                      </li>
                    ))}
                </ul>
              )}
            </section>
          </>
        )}

        <section className="mt-12 rounded-xl border border-brand-line p-6 bg-bg-elevated/40">
          <h2 className="text-xl font-extrabold">Fine print</h2>
          <ul className="mt-3 space-y-2 text-sm text-brand-mute leading-relaxed">
            <li>Referred crew must pass the same screening (ID, background check, training).</li>
            <li>{GIGS} completed gigs across any service category counts toward your bonus.</li>
            <li>Bonus paid via your existing Stripe Connect account on the next monthly batch.</li>
            <li>One code per referee — duplicates auto-rejected.</li>
            <li>
              Need help?{' '}
              <a
                href="mailto:hey@bricklabor.com?subject=Crew%20referral%20question"
                className="text-brand-accent underline-hover"
              >
                hey@bricklabor.com
              </a>
              .
            </li>
          </ul>
        </section>
      </div>
    </article>
  );
}

function Stat({
  label,
  value,
  accent = false,
}: {
  label: string;
  value: string;
  accent?: boolean;
}): JSX.Element {
  return (
    <div className="card">
      <p className="eyebrow">{label}</p>
      <p
        className={`mt-2 text-3xl font-extrabold ${accent ? 'text-brand-accent' : 'text-brand-ink'}`}
      >
        {value}
      </p>
    </div>
  );
}

function StatusBadge({ status }: { status: Referral['status'] }): JSX.Element {
  const palette: Record<Referral['status'], string> = {
    pending: 'border-brand-line bg-bg-elevated text-brand-mute',
    signed_up: 'border-brand-accent/40 bg-brand-accent/10 text-brand-accent',
    qualified: 'border-brand-ok/40 bg-brand-ok/10 text-brand-ok',
    paid: 'border-brand-ok/40 bg-brand-ok/10 text-brand-ok',
    void: 'border-brand-err/40 bg-brand-err/10 text-brand-err',
  };
  const label: Record<Referral['status'], string> = {
    pending: 'Pending',
    signed_up: 'Signed up',
    qualified: 'Qualified',
    paid: 'Paid',
    void: 'Void',
  };
  return (
    <span
      className={`rounded-full border px-2 py-0.5 text-[11px] font-semibold ${palette[status]}`}
    >
      {label[status]}
    </span>
  );
}

function formatDollars(cents: number): string {
  return `$${(cents / 100).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function formatDate(iso: string | null): string {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  } catch {
    return '—';
  }
}

function setMeta(name: string, content: string, attr: 'name' | 'property' = 'name') {
  let el = document.querySelector<HTMLMetaElement>(`meta[${attr}="${name}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function setLink(rel: string, href: string) {
  let el = document.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', rel);
    document.head.appendChild(el);
  }
  el.setAttribute('href', href);
}
