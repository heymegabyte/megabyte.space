import { useThemeToolsSurface } from '../../field-service-primitives.js';
/**
 * Reusable crew showcase — horizontal row of crew member cards
 * with circular photo or initials-on-brand-bg avatar.
 *
 * Accepts a `crew` array with name, role, tenure, and optional photoUrl.
 * Renders 3-4 crew max. Uses brand colors (#060610 bg, #FF6B1A accent).
 */
import type { JSX } from 'react';

interface CrewMember {
  name: string;
  role: string;
  tenure: string;
  photoUrl?: string;
}

interface CrewShowcaseProps {
  crew: CrewMember[];
}

function initials(name: string): string {
  return name
    .split(' ')
    .map((p) => p[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
}

export const DEFAULT_CREW: CrewMember[] = [
  { name: 'Marcus J.', role: 'Lead Crew', tenure: '2yr' },
  { name: 'Darnell W.', role: 'Moving Specialist', tenure: '1yr' },
  { name: 'Kareem T.', role: 'Cleanout Pro', tenure: '3yr' },
  { name: 'Tyrone H.', role: 'Yard Work', tenure: '6mo' },
];

export function CrewShowcase({ crew }: CrewShowcaseProps): JSX.Element {
  useThemeToolsSurface('crew-showcase');
  return (
    <section
      data-testid="crew-showcase"
      className="bg-[#060610] py-12 md:py-16"
    >
      <div className="mx-auto max-w-6xl px-4">
        <h2 className="mb-10 text-center text-2xl font-bold text-white md:text-3xl">
          Meet Our Crew
        </h2>
        <p className="mx-auto mb-10 max-w-2xl text-center text-sm text-gray-400 md:text-base">
          Every job is staffed by experienced, background-checked team members
          who take pride in their work.
        </p>
        <div className="flex flex-wrap justify-center gap-6 md:gap-8">
          {crew.slice(0, 4).map((member) => (
            <div
              key={member.name}
              className="flex w-[160px] flex-col items-center text-center"
            >
              {/* Avatar */}
              <div className="mb-3 h-24 w-24 overflow-hidden rounded-full bg-brand-accent/15 md:h-28 md:w-28">
                {member.photoUrl ? (
                  <img
                    src={member.photoUrl}
                    alt={member.name}
                    width={112}
                    height={112}
                    loading="lazy"
                    decoding="async"
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-brand-accent/20 to-brand-accent/5">
                    <span className="text-2xl font-bold text-brand-accent md:text-3xl">
                      {initials(member.name)}
                    </span>
                  </div>
                )}
              </div>

              {/* Name */}
              <p className="text-sm font-semibold text-white">{member.name}</p>

              {/* Role */}
              <p className="mb-2 text-xs text-gray-400">{member.role}</p>

              {/* Tenure badge */}
              <span className="inline-block rounded-full border border-brand-accent/30 bg-brand-accent/10 px-3 py-0.5 text-[11px] font-medium text-brand-accent">
                {member.tenure}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
