import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';

interface Props {
  /**
   * Short context the callout slots into ("Newark", "your power-washing job",
   * "your existing jobs"). Appears inside the lead sentence so the CTA reads
   * like it was written for this page, not bolted on.
   */
  context?: string;
  /**
   * Visual density. `tight` is a single-line inline callout (blog footer,
   * city-page tail, services-related row). `card` is a small bordered block
   * with the same copy plus a CTA button.
   */
  variant?: 'tight' | 'card';
  /** Optional analytics tag forwarded as `data-bcl-cta`. */
  source?: string;
  className?: string;
}

/**
 * Tasteful "you have a dashboard" reminder reused across blog posts, city
 * pages, and service detail surfaces. Single line of copy + CTA, never a
 * loud banner — the goal is to seed the discovery, not steal attention from
 * the page's primary action.
 *
 * Links to `/me` directly: MePage handles unauthenticated visitors by
 * rendering a sign-in path, so anyone can land there safely.
 */
export function DashboardCallout({
  context,
  variant = 'tight',
  source = 'inline',
  className,
}: Props) {
  useThemeToolsSurface('dashboard-callout');
  const lead = context ? `Already booked ${context}?` : 'Already a Brick Labor customer?';
  // Keep a mirror-locale visitor in /es · /pt: localize the dashboard/sign-in hrefs.
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const lp = (p: string) => (p.startsWith('/') ? localizedPath(locale, p) : p);

  if (variant === 'card') {
    return (
      <aside
        className={`mx-auto mt-12 max-w-3xl rounded-2xl border border-brand-accent/40 bg-brand-accent/5 p-6 ${className ?? ''}`}
        data-bcl-cta={`dashboard-callout-${source}`}
      >
        <p className="eyebrow mb-2">Your dashboard</p>
        <h2 className="font-display text-xl font-extrabold">
          Manage every job in one Google-Calendar-style screen.
        </h2>
        <p className="mt-2 text-brand-mute">
          {lead} Reschedule, message the crew, see what's next — all in your{' '}
          <a href={lp('/me')} className="text-brand-accent underline-hover">
            calendar dashboard
          </a>
          . SMS reminders before every visit. Installs to your phone like a real app.
        </p>
        <div className="mt-4 flex flex-wrap gap-3">
          <a href={lp('/me')} className="btn-primary" data-bcl-cta={`dashboard-${source}-primary`}>
            Open your dashboard →
          </a>
          <a
            href={lp('/login?as=customer&next=%2Fme')}
            className="btn-ghost"
            data-bcl-cta={`dashboard-${source}-signin`}
          >
            Sign in by SMS
          </a>
        </div>
      </aside>
    );
  }

  return (
    <p
      className={`mx-auto mt-10 max-w-3xl text-sm text-brand-mute ${className ?? ''}`}
      data-bcl-cta={`dashboard-callout-${source}`}
    >
      <span aria-hidden className="mr-1.5">
        📅
      </span>
      {lead} Open your{' '}
      <a
        href={lp('/me')}
        className="text-brand-accent underline-hover font-semibold"
        data-bcl-cta={`dashboard-${source}-link`}
      >
        Google-Calendar-style dashboard
      </a>{' '}
      — reschedule, message your crew, drag jobs around your calendar.{' '}
      <a
        href={lp('/me')}
        className="text-brand-accent underline-hover whitespace-nowrap"
        data-bcl-cta={`dashboard-${source}-arrow`}
      >
        Open /me →
      </a>
    </p>
  );
}
