import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect, useState } from 'react';
import { RollingCounter } from './RollingCounter.js';

interface DonationTotals {
  totalCents: number;
  yearCents: number;
  byMonth: Array<{ month: string; cents: number; count: number }>;
  computedAt: string;
}

interface Props {
  // Force a fixed year label (defaults to current UTC year). Useful for tests
  // and for the integrator if a fiscal-year override is ever needed.
  yearLabel?: number | string;
  // Inline placement (no card wrapper) — used inside hero strip when the
  // integrator wants a one-liner instead of the framed call-out.
  inline?: boolean;
}

/**
 * Homepage strip — "Brick Labor has donated $X,XXX to NJ affordable
 * housing this year." Pulls from /api/donations/total (KV-cached 1h) and
 * gracefully degrades when the endpoint is unreachable or empty (renders
 * nothing — never a "$0" placeholder, never a broken promise).
 *
 * Mounted by the integrator on the homepage. Reads zero query params, has
 * zero props (default form). Safe to mount on routes other than `/` —
 * suppressed visually when amount is zero.
 */
export function DonationCounter({ yearLabel, inline = false }: Props): JSX.Element | null {
  useThemeToolsSurface('donation-counter');
  const [totals, setTotals] = useState<DonationTotals | null>(null);
  const [errored, setErrored] = useState(false);

  useEffect(() => {
    let cancelled = false;
    fetch('/api/donations/total', { headers: { accept: 'application/json' } })
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error(`http_${r.status}`))))
      .then((data: { ok: boolean } & DonationTotals) => {
        if (cancelled) return;
        if (data?.ok) setTotals(data);
        else setErrored(true);
      })
      .catch(() => {
        if (cancelled) return;
        setErrored(true);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (errored || !totals) return null;
  if (totals.yearCents <= 0) return null;

  const year = yearLabel ?? new Date().getUTCFullYear();
  const dollars = formatDollars(totals.yearCents);
  // Numeric form for the animated count-up; whole-dollars over $1k read cleaner
  // than cents, matching formatDollars's own rounding (used for the aria-label).
  const dollarsNum = totals.yearCents / 100;
  const dollarDecimals = dollarsNum >= 1000 ? 0 : 2;
  const monthCount = totals.byMonth?.length ?? 0;

  const innerCopy = (
    <>
      Brick Labor has donated{' '}
      <strong className="text-brand-accent">
        <RollingCounter value={dollarsNum} prefix="$" decimals={dollarDecimals} />
      </strong>{' '}
      to NJ affordable housing in {year}.
      {monthCount > 1 ? (
        <span className="text-brand-mute"> Updated monthly · 100% goes to vetted partners.</span>
      ) : null}
    </>
  );

  if (inline) {
    return (
      <p
        className="text-sm text-brand-mute"
        aria-label={`Brick Labor has donated ${dollars} to NJ affordable housing in ${year}.`}
        data-animate="fade-up"
      >
        {innerCopy}
      </p>
    );
  }

  return (
    <aside
      className="my-8 rounded-xl border border-brand-accent/30 bg-brand-accent/5 p-4 text-sm leading-relaxed text-brand-ink"
      aria-label="Donation counter"
      data-animate="fade-up"
    >
      <div className="flex items-start gap-3">
        <span
          aria-hidden
          className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-brand-accent/15 text-brand-accent"
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth={1.8}
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-5 w-5"
          >
            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
          </svg>
        </span>
        <div>
          <p>{innerCopy}</p>
          <p className="mt-2 text-[12px] text-brand-mute">
            Every completed move triggers a small donation. See{' '}
            <a href="/sources" className="text-brand-accent underline-hover">
              our sources
            </a>{' '}
            for our nonprofit partner list.
          </p>
        </div>
      </div>
    </aside>
  );
}

function formatDollars(cents: number): string {
  const dollars = cents / 100;
  if (dollars >= 1000) {
    return `$${dollars.toLocaleString('en-US', { maximumFractionDigits: 0 })}`;
  }
  return `$${dollars.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}
