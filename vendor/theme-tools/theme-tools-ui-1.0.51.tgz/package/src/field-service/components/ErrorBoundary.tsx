import { useThemeToolsSurface } from '../../field-service-primitives.js';
/**
 * ErrorBoundary.tsx — the app-root React error boundary.
 *
 * Wraps `<App/>` in main.tsx. Before this, an uncaught render exception
 * unmounted the whole tree → a WHITE SCREEN with no recovery path (Sentry
 * *reported* it but could not *prevent* it), on every route including a
 * customer mid-booking. This converts that into either:
 *   - a silent auto-reload, when the cause is a stale code-split chunk after a
 *     deploy (the deploy-often SPA's #1 recoverable white-screen), or
 *   - a branded, dark, keyboard-reachable recovery card for a genuine crash.
 *
 * The decision logic + i18n copy are pure + unit-tested in
 * `src/shared/error-boundary.ts`; this file is the thin React shell + the
 * (inline-styled, so it survives a broken CSS chunk) fallback UI.
 */
import { Component, type CSSProperties, type ErrorInfo, type ReactNode } from 'react';
import {
  type AppErrorKind,
  type ErrorBoundaryCopy,
  classifyAppError,
  errorBoundaryCopy,
  makeSupportRef,
  shouldAutoReloadForChunk,
} from '@theme.tools/i18n-a11y/field-service/error-boundary';
import { PHONE_DISPLAY, PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';
import { stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { captureBoundaryError } from '@theme.tools/telemetry/field-service/sentry-browser';

/** sessionStorage key tracking the last chunk auto-reload (loop guard). */
const RELOAD_KEY = 'bcl_chunk_reload_at';

/** Automatic recovery is safe only when the cooldown survives navigation. */
function claimChunkReload(now: number): boolean {
  try {
    // Even reading the global can throw in storage-restricted contexts.
    if (typeof sessionStorage === 'undefined') return false;
    const storage = sessionStorage;
    const raw = storage.getItem(RELOAD_KEY);
    const parsed = raw == null ? null : Number(raw);
    const lastReload = parsed != null && Number.isFinite(parsed) ? parsed : null;
    if (!shouldAutoReloadForChunk(now, lastReload)) return false;
    const marker = String(now);
    storage.setItem(RELOAD_KEY, marker);
    return storage.getItem(RELOAD_KEY) === marker;
  } catch {
    // Keep manual recovery available when no persistent loop guard is possible.
    return false;
  }
}

function currentLocale(): 'en' | 'es' | 'pt' {
  if (typeof window === 'undefined') return 'en';
  try {
    return stripLocalePrefix(window.location.pathname).locale;
  } catch {
    return 'en';
  }
}

function randomHex(): string {
  try {
    const c = (globalThis as { crypto?: Crypto }).crypto;
    if (c?.getRandomValues) {
      const a = new Uint8Array(3);
      c.getRandomValues(a);
      return Array.from(a, (b) => b.toString(16).padStart(2, '0')).join('');
    }
  } catch {
    /* fall through */
  }
  return 'bcl0';
}

interface Props {
  readonly children: ReactNode;
}
interface State {
  readonly kind: AppErrorKind | null;
  readonly ref: string;
}

export class ErrorBoundary extends Component<Props, State> {
  override state: State = { kind: null, ref: '' };

  static getDerivedStateFromError(error: unknown): Partial<State> {
    return { kind: classifyAppError(error) };
  }

  override componentDidCatch(error: unknown, info: ErrorInfo): void {
    const kind = classifyAppError(error);
    const now = typeof Date !== 'undefined' ? Date.now() : 0;
    const ref = makeSupportRef(randomHex(), now);
    this.setState({ ref });
    captureBoundaryError(error, {
      errorBoundary: 'app-root',
      kind,
      ref,
      componentStack: info?.componentStack ?? '',
      path: typeof window !== 'undefined' ? window.location.pathname : '',
    });
    if (kind === 'chunk') this.maybeAutoReload(now);
  }

  private maybeAutoReload(now: number): void {
    if (typeof window === 'undefined') return;
    if (claimChunkReload(now)) {
      window.location.reload();
    }
  }

  private handleReload = (): void => {
    if (typeof window !== 'undefined') window.location.reload();
  };

  private handleHome = (): void => {
    if (typeof window !== 'undefined') window.location.assign('/');
  };

  override render(): ReactNode {
    const { kind, ref } = this.state;
    if (kind == null) return this.props.children;
    return (
      <ErrorFallback
        kind={kind}
        copy={errorBoundaryCopy(currentLocale())}
        refId={ref}
        onReload={this.handleReload}
        onHome={this.handleHome}
      />
    );
  }
}

// ── Inline styles ───────────────────────────────────────────────────────────
// Inline (not a CSS class) on purpose: a `chunk` error can mean the app's CSS
// chunk ALSO failed to load, so the recovery card must style itself with zero
// external-stylesheet dependency.
const ACCENT = '#ff6b1a';
const BG = '#0a0e14';
const CARD = '#11161f';
const INK = '#f4f4f5';
const MUTE = '#9ca3af';

const wrapStyle: CSSProperties = {
  minHeight: '70vh',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  padding: '2rem 1.25rem',
  background: BG,
  color: INK,
  fontFamily: "'Geist', 'Space Grotesk', system-ui, -apple-system, Segoe UI, Roboto, sans-serif",
};
const cardStyle: CSSProperties = {
  maxWidth: '34rem',
  width: '100%',
  background: CARD,
  border: '1px solid rgba(255,107,26,0.25)',
  borderRadius: '1rem',
  padding: '2rem',
  boxShadow: '0 24px 60px -24px rgba(0,0,0,0.7)',
  textAlign: 'center',
};
const titleStyle: CSSProperties = {
  fontSize: 'clamp(1.4rem, 4vw, 1.9rem)',
  fontWeight: 700,
  margin: '0 0 0.75rem',
  lineHeight: 1.15,
};
const bodyStyle: CSSProperties = {
  color: MUTE,
  fontSize: '1rem',
  lineHeight: 1.6,
  margin: '0 0 1.5rem',
};
const actionsStyle: CSSProperties = {
  display: 'flex',
  flexWrap: 'wrap',
  gap: '0.6rem',
  justifyContent: 'center',
};
const primaryBtn: CSSProperties = {
  appearance: 'none',
  border: 'none',
  cursor: 'pointer',
  background: ACCENT,
  color: BG,
  fontWeight: 700,
  fontSize: '0.95rem',
  padding: '0.7rem 1.25rem',
  borderRadius: '0.6rem',
  textDecoration: 'none',
  minWidth: '44px',
  minHeight: '44px',
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
};
const secondaryBtn: CSSProperties = {
  appearance: 'none',
  cursor: 'pointer',
  background: 'transparent',
  color: INK,
  fontWeight: 600,
  fontSize: '0.95rem',
  padding: '0.7rem 1.25rem',
  borderRadius: '0.6rem',
  border: '1px solid rgba(244,244,245,0.25)',
  textDecoration: 'none',
  minWidth: '44px',
  minHeight: '44px',
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
};
const refStyle: CSSProperties = {
  marginTop: '1.5rem',
  fontSize: '0.8rem',
  color: MUTE,
  fontFamily: "'JetBrains Mono', ui-monospace, SFMono-Regular, Menlo, monospace",
};

export interface ErrorFallbackProps {
  readonly kind: AppErrorKind;
  readonly copy: ErrorBoundaryCopy;
  readonly refId: string;
  readonly onReload: () => void;
  readonly onHome: () => void;
}

/**
 * Presentational recovery card — exported so the markup (role=alert, CTAs,
 * tel href, reference id) is directly unit-testable via `renderToStaticMarkup`.
 */
export function ErrorFallback({
  kind,
  copy,
  refId,
  onReload,
  onHome,
}: ErrorFallbackProps): ReactNode {
  useThemeToolsSurface('error-boundary');
  const isChunk = kind === 'chunk';
  const title = isChunk ? copy.chunkTitle : copy.title;
  const body = isChunk ? copy.chunkBody : copy.body;
  return (
    <div style={wrapStyle} role="alert" aria-live="assertive" data-testid="app-error-boundary">
      <div style={cardStyle}>
        <div aria-hidden="true" style={{ fontSize: '2.25rem', marginBottom: '0.5rem' }}>
          🧱
        </div>
        <h1 style={titleStyle}>{title}</h1>
        <p style={bodyStyle}>{body}</p>
        <div style={actionsStyle}>
          <button type="button" style={primaryBtn} onClick={onReload} data-testid="error-reload">
            {copy.reload}
          </button>
          {!isChunk && (
            <>
              <button type="button" style={secondaryBtn} onClick={onHome} data-testid="error-home">
                {copy.home}
              </button>
              <a style={secondaryBtn} href={PHONE_TEL_HREF} data-testid="error-call">
                {copy.call} · {PHONE_DISPLAY}
              </a>
            </>
          )}
        </div>
        {!isChunk && refId ? (
          <p style={refStyle}>
            {copy.refLabel}: {refId}
          </p>
        ) : null}
      </div>
    </div>
  );
}
