import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect, useRef, useState } from 'react';
import { useRovingTabs } from '../use-roving-radio.js';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { faqCopy } from '@theme.tools/i18n-a11y/field-service/faq-copy';
import { faqPage } from '@theme.tools/seo-geo/field-service/schemas';
import { useSoleFaqPage } from './seo/sole-faqpage.js';
import { PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';
import {
  CANONICAL_SERVICE_SLUGS,
  resolveServiceAlias,
  type CanonicalServiceSlug,
} from '@theme.tools/seo-geo/field-service/service-slug-aliases';
import { buildCustomerPrepChecklist } from '@theme.tools/scheduling/field-service/theme-tools-field-service-bridge';

/**
 * Structural FAQ data — locale-invariant. The per-item hrefs (and the order the
 * questions render in) stay constant across locales; the visitor-facing
 * question, answer, and per-link labels come from `faqCopy(locale).items[slug]`,
 * zipped on by stable slug. `links` here are positional with the localized
 * `links` label array. See `src/shared/faq-copy.mjs`.
 */
interface FaqStruct {
  /** Stable slug — the key into `faqCopy(locale).items`. */
  readonly slug: string;
  /** Per-answer link hrefs, positional with the localized link labels. */
  readonly hrefs: readonly string[];
}

const FAQ_STRUCT: readonly FaqStruct[] = [
  {
    slug: 'pricing',
    hrefs: ['/blog/fifty-dollar-hour-per-person-philosophy', '/#pricing', '/sources'],
  },
  {
    slug: 'licensed',
    hrefs: ['/blog/casual-labor-vs-licensed-contractor', '/services/light-repairs', '/#about'],
  },
  { slug: 'availability', hrefs: ['/blog/evenings-and-weekends-newark-property-crew', '/book'] },
  { slug: 'upfront', hrefs: ['/book', '/privacy'] },
  {
    slug: 'areas',
    hrefs: ['/c/newark', '/c/jersey-city', '/c/paterson', '/c/elizabeth', '/#coverage'],
  },
  { slug: 'crew-size', hrefs: ['/services/hauling', '/services/power-washing', '/book'] },
  { slug: 'recurring', hrefs: ['/#contact', PHONE_TEL_HREF, '/services/lawn-care'] },
  { slug: 'day-rates', hrefs: ['/#contact', '/blog/appliance-haul-away-newark'] },
  {
    slug: 'equipment',
    hrefs: ['/blog/driveway-power-washing-equipment', '/services/power-washing'],
  },
  { slug: 'uhaul', hrefs: ['/book', '/services/hauling', '/sources'] },
  { slug: 'speed', hrefs: ['/book', PHONE_TEL_HREF] },
  { slug: 'quote', hrefs: ['/#contact', 'mailto:hey@bricklabor.com', '/#testimonials'] },
  { slug: 'overrun', hrefs: ['/book', '/terms'] },
];

/** "Dig deeper" sidebar hrefs — positional with `faqCopy(locale).digDeeperLinks`. */
const DIG_DEEPER_HREFS: readonly string[] = [
  '/blog/fifty-dollar-hour-per-person-philosophy',
  '/blog/casual-labor-vs-licensed-contractor',
  '/blog/evenings-and-weekends-newark-property-crew',
  '/blog/driveway-power-washing-equipment',
  '/blog/appliance-haul-away-newark',
  '/blog',
];

/** DOM id for a question's `<details>` — the deep-link/permalink anchor target. */
const faqAnchorId = (slug: string) => `faq-${slug}`;

export function FAQ() {
  useThemeToolsSurface('faq');
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const t = faqCopy(locale);
  // Keep a mirror-locale visitor in /es · /pt: localize internal `/` hrefs
  // (incl. `/#pricing` homepage anchors); leave mailto:/tel:/external bare.
  const lp = (path: string) => (path.startsWith('/') ? localizedPath(locale, path) : path);

  // This rendered FAQPage (below, inside #root) is the canonical one. Drop the
  // stale prerendered <head> FAQPage so the page ships exactly one — two
  // (@id-less) FAQPage nodes make Google suppress the FAQ rich result.
  useSoleFaqPage();

  // Which question's permalink was just copied (transient confirmation pill).
  const [copiedSlug, setCopiedSlug] = useState<string | null>(null);
  const [activePrepCategory, setActivePrepCategory] =
    useState<CanonicalServiceSlug>('moving-labor');
  const prepTab = useRovingTabs(CANONICAL_SERVICE_SLUGS.length, (i) =>
    setActivePrepCategory(CANONICAL_SERVICE_SLUGS[i] ?? 'moving-labor'),
  );
  const prepPlan = buildCustomerPrepChecklist(activePrepCategory, 'Newark', false);
  const copiedTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Deep-link: when the URL carries `#faq-<slug>` (a shared permalink, an AI
  // search citation, or a Google jump-to-answer), open that exact question and
  // scroll it into view. Runs on mount AND on every hashchange so in-page
  // permalink navigation works without a reload. App.tsx's global scrollToHash
  // also resolves the id; opening first guarantees the answer is visible.
  useEffect(() => {
    const slugs = new Set(FAQ_STRUCT.map((f) => f.slug));
    const openFromHash = () => {
      const raw = window.location.hash.slice(1);
      if (!raw.startsWith('faq-')) return;
      const slug = raw.slice('faq-'.length);
      if (!slugs.has(slug)) return;
      const el = document.getElementById(faqAnchorId(slug));
      if (!(el instanceof HTMLDetailsElement)) return;
      el.open = true;
      const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      el.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
    };
    openFromHash();
    window.addEventListener('hashchange', openFromHash);
    return () => window.removeEventListener('hashchange', openFromHash);
  }, []);

  useEffect(
    () => () => {
      if (copiedTimer.current) clearTimeout(copiedTimer.current);
    },
    [],
  );

  const copyPermalink = (slug: string) => {
    // Permalink mirrors the visitor's current locale path (FAQ only renders on
    // `/`, `/es`, `/pt`) so a shared link lands the recipient in the same
    // language on the same answer.
    const url = `${window.location.origin}${window.location.pathname}#${faqAnchorId(slug)}`;
    const done = () => {
      // Reflect the permalink in the address bar without a history entry so the
      // open question is itself shareable/bookmarkable after the copy.
      history.replaceState(null, '', `#${faqAnchorId(slug)}`);
      setCopiedSlug(slug);
      if (copiedTimer.current) clearTimeout(copiedTimer.current);
      copiedTimer.current = setTimeout(() => setCopiedSlug(null), 1800);
    };
    if (navigator.clipboard?.writeText) {
      navigator.clipboard.writeText(url).then(done, done);
    } else {
      done();
    }
  };

  return (
    <section id="faq" className="section">
      <div className="container-pad">
        <div className="mb-12 max-w-3xl" data-animate="fade-up">
          <p className="eyebrow mb-3">{t.eyebrow}</p>
          <h2 className="text-4xl sm:text-5xl font-extrabold">
            {t.headlineMain}
            <span className="text-gradient">{t.headlineAccent}</span>
          </h2>
        </div>
        <div className="grid gap-3 max-w-3xl" data-stagger="60">
          {FAQ_STRUCT.map((f) => {
            const item = t.items[f.slug] ?? faqCopy('en').items[f.slug]!;
            const copied = copiedSlug === f.slug;
            return (
              <details
                key={f.slug}
                id={faqAnchorId(f.slug)}
                data-animate="fade-up"
                className="group rounded-xl border border-brand-line bg-bg-elevated transition-colors hover:border-brand-accent open:border-brand-accent target:border-brand-accent"
              >
                <summary className="flex cursor-pointer items-center justify-between gap-3 px-5 py-4 font-display font-semibold list-none">
                  <span data-faq-question>{item.q}</span>
                  {/* Chevron only — the copy-link control lives in the answer
                      body, NOT here. A <summary> is itself interactive, so an
                      interactive button nested inside it is a `nested-interactive`
                      WCAG 4.1.2 violation. Decorative chevron is aria-hidden. */}
                  <svg
                    viewBox="0 0 24 24"
                    className="h-5 w-5 shrink-0 text-brand-accent transition-transform group-open:rotate-180"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth={2}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden
                  >
                    <path d="M6 9l6 6 6-6" />
                  </svg>
                </summary>
                <div className="px-5 pb-5 text-sm leading-relaxed text-brand-mute">
                  <p data-faq-answer>{item.a}</p>
                  {f.hrefs.length > 0 && (
                    <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs">
                      {f.hrefs.map((href, i) => (
                        <a
                          key={href + i}
                          href={lp(href)}
                          className="text-brand-accent underline-hover font-mono"
                        >
                          {item.links[i] ?? faqCopy('en').items[f.slug]!.links[i]}
                        </a>
                      ))}
                    </div>
                  )}
                  {/* Permalink action — a labeled pill in the revealed body, so
                      it carries a visible accessible name and is never an
                      interactive descendant of the <summary>. */}
                  <button
                    type="button"
                    onClick={() => copyPermalink(f.slug)}
                    aria-label={copied ? t.copiedLabel : t.copyLinkLabel}
                    data-testid={`faq-copylink-${f.slug}`}
                    data-copied={copied ? 'true' : 'false'}
                    className={`mt-4 inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium transition-all duration-[333ms] hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent ${
                      copied
                        ? 'border-brand-accent bg-brand-accent/15 text-brand-accent'
                        : 'border-brand-line text-brand-mute hover:border-brand-accent hover:text-brand-accent'
                    }`}
                  >
                    <span aria-hidden>{copied ? '✓' : '🔗'}</span>
                    <span>{copied ? t.copiedLabel : t.copyLinkLabel}</span>
                  </button>
                </div>
              </details>
            );
          })}
        </div>

        <div
          className="mt-10 max-w-3xl rounded-xl border border-brand-line bg-bg-elevated/60 p-5"
          data-testid="faq-category-prep-explorer"
        >
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <p className="font-mono text-[11px] uppercase tracking-wider text-brand-accent">
                Pre-Arrival Preparation & Curb Guide
              </p>
              <h3 className="font-display text-lg font-bold text-brand-ink">
                24h–48h Customer Checklist by Service Category
              </h3>
            </div>
            <span className="rounded-full border border-brand-accent/30 bg-brand-accent/10 px-3 py-1 font-mono text-xs text-brand-accent">
              Curb clearance: {prepPlan.curbClearance.requiredCurbLengthFt} ft
            </span>
          </div>
          <div
            className="mt-3 flex flex-wrap gap-1.5"
            role="tablist"
            aria-label="Service category preparation checklists"
          >
            {CANONICAL_SERVICE_SLUGS.map((slug, idx) => {
              const selected = slug === activePrepCategory;
              const label = resolveServiceAlias(slug)?.displayName ?? slug;
              return (
                <button
                  key={slug}
                  type="button"
                  {...prepTab(idx, selected)}
                  onClick={() => setActivePrepCategory(slug)}
                  className={`min-h-[44px] rounded-lg border px-3 py-1.5 text-xs font-medium transition ${
                    selected
                      ? 'border-brand-accent bg-brand-accent/15 text-brand-accent'
                      : 'border-brand-line bg-bg-primary text-brand-mute hover:border-brand-accent/50 hover:text-brand-ink'
                  }`}
                >
                  {label}
                </button>
              );
            })}
          </div>
          <ul className="mt-4 grid gap-2 text-sm text-brand-mute">
            {prepPlan.items.map((item) => (
              <li
                key={item.id}
                className="flex items-start gap-2 rounded-lg border border-brand-line/60 bg-bg-primary/60 px-3 py-2"
              >
                <span className="mt-0.5 font-mono text-xs font-bold text-brand-accent">
                  -{item.windowHoursBefore}h
                </span>
                <span className="text-brand-ink">{item.label}</span>
              </li>
            ))}
          </ul>
          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-brand-mute">
            <span>{prepPlan.curbClearance.recommendations[0]}</span>
            <a
              href={lp(`/services/${activePrepCategory}#category-calculator`)}
              className="font-mono text-brand-accent underline-hover"
            >
              Open {resolveServiceAlias(activePrepCategory)?.displayName ?? activePrepCategory}{' '}
              Calculator →
            </a>
          </div>
        </div>

        <div className="mt-10 grid gap-4 max-w-3xl sm:grid-cols-2" data-animate="fade-up">
          <div className="rounded-xl border border-brand-line bg-bg-elevated/40 px-5 py-4">
            <p className="font-display text-sm font-bold uppercase tracking-wider text-brand-ink">
              {t.digDeeperHeading}
            </p>
            <ul className="mt-3 grid gap-2 text-sm">
              {DIG_DEEPER_HREFS.map((href, i) => (
                <li key={href}>
                  <a
                    href={lp(href)}
                    className="text-brand-mute underline-hover hover:text-brand-accent"
                  >
                    {t.digDeeperLinks[i] ?? faqCopy('en').digDeeperLinks[i]}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-xl border border-brand-line bg-bg-elevated/40 px-5 py-4">
            <p className="font-display text-sm font-bold uppercase tracking-wider text-brand-ink">
              {t.unansweredHeading}
            </p>
            <p className="mt-3 text-sm text-brand-mute">
              {t.unansweredPre}
              <a href={lp('/#contact')} className="text-brand-accent underline-hover">
                {t.unansweredContactLabel}
              </a>
              {t.unansweredMid}
              <a href={PHONE_TEL_HREF} className="text-brand-accent underline-hover">
                (855) 82LABOR
              </a>
              {t.unansweredEmailJoin}
              <a href="mailto:hey@bricklabor.com" className="text-brand-accent underline-hover">
                hey@bricklabor.com
              </a>
              {t.unansweredPost}
            </p>
            <div className="mt-4 flex flex-wrap gap-2 text-xs">
              <a href={lp('/book')} className="btn-primary">
                {t.btnBook}
              </a>
              <a href={lp('/#testimonials')} className="btn-ghost">
                {t.btnReviews}
              </a>
              <a href={lp('/sources')} className="btn-ghost">
                {t.btnCitations}
              </a>
            </div>
          </div>
        </div>
      </div>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          // Shared faqPage() helper so the homepage FAQ stays in lockstep with
          // the city/service generators. `speakable` marks the quotable region
          // for voice assistants + AI search (highest AI-citation surface).
          // Scope the spoken region to the question text + answer — NOT the
          // whole `<summary>` (which now also holds the decorative copy-link
          // glyph + chevron), so an assistant never reads "🔗" aloud.
          __html: JSON.stringify(
            faqPage(
              FAQ_STRUCT.map((f) => {
                const item = t.items[f.slug] ?? faqCopy('en').items[f.slug]!;
                return { q: item.q, a: item.a };
              }),
              ['#faq [data-faq-question]', '#faq [data-faq-answer]'],
            ),
          ),
        }}
      />
    </section>
  );
}
