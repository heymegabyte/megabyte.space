import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { type JSX } from 'react';
import { stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { floatingCtaCopy } from '@theme.tools/i18n-a11y/field-service/floating-cta-copy';
import { PHONE_TEL_HREF, PHONE_DISPLAY } from '@theme.tools/i18n-a11y/field-service/contact-phone';

/**
 * FloatingCallButton — a gorgeous click-to-call phone PILL fixed to the
 * bottom-LEFT of the screen (the AI Chat launcher owns bottom-right). It is the
 * site's only phone CTA (the in-navbar number was deliberately removed —
 * Header.tsx:79). One tap dials Brick Labor.
 *
 * The number `(855) 82LABOR` is rendered VISIBLY at every breakpoint — not just
 * an icon. Mobile is the dominant device for a local labor business, and a
 * customer needs to SEE/verify the local number before tapping (the old
 * icon-only FAB hid the number behind `sr-only` + a `hidden sm:block` tooltip,
 * a trust + conversion gap on the money-path entry). The localized call verb
 * shows alongside the number from `sm:` up so the pill stays compact on phones.
 *
 * Brand-locked: accent ring, animated ping halo, 0.333s hover lift, focus-visible
 * ring, ≥44px tap target, reduced-motion-safe.
 *
 * Localized: the call verb + aria-label render in the active mirror locale
 * (`en` · `es` · `pt`) so the /es + /pt money-loop visitor reads the affordance
 * in-language. The phone label is a brand string — never translated. Copy lives
 * in `src/shared/floating-cta-copy.ts`.
 */
/** Dial value + vanity label are single-sourced in `shared/contact-phone`. */
const PHONE_LABEL = PHONE_DISPLAY;

export function FloatingCallButton(): JSX.Element {
  useThemeToolsSurface('floating-call-button');
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const t = floatingCtaCopy(locale);
  return (
    <aside
      aria-label="Call Brick Labor"
      className="fixed bottom-5 left-4 lg:left-auto lg:right-20 lg:bottom-5 z-[100] print:hidden"
    >
      <a
        href={PHONE_TEL_HREF}
        data-bcl-phone-cta="floating"
        aria-label={t.ariaCall(PHONE_LABEL)}
        className="group relative inline-flex min-h-[44px] h-12 items-center gap-2 rounded-full border border-brand-accent/40 bg-bg-elevated/95 px-4 text-brand-accent shadow-2xl backdrop-blur transition-all duration-[333ms] hover:-translate-y-0.5 hover:scale-105 hover:border-brand-accent hover:bg-brand-accent hover:text-bg-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent focus-visible:ring-offset-2 focus-visible:ring-offset-bg-primary"
      >
        {/* Animated halo — pulses to draw the eye, killed under reduced-motion. */}
        <span
          aria-hidden
          className="pointer-events-none absolute inset-0 rounded-full bg-brand-accent/20 motion-safe:animate-ping motion-reduce:hidden"
        />
        <PhoneIcon />
        {/* Localized verb — visible from sm: up so phones keep a compact pill. */}
        <span className="hidden text-[11px] font-semibold uppercase tracking-wider sm:inline">
          {t.call}
        </span>
        {/* The number — ALWAYS visible (mobile included). Brand string, untranslated. */}
        <span className="relative whitespace-nowrap font-mono text-sm font-bold tracking-tight">
          {PHONE_LABEL}
        </span>
      </a>
    </aside>
  );
}

function PhoneIcon(): JSX.Element {
  return (
    <svg
      viewBox="0 0 24 24"
      className="relative h-6 w-6 transition-transform duration-[333ms] group-hover:rotate-[12deg]"
      fill="none"
      stroke="currentColor"
      strokeWidth={2.1}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z" />
    </svg>
  );
}
