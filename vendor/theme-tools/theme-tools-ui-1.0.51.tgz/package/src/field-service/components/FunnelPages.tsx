import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { useEffect, type JSX } from 'react';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { funnelPagesCopy, type FunnelPagesCopy } from '@theme.tools/i18n-a11y/field-service/funnel-pages-copy';
import { QuoteAreaMap } from './QuoteAreaMap.js';
import { PHONE_TEL_HREF, PHONE_SMS_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';

/**
 * Conversion-focused funnel landing pages: /schedule, /quote, /emergency-labor.
 *
 * Each page is a tight SEO-clean landing that frames the booking flow for a
 * specific intent. The booking form itself lives at /#book on the homepage
 * (the canonical conversion surface) — these pages provide the intent-matched
 * hero + trust strip + 3-step explainer + FAQ, then route the user to /#book
 * with UTM-style query tokens so analytics can attribute the source funnel.
 *
 * All chrome reads `funnelPagesCopy(locale)` so a /es or /pt visitor sees the
 * page in-language (single source of truth shared with the build via the
 * `.mjs` copy module); every internal href runs through `localizedPath` so a
 * mirror-locale visitor stays in their locale.
 *
 * Naming convention: SchedulePage, QuotePage, EmergencyLaborPage —
 * matched by route in src/web/App.tsx.
 */

/** Resolve the active locale from the URL (SSR-safe → `en`). */
function activeLocale(): 'en' | 'es' | 'pt' {
  return typeof window === 'undefined'
    ? 'en'
    : stripLocalePrefix(window.location.pathname).locale;
}

function setMeta(name: string, content: string, key: 'name' | 'property' = 'name'): void {
  let el = document.head.querySelector<HTMLMetaElement>(`meta[${key}="${name}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(key, name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function setTitle(title: string): void {
  document.title = title;
}

function useFunnelMeta(args: {
  readonly path: string;
  readonly title: string;
  readonly description: string;
  readonly ogImage: string;
}): void {
  useEffect(() => {
    const code = activeLocale();
    const url = `https://bricklabor.com${localizedPath(code, args.path)}`;
    setTitle(args.title);
    setMeta('description', args.description);
    setMeta('og:title', args.title, 'property');
    setMeta('og:description', args.description, 'property');
    setMeta('og:url', url, 'property');
    setMeta('og:image', `https://bricklabor.com${args.ogImage}`, 'property');
    setMeta('og:image:secure_url', `https://bricklabor.com${args.ogImage}`, 'property');
    setMeta('og:image:width', '1200', 'property');
    setMeta('og:image:height', '630', 'property');
    setMeta('og:image:type', 'image/png', 'property');
    setMeta('twitter:title', args.title);
    setMeta('twitter:description', args.description);
    setMeta('twitter:image', `https://bricklabor.com${args.ogImage}`);
    let canonical = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.rel = 'canonical';
      document.head.appendChild(canonical);
    }
    canonical.href = url;
  }, [args.path, args.title, args.description, args.ogImage]);
}

/** The six shared service links — labels localized, hrefs locale-prefixed. */
function commonLinks(
  copy: FunnelPagesCopy,
  lp: (path: string) => string,
): ReadonlyArray<{ readonly label: string; readonly href: string }> {
  const cl = copy.commonLinks;
  return [
    { label: cl.movingLabor, href: lp('/services/moving-labor') },
    { label: cl.apartmentCleanout, href: lp('/services/apartment-cleanout') },
    { label: cl.hauling, href: lp('/services/hauling') },
    { label: cl.loadingUnloading, href: lp('/services/loading-unloading') },
    { label: cl.furnitureRemoval, href: lp('/services/furniture-removal') },
    { label: cl.coverageMap, href: lp('/#coverage') },
  ];
}

function Section({
  eyebrow,
  title,
  children,
}: {
  eyebrow?: string;
  title: string;
  children: React.ReactNode;
}): JSX.Element {
  return (
    <section className="py-12 sm:py-16 border-b border-brand-line/40">
      <div className="container-pad">
        {eyebrow && (
          <p className="font-mono text-[11px] uppercase tracking-wider text-brand-accent mb-3">
            {eyebrow}
          </p>
        )}
        <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight mb-6">{title}</h2>
        {children}
      </div>
    </section>
  );
}

function ServiceLinkGrid({
  links,
}: {
  links: ReadonlyArray<{ readonly label: string; readonly href: string }>;
}): JSX.Element {
  return (
    <ul className="grid grid-cols-2 sm:grid-cols-3 gap-3">
      {links.map((l) => (
        <li key={l.href}>
          <a
            href={l.href}
            className="block px-4 py-3 rounded-md border border-brand-line bg-bg-elevated/60 hover:bg-brand-accent hover:text-bg-primary hover:border-brand-accent transition-colors text-sm font-medium"
          >
            {l.label} →
          </a>
        </li>
      ))}
    </ul>
  );
}

function RelatedLinks({
  copy,
  lp,
}: {
  copy: FunnelPagesCopy;
  lp: (path: string) => string;
}): JSX.Element {
  return (
    <Section eyebrow={copy.relatedHead} title={copy.relatedTitle}>
      <ServiceLinkGrid links={commonLinks(copy, lp)} />
    </Section>
  );
}

function CTABand({
  copy,
  lp,
  ctaHref,
  ctaLabel,
  source,
}: {
  copy: FunnelPagesCopy;
  lp: (path: string) => string;
  ctaHref: string;
  ctaLabel: string;
  source: string;
}): JSX.Element {
  const isTel = ctaHref.startsWith('tel:');
  const c = copy.cta;
  return (
    <section className="py-14 sm:py-20 bg-bg-elevated/40 border-y border-brand-line">
      <div className="container-pad text-center">
        <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight mb-4">{c.head}</h2>
        <p className="text-brand-mute mb-8 max-w-prose mx-auto">{c.body}</p>
        <div className="flex flex-wrap items-center justify-center gap-3">
          <a
            href={ctaHref}
            className="btn-primary px-6 py-3 text-base"
            data-bcl-cta-location={`${source}-cta-band`}
            {...(isTel ? { 'data-bcl-phone-cta': source } : { 'data-bcl-schedule-cta': source })}
          >
            {ctaLabel}
          </a>
          <a
            href={PHONE_TEL_HREF}
            className="btn-ghost px-5 py-3 text-base"
            aria-label="Call Brick Labor at (855) 82LABOR"
            data-bcl-phone-cta={source}
            data-bcl-cta-location={`${source}-cta-band-secondary`}
          >
            {c.phoneLabel}
          </a>
        </div>
        <p className="mt-5 text-xs text-brand-mute">
          <span aria-hidden className="mr-1">
            ◧
          </span>
          {c.bookedPre}
          <a
            href={lp('/me?panel=calendar')}
            className="text-brand-accent underline-hover"
            data-bcl-cta-location={`${source}-dashboard`}
          >
            {c.bookedLink}
          </a>
        </p>
      </div>
    </section>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// /schedule
// ─────────────────────────────────────────────────────────────────────────────

export function SchedulePage(): JSX.Element {
  useThemeToolsSurface('funnel-pages');
  const locale = activeLocale();
  const lp = (path: string): string => localizedPath(locale, path);
  const copy = funnelPagesCopy(locale);
  const s = copy.schedule;
  useFunnelMeta({
    path: '/schedule',
    title: s.metaTitle,
    description: s.metaDescription,
    ogImage: '/og/funnel-schedule.png',
  });
  const steps = [s.steps.tell, s.steps.confirm, s.steps.arrive];
  return (
    <div>
      <section className="py-14 sm:py-20 border-b border-brand-line">
        <div className="container-pad max-w-4xl">
          <p className="font-mono text-[11px] uppercase tracking-wider text-brand-accent mb-3">
            {s.eyebrow}
          </p>
          <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight mb-5">
            {s.h1}
          </h1>
          <p className="text-lg sm:text-xl text-brand-mute mb-8 max-w-prose">{s.lede}</p>
          <div className="flex flex-wrap items-center gap-3">
            <a href={lp('/book')} className="btn-primary px-6 py-3 text-base">
              {s.ctaPrimary}
            </a>
            <a href={lp('/quote')} className="btn-ghost px-5 py-3 text-base">
              {s.ctaSecondary}
            </a>
          </div>
        </div>
      </section>

      <Section eyebrow={s.howEyebrow} title={s.howTitle}>
        <ol className="grid sm:grid-cols-3 gap-6 mt-2">
          {steps.map((step, i) => (
            <li key={step.step} className="rounded-md border border-brand-line bg-bg-elevated/50 p-5">
              <div className="font-mono text-2xl font-bold text-brand-accent mb-2">0{i + 1}</div>
              <h3 className="font-display text-xl font-semibold mb-2">{step.step}</h3>
              <p className="text-brand-mute text-sm leading-relaxed">{step.body}</p>
            </li>
          ))}
        </ol>
      </Section>

      <Section eyebrow={s.coverEyebrow} title={s.coverTitle}>
        <ServiceLinkGrid links={commonLinks(copy, lp)} />
      </Section>

      <CTABand copy={copy} lp={lp} ctaHref={lp('/book')} ctaLabel={s.ctaBandLabel} source="schedule" />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// /quote
// ─────────────────────────────────────────────────────────────────────────────

export function QuotePage(): JSX.Element {
  const locale = activeLocale();
  const lp = (path: string): string => localizedPath(locale, path);
  const copy = funnelPagesCopy(locale);
  const q = copy.quote;
  useFunnelMeta({
    path: '/quote',
    title: q.metaTitle,
    description: q.metaDescription,
    ogImage: '/og/funnel-quote.png',
  });
  const inputs = [
    q.inputs.crew,
    q.inputs.time,
    q.inputs.access,
    q.inputs.vehicle,
    q.inputs.heavy,
    q.inputs.photos,
  ];
  // Job names localize; the dollar/crew/hour figures stay invariant.
  const pricing: ReadonlyArray<readonly [string, string]> = [
    [q.jobs.couch, '$100 · 1 hr × 2 crew'],
    [q.jobs.mattress, '$100 · 1 hr × 2 crew'],
    [q.jobs.uhaul, '$200 · 2 hrs × 2 crew'],
    [q.jobs.garage, '$300 · 3 hrs × 2 crew'],
    [q.jobs.driveway, '$75 · 1.5 hrs × 1 crew'],
    [q.jobs.hedge, '$100 · 2 hrs × 1 crew'],
    [q.jobs.bedroom, '$525 · 3.5 hrs × 3 crew'],
    [q.jobs.railing, '$300 · 3 hrs × 2 crew'],
  ];
  return (
    <div>
      <section className="py-14 sm:py-20 border-b border-brand-line">
        <div className="container-pad max-w-4xl">
          <p className="font-mono text-[11px] uppercase tracking-wider text-brand-accent mb-3">
            {q.eyebrow}
          </p>
          <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight mb-5">
            {q.h1Pre}
            <span className="text-gradient">{q.h1Accent}</span>
          </h1>
          <p className="text-lg sm:text-xl text-brand-mute mb-6 max-w-prose">
            {q.ledePre}
            <strong className="text-brand-ink">TaskRabbit, HomeAdvisor, and HireAHelper</strong>
            {q.ledePost}
          </p>
          <div className="rail-card mb-8 max-w-prose">
            <p className="eyebrow mb-2">{q.railHead}</p>
            <p className="text-sm text-brand-ink leading-relaxed">
              {q.railBodyPre}
              <strong className="text-brand-accent">crew × hours × $50</strong>
              {q.railBodyPost}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <a href={lp('/book')} className="btn-primary px-6 py-3 text-base">
              {q.ctaPrimary}
            </a>
            <a href={lp('/#fair-market')} className="btn-ghost px-5 py-3 text-base">
              {q.ctaSecondary}
            </a>
            <a href={PHONE_TEL_HREF} className="btn-ghost px-5 py-3 text-base">
              {q.ctaTel}
            </a>
          </div>
        </div>
      </section>

      <Section eyebrow={q.includeEyebrow} title={q.includeTitle}>
        <ul className="grid sm:grid-cols-2 gap-3 max-w-3xl">
          {inputs.map((item) => (
            <li
              key={item}
              className="flex items-start gap-3 rounded-md border border-brand-line bg-bg-elevated/40 px-4 py-3"
            >
              <span className="text-brand-accent text-lg leading-none mt-0.5" aria-hidden>
                →
              </span>
              <span className="text-sm">{item}</span>
            </li>
          ))}
        </ul>
        <p className="mt-6 text-sm text-brand-mute max-w-prose">{q.sanityNote}</p>
      </Section>

      <Section eyebrow={q.coverageEyebrow} title={q.coverageTitle}>
        <div className="max-w-4xl">
          <QuoteAreaMap />
          <p className="mt-4 text-sm text-brand-mute max-w-prose">{q.coverageNote}</p>
        </div>
      </Section>

      <Section eyebrow={q.pricingEyebrow} title={q.pricingTitle}>
        <div className="grid sm:grid-cols-2 gap-4 max-w-4xl">
          {pricing.map(([job, price]) => (
            <div
              key={job}
              className="rounded-md border border-brand-line bg-bg-elevated/40 px-4 py-3 flex items-center justify-between gap-4"
            >
              <span className="text-sm">{job}</span>
              <span className="font-mono text-sm text-brand-accent whitespace-nowrap">{price}</span>
            </div>
          ))}
        </div>
      </Section>

      <RelatedLinks copy={copy} lp={lp} />
      <CTABand copy={copy} lp={lp} ctaHref={lp('/book')} ctaLabel={q.ctaBandLabel} source="quote" />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// /emergency-labor
// ─────────────────────────────────────────────────────────────────────────────

export function EmergencyLaborPage(): JSX.Element {
  const locale = activeLocale();
  const lp = (path: string): string => localizedPath(locale, path);
  const copy = funnelPagesCopy(locale);
  const e = copy.emergency;
  useFunnelMeta({
    path: '/emergency-labor',
    title: e.metaTitle,
    description: e.metaDescription,
    ogImage: '/og/funnel-emergency.png',
  });
  const intents = [
    e.intents.moveout,
    e.intents.storm,
    e.intents.eviction,
    e.intents.movein,
    e.intents.estate,
    e.intents.pipe,
  ];
  return (
    <div>
      <section className="py-14 sm:py-20 border-b border-brand-line bg-bg-elevated/40">
        <div className="container-pad max-w-4xl">
          <p className="font-mono text-[11px] uppercase tracking-wider text-red-400 mb-3">
            {e.eyebrow}
          </p>
          <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight mb-5">
            {e.h1}
          </h1>
          <p className="text-lg sm:text-xl text-brand-mute mb-8 max-w-prose">{e.lede}</p>
          <div className="flex flex-wrap items-center gap-3">
            <a
              href={PHONE_TEL_HREF}
              className="btn-primary px-6 py-3 text-base"
              data-bcl-phone-cta="emergency"
              data-bcl-cta-location="emergency-hero"
              aria-label="Call Brick Labor at (855) 82LABOR for same-day labor"
            >
              {e.ctaCall}
            </a>
            <a
              href={`${PHONE_SMS_HREF}?body=Need%20same-day%20labor:%20`}
              className="btn-ghost px-5 py-3 text-base"
              data-bcl-sms-cta="emergency"
              data-bcl-cta-location="emergency-hero"
            >
              {e.ctaText}
            </a>
            <a href={lp('/book')} className="underline text-sm text-brand-mute">
              {e.ctaForm}
            </a>
          </div>
        </div>
      </section>

      <Section eyebrow={e.whatEyebrow} title={e.whatTitle}>
        <ul className="grid sm:grid-cols-2 gap-3 max-w-3xl">
          {intents.map((item) => (
            <li
              key={item}
              className="flex items-start gap-3 rounded-md border border-brand-line bg-bg-elevated/40 px-4 py-3"
            >
              <span className="text-red-400 text-lg leading-none mt-0.5" aria-hidden>
                ⚡
              </span>
              <span className="text-sm">{item}</span>
            </li>
          ))}
        </ul>
      </Section>

      <Section eyebrow={e.howEyebrow} title={e.howTitle}>
        <div className="space-y-3 text-brand-mute max-w-prose">
          <p>
            <strong className="text-brand-ink">{e.fast.singleLabel}</strong>
            {e.fast.singleBody}
          </p>
          <p>
            <strong className="text-brand-ink">{e.fast.multiLabel}</strong>
            {e.fast.multiBody}
          </p>
          <p>
            <strong className="text-brand-ink">{e.fast.afterLabel}</strong>
            {e.fast.afterBody}
          </p>
        </div>
      </Section>

      <RelatedLinks copy={copy} lp={lp} />
      <CTABand
        copy={copy}
        lp={lp}
        ctaHref={PHONE_TEL_HREF}
        ctaLabel={e.ctaBandLabel}
        source="emergency"
      />
    </div>
  );
}
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
