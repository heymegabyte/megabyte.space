import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect, useMemo, useRef, useState, type JSX, type ReactNode } from 'react';
import { Logo } from './Logo.js';
import { useAvatar } from '../avatar-context.js';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import {
  isActiveNavHref,
  pickActiveSectionHash,
} from '@theme.tools/seo-geo/field-service/nav-active';
import { headerCopy, type HeaderCopy } from '@theme.tools/i18n-a11y/field-service/header-copy';
import { MODAL_BACKDROP_CLASS, useModalMotion } from '../use-modal-motion.js';
import { useBodyScrollLock, useFocusManagement, useTabTrap } from '../use-dialog-a11y.js';
import {
  MEGA_MENU_CATEGORIES,
  UNIVERSAL_MEGA_MENU_ITEMS,
  type MegaMenuCatalogItem,
} from '../data/mega-menu-catalog.js';

export interface NavItem {
  href: string;
  label: string;
}

export interface HeaderOverrideUser {
  readonly displayName: string;
  readonly subtitle?: string;
  readonly avatarUrl?: string | null;
  readonly role?: 'customer' | 'worker' | 'admin' | 'super_admin';
}

export interface HeaderProps {
  navItems?: NavItem[];
  showBack?: boolean;
  ctaHref?: string;
  brandBadge?: string;
  overrideUser?: HeaderOverrideUser | null;
  headerActions?: ReactNode;
  onMobileSidebarToggle?: () => void;
}

type AuthState =
  | { kind: 'loading' }
  | { kind: 'anon' }
  | { kind: 'customer'; contact: string; displayName: string }
  | {
      kind: 'worker';
      workerId: string;
      firstName: string;
      lastName: string;
      hasAvatar: boolean;
    }
  | {
      kind: 'admin';
      displayName: string;
      email: string;
      role: 'admin' | 'super_admin';
    };

function computeInitials(label: string): string {
  const cleaned = label.trim();
  if (!cleaned) return 'BL';
  const parts = cleaned.split(/[\s@._-]+/).filter(Boolean);
  if (parts.length >= 2) {
    return `${parts[0]![0] ?? ''}${parts[1]![0] ?? ''}`.toUpperCase();
  }
  return cleaned.slice(0, 2).toUpperCase();
}

async function detectAuth(): Promise<AuthState> {
  try {
    const [whoamiRes, custRes, workRes] = await Promise.all([
      fetch('/api/auth/whoami', { credentials: 'include' }).catch(() => null),
      fetch('/api/auth/client/me', { credentials: 'include' }).catch(() => null),
      fetch('/api/work/auth/me', { credentials: 'include' }).catch(() => null),
    ]);

    if (whoamiRes && whoamiRes.ok) {
      const wData = (await whoamiRes.json().catch(() => null)) as {
        ok?: boolean;
        whoami?: {
          role?: string;
          displayName?: string | null;
          email?: string | null;
          workerId?: string | null;
          isAdmin?: boolean;
          isSuperAdmin?: boolean;
        };
      } | null;
      const who = wData?.whoami;
      if (who && who.role && who.role !== 'guest') {
        if (who.isAdmin || who.isSuperAdmin || who.role === 'admin' || who.role === 'super_admin') {
          return {
            kind: 'admin',
            displayName: who.displayName || who.email || 'Operator',
            email: who.email || 'hey@bricklabor.com',
            role: who.isSuperAdmin || who.role === 'super_admin' ? 'super_admin' : 'admin',
          };
        }
        if (who.role === 'crew' && who.workerId) {
          const names = (who.displayName || 'Crew Member').split(' ');
          return {
            kind: 'worker',
            workerId: who.workerId,
            firstName: names[0] || 'Crew',
            lastName: names.slice(1).join(' ') || '',
            hasAvatar: false,
          };
        }
        if (who.role === 'customer' && (who.email || who.displayName)) {
          return {
            kind: 'customer',
            contact: who.email || who.displayName || 'Customer',
            displayName: who.displayName || who.email || 'Customer',
          };
        }
      }
    }

    if (workRes && workRes.ok) {
      const w = (await workRes.json().catch(() => null)) as {
        authenticated?: boolean;
        worker?: {
          id?: string;
          first_name?: string;
          last_name?: string;
          avatar_r2_key?: string | null;
        };
      } | null;
      if (w?.authenticated && w.worker && typeof w.worker.id === 'string') {
        return {
          kind: 'worker',
          workerId: w.worker.id,
          firstName: w.worker.first_name ?? '',
          lastName: w.worker.last_name ?? '',
          hasAvatar: !!w.worker.avatar_r2_key,
        };
      }
    }

    if (custRes && custRes.ok) {
      const c = (await custRes.json().catch(() => null)) as {
        authenticated?: boolean;
        contact?: string;
        name?: string;
      } | null;
      if (c?.authenticated && c.contact) {
        return {
          kind: 'customer',
          contact: c.contact,
          displayName: c.name || c.contact,
        };
      }
    }

    if (typeof window !== 'undefined') {
      const ownerKey =
        window.localStorage.getItem('bcl_owner_key') ||
        window.localStorage.getItem('bcl_admin_token');
      if (ownerKey && ownerKey.trim().length > 0) {
        return {
          kind: 'admin',
          displayName: 'Operator',
          email: 'hey@bricklabor.com',
          role: 'super_admin',
        };
      }
    }

    return { kind: 'anon' };
  } catch {
    return { kind: 'anon' };
  }
}

/**
 * Mobile nav drawer — the slide-in panel behind the `md:hidden` hamburger.
 */
function MobileNavDrawer({
  open,
  onClose,
  items,
  lp,
  currentPath,
  activeHash,
  ctaHref,
  authAction,
  t,
}: {
  open: boolean;
  onClose: () => void;
  items: readonly NavItem[];
  lp: (path: string) => string;
  currentPath: string;
  activeHash: string | null;
  ctaHref: string;
  authAction: { href: string; label: string } | null;
  t: HeaderCopy;
}): JSX.Element | null {
  const panelRef = useRef<HTMLDivElement>(null);
  const lastFocusRef = useRef<HTMLElement | null>(null);
  const { closing, requestClose, resetClosing } = useModalMotion(onClose);
  useFocusManagement(open, panelRef, lastFocusRef);
  useBodyScrollLock(open, 768);
  const onTrapKey = useTabTrap(panelRef);

  useEffect(() => {
    if (open) resetClosing();
  }, [open, resetClosing]);

  useEffect(() => {
    if (!open && closing) resetClosing();
  }, [open, closing, resetClosing]);

  if (!open && !closing) return null;

  return (
    <div
      className={`${MODAL_BACKDROP_CLASS} fixed inset-0 z-[120] bg-black/70 backdrop-blur-md md:hidden`}
      data-closing={closing || undefined}
      onClick={requestClose}
    >
      <div
        id="mobile-nav-drawer"
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-label={t.menuLabel}
        data-closing={closing || undefined}
        onClick={(e) => e.stopPropagation()}
        onKeyDown={(e) => {
          if (e.key === 'Escape') {
            e.preventDefault();
            requestClose();
            return;
          }
          onTrapKey(e);
        }}
        style={{ backgroundColor: '#11161f' }}
        className="bcl-drawer-panel absolute right-0 top-0 flex h-full w-[86%] max-w-sm flex-col overflow-y-auto border-l border-brand-line bg-bg-elevated p-5 shadow-2xl"
      >
        <div className="mb-3 flex items-center justify-between">
          <span className="font-mono text-[11px] font-medium uppercase tracking-wider text-brand-accent">
            {t.menuLabel}
          </span>
          <button
            type="button"
            onClick={requestClose}
            aria-label={t.menuClose}
            className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-brand-line text-lg text-brand-ink transition-all duration-[333ms] hover:border-brand-accent hover:text-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent focus-visible:ring-offset-2 focus-visible:ring-offset-bg-primary"
          >
            ✕
          </button>
        </div>
        <nav aria-label={t.menuLabel} className="flex flex-col">
          {items.map((item) => (
            <a
              key={item.href}
              href={lp(item.href)}
              aria-current={
                isActiveNavHref(currentPath, item.href) || item.href === activeHash
                  ? 'page'
                  : undefined
              }
              onClick={requestClose}
              className="min-h-[44px] border-b border-brand-line/40 py-3 text-base text-brand-ink transition-colors duration-[333ms] hover:text-brand-accent aria-[current=page]:text-brand-accent"
            >
              {item.label}
            </a>
          ))}
        </nav>
        <a
          href={lp(ctaHref)}
          onClick={requestClose}
          className="btn-primary mt-5 inline-flex min-h-[48px] items-center justify-center text-sm"
          data-bcl-magic-link="mobile-nav-cta"
          aria-label={t.ariaCta}
        >
          {t.cta}
        </a>
        {authAction && (
          <a
            href={lp(authAction.href)}
            onClick={requestClose}
            className="mt-3 inline-flex min-h-[44px] items-center justify-center rounded-lg border border-brand-line text-sm text-brand-ink transition-all duration-[333ms] hover:border-brand-accent hover:text-brand-accent"
          >
            {authAction.label}
          </a>
        )}
      </div>
    </div>
  );
}

/**
 * Universal `@theme.tools/ui` Mega-Menu Navbar (`Header`).
 *
 * Implements the Universal Mega-Menu Navbar Standard across the entire app
 * (marketing pages, city/service/3D guides, blog articles, AND admin/customer/crew dashboards):
 * 1. Left: Creative Ideogram-generated Brand Emblem + Wordmark Lockup (`<Logo />`).
 * 2. Center: A single Mega-Menu Trigger Button (`data-testid="universal-mega-menu-trigger"`)
 *    instead of separate horizontal text links. Clicking opens the `@theme.tools/ui`
 *    Mega Menu (`data-testid="universal-mega-menu-panel"`) with a live Featured-Image
 *    Preview Pane (`data-testid="mega-menu-featured-preview"`) plus all blog articles,
 *    service hubs, sub-pages, and dashboards.
 * 3. Right: Login indicator with Avatar Circle (`data-testid="navbar-login-avatar-button"` when
 *    logged out; automatically swaps to the interactive Avatar Circle
 *    `data-testid="navbar-logged-in-avatar-circle"` when logged in) + global `"Book the crew"` CTA.
 */
export function Header({
  navItems,
  ctaHref = '/book?from=header-cta',
  brandBadge,
  overrideUser,
  headerActions,
  onMobileSidebarToggle,
}: HeaderProps = {}) {
  useThemeToolsSurface('header');
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const currentPath =
    typeof window === 'undefined' ? '/' : stripLocalePrefix(window.location.pathname).path;
  const t = headerCopy(locale);
  const lp = (path: string) => (path.startsWith('#') ? path : localizedPath(locale, path));

  const mobileFallbackItems: NavItem[] =
    navItems && navItems.length > 0
      ? navItems
      : UNIVERSAL_MEGA_MENU_ITEMS.slice(0, 10).map((it) => ({
          href: it.href,
          label: it.title,
        }));

  const [scrolled, setScrolled] = useState(false);
  const [activeHash, setActiveHash] = useState<string | null>(null);
  const hashKey = mobileFallbackItems
    .filter((item) => item.href.startsWith('#'))
    .map((item) => item.href)
    .join(',');
  const [auth, setAuth] = useState<AuthState>({ kind: 'loading' });
  const [menuOpen, setMenuOpen] = useState(false);
  const [megaOpen, setMegaOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState<'all' | 'services' | 'blog' | 'cities' | 'company'>('all');
  const [megaSearch, setMegaSearch] = useState('');
  const [activePreviewId, setActivePreviewId] = useState<string>(
    UNIVERSAL_MEGA_MENU_ITEMS[0]?.id ?? 'svc-flagship-sample',
  );
  const [avatarMenuOpen, setAvatarMenuOpen] = useState(false);

  const megaContainerRef = useRef<HTMLDivElement>(null);
  const avatarMenuRef = useRef<HTMLDivElement>(null);
  const { avatarUrl, setWorkerId, bust } = useAvatar();

  useEffect(() => {
    const targets = hashKey ? hashKey.split(',') : [];
    const onScroll = () => {
      setScrolled(window.scrollY > 12);
      if (!targets.length) {
        setActiveHash(null);
        return;
      }
      const activationLine = Math.max(96, Math.round(window.innerHeight * 0.3));
      const sections = targets
        .map((hash) => {
          const element = document.getElementById(hash.slice(1));
          return element ? { hash, top: element.getBoundingClientRect().top } : null;
        })
        .filter((section): section is { hash: string; top: number } => section !== null);
      setActiveHash(pickActiveSectionHash(sections, activationLine));
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, [hashKey]);

  useEffect(() => {
    let cancelled = false;
    detectAuth().then((s) => {
      if (cancelled) return;
      setAuth(s);
      if (s.kind === 'worker') setWorkerId(s.workerId);
    });
    return () => {
      cancelled = true;
    };
  }, [setWorkerId]);

  // Close Mega Menu or Avatar Dropdown on Escape or outside click
  useEffect(() => {
    if (!megaOpen && !avatarMenuOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setMegaOpen(false);
        setAvatarMenuOpen(false);
      }
    };
    const onPointerDown = (e: MouseEvent) => {
      const target = e.target as Node | null;
      if (
        megaOpen &&
        megaContainerRef.current &&
        target &&
        !megaContainerRef.current.contains(target)
      ) {
        setMegaOpen(false);
      }
      if (
        avatarMenuOpen &&
        avatarMenuRef.current &&
        target &&
        !avatarMenuRef.current.contains(target)
      ) {
        setAvatarMenuOpen(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('mousedown', onPointerDown);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('mousedown', onPointerDown);
    };
  }, [megaOpen, avatarMenuOpen]);

  const effectiveAuth: AuthState = useMemo(() => {
    if (overrideUser) {
      return {
        kind: 'admin',
        displayName: overrideUser.displayName,
        email: overrideUser.subtitle ?? 'hey@bricklabor.com',
        role: overrideUser.role === 'super_admin' ? 'super_admin' : 'admin',
      };
    }
    return auth;
  }, [overrideUser, auth]);

  const filteredMegaItems = useMemo(() => {
    const q = megaSearch.trim().toLowerCase();
    return UNIVERSAL_MEGA_MENU_ITEMS.filter((item) => {
      if (activeCategory !== 'all' && item.category !== activeCategory) return false;
      if (!q) return true;
      return (
        item.title.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        item.badge.toLowerCase().includes(q) ||
        item.href.toLowerCase().includes(q)
      );
    });
  }, [activeCategory, megaSearch]);

  const activePreviewItem: MegaMenuCatalogItem = useMemo(() => {
    return (
      UNIVERSAL_MEGA_MENU_ITEMS.find((i) => i.id === activePreviewId) ??
      filteredMegaItems[0] ??
      UNIVERSAL_MEGA_MENU_ITEMS[0]!
    );
  }, [activePreviewId, filteredMegaItems]);

  const authAction: { href: string; label: string } | null =
    effectiveAuth.kind === 'worker'
      ? { href: '/work/dashboard', label: t.dashboard }
      : effectiveAuth.kind === 'customer'
        ? { href: '/me', label: t.dashboard }
        : effectiveAuth.kind === 'admin'
          ? { href: '/dashboard', label: t.dashboard }
          : { href: '/login', label: t.login };

  const handleSignOut = async () => {
    setAvatarMenuOpen(false);
    try {
      await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' });
    } catch {
      // ignore
    }
    try {
      window.localStorage.removeItem('bcl_owner_key');
      window.localStorage.removeItem('bcl_admin_token');
    } catch {
      // ignore
    }
    window.location.href = lp('/login');
  };

  // Build the right-hand Login / Avatar Circle slot
  let authSlot: JSX.Element;
  if (
    effectiveAuth.kind === 'worker' ||
    effectiveAuth.kind === 'customer' ||
    effectiveAuth.kind === 'admin'
  ) {
    const displayName =
      effectiveAuth.kind === 'worker'
        ? `${effectiveAuth.firstName} ${effectiveAuth.lastName}`.trim() || 'Crew Member'
        : effectiveAuth.displayName;
    const roleLabel =
      effectiveAuth.kind === 'worker'
        ? 'CREW PORTAL'
        : effectiveAuth.kind === 'admin'
          ? effectiveAuth.role === 'super_admin'
            ? 'SUPER ADMIN'
            : 'ADMIN'
          : 'CUSTOMER';
    const initials = computeInitials(displayName);
    const resolvedAvatarSrc =
      overrideUser?.avatarUrl ??
      (effectiveAuth.kind === 'worker' && effectiveAuth.hasAvatar
        ? avatarUrl(effectiveAuth.workerId)
        : null);
    const primaryDashboardPath =
      effectiveAuth.kind === 'worker'
        ? '/work/dashboard'
        : effectiveAuth.kind === 'customer'
          ? '/me'
          : '/dashboard';

    authSlot = (
      <div
        ref={avatarMenuRef}
        className="relative"
        data-testid="universal-navbar-auth-slot"
      >
        <button
          type="button"
          onClick={() => setAvatarMenuOpen((v) => !v)}
          data-testid="navbar-logged-in-avatar-circle"
          data-bcl-auth={effectiveAuth.kind}
          aria-expanded={avatarMenuOpen}
          aria-haspopup="menu"
          aria-label={`Account menu for ${displayName}`}
          className="group relative inline-flex items-center gap-2 rounded-full border border-[#ff6b1a]/60 bg-[#121822]/90 p-1 pr-2.5 text-xs font-semibold text-[#f5f2ed] shadow-[0_0_20px_rgba(255,107,26,0.22)] transition-all duration-[333ms] hover:border-[#ff6b1a] hover:bg-[#171f2c] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
        >
          <span
            data-testid="navbar-avatar-circle"
            className="relative inline-flex h-8 w-8 shrink-0 items-center justify-center overflow-hidden rounded-full bg-gradient-to-br from-[#ff6b1a] to-[#d94e06] font-mono text-xs font-extrabold text-[#080b10] ring-2 ring-[#ff6b1a]/40"
          >
            {resolvedAvatarSrc ? (
              <img
                key={bust}
                src={resolvedAvatarSrc}
                alt={displayName}
                className="h-full w-full object-cover"
                loading="lazy"
                decoding="async"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                }}
              />
            ) : (
              <span>{initials}</span>
            )}
            <span
              aria-hidden="true"
              className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full border-2 border-[#0c1118] bg-emerald-400"
            />
          </span>
          <span className="hidden lg:inline-block max-w-[110px] truncate font-display text-xs font-bold text-[#f5f2ed]">
            {displayName}
          </span>
        </button>

        {avatarMenuOpen && (
          <div
            role="menu"
            data-testid="navbar-avatar-dropdown-menu"
            className="absolute right-0 top-[calc(100%+10px)] z-[110] w-64 overflow-hidden rounded-2xl border border-white/15 bg-[#0c1118]/98 p-2 shadow-[0_24px_60px_rgba(0,0,0,0.85)] backdrop-blur-xl"
          >
            <div className="border-b border-white/10 px-3 py-2.5">
              <span className="inline-block rounded-full border border-[#ff6b1a]/40 bg-[#ff6b1a]/15 px-2 py-0.5 font-mono text-[9px] font-bold uppercase tracking-wider text-[#ff8a47]">
                {roleLabel}
              </span>
              <p className="mt-1 truncate font-display text-sm font-bold text-white">
                {displayName}
              </p>
            </div>
            <div className="py-1.5 space-y-0.5">
              <a
                role="menuitem"
                href={lp(primaryDashboardPath)}
                onClick={() => setAvatarMenuOpen(false)}
                className="flex items-center justify-between rounded-xl px-3 py-2 text-xs font-semibold text-[#f5f2ed] hover:bg-white/[0.06] hover:text-[#ff8a47] transition"
              >
                <span>Open My Dashboard</span>
                <span aria-hidden="true">→</span>
              </a>
              <a
                role="menuitem"
                href={lp('/dashboard')}
                onClick={() => setAvatarMenuOpen(false)}
                className="flex items-center justify-between rounded-xl px-3 py-2 text-xs text-[#c5c0b8] hover:bg-white/[0.06] hover:text-white transition"
              >
                <span>Unified Operations Portal</span>
                <span aria-hidden="true">◆</span>
              </a>
              <a
                role="menuitem"
                href={lp('/me')}
                onClick={() => setAvatarMenuOpen(false)}
                className="flex items-center justify-between rounded-xl px-3 py-2 text-xs text-[#c5c0b8] hover:bg-white/[0.06] hover:text-white transition"
              >
                <span>Customer Bookings &amp; Quotes</span>
                <span aria-hidden="true">📅</span>
              </a>
              <a
                role="menuitem"
                href={lp('/admin/super-admin')}
                onClick={() => setAvatarMenuOpen(false)}
                className="flex items-center justify-between rounded-xl px-3 py-2 text-xs text-[#c5c0b8] hover:bg-white/[0.06] hover:text-white transition"
              >
                <span>Admin Operations Cockpit</span>
                <span aria-hidden="true">◎</span>
              </a>
            </div>
            <div className="border-t border-white/10 pt-1.5">
              <button
                role="menuitem"
                type="button"
                onClick={() => void handleSignOut()}
                className="flex w-full items-center justify-between rounded-xl px-3 py-2 text-left text-xs font-semibold text-rose-300 hover:bg-rose-500/15 transition"
              >
                <span>Sign out</span>
                <span aria-hidden="true">⎋</span>
              </button>
            </div>
          </div>
        )}
      </div>
    );
  } else {
    // Logged-out state: Login button with Avatar Circle indicator
    authSlot = (
      <div data-testid="universal-navbar-auth-slot">
        <a
          href={lp('/login')}
          data-testid="navbar-login-avatar-button"
          data-bcl-auth="anon"
          aria-label={t.ariaLogin}
          className="group inline-flex min-h-[40px] items-center gap-2 rounded-full border border-white/15 bg-white/[0.04] pl-1.5 pr-3.5 py-1 text-xs font-semibold text-[#f5f2ed] transition-all duration-[333ms] hover:border-[#ff6b1a]/70 hover:bg-[#ff6b1a]/10 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
        >
          <span
            data-testid="navbar-avatar-circle"
            aria-hidden="true"
            className="inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-white/25 bg-[#121822] text-[#ff8a47] transition-colors group-hover:border-[#ff6b1a] group-hover:bg-[#ff6b1a] group-hover:text-[#080b10]"
          >
            <svg
              viewBox="0 0 24 24"
              width="14"
              height="14"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="12" cy="8" r="4" />
              <path d="M5 20c1.5-3.5 4.2-5 7-5s5.5 1.5 7 5" />
            </svg>
          </span>
          <span>{t.login}</span>
        </a>
      </div>
    );
  }

  return (
    <header
      ref={megaContainerRef}
      data-testid="universal-app-navbar"
      className={`sticky top-0 z-50 transition-all duration-300 ${
        scrolled || megaOpen
          ? 'bg-[#080b10]/95 backdrop-blur-xl border-b border-white/12 shadow-[0_12px_36px_rgba(0,0,0,0.65)]'
          : 'bg-[#080b10]/85 backdrop-blur-md border-b border-white/10'
      }`}
    >
      <div className="container-pad flex h-[72px] items-center justify-between gap-3">
        {/* Left: Optional Dashboard Sidebar Hamburger + Transparent Orange Brick Labor Text Icon */}
        <div className="flex items-center gap-3 min-w-0">
          {onMobileSidebarToggle && (
            <button
              type="button"
              onClick={onMobileSidebarToggle}
              aria-label="Open dashboard sidebar"
              className="lg:hidden inline-flex h-10 w-10 items-center justify-center rounded-xl border border-white/15 bg-white/[0.04] text-lg text-brand-ink hover:border-brand-accent"
            >
              ☰
            </button>
          )}
          <a
            href={lp('/')}
            className="flex items-center gap-3.5 group shrink-0 py-1"
            aria-label={t.ariaHome}
          >
            <Logo className="h-8 sm:h-9 md:h-10 w-auto max-w-[180px] sm:max-w-[215px] md:max-w-[240px]" title="Brick Labor" />
            {brandBadge && (
              <span className="hidden 2xl:block text-[11px] font-mono font-normal tracking-wider text-brand-accent uppercase leading-tight border-l border-brand-line/60 pl-3">
                {`${brandBadge} · NEWARK NJ`}
                <span className="block text-brand-mute normal-case tracking-normal">
                  {t.kicker}
                </span>
              </span>
            )}
          </a>
        </div>

        {/* Center: Single Button Triggering the @theme.tools Mega Menu */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setMegaOpen((v) => !v)}
            data-testid="universal-mega-menu-trigger"
            aria-expanded={megaOpen}
            aria-controls="universal-mega-menu-panel"
            className={`inline-flex min-h-[42px] items-center gap-2.5 rounded-full border px-4 py-2 font-mono text-xs font-bold uppercase tracking-[0.12em] transition-all duration-[333ms] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent ${
              megaOpen
                ? 'border-[#ff6b1a] bg-[#ff6b1a] text-[#080b10] shadow-[0_0_25px_rgba(255,107,26,0.45)]'
                : 'border-white/15 bg-white/[0.05] text-[#f5f2ed] hover:border-[#ff6b1a]/70 hover:bg-[#ff6b1a]/12 hover:text-white'
            }`}
          >
            <svg
              viewBox="0 0 20 20"
              width="15"
              height="15"
              fill="currentColor"
              aria-hidden="true"
              className={megaOpen ? 'text-[#080b10]' : 'text-[#ff8a47]'}
            >
              <rect x="2" y="2" width="6.5" height="6.5" rx="1.5" />
              <rect x="11.5" y="2" width="6.5" height="6.5" rx="1.5" />
              <rect x="2" y="11.5" width="6.5" height="6.5" rx="1.5" />
              <rect x="11.5" y="11.5" width="6.5" height="6.5" rx="1.5" />
            </svg>
            <span>Explore &amp; Guides</span>
            <span
              aria-hidden="true"
              className={`inline-block text-[10px] transition-transform duration-300 ${
                megaOpen ? 'rotate-180' : ''
              }`}
            >
              ▼
            </span>
          </button>
        </div>

        {/* Right: Optional Dashboard Actions + Login/Avatar Circle + Global "Book the crew" CTA */}
        <div className="flex items-center gap-2 shrink-0">
          {headerActions}
          {authSlot}
          <a
            href={lp(ctaHref)}
            data-testid="navbar-book-crew-cta"
            data-bcl-magic-link="header-cta"
            aria-label={t.ariaCta}
            className="btn-primary text-[12px] px-4 py-2 min-h-[40px] inline-flex items-center font-extrabold rounded-full shadow-[0_6px_20px_rgba(255,107,26,0.35)]"
          >
            {t.cta}
          </a>
          <button
            type="button"
            onClick={() => setMenuOpen(true)}
            aria-label={t.menuOpen}
            aria-expanded={menuOpen}
            aria-controls="mobile-nav-drawer"
            className="md:hidden inline-flex h-11 w-11 items-center justify-center rounded-lg border border-brand-line text-brand-ink transition-all duration-[333ms] hover:border-brand-accent hover:text-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent focus-visible:ring-offset-2 focus-visible:ring-offset-bg-primary"
          >
            <svg
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              aria-hidden="true"
            >
              <line x1="3" y1="6" x2="21" y2="6" />
              <line x1="3" y1="12" x2="21" y2="12" />
              <line x1="3" y1="18" x2="21" y2="18" />
            </svg>
          </button>
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════════════════
          @THEME.TOOLS UNIVERSAL MEGA MENU PANEL WITH LIVE FEATURED-IMAGE PREVIEW
          ═══════════════════════════════════════════════════════════════════════ */}
      {megaOpen && (
        <div
          id="universal-mega-menu-panel"
          data-testid="universal-mega-menu-panel"
          role="region"
          aria-label="Brick Labor Sitewide Mega Menu"
          className="border-t border-white/12 bg-[#0a0e15]/98 shadow-[0_32px_80px_rgba(0,0,0,0.92)] backdrop-blur-2xl"
        >
          <div className="container-pad py-6">
            {/* Top Bar: Category Filter Pills & Instant Search */}
            <div className="mb-5 flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4">
              <div className="flex flex-wrap items-center gap-1.5" role="tablist" aria-label="Mega menu categories">
                <button
                  type="button"
                  role="tab"
                  aria-selected={activeCategory === 'all'}
                  onClick={() => setActiveCategory('all')}
                  className={`rounded-full border px-3.5 py-1.5 font-mono text-[11px] font-bold transition ${
                    activeCategory === 'all'
                      ? 'border-[#ff6b1a] bg-[#ff6b1a] text-[#080b10]'
                      : 'border-white/12 bg-white/[0.03] text-[#c5c0b8] hover:border-[#ff6b1a]/50 hover:text-white'
                  }`}
                >
                  All Sections ({UNIVERSAL_MEGA_MENU_ITEMS.length})
                </button>
                {MEGA_MENU_CATEGORIES.map((cat) => {
                  const active = activeCategory === cat.id;
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      role="tab"
                      aria-selected={active}
                      data-testid={`mega-menu-tab-${cat.id}`}
                      onClick={() => setActiveCategory(cat.id)}
                      className={`rounded-full border px-3.5 py-1.5 font-mono text-[11px] font-bold transition ${
                        active
                          ? 'border-[#ff6b1a] bg-[#ff6b1a] text-[#080b10]'
                          : 'border-white/12 bg-white/[0.03] text-[#c5c0b8] hover:border-[#ff6b1a]/50 hover:text-white'
                      }`}
                    >
                      {cat.label}
                    </button>
                  );
                })}
              </div>

              <div className="flex items-center gap-2 w-full sm:w-72">
                <input
                  type="search"
                  value={megaSearch}
                  onChange={(e) => setMegaSearch(e.target.value)}
                  data-testid="mega-menu-search-input"
                  placeholder="Filter guides, blog posts, cities..."
                  aria-label="Search mega menu links"
                  className="w-full rounded-full border border-white/15 bg-[#06080d] px-4 py-1.5 font-mono text-xs text-white placeholder:text-[#9ba1ab] focus:border-[#ff6b1a] focus:outline-none"
                />
              </div>
            </div>

            {/* Main Mega Menu Grid: 8-Col Categorized Links + 4-Col Live Featured-Image Preview */}
            <div className="grid gap-6 lg:grid-cols-12 items-start">
              {/* Left 8 Columns: Categorized Links */}
              <div className="lg:col-span-8 grid gap-5 sm:grid-cols-2 max-h-[62vh] overflow-y-auto pr-1">
                {MEGA_MENU_CATEGORIES.filter((cat) =>
                  activeCategory === 'all' ? true : cat.id === activeCategory,
                ).map((cat) => {
                  const catItems = filteredMegaItems.filter((i) => i.category === cat.id);
                  if (catItems.length === 0) return null;
                  return (
                    <div
                      key={cat.id}
                      className="rounded-2xl border border-white/10 bg-[#0e141d]/80 p-4"
                    >
                      <div className="mb-3 border-b border-white/10 pb-2">
                        <span className="font-mono text-[10px] font-bold uppercase tracking-[0.16em] text-[#ff8a47] block">
                          {cat.eyebrow}
                        </span>
                        <h3 className="font-display text-sm font-extrabold text-white">
                          {cat.label}
                        </h3>
                      </div>
                      <ul className="space-y-1.5">
                        {catItems.map((item) => {
                          const isPreviewed = item.id === activePreviewItem.id;
                          return (
                            <li key={item.id}>
                              <a
                                href={lp(item.href)}
                                data-testid={`mega-menu-link-${item.id}`}
                                onMouseEnter={() => setActivePreviewId(item.id)}
                                onFocus={() => setActivePreviewId(item.id)}
                                onClick={() => setMegaOpen(false)}
                                className={`group flex items-center gap-3 rounded-xl border p-2 transition-all duration-200 ${
                                  isPreviewed
                                    ? 'border-[#ff6b1a]/60 bg-[#ff6b1a]/15 text-white shadow-sm'
                                    : 'border-transparent bg-white/[0.02] text-[#c5c0b8] hover:border-white/15 hover:bg-white/[0.05] hover:text-white'
                                }`}
                              >
                                <img
                                  src={item.featuredImage}
                                  alt=""
                                  aria-hidden="true"
                                  width={56}
                                  height={40}
                                  loading="eager"
                                  className="h-10 w-14 shrink-0 rounded-lg border border-white/10 object-cover"
                                />
                                <div className="min-w-0 flex-1">
                                  <span className="block truncate font-mono text-[9px] font-bold uppercase tracking-wider text-[#ff8a47]">
                                    {item.badge}
                                  </span>
                                  <span className="block truncate font-display text-xs font-bold text-[#f5f2ed] group-hover:text-white">
                                    {item.title}
                                  </span>
                                </div>
                              </a>
                            </li>
                          );
                        })}
                      </ul>
                    </div>
                  );
                })}
              </div>

              {/* Right 4 Columns: Live Featured-Image Preview Card */}
              <aside
                data-testid="mega-menu-featured-preview"
                aria-label="Featured page image preview"
                className="lg:col-span-4 lg:sticky lg:top-4 overflow-hidden rounded-2xl border border-[#ff6b1a]/45 bg-[#0e141d] shadow-2xl"
              >
                <div className="relative aspect-[16/10] w-full overflow-hidden bg-[#06080d]">
                  <img
                    src={activePreviewItem.featuredImage}
                    alt={activePreviewItem.title}
                    data-testid="mega-menu-preview-image"
                    width={640}
                    height={400}
                    loading="eager"
                    className="h-full w-full object-cover transition-all duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0e141d] via-black/25 to-transparent" />
                  <span className="absolute left-3 top-3 rounded-full border border-[#ff6b1a]/60 bg-[#080b10]/90 px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-wider text-[#ff8a47]">
                    {activePreviewItem.badge}
                  </span>
                </div>

                <div className="p-5 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-[10px] font-semibold uppercase tracking-wider text-emerald-300">
                      ● {activePreviewItem.metaLabel}
                    </span>
                    <span className="font-mono text-[10px] text-[#9ba1ab]">
                      Featured preview
                    </span>
                  </div>

                  <h4
                    data-testid="mega-menu-preview-title"
                    className="font-display text-base sm:text-lg font-extrabold text-white leading-snug"
                  >
                    {activePreviewItem.title}
                  </h4>

                  <p className="text-xs text-[#c5c0b8] leading-relaxed">
                    {activePreviewItem.description}
                  </p>

                  <div className="pt-2 flex flex-wrap items-center gap-2">
                    <a
                      href={lp(activePreviewItem.href)}
                      onClick={() => setMegaOpen(false)}
                      data-testid="mega-menu-preview-cta"
                      className="flex-1 rounded-xl bg-[#ff6b1a] px-4 py-2.5 text-center font-mono text-xs font-extrabold uppercase tracking-wider text-[#080b10] hover:bg-[#ff823d] transition"
                    >
                      Open Page →
                    </a>
                    <a
                      href={lp(ctaHref)}
                      onClick={() => setMegaOpen(false)}
                      className="rounded-xl border border-white/15 bg-white/[0.04] px-3.5 py-2.5 font-mono text-xs font-bold text-white hover:border-[#ff6b1a] transition"
                    >
                      Book $50/hr
                    </a>
                  </div>
                </div>
              </aside>
            </div>
          </div>
        </div>
      )}

      <MobileNavDrawer
        open={menuOpen}
        onClose={() => setMenuOpen(false)}
        items={mobileFallbackItems}
        lp={lp}
        currentPath={currentPath}
        activeHash={activeHash}
        ctaHref={ctaHref}
        authAction={authAction}
        t={t}
      />
    </header>
  );
}

export default Header;
