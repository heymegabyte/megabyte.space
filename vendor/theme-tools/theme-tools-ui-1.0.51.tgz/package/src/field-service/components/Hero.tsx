import { useState } from 'react';
import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { Kinetic } from './motion/Kinetic.js';
import { GrainOverlay } from './motion/GrainOverlay.js';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { heroCopy } from '@theme.tools/i18n-a11y/field-service/hero-copy';
import { CITIES } from '../data/cities.js';
import { useRovingRadio } from '../use-roving-radio.js';
import { SocialProofLine } from './SocialProofLine.js';
import { buildQuotePrefill } from '@theme.tools/scheduling/field-service/hero-quote-prefill';

const HOURS = [1, 2, 3, 4, 5, 6, 8] as const;
const CREW = [1, 2, 3, 4] as const;
// React 18's server renderer predates the camel-cased fetchPriority prop. The
// standards-form lowercase attribute keeps SSR and hydration byte-compatible.
const HIGH_FETCH_PRIORITY = { fetchpriority: 'high' };

/**
 * Split a headline string into per-word reveal spans (A2 kinetic word-stagger).
 *
 * Each word becomes a direct `[data-animate="word-up"]` child of the `<h1>` so the
 * shared `animate.ts` runtime + `applyStagger` (driven by the h1's `data-stagger`)
 * give it a sequential `--anim-delay` — no bespoke per-word JS, no parallel reveal
 * primitive. Spaces between words are preserved so the inline-block words wrap
 * naturally; no-JS / reduced-motion show the full text (the universal
 * `[data-animate]` reduce block zeroes the transform).
 *
 * @param text - the headline line, e.g. `'Brick Labor.'`
 * @param spanClass - optional per-word class (e.g. `'text-gradient'`)
 * @param keyPrefix - React key namespace, unique per line
 */
function renderWords(text: string, spanClass: string | undefined, keyPrefix: string) {
  return text
    .split(/\s+/)
    .filter(Boolean)
    .flatMap((word, i) => [
      i > 0 ? <span key={`${keyPrefix}-sp-${i}`}> </span> : null,
      <span key={`${keyPrefix}-${i}`} data-animate="word-up" className={spanClass}>
        {word}
      </span>,
    ]);
}

export function Hero() {
  const [hours, setHours] = useState<number>(2);
  const [crew, setCrew] = useState<number>(1);

  // Hours + crew are single-select-among-mutually-exclusive — the APG radiogroup
  // pattern, not a toggle-button group. Spread `useRovingRadio` so each group is a
  // SINGLE tab stop with arrow/Home/End roving (axe is blind to this keyboard gap).
  const hoursRadio = useRovingRadio(HOURS.length, (i) => setHours(HOURS[i] ?? HOURS[0]));
  const crewRadio = useRovingRadio(CREW.length, (i) => setCrew(CREW[i] ?? CREW[0]));

  // The /es + /pt mirror pages render the SAME Hero (the SPA strips the locale
  // prefix to route), so without localized copy a Spanish/Portuguese visitor
  // lands on an English page. Read the locale off the URL and render the
  // matching above-the-fold bundle. SSR-safe: defaults to English when there
  // is no `window` (prerender) — the client render then localizes on mount.
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  // Keep a mirror-locale visitor in /es · /pt: localize internal `/` hrefs;
  // leave mailto:/tel:/external + static-asset paths bare.
  const lp = (p: string) => (p.startsWith('/') ? localizedPath(locale, p) : p);
  const t = heroCopy(locale);
  const surfaceProps = useThemeToolsSurface('hero', ['@theme.tools/ui', '@theme.tools/billing']);
  const pricingStandard = evaluateHourlyLaborPricingStandard({ crewSize: crew, hours, cadence: 'one-time' });

  async function handleQuote(e: React.FormEvent) {
    e.preventDefault();
    try {
      sessionStorage.setItem(
        'bcl-quote-prefill',
        JSON.stringify(buildQuotePrefill(hours, crew, Date.now())),
      );
    } catch {
      /* noop */
    }
    // §book-canonical (2026-05-28) — Booking form lives at /book only.
    // Navigate there directly instead of scrolling to a section that no
    // longer exists on the homepage.
    window.location.href = '/book';
  }

  return (
    <GrainOverlay toneHero>
      <section
        className="relative overflow-hidden"
        data-theme-tools-surface={surfaceProps['data-theme-tools-surface']}
        data-theme-tools-pricing-model={surfaceProps['data-theme-tools-pricing-model']}
        data-hero-estimated-cents={pricingStandard.baseLaborCents}
      >
        <picture aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10">
          <source
            media="(max-width: 767px)"
            srcSet="/brand/hero-poster-mobile.avif"
            type="image/avif"
          />
          <source
            media="(max-width: 767px)"
            srcSet="/brand/hero-poster-mobile.webp"
            type="image/webp"
          />
          <source srcSet="/brand/hero-poster.avif" type="image/avif" />
          <source srcSet="/brand/hero-poster.webp" type="image/webp" />
          <img
            src="/brand/hero-poster.jpg"
            alt=""
            loading="eager"
            {...HIGH_FETCH_PRIORITY}
            decoding="async"
            width={1920}
            height={1080}
            className="bcl-hero-poster h-full w-full object-cover opacity-55"
          />
        </picture>
        <div
          className="pointer-events-none absolute inset-0 -z-10"
          aria-hidden
          style={{
            background:
              'linear-gradient(105deg, rgba(6,6,16,0.85) 0%, rgba(6,6,16,0.65) 45%, rgba(6,6,16,0.55) 70%, rgba(6,6,16,0.92) 100%)',
          }}
        />
        <div className="pointer-events-none absolute inset-0 grid-pattern opacity-60" aria-hidden />
        <div
          className="bcl-hero-glow pointer-events-none absolute -top-40 -right-40 h-[500px] w-[500px] rounded-full bg-brand-accent/15 blur-3xl"
          aria-hidden
        />
        <div className="container-pad relative pt-20 pb-24 sm:pt-28 sm:pb-32">
          <div className="grid lg:grid-cols-[1.4fr_1fr] gap-10 lg:gap-14 items-start">
            <div className="max-w-3xl">
              <p className="eyebrow mb-5" data-animate="fade-up" data-delay="0">
                {t.eyebrowPre}
                <a
                  href={lp('/blog/evenings-and-weekends-newark-property-crew')}
                  className="underline-hover"
                >
                  {t.eveningsWeekends}
                </a>
              </p>
              <Kinetic className="text-5xl sm:text-7xl font-extrabold leading-[1.02]" stagger={60}>
                {renderWords('Brick Labor.', undefined, 'l1')}
                <br />
                {renderWords(t.hireCrew, 'text-gradient', 'l2')}
              </Kinetic>
              {locale === 'en' ? (
                <p
                  className="mt-6 text-lg sm:text-xl text-brand-mute max-w-2xl"
                  data-animate="fade-up"
                  data-delay="240"
                >
                  Newark-based property crew working{' '}
                  <a href={lp('/#coverage')} className="underline-hover">
                    all of New Jersey
                  </a>{' '}
                  and the five NYC boroughs.{' '}
                  <a href={lp('/services/power-washing')} className="underline-hover">
                    Power washing
                  </a>
                  ,{' '}
                  <a href={lp('/services/lawn-care')} className="underline-hover">
                    lawn care
                  </a>
                  ,{' '}
                  <a href={lp('/services/hauling')} className="underline-hover">
                    hauling
                  </a>
                  , and{' '}
                  <a href={lp('/services/light-repairs')} className="underline-hover">
                    light repairs
                  </a>{' '}
                  at{' '}
                  <a
                    href={lp('/blog/fifty-dollar-hour-per-person-philosophy')}
                    className="text-brand-ink font-bold underline-hover"
                  >
                    $50 per hour, per person
                  </a>
                  . Pick a slot, pick a crew size, we show up with the gear. No quote runaround.
                </p>
              ) : (
                <p
                  className="mt-6 text-lg sm:text-xl text-brand-mute max-w-2xl"
                  data-animate="fade-up"
                  data-delay="240"
                >
                  {t.lead}
                </p>
              )}
              <p
                className="tt-badge mt-4 font-mono text-[11px] tracking-[0.16em]"
                data-animate="fade-up"
                data-delay="300"
              >
                <span aria-hidden>✦</span>
                <a href="#fair-market" className="underline-hover text-brand-accent">
                  {t.fairMarket}
                </a>
              </p>
              <p
                className="mt-2 inline-flex items-center gap-2 rounded-full border border-brand-line bg-bg-primary/50 px-3.5 py-1.5 font-mono text-[11px] uppercase tracking-[0.16em] text-brand-mute"
                data-animate="fade-up"
                data-delay="320"
              >
                <span aria-hidden>◧</span>
                <a href={lp('/me?panel=calendar')} className="underline-hover text-brand-ink">
                  {t.calendarScheduling}
                </a>
              </p>
              <div
                className="mt-9 flex flex-col sm:flex-row flex-wrap gap-3"
                data-animate="cta-spring"
                data-delay="360"
              >
                <a
                  href={lp('/book')}
                  className="tt-btn tt-btn--primary btn-arrow cta-sheen text-base"
                  data-testid="hero-book-cta"
                >
                  {t.bookCrew}
                  <span data-btn-arrow aria-hidden>
                    →
                  </span>
                </a>
                <a href="#fair-market" className="tt-btn tt-btn--ghost text-base">
                  {t.seeEstimate}
                </a>
                <a
                  href={lp('/me')}
                  className="inline-flex items-center justify-center gap-2 rounded-lg border border-brand-accent/40 bg-brand-accent/10 px-5 py-3 font-display font-semibold text-brand-accent transition-all min-h-[44px] hover:bg-brand-accent/20 hover:border-brand-accent/70 hover:-translate-y-0.5"
                  data-bcl-cta="hero-dashboard"
                >
                  <span aria-hidden>📅</span>
                  {t.manageJobs}
                </a>
                <a href="#services" className="tt-btn tt-btn--ghost text-base">
                  {t.seeWhatWeDo}
                </a>
              </div>
              <SocialProofLine />
              <p className="mt-5 text-sm text-brand-mute" data-animate="fade-up" data-delay="420">
                <span className="text-brand-ink font-semibold">{t.popularCities}</span>{' '}
                <a href={lp('/c/newark')} className="text-brand-accent underline-hover">
                  Newark
                </a>{' '}
                ·{' '}
                <a href={lp('/c/jersey-city')} className="text-brand-accent underline-hover">
                  Jersey City
                </a>{' '}
                ·{' '}
                <a href={lp('/c/paterson')} className="text-brand-accent underline-hover">
                  Paterson
                </a>{' '}
                ·{' '}
                <a href={lp('/c/elizabeth')} className="text-brand-accent underline-hover">
                  Elizabeth
                </a>{' '}
                ·{' '}
                <a href={lp('/c/east-orange')} className="text-brand-accent underline-hover">
                  East Orange
                </a>{' '}
                ·{' '}
                <a href={lp('/c/hoboken')} className="text-brand-accent underline-hover">
                  Hoboken
                </a>{' '}
                ·{' '}
                <a href={lp('/#coverage')} className="text-brand-accent underline-hover">
                  {t.allFifty.replace('{n}', String(CITIES.length))}
                </a>
              </p>
              <ul
                className="mt-12 grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-x-4 gap-y-5 text-sm"
                data-stagger="80"
              >
                <li data-animate="fade-up">
                  <div className="font-display text-3xl font-extrabold text-brand-accent">
                    <span data-count="50" data-count-prefix="$" data-count-suffix="/hr">
                      $50/hr
                    </span>
                  </div>
                  <div className="text-brand-mute">{t.perPersonFlat}</div>
                </li>
                <li data-animate="fade-up">
                  <div className="font-display text-3xl font-extrabold text-brand-accent">
                    <span data-count="60" data-count-suffix="s">
                      60s
                    </span>
                  </div>
                  <div className="text-brand-mute">{t.toBookOnline}</div>
                </li>
                <li data-animate="fade-up">
                  <div className="font-display text-3xl font-extrabold text-brand-accent">1–4</div>
                  <div className="text-brand-mute">{t.crewSizes}</div>
                </li>
                <li data-animate="fade-up">
                  <div className="font-display text-3xl font-extrabold text-brand-accent">
                    <span data-count={CITIES.length} data-count-suffix=" cities">
                      {CITIES.length} cities
                    </span>
                  </div>
                  <div className="text-brand-mute">{t.acrossNjNyc}</div>
                </li>
                <li data-animate="fade-up" className="col-span-2 sm:col-span-1">
                  <div className="font-display text-3xl font-extrabold text-brand-accent">
                    <a
                      href={lp('/me')}
                      className="underline-hover"
                      data-bcl-cta="hero-stat-dashboard"
                    >
                      /me
                    </a>
                  </div>
                  <div className="text-brand-mute">{t.meDashboardDesc}</div>
                </li>
              </ul>
              <p
                className="mt-8 text-xs text-brand-mute max-w-xl leading-relaxed"
                data-animate="fade-up"
                data-delay="600"
              >
                <a
                  href={lp('/blog/casual-labor-vs-licensed-contractor')}
                  className="underline-hover"
                >
                  {t.casualLaborLink}
                </a>
                {t.casualLaborPost}
              </p>
            </div>

            <form
              onSubmit={handleQuote}
              className="tt-card sticky top-24 self-start lg:max-w-sm"
              data-animate="slide-left"
              data-delay="200"
              aria-labelledby="quote-title"
            >
              <p className="eyebrow mb-2">{t.instantQuote}</p>
              <h2 id="quote-title" className="font-display text-2xl font-bold mb-1">
                {t.knowPrice}
              </h2>
              <p className="text-sm text-brand-mute mb-5">{t.noRunaround}</p>

              <fieldset className="mb-5">
                <legend className="label mb-2 w-full">
                  <span className="flex w-full items-baseline justify-between gap-3">
                    <span>{t.hours}</span>
                    <span className="font-mono text-sm text-brand-accent whitespace-nowrap">
                      {hours}h
                    </span>
                  </span>
                </legend>
                <div
                  role="radiogroup"
                  aria-label={t.hours}
                  data-testid="hero-hours-group"
                  className="grid grid-cols-7 gap-1.5"
                >
                  {HOURS.map((h, i) => (
                    <button
                      key={h}
                      type="button"
                      role="radio"
                      aria-checked={hours === h}
                      aria-label={`${h} ${t.hours}`}
                      onClick={() => setHours(h)}
                      {...hoursRadio(i, hours === h)}
                      className={`rounded-md border px-1 py-2 font-mono text-xs transition-colors focus-visible:outline-2 focus-visible:outline-brand-accent focus-visible:outline-offset-2 active:scale-95 ${
                        hours === h
                          ? 'border-brand-accent bg-brand-accent text-bg-primary'
                          : 'border-brand-line text-brand-mute hover:border-brand-accent hover:text-brand-accent'
                      }`}
                    >
                      {h}
                    </button>
                  ))}
                </div>
              </fieldset>

              <fieldset className="mb-6">
                <legend className="label mb-2 w-full">
                  <span className="flex w-full items-baseline justify-between gap-3">
                    <span>{t.crewSize}</span>
                    <span className="font-mono text-sm text-brand-accent whitespace-nowrap">
                      {crew} {crew === 1 ? t.person : t.people}
                    </span>
                  </span>
                </legend>
                <div
                  role="radiogroup"
                  aria-label={t.crewSize}
                  data-testid="hero-crew-group"
                  className="grid grid-cols-4 gap-1.5"
                >
                  {CREW.map((c, i) => (
                    <button
                      key={c}
                      type="button"
                      role="radio"
                      aria-checked={crew === c}
                      aria-label={`${c} ${c === 1 ? t.person : t.people}`}
                      onClick={() => setCrew(c)}
                      {...crewRadio(i, crew === c)}
                      className={`rounded-md border px-2 py-2 font-mono text-xs transition-colors focus-visible:outline-2 focus-visible:outline-brand-accent focus-visible:outline-offset-2 active:scale-95 ${
                        crew === c
                          ? 'border-brand-accent bg-brand-accent text-bg-primary'
                          : 'border-brand-line text-brand-mute hover:border-brand-accent hover:text-brand-accent'
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </fieldset>

              {/* Section 3 — removed "where's the job?" address picker + total
                preview. Hours + crew sliders stay; "Lock this slot" jumps
                straight to the booking form via the canonical scroll-to. */}
              <button type="submit" className="tt-btn tt-btn--primary w-full">
                {t.lockSlot}
              </button>
              <p className="mt-3 text-center text-[11px] text-brand-mute">{t.noCard}</p>
              <p className="mt-4 border-t border-brand-line pt-3 text-center text-[11px] leading-relaxed text-brand-mute">
                {t.biggerJobPre}
                <a href="#contact" className="text-brand-accent underline-hover">
                  {t.dayRates}
                </a>
                {t.hiringAgency}
              </p>
            </form>
          </div>
        </div>
      </section>
    </GrainOverlay>
  );
}
