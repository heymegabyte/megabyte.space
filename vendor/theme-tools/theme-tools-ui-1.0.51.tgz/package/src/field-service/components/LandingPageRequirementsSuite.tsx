import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useState } from 'react';
import {
  STANDARDIZED_LANDING_PAGE_TEMPLATE_BLOCKS,
  type LongFormPageAuthorityDossier,
} from '@theme.tools/seo-geo/field-service/matrix-3d-engine';

export interface LandingPageRequirementsSuiteProps {
  readonly dossier: LongFormPageAuthorityDossier;
}

/**
 * 12-Pillar Landing Page Authority & Conversion Requirements Suite
 * (`@theme.tools/ui/field-service/components/LandingPageRequirementsSuite`).
 *
 * Implements all 12 additional high-converting landing page requirements:
 *   1. Municipal Parking Permit, Curbside Right-of-Way & Building COI Instant Generator
 *   2. Interactive Container, Box-Truck & Cubic-Foot Load Visualizer
 *   3. Side-by-Side Competitor & Broker Tariff Teardown Matrix
 *   4. Real-Time Dispatch Window, Drive-Time & Four-Season Weather Protocol Strip
 *   5. Verified Local Timecard Case Studies & Before/After Savings Ledger
 *   6. Physical Tool, Rigging & PPE Manifest Included at $0
 *   7. Honest Scope-of-Work & N.J.S.A. 45:14D Regulatory Boundary Disclosure
 *   8. Eco-Diversion, Local Donation Routing & Municipal Recycling Breakdown
 *   9. Interactive 4-Scene 60-Second Video Walkthrough Storyboard Player
 *  10. Instant Shareable Quote Permalink, SMS/WhatsApp Dispatch Deep-Link & Runbook Export
 *  11. 7-Node Schema.org Rich Graph & AI-Overview / LLM Atomic Fact Triples
 *  12. Post-Booking Customer Dashboard Lifecycle Preview (/dashboard Tabs)
 */
const SUBSTRATE_TEST_PATCH_PRESETS = [
  {
    id: 'ironbound-brick',
    label: '1890s Ironbound Clay Brick & Lime Mortar',
    neighborhood: 'Ferry St · Wilson Ave · Dr. MLK Jr. Blvd (07105 / 07102)',
    psi: '500 PSI (Soft-Wash)',
    nozzle: '40° White Fan Tip (14" Stand-Off)',
    dwellMinutes: 8,
    surfactant: 'EPA Safer Choice Biodegradable Masonry Wash',
    stainRemoved: 'Black I-280/Rt-21 diesel soot, green algae & atmospheric biofilm',
    safetyOutcome: '0% lime-sand mortar erosion · Preserves 19th-century brick fireskin',
    productionRate: '400 sq ft / hr ($50–$100 typical facade & stoop)',
    imageUrl: '/cities/newark/local-1.jpg',
    beforeBg: '#261813',
    afterBg: '#8c3b24',
  },
  {
    id: 'james-st-brownstone',
    label: 'A.D. 1888 Belleville Brownstone Stoop & Porch',
    neighborhood: 'James St Commons · High St · Lincoln Park (07102)',
    psi: '450 PSI (Gentle Rinse)',
    nozzle: '40° White Tip + Natural Soft-Bristle Brush Agitation',
    dwellMinutes: 8,
    surfactant: 'pH-Neutral Historic Sandstone & Limestone Cleaner',
    stainRemoved: 'Urban carbon crust, biological soot & shaded riser mildew',
    safetyOutcome: 'Zero sedimentary bedding delamination or high-pressure spalling',
    productionRate: '1 stoop + 8 steps + cheek walls in 1.0–1.5 hrs ($50–$75)',
    imageUrl: '/cities/newark/local-4.jpg',
    beforeBg: '#271c19',
    afterBg: '#784b3a',
  },
  {
    id: 'roseville-concrete',
    label: '2-Car Poured Concrete Driveway & Sidewalk',
    neighborhood: 'Roseville · Vailsburg · Weequahic (07106 / 07107 / 07112)',
    psi: '3,200 PSI @ 4.0 GPM',
    nozzle: '16-Inch Dual-Nozzle Rotary Surface Cleaner (1,800 RPM)',
    dwellMinutes: 6,
    surfactant: 'Biodegradable Hydrocarbon Pre-Spot + High-Flow Sheet Rinse',
    stainRemoved: 'Deep-rooted black Gloeocapsa magma algae, tire marks & winter salt',
    safetyOutcome: '100% uniform slab brightness · Zero handheld wand "zebra stripes"',
    productionRate: '600–700 sq ft / hr ($75–$100 typical 2-car driveway)',
    imageUrl: '/guides/power-washing/hero.jpg',
    beforeBg: '#1f2421',
    afterBg: '#94a3b8',
  },
  {
    id: 'forest-hill-bluestone',
    label: 'Forest Hill Bluestone Stoop & Flagstone Patio',
    neighborhood: 'Branch Brook Park · Mt. Prospect Ave (07104)',
    psi: '1,500 PSI (Sweeping Pass)',
    nozzle: '25° Green Fan Tip (45° Sweeping Angle)',
    dwellMinutes: 10,
    surfactant: 'EPA Safer Choice Botanical Lichen & Moss Emulsifier',
    stainRemoved: 'Slippery green tree-canopy moss, white lichen crusts & oak leaf tannins',
    safetyOutcome: 'Preserves polymeric joint sand · Restores slip-resistant stone grit',
    productionRate: '450 sq ft / hr ($50–$100 typical stoop + walkway)',
    imageUrl: '/guides/power-washing/dry-sweep.jpg',
    beforeBg: '#1c2421',
    afterBg: '#475569',
  },
  {
    id: 'vinyl-aluminum-siding',
    label: 'Oxidized Vinyl, Aluminum & Clapboard Siding',
    neighborhood: 'North Newark · Ivy Hill · Upper Roseville (07104 / 07106)',
    psi: '600 PSI (Downward Soft-Wash)',
    nozzle: '65° Black Soap Tip + 40° White Downward Rinse',
    dwellMinutes: 8,
    surfactant: 'EPA Safer Choice Non-Caustic Mildew & Chalking Surfactant',
    stainRemoved: 'North-facing green mildew, spider webbing & chalky UV oxidation',
    safetyOutcome: 'Downward spray angle prevents water intrusion behind lap vents',
    productionRate: 'Full 2-story elevation in 1.5–2.5 hrs ($75–$125)',
    imageUrl: '/guides/power-washing/machine-electric.jpg',
    beforeBg: '#232924',
    afterBg: '#cbd5e1',
  },
  {
    id: 'commercial-storefront',
    label: 'Downtown Broad & Market Commercial Storefront',
    neighborhood: 'Downtown Broad St · Market St · Ferry St Retail (07102 / 07105)',
    psi: '3,200 PSI @ 4.0 GPM',
    nozzle: '16-Inch Rotary Surface Spinner + 25° Edge Detail Wand',
    dwellMinutes: 8,
    surfactant: 'EPA Safer Choice Food-Service Degreaser + Sidewalk Hose Ramps',
    stainRemoved: 'Foot-traffic grease, gum shadows & awning organic film',
    safetyOutcome: 'Passaic Basin MS4 storm-drain compliant · Weekly -8% ($46/hr) option',
    productionRate: '600 sq ft / hr ($75 one-time · $69 on Weekly -8% contract)',
    imageUrl: '/cities/newark/8.jpg',
    beforeBg: '#1c1f24',
    afterBg: '#64748b',
  },
] as const;

export function LandingPageRequirementsSuite({ dossier }: LandingPageRequirementsSuiteProps) {
  useThemeToolsSurface('landing-page-requirements-suite');
  const req = dossier.twelveRequirements;
  const town = dossier.townHeritage;

  const [selectedTierIdx, setSelectedTierIdx] = useState(1);
  const [selectedSceneIdx, setSelectedSceneIdx] = useState(0);
  const [selectedSubstrateIdx, setSelectedSubstrateIdx] = useState(0);
  const [testPatchRevealPct, setTestPatchRevealPct] = useState(68);
  const [copiedQuote, setCopiedQuote] = useState(false);

  const activeTier = req.cubicLoadTiers[selectedTierIdx] ?? req.cubicLoadTiers[0]!;
  const activeScene = req.videoStoryboardScenes[selectedSceneIdx] ?? req.videoStoryboardScenes[0]!;
  const activeSubstrate =
    SUBSTRATE_TEST_PATCH_PRESETS[selectedSubstrateIdx] ?? SUBSTRATE_TEST_PATCH_PRESETS[0]!;
  const isPowerWash =
    activeTier.id.startsWith('wash-tier-') ||
    dossier.keywordCluster.primaryKeyword.toLowerCase().includes('power washing');

  const handleCopyShareUrl = async () => {
    try {
      await navigator.clipboard.writeText(req.instantShareAndExport.shareableBookingUrl);
      setCopiedQuote(true);
      window.setTimeout(() => setCopiedQuote(false), 2500);
    } catch {
      setCopiedQuote(true);
    }
  };

  return (
    <div
      data-testid="twelve-landing-page-requirements-suite"
      className="space-y-10 my-12"
    >
      {/* Interactive Free 4-Sq-Ft (2ft × 2ft) Test-Patch Live Calibrator & Before/After Slider */}
      <section
        data-testid="interactive-test-patch-lab"
        aria-label={`Interactive Free 4-Sq-Ft Test-Patch Simulator and Substrate PSI Calibrator for ${town.townName}`}
        className="rounded-2xl border-2 border-brand-accent/60 bg-bg-elevated p-6 sm:p-8 shadow-glow"
      >
        <div className="flex flex-wrap items-start justify-between gap-4 mb-6">
          <div>
            <p className="font-mono text-xs uppercase tracking-[0.18em] text-brand-accent mb-1">
              INTERACTIVE FREE 4-SQ-FT (2FT × 2FT) SAMPLE TEST-PATCH SIMULATOR · {town.townName.toUpperCase()}, {town.state}
            </p>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-brand-ink">
              Preview Your Free 2ft × 2ft On-Site Test Patch by {town.townName} Surface Type
            </h3>
            <p className="mt-1 text-sm text-brand-mute max-w-3xl">
              Select your exterior material below and drag the live comparison slider to see how our technician calibrates water pressure (500–3,200 PSI), fan-tip angle, and EPA Safer Choice surfactant dwell time on your complimentary 4-sq-ft test patch before you authorize the full $50/hr wash.
            </p>
          </div>
          <a
            href={`${dossier.prefilledBookingUrl}${dossier.prefilledBookingUrl.includes('?') ? '&' : '?'}substrate=${encodeURIComponent(activeSubstrate.id)}&sample=free-4sqft-test-patch`}
            data-testid="test-patch-lab-book-cta"
            className="rounded-xl bg-brand-accent px-5 py-3 font-mono text-xs font-extrabold uppercase tracking-wider text-bg-primary hover:opacity-90 transition-opacity"
          >
            Book Free 2ft×2ft Sample on {activeSubstrate.label.split(' ')[1]} ($50/hr) →
          </a>
        </div>

        {/* Substrate Selector Pills */}
        <div className="grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3 mb-6">
          {SUBSTRATE_TEST_PATCH_PRESETS.map((preset, idx) => {
            const active = idx === selectedSubstrateIdx;
            return (
              <button
                key={preset.id}
                type="button"
                onClick={() => setSelectedSubstrateIdx(idx)}
                className={`rounded-xl border p-3.5 text-left transition ${
                  active
                    ? 'border-brand-accent bg-brand-accent/15 shadow-glow'
                    : 'border-brand-line bg-bg-primary/70 hover:border-brand-accent'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-mono text-[11px] font-bold text-brand-accent">
                    {preset.psi}
                  </span>
                  <span className="font-mono text-[10px] text-emerald-400">
                    {preset.dwellMinutes}-Min Dwell
                  </span>
                </div>
                <span className="mt-1 block text-sm font-extrabold text-brand-ink">
                  {preset.label}
                </span>
                <span className="mt-0.5 block text-[11px] text-brand-mute truncate">
                  {preset.neighborhood}
                </span>
              </button>
            );
          })}
        </div>

        {/* Interactive Split Comparison Box + Telemetry Readouts */}
        <div className="grid gap-6 lg:grid-cols-12 items-stretch">
          <div className="lg:col-span-7 flex flex-col justify-between rounded-2xl border border-brand-line bg-bg-primary p-5">
            <div className="flex items-center justify-between gap-2 mb-3">
              <span className="font-mono text-xs font-bold uppercase text-brand-mute">
                Unwashed Biofilm / Soot (Before)
              </span>
              <span className="rounded-full bg-brand-accent/20 px-3 py-0.5 font-mono text-xs font-extrabold text-brand-accent">
                2ft × 2ft (4 Sq Ft) Free Test Patch: {testPatchRevealPct}% Revealed
              </span>
              <span className="font-mono text-xs font-bold uppercase text-emerald-400">
                Calibrated Pass (After)
              </span>
            </div>

            {/* Visual Before/After Split Canvas With Real Newark & Power-Washing Photography */}
            <div className="relative h-64 w-full overflow-hidden rounded-xl border border-brand-line select-none bg-[#0a0d14]">
              {/* Before Layer (Unwashed Soot / Biofilm Filter Over Real Photo) */}
              <div
                style={{ backgroundColor: activeSubstrate.beforeBg }}
                className="absolute inset-0"
              >
                <img
                  src={activeSubstrate.imageUrl}
                  alt={`Before washing: ${activeSubstrate.label} in ${town.townName}`}
                  width={900}
                  height={560}
                  loading="eager"
                  className="h-full w-full object-cover"
                  style={{
                    filter: 'brightness(0.42) contrast(1.18) sepia(0.32) saturate(0.75)',
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/50 p-3.5">
                  <span className="inline-block w-fit rounded-md bg-black/85 border border-amber-400/50 px-2.5 py-1 font-mono text-[10px] font-bold uppercase text-amber-300 shadow">
                    BEFORE · UNWASHED BIOFILM &amp; SOOT
                  </span>
                </div>
              </div>

              {/* After Layer (Clipped by Slider % — Bright Calibrated Pass Over Real Photo) */}
              <div
                style={{
                  clipPath: `inset(0 0 0 ${100 - testPatchRevealPct}%)`,
                }}
                className="absolute inset-0"
              >
                <img
                  src={activeSubstrate.imageUrl}
                  alt={`After free 2ft × 2ft test patch: ${activeSubstrate.label} at ${activeSubstrate.psi}`}
                  width={900}
                  height={560}
                  loading="eager"
                  className="h-full w-full object-cover"
                  style={{
                    filter: 'brightness(1.08) contrast(1.06) saturate(1.12)',
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/45 p-3.5 flex justify-end items-start">
                  <span className="inline-block w-fit rounded-md bg-emerald-950/90 border border-emerald-400/60 px-2.5 py-1 font-mono text-[10px] font-bold uppercase text-emerald-300 shadow-lg">
                    AFTER · FREE 2FT × 2FT TEST PATCH ({activeSubstrate.psi})
                  </span>
                </div>
              </div>

              {/* Vertical Divider Line & Drag Handle */}
              <div
                style={{ left: `${100 - testPatchRevealPct}%` }}
                className="pointer-events-none absolute inset-y-0 -translate-x-1/2 flex flex-col items-center justify-center"
              >
                <div className="h-full w-1 bg-brand-accent shadow-[0_0_14px_rgba(255,107,26,0.9)]" />
                <div className="absolute flex h-9 w-9 items-center justify-center rounded-full border-2 border-white bg-brand-accent font-mono text-xs font-extrabold text-bg-primary shadow-xl">
                  ⇄
                </div>
              </div>
            </div>

            {/* Clean Before/After Summary Strip Below Image (Zero Clipped Text!) */}
            <div className="mt-3 grid gap-2 sm:grid-cols-2 text-xs">
              <div className="rounded-lg border border-brand-line bg-bg-elevated/80 px-3 py-2">
                <span className="font-mono text-[10px] uppercase text-amber-300 block">Before (Unwashed Surface)</span>
                <span className="text-brand-mute">{activeSubstrate.stainRemoved}</span>
              </div>
              <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-3 py-2">
                <span className="font-mono text-[10px] uppercase text-emerald-300 block">After 2ft × 2ft Test Patch</span>
                <span className="font-semibold text-brand-ink">✓ {activeSubstrate.safetyOutcome}</span>
              </div>
            </div>

            {/* Range Slider Control */}
            <div className="mt-4">
              <label className="flex items-center justify-between font-mono text-xs text-brand-mute mb-1.5">
                <span>Drag to Scrub 2ft × 2ft Free Test-Patch Reveal:</span>
                <span className="font-bold text-brand-accent">{testPatchRevealPct}% Clean Reveal</span>
              </label>
              <input
                type="range"
                min={10}
                max={95}
                value={testPatchRevealPct}
                onChange={(e) => setTestPatchRevealPct(Number(e.target.value))}
                aria-label="Scrub free 4-square-foot test-patch before and after comparison"
                className="w-full accent-brand-accent cursor-pointer"
              />
            </div>
          </div>

          {/* Right Column: Live Calibrated Engineering Spec for Selected Substrate */}
          <div className="lg:col-span-5 flex flex-col justify-between rounded-2xl border border-brand-line bg-bg-primary/90 p-5 space-y-4">
            <div>
              <span className="font-mono text-[11px] uppercase tracking-wider text-brand-accent">
                CALIBRATED ON-SITE TEST-PATCH RECIPE
              </span>
              <h4 className="mt-1 text-lg font-extrabold text-brand-ink">
                {activeSubstrate.label}
              </h4>
              <dl className="mt-3 space-y-2 text-xs">
                <div className="flex justify-between border-b border-brand-line/60 pb-1.5">
                  <dt className="text-brand-mute">Target Calibrated PSI:</dt>
                  <dd className="font-mono font-bold text-brand-accent">{activeSubstrate.psi}</dd>
                </div>
                <div className="flex justify-between border-b border-brand-line/60 pb-1.5">
                  <dt className="text-brand-mute">Nozzle / Rotary Deck:</dt>
                  <dd className="font-mono font-bold text-brand-ink text-right">{activeSubstrate.nozzle}</dd>
                </div>
                <div className="flex justify-between border-b border-brand-line/60 pb-1.5">
                  <dt className="text-brand-mute">Surfactant &amp; Dwell:</dt>
                  <dd className="font-mono font-bold text-emerald-400 text-right">
                    {activeSubstrate.dwellMinutes} Min · EPA Safer Choice
                  </dd>
                </div>
                <div className="flex justify-between border-b border-brand-line/60 pb-1.5">
                  <dt className="text-brand-mute">Substrate Protection:</dt>
                  <dd className="font-semibold text-brand-ink text-right">{activeSubstrate.safetyOutcome}</dd>
                </div>
                <div className="flex justify-between pb-1">
                  <dt className="text-brand-mute">Hourly Wash Output:</dt>
                  <dd className="font-mono font-bold text-brand-ink text-right">{activeSubstrate.productionRate}</dd>
                </div>
              </dl>
            </div>
            <div className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 p-3 text-xs text-emerald-200">
              <strong>Zero-Obligation Visual Proof:</strong> We wash and dry-squeegee this 2ft × 2ft test corner in front of you during the first 15 minutes so you approve the exact finish before full washing proceeds.
            </div>
          </div>
        </div>
      </section>

      {/* Requirement 2: Domain-Adaptive Surface Sq-Ft & PSI Calibrator (or Cubic-Foot Container Visualizer) */}
      <section
        data-testid="req-cubic-load-visualizer"
        aria-label={
          isPowerWash
            ? 'Interactive Surface Square-Footage, PSI and $50/hr Power-Wash Estimator'
            : 'Interactive Container, Box-Truck and Cubic-Foot Load Visualizer'
        }
        className="rounded-2xl border border-brand-line bg-bg-elevated p-6 sm:p-8"
      >
        <div className="flex flex-wrap items-start justify-between gap-4 mb-5">
          <div>
            <p className="font-mono text-xs uppercase tracking-[0.18em] text-brand-accent mb-1">
              {isPowerWash
                ? 'INTERACTIVE SURFACE SQUARE-FOOTAGE, PSI & $50/HR WASH ESTIMATOR'
                : 'INTERACTIVE CUBIC-FOOT & CONTAINER FIT VISUALIZER'}
            </p>
            <h3 className="text-2xl font-extrabold text-brand-ink">
              {isPowerWash
                ? `Match Your ${town.townName} Wash Area (Sq Ft) to Calibrated PSI, Dwell Time & Exact $50/hr Cost`
                : `Match Your ${town.townName} Property Volume to Exact Container, Pad & Strap Counts`}
            </h3>
          </div>
          <a
            href="https://bricklabor.com/book"
            className="rounded-xl bg-brand-accent px-4 py-2.5 font-mono text-xs font-extrabold uppercase tracking-wider text-bg-primary hover:opacity-90"
          >
            Reserve {activeTier.recommendedCrew} {isPowerWash ? 'Tech' : 'Crew'} × {activeTier.recommendedHours} Hrs (${activeTier.estimatedLaborUsd}) →
          </a>
        </div>

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {req.cubicLoadTiers.map((tier, idx) => {
            const active = idx === selectedTierIdx;
            return (
              <button
                key={tier.id}
                type="button"
                onClick={() => setSelectedTierIdx(idx)}
                className={`rounded-xl border p-4 text-left transition ${
                  active
                    ? 'border-brand-accent bg-brand-accent/15 shadow-glow'
                    : 'border-brand-line bg-bg-primary/60 hover:border-brand-accent'
                }`}
              >
                <span className="font-mono text-xs font-bold text-brand-accent block">
                  {isPowerWash
                    ? `~${tier.cubicFeetCapacity.toLocaleString()} sq. ft. Wash Scope`
                    : `${tier.cubicFeetCapacity} cu. ft. Max Cube`}
                </span>
                <span className="mt-1 block text-sm font-extrabold text-brand-ink">
                  {tier.containerOrTruckLabel}
                </span>
                <span className="mt-1 block text-xs text-brand-mute">
                  {tier.typicalHomeOrScope}
                </span>
                <span className="mt-3 inline-block rounded-md bg-bg-elevated px-2.5 py-1 font-mono text-xs font-bold text-brand-ink">
                  {tier.recommendedCrew} {isPowerWash ? 'Tech' : 'Crew'} × {tier.recommendedHours}h = ${tier.estimatedLaborUsd}
                </span>
              </button>
            );
          })}
        </div>

        <div className="mt-4 grid gap-4 sm:grid-cols-3 rounded-xl border border-brand-line bg-bg-primary/80 p-4 text-xs">
          <div>
            <span className="font-mono uppercase text-brand-mute block">
              {isPowerWash ? 'Calibrated Operating Pressure' : 'Quilted Pads Recommended'}
            </span>
            <span className="text-lg font-extrabold text-brand-ink">
              {isPowerWash
                ? `${activeTier.furniturePadsRequired.toLocaleString()} PSI (4.0 GPM Rig)`
                : `${activeTier.furniturePadsRequired} Furniture Blankets`}
            </span>
          </div>
          <div>
            <span className="font-mono uppercase text-brand-mute block">
              {isPowerWash ? 'EPA Safer Choice Dwell Time' : '48-Inch Bulkhead Tie-Downs'}
            </span>
            <span className="text-lg font-extrabold text-brand-accent">
              {isPowerWash
                ? `${activeTier.ratchetStrapsRequired} Min Surfactant Dwell + Free 4-Sq-Ft Sample`
                : `${activeTier.ratchetStrapsRequired} E-Track / Cam Straps`}
            </span>
          </div>
          <div>
            <span className="font-mono uppercase text-brand-mute block">Estimated Labor @ $50/hr Std</span>
            <span className="text-lg font-extrabold text-emerald-400">
              ${activeTier.estimatedLaborUsd} ({activeTier.recommendedCrew} {isPowerWash ? 'Tech' : 'Crew'} × {activeTier.recommendedHours} Hrs)
            </span>
          </div>
        </div>
      </section>

      {/* Collapsible Field Operations, Equipment Manifest, Pricing Comparison & Regulatory Drawer */}
      <details className="rounded-2xl border border-brand-line bg-bg-elevated p-5 sm:p-6">
        <summary className="cursor-pointer flex flex-wrap items-center justify-between gap-3">
          <div>
            <span className="font-mono text-[11px] uppercase tracking-[0.18em] text-brand-accent block">
              EXPAND {town.townName.toUpperCase()} PRICING COMPARISON, EQUIPMENT MANIFEST &amp; FIELD SPECS
            </span>
            <span className="text-base sm:text-lg font-extrabold text-brand-ink">
              View $50/hr vs. Franchise Cost Table, Included Commercial Equipment ($0), Recent {town.townName} Timecards &amp; COI Rules
            </span>
          </div>
          <span className="rounded-full bg-brand-accent/15 px-3 py-1 font-mono text-xs font-bold text-brand-accent">
            Expand Field Specs ▼
          </span>
        </summary>

        <div className="mt-6 space-y-8 border-t border-brand-line pt-6">
          {/* Requirement 3: Side-by-Side Competitor & Franchise Tariff Teardown Matrix */}
          <section
            data-testid="req-competitor-teardown-matrix"
            aria-label="Side-by-Side Competitor and Franchise Pricing Comparison Matrix"
            className="rounded-2xl border border-brand-line bg-bg-primary/60 p-6"
          >
            <p className="font-mono text-xs uppercase tracking-[0.18em] text-brand-accent mb-1">
              {isPowerWash
                ? 'TRANSPARENT PRICING COMPARISON · HOURLY WASH VS. PER-SQ-FT FRANCHISES'
                : 'TRANSPARENT COMPETITOR & BROKER TARIFF TEARDOWN'}
            </p>
            <h3 className="text-xl sm:text-2xl font-extrabold text-brand-ink mb-4">
              {isPowerWash
                ? `Brick Labor ($50/hr + Free 4-Sq-Ft Sample) vs. Per-Sq-Ft Franchises & DIY Rentals in ${town.townName}`
                : `Brick Labor ($50/hr Direct) vs. Gig Apps, Labor Brokers & Van-Line Minimums in ${town.townName}`}
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs sm:text-sm">
                <thead>
                  <tr className="border-b border-brand-line font-mono text-[11px] uppercase tracking-wider text-brand-mute">
                    <th className="py-3 pr-4">Provider Model</th>
                    <th className="py-3 px-3">Hourly / Base Rate</th>
                    <th className="py-3 px-3">{isPowerWash ? 'Equipment & Time Overhead' : 'Platform / Broker Markup'}</th>
                    <th className="py-3 px-3">{isPowerWash ? 'Chemical & Travel Fees' : 'Stair & Travel Fees'}</th>
                    <th className="py-3 px-3">{isPowerWash ? 'Test-Patch & Substrate Safety' : 'Building COI & Armor'}</th>
                    <th className="py-3 pl-3">Est. Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-brand-line/60">
                  {req.competitorTeardown.map((row) => (
                    <tr
                      key={row.providerType}
                      className={row.isBrickLabor ? 'bg-brand-accent/10 font-semibold text-brand-ink' : ''}
                    >
                      <td className="py-3 pr-4 font-bold text-brand-ink">{row.providerType}</td>
                      <td className="py-3 px-3 font-mono text-xs">{row.hourlyOrBaseModel}</td>
                      <td className="py-3 px-3 text-xs text-brand-mute">{row.platformOrBrokerFeePct}</td>
                      <td className="py-3 px-3 text-xs text-brand-mute">{row.stairAndCarrySurcharges}</td>
                      <td className="py-3 px-3 text-xs text-brand-mute">{row.coiAndDamageProtection}</td>
                      <td className="py-3 pl-3 font-mono font-extrabold text-brand-accent">
                        ${row.estimatedTotalForThisJobUsd}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
          {/* Master 18-Point Service & Quality Guarantee Accordion */}
          <details
            data-testid="standardized-template-blueprint-card"
            className="rounded-2xl border border-brand-accent/40 bg-bg-primary/60 p-5"
          >
            <summary className="cursor-pointer flex flex-wrap items-center justify-between gap-3">
              <div>
                <span className="font-mono text-[11px] uppercase tracking-[0.18em] text-brand-accent block">
                  18-POINT BRICK LABOR SERVICE &amp; QUALITY GUARANTEE · {town.townName.toUpperCase()}, {town.state}
                </span>
                <span className="text-sm sm:text-base font-extrabold text-brand-ink">
                  View All 18 Included Service, Calibration, Insurance &amp; Transparency Standards on This Dispatch
                </span>
              </div>
              <span className="rounded-full bg-brand-accent/15 px-3 py-1 font-mono text-xs font-bold text-brand-accent">
                18 / 18 Included Standards ▼
              </span>
            </summary>
            <div className="mt-4 overflow-x-auto border-t border-brand-line pt-4">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-brand-line font-mono text-[11px] uppercase text-brand-mute">
                    <th className="py-2 pr-3">#</th>
                    <th className="py-2 px-3">Service Pillar</th>
                    <th className="py-2 px-3">Included Standard</th>
                    <th className="py-2 px-3">Module</th>
                    <th className="py-2 px-3">Coverage Scope</th>
                    <th className="py-2 pl-3">Customer Benefit</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-brand-line/50">
                  {STANDARDIZED_LANDING_PAGE_TEMPLATE_BLOCKS.map((blk) => (
                    <tr key={blk.blockId}>
                      <td className="py-2 pr-3 font-mono font-bold text-brand-accent">
                        {String(blk.order).padStart(2, '0')}
                      </td>
                      <td className="py-2 px-3 font-mono text-[11px] text-brand-ink">
                        {blk.tier === 'tier-1-universal-core'
                          ? 'Core Guarantee'
                          : blk.tier === 'tier-2-dimension-adaptive'
                            ? 'Local & Surface Spec'
                            : 'Customer Portal & Proof'}
                      </td>
                      <td className="py-2 px-3 font-bold text-brand-ink">{blk.title}</td>
                      <td className="py-2 px-3 font-mono text-[11px] text-brand-accent">
                        {blk.themeToolsComponent}
                      </td>
                      <td className="py-2 px-3 text-brand-mute">{blk.activationRule}</td>
                      <td className="py-2 pl-3 text-brand-mute">{blk.conversionOrSeoRole}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </details>

          {/* Requirement 1 & 4: Municipal Spigot / Right-of-Way / Building COI + Dispatch & Weather Telemetry */}
          <div className="grid gap-6 lg:grid-cols-12">
            <section
              data-testid="req-municipal-permit-coi-card"
              aria-label={`Municipal Right-of-Way and Building COI Readiness for ${town.townName}`}
              className="lg:col-span-7 rounded-2xl border border-brand-line bg-bg-primary/60 p-6"
            >
              <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-brand-accent">
                {isPowerWash
                  ? `WATER SPIGOT, SIDEWALK RIGHT-OF-WAY & $1M/$2M COI READINESS`
                  : `MUNICIPAL CURBSIDE PERMIT, RIGHT-OF-WAY & BUILDING COI READINESS`}
              </p>
              <h3 className="mt-1 text-xl sm:text-2xl font-extrabold text-brand-ink">
                {req.municipalPermitAndCoi.authorityName}
              </h3>
              <div className="mt-4 space-y-3 text-xs sm:text-sm text-brand-mute">
                <p>
                  <strong className="text-brand-ink">
                    {isPowerWash
                      ? `Water Supply & Sidewalk Hose-Ramp Protocol (${req.municipalPermitAndCoi.temporaryNoParkingLeadHours}h Notice):`
                      : `Temporary No-Parking (TNP) Lead Window (${req.municipalPermitAndCoi.temporaryNoParkingLeadHours}h):`}
                  </strong>{' '}
                  {req.municipalPermitAndCoi.containerStreetPermitRule}
                </p>
                <p>
                  <strong className="text-brand-ink">Commercial &amp; HOA Certificate of Insurance (COI):</strong>{' '}
                  {req.municipalPermitAndCoi.coiCoverageLimits}
                </p>
                <p>
                  <strong className="text-brand-ink">
                    {isPowerWash ? 'Exterior Outlet, Botanical & Lead-Safe Protection:' : 'Freight Elevator & Lobby Armor:'}
                  </strong>{' '}
                  {req.municipalPermitAndCoi.elevatorProtectionSpec}
                </p>
              </div>
              <div className="mt-5 flex flex-wrap gap-3">
                <a
                  href={req.municipalPermitAndCoi.prefilledCoiBookingUrl}
                  className="rounded-xl bg-brand-accent px-4 py-2.5 font-mono text-xs font-extrabold uppercase tracking-wider text-bg-primary hover:opacity-90"
                >
                  {isPowerWash
                    ? 'Book Free 4-Sq-Ft Sample & Full Wash (COI Ready) →'
                    : 'Book with Pre-Checked Building COI & Elevator Note →'}
                </a>
              </div>
            </section>

            <section
              data-testid="req-dispatch-weather-strip"
              aria-label="Dispatch Drive Time and Four-Season Weather Readiness"
              className="lg:col-span-5 rounded-2xl border border-brand-line bg-bg-primary/60 p-6"
            >
              <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-brand-accent">
                LOCAL DISPATCH ETA &amp; 4-SEASON OPERATING PROTOCOL
              </p>
              <h3 className="mt-1 text-xl font-extrabold text-brand-ink">
                ~{req.dispatchAndWeatherTelemetry.driveMinutesFromNewark} Min from 07102 Newark · ~{req.dispatchAndWeatherTelemetry.driveMinutesFrom07054} Min from 07054
              </h3>
              <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                <div className="rounded-lg border border-brand-line bg-bg-primary/70 p-2.5">
                  <span className="font-mono text-[10px] uppercase text-brand-accent block">Morning Slot</span>
                  <span className="font-semibold text-brand-ink">{req.dispatchAndWeatherTelemetry.morningWindowLabel}</span>
                </div>
                <div className="rounded-lg border border-brand-line bg-bg-primary/70 p-2.5">
                  <span className="font-mono text-[10px] uppercase text-brand-accent block">Afternoon / Evening</span>
                  <span className="font-semibold text-brand-ink">{req.dispatchAndWeatherTelemetry.afternoonWindowLabel}</span>
                </div>
              </div>
              <ul className="mt-3 space-y-1.5 text-xs text-brand-mute">
                {req.dispatchAndWeatherTelemetry.seasonalProtocols.map((sp) => (
                  <li key={sp.season}>
                    <strong className="text-brand-ink">{sp.season}:</strong> {sp.protocol}
                  </li>
                ))}
              </ul>
            </section>
          </div>

      {/* Requirement 5 & 6: Local Timecard Case Studies + $0 Equipment & Rigging Manifest */}
      <div className="grid gap-6 lg:grid-cols-12">
        <section
          data-testid="req-local-case-studies"
          aria-label={`Verified Local Timecard Case Studies in ${town.townName}`}
          className="lg:col-span-6 rounded-2xl border border-brand-line bg-bg-elevated p-6"
        >
          <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-brand-accent">
            VERIFIED {town.townName.toUpperCase()} TIMECARD CASE STUDIES &amp; 15-MINUTE CLOSEOUTS
          </p>
          <h3 className="mt-1 text-xl font-extrabold text-brand-ink mb-4">
            {isPowerWash
              ? `Recent ${town.townName} Free Test-Patch & Full-Wash Timecards`
              : `Recent ${town.county} County Dispatches & 15-Minute Closeouts`}
          </h3>
          <div className="space-y-3.5">
            {req.localCaseStudies.map((cs) => (
              <article
                key={cs.id}
                className="rounded-xl border border-brand-line bg-bg-primary/70 p-4 space-y-1.5"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-mono text-xs font-bold text-brand-accent">
                    {cs.neighborhoodOrLandmark}
                  </span>
                  <span className="font-mono text-xs font-extrabold text-emerald-400">
                    ${cs.totalBilledUsd} ({cs.crewSize} {isPowerWash ? 'tech' : 'crew'} × {cs.billedHours}h · Saved ${cs.estimatedBrokerQuoteUsd - cs.totalBilledUsd})
                  </span>
                </div>
                <p className="text-xs font-semibold text-brand-ink">{cs.jobSummary}</p>
                <p className="text-xs italic text-brand-mute">{cs.customerQuote}</p>
              </article>
            ))}
          </div>
        </section>

        <section
          data-testid="req-tool-rigging-manifest"
          aria-label="Commercial Equipment and Surface Protection Manifest Included at $0"
          className="lg:col-span-6 rounded-2xl border border-brand-line bg-bg-elevated p-6"
        >
          <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-brand-accent">
            {isPowerWash
              ? 'COMMERCIAL POWER-WASH & SOFT-WASH RIG MANIFEST ($0 INCLUDED)'
              : 'COMMERCIAL TOOL & RIGGING MANIFEST ($0 INCLUDED)'}
          </p>
          <h3 className="mt-1 text-xl font-extrabold text-brand-ink mb-4">
            {isPowerWash
              ? `Commercial Wash Equipment Included on Every ${town.townName} Truck`
              : `Standard Rigging & Surface Armor on Every ${town.townName} Dispatch`}
          </h3>
          <div className="grid gap-3 sm:grid-cols-2">
            {req.toolAndRiggingManifest.map((item) => (
              <div
                key={item.code}
                className="rounded-xl border border-brand-line bg-bg-primary/70 p-3.5"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-mono text-[10px] font-bold text-brand-accent">{item.code}</span>
                  <span className="font-mono text-[10px] text-emerald-400">{item.quantityIncluded}</span>
                </div>
                <p className="mt-1 text-xs font-bold text-brand-ink">{item.name}</p>
                <p className="mt-1 text-[11px] text-brand-mute leading-relaxed">{item.purpose}</p>
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* Requirement 7 & 8: Scope & Regulatory Boundary + Environmental & Storm-Drain Protection */}
      <div className="grid gap-6 lg:grid-cols-12">
        <section
          data-testid="req-scope-boundary-card"
          aria-label="Scope of Work and Regulatory Boundary Disclosure"
          className="lg:col-span-7 rounded-2xl border border-brand-line bg-bg-elevated p-6"
        >
          <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-brand-accent">
            {isPowerWash
              ? 'HONEST SCOPE OF WORK · NPS PRESERVATION BRIEF 1 & EPA RRP LEAD-SAFE BOUNDARY'
              : 'HONEST SCOPE OF WORK & N.J.S.A. 45:14D TRANSPARENCY'}
          </p>
          <h3 className="mt-1 text-xl font-extrabold text-brand-ink">
            {isPowerWash
              ? 'What Our $50/hr Power-Washing Techs Execute vs. High-Rigging / Lead-Abatement Boundaries'
              : 'What Our $50/hr Crew Executes vs. Licensed Carrier / Trade Boundaries'}
          </h3>
          <p className="mt-1 text-xs text-brand-mute">{req.scopeAndRegulatoryBoundary.regulatoryCitation}</p>
          <div className="mt-4 grid gap-4 sm:grid-cols-2 text-xs">
            <div className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 p-4">
              <p className="font-mono font-bold uppercase text-emerald-300 mb-2">
                ✓ Included in $50/hr Hourly Rate
              </p>
              <ul className="space-y-1.5 text-brand-ink">
                {req.scopeAndRegulatoryBoundary.includedIn50HrLabor.map((line, i) => (
                  <li key={i}>• {line}</li>
                ))}
              </ul>
            </div>
            <div className="rounded-xl border border-amber-500/40 bg-amber-500/10 p-4">
              <p className="font-mono font-bold uppercase text-amber-300 mb-2">
                {isPowerWash ? '⚠ Prohibited / Specialized Abatement Scope' : '⚠ Requires Vehicle Rental or Licensed Trade'}
              </p>
              <ul className="space-y-1.5 text-brand-mute">
                {req.scopeAndRegulatoryBoundary.requiresLicensedTradeOrCarrier.map((line, i) => (
                  <li key={i}>• {line}</li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        <section
          data-testid="req-eco-diversion-ledger"
          aria-label="Environmental Protection, Storm-Drain Compliance and Recycling Ledger"
          className="lg:col-span-5 rounded-2xl border border-brand-line bg-bg-elevated p-6"
        >
          <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-brand-accent">
            {isPowerWash
              ? `EPA SAFER CHOICE & PASSAIC BASIN MS4 STORM-DRAIN PROTECTION (${req.ecoDiversionAndDonation.targetDiversionPct}% BIODEGRADABLE)`
              : `ECO-DIVERSION & DONATION ROUTING (${req.ecoDiversionAndDonation.targetDiversionPct}% TARGET)`}
          </p>
          <h3 className="mt-1 text-xl font-extrabold text-brand-ink">
            {isPowerWash
              ? `${town.townName} Botanical Buffer & Watershed Compliance`
              : `${town.county} County Donation & Recycling Staging`}
          </h3>
          <p className="mt-2 font-mono text-xs font-bold text-brand-accent">
            {isPowerWash ? 'Environmental & Watershed Standards:' : 'Local Donation Drop-Off & Pickup Partners:'}
          </p>
          <ul className="mt-1 space-y-1 text-xs text-brand-mute">
            {req.ecoDiversionAndDonation.localDonationPartners.map((partner) => (
              <li key={partner}>▸ {partner}</li>
            ))}
          </ul>
          <p className="mt-3 font-mono text-xs font-bold text-brand-accent">
            {isPowerWash ? 'On-Site Runoff & Plant Protection Steps:' : 'Sorted Municipal Recycling Streams:'}
          </p>
          <ul className="mt-1 space-y-1 text-xs text-brand-mute">
            {req.ecoDiversionAndDonation.recyclingStreams.map((stream) => (
              <li key={stream}>▸ {stream}</li>
            ))}
          </ul>
        </section>
      </div>

      {/* Requirement 9: Interactive 4-Scene Walkthrough Storyboard Player */}
      <section
        data-testid="req-video-storyboard-player"
        aria-label="Interactive Shift Walkthrough Storyboard"
        className="rounded-2xl border border-brand-line bg-bg-elevated p-6 sm:p-8"
      >
        <div className="flex flex-wrap items-start justify-between gap-4 mb-5">
          <div>
            <p className="font-mono text-xs uppercase tracking-[0.18em] text-brand-accent mb-1">
              INTERACTIVE 4-STAGE ON-SITE EXECUTION WALKTHROUGH
            </p>
            <h3 className="text-2xl font-extrabold text-brand-ink">
              {isPowerWash
                ? `From Free 2ft × 2ft Test-Patch Calibration to Full ${town.townName} Property Wash Sign-Off`
                : `60-Second Shift Walkthrough: Threshold Check-In to 48-Inch Bulkhead Sign-Off`}
            </h3>
          </div>
          <a
            href="https://bricklabor.com/book"
            className="rounded-xl bg-brand-accent px-4 py-2.5 font-mono text-xs font-extrabold uppercase tracking-wider text-bg-primary hover:opacity-90"
          >
            Book This Workflow at bricklabor.com/book →
          </a>
        </div>

        <div className="grid gap-3 sm:grid-cols-4 mb-4">
          {req.videoStoryboardScenes.map((scene, idx) => (
            <button
              key={scene.sceneNumber}
              type="button"
              onClick={() => setSelectedSceneIdx(idx)}
              className={`rounded-xl border p-3.5 text-left transition ${
                idx === selectedSceneIdx
                  ? 'border-brand-accent bg-brand-accent/15'
                  : 'border-brand-line bg-bg-primary/60 hover:border-brand-accent'
              }`}
            >
              <span className="font-mono text-[11px] font-bold text-brand-accent block">
                {scene.timestampRange}
              </span>
              <span className="mt-1 block text-xs font-bold text-brand-ink">
                {scene.title}
              </span>
            </button>
          ))}
        </div>

        <div className="rounded-xl border border-brand-accent/40 bg-bg-primary/90 p-5">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
            <span className="font-mono text-xs font-bold text-brand-accent">
              {activeScene.timestampRange} · {activeScene.visualCallout}
            </span>
            <span className="font-mono text-xs text-brand-mute">
              Stage {activeScene.sceneNumber} of 4
            </span>
          </div>
          <h4 className="text-lg font-extrabold text-brand-ink">{activeScene.title}</h4>
          <p className="mt-2 text-sm text-brand-mute leading-relaxed">{activeScene.narration}</p>
        </div>
      </section>

      {/* Requirement 10, 11 & 12: Shareable Quote / SMS / WhatsApp Bar + Verified Service Facts + Dashboard Lifecycle */}
      <div className="grid gap-6 lg:grid-cols-12">
        <section
          data-testid="req-instant-share-export-bar"
          aria-label="Instant Shareable Quote Permalink, SMS and WhatsApp Dispatch Deep-Links"
          className="lg:col-span-5 rounded-2xl border border-brand-line bg-bg-elevated p-6 flex flex-col justify-between"
        >
          <div>
            <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-brand-accent">
              INSTANT ESTIMATE SHARE, SMS/WHATSAPP DISPATCH &amp; PREP RUNBOOK
            </p>
            <h3 className="mt-1 text-xl font-extrabold text-brand-ink">
              Share With a Spouse, Co-Owner, Landlord or Property Manager
            </h3>
            <p className="mt-2 text-xs text-brand-mute leading-relaxed">
              {req.instantShareAndExport.runbookChecklistSummary}
            </p>
          </div>
          <div className="mt-4 flex flex-col gap-2.5">
            <button
              type="button"
              onClick={() => void handleCopyShareUrl()}
              className="rounded-xl border border-brand-accent bg-brand-accent/15 px-4 py-2.5 font-mono text-xs font-bold text-brand-accent hover:bg-brand-accent/25 text-center"
            >
              {copiedQuote ? '✓ Copied Pre-Filled Booking Permalink!' : 'Copy Pre-Filled Booking Permalink'}
            </button>
            <div className="grid grid-cols-2 gap-2">
              <a
                href={req.instantShareAndExport.smsDispatchHref}
                className="rounded-xl border border-brand-line bg-bg-primary px-3 py-2 text-center font-mono text-xs font-bold text-brand-ink hover:border-brand-accent"
              >
                SMS Dispatch →
              </a>
              <a
                href={req.instantShareAndExport.whatsappDispatchHref}
                target="_blank"
                rel="noopener noreferrer"
                className="rounded-xl border border-brand-line bg-bg-primary px-3 py-2 text-center font-mono text-xs font-bold text-brand-ink hover:border-brand-accent"
              >
                WhatsApp Crew →
              </a>
            </div>
          </div>
        </section>

        <section
          data-testid="req-schema-ai-citation-capsule"
          aria-label="Verified Service Facts and Cited Specifications"
          className="lg:col-span-7 rounded-2xl border border-brand-line bg-bg-elevated p-6"
        >
          <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-brand-accent">
            VERIFIED {town.townName.toUpperCase()} SERVICE SPECIFICATIONS &amp; CITED FACTS
          </p>
          <h3 className="mt-1 text-xl font-extrabold text-brand-ink">
            At-a-Glance Pricing, Coverage &amp; Engineering Guarantees
          </h3>
          <div className="mt-3 space-y-2 text-xs">
            {req.aiOverviewAndSchemaGraph.atomicFactTriples.map((triple, idx) => (
              <div
                key={idx}
                className="rounded-lg border border-brand-line bg-bg-primary/70 p-2.5 flex flex-wrap items-center justify-between gap-2"
              >
                <span>
                  <strong className="text-brand-ink">{triple.subject}</strong>{' '}
                  <span className="text-brand-mute">{triple.predicate}</span>{' '}
                  <strong className="text-brand-accent">{triple.object}</strong>
                </span>
                <span className="font-mono text-[10px] text-brand-mute">[Ref {triple.citationIndex}]</span>
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* Requirement 12: Post-Booking Customer Dashboard Lifecycle Preview */}
      <section
        data-testid="req-dashboard-lifecycle-preview"
        aria-label="Post-Booking Customer Dashboard Lifecycle Preview"
        className="rounded-2xl border border-brand-line bg-bg-elevated p-6 sm:p-8"
      >
        <div className="flex flex-wrap items-start justify-between gap-4 mb-5">
          <div>
            <p className="font-mono text-xs uppercase tracking-[0.18em] text-brand-accent mb-1">
              CUSTOMER PORTAL &amp; LIVE JOB TRACKING (/DASHBOARD)
            </p>
            <h3 className="text-2xl font-extrabold text-brand-ink">
              What Unlocks in Your Customer Portal After You Book at bricklabor.com/book
            </h3>
          </div>
          <a
            href="https://bricklabor.com/book"
            className="rounded-xl bg-brand-accent px-5 py-3 font-mono text-xs font-extrabold uppercase tracking-wider text-bg-primary hover:opacity-90"
          >
            Start Booking at https://bricklabor.com/book →
          </a>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {req.postBookingDashboardStages.map((stage) => (
            <div
              key={stage.stepNumber}
              className="rounded-xl border border-brand-line bg-bg-primary/70 p-4"
            >
              <div className="flex items-center justify-between font-mono text-xs">
                <span className="font-bold text-brand-accent">0{stage.stepNumber} · {stage.tabRoute}</span>
              </div>
              <p className="mt-1.5 text-sm font-bold text-brand-ink">{stage.title}</p>
              <p className="mt-1 text-xs text-brand-mute leading-relaxed">{stage.capability}</p>
            </div>
          ))}
        </div>
      </section>
        </div>
      </details>
    </div>
  );
}

export default LandingPageRequirementsSuite;
