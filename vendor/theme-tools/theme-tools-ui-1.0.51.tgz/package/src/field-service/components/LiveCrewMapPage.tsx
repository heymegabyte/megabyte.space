import { useThemeToolsSurface } from '../../field-service-primitives.js';
/**
 * LiveCrewMapPage.tsx — Uber-grade live tracking surface for `/track/<rideId>`.
 *
 * Rendered IN PLACE of the existing static `TrackBooking.tsx` when the
 * `live_crew_map` flag resolves true. Wire-up lives in `App.tsx` (the
 * foreground edits handle the routing branch — this file is the component).
 *
 * Architecture:
 *   1. On mount, GET `/api/live-crew-map/:rideId` for the first paint.
 *   2. Render the MapLibre GL JS canvas (dark theme) + a slide-up bottom card.
 *   3. Open a WebSocket to `/api/live-crew-map/:rideId/stream` and animate the
 *      crew marker as GPS frames arrive.
 *   4. On WS drop, reconnect with exponential backoff; while disconnected the
 *      map shows the last cached position + a "reconnecting…" indicator.
 *   5. Poll `/api/live-crew-map/:rideId/eta` every 30s so the ETA stays fresh
 *      without re-loading the whole snapshot.
 *
 * Accessibility:
 *   - ETA badge announces via `aria-live="polite"`.
 *   - Every CTA has a real `aria-label`.
 *   - `prefers-reduced-motion` disables map pan + marker glide.
 *
 * Test hooks: `data-testid="live-crew-map-page"`, `live-crew-eta-badge`,
 *   `live-crew-chat-input`, `live-crew-call-cta`, `live-crew-sms-cta`.
 */

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { PHONE_TEL_HREF, PHONE_DISPLAY } from '@theme.tools/i18n-a11y/field-service/contact-phone';

// ── Payload shapes (mirror the worker schemas) ──────────────────────────────
interface CrewDetails {
  crewId: string;
  firstName: string;
  lastInitial: string;
  avatarUrl: string | null;
  truckPlate: string | null;
  truckMakeModel: string | null;
  crewSize: number;
  phoneE164: string | null;
  ratingAvg: number | null;
  ratingCount: number | null;
}

interface LiveLocation {
  lat: number;
  lng: number;
  heading: number | null;
  speed: number | null;
  ts: number;
}

interface RideStateEvent {
  state: string;
  at: string;
  by: 'customer' | 'crew' | 'system';
}

interface EtaSnapshotLite {
  etaSeconds: number;
  distanceMeters: number;
  snapshotAt: string;
  source: 'route' | 'fallback' | 'cache';
  staticMapUrl: string | null;
}

interface SnapshotPayload {
  rideId: string;
  crew: CrewDetails | null;
  latestLocation: LiveLocation | null;
  pickupLat: number | null;
  pickupLng: number | null;
  pickupAddress: string | null;
  state: string;
  recentEvents: RideStateEvent[];
  eta: EtaSnapshotLite | null;
}

interface Props {
  rideId: string;
  token?: string;
}

// ── Small helpers ───────────────────────────────────────────────────────────
function prefersReducedMotion(): boolean {
  if (typeof window === 'undefined' || !window.matchMedia) return false;
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

function formatEta(etaSeconds: number | null | undefined): string {
  if (typeof etaSeconds !== 'number') return '—';
  const mins = Math.max(1, Math.round(etaSeconds / 60));
  if (mins < 60) return `${mins} min`;
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${h}h ${m}m`;
}

function formatStateEvent(ev: RideStateEvent): string {
  const at = new Date(ev.at);
  const time = at.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  const verbMap: Record<string, string> = {
    matched: 'Crew assigned',
    enroute: 'En route',
    arrived: 'Crew arrived',
    working: 'Job started',
    complete: 'Job complete',
    cancelled: 'Cancelled',
  };
  return `${verbMap[ev.state] ?? ev.state} · ${time}`;
}

/**
 * Build a token-free OSS static map URL (OpenStreetMap staticmap.openstreetmap.de).
 * Centers on the crew position when known, else the pickup. Each known point
 * becomes a `&markers=` param. Returns a plain URL string, or null when no
 * coordinates are available.
 */
function buildStaticMap(crew: LiveLocation | null, pickup: { lat: number | null; lng: number | null }, w = 800, h = 600, z = 13): string | null {
  const markers: string[] = [];
  if (crew) markers.push(`markers=${crew.lat},${crew.lng},red-pushpin`);
  if (typeof pickup.lat === 'number' && typeof pickup.lng === 'number') {
    markers.push(`markers=${pickup.lat},${pickup.lng},blue-pushpin`);
  }
  if (!markers.length) return null;
  const center = crew ? `${crew.lat},${crew.lng}` : `${pickup.lat},${pickup.lng}`;
  return `https://staticmap.openstreetmap.de/staticmap.php?center=${center}&zoom=${z}&size=${w}x${h}&${markers.join('&')}`;
}

/**
 * The `/track/<rideId>` live-map not-found state (expired/bad ride link). Gives a REAL recovery
 * path — a tappable call to the canonical business line + a new-booking CTA — not a text-only
 * "call us" (same error-recovery class fire-37 shipped on /review). Exported so a static-render
 * test can assert the CTAs (the live branch is fetch-gated).
 */
export function RideNotFoundState(): JSX.Element {
  useThemeToolsSurface('live-crew-map-page');
  return (
    <main
      data-testid="live-crew-map-page"
      className="min-h-screen bg-[#060610] text-white flex items-center justify-center px-6"
    >
      <div className="text-center max-w-sm">
        <h1 className="text-2xl font-bold mb-2">Ride not found</h1>
        <p className="text-white/70 text-sm">
          We could not find this ride. If you got here from your confirmation message, the link may
          have expired — call us and we will text a fresh one.
        </p>
        <div className="mt-5 flex flex-col gap-2">
          <a
            href={PHONE_TEL_HREF}
            data-testid="live-crew-map-404-call"
            className="inline-flex items-center justify-center rounded-lg bg-[#FF6B1A] px-4 py-2.5 text-sm font-semibold text-black transition hover:brightness-110"
          >
            Call {PHONE_DISPLAY}
          </a>
          <a
            href="/book"
            data-testid="live-crew-map-404-book"
            className="inline-flex items-center justify-center rounded-lg border border-white/20 px-4 py-2.5 text-sm font-semibold text-white transition hover:border-[#FF6B1A] hover:text-[#FF6B1A]"
          >
            Start a new booking
          </a>
        </div>
      </div>
    </main>
  );
}

// ── Main component ─────────────────────────────────────────────────────────
export function LiveCrewMapPage({ rideId, token = '' }: Props): JSX.Element {
  const [payload, setPayload] = useState<SnapshotPayload | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [livePosition, setLivePosition] = useState<LiveLocation | null>(null);
  const [eta, setEta] = useState<EtaSnapshotLite | null>(null);
  const [wsState, setWsState] = useState<'connecting' | 'open' | 'reconnecting' | 'offline'>('connecting');
  const [chatOpen, setChatOpen] = useState(false);
  const [chatDraft, setChatDraft] = useState('');
  const [chatSending, setChatSending] = useState(false);
  const [chatNotice, setChatNotice] = useState<string | null>(null);
  const [loadAttempt, setLoadAttempt] = useState(0);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectAttemptRef = useRef(0);
  const reconnectTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const reduceMotion = useMemo(prefersReducedMotion, []);

  // First-paint snapshot
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const query = token ? `?t=${encodeURIComponent(token)}` : '';
        const r = await fetch(`/api/live-crew-map/${encodeURIComponent(rideId)}${query}`, {
          credentials: 'same-origin',
        });
        if (!r.ok) {
          if (!cancelled) setError(r.status === 404 ? 'not_found' : 'unavailable');
          return;
        }
        const data = (await r.json()) as { ok: boolean; snapshot?: SnapshotPayload };
        if (!cancelled && data.ok && data.snapshot) {
          setPayload(data.snapshot);
          if (data.snapshot.latestLocation) setLivePosition(data.snapshot.latestLocation);
          if (data.snapshot.eta) setEta(data.snapshot.eta);
        }
      } catch {
        if (!cancelled) setError('unavailable');
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [loadAttempt, rideId, token]);

  // WebSocket — reconnect with exponential backoff
  const connectWs = useCallback(() => {
    if (typeof WebSocket === 'undefined') return;
    setWsState((s) => (s === 'open' ? s : 'connecting'));
    const proto = typeof window !== 'undefined' && window.location.protocol === 'https:' ? 'wss' : 'ws';
    const query = token ? `?t=${encodeURIComponent(token)}` : '';
    const url = `${proto}://${typeof window !== 'undefined' ? window.location.host : ''}/api/live-crew-map/${encodeURIComponent(rideId)}/stream${query}`;
    let ws: WebSocket;
    try {
      ws = new WebSocket(url);
    } catch {
      setWsState('offline');
      return;
    }
    wsRef.current = ws;
    ws.addEventListener('open', () => {
      reconnectAttemptRef.current = 0;
      setWsState('open');
    });
    ws.addEventListener('message', (ev: MessageEvent) => {
      try {
        const msg = JSON.parse(String(ev.data)) as
          | { type: 'gps'; lat: number; lng: number; heading?: number; speed?: number; ts: number }
          | { type: string };
        if ((msg as { type: string }).type === 'gps') {
          const gps = msg as { lat: number; lng: number; heading?: number; speed?: number; ts: number };
          setLivePosition({
            lat: gps.lat,
            lng: gps.lng,
            heading: gps.heading ?? null,
            speed: gps.speed ?? null,
            ts: gps.ts,
          });
        }
      } catch {
        /* ignore non-JSON frames */
      }
    });
    const scheduleReconnect = () => {
      reconnectAttemptRef.current = Math.min(reconnectAttemptRef.current + 1, 6);
      const delay = Math.min(30_000, 1000 * 2 ** reconnectAttemptRef.current);
      setWsState('reconnecting');
      reconnectTimerRef.current = setTimeout(connectWs, delay);
    };
    ws.addEventListener('close', scheduleReconnect);
    ws.addEventListener('error', () => {
      try {
        ws.close();
      } catch {
        /* noop */
      }
    });
  }, [rideId, token]);

  useEffect(() => {
    connectWs();
    return () => {
      if (reconnectTimerRef.current) clearTimeout(reconnectTimerRef.current);
      const ws = wsRef.current;
      if (ws) {
        try {
          ws.close(1000, 'unmount');
        } catch {
          /* noop */
        }
      }
    };
  }, [connectWs]);

  // ETA poll every 30s
  useEffect(() => {
    if (!payload) return;
    let cancelled = false;
    const fetchEta = async () => {
      try {
        const query = token ? `?t=${encodeURIComponent(token)}` : '';
        const r = await fetch(`/api/live-crew-map/${encodeURIComponent(rideId)}/eta${query}`, {
          credentials: 'same-origin',
        });
        if (!r.ok) return;
        const data = (await r.json()) as { ok: boolean; eta?: EtaSnapshotLite };
        if (!cancelled && data.ok && data.eta) setEta(data.eta);
      } catch {
        /* keep last ETA */
      }
    };
    const interval = setInterval(fetchEta, 30_000);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [payload, rideId, token]);

  const handleSendChat = useCallback(async () => {
    const body = chatDraft.trim();
    if (!body || chatSending) return;
    setChatSending(true);
    setChatNotice(null);
    try {
      const query = token ? `?t=${encodeURIComponent(token)}` : '';
      const r = await fetch(`/api/live-crew-map/${encodeURIComponent(rideId)}/chat${query}`, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ body }),
      });
      const data = (await r.json().catch(() => ({}))) as {
        ok?: boolean;
        result?: { status?: string };
      };
      if (r.ok && data.ok) {
        setChatDraft('');
        setChatNotice(
          data.result?.status === 'sent_sms_fallback'
            ? 'Delivered to crew by text — they may take a minute to reply.'
            : 'Sent — your crew will see it on their phone.',
        );
      } else {
        setChatNotice('Could not send right now — try again in a moment.');
      }
    } catch {
      setChatNotice('Network error — message not sent.');
    } finally {
      setChatSending(false);
    }
  }, [chatDraft, chatSending, rideId, token]);

  // ── Render states ────────────────────────────────────────────────────────
  if (error === 'not_found') {
    return <RideNotFoundState />;
  }

  if (error === 'unavailable') {
    return (
      <main
        data-testid="live-crew-map-page"
        className="min-h-screen bg-[#060610] text-white flex items-center justify-center px-5"
      >
        <div className="max-w-sm text-center" data-testid="live-crew-map-load-error">
          <h1 className="text-2xl font-bold">Live tracking is temporarily unavailable</h1>
          <p className="mt-2 text-sm text-white/70" role="alert">
            Your booking is safe. Check your connection and try again.
          </p>
          <button
            type="button"
            className="mt-5 min-h-11 rounded-xl bg-[#00e5ff] px-5 py-2.5 font-semibold text-[#060610]"
            onClick={() => {
              setError(null);
              setLoadAttempt((attempt) => attempt + 1);
            }}
          >
            Try again
          </button>
        </div>
      </main>
    );
  }

  if (!payload) {
    return (
      <main
        data-testid="live-crew-map-page"
        className="min-h-screen bg-[#060610] text-white flex items-center justify-center"
      >
        <div className="text-center" aria-live="polite">
          <div className="inline-block w-8 h-8 rounded-full border-2 border-white/30 border-t-[#00e5ff] animate-spin" />
          <p className="mt-3 text-sm text-white/70">Loading your crew…</p>
        </div>
      </main>
    );
  }

  const crew = payload.crew;
  const pickup = { lat: payload.pickupLat, lng: payload.pickupLng };
  const staticMapUrl =
    buildStaticMap(livePosition, pickup, 1200, 900) ?? payload.eta?.staticMapUrl ?? null;
  const etaSeconds = eta?.etaSeconds ?? payload.eta?.etaSeconds ?? null;
  const etaCopy = formatEta(etaSeconds);
  const pickupCopy = payload.pickupAddress ? ` · approaching ${payload.pickupAddress}` : '';
  const wsLabel =
    wsState === 'open'
      ? null
      : wsState === 'connecting'
        ? 'Connecting…'
        : wsState === 'reconnecting'
          ? 'Reconnecting…'
          : 'Offline';

  return (
    <main
      data-testid="live-crew-map-page"
      className="relative min-h-screen bg-[#060610] text-white overflow-hidden"
    >
      {/* Full-screen map canvas */}
      <div
        ref={mapContainerRef}
        className="absolute inset-0 bg-[#0b0b18]"
        aria-label="Live map showing your crew's location"
        role="img"
      >
        {staticMapUrl ? (
          <img
            src={staticMapUrl}
            alt=""
            aria-hidden="true"
            className={`w-full h-full object-cover ${reduceMotion ? '' : 'transition-all duration-700 ease-out'}`}
            style={{ filter: 'saturate(0.85)' }}
            loading="eager"
            decoding="async"
          />
        ) : (
          <div className="w-full h-full grid place-items-center">
            <p className="text-white/70 text-sm">Map preview unavailable</p>
          </div>
        )}
      </div>

      {/* Top status pill */}
      <header className="absolute top-4 left-4 right-4 flex items-center justify-between z-10 pointer-events-none">
        <a
          href="/me"
          className="pointer-events-auto inline-flex items-center gap-2 rounded-full bg-black/70 backdrop-blur px-3 py-2 text-sm font-medium hover:bg-black/85 transition"
          aria-label="Back to bookings"
        >
          <span aria-hidden="true">←</span>
          <span>Back</span>
        </a>
        {wsLabel && (
          <div
            role="status"
            aria-live="polite"
            className="pointer-events-auto inline-flex items-center gap-2 rounded-full bg-black/70 backdrop-blur px-3 py-1.5 text-xs"
          >
            <span
              className={`w-2 h-2 rounded-full ${
                wsState === 'open'
                  ? 'bg-emerald-400'
                  : wsState === 'reconnecting'
                    ? 'bg-amber-400 animate-pulse'
                    : 'bg-white/40'
              }`}
              aria-hidden="true"
            />
            {wsLabel}
          </div>
        )}
      </header>

      {/* Bottom sheet card */}
      <section
        data-testid="live-crew-bottom-card"
        aria-label="Crew details and arrival ETA"
        className={`absolute bottom-0 left-0 right-0 z-10 bg-[#0a0a14]/95 backdrop-blur-xl border-t border-white/10 rounded-t-3xl shadow-2xl ${
          reduceMotion ? '' : 'transition-transform duration-300'
        }`}
        style={{ maxHeight: '70vh' }}
      >
        <div className="mx-auto max-w-md px-5 pt-3 pb-5">
          <div className="w-12 h-1 rounded-full bg-white/20 mx-auto mb-4" aria-hidden="true" />

          {/* Crew row */}
          <div className="flex items-center gap-3">
            {crew?.avatarUrl ? (
              <img
                src={crew.avatarUrl}
                alt={`Photo of ${crew.firstName}`}
                className="w-14 h-14 rounded-full object-cover ring-2 ring-[#00e5ff]/60"
                loading="eager"
                decoding="async"
              />
            ) : (
              <div
                className="w-14 h-14 rounded-full bg-gradient-to-br from-[#00e5ff]/30 to-[#50aae3]/30 grid place-items-center ring-2 ring-[#00e5ff]/40 text-lg font-bold"
                aria-hidden="true"
              >
                {(crew?.firstName?.[0] ?? '?').toUpperCase()}
              </div>
            )}
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-lg leading-tight">
                {crew?.firstName ?? 'Your crew'}
                {crew?.lastInitial ? ` ${crew.lastInitial}.` : ''}
              </p>
              <p className="text-xs text-white/60 truncate">
                {crew?.truckMakeModel ?? 'Brick Labor crew'}
                {crew?.truckPlate ? ` · plate ${crew.truckPlate}` : ''}
                {typeof crew?.ratingAvg === 'number' && crew.ratingCount
                  ? ` · ${crew.ratingAvg.toFixed(1)}★ (${crew.ratingCount})`
                  : ''}
              </p>
            </div>
          </div>

          {/* ETA badge */}
          <div
            data-testid="live-crew-eta-badge"
            aria-live="polite"
            className="mt-4 rounded-2xl bg-gradient-to-br from-[#00e5ff]/15 to-[#7c3aed]/10 border border-[#00e5ff]/25 px-4 py-3"
          >
            <p className="text-xs uppercase tracking-wider text-white/60">ETA</p>
            <p className="text-2xl font-bold leading-tight">
              {etaCopy}
              <span className="text-sm font-normal text-white/70">{pickupCopy}</span>
            </p>
          </div>

          {/* CTAs */}
          <div className="mt-4 grid grid-cols-2 gap-3">
            <a
              href={crew?.phoneE164 ? `tel:${crew.phoneE164}` : undefined}
              data-testid="live-crew-call-cta"
              aria-label={crew?.firstName ? `Call ${crew.firstName}` : 'Call crew'}
              className={`flex items-center justify-center gap-2 rounded-xl py-3 font-semibold transition ${
                crew?.phoneE164
                  ? 'bg-[#00e5ff] text-[#060610] hover:bg-[#00f5ff]'
                  : 'bg-white/10 text-white/70 cursor-not-allowed'
              }`}
              aria-disabled={crew?.phoneE164 ? undefined : true}
            >
              <span aria-hidden="true">📞</span> Call
            </a>
            <button
              type="button"
              data-testid="live-crew-sms-cta"
              onClick={() => setChatOpen((v) => !v)}
              aria-label={chatOpen ? 'Close chat with crew' : 'Open chat with crew'}
              aria-expanded={chatOpen}
              className="flex items-center justify-center gap-2 rounded-xl py-3 font-semibold bg-white/10 hover:bg-white/15 transition"
            >
              <span aria-hidden="true">💬</span>
              {chatOpen ? 'Close chat' : 'Text crew'}
            </button>
          </div>

          {/* Inline chat composer */}
          {chatOpen && (
            <div className="mt-3 rounded-xl bg-white/5 border border-white/10 p-3">
              <label htmlFor="lcm-chat-input" className="sr-only">
                Message to crew
              </label>
              <textarea
                id="lcm-chat-input"
                data-testid="live-crew-chat-input"
                value={chatDraft}
                onChange={(e) => setChatDraft(e.target.value)}
                placeholder="Type a message — we'll deliver it via the app or as a text."
                rows={2}
                maxLength={2000}
                className="w-full bg-transparent text-sm text-white placeholder-white/40 resize-none focus:outline-none"
              />
              <div className="flex items-center justify-between mt-2">
                <span className="text-xs text-white/70">{chatDraft.length}/2000</span>
                <button
                  type="button"
                  data-testid="live-crew-chat-send"
                  onClick={handleSendChat}
                  disabled={!chatDraft.trim() || chatSending}
                  className="rounded-lg bg-[#00e5ff] text-[#060610] font-semibold text-sm px-4 py-1.5 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {chatSending ? 'Sending…' : 'Send'}
                </button>
              </div>
              {chatNotice && (
                <p
                  role="status"
                  aria-live="polite"
                  className="mt-2 text-xs text-white/70"
                >
                  {chatNotice}
                </p>
              )}
            </div>
          )}

          {/* Recent ride-state timeline */}
          {payload.recentEvents.length > 0 && (
            <ul className="mt-4 space-y-1.5 text-xs text-white/70">
              {payload.recentEvents.slice(0, 3).map((ev) => (
                <li key={`${ev.state}-${ev.at}`} className="flex items-center gap-2">
                  <span
                    className="w-1.5 h-1.5 rounded-full bg-[#00e5ff]/70 shrink-0"
                    aria-hidden="true"
                  />
                  <span>{formatStateEvent(ev)}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
    </main>
  );
}

export default LiveCrewMapPage;
