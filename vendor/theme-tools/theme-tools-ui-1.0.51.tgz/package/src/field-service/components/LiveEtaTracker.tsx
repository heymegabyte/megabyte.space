import { useThemeToolsSurface } from '../../field-service-primitives.js';
/**
 * LiveEtaTracker.tsx — Wave 27 #13 live ETA via WebSocket.
 *
 * Subscribes to /api/crew-location/:gigId/ws (CrewLocationDO) and renders a
 * compact "ETA: 7 min" + status pill that recomputes every 15 seconds from
 * incoming GPS frames. When the great-circle distance to the customer
 * dropoff drops below the 75m geofence, the pill flips to "Arrived".
 *
 * Gated by `wave27_live_job_map` — returns `null` when the flag is off.
 * The WebSocket connection is lazy: we don't even attempt to open it until
 * the flag check resolves true, so the upstream DO never sees a connect from
 * a disabled tenant.
 *
 * Reconnects with exponential backoff (1s → 30s) on disconnect, gives up at
 * 5 failed attempts and shows a friendly fallback.
 */

import { useEffect, useRef, useState } from 'react';
import type { StatusLocale } from '@theme.tools/scheduling/field-service/booking-status';
import { trackCopy } from '@theme.tools/i18n-a11y/field-service/track-copy';
import { useFeatureFlag } from '../use-feature-flag.js';

interface Props {
  gigId: string;
  dropoffLat?: number;
  dropoffLng?: number;
  /** Locale for the pill + ETA copy (defaults to English). */
  locale?: StatusLocale;
}

interface GpsFrame {
  lat: number;
  lng: number;
  speed_mps?: number;
  heading_deg?: number;
  ts: number;
}

const ARRIVAL_M = 75;
const RECALC_MS = 15_000;
const MAX_RETRIES = 5;

export function haversineMeters(a: GpsFrame, b: { lat: number; lng: number }): number {
  const R = 6371000;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

export function etaMinutes(distanceM: number, speedMps: number | undefined): number | null {
  const speed = speedMps && speedMps > 1 ? speedMps : 6; // 6 m/s ≈ city-driving default
  if (!isFinite(distanceM) || distanceM <= 0) return 0;
  return Math.max(1, Math.round(distanceM / speed / 60));
}

export function LiveEtaTracker({
  gigId,
  dropoffLat,
  dropoffLng,
  locale = 'en',
}: Props): JSX.Element | null {
  useThemeToolsSurface('live-eta-tracker');
  const t = trackCopy(locale);
  const enabled = useFeatureFlag('live_job_map');
  const [latest, setLatest] = useState<GpsFrame | null>(null);
  const [status, setStatus] = useState<'connecting' | 'live' | 'arrived' | 'lost'>('connecting');
  const [tick, setTick] = useState(0);
  const wsRef = useRef<WebSocket | null>(null);
  const retryRef = useRef(0);

  useEffect(() => {
    if (!enabled || !gigId) return;
    let cancelled = false;
    let reconnectTimer: ReturnType<typeof setTimeout> | null = null;

    const connect = () => {
      if (cancelled) return;
      const proto = window.location.protocol === 'https:' ? 'wss' : 'ws';
      const url = `${proto}://${window.location.host}/api/crew-location/${encodeURIComponent(gigId)}/ws`;
      const ws = new WebSocket(url);
      wsRef.current = ws;

      ws.addEventListener('open', () => {
        retryRef.current = 0;
        setStatus('live');
      });
      ws.addEventListener('message', (evt) => {
        try {
          const f = JSON.parse(evt.data) as GpsFrame;
          if (typeof f.lat === 'number' && typeof f.lng === 'number') setLatest(f);
        } catch {
          /* ignore malformed */
        }
      });
      ws.addEventListener('close', () => {
        if (cancelled) return;
        retryRef.current += 1;
        if (retryRef.current >= MAX_RETRIES) {
          setStatus('lost');
          return;
        }
        const backoff = Math.min(30_000, 1000 * 2 ** retryRef.current);
        reconnectTimer = setTimeout(connect, backoff);
      });
      ws.addEventListener('error', () => {
        ws.close();
      });
    };

    connect();
    const recalc = setInterval(() => setTick((n) => n + 1), RECALC_MS);

    return () => {
      cancelled = true;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      clearInterval(recalc);
      wsRef.current?.close();
    };
  }, [enabled, gigId]);

  // Geofence arrival check — runs whenever a new frame arrives OR the recalc
  // ticker fires (so we don't get stuck in "live" if the crew stopped moving
  // already inside the geofence).
  useEffect(() => {
    if (!latest || dropoffLat == null || dropoffLng == null) return;
    const dist = haversineMeters(latest, { lat: dropoffLat, lng: dropoffLng });
    if (dist <= ARRIVAL_M) setStatus('arrived');
  }, [latest, dropoffLat, dropoffLng, tick]);

  if (!enabled) return null;

  const distance =
    latest && dropoffLat != null && dropoffLng != null
      ? haversineMeters(latest, { lat: dropoffLat, lng: dropoffLng })
      : null;
  const eta = distance != null ? etaMinutes(distance, latest?.speed_mps) : null;

  const statusLabel =
    status === 'arrived'
      ? t.etaArrived
      : status === 'lost'
        ? t.etaSignalLost
        : status === 'connecting'
          ? t.etaConnecting
          : t.etaEnRoute;

  return (
    <section
      aria-live="polite"
      aria-atomic="true"
      className="rounded-2xl border border-white/10 bg-black/30 p-5 shadow-md"
      data-testid="live-eta-tracker"
    >
      <header className="mb-2 flex items-center justify-between">
        <h3 className="text-sm uppercase tracking-wider text-brand-accent">{t.liveStatus}</h3>
        <span
          className={`rounded-full px-3 py-1 text-xs font-semibold ${
            status === 'arrived'
              ? 'bg-emerald-500/20 text-emerald-300'
              : status === 'lost'
                ? 'bg-rose-500/20 text-rose-200'
                : 'bg-brand-accent/15 text-brand-accent'
          }`}
          role="status"
        >
          {statusLabel}
        </span>
      </header>

      {status === 'arrived' ? (
        <p className="text-2xl font-semibold">{t.crewArrivedMsg}</p>
      ) : eta != null ? (
        <p className="text-2xl font-semibold">
          {t.etaLabel} <span className="text-brand-accent">{eta}</span> {t.etaMin}
          {distance != null ? (
            <span className="ml-2 text-sm font-normal text-white/60">
              ({t.miOut.replace('{n}', String(Math.round((distance / 1609.344) * 10) / 10))})
            </span>
          ) : null}
        </p>
      ) : (
        <p className="text-sm text-white/60">{t.waitingGps}</p>
      )}

      {status === 'lost' ? (
        <p className="mt-2 text-xs text-white/60">{t.signalLostMsg}</p>
      ) : null}
    </section>
  );
}
