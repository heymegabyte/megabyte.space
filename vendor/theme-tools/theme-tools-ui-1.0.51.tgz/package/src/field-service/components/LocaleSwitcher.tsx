import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect, useState } from 'react';
import {
  htmlLangFor,
  localizedPath,
  LOCALES,
  stripLocalePrefix,
  type LocaleCode,
} from '@theme.tools/i18n-a11y/field-service/locale';

/**
 * Locale switcher.
 *
 * Per [[i18n-by-demographics]]: Newark NJ → en + es + pt mirrors required.
 * Renders the switcher, persists choice to localStorage, sets <html lang>, and
 * re-routes to the locale-prefixed equivalent. The `/es/*` + `/pt/*` mirror
 * pages are prerendered by `scripts/build-locale-mirrors.mjs`; unmirrored paths
 * resolve through the worker's single-page-application ASSETS fallback, so
 * switching locale never 404s. Prefix <-> path math lives in `shared/locale.ts`
 * (the same module `App.tsx` uses to route mirror pages).
 */

function detectLocale(): LocaleCode {
  if (typeof window === 'undefined') return 'en';
  try {
    const stored = localStorage.getItem('bcl_locale');
    if (stored === 'en' || stored === 'es' || stored === 'pt') return stored;
  } catch {
    /* ignore */
  }
  const { locale } = stripLocalePrefix(window.location.pathname);
  if (locale !== 'en') return locale;
  const lang = (navigator.language ?? 'en').slice(0, 2).toLowerCase();
  if (lang === 'es' || lang === 'pt') return lang as LocaleCode;
  return 'en';
}

export function LocaleSwitcher({ inline }: { inline?: boolean }) {
  useThemeToolsSurface('locale-switcher');
  const [locale, setLocale] = useState<LocaleCode>('en');

  useEffect(() => {
    setLocale(detectLocale());
  }, []);

  useEffect(() => {
    if (typeof document !== 'undefined') document.documentElement.lang = htmlLangFor(locale);
  }, [locale]);

  function pick(code: LocaleCode) {
    setLocale(code);
    try {
      localStorage.setItem('bcl_locale', code);
    } catch {
      /* ignore */
    }
    // Re-route to the locale-prefixed equivalent of the CURRENT route. Strip
    // any existing /es|/pt prefix first so switching es → pt (or back to en)
    // never stacks prefixes.
    const { path } = stripLocalePrefix(window.location.pathname);
    const next = localizedPath(code, path);
    window.location.assign(next + window.location.search + window.location.hash);
  }

  if (inline) {
    return (
      <select
        id="locale-switcher"
        name="locale"
        autoComplete="language"
        value={locale}
        onChange={(e) => pick(e.target.value as LocaleCode)}
        aria-label="Select language"
        className="rounded-md border border-brand-line bg-bg-elevated px-2 py-1 text-xs text-brand-ink"
      >
        {LOCALES.map((l) => (
          <option key={l.code} value={l.code}>
            {l.flag} {l.name}
          </option>
        ))}
      </select>
    );
  }

  return (
    <div role="group" aria-label="Language" className="inline-flex gap-1">
      {LOCALES.map((l) => (
        <button
          key={l.code}
          type="button"
          onClick={() => pick(l.code)}
          aria-pressed={locale === l.code}
          className={`rounded-md border px-2 py-1 text-xs transition ${
            locale === l.code
              ? 'border-brand-accent bg-brand-accent/10 text-brand-ink'
              : 'border-brand-line bg-bg-elevated text-brand-mute hover:text-brand-ink'
          }`}
        >
          <span aria-hidden>{l.flag}</span> {l.name}
        </button>
      ))}
    </div>
  );
}
