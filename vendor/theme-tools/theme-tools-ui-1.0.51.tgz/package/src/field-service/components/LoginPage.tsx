import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AuthShell, AuthError, type AuthStage } from './auth/AuthShell.js';
import { LoginShell } from './auth/LoginShell.js';
import { SignInWithAppleButton } from './auth/SignInWithAppleButton.js';
import { useRovingRadio } from '../use-roving-radio.js';
import { useFeatureFlag } from '../use-feature-flag.js';

// Unified /login page — magic-link auth for customers AND crew on a single screen.
// Customer pane: email|phone → 6-digit code → /me dashboard.
// Crew pane:     phone (+optional name on signup) → 6-digit code → /work/dashboard.

const TITLE = 'Log In — Brick Labor';
const DESC =
  'Log in to view your bookings, reschedule, or chat with your Newark crew. Magic-link login by email or phone — no password to remember.';

const STORAGE_LAST_AUDIENCE = 'bcl-login-audience-v1';
const STORAGE_ACTIVE_ROLE = 'bcl_active_role';
const STORAGE_LAST_CONTACT_CUST = 'bcl-login-contact-cust-v1';
const STORAGE_LAST_PHONE_CREW = 'bcl-login-phone-crew-v1';
const RESEND_COOLDOWN_S = 30;

type Audience = 'customer' | 'crew' | 'admin';
type Stage = AuthStage;
type CrewIntent = 'login' | 'signup';

// ── /api/auth/identify wiring ────────────────────────────────────────────────
// The endpoint disclosed roles[] for an identifier so a returning user can
// be auto-routed (single role) or shown a Continue-as picker (multi-role).
// hasPasskey:true also surfaces the WebAuthn fast-path button.
type IdentifiedRole = 'customer' | 'crew' | 'admin';
interface IdentifyResponse {
  roles: IdentifiedRole[];
  hasPasskey: boolean;
  lastRole?: IdentifiedRole;
}
async function identify(identifier: string): Promise<IdentifyResponse | null> {
  if (!identifier.trim()) return null;
  try {
    const res = await fetch('/api/auth/identify', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ identifier: identifier.trim() }),
    });
    if (!res.ok) {
      // 5xx = server error → throw so the caller's catch surfaces "Connection
      // issue. Try again." instead of silently proceeding (SCAN-06 — a swallowed
      // identify read as "sign-in does nothing"). 4xx (e.g. unknown identifier)
      // → null so the flow proceeds gracefully (new-user / crew-via-email path).
      if (res.status >= 500) throw new Error(`identify_${res.status}`);
      return null;
    }
    const data = (await res.json()) as IdentifyResponse;
    return data;
  } catch (err) {
    // Network/server failure → rethrow so the caller shows "Connection issue.
    // Try again." rather than silently returning null and proceeding (SCAN-06).
    throw err instanceof Error ? err : new Error('identify_network');
  }
}

/** Pure helper — derives initial active tab from URL/storage. Exported for testing. */
export function resolveInitialAudience(
  search: string,
  storage: string | null,
  fallback: Audience = 'customer',
): Audience {
  const params = new URLSearchParams(search);
  const tab = params.get('as') || params.get('kind');
  if (tab === 'admin' || tab === 'crew' || tab === 'customer') return tab;
  if (storage === 'admin' || storage === 'crew' || storage === 'customer') return storage;
  return fallback;
}

function asErrorText(value: unknown, fallback: string): string {
  if (typeof value === 'string' && value) return value;
  if (value && typeof value === 'object' && 'message' in value) {
    const m = (value as { message?: unknown }).message;
    if (typeof m === 'string' && m) return m;
  }
  return fallback;
}

function looksLikeEmail(s: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s.trim());
}

function looksLikePhone(s: string): boolean {
  const digits = s.replace(/\D/g, '');
  return digits.length >= 10 && digits.length <= 11;
}

/**
 * Derives the inline-validity glyph state for a contact field.
 * - `valid`   → parses as email or US phone (ready to submit)
 * - `invalid` → user has typed ENOUGH to judge it wrong (an `@` present but not
 *               a valid email, or 4+ digits but not a complete 10/11-digit phone)
 * - `idle`    → too little typed to judge (show nothing, never nag early)
 * Pure + exported for unit testing.
 */
export function contactValidityState(
  contact: string,
  canStart: boolean,
): 'idle' | 'valid' | 'invalid' {
  const t = contact.trim();
  if (!t) return 'idle';
  if (canStart) return 'valid';
  const digits = t.replace(/\D/g, '');
  const looksLikeEmailAttempt = t.includes('@') && t.length > 3;
  const looksLikePhoneAttempt = digits.length >= 4 && !t.includes('@');
  if (looksLikeEmailAttempt || looksLikePhoneAttempt) return 'invalid';
  return 'idle';
}

function formatPhone(s: string): string {
  const d = s.replace(/\D/g, '').slice(0, 10);
  if (d.length < 4) return d;
  if (d.length < 7) return `(${d.slice(0, 3)}) ${d.slice(3)}`;
  return `(${d.slice(0, 3)}) ${d.slice(3, 6)}-${d.slice(6)}`;
}

function readString(key: string): string {
  try {
    return localStorage.getItem(key) || '';
  } catch {
    return '';
  }
}
function writeString(key: string, value: string): void {
  try {
    if (value) localStorage.setItem(key, value);
    else localStorage.removeItem(key);
  } catch {
    /* ignore */
  }
}

function useResendCooldown(): { left: number; start: () => void; reset: () => void } {
  const [left, setLeft] = useState(0);
  const timerRef = useRef<number | null>(null);
  const clear = useCallback(() => {
    if (timerRef.current !== null) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, []);
  const start = useCallback(() => {
    clear();
    setLeft(RESEND_COOLDOWN_S);
    timerRef.current = window.setInterval(() => {
      setLeft((n) => {
        if (n <= 1) {
          clear();
          return 0;
        }
        return n - 1;
      });
    }, 1000);
  }, [clear]);
  const reset = useCallback(() => {
    clear();
    setLeft(0);
  }, [clear]);
  useEffect(() => clear, [clear]);
  return { left, start, reset };
}

function safeNext(raw: string | null): string | null {
  if (!raw) return null;
  if (!raw.startsWith('/') || raw.startsWith('//')) return null;
  return raw;
}

const TERMS_FOOTER = (
  <>
    By continuing you agree to our{' '}
    <a href="/terms" className="underline-hover text-brand-mute">
      Terms
    </a>{' '}
    and{' '}
    <a href="/privacy" className="underline-hover text-brand-mute">
      Privacy Policy
    </a>
    . We text or email the code only — no spam, no upsell.
  </>
);

export interface LoginPageProps {
  /** When provided, pre-selects the tab + skips the URL/storage inference. */
  initialAudience?: Audience;
}

export function LoginPage({ initialAudience }: LoginPageProps = {}) {
  useThemeToolsSurface('login-page');
  // `audience` only drives the eyebrow/headline copy for the deep-link panes
  // (/login/crew|admin|customer). Bare /login renders the auto-routing
  // UnifiedPane, so there are no tabs to switch.
  const [audience, setAudienceState] = useState<Audience>(initialAudience ?? 'customer');
  const [stage, setStage] = useState<Stage>('contact');
  const [checking, setChecking] = useState(true);
  // When both customer + crew sessions are present, render an explicit
  // chooser instead of auto-bouncing between /me and /work/dashboard.
  const [dualRole, setDualRole] = useState<{ isCustomer: boolean; isCrew: boolean } | null>(null);

  useEffect(() => {
    document.title = TITLE;
    const meta = document.querySelector('meta[name="description"]');
    if (meta) meta.setAttribute('content', DESC);
    if (initialAudience) {
      setAudienceState(initialAudience);
      return;
    }
    setAudienceState(
      resolveInitialAudience(window.location.search, readString(STORAGE_LAST_AUDIENCE)),
    );
  }, [initialAudience]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [crewRes, custRes, whoamiRes] = await Promise.all([
          fetch('/api/work/auth/me', { credentials: 'include' }).catch(() => null),
          fetch('/api/auth/client/me', { credentials: 'include' }).catch(() => null),
          fetch('/api/auth/whoami', { credentials: 'include' }).catch(() => null),
        ]);
        if (cancelled) return;
        const params = new URLSearchParams(window.location.search);
        const next = safeNext(params.get('next'));
        const tab = params.get('as') || params.get('kind');
        const preferCrew = tab === 'crew';
        // /api/*/me intentionally return 200 with `{authenticated:false}` to
        // avoid console-error spam on every unauthenticated page load. Inspect
        // the JSON envelope, NOT res.ok, to know whether the user is signed in.
        const crewBody =
          crewRes && crewRes.ok
            ? ((await crewRes
                .clone()
                .json()
                .catch(() => null)) as { authenticated?: boolean } | null)
            : null;
        const custBody =
          custRes && custRes.ok
            ? ((await custRes
                .clone()
                .json()
                .catch(() => null)) as { authenticated?: boolean } | null)
            : null;
        const whoamiBody =
          whoamiRes && whoamiRes.ok
            ? ((await whoamiRes
                .clone()
                .json()
                .catch(() => null)) as {
                whoami?: { role?: string | null; isSuperAdmin?: boolean };
              } | null)
            : null;
        const crewOk = crewBody?.authenticated === true;
        const custOk = custBody?.authenticated === true;
        const adminOk =
          whoamiBody?.whoami?.isSuperAdmin === true ||
          whoamiBody?.whoami?.role === 'super_admin' ||
          whoamiBody?.whoami?.role === 'admin';
        // Dual-role: never auto-bounce. Show a chooser unless the URL/storage
        // already disambiguates via `?as=crew|customer` or a saved active role.
        if (crewOk && custOk) {
          const saved = readString(STORAGE_ACTIVE_ROLE);
          if (preferCrew || tab === 'customer') {
            const dest = preferCrew ? next || '/work/dashboard' : next || '/me';
            window.location.replace(dest);
            return;
          }
          if (saved === 'crew') {
            window.location.replace(next || '/work/dashboard');
            return;
          }
          if (saved === 'customer') {
            window.location.replace(next || '/me');
            return;
          }
          setDualRole({ isCustomer: true, isCrew: true });
          setChecking(false);
          return;
        }
        if (crewOk) {
          writeString(STORAGE_ACTIVE_ROLE, 'crew');
          window.location.replace(next || '/work/dashboard');
          return;
        }
        if (custOk) {
          writeString(STORAGE_ACTIVE_ROLE, 'customer');
          window.location.replace(next || '/me');
          return;
        }
        if (adminOk) {
          writeString(STORAGE_ACTIVE_ROLE, 'admin');
          window.location.replace(next || '/dashboard');
          return;
        }
        // §loop-break (2026-05-24) — all probes unauthed means the user is
        // genuinely unauthed. Clear any stale STORAGE_ACTIVE_ROLE so the
        // next visit doesn't re-trigger the dual-role chooser branch from
        // a phantom role marker.
        writeString(STORAGE_ACTIVE_ROLE, '');
        setChecking(false);
      } catch {
        if (!cancelled) setChecking(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    writeString(STORAGE_LAST_AUDIENCE, audience);
  }, [audience]);

  if (checking) {
    return (
      <AuthShell
        hideChrome
        eyebrow="Account"
        headline="Checking your session…"
        body="One moment — looking up your account."
      >
        <div
          role="status"
          aria-live="polite"
          className="flex items-center gap-3 text-sm text-brand-mute"
        >
          <span
            aria-hidden
            className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-brand-line border-t-brand-accent"
          />
          Verifying credentials.
        </div>
      </AuthShell>
    );
  }

  // Bare /login = the unified auto-routing screen; deep-links keep role copy.
  const eyebrow = !initialAudience
    ? 'Account'
    : audience === 'crew'
      ? 'Crew portal'
      : audience === 'admin'
        ? 'Admin console'
        : 'Customer login';
  const headline = !initialAudience
    ? 'Welcome back to Brick Labor.'
    : audience === 'crew'
      ? 'Sign in to the crew portal.'
      : audience === 'admin'
        ? 'Admin sign-in.'
        : 'Sign in to your bookings.';
  const body = !initialAudience ? (
    <>
      One sign-in for customers, crew, and operators. Google, GitHub, or a 6-digit code by email or
      text.
    </>
  ) : audience === 'crew' ? (
    <>Accept gigs, upload your docs, and track payouts. Six-digit text code, 30-day session.</>
  ) : audience === 'admin' ? (
    <>
      Allowlisted operators only — code by email or text, 12-hour session, SameSite=Strict cookies.
    </>
  ) : (
    <>
      Pull up every booking, reschedule a slot, or message your crew. Six-digit code by email or
      text — no password to remember.
    </>
  );

  // Dual-role chooser — when both sessions are present, render an explicit
  // "Pick a dashboard" surface instead of auto-bouncing between /me and
  // /work/dashboard. Persists the choice in localStorage so future visits
  // honor it; the user-menu still has a role switcher to flip back.
  if (dualRole) {
    const params = new URLSearchParams(window.location.search);
    const next = safeNext(params.get('next'));
    const pick = (role: 'customer' | 'crew') => {
      writeString(STORAGE_ACTIVE_ROLE, role);
      const dest = role === 'crew' ? next || '/work/dashboard' : next || '/me';
      window.location.replace(dest);
    };
    return (
      <AuthShell
        hideChrome
        eyebrow="Welcome back"
        headline="Pick a dashboard"
        body={
          <>
            You're signed in as both a customer and on the crew. Choose where to land — you can
            switch any time from the user menu.
          </>
        }
        footer={TERMS_FOOTER}
      >
        <div className="grid gap-3 sm:grid-cols-2">
          <button
            type="button"
            onClick={() => pick('customer')}
            className="group rounded-2xl border border-brand-line bg-brand-card p-6 text-left transition hover:border-brand-accent hover:-translate-y-0.5 hover:shadow-glow focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent motion-reduce:hover:transform-none"
          >
            <p className="eyebrow mb-2 text-brand-accent">Customer</p>
            <p className="text-xl font-extrabold text-brand-ink mb-1">My bookings</p>
            <p className="text-sm text-brand-mute">
              Track jobs, reschedule, message your crew, book a new one.
            </p>
            <p className="mt-4 text-sm text-brand-accent group-hover:underline">Continue →</p>
          </button>
          <button
            type="button"
            onClick={() => pick('crew')}
            className="group rounded-2xl border border-brand-line bg-brand-card p-6 text-left transition hover:border-brand-accent hover:-translate-y-0.5 hover:shadow-glow focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent motion-reduce:hover:transform-none"
          >
            <p className="eyebrow mb-2 text-brand-accent">Crew</p>
            <p className="text-xl font-extrabold text-brand-ink mb-1">Work portal</p>
            <p className="text-sm text-brand-mute">
              Accept gigs, upload docs, see today's schedule, get paid.
            </p>
            <p className="mt-4 text-sm text-brand-accent group-hover:underline">Continue →</p>
          </button>
        </div>
        <p className="mt-6 text-xs text-brand-mute">
          Wrong account?{' '}
          <button
            type="button"
            onClick={async () => {
              try {
                await Promise.all([
                  fetch('/api/auth/client/logout', {
                    method: 'POST',
                    credentials: 'include',
                  }).catch(() => null),
                  fetch('/api/work/auth/logout', { method: 'POST', credentials: 'include' }).catch(
                    () => null,
                  ),
                ]);
              } finally {
                writeString(STORAGE_ACTIVE_ROLE, '');
                window.location.replace('/login');
              }
            }}
            className="text-brand-accent underline-hover"
          >
            Sign out of both →
          </button>
        </p>
      </AuthShell>
    );
  }

  return (
    <LoginShell
      eyebrow={eyebrow}
      headline={headline}
      body={body}
      stage={stage}
      stageLabels={{ contact: 'Contact', code: 'Code', success: 'Done' }}
      footer={<LoginFooter />}
      aside={!initialAudience ? <LoginBrandAside /> : undefined}
    >
      {!initialAudience ? (
        <UnifiedPane stage={stage} setStage={setStage} />
      ) : initialAudience === 'crew' ? (
        <CrewPane stage={stage} setStage={setStage} />
      ) : initialAudience === 'admin' ? (
        <AdminPane stage={stage} setStage={setStage} />
      ) : (
        <CustomerPane stage={stage} setStage={setStage} />
      )}
    </LoginShell>
  );
}

// ── Desktop brand/value panel — fills the empty login width with the Brick
// Labor pitch: what they do, the flat $50/hr promise, and social proof. Hidden
// below `lg` (mobile keeps the compact single card). Decorative-only, so the
// form remains the sole interactive surface.
function LoginBrandAside(): JSX.Element {
  return (
    <div className="login-brand-aside flex flex-col justify-center gap-7 text-brand-ink">
      <div className="relative z-[1]">
        <p className="eyebrow">Newark's property crew</p>
        <p className="mt-3 font-display text-[clamp(1.6rem,1.1rem+1.4vw,2.15rem)] font-extrabold leading-[1.1] tracking-tight text-balance">
          Real hands, on your block — booked in minutes.
        </p>
        <p className="mt-3 max-w-sm text-sm leading-relaxed text-brand-mute text-pretty">
          Moving, hauling, cleanouts, junk removal, and yard work across Newark and nearby. One
          login for your bookings, your crew chat, and your receipts.
        </p>
      </div>

      <ul className="relative z-[1] grid gap-3">
        {[
          ['$50', 'per hour, per person — 1-hour minimum, no surprises'],
          ['15 min', 'blocks after the first hour, so you only pay for time used'],
          ['Same-day', 'crews available across Essex County when you need them'],
        ].map(([stat, label]) => (
          <li key={stat} className="flex items-start gap-3">
            <span className="mt-0.5 inline-flex shrink-0 items-center justify-center rounded-lg border border-brand-accent/40 bg-brand-accent/10 px-2.5 py-1 font-display text-sm font-extrabold text-brand-accent">
              {stat}
            </span>
            <span className="text-sm leading-snug text-brand-mute">{label}</span>
          </li>
        ))}
      </ul>

      <div className="relative z-[1] flex items-center gap-3 rounded-xl border border-brand-line bg-bg-primary/50 p-3.5">
        <span className="flex shrink-0" aria-hidden="true">
          {[0, 1, 2, 3, 4].map((i) => (
            <svg key={i} width="14" height="14" viewBox="0 0 20 20" fill="#ff6b1a">
              <path d="M10 1.5l2.6 5.27 5.82.85-4.21 4.1.99 5.79L10 14.77l-5.2 2.73.99-5.79L1.58 7.62l5.82-.85L10 1.5z" />
            </svg>
          ))}
        </span>
        <p className="text-xs leading-snug text-brand-mute">
          <span className="font-semibold text-brand-ink">4.9 out of 5</span> from Newark neighbors —
          licensed, insured, background-checked crews.
        </p>
      </div>
    </div>
  );
}

// ── Role hints — the unified pane auto-detects customer / crew / admin from
// the identifier, so there are no tabs. This quiet legend just reassures each
// audience "yes, this is your door too" without adding a decision. Purely
// informational (not buttons) — it must never compete with the one CTA.
function RoleHints(): JSX.Element {
  const ROLES: ReadonlyArray<readonly [string, string]> = [
    ['Customers', 'M4 7h16M4 12h16M4 17h10'],
    ['Crew', 'M10 11a3 3 0 100-6 3 3 0 000 6zM3.5 19a6.5 6.5 0 0113 0'],
    ['Operators', 'M12 3l7 4v5c0 4-3 7-7 8-4-1-7-4-7-8V7l7-4z'],
  ];
  return (
    <div
      className="flex flex-wrap items-center justify-center gap-x-2 gap-y-1 rounded-lg border border-brand-line/70 bg-bg-primary/40 px-3 py-2 text-[11px] text-brand-mute"
      data-testid="login-role-hints"
    >
      <span className="font-mono uppercase tracking-[0.12em] text-brand-mute/80">
        One login for
      </span>
      {ROLES.map(([label, path], i) => (
        <span key={label} className="inline-flex items-center gap-1">
          {i > 0 && (
            <span aria-hidden="true" className="text-brand-line">
              ·
            </span>
          )}
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path
              d={path}
              stroke="#ff6b1a"
              strokeWidth="1.6"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          <span className="font-semibold text-brand-ink">{label}</span>
        </span>
      ))}
    </div>
  );
}

// ── Trust bar — three quiet signals that lift a bare auth form: a live star
// rating, the local crew size, and a secure-login note. Reassures the customer
// that they're signing into the real Newark operation, not a phishing shell.
function TrustBar(): JSX.Element {
  return (
    <div
      className="mt-5 grid grid-cols-3 gap-2 rounded-xl border border-brand-line bg-bg-primary/60 p-3 text-center"
      data-testid="login-trust-bar"
    >
      <div className="flex flex-col items-center gap-0.5">
        <span className="flex items-center gap-1 text-sm font-extrabold text-brand-ink">
          <svg width="13" height="13" viewBox="0 0 20 20" fill="#ff6b1a" aria-hidden="true">
            <path d="M10 1.5l2.6 5.27 5.82.85-4.21 4.1.99 5.79L10 14.77l-5.2 2.73.99-5.79L1.58 7.62l5.82-.85L10 1.5z" />
          </svg>
          4.9
        </span>
        <span className="font-mono text-[9px] uppercase tracking-[0.12em] text-brand-mute">
          Rated
        </span>
      </div>
      <div className="flex flex-col items-center gap-0.5 border-x border-brand-line">
        <span className="text-sm font-extrabold text-brand-ink">Newark</span>
        <span className="font-mono text-[9px] uppercase tracking-[0.12em] text-brand-mute">
          Local crew
        </span>
      </div>
      <div className="flex flex-col items-center gap-0.5">
        <span className="flex items-center gap-1 text-sm font-extrabold text-brand-ink">
          <svg width="12" height="12" viewBox="0 0 20 20" fill="none" aria-hidden="true">
            <path
              d="M10 1.5l6.5 2.5v5c0 4-2.8 7.4-6.5 8.5-3.7-1.1-6.5-4.5-6.5-8.5V4L10 1.5z"
              stroke="#ff6b1a"
              strokeWidth="1.5"
              strokeLinejoin="round"
            />
            <path
              d="M7 10l2 2 4-4"
              stroke="#ff6b1a"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          Secure
        </span>
        <span className="font-mono text-[9px] uppercase tracking-[0.12em] text-brand-mute">
          Code login
        </span>
      </div>
    </div>
  );
}

// ── Compact card footer — one-line hiring CTA + terms ───────────────────────
// Keeps the widget short: a single "Apply to work the crew" link navigates to
// the dedicated full-page /apply flow (the multi-step hiring onboarding); the
// terms sit beneath it. (Was a focus-trapped <ApplyDialog> popup — now a real
// page so it's linkable, bookmarkable, and back-button friendly.)
function LoginFooter(): JSX.Element {
  return (
    <div className="space-y-3">
      <TrustBar />
      <a
        href="/apply"
        data-testid="apply-cta"
        data-bcl-cta="apply-to-work"
        className="group flex min-h-[44px] w-full items-center justify-between gap-3 rounded-xl border border-brand-line bg-bg-primary/60 px-4 py-3 text-left transition-all duration-[333ms] hover:border-brand-accent hover:bg-brand-accent/[0.06] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent focus-visible:ring-offset-2 focus-visible:ring-offset-bg-elevated motion-reduce:transition-none"
      >
        <span className="min-w-0 flex-1">
          <span className="block text-sm font-semibold text-brand-ink">
            Want to join the crew?
          </span>
          <span className="block truncate text-xs text-brand-mute">
            $50/hr per person · your own hours
          </span>
        </span>
        <span className="inline-flex shrink-0 items-center gap-1 whitespace-nowrap rounded-lg bg-brand-accent/10 px-2.5 py-1 text-sm font-semibold text-brand-accent">
          Apply to work the crew
          <span className="inline-block transition-transform duration-[333ms] group-hover:translate-x-0.5 motion-reduce:transition-none">
            →
          </span>
        </span>
      </a>
      <p className="text-center text-[11px] leading-relaxed text-brand-mute">{TERMS_FOOTER}</p>
    </div>
  );
}

// ── Google Sign-In button — Google Identity brand guidelines (dark theme) ───
// Surface #131314, hairline #8E918F, official 4-color "G" (18px), Roboto
// Medium 14px, 40px tall. One tap → /api/auth/google/start → Google consent →
// /api/auth/google/callback mints the right session + redirects by role.
function GoogleSignInButton(): JSX.Element {
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const handleGoogle = async () => {
    setNote('');
    setBusy(true);
    try {
      // Forward a safe ?next deep-link so it survives the OAuth round-trip
      // (the worker /start reads it from this URL into the state cookie).
      const nextQ = safeNext(new URLSearchParams(window.location.search).get('next'));
      const startUrl = nextQ
        ? `/api/auth/google/start?next=${encodeURIComponent(nextQ)}`
        : '/api/auth/google/start';
      const resp = await fetch(startUrl, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        credentials: 'include',
        body: '{}',
      });
      const data = (await resp.json().catch(() => null)) as {
        ok?: boolean;
        authorize_url?: string;
      } | null;
      if (resp.ok && data?.authorize_url) {
        window.location.assign(data.authorize_url);
        return;
      }
      // 501 not_configured (or any non-ok) — never a silent dead-end.
      setNote('Google sign-in isn’t available yet. Use email or text below.');
    } catch {
      setNote('Couldn’t reach Google. Use email or text below.');
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
    <button
      type="button"
      onClick={handleGoogle}
      disabled={busy}
      aria-label="Sign in with Google"
      data-bcl-cta="google-oauth"
      data-testid="google-signin"
      style={{ fontFamily: "'Roboto','Helvetica Neue',Arial,sans-serif" }}
      className="login-social-btn flex w-full items-center justify-center gap-3 rounded-lg border border-[#8E918F] bg-[#131314] px-3 text-sm font-medium text-[#E3E3E3] hover:bg-[#1f1f23] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#8E918F] focus-visible:ring-offset-2 focus-visible:ring-offset-bg-elevated disabled:opacity-60"
    >
      <svg width="18" height="18" viewBox="0 0 18 18" aria-hidden="true">
        <path
          fill="#4285F4"
          d="M17.64 9.205c0-.639-.057-1.252-.164-1.841H9v3.481h4.844a4.14 4.14 0 0 1-1.796 2.716v2.259h2.908c1.702-1.567 2.684-3.875 2.684-6.615Z"
        />
        <path
          fill="#34A853"
          d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.71H.957v2.332A8.997 8.997 0 0 0 9 18Z"
        />
        <path
          fill="#FBBC05"
          d="M3.964 10.71A5.41 5.41 0 0 1 3.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.997 8.997 0 0 0 0 9c0 1.452.348 2.827.957 4.042l3.007-2.332Z"
        />
        <path
          fill="#EA4335"
          d="M9 3.58c1.321 0 2.508.454 3.44 1.346l2.582-2.581C13.463.891 11.426 0 9 0A8.997 8.997 0 0 0 .957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58Z"
        />
      </svg>
      Sign in with Google
    </button>
    {note && (
      <p className="mt-1 text-xs text-brand-mute" role="status" data-testid="google-signin-note">
        {note}
      </p>
    )}
    </>
  );
}

// ── GitHub Sign-In button — GitHub brand (dark). One tap → POST /api/auth/github/start
// (mirrors Google's /start; the worker only reliably routes POST sub-paths under
// its SPA-fallback assets config) → GitHub consent → /api/auth/github/callback
// mints the right session + routes by role.
function GitHubSignInButton(): JSX.Element {
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const handleGithub = async () => {
    setNote('');
    setBusy(true);
    try {
      // Forward a safe ?next deep-link so it survives the OAuth round-trip
      // (the worker /start reads it from this URL into the state cookie).
      const nextQ = safeNext(new URLSearchParams(window.location.search).get('next'));
      const startUrl = nextQ
        ? `/api/auth/github/start?next=${encodeURIComponent(nextQ)}`
        : '/api/auth/github/start';
      const resp = await fetch(startUrl, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        credentials: 'include',
        body: '{}',
      });
      const data = (await resp.json().catch(() => null)) as {
        ok?: boolean;
        authorize_url?: string;
      } | null;
      if (resp.ok && data?.authorize_url) {
        window.location.assign(data.authorize_url);
        return;
      }
      // 501 not_configured (or any non-ok) — never a silent dead-end.
      setNote('GitHub sign-in isn’t available yet. Use email or text below.');
    } catch {
      setNote('Couldn’t reach GitHub. Use email or text below.');
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
    <button
      type="button"
      onClick={handleGithub}
      disabled={busy}
      aria-label="Sign in with GitHub"
      data-bcl-cta="github-oauth"
      data-testid="github-signin"
      className="login-social-btn flex w-full items-center justify-center gap-3 rounded-lg border border-[#3d444d] bg-[#24292f] px-3 text-sm font-medium text-white hover:bg-[#31373e] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#8b949e] focus-visible:ring-offset-2 focus-visible:ring-offset-bg-elevated disabled:opacity-60"
    >
      <svg width="18" height="18" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true">
        <path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8Z" />
      </svg>
      Sign in with GitHub
    </button>
    {note && (
      <p className="mt-1 text-xs text-brand-mute" role="status" data-testid="github-signin-note">
        {note}
      </p>
    )}
    </>
  );
}

// ── Unified pane — email/phone + Google + GitHub. Auto-routes by role ──
// from /api/auth/identify: admin email → admin · crew phone → crew · everyone
// else → customer. The matching existing start/verify endpoints are reused;
// no tabs, no role-picking by the user (minimal interaction).
const UNIFIED_ENDPOINTS = {
  customer: { start: '/api/auth/client/start', verify: '/api/auth/client/verify', dest: '/me' },
  crew: { start: '/api/work/auth/start', verify: '/api/work/auth/verify', dest: '/work/dashboard' },
  admin: {
    start: '/api/admin/auth/request-code',
    verify: '/api/admin/auth/verify-code',
    dest: '/admin',
  },
} as const;
type Flow = keyof typeof UNIFIED_ENDPOINTS;

function UnifiedPane({ stage, setStage }: PaneProps): JSX.Element {
  const [contact, setContact] = useState('');
  const [code, setCode] = useState('');
  const [flow, setFlow] = useState<Flow>('customer');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const cooldown = useResendCooldown();
  // Dark-by-default `sign_in_with_apple` flag. When off, the button never
  // renders; when on, the button self-degrades to "coming soon" if the
  // Apple OAuth creds aren't wired in this environment (probes /authorize).
  const appleEnabled = useFeatureFlag('sign_in_with_apple');

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const pre =
      params.get('contact') || params.get('phone') || readString(STORAGE_LAST_CONTACT_CUST);
    if (pre) setContact(pre);
    if ((params.get('error') || '').startsWith('google_')) {
      setError('Google sign-in didn’t complete. Try again, or use email/text below.');
    } else if ((params.get('error') || '').startsWith('apple_')) {
      setError('Apple sign-in didn’t complete. Try again, or use email/text below.');
    }
  }, []);

  const isEmail = looksLikeEmail(contact);
  const channel: 'email' | 'sms' = isEmail ? 'email' : 'sms';
  const canStart = isEmail || looksLikePhone(contact);
  const contactValidity = contactValidityState(contact, canStart);

  const start = useCallback(async () => {
    if (!canStart) {
      setError('Enter a valid email or 10-digit US phone number.');
      return;
    }
    setBusy(true);
    setError('');
    try {
      // One identify call decides the flow. Admin (email allowlist) wins; a
      // known crew PHONE routes to the crew portal; everything else is a
      // customer (covers new users + crew-via-email gracefully).
      const ident = await identify(contact);
      const roles = ident?.roles ?? [];
      const resolved: Flow = roles.includes('admin')
        ? 'admin'
        : !isEmail && roles.includes('crew')
          ? 'crew'
          : 'customer';
      setFlow(resolved);
      const ep = UNIFIED_ENDPOINTS[resolved];
      const body = resolved === 'crew' ? { phone: contact, intent: 'login' } : { contact };
      const res = await fetch(ep.start, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        const j = (await res.json().catch(() => ({}))) as { code?: string; error?: unknown };
        if (j.code === 'invalid_contact' || j.code === 'invalid_phone')
          setError('Enter a valid email or 10-digit US phone number.');
        else if (j.code === 'rate_limited')
          setError('Too many requests. Wait a minute and try again.');
        else if (j.code === 'not_found' && resolved === 'crew')
          setError("That phone isn't on the crew roster. New crew? Apply below.");
        else setError(asErrorText(j.error, 'Could not send code.'));
        return;
      }
      writeString(STORAGE_LAST_CONTACT_CUST, contact.trim());
      setStage('code');
      cooldown.start();
    } catch (err) {
      // Error tracked via Sentry
      setError('Connection issue. Try again.');
    } finally {
      setBusy(false);
    }
  }, [contact, canStart, isEmail, cooldown]);

  const verify = useCallback(
    async (codeValue?: string) => {
      const submitted = (codeValue ?? code).trim();
      if (submitted.length !== 6) return;
      setBusy(true);
      setError('');
      try {
        const ep = UNIFIED_ENDPOINTS[flow];
        const body =
          flow === 'crew' ? { phone: contact, code: submitted } : { contact, code: submitted };
        const res = await fetch(ep.verify, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify(body),
        });
        if (!res.ok) {
          const j = (await res.json().catch(() => ({}))) as { code?: string; error?: unknown };
          if (j.code === 'invalid_code')
            setError('That code did not match. Re-enter or send a new one.');
          else if (j.code === 'expired') setError('That code expired. Send a new one.');
          else if (j.code === 'already_used')
            setError('That code was already used. Send a new one.');
          else setError(asErrorText(j.error, 'Could not verify.'));
          return;
        }
        writeString(STORAGE_ACTIVE_ROLE, flow);
        setStage('success');
        cooldown.reset();
        setTimeout(() => {
          const next = new URLSearchParams(window.location.search).get('next');
          window.location.href = next && next.startsWith('/') ? next : UNIFIED_ENDPOINTS[flow].dest;
        }, 600);
      } catch {
        setError('Connection issue. Try again.');
      } finally {
        setBusy(false);
      }
    },
    [code, contact, flow, cooldown],
  );

  return (
    <div className="space-y-4">
      {stage === 'contact' && (
        <div className="stagger-in space-y-4">
          <RoleHints />
          <GoogleSignInButton />
          <GitHubSignInButton />
          {appleEnabled && (
            <SignInWithAppleButton className="transition-[opacity,background-color] duration-[333ms] hover:-translate-y-px" />
          )}
          <div className="flex items-center gap-3 py-1" aria-hidden>
            <span className="h-px flex-1 bg-brand-line" />
            <span className="text-xs uppercase tracking-wider text-brand-mute">or</span>
            <span className="h-px flex-1 bg-brand-line" />
          </div>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              void start();
            }}
            className="space-y-4"
          >
            <div>
              <label htmlFor="login-contact" className="field-label">
                Email or phone
              </label>
              <div className="login-input-wrap">
                <input
                  id="login-contact"
                  name="identifier"
                  type="text"
                  inputMode={isEmail ? 'email' : 'tel'}
                  autoComplete="username"
                  placeholder="you@example.com or (973) 555-0123"
                  value={contact}
                  onChange={(e) => setContact(e.target.value)}
                  className="field-input"
                  aria-invalid={contactValidity === 'invalid' || undefined}
                  aria-describedby="login-contact-hint"
                  autoFocus
                />
                <ValidityDot state={contactValidity} />
              </div>
              <span
                id="login-contact-hint"
                className="mt-1.5 flex items-center gap-1 text-xs text-brand-mute"
                aria-live="polite"
              >
                {canStart ? (
                  <>
                    We&apos;ll send a 6-digit code by <ChannelHint channel={channel} />.
                  </>
                ) : contactValidity === 'invalid' ? (
                  'That doesn’t look right — check the email or phone.'
                ) : (
                  'Enter an email or US phone number.'
                )}
              </span>
            </div>
            <button
              type="submit"
              disabled={busy || !canStart}
              data-testid="login-submit"
              data-bcl-cta="login-unified-send"
              className="btn-primary w-full"
            >
              {busy ? 'Sending…' : 'Continue'}
            </button>
          </form>
          <div
            data-testid="demo-login-bar"
            className="mt-3 rounded-xl border border-brand-line bg-bg-primary/60 p-3 space-y-2"
          >
            <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-brand-accent">
              Instant Demo / QA Sandbox
            </p>
            <div className="grid gap-2 sm:grid-cols-2">
              <button
                type="button"
                disabled={busy}
                data-testid="demo-account-signin"
                onClick={async () => {
                  setBusy(true);
                  setError('');
                  try {
                    const res = await fetch('/api/auth/client/demo', {
                      method: 'POST',
                      headers: { 'content-type': 'application/json' },
                      credentials: 'include',
                      body: JSON.stringify({ mode: 'populated' }),
                    });
                    if (!res.ok) {
                      setError('Could not launch demo account.');
                      return;
                    }
                    writeString(STORAGE_ACTIVE_ROLE, 'customer');
                    setStage('success');
                    const next = safeNext(new URLSearchParams(window.location.search).get('next'));
                    window.location.href = next || '/dashboard';
                  } catch {
                    setError('Connection issue. Try again.');
                  } finally {
                    setBusy(false);
                  }
                }}
                className="rounded-lg border border-brand-accent/40 bg-brand-accent/10 px-3 py-2 text-left text-xs font-semibold text-brand-ink transition hover:border-brand-accent hover:bg-brand-accent/20"
              >
                <span className="block text-brand-accent">Demo Account (Populated) →</span>
                <span className="block text-[11px] font-normal text-brand-mute">
                  Bookings, quotes, sites, crew &amp; admin
                </span>
              </button>
              <button
                type="button"
                disabled={busy}
                data-testid="demo-empty-signin"
                onClick={async () => {
                  setBusy(true);
                  setError('');
                  try {
                    const res = await fetch('/api/auth/client/demo', {
                      method: 'POST',
                      headers: { 'content-type': 'application/json' },
                      credentials: 'include',
                      body: JSON.stringify({ mode: 'empty' }),
                    });
                    if (!res.ok) {
                      setError('Could not launch empty test account.');
                      return;
                    }
                    writeString(STORAGE_ACTIVE_ROLE, 'customer');
                    setStage('success');
                    const next = safeNext(new URLSearchParams(window.location.search).get('next'));
                    window.location.href = next || '/dashboard';
                  } catch {
                    setError('Connection issue. Try again.');
                  } finally {
                    setBusy(false);
                  }
                }}
                className="rounded-lg border border-brand-line bg-bg-elevated/60 px-3 py-2 text-left text-xs font-semibold text-brand-ink transition hover:border-brand-accent"
              >
                <span className="block text-brand-ink">Empty Account Sandbox →</span>
                <span className="block text-[11px] font-normal text-brand-mute">
                  0-run clean dashboard states
                </span>
              </button>
            </div>
          </div>
        </div>
      )}

      {stage === 'code' && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void verify();
          }}
          className="stagger-in space-y-4"
        >
          <div className="flex items-start gap-2.5 rounded-lg border border-brand-line bg-bg-primary/50 p-3">
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              className="mt-0.5 shrink-0"
              aria-hidden="true"
            >
              <path
                d="M12 3l7 4v5c0 4-3 7-7 8-4-1-7-4-7-8V7l7-4z"
                stroke="#ff6b1a"
                strokeWidth="1.6"
                strokeLinejoin="round"
              />
              <path
                d="M9 12l2 2 4-4"
                stroke="#ff6b1a"
                strokeWidth="1.6"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <p className="text-sm text-brand-mute">
              Code sent to <strong className="text-brand-ink">{contact}</strong>. Enter it below —
              expires in 10 minutes.
            </p>
          </div>
          <div>
            <label htmlFor="login-code" className="field-label">
              Verification code
            </label>
            <CodeInput
              id="login-code"
              name="verificationCode"
              value={code}
              onChange={setCode}
              onComplete={(full) => void verify(full)}
              invalid={!!error}
            />
          </div>
          <button type="submit" disabled={busy || code.length !== 6} className="btn-primary w-full">
            {busy ? 'Verifying…' : 'Verify'}
          </button>
          <ResendRow
            onBack={() => {
              setStage('contact');
              setCode('');
              setError('');
              cooldown.reset();
            }}
            onResend={() => void start()}
            busy={busy}
            left={cooldown.left}
          />
        </form>
      )}

      {stage === 'success' && <SuccessBanner label="Signed in. Loading your dashboard…" />}

      <AuthError error={error} />
    </div>
  );
}

// ── Success banner — a warmer confirmation than a flat green box: an animated
// ring-check + a spinner tail so the redirect feels intentional, not frozen.
// Reused across every pane so the success moment is identical everywhere.
function SuccessBanner({ label }: { label: string }): JSX.Element {
  return (
    <div
      role="status"
      aria-live="polite"
      className="reveal-in flex items-center gap-3 rounded-xl border border-emerald-500/40 bg-emerald-500/10 p-4 text-sm text-emerald-100"
    >
      <span
        className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-emerald-500/20"
        aria-hidden="true"
      >
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
          <path
            d="M20 6L9 17l-5-5"
            stroke="#34d399"
            strokeWidth="2.4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </span>
      <span className="font-medium">{label}</span>
      <span
        aria-hidden="true"
        className="ml-auto inline-block h-4 w-4 shrink-0 animate-spin rounded-full border-2 border-emerald-500/30 border-t-emerald-300 motion-reduce:animate-none"
      />
    </div>
  );
}

// ── Multi-role picker — surfaced after /api/auth/identify returns >1 role ───
function RolePicker({
  roles,
  next,
  onPick,
}: {
  roles: IdentifiedRole[];
  next: string | null;
  onPick: (role: IdentifiedRole) => void;
}) {
  const label: Record<IdentifiedRole, string> = {
    customer: 'My bookings',
    crew: 'Work portal',
    admin: 'Admin console',
  };
  const dest: Record<IdentifiedRole, string> = {
    customer: next || '/me',
    crew: next || '/work/dashboard',
    admin: next || '/admin',
  };
  return (
    <div
      role="group"
      aria-label="Continue as"
      data-testid="role-picker"
      className="mt-4 grid gap-2 sm:grid-cols-2"
    >
      {roles.map((role) => (
        <button
          key={role}
          type="button"
          onClick={() => {
            writeString(STORAGE_ACTIVE_ROLE, role);
            onPick(role);
            window.location.href = dest[role];
          }}
          className="rounded-xl border border-brand-line bg-brand-card px-4 py-3 text-left transition hover:border-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
        >
          <p className="eyebrow mb-1 text-brand-accent">Continue as</p>
          <p className="font-semibold text-brand-ink">{label[role]}</p>
        </button>
      ))}
    </div>
  );
}

// ── Admin pane — POSTs to /api/admin/auth/{request-code,verify-code}. ────────
function AdminPane({ stage, setStage }: PaneProps) {
  const [contact, setContact] = useState('');
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [denied, setDenied] = useState(false);
  const cooldown = useResendCooldown();
  const channel: 'email' | 'sms' = looksLikeEmail(contact) ? 'email' : 'sms';
  const canStart = looksLikeEmail(contact) || looksLikePhone(contact);

  const start = useCallback(async () => {
    if (!canStart) {
      setError('Enter a valid email or 10-digit US phone number.');
      return;
    }
    setBusy(true);
    setError('');
    setDenied(false);
    try {
      // Identify first to gate the admin tab — non-allowlisted identifiers see
      // a friendly "not authorized" rather than a useless code.
      const ident = await identify(contact);
      if (ident && !ident.roles.includes('admin')) {
        setDenied(true);
        return;
      }
      const res = await fetch('/api/admin/auth/request-code', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ contact }),
      });
      if (!res.ok) {
        const j = (await res.json().catch(() => ({}))) as { code?: string; error?: unknown };
        if (j.code === 'invalid_contact')
          setError('Enter a valid email or 10-digit US phone number.');
        else if (j.code === 'rate_limited')
          setError('Too many requests. Wait a minute and try again.');
        else setError(asErrorText(j.error, 'Could not send code.'));
        return;
      }
      setStage('code');
      cooldown.start();
    } catch (err) {
      // Error tracked via Sentry
      setError('Connection issue. Try again.');
    } finally {
      setBusy(false);
    }
  }, [contact, canStart, cooldown, setStage]);

  const verify = useCallback(
    async (codeValue?: string) => {
      const submitted = (codeValue ?? code).trim();
      if (submitted.length !== 6) return;
      setBusy(true);
      setError('');
      try {
        const res = await fetch('/api/admin/auth/verify-code', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ contact, code: submitted }),
        });
        if (!res.ok) {
          const j = (await res.json().catch(() => ({}))) as { code?: string; error?: unknown };
          if (j.code === 'invalid_code')
            setError('That code did not match. Re-enter or send a new one.');
          else if (j.code === 'expired') setError('That code expired. Send a new one.');
          else setError(asErrorText(j.error, 'Could not verify.'));
          return;
        }
        writeString(STORAGE_ACTIVE_ROLE, 'admin');
        setStage('success');
        cooldown.reset();
        setTimeout(() => {
          const params = new URLSearchParams(window.location.search);
          const next = params.get('next');
          window.location.href = next && next.startsWith('/') ? next : '/admin';
        }, 600);
      } catch {
        setError('Connection issue. Try again.');
      } finally {
        setBusy(false);
      }
    },
    [code, contact, cooldown, setStage],
  );

  return (
    <div className="space-y-4">
      {stage === 'contact' && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void start();
          }}
          className="space-y-4"
        >
          <div>
            <label htmlFor="admin-contact" className="field-label">
              Admin email or phone
            </label>
            <div className="login-input-wrap">
              <input
                id="admin-contact"
                type="text"
                inputMode={channel === 'email' ? 'email' : 'tel'}
                autoComplete={channel === 'email' ? 'email' : 'tel'}
                placeholder="admin@bricklabor.com"
                value={contact}
                onChange={(e) => {
                  setContact(e.target.value);
                  setDenied(false);
                }}
                className="field-input"
                aria-invalid={contactValidityState(contact, canStart) === 'invalid' || undefined}
                autoFocus
              />
              <ValidityDot state={contactValidityState(contact, canStart)} />
            </div>
            <span className="mt-1.5 block text-xs text-brand-mute" aria-live="polite">
              {canStart
                ? `We'll send a 6-digit code by ${channel === 'email' ? 'email' : 'text'}.`
                : 'Allowlisted operators only.'}
            </span>
          </div>
          <button
            type="submit"
            disabled={busy || !canStart || denied}
            data-testid="login-submit"
            data-bcl-cta="login-admin-send"
            className="btn-primary w-full"
            title={
              canStart ? 'Send a 6-digit sign-in code' : 'Enter a valid admin email or phone first'
            }
          >
            {busy ? 'Sending…' : 'Sign in · Send code'}
          </button>
          {denied && (
            <p role="alert" className="text-sm text-amber-300">
              That identifier isn't on the admin allowlist.
            </p>
          )}
        </form>
      )}

      {stage === 'code' && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void verify();
          }}
          className="space-y-4"
        >
          <p className="text-sm text-brand-mute">
            Sent a 6-digit code to <strong className="text-brand-ink">{contact}</strong>. Expires in
            10 minutes.
          </p>
          <div>
            <label htmlFor="admin-code" className="field-label">
              Verification code
            </label>
            <CodeInput
              id="admin-code"
              value={code}
              onChange={setCode}
              onComplete={(full) => void verify(full)}
              invalid={!!error}
            />
          </div>
          <button type="submit" disabled={busy || code.length !== 6} className="btn-primary w-full">
            {busy ? 'Verifying…' : 'Verify'}
          </button>
          <ResendRow
            onBack={() => {
              setStage('contact');
              setCode('');
              setError('');
              cooldown.reset();
            }}
            onResend={() => void start()}
            busy={busy}
            left={cooldown.left}
          />
        </form>
      )}

      {stage === 'success' && <SuccessBanner label="Signed in. Loading admin console…" />}

      <AuthError error={error} />
    </div>
  );
}

// ── Segmented OTP — 6 discrete cells that read as a premium code field ──────
// A single real <input> (offscreen but focusable) owns paste / autofill
// (`one-time-code`) / IME / keyboard; the visible boxes mirror its value and
// show a blinking caret in the active empty cell. Digits auto-advance, a full
// paste fills all six, and a wrong code shakes the row. `id` wires the visible
// group to its <label> (the old single input had none — a broken association).
const OTP_LEN = 6;
function CodeInput({
  value,
  onChange,
  onComplete,
  id,
  name,
  invalid = false,
}: {
  value: string;
  onChange: (next: string) => void;
  onComplete?: (full: string) => void;
  id?: string;
  name?: string;
  invalid?: boolean;
}) {
  const ref = useRef<HTMLInputElement | null>(null);
  const [focused, setFocused] = useState(false);
  useEffect(() => {
    // Autofocus so a texted code can be pasted / autofilled immediately.
    const t = window.setTimeout(() => ref.current?.focus(), 30);
    return () => window.clearTimeout(t);
  }, []);
  const commit = useCallback(
    (raw: string) => {
      const next = raw.replace(/\D/g, '').slice(0, OTP_LEN);
      onChange(next);
      if (next.length === OTP_LEN && onComplete) onComplete(next);
    },
    [onChange, onComplete],
  );
  const cells = Array.from({ length: OTP_LEN }, (_, i) => value[i] ?? '');
  // Active cell = first empty slot, or the last when full.
  const activeIdx = focused ? Math.min(value.length, OTP_LEN - 1) : -1;
  return (
    <div
      className="relative"
      onClick={() => ref.current?.focus()}
      aria-hidden={false}
    >
      <input
        ref={ref}
        id={id}
        name={name}
        type="text"
        inputMode="numeric"
        autoComplete="one-time-code"
        maxLength={OTP_LEN}
        pattern="\d*"
        aria-label="6-digit verification code"
        aria-invalid={invalid || undefined}
        value={value}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        onChange={(e) => commit(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Backspace' && value.length > 0) {
            // Default backspace already removes the last char; no override
            // needed, but Left/Right could drift the caret out of sync — pin
            // the caret to the end so typing always lands in the next cell.
          }
          if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
            e.preventDefault();
          }
        }}
        // The real input is visually hidden but stays interactive + focusable
        // (never display:none, or autofill + paste break).
        style={{
          position: 'absolute',
          inset: 0,
          width: '100%',
          height: '100%',
          opacity: 0,
          cursor: 'text',
          zIndex: 2,
          // Keep the caret invisible; the cells render their own caret bar.
          color: 'transparent',
          background: 'transparent',
          border: 0,
          letterSpacing: '2.6em',
        }}
      />
      <div
        className="otp-field"
        data-invalid={invalid ? 'true' : 'false'}
        aria-hidden="true"
      >
        {cells.map((ch, i) => (
          <div
            key={i}
            className="otp-cell"
            data-filled={ch ? 'true' : 'false'}
            data-active={i === activeIdx ? 'true' : 'false'}
          >
            {ch}
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Resend row — the shared code-stage footer: a "go back" link + a resend
// control that visibly counts down (so the user sees WHY it's disabled) plus a
// plain-language recovery line. Reused by every pane so the recovery moment is
// identical. The countdown pill is width-stable (tabular-nums) so it never
// jitters as the seconds tick.
function ResendRow({
  onBack,
  onResend,
  busy,
  left,
  backLabel = 'Use a different contact',
}: {
  onBack: () => void;
  onResend: () => void;
  busy: boolean;
  left: number;
  backLabel?: string;
}): JSX.Element {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between gap-3 text-sm">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-1 text-brand-mute underline-hover"
        >
          <span aria-hidden="true">←</span> {backLabel}
        </button>
        <button
          type="button"
          data-testid="login-resend"
          onClick={onResend}
          disabled={busy || left > 0}
          className="login-resend inline-flex items-center gap-1.5 font-semibold text-brand-accent underline-hover disabled:cursor-not-allowed disabled:text-brand-mute disabled:no-underline"
          aria-label={left > 0 ? `Resend available in ${left} seconds` : 'Resend code'}
        >
          {left > 0 ? (
            <>
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.8" opacity="0.4" />
                <path
                  d="M12 7v5l3 2"
                  stroke="currentColor"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
              <span className="login-resend-timer">Resend in {left}s</span>
            </>
          ) : (
            <>
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path
                  d="M20 11a8 8 0 10-2.34 5.66M20 5v6h-6"
                  stroke="currentColor"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
              Resend code
            </>
          )}
        </button>
      </div>
      <p className="text-xs text-brand-mute" aria-live="polite">
        {left > 0
          ? "Didn't arrive? You can request a new code once the timer ends."
          : 'Didn’t get it? Check spam, or resend above.'}
      </p>
    </div>
  );
}

// ── Inline validity glyph — the small check/x that trails a contact field so
// the user KNOWS their entry parses before they submit (front-end mirror of the
// server's own validation, per the FE+BE Zod parity mandate). `state`:
//   'idle'  → nothing (empty field)
//   'valid' → orange check
//   'invalid' → muted x (only once they've typed enough to judge)
function ValidityDot({ state }: { state: 'idle' | 'valid' | 'invalid' }): JSX.Element | null {
  if (state === 'idle') return null;
  return (
    <span
      className="login-validity"
      style={{ opacity: 1 }}
      aria-hidden="true"
      data-state={state}
    >
      {state === 'valid' ? (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="10" fill="rgba(255,107,26,0.14)" />
          <path
            d="M8 12.5l2.5 2.5L16 9"
            stroke="#ff6b1a"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      ) : (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="10" fill="rgba(156,163,175,0.12)" />
          <path
            d="M9 9l6 6M15 9l-6 6"
            stroke="#9ca3af"
            strokeWidth="1.8"
            strokeLinecap="round"
          />
        </svg>
      )}
    </span>
  );
}

/** Small channel badge for the helper line — mail vs chat glyph + label. */
function ChannelHint({ channel }: { channel: 'email' | 'sms' }): JSX.Element {
  return (
    <span className="inline-flex items-center gap-1 text-brand-accent">
      {channel === 'email' ? (
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <rect x="3" y="5" width="18" height="14" rx="2" stroke="currentColor" strokeWidth="1.6" />
          <path d="M4 7l8 6 8-6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
        </svg>
      ) : (
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path
            d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinejoin="round"
          />
        </svg>
      )}
      {channel === 'email' ? 'email' : 'text'}
    </span>
  );
}

interface PaneProps {
  readonly stage: Stage;
  readonly setStage: (next: Stage) => void;
}

function CustomerPane({ stage, setStage }: PaneProps) {
  const [contact, setContact] = useState('');
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [identified, setIdentified] = useState<IdentifyResponse | null>(null);
  const cooldown = useResendCooldown();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const pre = params.get('contact') || readString(STORAGE_LAST_CONTACT_CUST);
    if (pre) setContact(pre);
  }, []);

  const channel: 'email' | 'sms' = looksLikeEmail(contact) ? 'email' : 'sms';
  const canStart = looksLikeEmail(contact) || looksLikePhone(contact);

  const start = useCallback(async () => {
    if (!canStart) {
      setError('Enter a valid email or 10-digit US phone number.');
      return;
    }
    setBusy(true);
    setError('');
    try {
      // Probe identify in parallel so a returning user sees their passkey
      // option / multi-role picker before/while the OTP fires. Non-blocking —
      // if it fails or returns no roles, the normal OTP flow proceeds.
      void identify(contact).then((ident) => {
        if (ident && (ident.roles.length > 1 || ident.hasPasskey)) setIdentified(ident);
      });
      const res = await fetch('/api/auth/client/start', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ contact }),
      });
      if (!res.ok) {
        const j = (await res.json().catch(() => ({}))) as { code?: string; error?: unknown };
        if (j.code === 'invalid_contact')
          setError('Enter a valid email or 10-digit US phone number.');
        else if (j.code === 'rate_limited')
          setError('Too many requests. Wait a minute and try again.');
        else setError(asErrorText(j.error, 'Could not send code.'));
        return;
      }
      writeString(STORAGE_LAST_CONTACT_CUST, contact.trim());
      setStage('code');
      cooldown.start();
    } catch (err) {
      // Error tracked via Sentry
      setError('Connection issue. Try again.');
    } finally {
      setBusy(false);
    }
  }, [contact, canStart, cooldown, setStage]);

  const verify = useCallback(
    async (codeValue?: string) => {
      const submitted = (codeValue ?? code).trim();
      if (submitted.length !== 6) return;
      setBusy(true);
      setError('');
      try {
        const res = await fetch('/api/auth/client/verify', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ contact, code: submitted }),
        });
        if (!res.ok) {
          const j = (await res.json().catch(() => ({}))) as { code?: string; error?: unknown };
          if (j.code === 'invalid_code')
            setError('That code did not match. Re-enter or send a new one.');
          else if (j.code === 'expired') setError('That code expired. Send a new one.');
          else if (j.code === 'already_used')
            setError('That code was already used. Send a new one.');
          else setError(asErrorText(j.error, 'Could not verify.'));
          return;
        }
        setStage('success');
        cooldown.reset();
        setTimeout(() => {
          const params = new URLSearchParams(window.location.search);
          const next = params.get('next');
          window.location.href = next && next.startsWith('/') ? next : '/me';
        }, 600);
      } catch {
        setError('Connection issue. Try again.');
      } finally {
        setBusy(false);
      }
    },
    [code, contact, cooldown, setStage],
  );

  return (
    <div className="space-y-4">
      {stage === 'contact' && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void start();
          }}
          className="space-y-4"
        >
          <div>
            <label htmlFor="cust-contact" className="field-label">
              Email or phone
            </label>
            <div className="login-input-wrap">
              <input
                id="cust-contact"
                type="text"
                inputMode={channel === 'email' ? 'email' : 'tel'}
                autoComplete={channel === 'email' ? 'email' : 'tel'}
                placeholder="you@example.com or (973) 555-0123"
                value={contact}
                onChange={(e) => setContact(e.target.value)}
                className="field-input"
                aria-invalid={contactValidityState(contact, canStart) === 'invalid' || undefined}
                autoFocus
              />
              <ValidityDot state={contactValidityState(contact, canStart)} />
            </div>
            <span className="mt-1.5 block text-xs text-brand-mute" aria-live="polite">
              {canStart
                ? `We'll send a 6-digit code by ${channel === 'email' ? 'email' : 'text'}.`
                : 'Enter an email or US phone number.'}
            </span>
          </div>
          <button
            type="submit"
            disabled={busy || !canStart}
            data-testid="login-submit"
            data-bcl-cta="login-customer-send"
            className="btn-primary w-full"
            title={
              canStart ? 'Send a 6-digit sign-in code' : 'Enter a valid email or US phone first'
            }
          >
            {busy ? 'Sending…' : 'Sign in · Send code'}
          </button>
          {identified?.hasPasskey && (
            <button
              type="button"
              data-testid="passkey-button"
              onClick={() => {
                // Surface only — full WebAuthn assertion handled elsewhere.
                window.location.href = `/login/passkey?contact=${encodeURIComponent(contact)}`;
              }}
              className="block w-full rounded-full border border-brand-accent px-4 py-2 text-sm font-semibold text-brand-accent transition hover:bg-brand-accent hover:text-bg-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
            >
              Use your passkey instead →
            </button>
          )}
          {identified && identified.roles.length > 1 && (
            <RolePicker
              roles={identified.roles}
              next={safeNext(new URLSearchParams(window.location.search).get('next'))}
              onPick={() => undefined}
            />
          )}
          <p className="text-center text-sm text-brand-mute">
            No booking yet?{' '}
            <a href="/book" className="text-brand-accent underline-hover">
              Book a crew →
            </a>
          </p>
        </form>
      )}

      {stage === 'code' && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void verify();
          }}
          className="space-y-4"
        >
          <p className="text-sm text-brand-mute">
            Sent a 6-digit code to <strong className="text-brand-ink">{contact}</strong>. Expires in
            10 minutes.
          </p>
          <div>
            <label htmlFor="cust-code" className="field-label">
              Verification code
            </label>
            <CodeInput
              id="cust-code"
              value={code}
              onChange={setCode}
              onComplete={(full) => void verify(full)}
              invalid={!!error}
            />
          </div>
          <button type="submit" disabled={busy || code.length !== 6} className="btn-primary w-full">
            {busy ? 'Verifying…' : 'Verify'}
          </button>
          <ResendRow
            onBack={() => {
              setStage('contact');
              setCode('');
              setError('');
              cooldown.reset();
            }}
            onResend={() => void start()}
            busy={busy}
            left={cooldown.left}
          />
        </form>
      )}

      {stage === 'success' && <SuccessBanner label="Signed in. Loading your dashboard…" />}

      <AuthError error={error} />
    </div>
  );
}

function CrewPane({ stage, setStage }: PaneProps) {
  const [phoneInput, setPhoneInput] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [intent, setIntent] = useState<CrewIntent>('login');
  // ARIA radio-group keyboard contract: the login/apply toggle is a single tab
  // stop with arrow/Home/End roving between options. onClick-only buttons fail
  // the pattern and axe-core can't see it — so wire the shared roving helper.
  const intentRadio = useRovingRadio(2, (i) => setIntent(i === 0 ? 'login' : 'signup'));
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const cooldown = useResendCooldown();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const pre = params.get('phone') || readString(STORAGE_LAST_PHONE_CREW);
    if (pre) setPhoneInput(formatPhone(pre));
    const i = params.get('intent');
    if (i === 'signup') setIntent('signup');
    else if (i === 'signin' || i === 'login') setIntent('login');
  }, []);

  const canStart = useMemo(() => {
    if (!looksLikePhone(phoneInput)) return false;
    if (intent === 'signup' && (!firstName.trim() || !lastName.trim())) return false;
    return true;
  }, [phoneInput, intent, firstName, lastName]);
  // Phone-only validity for the inline glyph (name fields don't gate the dot).
  const phoneValidity = contactValidityState(phoneInput, looksLikePhone(phoneInput));

  const start = useCallback(async () => {
    if (!canStart) {
      setError(
        intent === 'signup'
          ? 'Enter your name and a valid US phone number.'
          : 'Enter a valid 10-digit US phone number.',
      );
      return;
    }
    setBusy(true);
    setError('');
    try {
      const body: Record<string, string> = { phone: phoneInput, intent };
      if (intent === 'signup') {
        body.firstName = firstName.trim();
        body.lastName = lastName.trim();
      }
      const res = await fetch('/api/work/auth/start', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        const j = (await res.json().catch(() => ({}))) as { code?: string; error?: unknown };
        if (j.code === 'invalid_phone') setError('Enter a valid 10-digit US phone number.');
        else if (j.code === 'rate_limited')
          setError('Too many requests. Wait a minute and try again.');
        else if (j.code === 'not_found')
          setError(
            "We don't have that phone on file. Switch to Apply to start a new crew profile.",
          );
        else if (j.code === 'name_required') setError('Add your first and last name to apply.');
        else setError(asErrorText(j.error, 'Could not send code.'));
        return;
      }
      writeString(STORAGE_LAST_PHONE_CREW, phoneInput);
      setStage('code');
      cooldown.start();
    } catch (err) {
      // Error tracked via Sentry
      setError('Connection issue. Try again.');
    } finally {
      setBusy(false);
    }
  }, [canStart, phoneInput, intent, firstName, lastName, cooldown, setStage]);

  const verify = useCallback(
    async (codeValue?: string) => {
      const submitted = (codeValue ?? code).trim();
      if (submitted.length !== 6) return;
      setBusy(true);
      setError('');
      try {
        const res = await fetch('/api/work/auth/verify', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ phone: phoneInput, code: submitted }),
        });
        if (!res.ok) {
          const j = (await res.json().catch(() => ({}))) as { code?: string; error?: unknown };
          if (j.code === 'invalid_code')
            setError('That code did not match. Re-enter or send a new one.');
          else if (j.code === 'expired') setError('That code expired. Send a new one.');
          else if (j.code === 'already_used')
            setError('That code was already used. Send a new one.');
          else setError(asErrorText(j.error, 'Could not verify.'));
          return;
        }
        setStage('success');
        cooldown.reset();
        setTimeout(() => {
          const params = new URLSearchParams(window.location.search);
          const next = params.get('next');
          const fallback = intent === 'signup' ? '/work/dashboard#settings' : '/work/dashboard';
          window.location.href = next && next.startsWith('/') ? next : fallback;
        }, 600);
      } catch {
        setError('Connection issue. Try again.');
      } finally {
        setBusy(false);
      }
    },
    [code, phoneInput, intent, cooldown, setStage],
  );

  return (
    <div className="space-y-4">
      {stage === 'contact' && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void start();
          }}
          className="space-y-4"
        >
          <div
            role="radiogroup"
            aria-label="Crew action"
            className="inline-flex w-full rounded-full border border-brand-line bg-bg-primary p-1 text-sm"
          >
            <button
              role="radio"
              aria-checked={intent === 'login'}
              type="button"
              onClick={() => setIntent('login')}
              {...intentRadio(0, intent === 'login')}
              className={`flex-1 rounded-full px-3 py-1.5 font-mono uppercase tracking-[0.12em] text-xs transition-all duration-[333ms] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent ${
                intent === 'login'
                  ? 'bg-brand-accent text-bg-primary font-semibold'
                  : 'text-brand-mute hover:text-brand-ink'
              }`}
            >
              I'm on the crew
            </button>
            <button
              role="radio"
              aria-checked={intent === 'signup'}
              type="button"
              onClick={() => setIntent('signup')}
              {...intentRadio(1, intent === 'signup')}
              className={`flex-1 rounded-full px-3 py-1.5 font-mono uppercase tracking-[0.12em] text-xs transition-all duration-[333ms] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent ${
                intent === 'signup'
                  ? 'bg-brand-accent text-bg-primary font-semibold'
                  : 'text-brand-mute hover:text-brand-ink'
              }`}
            >
              Apply to work
            </button>
          </div>

          {intent === 'signup' && (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="crew-first" className="field-label">
                  First name
                </label>
                <input
                  id="crew-first"
                  type="text"
                  autoComplete="given-name"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value.slice(0, 60))}
                  className="field-input"
                />
              </div>
              <div>
                <label htmlFor="crew-last" className="field-label">
                  Last name
                </label>
                <input
                  id="crew-last"
                  type="text"
                  autoComplete="family-name"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value.slice(0, 60))}
                  className="field-input"
                />
              </div>
            </div>
          )}

          <div>
            <label htmlFor="crew-phone" className="field-label">
              Mobile phone
            </label>
            <div className="login-input-wrap">
              <input
                id="crew-phone"
                type="tel"
                inputMode="tel"
                autoComplete="tel"
                placeholder="(973) 555-0123"
                value={phoneInput}
                onChange={(e) => setPhoneInput(formatPhone(e.target.value))}
                className="field-input"
                aria-invalid={phoneValidity === 'invalid' || undefined}
                autoFocus
              />
              <ValidityDot state={phoneValidity} />
            </div>
            <span className="mt-1.5 block text-xs text-brand-mute">
              We&apos;ll text a 6-digit code. Standard carrier rates apply.
            </span>
          </div>

          <button
            type="submit"
            disabled={busy || !canStart}
            data-testid="login-submit"
            data-bcl-cta={intent === 'signup' ? 'login-crew-apply' : 'login-crew-send'}
            className="btn-primary w-full"
            title={
              canStart ? 'Send a 6-digit sign-in code' : 'Enter a valid 10-digit US phone first'
            }
          >
            {busy ? 'Sending…' : intent === 'signup' ? 'Apply · Send code' : 'Sign in · Send code'}
          </button>

          <p className="text-center text-sm text-brand-mute">
            {intent === 'login' ? (
              <>
                New to the crew?{' '}
                <button
                  type="button"
                  onClick={() => setIntent('signup')}
                  className="text-brand-accent underline-hover"
                >
                  Apply →
                </button>
              </>
            ) : (
              <>
                Already on the crew?{' '}
                <button
                  type="button"
                  onClick={() => setIntent('login')}
                  className="text-brand-accent underline-hover"
                >
                  Log in →
                </button>
              </>
            )}
          </p>
        </form>
      )}

      {stage === 'code' && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void verify();
          }}
          className="space-y-4"
        >
          <p className="text-sm text-brand-mute">
            Texted a 6-digit code to <strong className="text-brand-ink">{phoneInput}</strong>.
            Expires in 10 minutes.
          </p>
          <div>
            <label htmlFor="crew-code" className="field-label">
              Verification code
            </label>
            <CodeInput
              id="crew-code"
              value={code}
              onChange={setCode}
              onComplete={(full) => void verify(full)}
              invalid={!!error}
            />
          </div>
          <button type="submit" disabled={busy || code.length !== 6} className="btn-primary w-full">
            {busy ? 'Verifying…' : 'Verify'}
          </button>
          <ResendRow
            backLabel="Use a different phone"
            onBack={() => {
              setStage('contact');
              setCode('');
              setError('');
              cooldown.reset();
            }}
            onResend={() => void start()}
            busy={busy}
            left={cooldown.left}
          />
        </form>
      )}

      {stage === 'success' && (
        <SuccessBanner
          label={
            intent === 'signup'
              ? 'Application started. Loading your profile…'
              : 'Signed in. Loading your dashboard…'
          }
        />
      )}

      <AuthError error={error} />
    </div>
  );
}
