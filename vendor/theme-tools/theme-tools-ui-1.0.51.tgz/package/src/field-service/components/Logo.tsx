import { useThemeToolsSurface } from '../../field-service-primitives.js';

interface LogoProps {
  className?: string;
  title?: string;
}

/**
 * Brick Labor Universal Brand Lockup (`@theme.tools/ui/field-service/components/Logo`).
 *
 * Renders the pure-transparent orange `BRICK LABOR` text icon (`/brand/bcl-wordmark-*`)
 * with 100% of background pixels stripped to transparent alpha, tightly cropped,
 * and optically shifted `relative -5px` (`top: -5px`) so the brick letter baseline
 * centers cleanly in the navbar below the hammer head.
 */
export function Logo({ className = 'h-8 sm:h-9 md:h-10 w-auto', title }: LogoProps) {
  useThemeToolsSurface('logo');
  const label = title ?? 'Brick Labor';
  return (
    <picture className="inline-flex shrink-0 items-center">
      <source
        srcSet="/brand/bcl-wordmark-512.webp?v=14 512w, /brand/bcl-wordmark-1024.webp?v=14 1024w"
        sizes="(min-width: 768px) 230px, 185px"
        type="image/webp"
      />
      <img
        src="/brand/bcl-wordmark-512.png?v=14"
        srcSet="/brand/bcl-wordmark-256.png?v=14 256w, /brand/bcl-wordmark-512.png?v=14 512w, /brand/bcl-wordmark-1024.png?v=14 1024w"
        sizes="(min-width: 768px) 230px, 185px"
        alt={label}
        data-testid="brand-ideogram-emblem"
        width={1218}
        height={250}
        style={{ position: 'relative', top: '-5px' }}
        className={`relative -top-[5px] ${className} object-contain drop-shadow-[0_2px_14px_rgba(255,107,26,0.35)] transition-transform duration-[333ms] group-hover:scale-[1.02]`}
        loading="eager"
        decoding="async"
      />
    </picture>
  );
}

