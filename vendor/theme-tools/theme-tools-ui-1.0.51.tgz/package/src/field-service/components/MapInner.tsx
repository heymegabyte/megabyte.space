import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect, useRef, useState } from 'react';
import { CITIES } from '../data/cities.js';
import { TERRITORY_CENTER } from '@theme.tools/seo-geo/field-service/coverage-territory';

interface MapsConfig {
  ok: boolean;
  apiKey: string;
  mapId: string;
}

// Brand-aligned dark styling — matches #060610/#0A0E14 background + brand orange.
// Inline styling works without a Cloud-hosted Map ID, keeping the operator's
// Cloud Console config to a single API key with API restrictions to Maps JS.
const DARK_STYLES: google.maps.MapTypeStyle[] = [
  { elementType: 'geometry', stylers: [{ color: '#0a0e14' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#6f7886' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#0a0e14' }] },
  {
    featureType: 'administrative.land_parcel',
    elementType: 'labels',
    stylers: [{ visibility: 'off' }],
  },
  {
    featureType: 'administrative.locality',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#a8b0bd' }],
  },
  {
    featureType: 'administrative.country',
    elementType: 'geometry.stroke',
    stylers: [{ color: '#2a2f3a' }],
  },
  {
    featureType: 'administrative.province',
    elementType: 'geometry.stroke',
    stylers: [{ color: '#2a2f3a' }],
  },
  { featureType: 'poi', elementType: 'geometry', stylers: [{ color: '#11151c' }] },
  { featureType: 'poi', elementType: 'labels', stylers: [{ visibility: 'off' }] },
  { featureType: 'poi.park', elementType: 'geometry', stylers: [{ color: '#0f1a14' }] },
  { featureType: 'poi.park', elementType: 'labels.text.fill', stylers: [{ color: '#3a5040' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#1a1f29' }] },
  { featureType: 'road', elementType: 'labels.icon', stylers: [{ visibility: 'off' }] },
  { featureType: 'road.arterial', elementType: 'geometry', stylers: [{ color: '#1f2530' }] },
  { featureType: 'road.highway', elementType: 'geometry', stylers: [{ color: '#2b323d' }] },
  { featureType: 'road.highway', elementType: 'geometry.stroke', stylers: [{ color: '#0a0e14' }] },
  { featureType: 'road.highway', elementType: 'labels.text.fill', stylers: [{ color: '#8a93a3' }] },
  { featureType: 'road.local', elementType: 'labels.text.fill', stylers: [{ color: '#5a6272' }] },
  { featureType: 'transit', elementType: 'labels', stylers: [{ visibility: 'off' }] },
  { featureType: 'transit.line', elementType: 'geometry', stylers: [{ color: '#1a1f29' }] },
  { featureType: 'transit.station', elementType: 'geometry', stylers: [{ color: '#11151c' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#04060a' }] },
  { featureType: 'water', elementType: 'labels.text.fill', stylers: [{ color: '#2a3a4a' }] },
];

let sdkPromise: Promise<typeof google> | null = null;

function loadSdk(apiKey: string): Promise<typeof google> {
  if (typeof window !== 'undefined' && (window as { google?: typeof google }).google?.maps) {
    return Promise.resolve((window as { google: typeof google }).google);
  }
  if (sdkPromise) return sdkPromise;
  sdkPromise = new Promise((resolve, reject) => {
    const cbName = `__bcl_gmaps_cb_${Date.now()}`;
    (window as unknown as Record<string, unknown>)[cbName] = () => {
      delete (window as unknown as Record<string, unknown>)[cbName];
      resolve((window as { google: typeof google }).google);
    };
    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(apiKey)}&v=weekly&loading=async&libraries=marker&callback=${cbName}`;
    script.async = true;
    script.defer = true;
    script.onerror = () => reject(new Error('gmaps-load-failed'));
    document.head.appendChild(script);
  });
  return sdkPromise;
}

export function MapInner() {
  useThemeToolsSurface('map-inner');
  const [config, setConfig] = useState<MapsConfig | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    fetch('/api/maps/config')
      .then((r) => r.json() as Promise<MapsConfig>)
      .then((cfg) => {
        if (cancelled) return;
        if (!cfg.ok || !cfg.apiKey) {
          setError('map-disabled');
          return;
        }
        setConfig(cfg);
      })
      .catch(() => {
        if (!cancelled) setError('config-fetch-failed');
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (error || !config) {
    return (
      <div className="flex h-full w-full items-center justify-center bg-bg-elevated/60 text-brand-mute font-mono text-sm">
        <div className="flex items-center gap-3">
          <span className="inline-block h-2 w-2 rounded-full bg-brand-accent animate-pulse" />
          {error === 'map-disabled' ? 'Map offline — call (855) 82LABOR' : 'Loading map…'}
        </div>
      </div>
    );
  }

  return <VanillaMap apiKey={config.apiKey} mapId={config.mapId} />;
}

function VanillaMap({ apiKey, mapId }: { apiKey: string; mapId: string }) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');

  useEffect(() => {
    if (!ref.current) return;
    let cancelled = false;
    let map: google.maps.Map | null = null;
    let infoWindow: google.maps.InfoWindow | null = null;
    const markers: google.maps.marker.AdvancedMarkerElement[] = [];

    (async () => {
      try {
        await loadSdk(apiKey);
        if (cancelled || !ref.current) return;
        const { Map: GMap, InfoWindow } = (await google.maps.importLibrary(
          'maps',
        )) as google.maps.MapsLibrary;
        // Only import the `marker` library (which gives AdvancedMarkerElement)
        // when the operator has supplied a Cloud-hosted Map ID. Without one,
        // AdvancedMarkerElement still works but Google logs a noisy warning
        // every render: "The map is initialized without a valid Map ID, which
        // will prevent use of Advanced Markers." Fall back to the classic
        // `google.maps.Marker` in that case — same UX, zero console noise.
        const useAdvancedMarkers = Boolean(mapId);
        const markerLib = useAdvancedMarkers
          ? ((await google.maps.importLibrary('marker')) as google.maps.MarkerLibrary)
          : null;
        if (cancelled || !ref.current) return;

        const options: google.maps.MapOptions = {
          center: { lat: TERRITORY_CENTER[0] as number, lng: TERRITORY_CENTER[1] as number },
          zoom: 10,
          gestureHandling: 'cooperative',
          streetViewControl: false,
          mapTypeControl: false,
          fullscreenControl: false,
          clickableIcons: false,
          zoomControl: true,
          backgroundColor: '#0a0e14',
        };
        // AdvancedMarkerElement requires a Cloud-hosted Map ID. When the
        // operator hasn't configured one, use inline JSON dark styling +
        // classic markers so the console stays silent.
        if (mapId) options.mapId = mapId;
        else options.styles = DARK_STYLES;

        map = new GMap(ref.current, options);
        infoWindow = new InfoWindow();

        for (const city of CITIES) {
          const isHome = Boolean(city.primary);
          const isNYC = city.state === 'NY';
          const fill = isHome ? '#FF6B1A' : isNYC ? '#22D3EE' : '#FF6B1A';
          const size = isHome ? 22 : 14;
          const stroke = isHome
            ? '#0A0E14'
            : isNYC
              ? 'rgba(34,211,238,0.35)'
              : 'rgba(255,107,26,0.4)';
          const strokeWeight = isHome ? 3 : 2;
          const tooltip = `${city.name}, ${city.state} — flat $50/hr — tap to book`;
          const cityUrl = `/c/${city.slug}`;

          const openInfo = (
            anchor: google.maps.MVCObject | google.maps.marker.AdvancedMarkerElement,
          ) => {
            if (!infoWindow || !map) return;
            const sub = city.state === 'NY' ? 'NYC borough' : `${city.county} County, NJ`;
            const home = isHome ? ' · home base' : '';
            infoWindow.setContent(
              `<div style="font-family:system-ui,sans-serif;color:#0a0e14;min-width:200px">` +
                `<strong style="display:block;margin-bottom:4px;font-size:14px">${city.name}${home}</strong>` +
                `<div style="font-size:12px;color:#4a5260;margin-bottom:8px">${sub}</div>` +
                `<a href="${cityUrl}" style="display:inline-block;background:#FF6B1A;color:#0A0E14;font-weight:700;padding:6px 10px;border-radius:6px;text-decoration:none">Book ${city.name} →</a>` +
                `</div>`,
            );
            infoWindow.open({ map, anchor: anchor as google.maps.MVCObject });
          };

          if (useAdvancedMarkers && markerLib) {
            const pin = document.createElement('a');
            pin.setAttribute('href', cityUrl);
            pin.setAttribute('aria-label', `${city.name}, ${city.state} — book this city`);
            pin.setAttribute('data-city-slug', city.slug);
            pin.style.cssText = [
              `width:${size}px`,
              `height:${size}px`,
              'border-radius:50%',
              `background:${fill}`,
              `border:${strokeWeight}px solid ${stroke}`,
              'box-shadow:0 1px 4px rgba(0,0,0,0.4)',
              'cursor:pointer',
              'transition:transform 160ms ease, box-shadow 160ms ease',
              'display:block',
            ].join(';');
            pin.addEventListener('mouseenter', () => {
              pin.style.transform = 'scale(1.25)';
              pin.style.boxShadow = '0 4px 14px rgba(255,107,26,0.55)';
            });
            pin.addEventListener('mouseleave', () => {
              pin.style.transform = 'scale(1)';
              pin.style.boxShadow = '0 1px 4px rgba(0,0,0,0.4)';
            });

            const marker = new markerLib.AdvancedMarkerElement({
              position: { lat: city.lat, lng: city.lng },
              map,
              title: tooltip,
              zIndex: isHome ? 1000 : isNYC ? 50 : 10,
              content: pin,
            });

            marker.addListener('gmp-click', (ev: { domEvent?: Event }) => {
              ev.domEvent?.preventDefault();
              openInfo(marker);
            });

            markers.push(marker);
          } else {
            // Classic Marker path — same circular SVG pin via dataURI so the
            // visual matches the AdvancedMarker variant.
            const svg = encodeURIComponent(
              `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">` +
                `<circle cx="${size / 2}" cy="${size / 2}" r="${(size - strokeWeight) / 2}" fill="${fill}" stroke="${stroke.replace(/"/g, "'")}" stroke-width="${strokeWeight}"/>` +
                `</svg>`,
            );
            const marker = new google.maps.Marker({
              position: { lat: city.lat, lng: city.lng },
              map,
              title: tooltip,
              zIndex: isHome ? 1000 : isNYC ? 50 : 10,
              icon: {
                url: `data:image/svg+xml;charset=UTF-8,${svg}`,
                scaledSize: new google.maps.Size(size, size),
                anchor: new google.maps.Point(size / 2, size / 2),
              },
            });
            marker.addListener('click', () => {
              openInfo(marker);
              // Defer the nav so the InfoWindow gets a chance to render —
              // mirrors the AdvancedMarker path where the <a> handles nav
              // directly. 1.2s window lets the user read the InfoWindow.
              window.setTimeout(() => {
                window.location.href = cityUrl;
              }, 1200);
            });
            // Cast through unknown so the heterogeneous markers array (classic
            // + advanced) can share teardown logic below.
            (markers as unknown as google.maps.Marker[]).push(marker);
          }
        }

        setStatus('ready');
      } catch {
        if (!cancelled) setStatus('error');
      }
    })();

    return () => {
      cancelled = true;
      for (const m of markers as unknown as Array<
        google.maps.marker.AdvancedMarkerElement | google.maps.Marker
      >) {
        if (m instanceof google.maps.Marker) m.setMap(null);
        else (m as google.maps.marker.AdvancedMarkerElement).map = null;
      }
      if (infoWindow) infoWindow.close();
      map = null;
    };
  }, [apiKey, mapId]);

  return (
    <div className="relative h-full w-full">
      <div ref={ref} className="h-full w-full" />
      {status === 'loading' && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-bg-elevated/60 text-brand-mute font-mono text-sm">
          <div className="flex items-center gap-3">
            <span className="inline-block h-2 w-2 rounded-full bg-brand-accent animate-pulse" />
            Loading map…
          </div>
        </div>
      )}
      {status === 'error' && (
        <div className="absolute inset-0 flex items-center justify-center bg-bg-elevated/60 text-brand-mute font-mono text-sm">
          Map offline — call (855) 82LABOR
        </div>
      )}
    </div>
  );
}
