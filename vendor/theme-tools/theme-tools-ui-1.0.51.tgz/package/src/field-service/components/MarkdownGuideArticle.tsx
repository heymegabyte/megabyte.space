import { useMemo } from 'react';
import {
  ThemeToolsPageSurface,
  useThemeToolsSurface,
} from '../../field-service-primitives.js';
import type { LongFormPageAuthorityDossier } from '@theme.tools/seo-geo/field-service/matrix-3d-engine';
import type { LandingMatrixPage as LandingMatrixPageEntry } from '@theme.tools/seo-geo/field-service/landing-matrix';
import { PHONE_DISPLAY, PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';
import { ArticleMultimediaSuite } from './ArticleMultimediaSuite.js';

export interface MarkdownGuideArticleProps {
  readonly dossier: LongFormPageAuthorityDossier;
  readonly page: LandingMatrixPageEntry;
  readonly isPowerWash: boolean;
  readonly estimatedTotalUsd: number;
  readonly bookingUrl?: string;
}

export interface ParsedTocItem {
  readonly id: string;
  readonly title: string;
}

export interface ParsedGuideHtml {
  readonly html: string;
  readonly toc: readonly ParsedTocItem[];
  readonly wordCount: number;
}

function slugifyHeading(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function escapeHtml(raw: string): string {
  return raw
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function renderInlineMarkdown(text: string): string {
  let out = escapeHtml(text);
  // Inline code `code`
  out = out.replace(/`([^`]+)`/g, '<code>$1</code>');
  // Bold **text**
  out = out.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  // Italic *text*
  out = out.replace(/\*([^*]+)\*/g, '<em>$1</em>');
  // Links [label](href)
  out = out.replace(
    /\[([^\]]+)\]\((https?:\/\/[^\s)]+|\/[^\s)]+)\)/g,
    '<a href="$2" class="text-brand-accent underline-hover font-semibold">$1</a>',
  );
  return out;
}

/**
 * Converts a structured Markdown guide document into clean semantic HTML
 * styled by `.prose-bcl` (h2, h3, p, blockquote, ul, ol, table, and inline
 * `<figure data-testid="custom-page-photo-card">` photo cards).
 */
export function convertGuideMarkdownToHtml(markdown: string): {
  readonly html: string;
  readonly toc: readonly ParsedTocItem[];
  readonly wordCount: number;
} {
  const blocks = markdown
    .trim()
    .split(/\n{2,}/)
    .map((b) => b.trim())
    .filter(Boolean);

  const htmlParts: string[] = [];
  const toc: ParsedTocItem[] = [];
  let isFirstParagraph = true;

  for (const block of blocks) {
    // 1. H2 Heading: ## Title
    if (block.startsWith('## ')) {
      const title = block.slice(3).trim();
      const id = slugifyHeading(title);
      toc.push({ id, title });
      htmlParts.push(`<h2 id="${id}" class="scroll-mt-28">${renderInlineMarkdown(title)}</h2>`);
      continue;
    }

    // 2. H3 Heading: ### Title
    if (block.startsWith('### ')) {
      const title = block.slice(4).trim();
      const id = slugifyHeading(title);
      htmlParts.push(`<h3 id="${id}" class="scroll-mt-28">${renderInlineMarkdown(title)}</h3>`);
      continue;
    }

    // 3. Standalone Image / Photo Card: ![alt](src "Title | Badge | Caption")
    const imgMatch = block.match(/^!\[([^\]]*)\]\(([^\s)]+)\s+"([^"]+)"\)$/);
    if (imgMatch) {
      const alt = escapeHtml(imgMatch[1] ?? '');
      const src = escapeHtml(imgMatch[2] ?? '');
      const metaParts = (imgMatch[3] ?? '').split('|').map((s) => s.trim());
      const title = escapeHtml(metaParts[0] ?? '');
      const badge = escapeHtml(metaParts[1] ?? 'NEWARK FIELD GUIDE');
      const caption = escapeHtml(metaParts[2] ?? '');
      htmlParts.push(`
        <figure data-testid="custom-page-photo-card" data-photo-kind="guide-photo" class="tt-figure my-10 overflow-hidden rounded-2xl border border-white/12 bg-[#0d121a] shadow-[0_24px_56px_-24px_rgba(0,0,0,0.82)] not-prose">
          <div class="relative aspect-[16/10] w-full overflow-hidden bg-[#080b12]">
            <img src="${src}" alt="${alt}" width="1200" height="750" loading="eager" class="h-full w-full object-cover" />
            <span class="tt-badge absolute left-4 top-4 rounded-full border border-brand-accent/50 bg-bg-primary/90 px-3.5 py-1 font-mono text-[10px] font-bold uppercase tracking-wider text-brand-accent">
              ${badge}
            </span>
          </div>
          <figcaption class="border-t border-white/10 bg-[#0d121a] px-6 py-5 sm:px-7 sm:py-6">
            <p class="font-display text-base sm:text-lg font-bold text-brand-ink">${title}</p>
            ${caption ? `<p class="mt-1.5 text-xs sm:text-sm text-brand-mute leading-relaxed">${caption}</p>` : ''}
          </figcaption>
        </figure>
      `);
      continue;
    }

    // 4. Blockquote: > line
    if (block.startsWith('> ')) {
      const quoteLines = block
        .split('\n')
        .map((l) => l.replace(/^>\s?/, '').trim())
        .join(' ');
      htmlParts.push(`<blockquote><p class="mb-0">${renderInlineMarkdown(quoteLines)}</p></blockquote>`);
      continue;
    }

    // 5. Markdown Table: | Col 1 | Col 2 |
    if (block.startsWith('|') && block.includes('\n|')) {
      const rows = block
        .split('\n')
        .map((r) => r.trim())
        .filter((r) => r.startsWith('|'));
      if (rows.length >= 2) {
        const headerCells = rows[0]!
          .split('|')
          .slice(1, -1)
          .map((c) => c.trim());
        const bodyRows = rows.slice(2);
        const theadHtml = headerCells
          .map(
            (c) =>
              `<th class="py-3.5 px-5 first:pl-6 last:pr-6 text-left font-mono text-[11px] font-bold uppercase tracking-wider text-brand-accent border-b border-white/12">${renderInlineMarkdown(c)}</th>`,
          )
          .join('');
        const tbodyHtml = bodyRows
          .map((row, rIdx) => {
            const cells = row
              .split('|')
              .slice(1, -1)
              .map((c) => c.trim());
            const tdHtml = cells
              .map(
                (c, cIdx) =>
                  `<td class="py-4 px-5 first:pl-6 last:pr-6 align-top text-xs sm:text-sm leading-relaxed ${cIdx === 0 ? 'font-semibold text-brand-ink' : 'text-brand-mute'}">${renderInlineMarkdown(c)}</td>`,
              )
              .join('');
            return `<tr class="${rIdx === 0 ? 'bg-brand-accent/10' : 'border-t border-white/10'}">${tdHtml}</tr>`;
          })
          .join('');
        htmlParts.push(`
          <div class="my-10 overflow-x-auto rounded-2xl border border-white/12 bg-[#0d121a] shadow-[0_20px_50px_-28px_rgba(0,0,0,0.8)] not-prose">
            <table class="w-full border-collapse text-left">
              <thead class="bg-white/[0.03]"><tr>${theadHtml}</tr></thead>
              <tbody>${tbodyHtml}</tbody>
            </table>
          </div>
        `);
        continue;
      }
    }

    // 6. Unordered List: - item
    if (block.startsWith('- ')) {
      const items = block
        .split('\n')
        .map((l) => l.replace(/^-\s+/, '').trim())
        .filter(Boolean);
      const liHtml = items.map((it) => `<li>${renderInlineMarkdown(it)}</li>`).join('');
      htmlParts.push(`<ul>${liHtml}</ul>`);
      continue;
    }

    // 7. Ordered List: 1. item
    if (/^\d+\.\s+/.test(block)) {
      const items = block
        .split('\n')
        .map((l) => l.replace(/^\d+\.\s+/, '').trim())
        .filter(Boolean);
      const liHtml = items.map((it) => `<li>${renderInlineMarkdown(it)}</li>`).join('');
      htmlParts.push(`<ol>${liHtml}</ol>`);
      continue;
    }

    // 8. Standard Paragraph
    const joined = block.replace(/\n+/g, ' ');
    if (isFirstParagraph) {
      isFirstParagraph = false;
      htmlParts.push(`<p class="lead">${renderInlineMarkdown(joined)}</p>`);
    } else {
      htmlParts.push(`<p>${renderInlineMarkdown(joined)}</p>`);
    }
  }

  const plainWords = markdown
    .replace(/!\[[^\]]*\]\([^)]+\)/g, ' ')
    .replace(/[#*>|`_-]/g, ' ')
    .trim()
    .split(/\s+/)
    .filter(Boolean).length;

  return {
    html: htmlParts.join('\n'),
    toc,
    wordCount: plainWords,
  };
}

/**
 * Builds the 2,200+ word plain-English Markdown guide for Newark Power Washing
 * & Free Sample Work (or any town × workType × modifier page).
 */
export function buildPowerWashMarkdownGuide(
  dossier: LongFormPageAuthorityDossier,
  page: LandingMatrixPageEntry,
  estimatedTotalUsd: number,
): string {
  const town = dossier.townHeritage.townName;
  const county = dossier.townHeritage.county;
  const state = dossier.townHeritage.state;
  const photoCitySlug = dossier.townHeritage.townSlug === 'newark' ? 'newark' : dossier.townHeritage.townSlug;
  const brownstoneImg =
    photoCitySlug === 'newark' ? '/cities/newark/local-4.jpg' : `/cities/${photoCitySlug}/1.jpg`;
  const brickImg =
    photoCitySlug === 'newark' ? '/cities/newark/local-1.jpg' : `/cities/${photoCitySlug}/2.jpg`;
  const parkImg =
    photoCitySlug === 'newark' ? '/cities/newark/3.jpg' : `/cities/${photoCitySlug}/3.jpg`;

  return `
If you have ever hired a pressure-washing contractor in **${town}, ${state}** and felt nervous watching them point a high-powered wand at your front brick steps, painted porch trim, or driveway, you are not alone. Most homeowners want to know two simple things before paying for a full exterior wash: **will it actually lift the dark grime and green moss off my surface**, and **will it clean without chipping my mortar or leaving streaky lines?** That is why every Brick Labor power-washing visit in ${town} begins with a **free 2ft × 2ft sample test spot** right on your property before we wash the rest of the job at our flat **$50/hr per-worker rate** [Book Your Free Sample Spot](https://bricklabor.com/book).

![Brick Labor technician washing a clean test stripe on a ${town} concrete sidewalk](/guides/power-washing/hero.jpg "Live 2ft × 2ft Test Spot on ${town} Concrete | FREE SAMPLE SPOT FIRST | Seeing a clean, bright stripe right next to the unwashed concrete lets you judge the result in person before we wash the rest of the property.")

## Why We Wash a Free 2ft × 2ft Sample Spot First

Every home in ${town} weathers differently. A shaded bluestone walkway under the trees near Branch Brook Park in Forest Hill collects slippery green moss and dark oak-leaf stains. A three-family red-brick rowhouse in the Ironbound or along Dr. Martin Luther King Jr. Boulevard collects a thin layer of dark street soot from commuter traffic. A poured-concrete driveway in Roseville, Vailsburg, or Weequahic bakes in the summer sun and holds onto winter road salt and tire marks.

When a traditional pressure-washing company gives you a flat price over the phone or from a satellite photo, they are guessing how your stone, brick, siding, or concrete will respond. Worse, if a crew shows up rushing to finish a flat-rate package as fast as possible, they often crank the pressure way too high instead of letting a gentle cleaning solution do the work.

> "The best way to know what a wash will do for your home is to see a real 2ft × 2ft corner cleaned and dried right in front of you. No sales pitch, no guessing — just a clean patch of your own brick, stone, or concrete."

Our **free sample spot** keeps the process completely straightforward:

- **We test a low-visibility 2ft × 2ft corner first:** Together with you, we pick an inconspicuous spot on your driveway apron, bottom porch step, courtyard brick, or north-facing siding.
- **We dial in the gentlest method that gets it clean:** Instead of blasting delicate surfaces, we apply an eco-friendly, plant-safe outdoor soap, give it a few minutes to loosen the dirt and algae, and rinse at the right water pressure for your material.
- **We squeegee or rinse the test spot so you can see the true contrast:** Wet stone and wet concrete always look darker than dry stone. Clearing the test patch lets you see the real side-by-side difference between the unwashed surface and the freshly cleaned spot.
- **You decide how much you want washed at $50/hr:** Once you love how the sample spot looks, our technician washes the rest of your driveway, stoop, patio, or siding at our flat **$50 per hour, per worker** rate (1-hour minimum, billed in simple 15-minute increments after the first hour).

## What Happens During Your First 20 Minutes on Site

We believe property work should feel calm, organized, and predictable from the moment our truck pulls up to your curb in ${town}. We do not show up and immediately blast water across your porch. Every job follows a simple four-part routine during the first twenty minutes.

![Sweeping loose leaves and grit off a patio before power washing](/guides/power-washing/dry-sweep.jpg "Step 1: Dry Sweeping Loose Leaves & Grit First | WATER IS NEVER TOOL #1 | Sweeping away loose leaves, acorns, and surface dirt before turning on the water keeps mud from splashing onto your brick walls and garden beds.")

### 1. Walk the Property & Sweep Loose Debris (Minutes 0–5)

Water should never be the first tool used against loose leaves, twigs, and curb dirt. If you hit a pile of dry leaves and street dust with a pressure washer, it turns into wet mud that splatters across your lower brick wall, screen door, and flower beds. Before we connect a hose, we take two minutes to push-broom or blow away loose leaves, acorns, and surface grit so the water only has to clean the actual stain on the surface.

During this initial walk-around, we also check your outdoor garden spigot to make sure it has steady water flow, confirm that nearby windows and storm doors are latched shut, and look for any delicate areas—like loose mortar joints, older flaking paint, or low-voltage pathway lights—that should be treated gently or avoided.

### 2. Rinse Surrounding Plants & Apply Gentle Cleaner (Minutes 5–12)

If you have hydrangeas, boxwoods, hostas, or grass bordering your ${town} walkway or patio, we soak the leaves and soil with fresh water before applying any cleaning soap. When a plant's roots and leaves are already full of clean water, any mild soapy rinse water that runs off the patio simply slides off without burning the foliage.

Next, we apply a biodegradable outdoor cleaning solution to the 2ft × 2ft test spot and let it sit for about five to eight minutes. Giving the cleaner a few minutes of **dwell time** is the secret to great power washing: the soap breaks the grip of green mildew, black algae, and street grime chemically so we do not have to use harsh, damaging water pressure.

### 3. Wash the 2ft × 2ft Sample Spot & Inspect Together (Minutes 12–18)

Once the cleaner has loosened the grime, we wash the 2ft × 2ft sample patch using the exact attachment matched to your surface. On a flat concrete driveway or sidewalk, we use our circular rotary surface cleaner so the concrete cleans evenly from edge to edge. On brick, brownstone, bluestone, or house siding, we use a wide, gentle fan spray that lifts away the dissolved dirt without digging into the surface.

We invite you to step outside and look at the cleaned 2ft × 2ft square right next to the unwashed area. You can see the color come back to your brick or concrete immediately, and we can give you an honest, accurate time estimate—usually **1 to 2 hours ($50 to $100)** for a typical ${town} stoop, walkway, or two-car driveway—before we wash the rest.

### 4. Finish the Full Wash & Final Rinse (Minutes 18–120)

With your thumbs-up, we apply our cleaning solution across the rest of the work area, wash in steady overlapping passes, rinse down every adjacent step and curb edge so no dirty puddles dry on the slab, and give your neighboring plants one final fresh-water rinse before wrapping up our hoses.

## How We Care for ${town}'s Classic Brick, Brownstone, Bluestone & Concrete

Walking through ${town}'s neighborhoods—from the historic brick rowhouses of the **Ironbound (07105)** and **University Heights (07102/07103)** to the grand brownstone stoops near **James Street Commons**, **Lincoln Park**, and **Military Park**, and the tree-lined yards of **Forest Hill (07104)**, **Roseville (07107)**, **Vailsburg (07106)**, and **Weequahic (07112)**—you see masonry and stonework that has stood for well over a century. Those surfaces deserve a crew that understands the difference between modern poured concrete and 19th-century brick and stone.

![Historic A.D. 1888 rusticated brownstone porch and masonry in ${town}](${brownstoneImg} "A.D. 1888 ${town} Brownstone & Historic Stoops | GENTLE LOW-PRESSURE WASH | Historic Belleville brownstone and older sandstone steps are naturally soft and porous — we clean them with mild stone soap and a gentle rinse, never high pressure.")

### Historic Red Brick & Older Lime Mortar (Ironbound, Central Ward & University Heights)

Many brick homes built in ${town} before the 1940s were laid with traditional **lime-and-sand mortar** rather than hard modern Portland cement. Lime mortar is intentionally softer than the clay bricks around it so the wall can expand and contract through New Jersey winters without cracking the bricks.

If someone blasts a pre-war brick wall or chimney with a narrow, high-pressure nozzle from a few inches away, the water jet can carve right into the soft mortar joints and pit the protective baked outer face of the brick. On historic brick, our free 2ft × 2ft sample spot shows you how **soft washing** works: we let our masonry cleaner dissolve the dark city soot and green moss, then rinse with a wide fan spray at low pressure—roughly the force of a strong garden nozzle—so the brick brightens up while every mortar joint stays solid and intact.

![Historic red-brick and white limestone trim architecture in ${town}](${brickImg} "19th-Century ${town} Red Brick & Limestone Trim | SOFT-WASH MASONRY CARE | Low-pressure rinsing after a gentle soap soak lifts years of dark street soot off brick and white stone trim without disturbing a single mortar joint.")

### Brownstone Steps, Bluestone Walkways & Paver Patios (James Street & Forest Hill)

Newark's classic brownstone stoops (quarried from nearby Belleville and Passaic River sandstone beds) and Forest Hill's shaded bluestone patios look incredible when clean, but both get slick when damp moss and tree pollen build up in the spring and fall.

- **Brownstone stoops and cheek walls:** Because brownstone is a layered sedimentary stone, high water pressure can cause thin flakes of stone to peel away. We use a pH-neutral stone cleaner, a soft natural-bristle brush on stubborn shaded step risers, and a gentle low-pressure rinse.
- **Bluestone slabs and backyard pavers:** On flagstone and brick pavers, we angle a medium-pressure fan spray across the stone rather than pointing straight down into the cracks. That lifts the slippery green moss off the stone face while keeping the joint sand between your pavers in place.

### Poured Concrete Driveways, Aprons & Sidewalks (All ${town} Wards)

Hard poured concrete is much denser than brick or brownstone, pulsing with thousands of tiny pores that trap black algae, winter de-icing salt, and rubber tire marks. If you try to wash a two-car concrete driveway with a small handheld wand, the narrow spray cleans a two-inch line wherever you wave it—leaving behind permanent light-and-dark "zebra stripes" once the driveway dries.

![Circular rotary surface cleaner washing a concrete slab evenly](/guides/power-washing/surface-cleaner.jpg "Our Circular Surface Cleaner on Concrete | ZERO WAND STREAKS | Under this hovering round deck, twin spray nozzles spin at fixed height above the slab so your driveway and sidewalk dry with a completely uniform, streak-free finish.")

Instead of waving a wand by hand, we use a **commercial circular surface cleaner** powered by our high-flow washer. Under its round cover, two balanced spray tips spin at a fixed height above the concrete. As our technician walks it steadily across your driveway or sidewalk, every square inch receives the exact same cleaning pass—eliminating wand streaks and cleaning a full two-car driveway in right around an hour to ninety minutes.

### Vinyl, Aluminum & Painted Wood Siding

North-facing house siding in ${town} often develops a dusty green film of mildew or a chalky white residue from years of sun exposure. On siding, we always work at **low pressure** and spray at a **downward angle**. Spraying upward at high pressure can force water behind overlapping siding panels and through weep holes. Our gentle soap-and-rinse approach melts away the green mildew and spider webs from the ground up, leaving your siding bright and dry inside.

## The Two Pressure Washers We Carry — And Why Flow (GPM) Matters More Than PSI

When people shop for a pressure washer at a hardware store, the biggest number on the box is always **PSI** (pounds per square inch). It is easy to assume that a 4,000 PSI machine cleans twice as well as a 2,000 PSI machine. In real fieldwork, however, **water flow—measured in gallons per minute (GPM)—is what actually flushes dirt away and rinses a driveway quickly.**

![Commercial belt-drive gas pressure washer staged curbside](/guides/power-washing/machine-gas.jpg "Commercial 4.0 GPM Gas Washer & Hose Reels | INCLUDED AT $0 GEAR FEE | We bring both our high-flow commercial gas washer for concrete driveways and our quiet electric soft-wash setup for porches, brick, and siding at zero equipment surcharge.")

We carry two different machines on our ${town} truck, and we pick the right one for your surfaces during your free sample test spot:

1. **Our High-Flow Commercial Gas Washer (4.0 Gallons Per Minute):** We use this machine when washing large concrete driveways, sidewalks, parking pads, and commercial storefronts where our circular surface cleaner needs plenty of water flow to spin smoothly and flush heavy dirt down to the curb. Even when using our commercial gas machine on brick or stone, we dial the pressure down and switch to wide-angle tips whenever a gentler touch is needed.
2. **Our Quiet Electric Soft-Wash Setup (Low-Pressure Precision):** For smaller front porches, wooden decks, vinyl siding, fenced courtyards, and delicate historic brick or brownstone stoops, our compact electric washer delivers quiet, controlled low-pressure rinsing without waking up the block or overwhelming delicate trim.

Best of all, **we never charge an equipment rental fee, chemical fee, or fuel surcharge.** Whether your job uses our commercial surface cleaner, 100 feet of non-marking hose, plant-safe outdoor detergent, or soft-wash brushes, every tool on the truck is included in our flat **$50/hr per-worker rate**.

## Simple $50/hr Pricing vs. Traditional Per-Square-Foot Quotes

Most exterior cleaning companies price jobs by the square foot or bundle you into a flat-rate package with a $350 to $500 minimum call-out charge—even when the actual washing on your property only takes ninety minutes. Other homeowners spend $95 renting a small machine from a big-box hardware store, buy $40 worth of cleaner jugs, haul a wet machine in the trunk of their car, and lose their entire Saturday afternoon fighting a slow 1.5-GPM wand.

At Brick Labor, we price power washing the same honest way we price all of our property work across New Jersey: **a flat $50 per hour, per worker**, with a one-hour minimum and simple **15-minute billing increments ($12.50)** after the first hour [Book Online in 60 Seconds](https://bricklabor.com/book).

| Wash Option in ${town}, ${state} | Typical 2-Hour Driveway & Stoop Cost | Equipment & Soap Fees | Free 2ft × 2ft Sample Spot First? | How Billing Works |
| --- | --- | --- | --- | --- |
| **Brick Labor ($50/hr Per Worker)** | **$100** (1 worker × 2 hrs) | **$0** (All gear & soap included) | **Yes — free 2ft × 2ft test spot** | Flat $50/hr · 1-hr min · 15-min increments after hr 1 |
| **DIY Big-Box Store Rental** | **$145–$175** + 5 hrs of your Saturday | $95 rental + $45 soap + gas | No (you do all the work yourself) | Full-day rental deposit + pickup & return trip |
| **Per-Sq-Ft Pressure-Wash Franchise** | **$380–$490** flat package quote | Often adds $50–$90 chemical fee | Rarely included before signing | High flat-rate markup over actual time on site |
| **Commercial Exterior Rig Call-Out** | **$495–$600** minimum dispatch | Portal-to-portal travel fee | Only on large commercial bids | Enforces a 4-hour minimum even on small residential jobs |

![Spring cherry blossoms at Branch Brook Park in ${town}, ${state}](${parkImg} "Dispatched From Our ${town} Home Base | $0 TRAVEL FEE IN ${town.toUpperCase()} | Because ${town} is our home base, you never pay a travel fee, zone fee, or equipment surcharge anywhere in ${county} County.")

### What Can 1 Worker Wash in 1 to 3 Hours?

Because our commercial washer moves four gallons of water per minute and drives a 16-inch circular surface cleaner, a single experienced technician moves much faster than a homeowner with a retail machine:

- **1 Hour ($50 total — 1 worker × 1 hr):** Ideal for a front brownstone or brick stoop, a front sidewalk strip, and a small courtyard or back patio (roughly 350 to 450 square feet), including your free 2ft × 2ft sample test spot at the start.
- **2 Hours ($100 total — 1 worker × 2 hrs):** Our most popular booking in ${town}. Covers a standard two-car concrete driveway, the front walkway, and the front porch steps (roughly 650 to 900 square feet).
- **3 Hours ($150 total — 1 worker × 3 hrs):** Great for a full driveway plus a backyard bluestone or paver patio, retaining wall, and first-floor vinyl or brick siding elevation.
- **Recurring Standing Schedules (Up to 12% Off):** For ${town} homeowners, multi-family landlords, and Broad Street or Ferry Street storefronts that want regular sidewalk and entryway washing, our standing schedules automatically discount our $50/hr rate: **Daily (-12% · $44/hr)**, **Weekly (-8% · $46/hr)**, **Biweekly (-5% · $47.50/hr)**, and **Monthly (-3% · $48.50/hr)**.

## How to Prep Your Home in 5 Minutes Before We Arrive

You do not need to do any heavy lifting before our crew arrives—and if you have heavy patio tables, ceramic planters, or grills on your deck or patio, our technician is happy to slide them out of the way and put them back as part of the hourly clock. Doing these five quick things before your window helps us get straight to your free sample test spot:

1. **Turn on your outdoor water spigot:** Make sure the interior basement or utility shutoff valve feeding your outside garden hose bib is turned all the way on. Our washer connects to a standard garden spigot and uses normal household water flow.
2. **Close windows and latch storm doors:** Double-check that first-floor and basement windows, mail slots, and storm doors near the wash area are snugly closed so fine mist stays outside.
3. **Move cars out of the driveway apron:** If we are washing your driveway or front walk, parking your car a couple of spaces down the street keeps soap mist off your clean windshield.
4. **Keep pets indoors during the wash:** Dogs and cats are naturally curious about hoses and spinning surface cleaners; keeping them inside until our final fresh-water rinse keeps paws dry and safe.
5. **Pick out your favorite 2ft × 2ft sample spot:** Think about which stubborn patch of green moss, dark soot, or weathered concrete you most want to see transformed first when we knock on your door!

## Honest Expectations: What Power Washing Fixes Instantly (And When We Stop)

We believe you deserve honest answers before a single dollar is spent. That is the whole point of washing a free 2ft × 2ft sample spot first.

- **What lifts off beautifully:** Green moss, black weather algae, dark commuter-corridor soot, tree pollen, bird droppings, winter salt residue, spider webs, and surface dirt lift away dramatically—often making concrete, bluestone, brick, and vinyl siding look ten years younger in a single pass.
- **Old, deep motor-oil shadows on porous concrete:** When hot crankcase oil drips onto an unsealed concrete driveway for years, it soaks deep below the surface like dye in a sponge. Our degreaser and rotary surface cleaner will remove 100% of the slick surface grease and lighten the spot significantly, though a faint shadow can sometimes remain in the pores of older concrete. Because we test a sample spot first, you will see the exact improvement with your own eyes.
- **When we recommend stopping or skipping a spot:** If we inspect a section of older pre-1978 painted wood trim that is actively peeling or blistering, or a crumbling brick step where the mortar has turned to loose sand, we will point it out to you right away. We never blast loose paint or fragile, crumbling masonry that should be hand-scraped or repointed first.

> Ready to see what a clean 2ft × 2ft sample patch looks like on your ${town} home? Book your slot online at [bricklabor.com/book](https://bricklabor.com/book) or call us at **${PHONE_DISPLAY}** — flat **$50/hr per worker**, 1-hour minimum, and **$0 travel fee** anywhere in ${town}.
`.trim();
}

export function MarkdownGuideArticle({
  dossier,
  page,
  isPowerWash,
  estimatedTotalUsd,
  bookingUrl = 'https://bricklabor.com/book',
}: MarkdownGuideArticleProps) {
  const ttSurface = useThemeToolsSurface('markdown-guide-article');
  const markdownSource = useMemo(() => {
    if (isPowerWash) {
      return buildPowerWashMarkdownGuide(dossier, page, estimatedTotalUsd);
    }
    // For non-power-wash matrix pages, assemble a clean Markdown guide from dossier chapters & photos
    const town = dossier.townHeritage.townName;
    const state = dossier.townHeritage.state;
    const allPhotos = [...dossier.townHeritage.nostalgicPhotos, ...dossier.crewScenarioPhotos];
    const parts: string[] = [page.answerCapsule];
    dossier.chapters.slice(0, 6).forEach((ch, idx) => {
      const photo = allPhotos[idx];
      if (photo) {
        parts.push(
          `![${photo.altText}](${photo.imageUrl} "${photo.title.replace(/"/g, "'")} | ${photo.eraOrSetupBadge.replace(/"/g, "'")} | ${photo.caption.replace(/"/g, "'")}")`,
        );
      }
      parts.push(`## ${ch.heading}`);
      ch.paragraphs.forEach((p) => parts.push(p));
      if (ch.keyBullets.length > 0) {
        parts.push(ch.keyBullets.map((b) => `- ${b}`).join('\n'));
      }
    });
    parts.push(
      `> Ready to book your ${town}, ${state} crew at a flat $50/hr per worker? Reserve online at [bricklabor.com/book](https://bricklabor.com/book).`,
    );
    return parts.join('\n\n');
  }, [dossier, page, isPowerWash, estimatedTotalUsd]);

  const parsed = useMemo(() => convertGuideMarkdownToHtml(markdownSource), [markdownSource]);

  return (
    <ThemeToolsPageSurface
      surface="markdown-guide-article"
      data-testid="markdown-rendered-guide-section"
      data-guide-word-count={parsed.wordCount}
      className="grid gap-10 lg:grid-cols-12 items-start my-6"
      {...ttSurface.dataAttributes}
    >
      {/* Left Column: Sizable Markdown-to-HTML Editorial Guide (.tt-prose.prose-bcl) */}
      <article
        data-testid="markdown-guide-article"
        className="tt-guide-shell lg:col-span-8 px-1 sm:px-2 lg:px-0 lg:pr-6 pt-2 pb-4"
      >
        <div
          data-testid="markdown-guide-html-body"
          className="tt-prose prose-bcl max-w-none"
          dangerouslySetInnerHTML={{ __html: parsed.html }}
        />

        {/* Editorial Multimedia Sections Integrated Directly Into Guide Flow */}
        <ArticleMultimediaSuite
          townName={dossier.townHeritage.townName}
          state={dossier.townHeritage.state}
          isPowerWash={isPowerWash}
          bookingUrl={bookingUrl}
          hideFaq={true}
        />

        {/* Clean Bottom Callout Inside Article */}
        <div className="tt-callout mt-12 rounded-2xl px-6 py-6 sm:px-8 sm:py-7 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-6">
          <div className="max-w-xl">
            <p className="font-mono text-xs uppercase tracking-wider text-brand-accent">
              Flat $50/hr Per Worker · Free 2ft × 2ft Sample First
            </p>
            <h3 className="mt-1.5 font-display text-xl sm:text-2xl font-extrabold text-brand-ink leading-snug">
              Ready to see a clean test spot on your {dossier.townHeritage.townName} property?
            </h3>
            <p className="mt-1.5 text-xs sm:text-sm text-brand-mute leading-relaxed">
              1-hour minimum · 15-minute increments after hour 1 · $0 equipment or travel fee in {dossier.townHeritage.townName}.
            </p>
          </div>
          <a
            href={bookingUrl}
            className="tt-btn tt-btn--primary btn btn-primary btn-arrow whitespace-nowrap shrink-0"
          >
            <span>Book at bricklabor.com/book</span>
            <span data-btn-arrow aria-hidden="true">→</span>
          </a>
        </div>
      </article>

      {/* Right Column: Clean, Simple Sticky Table of Contents & Quick Summary Card */}
      <aside className="lg:col-span-4 lg:sticky lg:top-20 space-y-3">
        <nav
          aria-label="In this guide"
          className="tt-toc-card rounded-2xl border border-brand-line bg-bg-elevated p-4"
        >
          <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-brand-accent mb-2">
            In This {dossier.townHeritage.townName} Guide
          </p>
          <ol className="space-y-1.5 text-xs">
            {parsed.toc.map((item, idx) => (
              <li key={item.id} className="flex items-start gap-2">
                <span className="font-mono text-[11px] font-bold text-brand-accent mt-0.5">
                  0{idx + 1}.
                </span>
                <a
                  href={`#${item.id}`}
                  className="text-brand-mute hover:text-brand-accent transition-colors leading-snug"
                >
                  {item.title}
                </a>
              </li>
            ))}
          </ol>
        </nav>

        {/* Simple At-a-Glance Summary Card */}
        <div className="tt-glance-card rounded-2xl border border-brand-line bg-bg-elevated p-4 space-y-2.5">
          <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-brand-accent">
            At a Glance · {dossier.townHeritage.townName}, {dossier.townHeritage.state}
          </p>
          <dl className="space-y-1.5 text-xs">
            <div className="flex justify-between border-b border-brand-line/60 pb-1">
              <dt className="text-brand-mute">Hourly Rate:</dt>
              <dd className="font-mono font-bold text-brand-ink">$50/hr per worker</dd>
            </div>
            <div className="flex justify-between border-b border-brand-line/60 pb-1">
              <dt className="text-brand-mute">Sample Spot:</dt>
              <dd className="font-mono font-bold text-emerald-400">Free 2ft × 2ft patch ($0)</dd>
            </div>
            <div className="flex justify-between border-b border-brand-line/60 pb-1">
              <dt className="text-brand-mute">Typical 2-Hr Wash:</dt>
              <dd className="font-mono font-bold text-brand-accent">${estimatedTotalUsd} (1 tech × 2 hrs)</dd>
            </div>
            <div className="flex justify-between border-b border-brand-line/60 pb-1">
              <dt className="text-brand-mute">After Hour 1:</dt>
              <dd className="font-mono font-bold text-brand-ink">15-min increments ($12.50)</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-brand-mute">Gear &amp; Travel Fee:</dt>
              <dd className="font-mono font-bold text-emerald-400">$0 in {dossier.townHeritage.townName}</dd>
            </div>
          </dl>
          <div className="pt-1">
            <a
              href={bookingUrl}
              className="tt-btn tt-btn--primary btn btn-primary w-full text-center text-xs py-2.5"
            >
              Book Free Sample + Wash (${estimatedTotalUsd}) →
            </a>
          </div>
        </div>
      </aside>
    </ThemeToolsPageSurface>
  );
}

export default MarkdownGuideArticle;
