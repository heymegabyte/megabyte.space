import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useCallback, useEffect, useMemo, useState, type JSX, type ReactNode } from 'react';
import { CalendarWorkspace } from './customer/CalendarWorkspace.js';
import { MyBookingsList } from './customer/MyBookingsList.js';
import { MyJobDetail } from './customer/MyJobDetail.js';
import { MyPhotoArchive } from './customer/MyPhotoArchive.js';
import { UpcomingJobsList } from './customer/UpcomingJobsList.js';
import { CustomerProfileCard } from './customer/CustomerProfileCard.js';
import MyAiRules from './customer/MyAiRules.js';
import { NotificationPrefs } from './customer/NotificationPrefs.js';
import { NeighborReferralCard } from './customer/NeighborReferralCard.js';
import { ReferralLinkShare } from './ReferralLinkShare.js';
import { AffiliateProfitShareCard } from './AffiliateProfitShareCard.js';
import { SquarePaymentHistory } from './customer/SquarePaymentHistory.js';
import { RecurringPlansPanel } from './customer/RecurringPlansPanel.js';
import { AddressBookCard } from './customer/AddressBookCard.js';
import { LoyaltyDashboard } from './customer/LoyaltyDashboard.js';
import { MyCommLog } from './customer/MyCommLog.js';
import CommPrefsForm from './wave29/CommPrefsForm.js';
import { ArrivalPushSettings } from './ArrivalPushSettings.js';
import { PredictNextCard } from './customer/PredictNextCard.js';
import { DataRights } from './customer/DataRights.js';
import { PhotoBookmarksGrid } from './customer/PhotoBookmarksGrid.js';
import { BadgesCard, AutofillCard, AffinityCard } from './customer/wave20/tiles.js';
import { SmartHomeSetup } from './customer/SmartHomeSetup.js';
import { useFeatureFlag } from '../use-feature-flag.js';
import type { Booking, MePayload } from '@theme.tools/scheduling/field-service/customer-types';
import { useCustomerJobs } from '../customer-jobs.js';
import type { JobListItem } from '../customer-jobs.js';
import { scrollToTop } from '../scroll-to.js';
import { DashboardShell, type DashboardNavGroup } from './shell/DashboardShell.js';
import type { UserAvatarMenuGroup } from './shell/UserAvatarMenu.js';
import { PHONE_TEL_HREF, PHONE_SMS_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';

const TITLE = 'Your dashboard — Brick Labor';
const DESC =
  'Google-Calendar-style scheduling, AI concierge, before/after photos, payments — manage every Newark job in one screen.';

const COMPACT_KEY = 'bcl_me_shell_compact_v1';

type PanelKey =
  | 'calendar'
  | 'jobs'
  | 'photos'
  | 'payments'
  | 'plans'
  | 'rewards'
  | 'refer'
  | 'profile'
  | 'notifications';

interface PanelMeta {
  readonly key: PanelKey;
  readonly label: string;
  readonly icon: string;
  readonly description: string;
}

const PANELS_FIRST: PanelMeta = {
  key: 'calendar',
  label: 'Calendar',
  icon: '◧',
  description: 'Google-Calendar-style scheduling',
};

const PANELS: ReadonlyArray<PanelMeta> = [
  PANELS_FIRST,
  {
    key: 'jobs',
    label: 'Jobs',
    icon: '◇',
    description: 'Upcoming + past, with tracking',
  },
  {
    key: 'photos',
    label: 'Photos',
    icon: '◐',
    description: 'Before / after across every gig',
  },
  {
    key: 'payments',
    label: 'Payments',
    icon: '$',
    description: 'Square receipts + saved card',
  },
  {
    key: 'plans',
    label: 'Plans',
    icon: '↻',
    description: 'Recurring subscriptions — pause, resume, snooze',
  },
  {
    key: 'rewards',
    label: 'Rewards',
    icon: '★',
    description: 'Loyalty tier, points, and perks',
  },
  {
    key: 'refer',
    label: 'Refer',
    icon: '◊',
    description: 'Share your $25-off link with a neighbor',
  },
  {
    key: 'profile',
    label: 'Profile',
    icon: '◌',
    description: 'Name, addresses, business info',
  },
  {
    key: 'notifications',
    label: 'Notifications',
    icon: '◍',
    description: 'SMS · email · push · quiet hours',
  },
];

function track(name: string, props: Record<string, unknown> = {}): void {
  try {
    const w = window as unknown as {
      posthog?: { capture: (n: string, p?: Record<string, unknown>) => void };
    };
    w.posthog?.capture(name, props);
  } catch {
    /* noop */
  }
}

function panelFromUrl(): PanelKey {
  if (typeof window === 'undefined') return 'calendar';
  const search = new URLSearchParams(window.location.search);
  const fromParam = (search.get('panel') || '').toLowerCase();
  if (PANELS.some((p) => p.key === fromParam)) return fromParam as PanelKey;
  // Legacy `#upcoming|#past|#account|#photos` deep-links — route them.
  const h = window.location.hash.replace(/^#/, '').toLowerCase();
  if (h === 'photos') return 'photos';
  if (h === 'past' || h === 'upcoming') return 'jobs';
  if (h === 'account') return 'profile';
  return 'calendar';
}

export function MePage(): JSX.Element {
  useThemeToolsSurface('me-page');
  const [panel, setPanel] = useState<PanelKey>(panelFromUrl);
  const [detailId, setDetailId] = useState<string | null>(null);
  // Recurring-subscriptions is dark by default — gate its nav entry on the flag
  // so the "Plans" item only appears once the feature is promoted.
  const plansEnabled = useFeatureFlag('recurring_subscriptions');
  // Saved-address book lives in the Profile panel; self-hides when off.
  const addressBookEnabled = useFeatureFlag('customer_address_book');
  // GDPR data export is always available (compliance); the account-deletion
  // half of DataRights is gated by account_self_delete (dark by default).
  const accountSelfDeleteEnabled = useFeatureFlag('account_self_delete');
  const affiliateProfitShareEnabled = useFeatureFlag('affiliate_profit_share');
  // HEAD's job-list source — drives the Jobs/Photos panels + nav badge counts.
  const { data, error, loading, refresh } = useCustomerJobs('all');
  // Agent's calendar-only payload — drives the CalendarWorkspace (richer
  // Booking shape with notes + address). Fetched in parallel so the calendar
  // doesn't wait on the legacy /api/customer/jobs endpoint.
  const [calendarPayload, setCalendarPayload] = useState<MePayload | null>(null);
  const [compact, setCompact] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    try {
      return window.localStorage.getItem(COMPACT_KEY) === '1';
    } catch {
      return false;
    }
  });

  const refreshCalendar = useCallback(async () => {
    try {
      const res = await fetch('/api/auth/client/me', { credentials: 'same-origin' });
      if (res.status === 401) {
        // Don't redirect — the inline sign-in panel below renders when the
        // useCustomerJobs hook reports `unauthorized`. Keep the calendar
        // payload null so we don't leak stale state.
        setCalendarPayload(null);
        return;
      }
      const json = (await res.json()) as MePayload;
      setCalendarPayload(json);
    } catch {
      /* swallow — calendar will render empty rather than crash */
    }
  }, []);

  useEffect(() => {
    document.title = TITLE;
    const meta = document.querySelector('meta[name="description"]');
    if (meta) meta.setAttribute('content', DESC);
    track('me_dashboard_viewed');
    void refreshCalendar();
  }, [refreshCalendar]);

  useEffect(() => {
    try {
      window.localStorage.setItem(COMPACT_KEY, compact ? '1' : '0');
    } catch {
      /* noop */
    }
  }, [compact]);

  // §loop-break (2026-05-24) — DO NOT auto-redirect to /login on 401. The
  // previous flow caused an infinite loop: /me 401s → /login?next=/me →
  // LoginPage saw stale bcl_active_role=customer in localStorage + a stale
  // cookie that /api/auth/client/me accepted but /api/customer/jobs rejected
  // → redirected back to /me → 401 → /login → loop. Render an inline sign-in
  // panel instead so the user always has a manual escape hatch.
  // useEffect(() => {
  //   if (error === 'unauthorized') {
  //     window.location.href = '/login?next=%2Fme';
  //   }
  // }, [error]);

  useEffect(() => {
    const onUrlChange = () => setPanel(panelFromUrl());
    window.addEventListener('popstate', onUrlChange);
    window.addEventListener('hashchange', onUrlChange);
    return () => {
      window.removeEventListener('popstate', onUrlChange);
      window.removeEventListener('hashchange', onUrlChange);
    };
  }, []);

  const setPanelAndUrl = useCallback((next: PanelKey) => {
    setPanel(next);
    if (typeof window !== 'undefined') {
      const url = new URL(window.location.href);
      url.searchParams.set('panel', next);
      url.hash = '';
      history.replaceState(null, '', url.toString());
    }
    track('me_panel_changed', { panel: next });
    scrollToTop('[data-me-panel]', { behavior: 'smooth' });
  }, []);

  const logout = useCallback(async () => {
    await fetch('/api/auth/client/logout', {
      method: 'POST',
      credentials: 'same-origin',
    });
    window.location.href = '/';
  }, []);

  const items: ReadonlyArray<JobListItem> = data?.items ?? [];
  const meta = PANELS.find((p) => p.key === panel) ?? PANELS_FIRST;

  // Build the side-menu groups for DashboardShell.
  const navGroups: DashboardNavGroup[] = useMemo(() => {
    const stats = computeStats(items);
    return [
      {
        items: PANELS.filter((p) => p.key !== 'plans' || plansEnabled).map((p) => ({
          key: p.key,
          label: p.label,
          icon: p.icon,
          href: `?panel=${p.key}`,
          badge:
            p.key === 'jobs' && stats.upcoming > 0
              ? stats.upcoming
              : p.key === 'calendar' && stats.upcoming > 0
                ? stats.upcoming
                : undefined,
        })),
      },
    ];
  }, [items, plansEnabled]);

  // Override the nav item click → our setPanelAndUrl (so URL stays /me + ?panel=).
  const navWithHandlers: DashboardNavGroup[] = navGroups.map((g) => ({
    ...g,
    items: g.items.map((item) => ({
      ...item,
      href: `/me?panel=${item.key}`,
    })),
  }));

  const contact = data?.contact ?? calendarPayload?.contact ?? '';
  const channel: 'sms' | 'email' = calendarPayload?.channel ?? 'email';
  const displayName = useMemo(() => {
    if (!contact) return 'Welcome';
    if (contact.includes('@')) return contact.split('@')[0] ?? 'You';
    return contact;
  }, [contact]);

  const userMenu: UserAvatarMenuGroup[] = [
    {
      items: [
        { label: 'Profile', href: '/me?panel=profile', icon: '◌' },
        { label: 'Notifications', href: '/me?panel=notifications', icon: '◍' },
        { label: 'Payments', href: '/me?panel=payments', icon: '$' },
      ],
    },
    {
      items: [
        { label: 'Book another crew', href: '/book', icon: '+' },
        { label: 'Back to bricklabor.com', href: '/', icon: '←' },
      ],
    },
    {
      items: [{ label: 'Sign out', onClick: () => void logout(), icon: '⎋', danger: true }],
    },
  ];

  // Intercept nav-item anchor clicks so we use setPanelAndUrl instead of
  // a full navigation — keeps the dashboard SPA-fast.
  const onShellClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const target = e.target as HTMLElement;
    const link = target.closest<HTMLAnchorElement>('a[href^="/me?panel="]');
    if (!link) return;
    e.preventDefault();
    const url = new URL(link.href);
    const next = url.searchParams.get('panel') as PanelKey | null;
    if (next && PANELS.some((p) => p.key === next)) {
      setPanelAndUrl(next);
    }
  };

  // Inline sign-in panel when unauthenticated. Replaces the prior
  // window.location bounce-to-login that caused an infinite refresh loop
  // when /api/auth/client/me and /api/customer/jobs disagreed on cookie
  // validity. User now ALWAYS sees a stable page with a manual escape hatch.
  if (error === 'unauthorized') {
    if (typeof window !== 'undefined') {
      try {
        window.localStorage.removeItem('bcl_active_role');
      } catch {
        /* ignore */
      }
    }
    return (
      <article className="min-h-[70vh] grid place-items-center px-4">
        <div className="max-w-md w-full rounded-2xl border border-brand-line bg-bg-elevated/60 p-8 sm:p-10 text-center">
          <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-brand-accent mb-3">
            Your dashboard
          </p>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-brand-ink mb-3">
            Sign in to see your bookings.
          </h1>
          <p className="text-brand-mute leading-relaxed mb-6">
            Every booking, message, photo, and payment in one place. Six-digit code by email or text
            — no password.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <a
              href="/login/customer?next=%2Fme"
              className="inline-flex items-center justify-center rounded-md bg-brand-accent px-5 py-3 font-mono text-[12px] font-bold uppercase tracking-wider text-bg-primary hover:bg-brand-accent/90 transition-colors"
            >
              Sign in →
            </a>
            <a
              href="/book"
              className="inline-flex items-center justify-center rounded-md border border-brand-line px-5 py-3 font-mono text-[12px] font-bold uppercase tracking-wider text-brand-ink hover:border-brand-accent hover:text-brand-accent transition-colors"
            >
              Book a crew first
            </a>
          </div>
        </div>
      </article>
    );
  }

  // Calendar panel renders full-bleed (drag-create, mini-calendar, keyboard
  // shortcuts, AI optimizer all need the full canvas). Other panels keep the
  // default page-title strip + padded surface.
  const isCalendar = panel === 'calendar';

  return (
    <div onClick={onShellClick}>
      <DashboardShell
        active={panel}
        title={meta.label}
        breadcrumb={[{ label: 'Your account', href: '/me' }, { label: meta.label }]}
        nav={navWithHandlers}
        userDisplayName={displayName}
        userSubtitle={contact ? 'Signed in' : undefined}
        userMenu={userMenu}
        brandBadge="ACCOUNT"
        compact={isCalendar ? compact : false}
        onToggleCompact={isCalendar ? setCompact : undefined}
        fullBleed={isCalendar}
      >
        <div data-me-panel className={isCalendar ? 'flex flex-col flex-1 min-h-0' : ''}>
          {loading && items.length === 0 && !isCalendar && (
            <p className="text-brand-mute text-sm" role="status" aria-live="polite">
              Loading your dashboard…
            </p>
          )}

          {error && error !== 'unauthorized' && !isCalendar && (
            <div className="mb-4 rounded-xl border border-red-500/40 bg-red-500/10 p-4 text-sm text-red-200">
              Couldn't load your jobs ({error}).{' '}
              <button
                type="button"
                onClick={refresh}
                className="underline-hover text-red-100 font-semibold"
              >
                Try again
              </button>
              .
            </div>
          )}

          {panel === 'calendar' && (
            <CalendarPanel
              bookings={calendarPayload?.bookings ?? []}
              contact={contact}
              channel={channel}
              onRefresh={refreshCalendar}
            />
          )}
          {panel === 'jobs' && (
            <JobsPanel items={items} loading={loading} onOpenDetail={setDetailId} />
          )}
          {panel === 'photos' && <PhotosPanel items={items} />}
          {panel === 'payments' && <SquarePaymentHistory />}
          {panel === 'plans' && <RecurringPlansPanel />}
          {panel === 'rewards' && <LoyaltyDashboard />}
          {panel === 'rewards' && (
            <div className="grid grid-cols-3 gap-3 mt-4" data-testid="mounted-wave20-tiles">
              <BadgesCard />
              <AutofillCard />
              <AffinityCard />
            </div>
          )}
          {panel === 'refer' && (
            <div className="space-y-4">
              <ReferralLinkShare />
              <NeighborReferralCard />
              <AffiliateProfitShareCard enabled={affiliateProfitShareEnabled} />
            </div>
          )}
          {panel === 'profile' && (
            <div className="space-y-6">
              <CustomerProfileCard onAccountChange={logout} />
              <MyAiRules />
              <AddressBookCard customerId={contact} enabled={addressBookEnabled} />
              <SmartHomeSetup />
              <DataRights accountSelfDeleteEnabled={accountSelfDeleteEnabled} />
            </div>
          )}
          {panel === 'notifications' && (
            <div className="space-y-6">
              <NotificationPrefs />
              <CommPrefsForm />
              <ArrivalPushSettings />
              <MyCommLog />
              <HelpCard />
            </div>
          )}
        </div>
      </DashboardShell>
      {detailId && <MyJobDetail bookingId={detailId} onClose={() => setDetailId(null)} />}
    </div>
  );
}

function computeStats(items: ReadonlyArray<JobListItem>) {
  const upcoming = items.filter((i) =>
    [
      'pending_payment',
      'pending_confirmation',
      'paid',
      'paid_in_full',
      'confirmed',
      'reminded',
      'in_progress',
      'en_route',
    ].includes(i.status),
  ).length;
  const completed = items.filter((i) => i.status === 'completed').length;
  const spent = items.filter((i) => i.status !== 'canceled').reduce((s, i) => s + i.totalCents, 0);
  return { upcoming, completed, spent };
}

// Legacy SidebarBrand / SidebarStats / SidebarNav / SidebarFooter / TopBar
// removed 2026-05-23 — now sourced from shell/DashboardShell.tsx +
// shell/UserAvatarMenu.tsx so every authenticated dashboard (admin / crew /
// account) shares one full-width chrome.

// ─── Panels ─────────────────────────────────────────────────────────────────

function CalendarPanel({
  bookings,
  contact,
  channel,
  onRefresh,
}: {
  bookings: Booking[];
  contact: string;
  channel: 'sms' | 'email';
  onRefresh: () => Promise<void> | void;
}): JSX.Element {
  // §Calendar — full-bleed top-left, no hero card consuming real-estate.
  // The CalendarWorkspace IS the page when this panel is active.
  return (
    <CalendarWorkspace
      bookings={bookings}
      contact={contact}
      channel={channel}
      onRefresh={onRefresh}
    />
  );
}

function JobsPanel({
  items,
  loading,
  onOpenDetail,
}: {
  items: ReadonlyArray<JobListItem>;
  loading: boolean;
  onOpenDetail: (id: string) => void;
}): JSX.Element {
  return (
    <div className="space-y-8">
      <PanelHero
        eyebrow="Jobs"
        title="Every gig, every receipt."
        body="Upcoming jobs come first with live tracking + ETA. Past jobs roll into the search-friendly history below — tap any row for the full detail panel."
      />
      {/* Predicted-next-service nudge — self-gating (hides when no suggestion or
          dismissed-for-30-days). Backed by /api/loyalty/predict-next. */}
      <PredictNextCard />
      <UpcomingJobsList items={items} loading={loading} />
      <MyBookingsList items={items} loading={loading} onOpenDetail={onOpenDetail} />
    </div>
  );
}

function PhotosPanel({ items }: { items: ReadonlyArray<JobListItem> }): JSX.Element {
  return (
    <div className="space-y-4">
      <PanelHero
        eyebrow="Photos"
        title="Before + after, every gig."
        body="Crews snap 4 before + 4 after on every job. Filter by service or year, tap a tile to open the lightbox."
      />
      <PhotoBookmarksGrid />
      <MyPhotoArchive items={items} />
    </div>
  );
}

function PanelHero({
  eyebrow,
  title,
  body,
  cta,
}: {
  eyebrow: string;
  title: string;
  body: string;
  cta?: { href: string; label: string };
}): JSX.Element {
  return (
    <header className="rounded-3xl border border-brand-line bg-brand-card p-6 sm:p-8">
      <p className="eyebrow mb-2">{eyebrow}</p>
      <h2 className="font-display text-2xl sm:text-3xl font-extrabold leading-tight text-brand-ink">
        {title}
      </h2>
      <p className="mt-2 text-brand-mute max-w-2xl">{body}</p>
      {cta && (
        <a href={cta.href} className="btn-primary mt-4 inline-flex text-xs h-9 px-4 items-center">
          {cta.label}
        </a>
      )}
    </header>
  );
}

function HelpCard(): JSX.Element {
  return (
    <section className="rounded-2xl border border-brand-line bg-brand-card p-6">
      <h2 className="text-2xl font-extrabold mb-1">Need help?</h2>
      <p className="text-brand-mute text-sm mb-4">
        AI concierge — 24/7. Booking changes, refunds, scope tweaks, all in one tap.
      </p>
      <ul className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-sm">
        <HelpRow href={PHONE_TEL_HREF} label="(855) 82LABOR" />
        <HelpRow href={PHONE_SMS_HREF} label="Text us" />
        <HelpRow href="mailto:hello@bricklabor.com" label="hello@bricklabor.com" />
      </ul>
    </section>
  );
}

function HelpRow({ href, label }: { href: string; label: string }): ReactNode {
  return (
    <li>
      <a
        href={href}
        className="block rounded-md border border-brand-line bg-brand-bg/40 px-3 py-2 text-brand-ink hover:border-brand-accent underline-hover"
      >
        {label}
      </a>
    </li>
  );
}
