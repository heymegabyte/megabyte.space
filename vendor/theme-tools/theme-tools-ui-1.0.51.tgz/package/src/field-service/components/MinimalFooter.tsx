import { useThemeToolsSurface } from '../../field-service-primitives.js';
import type { JSX } from 'react';
import { PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';

/**
 * MinimalFooter — terse single-row footer for auth, checkout, dashboard, and
 * tracking surfaces where the giant marketing footer (5-column site nav grid +
 * newsletter signup) would be noise. Spec: company name + © + Privacy · Terms
 * · Status · Support + small build/version indicator. Brand tokens, minimal
 * padding, dark-first.
 */
export function MinimalFooter(): JSX.Element {
  useThemeToolsSurface('minimal-footer');
  const year = new Date().getFullYear();
  const buildTag =
    typeof window !== 'undefined' && (window as { __BCL_BUILD__?: string }).__BCL_BUILD__
      ? (window as { __BCL_BUILD__?: string }).__BCL_BUILD__
      : 'live';
  return (
    <footer
      data-minimal-footer
      className="border-t border-brand-line bg-bg-primary/60 backdrop-blur-sm"
    >
      <div className="container-pad py-6">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-xs text-brand-mute">
            <span className="font-semibold text-brand-ink">Brick Labor</span>
            <span aria-hidden> · </span>© {year} ·{' '}
            <a
              href={PHONE_TEL_HREF}
              className="text-brand-mute underline-hover hover:text-brand-accent"
              data-bcl-phone-cta="minimal-footer"
            >
              (855) 82LABOR
            </a>
          </p>
          <nav
            aria-label="Legal and support"
            className="flex flex-wrap items-center gap-3 text-xs text-brand-mute"
          >
            <a href="/privacy" className="underline-hover hover:text-brand-ink">
              Privacy
            </a>
            <span aria-hidden className="text-brand-line">
              ·
            </span>
            <a href="/terms" className="underline-hover hover:text-brand-ink">
              Terms
            </a>
            <span aria-hidden className="text-brand-line">
              ·
            </span>
            <a href="/status" className="underline-hover hover:text-brand-ink">
              Status
            </a>
            <span aria-hidden className="text-brand-line">
              ·
            </span>
            <a href="mailto:hey@bricklabor.com" className="underline-hover hover:text-brand-ink">
              Support
            </a>
            <span
              aria-label="Build identifier"
              className="ml-1 rounded-full border border-brand-line bg-bg-elevated/60 px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider text-brand-mute/80"
            >
              {buildTag}
            </span>
          </nav>
        </div>
      </div>
    </footer>
  );
}
