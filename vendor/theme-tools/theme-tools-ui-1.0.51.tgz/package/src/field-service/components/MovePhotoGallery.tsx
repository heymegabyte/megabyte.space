import { useThemeToolsSurface } from '../../field-service-primitives.js';
/**
 * MovePhotoGallery.tsx — Wave 27 #15 real before/after gallery.
 *
 * Fetches consented, approved move photos via `/api/move-photos?neighborhood=
 * &service=` and renders a responsive thumbnail grid with native-lazy AVIF
 * (with WebP/JPEG fallback inferred by file extension). Tapping a thumbnail
 * opens an inline lightbox overlay (no external dep).
 *
 * The lightbox is a real ARIA APG modal dialog: it follows the shared dialog
 * a11y kit (`use-dialog-a11y.ts`) — focus moves INTO the panel on open, returns
 * to the thumbnail trigger on close, Tab/Shift+Tab stay trapped inside, and body
 * scroll locks while it covers the viewport (axe-core is blind to every one of
 * those interaction gaps). Dismissal (Esc, backdrop, close button) plays the
 * shared A7 backdrop-fade + panel-slide exit via `use-modal-motion.ts` before
 * unmounting; ←/→ swap the photo instantly without dismissing. All motion is
 * reduced-motion gated by the shared CSS. Extend-don't-duplicate: the same hooks
 * power the chat panel, mobile nav drawer, and surge modal.
 *
 * Gated by `move_photo_gallery`. Default-off ⇒ component returns null
 * until the flag resolves true AND the API responds with ≥1 photo. Empty-list
 * also renders null so we never ship a "No photos yet" placeholder on top of
 * production marketing surfaces.
 */

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useFeatureFlag } from '../use-feature-flag.js';
import { useBodyScrollLock, useFocusManagement, useTabTrap } from '../use-dialog-a11y.js';
import { MODAL_BACKDROP_CLASS, MODAL_PANEL_CLASS, useModalMotion } from '../use-modal-motion.js';

interface Photo {
  id: string;
  neighborhood: string | null;
  service: string | null;
  variant: string;
  photo_url: string;
  alt: string;
  taken_at: string;
}

interface Props {
  neighborhood?: string;
  service?: string;
  limit?: number;
  heading?: string;
}

function pictureSources(url: string): { avif: string; webp: string; fallback: string } {
  const dot = url.lastIndexOf('.');
  const base = dot > 0 ? url.slice(0, dot) : url;
  return {
    avif: `${base}.avif`,
    webp: `${base}.webp`,
    fallback: url,
  };
}

export function MovePhotoGallery({
  neighborhood,
  service,
  limit = 24,
  heading = 'Real moves we just finished',
}: Props): JSX.Element | null {
  useThemeToolsSurface('move-photo-gallery');
  const enabled = useFeatureFlag('move_photo_gallery');
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [openIdx, setOpenIdx] = useState<number | null>(null);
  const panelRef = useRef<HTMLDivElement | null>(null);
  const lastFocusRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!enabled) return;
    let cancelled = false;
    const controller = new AbortController();
    const params = new URLSearchParams();
    if (neighborhood) params.set('neighborhood', neighborhood);
    if (service) params.set('service', service);
    params.set('limit', String(limit));
    void (async () => {
      try {
        const r = await fetch(`/api/move-photos?${params}`, {
          credentials: 'same-origin',
          signal: controller.signal,
        });
        if (!r.ok) return;
        const j = (await r.json()) as { ok: boolean; photos?: Photo[] };
        if (!cancelled && j.ok && Array.isArray(j.photos)) setPhotos(j.photos);
      } catch {
        /* swallow — gallery is best-effort */
      }
    })();
    return () => {
      cancelled = true;
      controller.abort();
    };
  }, [enabled, neighborhood, service, limit]);

  const isOpen = openIdx != null;
  const close = useCallback(() => setOpenIdx(null), []);
  // Animated dismissal — plays the shared exit keyframe, then unmounts (close).
  const { closing, requestClose } = useModalMotion(close);
  const prev = useCallback(
    () => setOpenIdx((i) => (i == null ? null : (i - 1 + photos.length) % photos.length)),
    [photos.length],
  );
  const next = useCallback(
    () => setOpenIdx((i) => (i == null ? null : (i + 1) % photos.length)),
    [photos.length],
  );

  // Shared dialog a11y kit (axe-blind interaction patterns):
  // focus into the panel on open + restore to the trigger on close, body-scroll
  // lock while the full-screen lightbox is up, and a Tab trap on the overlay.
  useFocusManagement(isOpen, panelRef, lastFocusRef);
  useBodyScrollLock(isOpen, 99999);
  const onTabKeyDown = useTabTrap(panelRef);

  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') requestClose();
      else if (e.key === 'ArrowLeft') prev();
      else if (e.key === 'ArrowRight') next();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isOpen, requestClose, prev, next]);

  const open = useMemo(() => (openIdx == null ? null : photos[openIdx]), [openIdx, photos]);

  if (!enabled) return null;
  if (photos.length === 0) return null;

  return (
    <section aria-label={heading} className="my-8" data-testid="move-photo-gallery">
      <h2 className="mb-4 text-xl font-semibold">{heading}</h2>
      <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
        {photos.map((p, idx) => {
          const src = pictureSources(p.photo_url);
          return (
            <li key={p.id}>
              <button
                type="button"
                onClick={() => setOpenIdx(idx)}
                aria-label={`Open photo: ${p.alt}`}
                className="block min-h-[44px] w-full overflow-hidden rounded-xl ring-1 ring-white/10 transition-transform duration-[333ms] hover:-translate-y-0.5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-accent"
              >
                <picture>
                  <source srcSet={src.avif} type="image/avif" />
                  <source srcSet={src.webp} type="image/webp" />
                  <img
                    src={src.fallback}
                    alt={p.alt}
                    loading="lazy"
                    decoding="async"
                    className="aspect-square h-auto w-full object-cover"
                  />
                </picture>
              </button>
            </li>
          );
        })}
      </ul>

      {open ? (
        <div
          ref={panelRef}
          role="dialog"
          aria-modal="true"
          aria-label={open.alt}
          data-closing={closing ? 'true' : undefined}
          onKeyDown={onTabKeyDown}
          className={`${MODAL_BACKDROP_CLASS} fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4`}
          onClick={requestClose}
        >
          <button
            type="button"
            aria-label="Previous photo"
            onClick={(e) => {
              e.stopPropagation();
              prev();
            }}
            className="absolute left-4 top-1/2 min-h-[44px] min-w-[44px] -translate-y-1/2 rounded-full bg-white/10 text-2xl text-white transition-[transform,background-color] duration-[333ms] hover:scale-105 hover:bg-white/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
          >
            ‹
          </button>
          <picture
            data-closing={closing ? 'true' : undefined}
            className={MODAL_PANEL_CLASS}
            onClick={(e) => e.stopPropagation()}
          >
            <source srcSet={pictureSources(open.photo_url).avif} type="image/avif" />
            <source srcSet={pictureSources(open.photo_url).webp} type="image/webp" />
            <img
              src={open.photo_url}
              alt={open.alt}
              className="max-h-[85vh] max-w-[95vw] rounded-xl object-contain"
            />
          </picture>
          <button
            type="button"
            aria-label="Next photo"
            onClick={(e) => {
              e.stopPropagation();
              next();
            }}
            className="absolute right-4 top-1/2 min-h-[44px] min-w-[44px] -translate-y-1/2 rounded-full bg-white/10 text-2xl text-white transition-[transform,background-color] duration-[333ms] hover:scale-105 hover:bg-white/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
          >
            ›
          </button>
          <button
            type="button"
            aria-label="Close gallery"
            onClick={(e) => {
              e.stopPropagation();
              requestClose();
            }}
            className="absolute right-4 top-4 min-h-[44px] min-w-[44px] rounded-full bg-white/10 text-2xl text-white transition-[transform,background-color] duration-[333ms] hover:scale-105 hover:bg-white/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
          >
            ×
          </button>
        </div>
      ) : null}
    </section>
  );
}
