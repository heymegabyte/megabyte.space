import { useThemeToolsSurface } from '../../field-service-primitives.js';
/**
 * NeighborReferralPage.tsx — Tier-S idea #4 auto-generated `/by/:slug`
 * landing page.
 *
 * Renders a personalized hero with the referrer's display name + city + a
 * prominent "$25 off your first move" CTA that deep-links the booking form
 * with the referral code pre-filled. Posts a 1× view-track event to the
 * worker on mount (worker handles dedupe).
 *
 * Flag-gated server-side; the page falls back to a "not found" rendering
 * when the slug returns 404 from the API.
 */
import { useEffect, useState } from 'react';
import { track } from '../analytics.js';

interface LandingPayload {
  ok: true;
  slug: string;
  code: string;
  displayName: string;
  city: string;
  viewCount: number;
}

interface Props {
  slug: string;
}

function cityToDisplay(city: string): string {
  return city
    .split('-')
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');
}

export function NeighborReferralPage({ slug }: Props): JSX.Element {
  useThemeToolsSurface('neighbor-referral-page');
  const [state, setState] = useState<
    { kind: 'loading' } | { kind: 'ready'; data: LandingPayload } | { kind: 'not_found' }
  >({ kind: 'loading' });

  useEffect(() => {
    const prev = document.title;
    document.title = 'Neighbor Referral — $25 Off Your First Move · Brick Labor';
    return () => {
      document.title = prev;
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const r = await fetch(`/api/neighbor-referrals/by/${encodeURIComponent(slug)}`);
        if (cancelled) return;
        if (!r.ok) {
          setState({ kind: 'not_found' });
          return;
        }
        const data = (await r.json()) as LandingPayload;
        if (!data.ok) {
          setState({ kind: 'not_found' });
          return;
        }
        setState({ kind: 'ready', data });
        // Refine title when we know the referrer name.
        document.title = `${data.displayName} Recommends Brick Labor in ${cityToDisplay(data.city)}`;
        // Fire-and-forget view track (worker dedupes 24h per visitor hash).
        void fetch(`/api/neighbor-referrals/track/${encodeURIComponent(slug)}`, {
          method: 'POST',
        });
        track('neighbor_referral_landing_view', {
          slug,
          city: data.city,
          code: data.code,
        });
      } catch {
        if (!cancelled) setState({ kind: 'not_found' });
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [slug]);

  if (state.kind === 'loading') {
    return (
      <main className="container-pad max-w-3xl py-16">
        <div className="rounded-2xl border border-brand-line bg-bg-elevated p-8">
          <div className="h-8 w-3/4 animate-pulse rounded bg-brand-line" />
          <div className="mt-4 h-4 w-1/2 animate-pulse rounded bg-brand-line" />
        </div>
      </main>
    );
  }

  if (state.kind === 'not_found') {
    return (
      <main className="container-pad max-w-3xl py-16">
        <div className="rounded-2xl border border-brand-line bg-bg-elevated p-8">
          <h1 className="font-display text-3xl font-extrabold text-brand-ink">Link not found.</h1>
          <p className="mt-2 text-brand-mute">
            That referral link doesn&apos;t resolve to an active offer right now. You can still grab
            the regular{' '}
            <a className="text-brand-accent underline" href="/book">
              first-job pricing
            </a>{' '}
            with no code needed.
          </p>
        </div>
      </main>
    );
  }

  const { displayName, city, code } = state.data;
  const cityLabel = cityToDisplay(city);
  const bookUrl = `/book?ref=${encodeURIComponent(code)}&utm_source=neighbor-referral&utm_medium=share&utm_campaign=${encodeURIComponent(slug)}`;

  return (
    <main
      data-testid="neighbor-referral-page"
      data-bcl-surface="neighbor-referral-landing"
      data-bcl-slug={slug}
      data-bcl-city={city}
    >
      <section className="container-pad max-w-4xl py-12 sm:py-16">
        <div className="rounded-3xl border border-brand-line bg-gradient-to-br from-brand-accent/10 to-transparent p-6 sm:p-10">
          <p className="eyebrow mb-3">{cityLabel} · Neighbor referral</p>
          <h1 className="font-display text-3xl font-extrabold leading-tight text-brand-ink sm:text-5xl">
            {displayName} thinks you should hire{' '}
            <span className="text-brand-accent">Brick Labor</span>.
          </h1>
          <p className="mt-4 max-w-2xl text-lg text-brand-mute leading-relaxed">
            Use their code <span className="font-mono text-brand-accent">{code}</span> and get{' '}
            <span className="font-extrabold text-brand-ink">$25 off</span> your first Brick Labor
            job in {cityLabel}. Same crew, same flat rate, same no-surprise pricing — just with a
            hand from a neighbor.
          </p>
          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <a
              href={bookUrl}
              data-bcl-action="neighbor_book_click"
              data-bcl-slug={slug}
              data-bcl-code={code}
              className="inline-flex min-h-[52px] items-center justify-center rounded-lg bg-brand-accent px-6 py-3 text-base font-extrabold text-bg-primary"
            >
              Book now — code applied →
            </a>
            <a
              href="#how-it-works"
              className="inline-flex min-h-[52px] items-center justify-center rounded-lg border border-brand-line bg-bg-elevated px-6 py-3 text-base font-bold text-brand-ink"
            >
              How it works
            </a>
          </div>
        </div>

        <section id="how-it-works" className="mt-12 grid gap-6 sm:grid-cols-3">
          <article className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
            <p className="font-mono text-xs uppercase tracking-widest text-brand-accent">Step 1</p>
            <h2 className="mt-2 font-display text-xl font-extrabold">Pick a date + crew size</h2>
            <p className="mt-2 text-sm text-brand-mute">
              Tell us the day, the address, and how big the job is. Flat $50/hr per person. Newark,
              Jersey City, Hoboken, all of NJ + NYC boroughs.
            </p>
          </article>
          <article className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
            <p className="font-mono text-xs uppercase tracking-widest text-brand-accent">Step 2</p>
            <h2 className="mt-2 font-display text-xl font-extrabold">Code auto-applies</h2>
            <p className="mt-2 text-sm text-brand-mute">
              When you click through from this page, {displayName}&apos;s code{' '}
              <span className="font-mono">{code}</span> is on your booking. $25 comes off your first
              job total automatically.
            </p>
          </article>
          <article className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
            <p className="font-mono text-xs uppercase tracking-widest text-brand-accent">Step 3</p>
            <h2 className="mt-2 font-display text-xl font-extrabold">Crew shows up, job done</h2>
            <p className="mt-2 text-sm text-brand-mute">
              Real local crew. Live ETA, post-job photos, and a $25 thank-you credit
              lands on {displayName}&apos;s account when your move completes.
            </p>
          </article>
        </section>

        <section className="mt-12 rounded-2xl border border-brand-line bg-bg-elevated p-5">
          <h2 className="font-display text-2xl font-extrabold">Why {cityLabel} books with us</h2>
          <ul className="mt-3 grid gap-2 text-sm text-brand-mute sm:grid-cols-2">
            <li className="flex items-start gap-2">
              <span className="text-brand-accent" aria-hidden>
                ✓
              </span>{' '}
              Flat <strong className="text-brand-ink">$50/hr per person</strong> — no hidden truck
              fee, no fuel surcharge, no "moving day premium".
            </li>
            <li className="flex items-start gap-2">
              <span className="text-brand-accent" aria-hidden>
                ✓
              </span>{' '}
              Same crew quality whether you&apos;re moving a studio or a 4-bedroom.
            </li>
            <li className="flex items-start gap-2">
              <span className="text-brand-accent" aria-hidden>
                ✓
              </span>{' '}
              Owner-run Newark crew, every job photo-documented with a 24-hour
              dispute window — see our{' '}
              <a className="text-brand-accent" href="/sources">
                sources page
              </a>
              .
            </li>
            <li className="flex items-start gap-2">
              <span className="text-brand-accent" aria-hidden>
                ✓
              </span>{' '}
              Honest cancellation: free up to 24h before, 50% inside 24h. That&apos;s it.
            </li>
          </ul>
        </section>

        <p className="mt-10 text-center text-sm text-brand-mute">
          New here?{' '}
          <a className="text-brand-accent underline" href="/c/{city}">
            See our {cityLabel} page
          </a>{' '}
          for hyperlocal pricing + crew profiles.
        </p>
      </section>
    </main>
  );
}
