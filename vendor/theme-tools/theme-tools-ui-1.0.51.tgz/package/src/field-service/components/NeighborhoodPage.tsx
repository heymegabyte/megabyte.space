import { useEffect, useMemo } from 'react';
import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { evaluateCurbAndParkingClearance } from '@theme.tools/scheduling/field-service/theme-tools-field-service-bridge';
import {
  findNeighborhood,
  getAllNeighborhoodsByCity,
  type NeighborhoodDef,
} from '../data/neighborhoods.js';
import { getCityBySlug, type City } from '../data/cities.js';
import { cityImageSrc } from '../data/city-images.js';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { neighborhoodPageCopy, fillNb } from '@theme.tools/i18n-a11y/field-service/neighborhood-page-copy';
import { Booking } from './Booking.js';
import { PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';

interface Props {
  citySlug: string;
  nbSlug: string;
}

/**
 * SPA hydration target for /c/<city>/<neighborhood> routes. The static HTML
 * is prerendered by scripts/build-neighborhood-pages.mjs — this component
 * takes over on client navigation. Visual + meta stay consistent.
 *
 * The template CHROME (breadcrumb, hero eyebrow + CTAs, section headers, the
 * three bundle cards) renders per-locale from `neighborhood-page-copy` so a
 * `/es` or `/pt` neighborhood visitor reads it in-language; the per-neighborhood
 * factual prose (H1, lede, job notes, FAQ, street + landmark lists) stays
 * English, sourced from the `neighborhoods` data module.
 */
export function NeighborhoodPage({ citySlug, nbSlug }: Props) {
  const city: City | undefined = useMemo(() => getCityBySlug(citySlug), [citySlug]);
  const nb: NeighborhoodDef | undefined = useMemo(
    () => findNeighborhood(citySlug, nbSlug),
    [citySlug, nbSlug],
  );

  // SSR/prerender is locale-stamped per route; on the client we read the URL so
  // a /es or /pt neighborhood page renders its chrome in-language after hydration.
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const copy = neighborhoodPageCopy(locale);
  /** Keep a /es|/pt visitor inside their locale when clicking internal links. */
  const lp = (path: string): string => localizedPath(locale, path);

  useEffect(() => {
    if (!nb || !city) return;
    // Per-neighborhood title/description are primary-sourced English SEO data —
    // intentionally not translated this pass; only the canonical is locale-aware.
    document.title = nb.title;
    setMeta('description', nb.description);
    setLink(
      'canonical',
      `https://bricklabor.com${localizedPath(
        stripLocalePrefix(window.location.pathname).locale,
        `/c/${citySlug}/${nbSlug}`,
      )}`,
    );
  }, [city, nb, citySlug, nbSlug]);

  if (!city || !nb) return <NotFound copy={copy} backHomeHref={lp('/')} />;

  const heroSrc = cityImageSrc(citySlug);
  const surfaceProps = useThemeToolsSurface(`neighborhood-${citySlug}-${nbSlug}`, [
    '@theme.tools/ui',
    '@theme.tools/scheduling',
    '@theme.tools/seo-geo',
  ]);
  const curbEvaluation = evaluateCurbAndParkingClearance({
    categorySlug: 'moving-labor',
    cityOrMunicipality: city.name,
  });
  /** Common interpolation vars for `fillNb` across this render. */
  const v = { nb: nb.name, city: city.name, state: city.state };
  const f = (tpl: string): string => fillNb(tpl, v);

  return (
    <>
      <section
        className="relative overflow-hidden"
        data-theme-tools-surface={surfaceProps['data-theme-tools-surface']}
        data-theme-tools-pricing-model={surfaceProps['data-theme-tools-pricing-model']}
        data-curb-permit-lead-hours={curbEvaluation.permitLeadTimeHours}
      >
        <div className="absolute inset-0 pointer-events-none" aria-hidden>
          <img
            src={heroSrc}
            alt=""
            loading="eager"
            decoding="async"
            fetchPriority="high"
            className="absolute inset-0 h-full w-full object-cover opacity-25"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-bg-base via-bg-base/85 to-bg-base" />
          <div
            className="absolute -top-40 -right-40 h-[500px] w-[500px] rounded-full bg-brand-accent/15 blur-3xl animate-pulse-slow"
            aria-hidden
          />
        </div>
        <div className="container-pad relative pt-16 pb-20 sm:pt-24 sm:pb-28">
          <nav aria-label="Breadcrumb" className="mb-6 text-sm text-brand-mute">
            <a href={lp('/')} className="underline-hover">
              {copy.crumbHome}
            </a>
            <span className="mx-2">/</span>
            <a href={lp(`/c/${citySlug}`)} className="underline-hover">
              {city.name}, {city.state}
            </a>
            <span className="mx-2">/</span>
            <span className="text-brand-ink">{nb.name}</span>
          </nav>
          <p className="eyebrow mb-5">{f(copy.eyebrow)}</p>
          <h1 className="text-4xl sm:text-6xl font-extrabold leading-[1.04] max-w-4xl">{nb.h1}</h1>
          <p className="mt-6 text-lg sm:text-xl text-brand-mute max-w-3xl leading-relaxed">
            {nb.lede}
          </p>
          <div className="mt-9 flex flex-col sm:flex-row gap-3">
            <a
              href={lp(
                `/book?nb=${encodeURIComponent(nb.name)}&city=${encodeURIComponent(city.name)}`,
              )}
              className="btn-primary text-base"
            >
              {f(copy.ctaBookCrew)}
            </a>
            <a href={PHONE_TEL_HREF} className="btn-ghost text-base">
              {copy.ctaCall}
            </a>
          </div>
        </div>
      </section>

      <section className="section-tight">
        <div className="container-pad grid lg:grid-cols-[1.4fr_1fr] gap-10 lg:gap-14 items-start">
          <div>
            <p className="eyebrow mb-3">{copy.jobsEyebrow}</p>
            <h2 className="text-3xl sm:text-4xl font-extrabold mb-5">
              {f(copy.jobsHead1)} <span className="text-gradient">{copy.jobsHead2}</span>
            </h2>
            <p className="text-lg text-brand-mute leading-relaxed">{nb.jobsParagraph}</p>
            <p className="mt-5 text-base text-brand-mute leading-relaxed">{nb.homeStock}</p>
            <p className="mt-5 font-mono text-sm text-brand-mute border-l-2 border-brand-accent pl-4">
              {nb.access}
            </p>
          </div>
          <aside className="rounded-2xl border border-brand-line bg-bg-elevated p-6">
            <p className="eyebrow mb-4">{f(copy.topCallsLabel)}</p>
            <ul className="space-y-2.5">
              {nb.jobs.map((j) => (
                <li key={j} className="flex items-start gap-2.5 text-sm">
                  <span
                    aria-hidden
                    className="mt-1 inline-block h-1.5 w-1.5 flex-none rounded-full bg-brand-accent"
                  />
                  <span className="text-brand-ink">{j}</span>
                </li>
              ))}
            </ul>
            <div className="mt-5 border-t border-brand-line pt-4">
              <p className="font-mono text-xs text-brand-mute mb-2">{copy.landmarksLabel}</p>
              <ul aria-label={copy.landmarksLabel} className="flex flex-wrap gap-1.5">
                {nb.landmarks.map((lm, i) => (
                  <li
                    key={lm}
                    style={{ animationDelay: `${i * 50}ms` }}
                    className="rounded-full border border-brand-line bg-bg-elevated px-2.5 py-0.5 font-mono text-xs text-brand-mute transition-all duration-[333ms] hover:-translate-y-0.5 hover:border-brand-accent hover:text-brand-ink"
                  >
                    {lm}
                  </li>
                ))}
              </ul>
            </div>
          </aside>
        </div>
      </section>

      <section className="section-tight">
        <div className="container-pad">
          <p className="eyebrow mb-3">{f(copy.corridorsEyebrow)}</p>
          <h2 className="text-3xl sm:text-4xl font-extrabold mb-6 max-w-3xl">
            {copy.corridorsHead1} <span className="text-gradient">{copy.corridorsHead2}</span>
          </h2>
          <ul className="flex flex-wrap gap-2 text-sm">
            {nb.streets.map((s) => (
              <li
                key={s}
                className="inline-flex min-h-[24px] items-center rounded-full border border-brand-line bg-bg-elevated px-3 py-1.5 transition-all duration-[333ms] hover:-translate-y-0.5 hover:border-brand-accent text-brand-mute"
              >
                {s}
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="section-tight">
        <div className="container-pad max-w-4xl">
          <p className="eyebrow mb-3">{f(copy.bundlesEyebrow)}</p>
          <h2 className="text-3xl sm:text-4xl font-extrabold mb-7">
            {copy.bundlesHead1} <span className="text-gradient">{copy.bundlesHead2}</span>
          </h2>
          <div className="grid sm:grid-cols-3 gap-4">
            <BundleCard
              name={copy.bundles['spring-rinse'].name}
              price="$299"
              desc={copy.bundles['spring-rinse'].desc}
              bookLabel={fillNb(copy.bundleBook, { name: copy.bundles['spring-rinse'].name })}
              ctaHref={lp(`/book?nb=${encodeURIComponent(nb.name)}&bundle=spring-rinse`)}
            />
            <BundleCard
              name={copy.bundles['move-out'].name}
              price="$549"
              desc={copy.bundles['move-out'].desc}
              bookLabel={fillNb(copy.bundleBook, { name: copy.bundles['move-out'].name })}
              ctaHref={lp(`/book?nb=${encodeURIComponent(nb.name)}&bundle=move-out`)}
            />
            <BundleCard
              name={copy.bundles.storm.name}
              price="$749"
              desc={copy.bundles.storm.desc}
              bookLabel={fillNb(copy.bundleBook, { name: copy.bundles.storm.name })}
              ctaHref={lp(`/book?nb=${encodeURIComponent(nb.name)}&bundle=storm`)}
            />
          </div>
        </div>
      </section>

      <section className="section-tight">
        <div className="container-pad max-w-4xl">
          <p className="eyebrow mb-3">{f(copy.questionsEyebrow)}</p>
          <h2 className="text-3xl sm:text-4xl font-extrabold mb-7">
            {f(copy.questionsHead1)} <span className="text-gradient">{copy.questionsHead2}</span>
          </h2>
          <div className="space-y-3">
            {nb.faq.map((fq) => (
              <details
                key={fq.q}
                className="group rounded-2xl border border-brand-line bg-bg-elevated px-5 py-4"
              >
                <summary className="cursor-pointer list-none font-display text-lg font-bold flex items-center justify-between gap-4">
                  {fq.q}
                  <span
                    aria-hidden
                    className="ml-auto text-brand-accent transition-transform group-open:rotate-45"
                  >
                    ＋
                  </span>
                </summary>
                <p className="mt-3 text-brand-mute leading-relaxed">{fq.a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className="section-tight">
        <div className="container-pad">
          <h2 className="text-3xl font-extrabold mb-6">{f(copy.otherNbHead)}</h2>
          <NearbyNeighborhoods citySlug={citySlug} currentSlug={nbSlug} lp={lp} />
          <p className="mt-6 text-sm">
            <a href={lp(`/c/${citySlug}`)} className="underline-hover hover:text-brand-accent">
              {f(copy.backToCity)}
            </a>
          </p>
        </div>
      </section>

      <Booking />
    </>
  );
}

function BundleCard({
  name,
  price,
  desc,
  bookLabel,
  ctaHref,
}: {
  name: string;
  price: string;
  desc: string;
  bookLabel: string;
  ctaHref: string;
}) {
  return (
    <div className="rounded-2xl border border-brand-line bg-bg-elevated p-5 flex flex-col">
      <div className="flex items-baseline justify-between">
        <span className="font-display text-xl font-bold">{name}</span>
        <span className="font-mono text-2xl text-brand-accent font-bold">{price}</span>
      </div>
      <p className="mt-3 text-sm text-brand-mute leading-relaxed flex-1">{desc}</p>
      <a href={ctaHref} className="btn-primary text-sm mt-5 self-start">
        {bookLabel}
      </a>
    </div>
  );
}

function NearbyNeighborhoods({
  citySlug,
  currentSlug,
  lp,
}: {
  citySlug: string;
  currentSlug: string;
  lp: (path: string) => string;
}) {
  const siblings = useMemo(() => {
    const c = getAllNeighborhoodsByCity().find((x) => x.citySlug === citySlug);
    if (!c) return [];
    return c.neighborhoods.filter((n) => n.slug !== currentSlug);
  }, [citySlug, currentSlug]);

  if (siblings.length === 0) return null;

  return (
    <ul className="flex flex-wrap gap-2 text-sm">
      {siblings.map((n) => (
        <li key={n.slug}>
          <a
            href={lp(`/c/${citySlug}/${n.slug}`)}
            className="inline-flex min-h-[24px] items-center rounded-full border border-brand-line bg-bg-elevated px-3 py-1.5 transition-all duration-[333ms] hover:-translate-y-0.5 hover:border-brand-accent text-brand-mute underline-hover hover:text-brand-accent"
          >
            {n.name} →
          </a>
        </li>
      ))}
    </ul>
  );
}

function setMeta(name: string, content: string) {
  let m = document.querySelector(`meta[name="${name}"]`);
  if (!m) {
    m = document.createElement('meta');
    m.setAttribute('name', name);
    document.head.appendChild(m);
  }
  m.setAttribute('content', content);
}

function setLink(rel: string, href: string) {
  let l = document.querySelector(`link[rel="${rel}"]`);
  if (!l) {
    l = document.createElement('link');
    l.setAttribute('rel', rel);
    document.head.appendChild(l);
  }
  l.setAttribute('href', href);
}

function NotFound({
  copy,
  backHomeHref,
}: {
  copy: ReturnType<typeof neighborhoodPageCopy>;
  backHomeHref: string;
}) {
  return (
    <section className="section-tight">
      <div className="container-pad max-w-3xl">
        <h1 className="text-3xl font-extrabold">{copy.notFoundHead}</h1>
        <p className="mt-4 text-brand-mute">{copy.notFoundBody}</p>
        <p className="mt-6 text-sm">
          <a href={backHomeHref} className="underline-hover hover:text-brand-accent">
            {copy.backHome}
          </a>
        </p>
      </div>
    </section>
  );
}
