import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect, useState } from 'react';
import { suggestClosestRoute, POPULAR_FALLBACK_ROUTES } from '@theme.tools/seo-geo/field-service/route-suggest';

/**
 * Recovery-first 404 page (idea #17).
 *
 * Two layers of "did you mean?":
 *  1. INSTANT, offline — a deterministic Levenshtein match against the real route
 *     set (`suggestClosestRoute`) renders the moment the page mounts, with zero
 *     network. A mistyped `/servies` recovers to `/services` immediately even
 *     when the AI surface is slow, down, or out of budget.
 *  2. ENRICHED — `/api/ai/404-suggest` then refines the guess + adds alternates
 *     when it answers. If it never answers, layer 1 (or the curated popular-pages
 *     fallback) still gives the visitor a way out.
 */

type Suggestion = {
  topGuess: string;
  alternates: string[];
  explanation: string;
};

export function NotFound404() {
  useThemeToolsSurface('not-found404');
  const [path, setPath] = useState('');
  const [sug, setSug] = useState<Suggestion | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const p = typeof window !== 'undefined' ? window.location.pathname : '';
    setPath(p);
    if (!p || p === '/') return;

    // Layer 1 — instant deterministic guess, no network.
    const local = suggestClosestRoute(p);
    if (local) {
      setSug({
        topGuess: local,
        alternates: [],
        explanation: 'Closest match to what you typed.',
      });
    }

    // Layer 2 — enrich with the AI suggester when (if) it answers.
    setLoading(true);
    void (async () => {
      try {
        const res = await fetch('/api/ai/404-suggest', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ brokenPath: p }),
        });
        const json = (await res.json()) as { ok: boolean; suggestion?: Suggestion };
        if (json.ok && json.suggestion?.topGuess) setSug(json.suggestion);
      } catch {
        /* silent — layer 1 / popular-pages fallback already covers it */
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  // Cap the echoed path so a pathological URL (e.g. a 500-char path) can't blow the layout.
  const shownPath = path.length > 80 ? `${path.slice(0, 80)}…` : path;

  return (
    <main className="bg-bg-primary min-h-screen pb-24">
      <section className="mx-auto max-w-2xl px-4 pt-16">
        <p className="mb-3 font-mono text-[11px] uppercase tracking-[0.18em] text-brand-accent">
          404
        </p>
        <h1 className="mb-3 text-3xl font-bold leading-tight text-brand-ink sm:text-4xl">
          That page isn't here.
        </h1>
        <p className="mb-8 text-brand-mute">
          You tried{' '}
          <code className="rounded bg-bg-elevated px-1.5 py-0.5 text-sm" title={path}>
            {shownPath}
          </code>{' '}
          but no route matches. Best guess below.
        </p>

        {sug ? (
          <div className="space-y-4" aria-live="polite">
            <a
              href={sug.topGuess}
              data-bcl-action="404_top_guess"
              className="block rounded-2xl border border-brand-accent bg-brand-accent/10 p-5 transition-[border-color,box-shadow] duration-[0.333s] hover:shadow-[0_0_0_1px_var(--brand-accent)]"
            >
              <p className="font-mono text-[10px] uppercase tracking-widest text-brand-accent">
                Take me to
              </p>
              <p className="mt-1 text-xl font-bold text-brand-ink">{sug.topGuess}</p>
              <p className="mt-2 text-sm text-brand-mute">{sug.explanation}</p>
            </a>
            {sug.alternates.length > 0 && (
              <div className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
                <p className="mb-3 font-mono text-[10px] uppercase tracking-widest text-brand-mute">
                  Or maybe
                </p>
                <ul className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                  {sug.alternates.map((p) => (
                    <li key={p}>
                      <a
                        href={p}
                        className="block rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink transition-colors duration-[0.333s] hover:border-brand-accent"
                      >
                        {p}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ) : loading ? (
          <div className="space-y-4" aria-live="polite" aria-busy="true">
            <div className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
              <p className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
                Finding the right page…
              </p>
              <div className="mt-3 h-5 w-2/3 animate-pulse rounded bg-brand-line motion-reduce:animate-none" />
              <div className="mt-2 h-4 w-full animate-pulse rounded bg-brand-line motion-reduce:animate-none" />
            </div>
          </div>
        ) : (
          // No near-miss + no AI answer — never a dead end. Offer the pages a lost visitor most likely wanted.
          <div className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
            <p className="mb-3 font-mono text-[10px] uppercase tracking-widest text-brand-mute">
              Popular pages
            </p>
            <ul className="grid grid-cols-2 gap-2">
              {POPULAR_FALLBACK_ROUTES.map((r) => (
                <li key={r.href}>
                  <a
                    href={r.href}
                    data-bcl-action="404_popular"
                    className="block rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm font-semibold text-brand-ink transition-colors duration-[0.333s] hover:border-brand-accent"
                  >
                    {r.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        )}

        <a
          href="/"
          className="mt-6 inline-flex items-center rounded-md border border-brand-line px-4 py-3 text-sm font-semibold text-brand-ink transition-colors duration-[0.333s] hover:border-brand-accent"
        >
          Take me home →
        </a>
      </section>
    </main>
  );
}
