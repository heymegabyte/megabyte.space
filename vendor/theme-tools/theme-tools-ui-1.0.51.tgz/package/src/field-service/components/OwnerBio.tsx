import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { EeatStrip, JsonLd, personBrian } from './seo/index.js';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { ownerBioCopy } from '@theme.tools/i18n-a11y/field-service/owner-bio-copy';
import { PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';

const REVIEWED = '2026-05-19';

export function OwnerBio() {
  useThemeToolsSurface('owner-bio');
  // SSR/prerender is locale-stamped per route; on the client we read the URL so
  // the `/es` + `/pt` mirrors render in-language post-hydration. EN default.
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const copy = ownerBioCopy(locale);
  const { bio1, bio2, eeat } = copy;
  // Keep a mirror-locale visitor in /es · /pt: localize internal `/` hrefs
  // (incl. `/#pricing` homepage anchors); leave tel:/external bare.
  const lp = (path: string) => (path.startsWith('/') ? localizedPath(locale, path) : path);

  return (
    <section id="about" aria-label="About Brick Labor" className="section">
      <div className="container-pad">
        <div className="grid md:grid-cols-[1fr,2fr] gap-10 items-center max-w-5xl mx-auto">
          <figure
            className="relative aspect-square rounded-2xl border border-brand-line bg-bg-elevated overflow-hidden"
            data-animate="scale-in"
          >
            <img
              src="/cities/newark.jpg"
              alt="Newark, New Jersey skyline — home base for Brick Labor"
              loading="lazy"
              decoding="async"
              width={1200}
              height={1200}
              className="absolute inset-0 h-full w-full object-cover"
            />
            <div
              aria-hidden
              className="absolute inset-0 bg-gradient-to-t from-bg-primary/85 via-bg-primary/30 to-transparent"
            />
            <figcaption className="absolute bottom-0 left-0 right-0 p-5">
              <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-brand-accent">
                {copy.homeBaseEyebrow}
              </span>
              <span className="block font-display text-xl font-extrabold text-brand-ink mt-1">
                {copy.homeBaseCity}
              </span>
            </figcaption>
          </figure>

          <div data-animate="slide-left" data-delay="120">
            <p className="eyebrow mb-3">{copy.eyebrow}</p>
            <h2 className="text-4xl font-extrabold mb-4">
              {copy.titlePre}
              <span className="text-gradient">{copy.titleAccent}</span>
            </h2>
            <p className="text-brand-mute leading-relaxed mb-4">
              {bio1.pre}
              <a href={lp('/c/newark')} className="text-brand-accent underline-hover">
                {bio1.newarkLink}
              </a>
              {bio1.midA}
              <a href={lp('/#coverage')} className="text-brand-accent underline-hover">
                {bio1.njLink}
              </a>
              {bio1.midB}
              <a href={lp('/services/power-washing')} className="text-brand-accent underline-hover">
                {bio1.powerWashLink}
              </a>
              {bio1.midC}
              <a href={lp('/services/lawn-care')} className="text-brand-accent underline-hover">
                {bio1.lawnLink}
              </a>
              {bio1.midD}
              <a href={lp('/services/hauling')} className="text-brand-accent underline-hover">
                {bio1.haulLink}
              </a>
              {bio1.midE}
              <a href={lp('/services/light-repairs')} className="text-brand-accent underline-hover">
                {bio1.repairsLink}
              </a>
              {bio1.midF}
              <a href={lp('/#pricing')} className="text-brand-accent underline-hover">
                {bio1.priceLink}
              </a>
              {bio1.midG}
              <a href={lp('/c/hoboken')} className="text-brand-accent underline-hover">
                {bio1.hobokenLink}
              </a>
              {bio1.post}
            </p>
            <p className="text-brand-mute leading-relaxed mb-6">
              {bio2.pre}
              <strong className="text-brand-ink">{bio2.name}</strong>
              {bio2.midA}
              <a
                href={lp('/blog/fifty-dollar-hour-per-person-philosophy')}
                className="text-brand-accent underline-hover"
              >
                {bio2.priceFlatLink}
              </a>
              {bio2.midB}
              <a
                href={lp('/blog/casual-labor-vs-licensed-contractor')}
                className="text-brand-accent underline-hover"
              >
                {bio2.casualLink}
              </a>
              {bio2.midC}
              <a href={lp('/blog')} className="text-brand-accent underline-hover">
                {bio2.blogLink}
              </a>
              {bio2.midD}
              <a href={lp('/#testimonials')} className="text-brand-accent underline-hover">
                {bio2.neighborsLink}
              </a>
              {bio2.post}
            </p>

            <ul className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              {copy.cards.map((card) => (
                <li key={card.value} className="rounded-lg border border-brand-line px-3 py-2">
                  <div className="font-mono text-brand-accent">{card.value}</div>
                  <div className="text-brand-mute">{card.sub}</div>
                </li>
              ))}
            </ul>

            <div className="mt-6 flex flex-wrap gap-3">
              <a href={PHONE_TEL_HREF} className="btn-primary">
                {copy.ctaCall}
              </a>
              <a href={lp('/book')} className="btn-ghost">
                {copy.ctaBook}
              </a>
              <a href={lp('/#contact')} className="btn-ghost">
                {copy.ctaQuote}
              </a>
              <a href={lp('/work')} className="btn-ghost">
                {copy.ctaWork}
              </a>
            </div>
            <p className="mt-5 text-xs font-mono text-brand-mute leading-relaxed">
              <span className="text-brand-ink">{eeat.ownerLabel}</span>{' '}
              <a
                href="https://linkedin.com/in/brianzalewski"
                target="_blank"
                rel="noopener noreferrer"
                className="text-brand-accent underline-hover"
              >
                Brian Zalewski
              </a>{' '}
              · <span data-eeat="usdot">{eeat.usdot}</span> · <span data-eeat="mc">{eeat.mc}</span>
              {eeat.regInsured}
              <time dateTime={REVIEWED}>{REVIEWED}</time>.
            </p>
            <p className="mt-4 text-xs text-brand-mute">
              {copy.topCitiesLabel}{' '}
              <a href={lp('/c/newark')} className="text-brand-accent underline-hover">
                Newark
              </a>{' '}
              ·{' '}
              <a href={lp('/c/jersey-city')} className="text-brand-accent underline-hover">
                Jersey City
              </a>{' '}
              ·{' '}
              <a href={lp('/c/paterson')} className="text-brand-accent underline-hover">
                Paterson
              </a>{' '}
              ·{' '}
              <a href={lp('/c/elizabeth')} className="text-brand-accent underline-hover">
                Elizabeth
              </a>{' '}
              ·{' '}
              <a href={lp('/c/east-orange')} className="text-brand-accent underline-hover">
                East Orange
              </a>{' '}
              ·{' '}
              <a href={lp('/c/irvington')} className="text-brand-accent underline-hover">
                Irvington
              </a>{' '}
              ·{' '}
              <a href={lp('/c/bloomfield')} className="text-brand-accent underline-hover">
                Bloomfield
              </a>
              .
            </p>
          </div>
        </div>
      </div>
      <EeatStrip variant="home" />
      <JsonLd data={personBrian()} />
    </section>
  );
}
