import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect, useState } from 'react';
import { JsonLd } from './seo/index.js';
import { TurnstileWidget } from './TurnstileWidget.js';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { partnerLandingCopy } from '@theme.tools/i18n-a11y/field-service/partner-landing-copy';
import { PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';

interface SignupState {
  status: 'idle' | 'submitting' | 'ok' | 'error';
  message?: string;
  shortLink?: string | null;
}

/**
 * /partners — pitch + signup form for property managers, apartment
 * complexes, and resident-services teams. We promise $50/confirmed move and
 * an emailed Dub short link they can share in lease packets or resident
 * portals.
 *
 * Form posts JSON to /api/partners/signup. The worker handles email + Dub
 * link generation; this component renders the confirmation state inline so
 * we don't bounce the user away from their entry point.
 *
 * Localized for /es + /pt: reads the locale from the path prefix, renders copy
 * from `partner-landing-copy`, and routes every internal href through
 * `localizedPath` so a mirror-locale visitor stays in their locale. The
 * locale-invariant tokens ($50/$0, (855) 82LABOR, hey@bricklabor.com, the
 * Newark/Jersey City/Hoboken anchors, Dub/Stripe Connect/ACH/1099/IRS) stay
 * verbatim.
 */
export function PartnerLanding(): JSX.Element {
  useThemeToolsSurface('partner-landing');
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const copy = partnerLandingCopy(locale);
  const lp = (path: string): string => localizedPath(locale, path);

  useEffect(() => {
    const code = stripLocalePrefix(window.location.pathname).locale;
    const c = partnerLandingCopy(code);
    const canonical = `https://bricklabor.com${localizedPath(code, '/partners')}`;
    document.title = c.metaTitle;
    setMeta('description', c.metaDescription);
    setLink('canonical', canonical);
    setMeta('robots', 'index,follow', 'name');
    setMeta('og:title', c.metaTitle, 'property');
    setMeta('og:description', c.metaDescription, 'property');
    setMeta('og:url', canonical, 'property');
  }, []);

  const [state, setState] = useState<SignupState>({ status: 'idle' });
  const [turnstileToken, setTurnstileToken] = useState('');

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);
    const unitCountRaw = String(fd.get('unitCount') || '').trim();
    const payload = {
      name: String(fd.get('name') || '').trim(),
      contactEmail: String(fd.get('contactEmail') || '').trim(),
      companyName: String(fd.get('companyName') || '').trim(),
      unitCount: unitCountRaw ? Number(unitCountRaw) : undefined,
      notes: String(fd.get('notes') || '').trim(),
      source: 'partners' as const,
      turnstileToken,
    };
    setState({ status: 'submitting' });
    try {
      const res = await fetch('/api/partners/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = (await res.json()) as {
        ok: boolean;
        message?: string;
        error?: string;
        shortLink?: string | null;
      };
      if (res.ok && data.ok) {
        setState({
          status: 'ok',
          message: data.message ?? copy.okMsg,
          shortLink: data.shortLink ?? null,
        });
        form.reset();
      } else {
        setState({
          status: 'error',
          message: data.error || data.message || copy.errMsg,
        });
      }
    } catch (err) {
      // Error tracked via Sentry
      setState({ status: 'error', message: copy.networkErrMsg });
    }
  }

  const steps = [copy.steps.signup, copy.steps.link, copy.steps.book, copy.steps.paid];

  return (
    <article className="section">
      <div className="container-pad max-w-5xl">
        <p className="eyebrow mb-3">{copy.eyebrow}</p>
        <h1 className="text-4xl sm:text-5xl font-extrabold">
          {copy.h1Pre}
          <span className="text-brand-accent">{copy.h1Accent}</span>
          {copy.h1Post}
        </h1>
        <p className="mt-4 text-lg text-brand-mute max-w-2xl">{copy.lede}</p>

        <div className="mt-10 grid lg:grid-cols-2 gap-10">
          <section>
            <h2 className="text-2xl font-extrabold mb-3">{copy.howHead}</h2>
            <ol className="space-y-3 text-brand-mute leading-relaxed">
              {steps.map((s) => (
                <li key={s.label}>
                  <strong className="text-brand-ink">{s.label}</strong> {s.body}
                </li>
              ))}
            </ol>

            <h2 className="text-2xl font-extrabold mt-10 mb-3">{copy.leaseHead}</h2>
            <p className="text-brand-mute leading-relaxed">
              {copy.leaseBodyPre}
              <a href={lp('/property-managers')} className="text-brand-accent underline-hover">
                {copy.leaseLink}
              </a>
              {copy.leaseBodyPost}
            </p>

            <h2 className="text-2xl font-extrabold mt-10 mb-3">{copy.whoHead}</h2>
            <ul className="space-y-2 text-brand-mute">
              <li>
                {copy.audience.complexesPre}
                <a href={lp('/c/newark')} className="text-brand-accent underline-hover">
                  Newark
                </a>
                {copy.audience.complexesMid1}
                <a href={lp('/c/jersey-city')} className="text-brand-accent underline-hover">
                  Jersey City
                </a>
                {copy.audience.complexesMid2}
                <a href={lp('/c/hoboken')} className="text-brand-accent underline-hover">
                  Hoboken
                </a>
                {copy.audience.complexesSuffix}
              </li>
              <li>{copy.audience.managers}</li>
              <li>{copy.audience.hoas}</li>
              <li>{copy.audience.realtors}</li>
            </ul>

            <p className="mt-8 text-sm text-brand-mute">
              {copy.questionsPre}
              <a
                href="mailto:hey@bricklabor.com?subject=Partner%20program"
                className="text-brand-accent underline-hover"
              >
                hey@bricklabor.com
              </a>
              {copy.questionsMid}
              <a href={PHONE_TEL_HREF} className="text-brand-accent underline-hover">
                (855) 82LABOR
              </a>
              {copy.questionsPost}
            </p>
          </section>

          <form onSubmit={onSubmit} className="card space-y-4" aria-label={copy.formAria}>
            <h2 className="text-xl font-extrabold">{copy.formHead}</h2>
            <p className="text-sm text-brand-mute">{copy.formIntro}</p>

            <div>
              <label className="label" htmlFor="pl-name">
                {copy.labelName}
              </label>
              <input
                id="pl-name"
                name="name"
                required
                autoComplete="name"
                className="input"
                minLength={2}
                maxLength={120}
              />
            </div>

            <div>
              <label className="label" htmlFor="pl-email">
                {copy.labelEmail}
              </label>
              <input
                id="pl-email"
                name="contactEmail"
                type="email"
                required
                autoComplete="email"
                className="input"
                maxLength={160}
              />
            </div>

            <div>
              <label className="label" htmlFor="pl-company">
                {copy.labelCompany}
              </label>
              <input
                id="pl-company"
                name="companyName"
                autoComplete="organization"
                className="input"
                maxLength={160}
                placeholder={copy.companyPlaceholder}
              />
            </div>

            <div>
              <label className="label" htmlFor="pl-units">
                {copy.labelUnits}
              </label>
              <input
                id="pl-units"
                name="unitCount"
                type="number"
                min={0}
                max={100000}
                className="input"
                placeholder={copy.unitsPlaceholder}
              />
            </div>

            <div>
              <label className="label" htmlFor="pl-notes">
                {copy.labelNotes}
              </label>
              <textarea
                id="pl-notes"
                name="notes"
                rows={3}
                maxLength={1000}
                className="input resize-y"
                placeholder={copy.notesPlaceholder}
              />
            </div>

            <TurnstileWidget onToken={setTurnstileToken} action="partner-signup" />

            <button
              type="submit"
              disabled={state.status === 'submitting'}
              className="btn-primary w-full"
            >
              {state.status === 'submitting' ? copy.submitting : copy.submitIdle}
            </button>

            {state.status === 'ok' && (
              <div
                role="status"
                className="rounded-lg border border-brand-ok/40 bg-brand-ok/10 p-3 text-sm text-brand-ok"
              >
                <p>{state.message}</p>
                {state.shortLink && (
                  <p className="mt-2 break-all">
                    {copy.linkLabel}{' '}
                    <a href={state.shortLink} className="underline">
                      {state.shortLink}
                    </a>
                  </p>
                )}
              </div>
            )}
            {state.status === 'error' && (
              <div
                role="alert"
                className="rounded-lg border border-brand-err/40 bg-brand-err/10 p-3 text-sm text-brand-err"
              >
                {state.message}
              </div>
            )}

            <p className="border-t border-brand-line pt-3 text-[11px] leading-relaxed text-brand-mute">
              {copy.termsPre}
              <a href={lp('/terms')} className="text-brand-accent underline-hover">
                {copy.termsLink}
              </a>
              {copy.termsMid}
              <a href={lp('/privacy')} className="text-brand-accent underline-hover">
                {copy.privacyLink}
              </a>
              {copy.termsPost}
            </p>
          </form>
        </div>
      </div>

      <JsonLd
        data={{
          '@context': 'https://schema.org',
          '@type': 'WebPage',
          '@id': `https://bricklabor.com${localizedPath(locale, '/partners')}`,
          url: `https://bricklabor.com${localizedPath(locale, '/partners')}`,
          name: copy.metaTitle,
          description: copy.metaDescription,
          isPartOf: { '@id': 'https://bricklabor.com/#website' },
          about: {
            '@type': 'Service',
            name: 'Brick Labor Partner Program',
            provider: { '@id': 'https://bricklabor.com/#org' },
            areaServed: 'Newark, NJ',
          },
        }}
      />
    </article>
  );
}

function setMeta(name: string, content: string, attr: 'name' | 'property' = 'name') {
  let el = document.querySelector<HTMLMetaElement>(`meta[${attr}="${name}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function setLink(rel: string, href: string) {
  let el = document.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', rel);
    document.head.appendChild(el);
  }
  el.setAttribute('href', href);
}
