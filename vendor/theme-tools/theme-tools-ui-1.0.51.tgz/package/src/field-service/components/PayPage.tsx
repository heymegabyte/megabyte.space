/**
 * PayPage — /pay
 *
 * Transparent pricing for both sides of the marketplace:
 *  - What customers pay (hourly rate + recurring discounts)
 *  - What crew earns (hourly wage + mileage + bonuses)
 *  - How the referral model works (affiliate-profit-share feature)
 *  - A transparent $100k/year scenario (honest math, not a guarantee)
 */
import { useEffect } from 'react';
import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';

const PRICING_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1, cadence: 'one-time' });

/** Canonical rate and block size — mirrors src/shared/ constants */
const HOURLY_RATE = PRICING_STANDARD.hourlyRatePerPersonCents / 100; // dollars per crew member per hour
const QUARTER_HOUR_RATE = PRICING_STANDARD.quarterHourIncrementCents / 100; // ~$12.50 per 15-min block
const MILEAGE_RATE = 0.3; // dollars per mile reimbursement
const AFFILIATE_PCT = 5; // % revenue share on referred bookings

interface RecurringRow {
  label: string;
  cadence: string;
  discount: number; // percent
  description: string;
}

const RECURRING_ROWS: RecurringRow[] = [
  {
    label: 'Daily',
    cadence: 'daily',
    discount: 12,
    description: 'Same crew every day — best for ongoing property work',
  },
  {
    label: 'Weekly',
    cadence: 'weekly',
    discount: 8,
    description: 'Once a week — lawn, cleanouts, light hauling',
  },
  {
    label: 'Biweekly',
    cadence: 'biweekly',
    discount: 5,
    description: 'Every other week — maintenance cadence',
  },
  {
    label: 'Monthly',
    cadence: 'monthly',
    discount: 3,
    description: 'Once a month — seasonal help',
  },
];

function fmt$(n: number, decimals = 0): string {
  return n.toLocaleString('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

/** ── Customer Rate Section ───────────────────────────────────────────── */
function CustomerRateSection(): JSX.Element {
  const surfaceProps = useThemeToolsSurface('pay-page', [
    '@theme.tools/ui',
    '@theme.tools/billing',
  ]);
  return (
    <section
      data-testid="customer-rate-section"
      data-theme-tools-surface={surfaceProps['data-theme-tools-surface']}
      data-theme-tools-pricing-model={surfaceProps['data-theme-tools-pricing-model']}
      data-theme-tools-packages={surfaceProps['data-theme-tools-packages']}
      className="rounded-2xl border border-brand-line/40 bg-bg-elevated/60 p-6 sm:p-8"
    >
      <h2 className="mb-1 text-2xl font-bold tracking-tight text-brand-ink">What you pay</h2>
      <p className="mb-6 text-brand-ink/70">
        Simple hourly rate. No hidden fees. No tipping required.
      </p>

      {/* Hero rate display */}
      <div className="mb-6 flex flex-col items-start gap-2 sm:flex-row sm:items-end sm:gap-4">
        <div className="flex items-baseline gap-1">
          <span className="text-5xl font-black text-brand-cyan tabular-nums">
            {fmt$(HOURLY_RATE)}
          </span>
          <span className="text-lg font-semibold text-brand-ink/60">/ hour per crew member</span>
        </div>
      </div>

      {/* Key billing facts */}
      <ul className="mb-6 space-y-3 text-brand-ink/80">
        <li className="flex items-start gap-3">
          <span className="mt-0.5 flex-shrink-0 text-brand-cyan">✓</span>
          <span>
            <strong className="text-brand-ink">1-hour minimum</strong> — every job starts with at
            least one full hour per crew member.
          </span>
        </li>
        <li className="flex items-start gap-3">
          <span className="mt-0.5 flex-shrink-0 text-brand-cyan">✓</span>
          <span>
            <strong className="text-brand-ink">15-minute billing blocks</strong> after the first
            hour — {fmt$(QUARTER_HOUR_RATE, 2)} per block per person. You only pay for time worked.
          </span>
        </li>
        <li className="flex items-start gap-3">
          <span className="mt-0.5 flex-shrink-0 text-brand-cyan">✓</span>
          <span>
            <strong className="text-brand-ink">Scale the crew size</strong> to match the job. Two
            crew members at 2 hours = {fmt$(HOURLY_RATE * 2 * 2)}.
          </span>
        </li>
        <li className="flex items-start gap-3">
          <span className="mt-0.5 flex-shrink-0 text-brand-cyan">✓</span>
          <span>
            Surge pricing may apply on same-day, next-day, and weekend bookings. Your quote locks in
            the rate before you confirm.
          </span>
        </li>
      </ul>

      {/* Example scenarios */}
      <div className="grid gap-3 sm:grid-cols-2">
        {[
          { label: 'Light move (1 person, 2 hrs)', total: 100 },
          { label: 'Standard move (2 people, 3 hrs)', total: 300 },
          { label: 'Big cleanout (3 people, 4 hrs)', total: 600 },
          { label: 'Yard work (2 people, 1 hr 30 min)', total: 150 },
        ].map(({ label, total }) => (
          <div
            key={label}
            className="flex items-center justify-between rounded-xl border border-brand-line/30 bg-brand-bg/60 px-4 py-3"
          >
            <span className="text-sm text-brand-ink/80">{label}</span>
            <span className="font-bold text-brand-cyan">{fmt$(total)}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

/** ── Recurring Discounts Section ─────────────────────────────────────── */
function RecurringDiscountsSection(): JSX.Element {
  return (
    <section
      data-testid="recurring-discounts-section"
      className="rounded-2xl border border-brand-line/40 bg-bg-elevated/60 p-6 sm:p-8"
    >
      <h2 className="mb-1 text-2xl font-bold tracking-tight text-brand-ink">
        Recurring contracts save you money
      </h2>
      <p className="mb-6 text-brand-ink/70">
        Lock in a standing crew schedule and get a discount on every booking. Cancel or pause
        anytime — no contracts to sign.
      </p>

      <div className="grid gap-3 sm:grid-cols-2">
        {RECURRING_ROWS.map(({ label, cadence, discount, description }) => (
          <div
            key={cadence}
            className="group relative overflow-hidden rounded-xl border border-brand-line/30 bg-brand-bg/50 p-4 transition-all duration-300 hover:-translate-y-0.5 hover:border-brand-cyan/40 hover:shadow-lg hover:shadow-brand-cyan/10"
          >
            <div className="mb-1 flex items-center justify-between">
              <span className="font-semibold text-brand-ink">{label}</span>
              <span className="rounded-full bg-brand-cyan/15 px-2.5 py-0.5 text-sm font-bold text-brand-cyan">
                {discount}% off
              </span>
            </div>
            <p className="text-sm text-brand-ink/60">{description}</p>
            <div className="mt-2 text-xs text-brand-ink/40">
              Effective rate: {fmt$(HOURLY_RATE * (1 - discount / 100), 2)}/hr per person
            </div>
          </div>
        ))}
      </div>

      <p className="mt-4 text-xs text-brand-ink/40">
        Discounts apply to the base hourly rate. Surge pricing, if active, is calculated before the
        recurring discount is applied.
      </p>
    </section>
  );
}

/** ── Crew Earnings Section ───────────────────────────────────────────── */
function CrewEarningsSection(): JSX.Element {
  return (
    <section
      data-testid="crew-earnings-section"
      className="rounded-2xl border border-brand-line/40 bg-bg-elevated/60 p-6 sm:p-8"
    >
      {/* Eyebrow */}
      <p className="mb-1 text-xs font-semibold uppercase tracking-widest text-brand-cyan">
        For crew members
      </p>
      <h2 className="mb-1 text-2xl font-bold tracking-tight text-brand-ink">What you earn</h2>
      <p className="mb-6 text-brand-ink/70">
        Real pay for real work. Every hour, every mile, every completed job.
      </p>

      {/* Base pay + mileage */}
      <div className="mb-6 grid gap-4 sm:grid-cols-2">
        <div className="rounded-xl border border-brand-line/30 bg-brand-bg/50 p-4">
          <p className="mb-0.5 text-xs uppercase tracking-wider text-brand-ink/50">Base Pay</p>
          <p className="text-3xl font-black text-brand-cyan tabular-nums">
            {fmt$(HOURLY_RATE)}
            <span className="text-lg font-semibold text-brand-ink/60">/hr</span>
          </p>
          <p className="mt-1 text-sm text-brand-ink/60">Per crew member, per hour worked</p>
        </div>
        <div className="rounded-xl border border-brand-line/30 bg-brand-bg/50 p-4">
          <p className="mb-0.5 text-xs uppercase tracking-wider text-brand-ink/50">Mileage</p>
          <p className="text-3xl font-black text-brand-cyan tabular-nums">
            {fmt$(MILEAGE_RATE, 2)}
            <span className="text-lg font-semibold text-brand-ink/60">/mi</span>
          </p>
          <p className="mt-1 text-sm text-brand-ink/60">
            Reimbursed for every mile driven to the job
          </p>
        </div>
      </div>

      {/* Additional earnings */}
      <ul className="space-y-3 text-brand-ink/80">
        <li className="flex items-start gap-3">
          <span className="mt-0.5 flex-shrink-0 text-brand-cyan">+</span>
          <span>
            <strong className="text-brand-ink">Rush bonus</strong> — same-day jobs earn extra when
            you accept on short notice.
          </span>
        </li>
        <li className="flex items-start gap-3">
          <span className="mt-0.5 flex-shrink-0 text-brand-cyan">+</span>
          <span>
            <strong className="text-brand-ink">Shift-lead bonus</strong> — lead your crew and earn
            more per hour on multi-member jobs.
          </span>
        </li>
        <li className="flex items-start gap-3">
          <span className="mt-0.5 flex-shrink-0 text-brand-cyan">+</span>
          <span>
            <strong className="text-brand-ink">Tips pass through 100%</strong> — every dollar a
            customer tips goes directly to you.
          </span>
        </li>
        <li className="flex items-start gap-3">
          <span className="mt-0.5 flex-shrink-0 text-brand-cyan">+</span>
          <span>
            <strong className="text-brand-ink">Quality payout multiplier</strong> — 5-star reviews,
            on-time arrivals, and zero claims can earn 1.10× on qualifying jobs (feature in beta).
          </span>
        </li>
      </ul>
    </section>
  );
}

/** ── Referral Section ────────────────────────────────────────────────── */
function ReferralSection(): JSX.Element {
  return (
    <section
      data-testid="referral-section"
      className="rounded-2xl border border-brand-cyan/20 bg-brand-cyan/5 p-6 sm:p-8"
    >
      <p className="mb-1 text-xs font-semibold uppercase tracking-widest text-brand-cyan">
        Referral program
      </p>
      <h2 className="mb-1 text-2xl font-bold tracking-tight text-brand-ink">
        Earn by growing the network
      </h2>
      <p className="mb-6 text-brand-ink/70">
        Every customer and crew member gets a personal referral link. When someone books through
        your link, you earn — automatically.
      </p>

      {/* How it works */}
      <div className="mb-6 grid gap-4 sm:grid-cols-2">
        <div className="rounded-xl border border-brand-line/30 bg-brand-bg/60 p-4">
          <p className="mb-2 font-semibold text-brand-ink">Customer referrals</p>
          <p className="mb-1 text-sm text-brand-ink/70">
            Share your booking link. When an eligible referred booking is paid, its profit share
            appears in your dashboard ledger.
          </p>
          <p className="mt-2 rounded-lg bg-brand-cyan/10 px-3 py-2 text-sm font-bold text-brand-cyan">
            {AFFILIATE_PCT}% of paid referred-job revenue
          </p>
          <p className="mt-1 text-xs text-brand-ink/40">
            The separate neighbor-credit program may also apply under its own terms.
          </p>
        </div>
        <div className="rounded-xl border border-brand-line/30 bg-brand-bg/60 p-4">
          <p className="mb-2 font-semibold text-brand-ink">Crew affiliate links</p>
          <p className="mb-1 text-sm text-brand-ink/70">
            Crew members can share the same kind of booking link and track eligible referred-job
            earnings from the Earnings dashboard.
          </p>
          <p className="mt-2 rounded-lg bg-brand-cyan/10 px-3 py-2 text-sm font-bold text-brand-cyan">
            {AFFILIATE_PCT}% of paid referred-job revenue
          </p>
          <p className="mt-1 text-xs text-brand-ink/40">
            Accrued amounts require operator approval before payout.
          </p>
        </div>
      </div>

      {/* How it works steps */}
      <ol className="space-y-2 text-sm text-brand-ink/70">
        <li className="flex gap-3">
          <span className="flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-full bg-brand-cyan/20 text-xs font-bold text-brand-cyan">
            1
          </span>
          <span>Get your personal link from your dashboard or ask a dispatcher.</span>
        </li>
        <li className="flex gap-3">
          <span className="flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-full bg-brand-cyan/20 text-xs font-bold text-brand-cyan">
            2
          </span>
          <span>Share it by text, social, or word of mouth.</span>
        </li>
        <li className="flex gap-3">
          <span className="flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-full bg-brand-cyan/20 text-xs font-bold text-brand-cyan">
            3
          </span>
          <span>
            Earnings accrue automatically when a booking completes and Square payment clears.
          </span>
        </li>
      </ol>

      <p className="mt-4 rounded-lg border border-brand-line/30 bg-brand-bg/50 px-4 py-3 text-xs text-brand-ink/50">
        <strong className="text-brand-ink/70">Limited beta.</strong> Ask your dispatcher to activate
        your referral link. Affiliate earnings remain accrued until approved and paid by the
        operator.
      </p>
    </section>
  );
}

/** ── $100k Scenario Section ──────────────────────────────────────────── */
function EarningsScenarioSection(): JSX.Element {
  // Transparent assumptions for the scenario
  const hoursPerWeek = 40;
  const weeksPerYear = 50;
  const annualHourlyBase = HOURLY_RATE * hoursPerWeek * weeksPerYear; // $100k

  // Affiliate scenario: three referral sources collectively driving the stated
  // annual paid booking revenue. Profit share is booking attribution, never a
  // percentage of another crew member's wages.
  const referralSources = 3;
  const avgAnnualReferredJobRevenue = 50_000;
  const annualOverride = referralSources * avgAnnualReferredJobRevenue * (AFFILIATE_PCT / 100);

  const annualTotal = annualHourlyBase + annualOverride;

  return (
    <section
      data-testid="earnings-scenario-section"
      className="rounded-2xl border border-brand-line/40 bg-bg-elevated/60 p-6 sm:p-8"
    >
      <p className="mb-1 text-xs font-semibold uppercase tracking-widest text-brand-cyan">
        Transparent math
      </p>
      <h2 className="mb-1 text-2xl font-bold tracking-tight text-brand-ink">
        Can you reach $100,000 / year?
      </h2>
      <p className="mb-2 text-brand-ink/70">
        Yes — with consistent full-time hours and a modest referral network. Here is exactly how the
        math works. These are illustrative assumptions, not earnings guarantees.
      </p>

      {/* Assumption callout */}
      <div className="mb-6 rounded-xl border border-amber-500/20 bg-amber-500/5 px-4 py-3 text-sm text-amber-400/90">
        <strong className="text-amber-300">Assumptions in this scenario:</strong> {hoursPerWeek}{' '}
        hours/week × {weeksPerYear} weeks/year at base {fmt$(HOURLY_RATE)}/hr, plus{' '}
        {referralSources} referral sources each driving ~{fmt$(avgAnnualReferredJobRevenue)}/yr in
        paid jobs. Actual results depend on job availability, your market, and how many people you
        bring in.
      </div>

      {/* Math breakdown */}
      <div className="mb-4 overflow-hidden rounded-xl border border-brand-line/30">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-brand-line/30 bg-brand-bg/60">
              <th className="px-4 py-2.5 text-left font-semibold text-brand-ink/80">
                Income source
              </th>
              <th className="px-4 py-2.5 text-right font-semibold text-brand-ink/80">
                Calculation
              </th>
              <th className="px-4 py-2.5 text-right font-semibold text-brand-ink/80">Annual</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b border-brand-line/20">
              <td className="px-4 py-3 text-brand-ink/80">Hourly labor</td>
              <td className="px-4 py-3 text-right text-brand-ink/60">
                {fmt$(HOURLY_RATE)}/hr × {hoursPerWeek} hr/wk × {weeksPerYear} wk
              </td>
              <td className="px-4 py-3 text-right font-bold text-brand-cyan">
                {fmt$(annualHourlyBase)}
              </td>
            </tr>
            <tr className="border-b border-brand-line/20">
              <td className="px-4 py-3 text-brand-ink/80">
                Paid referred-job share
                <span className="ml-1 text-xs text-brand-ink/40">
                  ({referralSources} sources × {fmt$(avgAnnualReferredJobRevenue)} ea. ×{' '}
                  {AFFILIATE_PCT}%)
                </span>
              </td>
              <td className="px-4 py-3 text-right text-brand-ink/60">
                {referralSources} × {fmt$(avgAnnualReferredJobRevenue)} × {AFFILIATE_PCT / 100}
              </td>
              <td className="px-4 py-3 text-right font-bold text-brand-cyan">
                {fmt$(annualOverride)}
              </td>
            </tr>
            <tr className="bg-brand-cyan/5">
              <td className="px-4 py-3 font-bold text-brand-ink">Total (scenario)</td>
              <td className="px-4 py-3 text-right text-brand-ink/50">—</td>
              <td className="px-4 py-3 text-right text-2xl font-black text-brand-cyan">
                {fmt$(annualTotal)}
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Reality check */}
      <div className="space-y-2 text-sm text-brand-ink/60">
        <p>
          <strong className="text-brand-ink">What this requires:</strong> consistent availability,
          showing up on time, maintaining 5-star reviews, and actively referring customers who
          complete paid jobs.
        </p>
        <p>
          <strong className="text-brand-ink">What it does not require:</strong> special equipment, a
          vehicle larger than a standard car (for most jobs), or any out-of-pocket investment.
        </p>
        <p>
          <strong className="text-brand-ink">Not a guarantee.</strong> Actual earnings depend on job
          availability in your area, your hours worked, and whether you activate the referral
          program. Mileage, rush bonuses, and tips can increase your total above the scenario shown.
        </p>
      </div>
    </section>
  );
}

/** ── Main export ─────────────────────────────────────────────────────── */
export function PayPage(): JSX.Element {
  useEffect(() => {
    const prev = document.title;
    document.title = 'Transparent Pricing — Brick Labor Newark NJ';
    return () => {
      document.title = prev;
    };
  }, []);

  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
      {/* Page header */}
      <header className="mb-10 text-center">
        <p className="mb-2 text-xs font-semibold uppercase tracking-widest text-brand-cyan">
          No surprises
        </p>
        <h1 className="mb-3 text-4xl font-black tracking-tight text-brand-ink sm:text-5xl">
          Transparent Pricing
        </h1>
        <p className="mx-auto max-w-xl text-lg text-brand-ink/70">
          {fmt$(HOURLY_RATE)}/hour per crew member. Recurring discounts. Crew earns the same rate.
          Every number on this page is real.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <a
            href="/book"
            className="rounded-full bg-brand-cyan px-6 py-2.5 font-bold text-brand-bg transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg hover:shadow-brand-cyan/30"
          >
            Book now
          </a>
          <a
            href="/apply"
            className="rounded-full border border-brand-cyan/40 px-6 py-2.5 font-semibold text-brand-cyan transition-all duration-300 hover:border-brand-cyan hover:bg-brand-cyan/10"
          >
            Join the crew
          </a>
        </div>
      </header>

      {/* Two-column grid on md+ */}
      <div className="space-y-6">
        {/* Customer pricing */}
        <CustomerRateSection />

        {/* Recurring contracts */}
        <RecurringDiscountsSection />

        {/* Crew earnings */}
        <CrewEarningsSection />

        {/* Referral program */}
        <ReferralSection />

        {/* $100k scenario */}
        <EarningsScenarioSection />

        {/* Bottom CTA */}
        <div className="rounded-2xl border border-brand-cyan/20 bg-brand-cyan/5 p-6 text-center sm:p-8">
          <h2 className="mb-2 text-xl font-bold text-brand-ink">Ready to get started?</h2>
          <p className="mb-5 text-brand-ink/70">
            Book labor for your next project or apply to join the crew today.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <a
              href="/book"
              className="rounded-full bg-brand-cyan px-6 py-2.5 font-bold text-brand-bg transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg hover:shadow-brand-cyan/30"
            >
              Book labor
            </a>
            <a
              href="/apply"
              className="rounded-full border border-brand-cyan/40 px-6 py-2.5 font-semibold text-brand-cyan transition-all duration-300 hover:border-brand-cyan hover:bg-brand-cyan/10"
            >
              Apply to crew
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
