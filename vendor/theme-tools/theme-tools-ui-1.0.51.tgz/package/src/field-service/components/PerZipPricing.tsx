import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { useEffect, useState } from 'react';

// One-line stat on city pages: "Average 2-mover-4hr move in 11215: $412,
// last 30 days, 23 jobs". Hits GET /api/pricing-zip?zip=<currentZip>. If the
// sample size is <10 we hide the widget entirely — confidence threshold.

interface PricingZipResponse {
  ok: boolean;
  zip: string;
  avgCents: number;
  count: number;
  windowDays: number;
}

export interface PerZipPricingProps {
  zip: string;
  // Optional label override — defaults to "2-mover, 4 hr job".
  jobLabel?: string;
  // Minimum sample size for display. Match the server HAVING clause (10).
  minCount?: number;
}

function formatUsd(cents: number): string {
  const dollars = cents / 100;
  return dollars.toLocaleString('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  });
}

export function PerZipPricing(props: PerZipPricingProps) {
  useThemeToolsSurface('per-zip-pricing');
  const { zip, jobLabel = '2-mover, 4 hr job', minCount = 10 } = props;
  const [data, setData] = useState<PricingZipResponse | null>(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    if (!zip) return;
    let cancelled = false;
    fetch(`/api/pricing-zip?zip=${encodeURIComponent(zip)}`)
      .then((res) => (res.ok ? (res.json() as Promise<PricingZipResponse>) : null))
      .then((body) => {
        if (cancelled) return;
        if (!body || !body.ok) {
          setError(true);
          return;
        }
        setData(body);
      })
      .catch(() => {
        if (!cancelled) setError(true);
      });
    return () => {
      cancelled = true;
    };
  }, [zip]);

  if (error || !data) return null;
  if (data.count < minCount) return null;

  return (
    <p
      className="inline-flex flex-wrap items-baseline gap-x-2 gap-y-1 rounded-full border border-brand-line bg-bg-elevated/40 px-4 py-1.5 text-xs text-brand-mute"
      data-testid="per-zip-pricing"
    >
      <span className="font-mono text-brand-accent">{data.zip}</span>
      <span>{jobLabel} avg:</span>
      <strong className="text-brand-ink">{formatUsd(data.avgCents)}</strong>
      <span>
        · last {data.windowDays} days · {data.count} jobs
      </span>
    </p>
  );
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
