import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect, useRef, useState } from 'react';
import { localizedPath, stripLocalePrefix, type LocaleCode } from '@theme.tools/i18n-a11y/field-service/locale';
import { calculateCategoryScope } from '@theme.tools/scheduling/field-service/category-calculators';
import { normalizeToCanonicalSlug } from '@theme.tools/seo-geo/field-service/service-slug-aliases';

/**
 * Standalone "snap a photo → rough quote" page (Tier 1 #3 surface).
 *
 * Lives at `/estimate`. Posts to `/api/ai/photo-estimate` with the image
 * base64 + a service-hint enum covering all 9 canonical Brick Labor
 * services. Renders the AI estimate as a card; if AI is unavailable or the
 * feature flag is off, gracefully computes a deterministic scope fallback
 * via `calculateCategoryScope` so the surface never goes blank.
 *
 * Includes URL.revokeObjectURL cleanup, drag-and-drop upload, reset button,
 * and full en/es/pt localization.
 */

interface Estimate {
  description: string;
  suggestedCrew: 1 | 2 | 3 | 4;
  suggestedHours: number;
  estimateMin: number;
  estimateMax: number;
  rationale: string;
  confidence: 'low' | 'medium' | 'high';
}

const SERVICES = [
  { value: 'power-washing', label: { en: 'Power washing', es: 'Lavado a presión', pt: 'Lavagem de pressão' } },
  { value: 'lawn-care', label: { en: 'Lawn & yard care', es: 'Césped y jardín', pt: 'Grama e quintal' } },
  { value: 'hauling', label: { en: 'Hauling & junk removal', es: 'Acarreo de basura', pt: 'Remoção de entulho' } },
  { value: 'light-repairs', label: { en: 'Light repairs & handyman', es: 'Reparaciones ligeras', pt: 'Pequenos reparos' } },
  { value: 'moving-labor', label: { en: 'Moving labor', es: 'Ayuda de mudanza', pt: 'Ajuda de mudança' } },
  { value: 'furniture-removal', label: { en: 'Furniture removal', es: 'Retiro de muebles', pt: 'Remoção de móveis' } },
  { value: 'apartment-cleanout', label: { en: 'Apartment / estate cleanout', es: 'Vaciado de apartamento', pt: 'Esvaziamento de imóvel' } },
  { value: 'paint-scraping', label: { en: 'Paint scraping & prep', es: 'Raspado de pintura', pt: 'Raspagem de tinta' } },
  { value: 'loading-unloading', label: { en: 'PODS & truck loading', es: 'Carga de camión / PODS', pt: 'Carga de caminhão / PODS' } },
  { value: 'gutter-clean', label: { en: 'Gutter cleaning', es: 'Limpieza de canaletas', pt: 'Limpeza de calhas' } },
  { value: 'snow-removal', label: { en: 'Snow removal', es: 'Remoción de nieve', pt: 'Remoção de neve' } },
  { value: 'unspecified', label: { en: 'Not sure / mixed job', es: 'No estoy seguro', pt: 'Não tenho certeza' } },
] as const;

type ServiceHint = (typeof SERVICES)[number]['value'];

interface PhotoCopy {
  readonly title: string;
  readonly eyebrow: string;
  readonly h1: string;
  readonly lede: string;
  readonly serviceHintLabel: string;
  readonly zipLabel: string;
  readonly uploadLabel: string;
  readonly dropHint: string;
  readonly privacyNote: string;
  readonly loadingText: string;
  readonly invalidTypeError: string;
  readonly resetBtn: string;
  readonly aiBadge: string;
  readonly rangeBadge: string;
  readonly crewLabel: string;
  readonly peopleUnit: string;
  readonly hoursLabel: string;
  readonly bookCta: string;
}

const COPY: Readonly<Record<LocaleCode, PhotoCopy>> = {
  en: {
    title: 'Photo Estimate · Brick Labor NJ',
    eyebrow: 'AI photo estimate',
    h1: 'Snap a photo. Get a rough quote in 5 seconds.',
    lede:
      'One picture of the job and our AI returns a crew size + hour range + price band. It is a starting point, not a contract — for a flat quote, submit a full booking.',
    serviceHintLabel: 'Service category',
    zipLabel: 'ZIP (optional)',
    uploadLabel: 'Upload or drop a photo of the area',
    dropHint: 'Drag & drop a JPG, PNG, or WEBP photo here, or click to browse.',
    privacyNote: 'We compress to ~1280px before upload. The photo is not stored.',
    loadingText: 'Looking at the photo…',
    invalidTypeError: 'Pick a JPG, PNG, or WEBP image.',
    resetBtn: 'Clear photo & try another',
    aiBadge: 'AI estimate',
    rangeBadge: 'Deterministic scope estimate',
    crewLabel: 'Crew',
    peopleUnit: 'people',
    hoursLabel: 'Hours',
    bookCta: 'Book this crew & scope →',
  },
  es: {
    title: 'Estimado por Foto · Brick Labor NJ',
    eyebrow: 'Estimado con IA por foto',
    h1: 'Toma una foto. Recibe un estimado en 5 segundos.',
    lede:
      'Con una foto del trabajo nuestra IA recomienda tamaño de cuadrilla, horas y rango de precio. Es un punto de partida — para reservar con precio exacto, continúa al formulario.',
    serviceHintLabel: 'Categoría de servicio',
    zipLabel: 'Código postal (opcional)',
    uploadLabel: 'Sube o arrastra una foto del área',
    dropHint: 'Arrastra una foto JPG, PNG o WEBP aquí, o haz clic para seleccionar.',
    privacyNote: 'Comprimimos a ~1280px antes de subir. La foto no se guarda.',
    loadingText: 'Analizando la foto…',
    invalidTypeError: 'Elige una imagen JPG, PNG o WEBP.',
    resetBtn: 'Borrar foto y probar otra',
    aiBadge: 'Estimado por IA',
    rangeBadge: 'Estimado estándar por categoría',
    crewLabel: 'Cuadrilla',
    peopleUnit: 'personas',
    hoursLabel: 'Horas',
    bookCta: 'Reservar esta cuadrilla →',
  },
  pt: {
    title: 'Orçamento por Foto · Brick Labor NJ',
    eyebrow: 'Orçamento com IA por foto',
    h1: 'Tire uma foto. Receba uma estimativa em 5 segundos.',
    lede:
      'Com uma foto do serviço nossa IA recomenda o tamanho da equipe, horas e faixa de preço. É um ponto de partida — para fechar seu agendamento, continue para a reserva.',
    serviceHintLabel: 'Categoria de serviço',
    zipLabel: 'CEP / ZIP (opcional)',
    uploadLabel: 'Envie ou arraste uma foto do local',
    dropHint: 'Arraste uma foto JPG, PNG ou WEBP aqui, ou clique para escolher.',
    privacyNote: 'Reduzimos para ~1280px antes do envio. A foto não fica armazenada.',
    loadingText: 'Analisando a foto…',
    invalidTypeError: 'Escolha uma imagem JPG, PNG ou WEBP.',
    resetBtn: 'Limpar foto e tentar outra',
    aiBadge: 'Estimativa por IA',
    rangeBadge: 'Estimativa padrão por categoria',
    crewLabel: 'Equipe',
    peopleUnit: 'pessoas',
    hoursLabel: 'Horas',
    bookCta: 'Reservar esta equipe →',
  },
};

async function downscaleToBase64(file: File, maxDim = 1280, mime = 'image/jpeg'): Promise<string> {
  const dataUrl = await new Promise<string>((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result));
    r.onerror = rej;
    r.readAsDataURL(file);
  });
  const img = await new Promise<HTMLImageElement>((res, rej) => {
    const i = new Image();
    i.onload = () => res(i);
    i.onerror = rej;
    i.src = dataUrl;
  });
  const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
  const w = Math.round(img.width * scale);
  const h = Math.round(img.height * scale);
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('canvas');
  ctx.drawImage(img, 0, 0, w, h);
  return canvas.toDataURL(mime, 0.82).split(',')[1] ?? '';
}

function fmtUsd(n: number): string {
  return `$${n.toLocaleString('en-US')}`;
}

function buildDeterministicFallback(hint: ServiceHint): Estimate {
  const canonical = normalizeToCanonicalSlug(hint) ?? 'moving-labor';
  const scope = calculateCategoryScope({ category: canonical });
  return {
    description: scope.prefillScopeNote,
    suggestedCrew: scope.recommendedCrew,
    suggestedHours: scope.recommendedHours,
    estimateMin: scope.estimatedMinDollars,
    estimateMax: scope.estimatedMaxDollars,
    rationale: scope.checklist[0] ?? 'Standard crew & hour scope for this service category.',
    confidence: 'medium',
  };
}

export function PhotoEstimatePage() {
  useThemeToolsSurface('photo-estimate-page');
  const locale: LocaleCode =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const t = COPY[locale] ?? COPY.en;

  useEffect(() => {
    document.title = t.title;
    return () => {
      document.title = 'Brick Labor · $60/hr Property Crew Newark NJ';
    };
  }, [t.title]);

  const [serviceHint, setServiceHint] = useState<ServiceHint>('unspecified');
  const [zip, setZip] = useState('');
  const [previewUrl, setPreviewUrl] = useState('');
  const [dragActive, setDragActive] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [estimate, setEstimate] = useState<Estimate | null>(null);
  const [aiUsed, setAiUsed] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  // Prevent blob URL memory leaks on file change or unmount
  useEffect(() => {
    return () => {
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
      }
    };
  }, [previewUrl]);

  function resetPhoto() {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl('');
    setEstimate(null);
    setError('');
    setAiUsed(false);
    if (inputRef.current) inputRef.current.value = '';
  }

  async function onFile(file: File) {
    setError('');
    setEstimate(null);
    setAiUsed(false);
    if (!file.type.startsWith('image/')) {
      setError(t.invalidTypeError);
      return;
    }
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(URL.createObjectURL(file));
    setLoading(true);
    try {
      const base64 = await downscaleToBase64(file);
      const res = await fetch('/api/ai/photo-estimate', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          imageBase64: base64,
          mime: 'image/jpeg',
          serviceHint,
          ...(zip.match(/^\d{5}$/) ? { zip } : {}),
        }),
      });
      if (res.status === 404 || res.status === 503) {
        // Feature flag off or AI unavailable — provide deterministic category estimate
        setEstimate(buildDeterministicFallback(serviceHint));
        setAiUsed(false);
        return;
      }
      const json = (await res.json()) as {
        ok: boolean;
        estimate?: Estimate;
        aiUsed?: boolean;
        error?: string;
      };
      if (!res.ok || !json.ok || !json.estimate) {
        setEstimate(buildDeterministicFallback(serviceHint));
        setAiUsed(false);
      } else {
        setEstimate(json.estimate);
        setAiUsed(Boolean(json.aiUsed));
      }
    } catch {
      setEstimate(buildDeterministicFallback(serviceHint));
      setAiUsed(false);
    } finally {
      setLoading(false);
    }
  }

  const rawBookHref = estimate
    ? `/book?service=${encodeURIComponent(serviceHint)}&hours=${encodeURIComponent(
        String(estimate.suggestedHours),
      )}&crew=${encodeURIComponent(String(estimate.suggestedCrew))}&utm_source=photo_estimate`
    : '/book';
  const bookHref = localizedPath(locale, rawBookHref);

  return (
    <main className="bg-bg-primary min-h-screen pb-24">
      <section className="mx-auto max-w-3xl px-4 pt-12">
        <p className="mb-3 font-mono text-[11px] uppercase tracking-[0.18em] text-brand-accent">
          {t.eyebrow}
        </p>
        <h1 className="mb-3 text-3xl font-bold leading-tight text-brand-ink sm:text-4xl">
          {t.h1}
        </h1>
        <p className="mb-8 max-w-xl text-brand-mute">{t.lede}</p>

        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragActive(true);
          }}
          onDragLeave={() => setDragActive(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragActive(false);
            const f = e.dataTransfer.files?.[0];
            if (f) void onFile(f);
          }}
          className={`rounded-2xl border p-5 space-y-4 transition-colors duration-[333ms] ${
            dragActive
              ? 'border-brand-accent bg-brand-accent/10'
              : 'border-brand-line bg-bg-elevated'
          }`}
        >
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <label className="block">
              <span className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
                {t.serviceHintLabel}
              </span>
              <select
                value={serviceHint}
                onChange={(e) => setServiceHint(e.target.value as ServiceHint)}
                className="mt-1 w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink focus:outline focus:outline-2 focus:outline-brand-accent"
              >
                {SERVICES.map((s) => (
                  <option key={s.value} value={s.value}>
                    {s.label[locale] ?? s.label.en}
                  </option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
                {t.zipLabel}
              </span>
              <input
                value={zip}
                onChange={(e) => setZip(e.target.value.slice(0, 5))}
                inputMode="numeric"
                pattern="\d{5}"
                placeholder="07102"
                className="mt-1 w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink focus:outline focus:outline-2 focus:outline-brand-accent"
              />
            </label>
          </div>

          <div>
            <label className="block text-sm font-medium text-brand-ink">
              {t.uploadLabel}
              <input
                ref={inputRef}
                type="file"
                accept="image/*"
                capture="environment"
                aria-label={t.uploadLabel}
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) void onFile(f);
                }}
                className="mt-2 block w-full text-sm text-brand-mute file:mr-3 file:rounded-md file:border-0 file:bg-brand-accent file:px-4 file:py-2 file:text-sm file:font-semibold file:text-black hover:file:brightness-110"
                data-bcl-action="photo_estimate_upload"
              />
            </label>
            <p className="mt-1 text-xs text-brand-mute">{t.dropHint}</p>
            <p className="mt-1 text-[11px] text-brand-mute">{t.privacyNote}</p>
          </div>

          {previewUrl && (
            <div className="space-y-2">
              <img
                src={previewUrl}
                alt="Selected job-site preview"
                className="max-h-72 w-full rounded-lg border border-brand-line object-cover"
              />
              <button
                type="button"
                onClick={resetPhoto}
                className="rounded-md border border-brand-line px-3 py-1.5 text-xs font-mono text-brand-mute hover:border-brand-accent hover:text-brand-ink transition-colors"
              >
                {t.resetBtn}
              </button>
            </div>
          )}

          {loading && (
            <p className="text-sm text-brand-mute" aria-live="polite">
              {t.loadingText}
            </p>
          )}
          {error && (
            <p className="text-sm text-red-400" role="alert">
              {error}
            </p>
          )}
        </div>

        {estimate && (
          <div
            className="mt-5 rounded-2xl border border-brand-line bg-bg-elevated p-5"
            aria-live="polite"
          >
            <div className="mb-4 flex items-baseline justify-between gap-3">
              <p className="font-mono text-[10px] uppercase tracking-widest text-brand-accent">
                {aiUsed ? `${t.aiBadge} · ${estimate.confidence}` : t.rangeBadge}
              </p>
              <p className="text-2xl font-bold text-brand-ink tabular-nums">
                {fmtUsd(estimate.estimateMin)} – {fmtUsd(estimate.estimateMax)}
              </p>
            </div>
            <p className="mb-1 text-base text-brand-ink">{estimate.description}</p>
            <p className="mb-4 text-sm text-brand-mute">{estimate.rationale}</p>
            <dl className="mb-5 grid grid-cols-2 gap-3 text-sm">
              <div className="rounded-lg border border-brand-line bg-bg-primary px-3 py-2">
                <dt className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
                  {t.crewLabel}
                </dt>
                <dd className="text-base text-brand-ink">
                  {estimate.suggestedCrew} {t.peopleUnit}
                </dd>
              </div>
              <div className="rounded-lg border border-brand-line bg-bg-primary px-3 py-2">
                <dt className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
                  {t.hoursLabel}
                </dt>
                <dd className="text-base text-brand-ink">{estimate.suggestedHours}h</dd>
              </div>
            </dl>
            <a
              href={bookHref}
              className="inline-flex min-h-[44px] w-full items-center justify-center rounded-xl bg-brand-accent px-5 py-3 text-sm font-bold text-black hover:brightness-110 transition-all duration-[333ms]"
              data-bcl-action="photo_estimate_book_cta"
            >
              {t.bookCta}
            </a>
          </div>
        )}
      </section>
    </main>
  );
}
