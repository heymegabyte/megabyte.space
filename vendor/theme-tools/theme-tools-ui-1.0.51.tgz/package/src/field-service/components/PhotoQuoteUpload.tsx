import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
/**
 * PhotoQuoteUpload.tsx — Flag-gated AI photo-to-quote intake component.
 *
 * When the `photo_to_quote` flag is ON, renders a dropzone/camera-capture card
 * where customers snap a photo of the job and get an instant AI-powered estimate.
 *
 * POSTs the image as base64 to `/api/ai-photo-estimate` and displays the
 * returned price range, crew size, and estimated hours.
 *
 * When the flag is OFF: renders null.
 */

import { type FormEvent, useRef, useState } from 'react';
import { useFeatureFlag } from '../use-feature-flag.js';

/* ---------- types ---------- */

interface EstimateResponse {
  ok: boolean;
  estimate: {
    suggestedCrew: number;
    suggestedHours: number;
    estimateMin: number;
    estimateMax: number;
    confidence: 'low' | 'medium' | 'high';
  };
  aiUsed: boolean;
}

/* ---------- helpers ---------- */

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      // Strip the data:image/...;base64, prefix
      resolve(result.split(',')[1] ?? '');
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}

function formatCurrency(cents: number): string {
  return '$' + (cents / 100).toLocaleString('en-US', { minimumFractionDigits: 0 });
}

/* ---------- component ---------- */

export default function PhotoQuoteUpload() {
  useThemeToolsSurface('photo-quote-upload');
  const enabled = useFeatureFlag('photo_to_quote');
  const inputRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<EstimateResponse['estimate'] | null>(null);

  if (!enabled) return null;

  const handleFile = (f: File | null) => {
    setError(null);
    setResult(null);
    if (!f) {
      setFile(null);
      setPreviewUrl(null);
      return;
    }
    if (!f.type.startsWith('image/')) {
      setError('Please select an image file.');
      return;
    }
    if (f.size > 5 * 1024 * 1024) {
      setError('Image must be under 5 MB.');
      return;
    }
    setFile(f);
    setPreviewUrl(URL.createObjectURL(f));
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const f = e.dataTransfer.files?.[0];
    if (f) handleFile(f);
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!file) return;

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const imageBase64 = await fileToBase64(file);
      const mime = file.type as 'image/jpeg' | 'image/png' | 'image/webp';

      const res = await fetch('/api/ai-photo-estimate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64, mime }),
      });

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error((body as { error?: string }).error ?? `Server error (${res.status})`);
      }

      const data = (await res.json()) as EstimateResponse;
      if (data.ok && data.estimate) {
        setResult(data.estimate);
      } else {
        throw new Error('Unexpected response format');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const confidenceLabel: Record<string, string> = {
    low: 'Rough estimate',
    medium: 'Good estimate',
    high: 'High confidence',
  };

  const handleClear = () => {
    setFile(null);
    setPreviewUrl(null);
    setResult(null);
    setError(null);
    if (inputRef.current) inputRef.current.value = '';
  };

  return (
    <section data-testid="photo-quote-upload" className="bg-brand-dark px-4 py-16">
      <div className="mx-auto max-w-2xl text-center">
        <h2 className="font-heading text-3xl font-bold text-white sm:text-4xl">
          Snap a photo for an instant estimate
        </h2>
        <p className="mt-3 text-brand-muted text-lg">
          Send us a picture of the job — messy garage, pile of junk, overgrown yard — and
          get an AI-powered rough price in seconds.
        </p>

        <form
          onSubmit={handleSubmit}
          onDragOver={(e) => e.preventDefault()}
          onDrop={handleDrop}
          className="mt-8 rounded-2xl border-2 border-dashed border-brand-accent/30 bg-white/5 p-8 transition-colors hover:border-brand-accent/60"
        >
          {!previewUrl ? (
            <div className="flex flex-col items-center gap-4">
              <div className="flex h-20 w-20 items-center justify-center rounded-full bg-brand-accent/10 text-4xl text-brand-accent">
                &#128247;
              </div>
              <p className="text-sm text-brand-muted">
                Drag a photo here, or click to browse
              </p>
              <button
                type="button"
                onClick={() => inputRef.current?.click()}
                className="rounded-lg bg-brand-accent px-6 py-2.5 font-semibold text-brand-dark transition hover:bg-brand-accent/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
              >
                Choose Photo
              </button>
              <input
                ref={inputRef}
                type="file"
                accept="image/*"
                capture="environment"
                className="hidden"
                onChange={(e) => handleFile(e.target.files?.[0] ?? null)}
              />
              <p className="text-xs text-brand-muted/60">or use your camera on mobile</p>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-4">
              <div className="relative w-full max-w-sm overflow-hidden rounded-xl">
                <img
                  src={previewUrl}
                  alt="Job photo preview"
                  className="h-auto w-full object-cover"
                />
                <button
                  type="button"
                  onClick={handleClear}
                  className="absolute right-2 top-2 flex h-7 w-7 items-center justify-center rounded-full bg-black/60 text-sm text-white hover:bg-black/80"
                  aria-label="Remove photo"
                >
                  &times;
                </button>
              </div>

              {loading && (
                <div className="w-full max-w-sm animate-pulse space-y-3 py-4">
                  <div className="h-4 w-3/4 rounded bg-white/10" />
                  <div className="h-4 w-1/2 rounded bg-white/10" />
                  <div className="h-4 w-5/6 rounded bg-white/10" />
                  <div className="h-10 w-36 rounded bg-white/10 mx-auto" />
                </div>
              )}

              {result && !loading && (
                <div className="w-full max-w-sm rounded-xl bg-white/10 p-5 text-left">
                  <div className="mb-3 flex items-center justify-between">
                    <span className="text-sm font-medium text-brand-accent">
                      {confidenceLabel[result.confidence] ?? 'Estimate'}
                    </span>
                    <span className="rounded bg-brand-accent/15 px-2 py-0.5 text-xs text-brand-accent">
                      AI-powered
                    </span>
                  </div>

                  <div className="mb-3 text-center">
                    <span className="font-heading text-3xl font-bold text-white">
                      {formatCurrency(result.estimateMin)}
                    </span>
                    <span className="mx-2 text-xl text-brand-muted">&ndash;</span>
                    <span className="font-heading text-3xl font-bold text-white">
                      {formatCurrency(result.estimateMax)}
                    </span>
                  </div>

                  <div className="flex justify-center gap-6 text-sm text-brand-muted">
                    <span>&#128170; {result.suggestedCrew} crew</span>
                    <span>&#9200; ~{result.suggestedHours} hr{result.suggestedHours !== 1 ? 's' : ''}</span>
                  </div>

                  <div className="mt-4 flex justify-center gap-3">
                    <button
                      type="button"
                      onClick={handleClear}
                      className="rounded-lg border border-white/20 px-4 py-2 text-sm text-white transition hover:bg-white/10"
                    >
                      Try another photo
                    </button>
                    <a
                      href="/book"
                      className="rounded-lg bg-brand-accent px-5 py-2 text-sm font-semibold text-brand-dark transition hover:bg-brand-accent/90"
                    >
                      Book the job
                    </a>
                  </div>
                </div>
              )}

              {!loading && !result && !error && (
                <button
                  type="submit"
                  className="rounded-lg bg-brand-accent px-8 py-2.5 font-semibold text-brand-dark transition hover:bg-brand-accent/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent disabled:opacity-50"
                  disabled={!file}
                >
                  Get Estimate
                </button>
              )}

              <p className="text-xs text-brand-muted/60">
                Photo analyzed by AI &mdash; results are rough estimates, not guaranteed quotes.
              </p>
            </div>
          )}

          {/* fire-81: error hoisted OUTSIDE the previewUrl ternary. The invalid-type (:71) and
              over-5MB (:75) errors never set previewUrl, so the old in-branch <p> rendered in the
              preview-only branch → those two errors were INVISIBLE (not just unannounced). Here it
              shows for all 3 states (incl. server :118) and carries role="alert" so screen readers
              announce it (WCAG 2.2 SC 4.1.3) — matching the sibling PhotoQuoteWidget's live region. */}
          {error && !loading && (
            <p className="mt-4 text-sm text-red-400" role="alert">
              {error}
            </p>
          )}
        </form>
      </div>
    </section>
  );
}
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
