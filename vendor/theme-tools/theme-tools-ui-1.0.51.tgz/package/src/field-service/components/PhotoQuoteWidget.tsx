import { useRef, useState, type JSX } from 'react';
import { useFeatureFlag } from '../use-feature-flag.js';
import { usd } from '@theme.tools/billing/field-service/money';

interface EstimateResult {
  estimatedHours?: number;
  crewSize?: number;
  bandLabel?: string;
  estimatedCents?: number;
  serviceHint?: string;
}

type WidgetState = 'idle' | 'uploading' | 'estimating' | 'result' | 'error' | 'timeout';

export function PhotoQuoteWidget(): JSX.Element | null {
  const enabled = useFeatureFlag('photo_sms_intake');
  const [state, setState] = useState<WidgetState>('idle');
  const [result, setResult] = useState<EstimateResult | null>(null);
  const [error, setError] = useState('');
  const [preview, setPreview] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleFile = async (file: File) => {
    setPreview(URL.createObjectURL(file));
    setState('uploading');
    setError('');
    setResult(null);

    try {
      const formData = new FormData();
      formData.append('image', file);
      formData.append('source', 'web_widget');
      formData.append('phone', '0000000000');

      const res = await fetch('/api/photo-sms-intake/process', {
        method: 'POST',
        body: formData,
        credentials: 'same-origin',
      });

      if (!res.ok) {
        const errBody = (await res.json().catch(() => ({}))) as Record<string, unknown>;
        throw new Error((errBody.error as string) || `HTTP ${res.status}`);
      }

      setState('estimating');
      const data = (await res.json()) as { id?: string; estimate?: EstimateResult; ok?: boolean };
      if (data.estimate) {
        setResult(data.estimate);
        setState('result');
        return;
      }
      if (data.id) {
        for (let i = 0; i < 5; i++) {
          await new Promise((resolve) => setTimeout(resolve, 2000));
          const check = await fetch(`/api/photo-sms-intake/${data.id}`, {
            credentials: 'same-origin',
          });
          if (check.ok) {
            const checkData = (await check.json()) as { estimate?: EstimateResult };
            if (checkData.estimate) {
              setResult(checkData.estimate);
              setState('result');
              return;
            }
          }
        }
      }
      setState('timeout');
    } catch (err) {
      setError((err as Error).message);
      setState('error');
    }
  };

  const reset = () => {
    setState('idle');
    setResult(null);
    setError('');
    setPreview(null);
  };

  if (!enabled) return null;

  return (
    <section className="w-full max-w-xl mx-auto py-10 px-4" aria-label="Photo estimate">
      <div className="rounded-2xl border border-brand-line bg-brand-card p-6 text-center md:p-8">
        <h2 className="mb-1 text-xl font-bold text-brand-ink md:text-2xl">
          Snap a photo — get an instant estimate
        </h2>
        <p className="mb-6 text-sm text-brand-mute">
          Take a picture of your junk pile, moving load, or messy yard. AI estimates the job in seconds.
        </p>

        {state === 'idle' && (
          <>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={(event) => {
                const file = event.target.files?.[0];
                if (file) void handleFile(file);
              }}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="inline-flex items-center gap-2 rounded-xl border-2 border-dashed border-brand-line px-8 py-12 transition-colors hover:border-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
            >
              <span className="text-4xl" aria-hidden>📸</span>
              <span className="mt-2 block text-sm text-brand-mute">Tap to take a photo or choose one</span>
            </button>
          </>
        )}

        {(state === 'uploading' || state === 'estimating') && (
          <div className="py-10 text-brand-mute" role="status" aria-live="polite">
            <div className="mb-3 animate-pulse text-4xl" aria-hidden>
              {state === 'uploading' ? '📤' : '🤖'}
            </div>
            <p>{state === 'uploading' ? 'Uploading photo...' : 'AI analyzing your photo...'}</p>
          </div>
        )}

        {state === 'result' && result && (
          <div className="space-y-3">
            {preview && <img src={preview} alt="Your upload" className="mx-auto max-h-[200px] rounded-lg" />}
            <div className="text-3xl font-extrabold text-brand-ink">
              {result.estimatedCents ? usd(result.estimatedCents) : '—'}
            </div>
            <div className="text-sm text-brand-mute">
              {result.bandLabel || 'Estimate'} · {result.crewSize ?? '?'} person
              {result.crewSize !== 1 ? 's' : ''}
              {result.estimatedHours ? ` · ~${result.estimatedHours} hr` : ''}
            </div>
            <a
              href="/book"
              className="inline-block rounded-lg bg-brand-accent px-6 py-3 text-sm font-bold text-bg-primary transition-colors hover:bg-brand-accent/90"
            >
              Book with this estimate
            </a>
            <br />
            <button type="button" onClick={reset} className="mt-2 text-xs text-brand-mute underline hover:text-brand-accent">
              Try another photo
            </button>
          </div>
        )}

        {state === 'timeout' && (
          <div data-testid="photo-quote-timeout" role="status" aria-live="polite" className="space-y-3 py-6">
            <div className="mb-1 text-4xl" aria-hidden>⏳</div>
            <p className="font-semibold text-brand-ink">This is taking longer than expected</p>
            <p className="mx-auto max-w-sm text-sm text-brand-mute">
              We couldn&apos;t get your estimate back in time. Try another photo, or book now and
              we&apos;ll confirm the scope on-site — the 1-hour minimum still applies.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
              <button
                type="button"
                onClick={reset}
                className="rounded-lg bg-brand-accent px-6 py-2.5 text-sm font-bold text-bg-primary transition-colors hover:bg-brand-accent/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
              >
                Try again
              </button>
              <a
                href="/book"
                className="rounded-lg border border-brand-line px-6 py-2.5 text-sm font-semibold text-brand-ink transition-colors hover:border-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
              >
                Book anyway
              </a>
            </div>
          </div>
        )}

        {state === 'error' && (
          <div className="py-6" role="status" aria-live="polite">
            <p className="mb-3 text-sm text-red-400">{error || 'Something went wrong. Try again.'}</p>
            <button type="button" onClick={reset} className="text-sm text-brand-accent underline">
              Try again
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
