import { useThemeToolsSurface } from '../../field-service-primitives.js';
/**
 * PhotoSmsEstimate.tsx — Wave 33 photo-sms-intake widget.
 *
 * Flag-gated card that invites customers to text a photo of their job
 * for a free estimate. Shows the business phone number prominently with
 * a "Text a Photo" CTA. SMS href pre-fills a message so the customer just
 * taps → attaches photo → sends.
 *
 * When the flag is OFF: renders null.
 */

import { useFeatureFlag } from '../use-feature-flag.js';
import { PHONE_DISPLAY, PHONE_SMS_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';

const SMS_BODY = encodeURIComponent(
  'Hi Brick Labor! Here\'s a photo of my job for an estimate:',
);

export default function PhotoSmsEstimate() {
  useThemeToolsSurface('photo-sms-estimate');
  const intakeEnabled = useFeatureFlag('photo_sms_intake');
  const photoEnabled = useFeatureFlag('photo_to_quote');

  if (!intakeEnabled || !photoEnabled) return null;

  return (
    <section
      data-testid="photo-sms-estimate"
      className="mx-auto max-w-5xl px-4 py-16 sm:px-6 lg:px-8"
    >
      <div className="rounded-2xl border border-brand-accent/20 bg-gradient-to-br from-brand-accent/5 to-transparent p-8 text-center sm:p-12">
        {/* Icon */}
        <div aria-hidden="true" className="mx-auto mb-4 text-5xl">
          📸
        </div>

        {/* Headline */}
        <h2 className="mb-3 text-2xl font-bold text-white sm:text-3xl">
          Text us a photo for a free estimate
        </h2>

        {/* Subcopy */}
        <p className="mx-auto mb-6 max-w-md text-base text-white/70">
          Snap a picture of your job and send it our way. Our coordinator will
          review the estimate before we text it back.
        </p>

        {/* Phone link with pre-filled SMS */}
        <a
          href={`${PHONE_SMS_HREF}?body=${SMS_BODY}`}
          className="inline-flex items-center gap-2 rounded-xl bg-brand-accent px-6 py-3 text-base font-semibold text-bg-primary shadow-lg transition-all hover:bg-brand-accent/85 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent focus-visible:ring-offset-2 focus-visible:ring-offset-brand-surface"
          data-bcl="photo-sms-cta"
        >
          📱 Text a Photo
        </a>

        {/* Phone number displayed as a tappable link */}
        <p className="mt-4">
          <a
            href={PHONE_SMS_HREF}
            className="text-lg font-semibold text-brand-accent underline underline-offset-2 hover:text-white"
          >
            {PHONE_DISPLAY}
          </a>
        </p>

        {/* Disclaimer */}
        <p className="mt-4 text-xs text-white/40">
          Message and data rates may apply. We'll never share your number.
        </p>
      </div>
    </section>
  );
}
