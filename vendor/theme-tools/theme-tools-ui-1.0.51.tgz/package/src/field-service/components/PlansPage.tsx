import { useEffect, useState } from 'react';
import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { plansPageCopy } from '@theme.tools/billing/field-service/plans-page-copy';
import { TurnstileWidget } from './TurnstileWidget.js';

/**
 * Public recurring-subscriptions catalog (idea #10 surface).
 *
 * `/plans` lists every active plan from /api/subscriptions/plans, lets the
 * customer pick one, fills a short form, posts to /api/subscriptions/subscribe.
 *
 * Status returned: 'active' if Square minted the subscription inline; else
 * 'pending' — Square keys may be absent in dev, or the API rejected the
 * plan-variation id, in which case the operator activates within 24h.
 */

type Plan = {
  id: string;
  slug: string;
  name: string;
  description: string;
  cadence: 'weekly' | 'biweekly' | 'monthly' | 'quarterly' | 'yearly';
  monthly_price_cents: number;
  services_csv: string;
  cycle_includes: string;
};

type SignupResult = {
  ok: boolean;
  subscriptionId?: string;
  status?: 'active' | 'pending';
  nextCycleDate?: string;
  monthlyPriceCents?: number;
  note?: string;
  error?: string;
};

function fmtUsd(cents: number): string {
  return `$${(cents / 100).toFixed(0)}`;
}

export function PlansPage() {
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const copy = plansPageCopy(locale);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [pickedSlug, setPickedSlug] = useState('');
  const [form, setForm] = useState({
    customerEmail: '',
    customerName: '',
    customerPhone: '',
    serviceAddress: '',
    serviceCity: 'Newark',
    serviceZip: '',
    startDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10),
    autopilot: true,
    notes: '',
  });
  const [result, setResult] = useState<SignupResult | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [turnstileToken, setTurnstileToken] = useState('');

  useEffect(() => {
    document.title = 'Recurring Plans · Brick Labor NJ';
    return () => {
      document.title = 'Brick Labor · $50/hr Property Crew Newark NJ';
    };
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    void (async () => {
      try {
        const res = await fetch('/api/subscriptions/plans', { signal: controller.signal });
        const json = (await res.json()) as { ok: boolean; plans?: Plan[] };
        if (json.ok && json.plans) setPlans(json.plans);
        else setError(copy.plansUnavailable);
      } catch {
        if (controller.signal.aborted) return;
        setError(copy.networkError);
      } finally {
        if (!controller.signal.aborted) setLoading(false);
      }
    })();
    return () => controller.abort();
  }, [copy.plansUnavailable, copy.networkError]);

  const picked = plans.find((p) => p.slug === pickedSlug);
  const pricingStandard = evaluateHourlyLaborPricingStandard({ crewSize: 2, hours: 2, cadence: 'weekly' });
  const surfaceProps = useThemeToolsSurface('plans-page', [
    '@theme.tools/ui',
    '@theme.tools/billing',
    '@theme.tools/scheduling',
  ]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!picked) return;
    setSubmitting(true);
    setResult(null);
    try {
      const res = await fetch('/api/subscriptions/subscribe', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          planId: picked.id,
          ...form,
          turnstileToken,
        }),
      });
      const json = (await res.json()) as SignupResult;
      setResult(json);
    } catch (err) {
      setResult({ ok: false, error: (err as Error).message });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main
      className="bg-bg-primary min-h-screen pb-24"
      data-theme-tools-surface={surfaceProps['data-theme-tools-surface']}
      data-theme-tools-pricing-model={surfaceProps['data-theme-tools-pricing-model']}
      data-theme-tools-packages={surfaceProps['data-theme-tools-packages']}
      data-base-hourly-rate-cents={pricingStandard.hourlyRatePerPersonCents}
    >
      <section className="mx-auto max-w-5xl px-4 pt-12">
        <p className="mb-3 font-mono text-[11px] uppercase tracking-[0.18em] text-brand-accent">
          {copy.eyebrow}
        </p>
        <h1 className="mb-3 text-3xl font-bold leading-tight text-brand-ink sm:text-4xl">
          {copy.headline}
        </h1>
        <p className="mb-8 max-w-2xl text-brand-mute">{copy.lede}</p>

        {loading && (
          <p className="text-sm text-brand-mute" aria-live="polite">
            {copy.loading}
          </p>
        )}
        {error && (
          <p className="text-sm text-red-400" role="alert">
            {error}
          </p>
        )}

        {!loading && plans.length > 0 && (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            {plans.map((p) => {
              const sel = p.slug === pickedSlug;
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setPickedSlug(p.slug)}
                  data-bcl-action="plan_picked"
                  data-bcl-plan={p.slug}
                  aria-pressed={sel}
                  className={`flex flex-col items-start gap-2 rounded-2xl border p-5 text-left transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-accent ${
                    sel
                      ? 'border-brand-accent bg-brand-accent/10'
                      : 'border-brand-line bg-bg-elevated hover:border-brand-accent/60'
                  }`}
                >
                  <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-brand-accent">
                    {p.name}
                  </span>
                  <span className="text-2xl font-bold text-brand-ink">
                    {fmtUsd(p.monthly_price_cents)}
                    <span className="text-sm font-normal text-brand-mute">
                      {copy.cadence[p.cadence]}
                    </span>
                  </span>
                  <span className="text-sm text-brand-ink">{p.description}</span>
                  <span className="mt-2 font-mono text-[10px] uppercase tracking-widest text-brand-mute">
                    {copy.eachCycle}
                  </span>
                  <span className="text-xs text-brand-mute">{p.cycle_includes}</span>
                </button>
              );
            })}
          </div>
        )}

        {picked && !result?.ok && (
          <form
            onSubmit={submit}
            className="mt-8 rounded-2xl border border-brand-line bg-bg-elevated p-5 space-y-4"
            aria-labelledby="plan-signup-title"
          >
            <h2 id="plan-signup-title" className="text-xl font-bold text-brand-ink">
              {copy.startPrefix} {picked.name}
            </h2>
            <p className="text-xs text-brand-mute">
              {fmtUsd(picked.monthly_price_cents)}
              {copy.cadence[picked.cadence]}
              {copy.billedSuffix}
            </p>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <Field
                label={copy.fields.name}
                value={form.customerName}
                onChange={(v) => setForm({ ...form, customerName: v })}
                required
              />
              <Field
                label={copy.fields.email}
                type="email"
                value={form.customerEmail}
                onChange={(v) => setForm({ ...form, customerEmail: v })}
                required
              />
              <Field
                label={copy.fields.phone}
                type="tel"
                value={form.customerPhone}
                onChange={(v) => setForm({ ...form, customerPhone: v })}
                required
              />
              <Field
                label={copy.fields.address}
                value={form.serviceAddress}
                onChange={(v) => setForm({ ...form, serviceAddress: v })}
                required
              />
              <Field
                label={copy.fields.city}
                value={form.serviceCity}
                onChange={(v) => setForm({ ...form, serviceCity: v })}
                required
              />
              <Field
                label={copy.fields.zip}
                value={form.serviceZip}
                onChange={(v) => setForm({ ...form, serviceZip: v.slice(0, 5) })}
                required
              />
              <Field
                label={copy.fields.firstServiceDate}
                type="date"
                value={form.startDate}
                onChange={(v) => setForm({ ...form, startDate: v })}
                required
              />
              <label className="flex items-center gap-2 text-sm text-brand-ink sm:col-span-2">
                <input
                  type="checkbox"
                  checked={form.autopilot}
                  onChange={(e) => setForm({ ...form, autopilot: e.target.checked })}
                  className="h-4 w-4 rounded border-brand-line"
                />
                {copy.autopilot}
              </label>
              <Field
                label={copy.fields.notes}
                value={form.notes}
                onChange={(v) => setForm({ ...form, notes: v })}
                multiline
                className="sm:col-span-2"
              />
            </div>
            <TurnstileWidget onToken={setTurnstileToken} action="subscribe" />
            <button
              type="submit"
              disabled={submitting}
              data-bcl-action="plan_subscribe"
              data-bcl-plan={picked.slug}
              className="inline-flex items-center justify-center rounded-md bg-brand-accent px-4 py-3 text-sm font-semibold text-black transition hover:brightness-110 disabled:opacity-50"
            >
              {submitting ? copy.starting : `${copy.startVerb} ${picked.name} →`}
            </button>
            <p className="text-[11px] text-brand-mute">
              {copy.authorizePrefix} {fmtUsd(picked.monthly_price_cents)}
              {copy.cadence[picked.cadence]} {copy.authorizeSuffix}
            </p>
          </form>
        )}

        {result && result.ok && (
          <div className="mt-8 rounded-2xl border border-emerald-500/50 bg-emerald-500/5 p-5 text-brand-ink">
            <p className="mb-2 font-mono text-[11px] uppercase tracking-widest text-emerald-400">
              {result.status === 'active' ? copy.subActive : copy.subPending}
            </p>
            <p className="text-base">{result.note}</p>
            {result.nextCycleDate && (
              <p className="mt-2 text-sm text-brand-mute">
                {copy.nextCycle} <strong>{result.nextCycleDate}</strong>
              </p>
            )}
            <p className="mt-4 text-xs text-brand-mute">
              {copy.confirmTo(form.customerEmail)}{' '}
              <a href="/me" className="text-brand-accent underline">
                /me
              </a>
              .
            </p>
          </div>
        )}

        {result && !result.ok && (
          <p className="mt-4 text-sm text-red-400" role="alert">
            {result.error ?? copy.subFailed}
          </p>
        )}
      </section>
    </main>
  );
}

function Field(props: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
  multiline?: boolean;
  className?: string;
}) {
  const id = `f-${props.label.toLowerCase().replace(/\W+/g, '-')}`;
  const inputClass =
    'mt-1 w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink focus:outline focus:outline-2 focus:outline-brand-accent';
  return (
    <label htmlFor={id} className={`block text-sm ${props.className ?? ''}`}>
      <span className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
        {props.label}
      </span>
      {props.multiline ? (
        <textarea
          id={id}
          value={props.value}
          onChange={(e) => props.onChange(e.target.value)}
          required={props.required}
          rows={3}
          className={inputClass}
        />
      ) : (
        <input
          id={id}
          type={props.type ?? 'text'}
          value={props.value}
          onChange={(e) => props.onChange(e.target.value)}
          required={props.required}
          className={inputClass}
        />
      )}
    </label>
  );
}
