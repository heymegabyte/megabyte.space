import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

interface PodcastPlayerProps {
  src: string;
  title: string;
  subtitle?: string;
  downloadName?: string;
  artworkSrc?: string;
  duration?: number;
}

function fmt(t: number): string {
  if (!Number.isFinite(t) || t < 0) return '0:00';
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  return `${m}:${s < 10 ? '0' : ''}${s}`;
}

export function PodcastPlayer({
  src,
  title,
  subtitle,
  downloadName,
  artworkSrc,
  duration,
}: PodcastPlayerProps) {
  useThemeToolsSurface('podcast-player');
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const ctxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const sourceRef = useRef<MediaElementAudioSourceNode | null>(null);
  const rafRef = useRef<number | null>(null);

  const [playing, setPlaying] = useState(false);
  const [current, setCurrent] = useState(0);
  const [total, setTotal] = useState(duration ?? 0);
  const [rate, setRate] = useState(1);
  const [volume, setVolume] = useState(1);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState(false);

  const ensureAudioGraph = useCallback(() => {
    const el = audioRef.current;
    if (!el || ctxRef.current) return;
    try {
      const AC: typeof AudioContext =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AC();
      const src = ctx.createMediaElementSource(el);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 128;
      analyser.smoothingTimeConstant = 0.78;
      src.connect(analyser);
      analyser.connect(ctx.destination);
      ctxRef.current = ctx;
      analyserRef.current = analyser;
      sourceRef.current = src;
    } catch {
      // No-op: visualization just won't run.
    }
  }, []);

  const drawFrame = useCallback(() => {
    const canvas = canvasRef.current;
    const analyser = analyserRef.current;
    if (!canvas || !analyser) {
      rafRef.current = requestAnimationFrame(drawFrame);
      return;
    }
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    if (canvas.width !== Math.floor(w * dpr) || canvas.height !== Math.floor(h * dpr)) {
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);

    const data = new Uint8Array(analyser.frequencyBinCount);
    analyser.getByteFrequencyData(data);
    const bars = Math.min(48, data.length);
    const gap = 3;
    const barW = Math.max(2, (w - gap * (bars - 1)) / bars);
    const midY = h / 2;
    for (let i = 0; i < bars; i++) {
      const v = (data[i] ?? 0) / 255;
      const peak = Math.max(2, v * (h * 0.85));
      const x = i * (barW + gap);
      const y = midY - peak / 2;
      const grad = ctx.createLinearGradient(0, y, 0, y + peak);
      grad.addColorStop(0, 'rgba(255,107,26,0.95)');
      grad.addColorStop(1, 'rgba(34,211,238,0.55)');
      ctx.fillStyle = grad;
      const r = Math.min(barW / 2, 3);
      ctx.beginPath();
      ctx.roundRect(x, y, barW, peak, r);
      ctx.fill();
    }
    rafRef.current = requestAnimationFrame(drawFrame);
  }, []);

  useEffect(() => {
    rafRef.current = requestAnimationFrame(drawFrame);
    return () => {
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
    };
  }, [drawFrame]);

  useEffect(() => {
    const el = audioRef.current;
    if (!el) return;
    const onLoaded = () => {
      if (Number.isFinite(el.duration)) setTotal(el.duration);
      setReady(true);
    };
    const onTime = () => setCurrent(el.currentTime);
    const onPlay = () => setPlaying(true);
    const onPause = () => setPlaying(false);
    const onEnded = () => setPlaying(false);
    const onError = () => setError(true);
    el.addEventListener('loadedmetadata', onLoaded);
    el.addEventListener('timeupdate', onTime);
    el.addEventListener('play', onPlay);
    el.addEventListener('pause', onPause);
    el.addEventListener('ended', onEnded);
    el.addEventListener('error', onError);
    return () => {
      el.removeEventListener('loadedmetadata', onLoaded);
      el.removeEventListener('timeupdate', onTime);
      el.removeEventListener('play', onPlay);
      el.removeEventListener('pause', onPause);
      el.removeEventListener('ended', onEnded);
      el.removeEventListener('error', onError);
    };
  }, []);

  const toggle = useCallback(async () => {
    const el = audioRef.current;
    if (!el) return;
    ensureAudioGraph();
    if (ctxRef.current?.state === 'suspended') {
      try {
        await ctxRef.current.resume();
      } catch {
        /* ignore */
      }
    }
    if (el.paused) {
      try {
        await el.play();
      } catch {
        setError(true);
      }
    } else {
      el.pause();
    }
  }, [ensureAudioGraph]);

  const skip = useCallback((seconds: number) => {
    const el = audioRef.current;
    if (!el) return;
    el.currentTime = Math.max(
      0,
      Math.min(el.duration || el.currentTime + seconds, el.currentTime + seconds),
    );
  }, []);

  const seek = useCallback((ratio: number) => {
    const el = audioRef.current;
    if (!el) return;
    const target = (el.duration || 0) * Math.max(0, Math.min(1, ratio));
    el.currentTime = target;
  }, []);

  const changeRate = useCallback((next: number) => {
    const el = audioRef.current;
    if (!el) return;
    el.playbackRate = next;
    setRate(next);
  }, []);

  const changeVolume = useCallback((next: number) => {
    const el = audioRef.current;
    if (!el) return;
    el.volume = next;
    setVolume(next);
  }, []);

  const progress = useMemo(() => (total > 0 ? Math.min(1, current / total) : 0), [current, total]);

  return (
    <section
      className="podcast-player not-prose relative overflow-hidden rounded-3xl border border-brand-accent/30 bg-gradient-to-br from-bg-elevated via-bg-primary to-bg-elevated shadow-[0_30px_80px_-20px_rgba(255,107,26,0.25)]"
      aria-label={`Podcast player — ${title}`}
    >
      <div
        className="pointer-events-none absolute inset-0 opacity-60 [mask-image:radial-gradient(circle_at_top_left,black,transparent_70%)]"
        aria-hidden
      >
        <div className="absolute -left-20 -top-20 h-72 w-72 rounded-full bg-brand-accent/20 blur-3xl" />
        <div className="absolute -right-24 -bottom-24 h-72 w-72 rounded-full bg-cyan-400/15 blur-3xl" />
      </div>

      <div className="relative grid gap-6 p-6 md:grid-cols-[180px_1fr] md:p-8 md:gap-8">
        <div className="hidden md:block">
          <div className="relative aspect-square overflow-hidden rounded-2xl border border-brand-accent/40 bg-bg-elevated shadow-[0_15px_40px_-10px_rgba(255,107,26,0.45)]">
            {artworkSrc ? (
              <img
                src={artworkSrc}
                alt={`${title} artwork`}
                className="h-full w-full object-cover"
                loading="lazy"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-brand-accent/30 to-cyan-400/20">
                <span aria-hidden className="text-5xl">
                  🎙️
                </span>
              </div>
            )}
            {playing && (
              <div
                className="absolute inset-0 ring-2 ring-brand-accent/70 ring-offset-2 ring-offset-bg-primary animate-pulse"
                aria-hidden
              />
            )}
          </div>
        </div>

        <div className="flex min-w-0 flex-col gap-4">
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0">
              <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-brand-accent">
                Field Notes Podcast
              </p>
              <h3 className="mt-1 font-display text-xl font-extrabold text-brand-ink md:text-2xl">
                {title}
              </h3>
              {subtitle && <p className="mt-1 text-sm text-brand-mute">{subtitle}</p>}
            </div>
            <a
              href={src}
              download={downloadName}
              className="shrink-0 rounded-md border border-brand-line bg-bg-primary px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider text-brand-mute hover:border-brand-accent hover:text-brand-accent"
              aria-label="Download MP3"
            >
              ↓ MP3
            </a>
          </div>

          <canvas
            ref={canvasRef}
            className="h-16 w-full rounded-lg bg-bg-primary/60 backdrop-blur-sm"
            aria-hidden="true"
          />

          <div className="space-y-2">
            <button
              type="button"
              role="slider"
              aria-label="Seek"
              aria-valuemin={0}
              aria-valuemax={Math.max(1, Math.round(total))}
              aria-valuenow={Math.round(current)}
              aria-valuetext={`${fmt(current)} of ${fmt(total)}`}
              onClick={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                seek((e.clientX - rect.left) / rect.width);
              }}
              onKeyDown={(e) => {
                if (e.key === 'ArrowLeft') skip(-5);
                else if (e.key === 'ArrowRight') skip(5);
              }}
              className="group relative block h-2 w-full overflow-hidden rounded-full bg-brand-line/40 focus-visible:outline-2 focus-visible:outline-brand-accent focus-visible:outline-offset-2"
            >
              <span
                className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-brand-accent to-cyan-400 transition-[width]"
                style={{ width: `${progress * 100}%` }}
                aria-hidden
              />
              <span
                className="absolute top-1/2 h-3.5 w-3.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-brand-accent shadow-[0_0_0_3px_rgba(255,107,26,0.25)] transition-[left] group-hover:scale-110"
                style={{ left: `${progress * 100}%` }}
                aria-hidden
              />
            </button>
            <div className="flex items-center justify-between font-mono text-[11px] text-brand-mute">
              <span>{fmt(current)}</span>
              <span>{ready || total > 0 ? `−${fmt(Math.max(0, total - current))}` : '--:--'}</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => skip(-15)}
              className="h-10 w-10 rounded-full border border-brand-line bg-bg-primary text-brand-ink hover:border-brand-accent hover:text-brand-accent active:scale-95"
              aria-label="Back 15 seconds"
              title="Back 15s"
            >
              −15
            </button>
            <button
              type="button"
              onClick={toggle}
              className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-brand-accent to-orange-500 text-bg-primary shadow-[0_10px_30px_-5px_rgba(255,107,26,0.6)] hover:scale-105 active:scale-95 transition-transform"
              aria-label={playing ? 'Pause' : 'Play'}
              aria-pressed={playing}
            >
              {playing ? (
                <svg viewBox="0 0 24 24" className="h-6 w-6" fill="currentColor" aria-hidden>
                  <rect x="6" y="5" width="4" height="14" rx="1" />
                  <rect x="14" y="5" width="4" height="14" rx="1" />
                </svg>
              ) : (
                <svg viewBox="0 0 24 24" className="ml-0.5 h-6 w-6" fill="currentColor" aria-hidden>
                  <path d="M8 5v14l11-7z" />
                </svg>
              )}
            </button>
            <button
              type="button"
              onClick={() => skip(30)}
              className="h-10 w-10 rounded-full border border-brand-line bg-bg-primary text-brand-ink hover:border-brand-accent hover:text-brand-accent active:scale-95"
              aria-label="Forward 30 seconds"
              title="Forward 30s"
            >
              +30
            </button>

            <div className="ml-auto flex items-center gap-2">
              <div className="flex items-center gap-1 rounded-full border border-brand-line bg-bg-primary p-0.5">
                {[1, 1.25, 1.5, 2].map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => changeRate(r)}
                    className={`rounded-full px-2 py-0.5 font-mono text-[11px] transition ${
                      rate === r
                        ? 'bg-brand-accent text-bg-primary'
                        : 'text-brand-mute hover:text-brand-ink'
                    }`}
                    aria-pressed={rate === r}
                    aria-label={`Playback speed ${r}x`}
                  >
                    {r}×
                  </button>
                ))}
              </div>

              <label className="hidden items-center gap-2 sm:flex" aria-label="Volume">
                <span aria-hidden className="text-brand-mute">
                  🔊
                </span>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={volume}
                  onChange={(e) => changeVolume(Number(e.target.value))}
                  className="h-1 w-20 cursor-pointer accent-brand-accent"
                />
              </label>
            </div>
          </div>

          {error && (
            <p className="text-xs text-red-400">
              Could not load audio.{' '}
              <a href={src} className="underline">
                Open MP3 directly
              </a>
              .
            </p>
          )}

          <audio ref={audioRef} preload="metadata" crossOrigin="anonymous" aria-label={title}>
            <source src={src} type="audio/mpeg" />
          </audio>
        </div>
      </div>
    </section>
  );
}
