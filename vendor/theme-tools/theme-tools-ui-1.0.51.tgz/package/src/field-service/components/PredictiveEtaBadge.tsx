import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect, useState, useRef } from 'react';
import type { StatusLocale } from '@theme.tools/scheduling/field-service/booking-status';
import { trackCopy } from '@theme.tools/i18n-a11y/field-service/track-copy';

const POLL_MS = 60_000;

interface PredictiveEtaBadgeProps {
  rideId: string;
  locale?: StatusLocale;
  /** Story/test override; production retains the one-minute cadence. */
  pollMs?: number;
}

interface EtaSnapshot {
  etaSeconds: number;
  distanceMeters: number;
  originLat: number | null;
  originLng: number | null;
  destLat: number | null;
  destLng: number | null;
  source: 'haversine' | 'cache';
  snapshotAt: string;
  staticMapUrl: string | null;
}

type BadgeState =
  | { kind: 'loading' }
  | { kind: 'loaded'; etaSeconds: number; stale: boolean }
  | { kind: 'empty' };

function formatEta(seconds: number): string {
  const mins = Math.round(seconds / 60);
  if (mins < 1) return '<1 min';
  if (mins >= 60) {
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return m > 0 ? `~${h}h ${m}m` : `~${h}h`;
  }
  return `~${mins} min`;
}

export function PredictiveEtaBadge({
  rideId,
  locale = 'en',
  pollMs = POLL_MS,
}: PredictiveEtaBadgeProps) {
  useThemeToolsSurface('predictive-eta-badge');
  const copy = trackCopy(locale);
  const [state, setState] = useState<BadgeState>({ kind: 'loading' });
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const latestSnapshotAtRef = useRef<number | null>(null);

  useEffect(() => {
    latestSnapshotAtRef.current = null;
    setState({ kind: 'loading' });
    if (!rideId) {
      setState({ kind: 'empty' });
      return;
    }

    let stopped = false;
    const controllers = new Set<AbortController>();
    const markUnavailable = () =>
      setState((current) =>
        current.kind === 'loaded' ? { ...current, stale: true } : { kind: 'empty' },
      );

    const fetchEta = async () => {
      const controller = new AbortController();
      controllers.add(controller);
      try {
        const res = await fetch(`/api/predictive-eta/${encodeURIComponent(rideId)}/poll`, {
          headers: { Accept: 'application/json' },
          signal: controller.signal,
        });
        if (stopped) return;

        if (res.status === 404) {
          markUnavailable();
          return;
        }

        if (!res.ok) {
          markUnavailable();
          return;
        }

        const body = (await res.json()) as { ok: boolean; snapshot?: EtaSnapshot };
        if (stopped) return;

        const etaSeconds = body.snapshot?.etaSeconds;
        const snapshotAt = body.snapshot ? Date.parse(body.snapshot.snapshotAt) : Number.NaN;
        if (
          body.ok &&
          body.snapshot &&
          typeof etaSeconds === 'number' &&
          Number.isFinite(etaSeconds) &&
          etaSeconds >= 0 &&
          Number.isFinite(snapshotAt)
        ) {
          const latest = latestSnapshotAtRef.current;
          if (latest === null || snapshotAt >= latest) {
            latestSnapshotAtRef.current = snapshotAt;
            setState({ kind: 'loaded', etaSeconds, stale: false });
          }
        } else {
          markUnavailable();
        }
      } catch (error) {
        if (error instanceof DOMException && error.name === 'AbortError') return;
        if (!stopped) markUnavailable();
      } finally {
        controllers.delete(controller);
      }
    };

    fetchEta();
    timerRef.current = setInterval(fetchEta, Math.max(10, pollMs));

    return () => {
      stopped = true;
      if (timerRef.current !== null) clearInterval(timerRef.current);
      controllers.forEach((controller) => controller.abort());
      controllers.clear();
    };
  }, [pollMs, rideId]);

  if (state.kind === 'empty') return null;

  return (
    <div
      data-testid="predictive-eta-badge"
      className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold tracking-wide transition-opacity ${
        state.kind === 'loading'
          ? 'motion-safe:animate-pulse bg-brand-line text-brand-mute'
          : state.stale
            ? 'border border-amber-400/40 bg-amber-950/40 text-amber-200'
            : 'bg-cyan-950/50 text-cyan-300 border border-cyan-500/30'
      }`}
      data-state={state.kind === 'loaded' && state.stale ? 'stale' : state.kind}
    >
      {/* Clock icon */}
      <svg
        className="h-3.5 w-3.5"
        viewBox="0 0 16 16"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden="true"
      >
        <circle cx="8" cy="8" r="6.5" />
        <path d="M8 4.5V8l2.5 1.5" />
      </svg>

      {state.kind === 'loading' ? (
        <span
          className="inline-block w-10 h-3 rounded bg-current opacity-30"
          role="status"
          aria-live="polite"
          aria-label={copy.etaLoading}
        />
      ) : (
        <span role={state.stale ? 'status' : undefined} aria-live={state.stale ? 'polite' : undefined}>
          {state.stale ? `${copy.etaLastKnown} · ` : ''}
          {formatEta(state.etaSeconds)}
        </span>
      )}
    </div>
  );
}
