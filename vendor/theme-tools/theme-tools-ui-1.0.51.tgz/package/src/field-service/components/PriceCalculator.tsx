/**
 * PriceCalculator — interactive inline estimator on the homepage.
 * Uses the same deterministic computeSurge as the booking flow so the
 * displayed estimate matches what the customer will actually pay, now
 * localized in en/es/pt with a 9-service category selector and lossless
 * /book?service=&hours=&crew=&date= prefill.
 */
import { useState } from 'react';
import { Badge, useThemeToolsSurface } from '../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { computeSurge, type SurgeContext } from '@theme.tools/billing/field-service/surge';
import { DEFAULT_HOURLY_RATE_CENTS } from '@theme.tools/billing/field-service/booking-pricing';
import { usd } from '@theme.tools/billing/field-service/money';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { priceCalculatorCopy } from '@theme.tools/billing/field-service/price-calculator-copy';
import {
  CANONICAL_SERVICE_SLUGS,
  resolveServiceAlias,
  type CanonicalServiceSlug,
} from '@theme.tools/seo-geo/field-service/service-slug-aliases';

// Bookable set only — the /book server schema is `hours: z.number().int().min(1)`, so a 30-min
// (0.5) or 1.5h estimate would quote a job the customer CANNOT book (quote≠charge). 15-min blocks
// apply to the final actual-time charge, not this whole-hour upfront estimate.
const HOURS_OPTIONS = [1, 2, 3, 4, 6, 8];
const CREW_OPTIONS = [1, 2, 3, 4];

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'] as const;
const TIMES = ['7am', '9am', '11am', '1pm', '3pm', '5pm', '7pm'] as const;

export function PriceCalculator(): JSX.Element {
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const copy = priceCalculatorCopy(locale);

  const [service, setService] = useState<CanonicalServiceSlug>('moving-labor');
  const [hours, setHours] = useState(2);
  const [crew, setCrew] = useState(2);
  const [showBreakdown, setShowBreakdown] = useState(false);
  // Date/time surge selectors — default to today + 9am
  const today = new Date();
  const [dayOffset, setDayOffset] = useState(0); // 0=today, 1=tomorrow...
  const [timeIdx, setTimeIdx] = useState(1); // 9am default

  const handleServiceChange = (nextSlug: CanonicalServiceSlug) => {
    setService(nextSlug);
    const meta = resolveServiceAlias(nextSlug);
    if (meta) {
      setCrew(meta.defaultCrew);
      setHours(meta.defaultHours);
    }
  };

  // Build surge context with selected date/time and service
  const targetDate = new Date(today);
  targetDate.setDate(targetDate.getDate() + dayOffset);
  const prefDate = targetDate.toISOString().slice(0, 10);
  const prefTime = TIMES[timeIdx]!;
  const ctx: SurgeContext = {
    nowIso: today.toISOString(),
    preferredDate: prefDate,
    preferredTime: prefTime,
    services: [service],
  };
  const surge = computeSurge(ctx);
  const pricingStandard = evaluateHourlyLaborPricingStandard({ crewSize: crew, hours, cadence: 'one-time' });
  const surfaceProps = useThemeToolsSurface('price-calculator', [
    '@theme.tools/ui',
    '@theme.tools/billing',
    '@theme.tools/scheduling',
  ]);
  const baseCents = pricingStandard.baseLaborCents;
  const totalCents = Math.round(baseCents * surge.multiplier);
  const fmt = (c: number) => usd(c);

  const bookHref = localizedPath(
    locale,
    `/book?service=${encodeURIComponent(service)}&hours=${hours}&crew=${crew}&date=${encodeURIComponent(prefDate)}`,
  );

  return (
    <section
      className="w-full max-w-2xl mx-auto py-10 px-4"
      aria-label={copy.ariaLabel}
      data-theme-tools-surface={surfaceProps['data-theme-tools-surface']}
      data-theme-tools-pricing-model={surfaceProps['data-theme-tools-pricing-model']}
      data-theme-tools-packages={surfaceProps['data-theme-tools-packages']}
    >
      <div className="rounded-2xl border border-brand-line bg-brand-card p-6 md:p-8">
        <h2 className="text-xl md:text-2xl font-bold text-brand-ink mb-1">{copy.heading}</h2>
        <p className="text-brand-mute text-sm mb-5">{copy.subheading}</p>

        <div className="mb-4">
          <label className="flex flex-col gap-1">
            <span className="text-xs font-mono uppercase tracking-wider text-brand-mute">
              {copy.serviceLabel}
            </span>
            <select
              value={service}
              onChange={(e) => handleServiceChange(e.target.value as CanonicalServiceSlug)}
              data-testid="price-calc-service"
              className="rounded-lg border border-brand-line bg-bg-primary px-3 py-2.5 text-sm text-brand-ink transition-colors duration-[333ms] focus:outline-none focus:ring-2 focus:ring-brand-accent"
            >
              {CANONICAL_SERVICE_SLUGS.map((slug) => (
                <option key={slug} value={slug}>
                  {copy.serviceNames[slug]}
                </option>
              ))}
            </select>
          </label>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
          <label className="flex flex-col gap-1">
            <span className="text-xs font-mono uppercase tracking-wider text-brand-mute">
              {copy.dayLabel}
            </span>
            <select
              value={dayOffset}
              onChange={(e) => setDayOffset(Number(e.target.value))}
              className="rounded-lg border border-brand-line bg-bg-primary px-2 py-2.5 text-xs text-brand-ink focus:outline-none focus:ring-2 focus:ring-brand-accent"
            >
              {Array.from({ length: 7 }, (_, i) => (
                <option key={i} value={i}>
                  {i === 0
                    ? copy.todayOption
                    : i === 1
                      ? copy.tomorrowOption
                      : DAYS[(today.getDay() + i) % 7]}
                </option>
              ))}
            </select>
          </label>
          <label className="flex flex-col gap-1">
            <span className="text-xs font-mono uppercase tracking-wider text-brand-mute">
              {copy.timeLabel}
            </span>
            <select
              value={timeIdx}
              onChange={(e) => setTimeIdx(Number(e.target.value))}
              className="rounded-lg border border-brand-line bg-bg-primary px-2 py-2.5 text-xs text-brand-ink focus:outline-none focus:ring-2 focus:ring-brand-accent"
            >
              {TIMES.map((t, i) => (
                <option key={t} value={i}>
                  {t}
                </option>
              ))}
            </select>
          </label>
          <label className="flex flex-col gap-1">
            <span className="text-xs font-mono uppercase tracking-wider text-brand-mute">
              {copy.hoursLabel}
            </span>
            <select
              value={hours}
              onChange={(e) => setHours(Number(e.target.value))}
              className="rounded-lg border border-brand-line bg-bg-primary px-3 py-2.5 text-sm text-brand-ink focus:outline-none focus:ring-2 focus:ring-brand-accent"
            >
              {HOURS_OPTIONS.map((h) => (
                <option key={h} value={h}>
                  {`${h} ${h > 1 ? copy.hourPlural : copy.hourSingular}`}
                </option>
              ))}
            </select>
          </label>

          <label className="flex flex-col gap-1">
            <span className="text-xs font-mono uppercase tracking-wider text-brand-mute">
              {copy.crewLabel}
            </span>
            <select
              value={crew}
              onChange={(e) => setCrew(Number(e.target.value))}
              className="rounded-lg border border-brand-line bg-bg-primary px-3 py-2.5 text-sm text-brand-ink focus:outline-none focus:ring-2 focus:ring-brand-accent"
            >
              {CREW_OPTIONS.map((c) => (
                <option key={c} value={c}>
                  {`${c} ${c > 1 ? copy.personPlural : copy.personSingular}`}
                </option>
              ))}
            </select>
          </label>
        </div>

        <div
          className="rounded-xl bg-bg-primary border border-brand-line p-5 text-center"
          aria-live="polite"
        >
          <div className="flex items-center justify-center gap-3 mb-1">
            <span className="text-4xl md:text-5xl font-extrabold text-brand-ink tracking-tight tabular-nums">
              {fmt(totalCents)}
            </span>
            {surge.multiplier > 1.05 && (
              <Badge variant="warning">
                +{Math.round((surge.multiplier - 1) * 100)}% {copy.surgeBadgeSuffix}
              </Badge>
            )}
            {surge.multiplier <= 1.05 && (
              <Badge variant="success">
                {copy.bestRateBadge}
              </Badge>
            )}
          </div>
          <div className="text-sm text-brand-mute mt-1">
            {crew} {crew > 1 ? copy.personPlural : copy.personSingular} · {hours}{' '}
            {hours > 1 ? copy.hourPlural : copy.hourSingular} · ${DEFAULT_HOURLY_RATE_CENTS / 100}
            {copy.perHourPerPerson} · {DAYS[(today.getDay() + dayOffset) % 7]} {prefTime}
          </div>
          {surge.multiplier > 1.05 && dayOffset === 0 && (
            <p className="mt-2 text-xs text-brand-accent font-mono">{copy.skipSurgeHint}</p>
          )}

          <button
            type="button"
            aria-expanded={showBreakdown}
            onClick={() => setShowBreakdown(!showBreakdown)}
            className="mt-3 inline-flex min-h-6 items-center rounded text-xs font-mono text-brand-accent hover:underline focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
          >
            {showBreakdown ? copy.hideDetails : copy.showDetails}
          </button>

          {showBreakdown && surge.reasons.length > 0 && (
            <div className="mt-4 space-y-1 text-xs text-brand-mute font-mono">
              {surge.reasons.map((r, i) => (
                <div key={i} className="flex justify-between max-w-xs mx-auto">
                  <span title={r.detail}>{r.label}</span>
                  <span className="text-brand-ink">
                    {r.factor > 1 ? `+${Math.round((r.factor - 1) * 100)}%` : '—'}
                  </span>
                </div>
              ))}
              <div className="flex justify-between max-w-xs mx-auto pt-2 mt-2 border-t border-brand-line">
                <span>{copy.surgeMultiplierLabel}</span>
                <span className="text-brand-ink font-bold">{surge.multiplier.toFixed(2)}×</span>
              </div>
            </div>
          )}

          <a
            href={bookHref}
            data-testid="price-calc-book-cta"
            className="inline-block mt-5 rounded-lg bg-brand-accent px-6 py-3 text-sm font-bold text-bg-primary hover:bg-brand-accent/90 transition-colors duration-[333ms] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent focus-visible:ring-offset-2 focus-visible:ring-offset-brand-card"
          >
            {copy.bookCta}
          </a>
        </div>

        <p className="text-[11px] text-brand-mute text-center mt-4">{copy.disclaimer}</p>
      </div>
    </section>
  );
}
