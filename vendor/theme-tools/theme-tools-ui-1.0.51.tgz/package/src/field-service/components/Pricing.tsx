import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { useMemo, useState } from 'react';
import { computeFlatRateCap, type SurgeContext } from '@theme.tools/billing/field-service/surge';
import { SurgeBreakdownWidget } from './SurgeBreakdownWidget.js';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { pricingCopy } from '@theme.tools/i18n-a11y/field-service/pricing-copy';
import { useRovingRadio } from '../use-roving-radio.js';
import { useFeatureFlag } from '../use-feature-flag.js';
import { RecurringDiscountWidget } from './RecurringDiscountWidget.js';
import { CANONICAL_SERVICE_SLUGS, resolveServiceAlias } from '@theme.tools/seo-geo/field-service/service-slug-aliases';
import { calculateCategoryScope } from '@theme.tools/scheduling/field-service/category-calculators';
import { evaluateCurbAndParkingClearance } from '@theme.tools/scheduling/field-service/theme-tools-field-service-bridge';

type RateMode = 'hourly' | 'flat-cap';

function buildSampleContext(): SurgeContext {
  // Sample = Saturday two-days-out, mid-afternoon — fires weekend (+10%).
  // Deterministic relative to "today" so the page is stable for SEO snapshots.
  const today = new Date();
  const target = new Date(today);
  const dow = today.getUTCDay();
  const daysToSat = (6 - dow + 7) % 7 || 7;
  target.setUTCDate(today.getUTCDate() + daysToSat);
  const yyyy = target.getUTCFullYear();
  const mm = String(target.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(target.getUTCDate()).padStart(2, '0');
  return {
    preferredDate: `${yyyy}-${mm}-${dd}`,
    preferredTime: '14:00',
  };
}

function formatUsd(amount: number): string {
  return amount.toLocaleString('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  });
}

export function Pricing() {
  useThemeToolsSurface('pricing');
  const [mode, setMode] = useState<RateMode>('hourly');
  // ARIA roving-tabindex keyboard contract for the custom rate-mode radiogroup
  // (axe-blind interaction gap — see use-roving-radio). Order: 0=hourly, 1=flat-cap.
  const modeRadio = useRovingRadio(2, (i) => setMode(i === 0 ? 'hourly' : 'flat-cap'));
  const sampleCtx = useMemo(buildSampleContext, []);
  const flatCap = useMemo(
    () => computeFlatRateCap(sampleCtx, { baseHourlyRate: 50, crewSize: 2, hours: 3 }),
    [sampleCtx],
  );
  // Locale read off the URL (SSR-safe `en` default), mirroring Hero/Services —
  // the prerendered mirror is a pure SPA shell, so the runtime React path is the
  // primary localization for the `/es` + `/pt` pricing section.
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  // Keep a mirror-locale visitor in /es · /pt: localize internal `/` hrefs;
  // leave mailto:/tel:/external + static-asset paths bare.
  const lp = (p: string) => (p.startsWith('/') ? localizedPath(locale, p) : p);
  const t = pricingCopy(locale);
  // fire-40: wires the previously-orphaned 12-week recurring-savings visualizer into #pricing,
  // flag-gated default-OFF (dark-infra-light-up — the loop wires+verifies, Brian promotes).
  const savingsOn = useFeatureFlag('pricing_recurring_savings');

  return (
    <section
      id="pricing"
      className="section bg-bg-elevated/40 border-y border-brand-line"
      data-animate="scale-up"
    >
      <div className="container-pad">
        <div className="mb-14 max-w-3xl" data-animate="fade-up">
          <p className="eyebrow mb-3">{t.eyebrow}</p>
          <h2 className="text-4xl sm:text-5xl font-extrabold">
            {t.headlineMain}
            <span className="text-gradient">{t.headlineAccent}</span>
          </h2>
          <p className="mt-4 text-lg text-brand-mute">
            {t.leadPre}
            <a
              href={lp('/blog/fifty-dollar-hour-per-person-philosophy')}
              className="text-brand-ink underline-hover"
            >
              {t.leadRateLink}
            </a>
            {t.leadPost}
          </p>
          <p className="mt-3 text-sm text-brand-mute">
            {t.biggerPre}
            <strong className="text-brand-ink">{t.biggerDayRates}</strong>
            {t.biggerMid1}
            <strong className="text-brand-ink">{t.biggerMultiDay}</strong>
            {t.biggerMid2}
            <strong className="text-brand-ink">{t.biggerRecurring}</strong>
            {t.biggerPost}
            <a href="#contact" className="text-brand-accent underline-hover">
              {t.requestQuote}
            </a>
            .
          </p>
          <p className="mt-3 text-xs text-brand-mute leading-relaxed">
            {t.whyFlatPre}
            <strong className="text-brand-ink">{t.wage1}</strong>
            {t.whyFlatMid1}
            <strong className="text-brand-ink">{t.wage2}</strong>
            {t.whyFlatMid2}
            <em>{t.plusMaterials}</em>
            {t.whyFlatPost}
            <a href={lp('/sources')} className="text-brand-accent underline-hover">
              {t.seeBls}
            </a>
          </p>
          <p className="mt-4 text-sm text-brand-mute">
            {t.sameRatePre}
            <a href={lp('/services/power-washing')} className="text-brand-accent underline-hover">
              {t.linkPowerWashing}
            </a>
            ,{' '}
            <a href={lp('/services/lawn-care')} className="text-brand-accent underline-hover">
              {t.linkLawnCare}
            </a>
            ,{' '}
            <a href={lp('/services/hauling')} className="text-brand-accent underline-hover">
              {t.linkHauling}
            </a>
            ,{' '}
            <a href={lp('/services/light-repairs')} className="text-brand-accent underline-hover">
              {t.linkLightRepairs}
            </a>
            {t.sameRateMid}
            <a href={lp('/#coverage')} className="text-brand-accent underline-hover">
              {t.coverageMap}
            </a>
            .
          </p>
        </div>
        <div
          className="mb-8 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"
          data-animate="fade-up"
        >
          <div
            role="radiogroup"
            aria-label={t.radiogroupLabel}
            className="inline-flex rounded-full border border-brand-line bg-bg-primary p-1"
          >
            <button
              type="button"
              role="radio"
              aria-checked={mode === 'hourly'}
              onClick={() => setMode('hourly')}
              {...modeRadio(0, mode === 'hourly')}
              className={`rounded-full px-4 py-1.5 text-sm font-medium transition ${
                mode === 'hourly'
                  ? 'bg-brand-accent/15 text-brand-accent'
                  : 'text-brand-mute hover:text-brand-ink'
              }`}
            >
              {t.modeHourly}
            </button>
            <button
              type="button"
              role="radio"
              aria-checked={mode === 'flat-cap'}
              onClick={() => setMode('flat-cap')}
              {...modeRadio(1, mode === 'flat-cap')}
              className={`rounded-full px-4 py-1.5 text-sm font-medium transition ${
                mode === 'flat-cap'
                  ? 'bg-brand-accent/15 text-brand-accent'
                  : 'text-brand-mute hover:text-brand-ink'
              }`}
            >
              {t.modeFlatCap}
            </button>
          </div>
          {mode === 'flat-cap' && (
            <p className="text-xs text-brand-mute">
              {t.flatCapQuotePre}
              {formatUsd(flatCap.flatRate)}
              {t.flatCapCappedAt}
              <strong className="text-brand-ink">{formatUsd(flatCap.cap)}</strong>
              {t.flatCapNeverMore}
            </p>
          )}
        </div>

        {mode === 'flat-cap' && (
          <div
            className="mb-8 rounded-xl border border-brand-accent/30 bg-brand-accent/5 p-5 sm:p-6"
            data-animate="fade-up"
          >
            <h3 className="font-display text-lg font-bold text-brand-ink">{t.flatCapMathTitle}</h3>
            <p className="mt-1 text-sm text-brand-mute">
              {t.flatCapMathPre}
              {formatUsd(flatCap.flatRate)}
              {t.flatCapMathFlat}
              {formatUsd(flatCap.cap)}
              {t.flatCapMathCap}
              {flatCap.surge.toFixed(2)}
              {t.flatCapMathToday}
            </p>
            <div className="mt-4">
              <SurgeBreakdownWidget
                ctx={sampleCtx}
                baseHourlyRate={50}
                crewSize={2}
                hours={3}
                variant="card"
              />
            </div>
          </div>
        )}

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="card lg:col-span-1 relative overflow-hidden" data-animate="slide-right">
            <div className="absolute inset-0 grid-pattern opacity-30" aria-hidden />
            <div className="relative">
              <div className="font-mono text-xs uppercase tracking-widest text-brand-accent">
                {t.hourlyRateLabel}
              </div>
              <div className="mt-3 flex items-baseline gap-1">
                <span className="font-display text-7xl font-extrabold text-brand-ink">
                  <span data-count="50" data-count-prefix="$">
                    $50
                  </span>
                </span>
                <span className="text-brand-mute">{t.perHour}</span>
              </div>
              <p className="mt-1 text-sm font-mono text-brand-accent">{t.perPersonCrew}</p>
              <p className="mt-4 text-sm text-brand-mute">
                {t.hourlyBodyPre}
                <strong className="text-brand-ink">{t.fifteenMinBlocks}</strong>
                {t.hourlyBodyPost}
              </p>
              <a href={lp('/book')} className="btn-primary btn-arrow mt-7 w-full">
                {t.bookCta}
                <span data-btn-arrow aria-hidden>
                  →
                </span>
              </a>
              <p className="mt-3 text-center text-xs text-brand-mute">{t.prepayNote}</p>
            </div>
          </div>

          <div className="card lg:col-span-2" data-animate="slide-left" data-delay="120">
            <h3 className="font-display text-xl font-bold mb-1">{t.includedTitle}</h3>
            <p className="text-sm text-brand-mute mb-5">{t.includedSub}</p>
            <ul className="grid sm:grid-cols-2 gap-2.5">
              {t.included.map((item) => (
                <li key={item} className="flex items-start gap-2 text-sm">
                  <svg
                    viewBox="0 0 24 24"
                    className="h-5 w-5 shrink-0 text-brand-accent mt-0.5"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth={2.4}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden
                  >
                    <path d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-brand-ink">{item}</span>
                </li>
              ))}
            </ul>

            <h3 className="font-display text-xl font-bold mt-8 mb-1">{t.passThroughTitle}</h3>
            <p className="text-sm text-brand-mute mb-5">{t.passThroughSub}</p>
            <ul className="grid sm:grid-cols-2 gap-2.5">
              {t.notIncluded.map((item) => (
                <li key={item} className="flex items-start gap-2 text-sm">
                  <svg
                    viewBox="0 0 24 24"
                    className="h-5 w-5 shrink-0 text-brand-mute mt-0.5"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth={2.4}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden
                  >
                    <path d="M12 8v4m0 4h.01M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0z" />
                  </svg>
                  <span className="text-brand-mute">{item}</span>
                </li>
              ))}
            </ul>

            <div className="mt-8 grid gap-3 sm:grid-cols-2">
              <div className="rounded-lg border border-brand-line bg-bg-primary px-4 py-3 text-xs text-brand-mute">
                <strong className="text-brand-ink">{t.crewMathBold}</strong>
                {t.crewMathBody1}
                <span className="text-brand-accent font-mono">$300</span>
                {t.crewMathBody2}
              </div>
              <div className="rounded-lg border border-brand-accent/40 bg-brand-accent/5 px-4 py-3 text-xs text-brand-mute">
                <strong className="text-brand-ink">{t.byDayBold}</strong>
                {t.byDayBody}
                <a href="#contact" className="text-brand-accent underline-hover">
                  {t.getQuote}
                </a>
              </div>
              <div className="sm:col-span-2 rounded-lg border border-brand-accent/40 bg-brand-accent/5 px-4 py-3 text-xs text-brand-mute">
                <strong className="text-brand-ink">{t.uhaulBold}</strong>
                {t.uhaulBody}
                <a href={lp('/book')} className="text-brand-accent underline-hover">
                  {t.addUhauls}
                </a>
              </div>
            </div>
          </div>
        </div>

        {savingsOn && (
          <div className="mt-10" data-animate="fade-up">
            <RecurringDiscountWidget bookHref={lp('/book')} />
          </div>
        )}

        <div
          className="mt-10 rounded-xl border border-brand-line bg-bg-primary/70 p-5 sm:p-6"
          data-testid="pricing-category-matrix"
        >
          <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
            <div>
              <p className="font-mono text-xs uppercase tracking-wider text-brand-accent">
                All 9 Services · Same $50/hr Per Crew Member Rate
              </p>
              <h3 className="font-display text-xl font-bold text-brand-ink">
                Typical Crew, Hours & Curb Clearance by Category
              </h3>
            </div>
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {CANONICAL_SERVICE_SLUGS.map((slug) => {
              const meta = resolveServiceAlias(slug);
              const label = meta?.displayName ?? slug;
              const scope = calculateCategoryScope({ category: slug });
              const curb = evaluateCurbAndParkingClearance({ categorySlug: slug });
              const bookUrl = lp(scope.bookingHref);
              return (
                <div
                  key={slug}
                  className="flex flex-col justify-between rounded-lg border border-brand-line bg-bg-elevated/60 p-4"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <a
                        href={lp(`/services/${slug}`)}
                        className="font-display text-sm font-bold text-brand-ink hover:text-brand-accent"
                      >
                        {label}
                      </a>
                      <span className="font-mono text-xs font-bold text-brand-accent">
                        ${Math.round(scope.baseLaborCents / 100)} est.
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-brand-mute">
                      {scope.recommendedCrew} crew × {scope.recommendedHours}h ·{' '}
                      {curb.requiredCurbLengthFt} ft curb clearance
                    </p>
                    <div className="mt-2 flex flex-wrap gap-1">
                      {scope.equipmentPills.slice(0, 2).map((eq: string) => (
                        <span
                          key={eq}
                          className="rounded border border-brand-line/70 bg-bg-primary px-2 py-0.5 text-[11px] text-brand-mute"
                        >
                          {eq}
                        </span>
                      ))}
                    </div>
                  </div>
                  <a
                    href={bookUrl}
                    className="mt-3 inline-flex min-h-[44px] items-center justify-between rounded-lg border border-brand-accent/40 bg-brand-accent/10 px-3 py-2 text-xs font-semibold text-brand-accent hover:bg-brand-accent/20"
                  >
                    <span>Book {label}</span>
                    <span aria-hidden>→</span>
                  </a>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
