import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect } from 'react';
import { PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';

const TITLE = 'Privacy Policy · Brick Labor — Newark NJ Property Crew';
const DESC =
  'How Brick Labor handles your name, email, phone, and address when you book casual property work in Newark NJ. Plain English, no dark patterns.';
const LAST_UPDATED = '2026-06-25';

export function Privacy() {
  useThemeToolsSurface('privacy');
  useEffect(() => {
    document.title = TITLE;
    setMeta('description', DESC);
    setLink('canonical', 'https://bricklabor.com/privacy');
    setMeta('robots', 'index,follow', 'name');
  }, []);

  return (
    <article className="section">
      <div className="container-pad max-w-3xl">
        <p className="eyebrow mb-3">Legal</p>
        <h1 className="text-4xl sm:text-5xl font-extrabold mb-2 text-brand-ink">Privacy Policy</h1>
        <p className="text-brand-mute mb-6">Last updated: {LAST_UPDATED}</p>

        <aside
          role="note"
          aria-label="Attorney review recommended"
          className="mb-10 rounded-md border border-amber-400/40 bg-amber-400/10 p-4 text-amber-100"
        >
          <p className="text-sm leading-relaxed">
            <strong className="font-bold">Heads up:</strong> This document was drafted with AI
            assistance. We strongly recommend having a licensed attorney review it before relying on
            it for your business or as a binding privacy notice for yours.
          </p>
        </aside>

        <nav
          aria-label="On this page"
          className="mb-10 rounded-md border border-brand-line bg-bg-elevated/40 p-5 text-sm"
        >
          <p className="eyebrow mb-3">On this page</p>
          <ol className="grid gap-1 sm:grid-cols-2">
            <li>
              <a href="#data-collected" className="text-brand-accent underline-hover">
                1. Data we collect
              </a>
            </li>
            <li>
              <a href="#why" className="text-brand-accent underline-hover">
                2. Why we collect it
              </a>
            </li>
            <li>
              <a href="#third-parties" className="text-brand-accent underline-hover">
                3. Third parties &amp; sub-processors
              </a>
            </li>
            <li>
              <a href="#retention" className="text-brand-accent underline-hover">
                4. Retention
              </a>
            </li>
            <li>
              <a href="#deletion" className="text-brand-accent underline-hover">
                5. Deletion rights &amp; DSAR
              </a>
            </li>
            <li>
              <a href="#sms-opt-out" className="text-brand-accent underline-hover">
                6. SMS opt-out
              </a>
            </li>
            <li>
              <a href="#cookies" className="text-brand-accent underline-hover">
                7. Cookies &amp; tracking
              </a>
            </li>
            <li>
              <a href="#rights" className="text-brand-accent underline-hover">
                8. CCPA &amp; GDPR rights
              </a>
            </li>
            <li>
              <a href="#new-jersey" className="text-brand-accent underline-hover">
                9. New Jersey rights &amp; appeals
              </a>
            </li>
            <li>
              <a href="#children" className="text-brand-accent underline-hover">
                10. Children
              </a>
            </li>
            <li>
              <a href="#security" className="text-brand-accent underline-hover">
                11. Security
              </a>
            </li>
            <li>
              <a href="#changes" className="text-brand-accent underline-hover">
                12. Changes to this policy
              </a>
            </li>
          </ol>
        </nav>

        <div className="space-y-10 text-brand-mute leading-relaxed [text-wrap:pretty]">
          <section id="data-collected">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">
              1. Data we collect
            </h2>
            <p>
              We collect only what we need to dispatch a crew, complete payment, and follow up
              afterwards. Specifically:
            </p>
            <ul className="mt-3 list-disc space-y-2 pl-6">
              <li>
                <strong>Identity</strong> — name, email address, phone number (normalized to E.164,
                e.g. +12015551234).
              </li>
              <li>
                <strong>Service address</strong> — the street, ZIP, and any unit number you supply
                so the crew can reach the job. We retain the full address for active bookings and
                truncate it to ZIP-only for analytics after 90 days.
              </li>
              <li>
                <strong>Payment metadata</strong> — last four digits of your payment card,
                card-brand, your Square customer ID, and (for crew members receiving payouts) your
                Stripe Connect account ID. <strong>We never see or store the full PAN.</strong> Card
                vaulting and PCI scope live entirely with Square.
              </li>
              <li>
                <strong>Booking details</strong> — service requested, crew size, scheduled date and
                time, hours estimated, notes you typed, any photos you uploaded to the "what needs
                doing" field.
              </li>
              <li>
                <strong>Device + network signals</strong> — IP address, user-agent string, screen
                size, referring URL, time-zone offset. Geolocation only when you explicitly grant
                browser permission (used to prefill your ZIP).
              </li>
              <li>
                <strong>Conversation logs</strong> — messages you send to our AI Concierge or AI
                Chat, including the model's responses.
              </li>
              <li>
                <strong>Behavioral analytics</strong> — page views, scroll depth, button clicks,
                form submissions, recorded via PostHog and Google Analytics 4 with cookie-free
                in-memory persistence where supported.
              </li>
              <li>
                <strong>Audit log</strong> — timestamped record of every state change on your
                booking (created, paid, dispatched, completed, canceled) for fraud prevention and
                dispute resolution.
              </li>
            </ul>
          </section>

          <section id="why">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">
              2. Why we collect it
            </h2>
            <ul className="mt-3 list-disc space-y-2 pl-6">
              <li>
                <strong>Booking fulfillment</strong> — to show the crew where to go, when, and how
                to reach you if a gate is locked or there is a parking problem.
              </li>
              <li>
                <strong>Dispatch and on-the-way ETAs</strong> — to message you when a crew member is
                en route, late, or has arrived.
              </li>
              <li>
                <strong>Payments and receipts</strong> — to charge the deposit and balance, refund
                cancellations, and send tax-time receipts.
              </li>
              <li>
                <strong>Fraud prevention</strong> — to detect repeat chargeback patterns,
                impossible-velocity bookings, and stolen-card use; we may decline a booking that
                fails these signals.
              </li>
              <li>
                <strong>Service quality</strong> — to send the one-time post-job review request and
                aggregate ratings into crew member dashboards.
              </li>
              <li>
                <strong>Product analytics</strong> — to see which pages are reached, which steps in
                the booking funnel drop off, and where the site is slow.
              </li>
            </ul>
          </section>

          <section id="third-parties">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">
              3. Third parties &amp; sub-processors
            </h2>
            <p>
              We use the following service providers. Each receives only the data necessary for
              their slice of the service, and each is contractually bound to use it only for that
              purpose:
            </p>
            <ul className="mt-3 list-disc space-y-2 pl-6">
              <li>
                <strong>Square, Inc.</strong> — customer payment processing (cards, Apple Pay, Cash
                App Pay), card vaulting, refunds. Receives: name, email, phone, card data, booking
                total.
              </li>
              <li>
                <strong>Stripe, Inc.</strong> — crew payouts via Stripe Connect Express, 1099-NEC
                tax forms. Receives: crew member name, email, SSN/EIN (collected directly by Stripe
                in their onboarding flow, not stored by BCL), payout amounts.
              </li>
              <li>
                <strong>Twilio, Inc.</strong> — outbound SMS, inbound SMS reply handling, voice
                fallback. Receives: phone number, message body.
              </li>
              <li>
                <strong>Resend, Inc.</strong> — transactional email (confirmations, receipts,
                magic-link auth, review requests). Receives: email address, message body.
              </li>
              <li>
                <strong>Cloudflare, Inc.</strong> — website hosting, edge compute (Workers), CDN,
                bot protection (Turnstile), AI Gateway, error tracking. Receives: every HTTP request
                and the data it contains.
              </li>
              <li>
                <strong>Google LLC</strong> — Google Places (address autocomplete and geocoding),
                Google Maps (embedded maps), Google Analytics 4 via Google Tag Manager. Receives:
                address strings you type, page-view events, anonymized IP.
              </li>
              <li>
                <strong>Anthropic, PBC</strong> — Claude API powering the AI Concierge and AI Chat.
                Receives: your chat messages and any context attached to them. No training on user
                data per Anthropic's API terms.
              </li>
              <li>
                <strong>PostHog, Inc.</strong> — product analytics, session replay (sampled),
                feature flags. Receives: page views, click events, anonymized IP.
              </li>
              <li>
                <strong>Functional Software, Inc. d/b/a Sentry</strong> — error and exception
                tracking for the worker and the website. Receives: stack traces, request IDs,
                anonymized IP.
              </li>
            </ul>
            <p className="mt-3">
              We do not sell, rent, or trade your personal information to advertisers, data brokers,
              or any third party for their own purposes.
            </p>
          </section>

          <section id="retention">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">4. Retention</h2>
            <ul className="mt-3 list-disc space-y-2 pl-6">
              <li>
                <strong>Tax and payment records</strong> — 7 years from the date of the transaction,
                as required by IRS recordkeeping rules and state revenue rules.
              </li>
              <li>
                <strong>AI Concierge and AI Chat transcripts</strong> — 18 months from the last
                message in the conversation, after which transcripts are deleted from our database
                and from the model provider's logs (per Anthropic's 30-day retention default for API
                logs).
              </li>
              <li>
                <strong>Dispatch and ETA SMS logs</strong> — 90 days after the job completion date,
                then purged. Inbound STOP/HELP/YES/NO replies are kept indefinitely for TCPA
                compliance evidence.
              </li>
              <li>
                <strong>Booking audit log</strong> — 3 years after the job completion date.
              </li>
              <li>
                <strong>Analytics events</strong> — 14 months in PostHog and Google Analytics 4,
                then automatically aged out.
              </li>
              <li>
                <strong>Account record</strong> — retained as long as the account is active; 90 days
                after a deletion request (so we can reverse the deletion if you change your mind),
                then permanently purged.
              </li>
            </ul>
          </section>

          <section id="deletion">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">
              5. Deletion rights &amp; DSAR endpoint
            </h2>
            <p>
              You have the right to request access to, correction of, export of, and deletion of the
              personal data we hold about you. To file a Data Subject Access Request (DSAR), email{' '}
              <a href="mailto:hey@bricklabor.com" className="text-brand-accent underline-hover">
                hey@bricklabor.com
              </a>{' '}
              with the subject <code>DSAR</code> and one of: <code>ACCESS</code>,{' '}
              <code>CORRECTION</code>, <code>EXPORT</code>, or <code>DELETE</code>. Include the
              email address and phone number on the account so we can verify your identity.
            </p>
            <p className="mt-3">
              We respond within <strong>30 days</strong> of receiving a verifiable request, or
              within the timeline required by applicable law (45 days for CCPA with an optional
              45-day extension; one month for GDPR). Some records may be retained beyond a deletion
              request to satisfy legal obligations (tax records, dispute evidence, fraud
              prevention), in which case we will tell you which categories were retained and why.
            </p>
            <p className="mt-3">
              If we decline your request, you can appeal — see{' '}
              <a href="#new-jersey" className="text-brand-accent underline-hover">
                Section 9 (New Jersey rights &amp; appeals)
              </a>
              .
            </p>
          </section>

          <section id="sms-opt-out">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">6. SMS opt-out</h2>
            <p>You can stop SMS at any time, two ways:</p>
            <ul className="mt-3 list-disc space-y-2 pl-6">
              <li>
                Reply <code>STOP</code> to any BCL SMS. The opt-out is immediate, permanent for that
                number, and we will send one confirmation message and then no further texts except
                those required for an in-flight booking already in the dispatch queue.
              </li>
              <li>
                Toggle "SMS notifications" off in your{' '}
                <a href="/me" className="text-brand-accent underline-hover">
                  customer dashboard
                </a>{' '}
                or in your{' '}
                <a href="/work/dashboard" className="text-brand-accent underline-hover">
                  crew dashboard
                </a>
                .
              </li>
            </ul>
            <p className="mt-3">
              Reply <code>HELP</code> to any BCL SMS for our contact information. Reply{' '}
              <code>START</code> to resume after a previous STOP.
            </p>
          </section>

          <section id="cookies">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">
              7. Cookies &amp; tracking
            </h2>
            <p>
              We use a small set of cookies. We do not use third-party advertising cookies and we do
              not run pixel-based retargeting.
            </p>
            <ul className="mt-3 list-disc space-y-2 pl-6">
              <li>
                <strong>
                  <code>bcl_cust_sid</code>
                </strong>{' '}
                — 14-day customer session, HttpOnly, Secure, SameSite=Lax, used at <code>/me</code>{' '}
                and during checkout.
              </li>
              <li>
                <strong>
                  <code>bcl_work_sid</code>
                </strong>{' '}
                — 30-day crew session, HttpOnly, Secure, SameSite=Lax, used at{' '}
                <code>/work/dashboard</code>.
              </li>
              <li>
                <strong>PostHog</strong> — configured to use in-memory persistence where possible
                (no cross-site identifier).
              </li>
              <li>
                <strong>Google Analytics 4</strong> — first-party cookie scoped to
                bricklabor.com, IP-anonymized.
              </li>
            </ul>
            <p className="mt-3">
              The PostHog and Google Analytics 4 cookies above are{' '}
              <strong>off by default</strong>. On your first visit we show a consent banner; analytics
              load only after you choose <strong>Accept</strong>. Decline and only the
              strictly-necessary session cookies are set. You can change your choice anytime via the{' '}
              <strong>Cookie preferences</strong> link in the footer.
            </p>
            <p className="mt-3">
              We honor the browser <strong>Do Not Track (DNT)</strong> signal and the Global Privacy
              Control (GPC) signal: when GPC is set we treat it as a universal opt-out, suppress the
              banner, disable analytics on that session, and set only strictly-necessary session
              cookies.
            </p>
          </section>

          <section id="rights">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">
              8. CCPA &amp; GDPR rights
            </h2>
            <p>
              If you are a California resident, the California Consumer Privacy Act (CCPA, as
              amended by the CPRA) gives you the right to know, delete, correct, and limit the use
              of sensitive personal information; to opt out of sale or sharing for cross-context
              behavioral advertising; and to be free from retaliation for exercising these rights.
              We do not sell or share personal information for cross-context behavioral advertising.
            </p>
            <p className="mt-3">
              If you are in the European Economic Area, the United Kingdom, or Switzerland, the
              General Data Protection Regulation (GDPR) and the UK GDPR give you the right to
              access, rectify, erase, restrict processing of, object to processing of, and port your
              personal data, and the right to lodge a complaint with your supervisory authority. Our
              legal bases for processing are: <strong>contract</strong> (to deliver the booking you
              requested), <strong>legitimate interest</strong> (fraud prevention, service quality,
              product analytics), <strong>consent</strong> (SMS notifications, optional
              geolocation), and <strong>legal obligation</strong> (tax recordkeeping, TCPA records).
            </p>
            <p className="mt-3">Exercise any of these rights via the DSAR process in Section 5.</p>
          </section>

          <section id="new-jersey">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">
              9. New Jersey rights &amp; appeals
            </h2>
            <p>
              Brick Labor is a Newark, New Jersey business and most of our customers are New Jersey
              residents, so the <strong>New Jersey Data Privacy Act (NJDPA)</strong> applies. As a
              New Jersey resident you have the right to:
            </p>
            <ul className="mt-3 list-disc space-y-2 pl-6">
              <li>
                <strong>Confirm &amp; access</strong> — ask whether we process your personal data and
                get a copy of it.
              </li>
              <li>
                <strong>Correct</strong> — fix inaccuracies in the personal data we hold about you.
              </li>
              <li>
                <strong>Delete</strong> — ask us to delete personal data we collected from you.
              </li>
              <li>
                <strong>Portability</strong> — receive your data in a portable, machine-readable
                format.
              </li>
              <li>
                <strong>Opt out</strong> of the processing of your personal data for{' '}
                <strong>targeted advertising</strong>, the <strong>sale</strong> of personal data,
                or <strong>profiling</strong> in furtherance of decisions that produce a legal or
                similarly significant effect. We do not sell your data or run targeted advertising,
                and we honor the Global Privacy Control signal as a universal opt-out (see Section
                7).
              </li>
            </ul>
            <p className="mt-3">
              File any of these requests through the DSAR process in{' '}
              <a href="#deletion" className="text-brand-accent underline-hover">
                Section 5
              </a>
              . We respond to a verifiable New Jersey request within{' '}
              <strong>45 days</strong>, with one 45-day extension where reasonably necessary (we will
              tell you if we need it).
            </p>
            <p className="mt-3">
              <strong>Appeals.</strong> If we decline to act on your request, you may appeal within a
              reasonable period by emailing{' '}
              <a href="mailto:hey@bricklabor.com" className="text-brand-accent underline-hover">
                hey@bricklabor.com
              </a>{' '}
              with the subject <code>DSAR APPEAL</code>. We will respond to your appeal in writing
              within <strong>45 days</strong> and explain the reasons for any decision. If we deny
              the appeal, you may submit a complaint to the{' '}
              <a
                href="https://www.njoag.gov/about/divisions-and-offices/division-of-consumer-affairs-home/"
                rel="noopener noreferrer"
                target="_blank"
                className="text-brand-accent underline-hover"
              >
                New Jersey Division of Consumer Affairs
              </a>{' '}
              (Office of the Attorney General), which enforces the NJDPA.
            </p>
          </section>

          <section id="children">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">10. Children</h2>
            <p>
              The BCL service is not directed at children under 13, and we do not knowingly collect
              personal information from anyone under 13. If we learn that we have inadvertently
              collected information from a child under 13, we will delete it promptly. If you
              believe we have such information, contact{' '}
              <a href="mailto:hey@bricklabor.com" className="text-brand-accent underline-hover">
                hey@bricklabor.com
              </a>
              .
            </p>
          </section>

          <section id="security">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">11. Security</h2>
            <ul className="mt-3 list-disc space-y-2 pl-6">
              <li>
                <strong>Transport</strong> — TLS 1.3 with HSTS preload, all HTTP redirected to HTTPS
                at the edge, Content Security Policy with strict-dynamic.
              </li>
              <li>
                <strong>Sessions</strong> — opaque session tokens are SHA-256 hashed before being
                stored in our database; the raw token is never logged.
              </li>
              <li>
                <strong>Data at rest</strong> — encrypted by Cloudflare D1 at the storage layer.
              </li>
              <li>
                <strong>Payments</strong> — full card numbers are never seen or stored by BCL; card
                vaulting lives entirely inside Square's PCI-DSS Level 1 environment.
              </li>
              <li>
                <strong>Bot protection</strong> — Cloudflare Turnstile on every form submission,
                rate-limiting on every public endpoint.
              </li>
              <li>
                <strong>Breach notification</strong> — if we discover a security incident affecting
                your personal data, we will notify affected users within <strong>72 hours</strong>{' '}
                of confirmation, by email and (if applicable) by SMS, with what happened, what data
                was involved, and what we are doing about it.
              </li>
            </ul>
          </section>

          <section id="changes">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">
              12. Changes to this policy
            </h2>
            <p>
              We will update this policy as our practices evolve. For non-material changes
              (formatting, link updates, clarifications) we will update the "Last updated" date at
              the top of this page. For <strong>material changes</strong> (new data category, new
              sub-processor with access to your data, new sharing practice, new retention period),
              we will provide at least <strong>30 days' notice</strong> by email to the address on
              your account and by an in-app banner the next time you sign in.
            </p>
          </section>

          <section id="contact" className="border-t border-brand-line pt-8">
            <h2 className="mt-0 mb-4 text-2xl font-extrabold text-brand-ink">Contact</h2>
            <p>
              Brick Labor · Brian Zalewski (founder) · Newark, NJ ·{' '}
              <a href="mailto:hey@bricklabor.com" className="text-brand-accent underline-hover">
                hey@bricklabor.com
              </a>{' '}
              ·{' '}
              <a href={PHONE_TEL_HREF} className="text-brand-accent underline-hover">
                (855) 825-2267
              </a>
              .
            </p>
            <p className="mt-3 text-sm">
              See also:{' '}
              <a href="/terms" className="text-brand-accent underline-hover">
                Terms of Service
              </a>
              ,{' '}
              <a href="/sources" className="text-brand-accent underline-hover">
                how we cite our facts
              </a>
              , and the{' '}
              <a href="/.well-known/security.txt" className="text-brand-accent underline-hover">
                security.txt
              </a>{' '}
              contact.
            </p>
          </section>
        </div>
      </div>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'WebPage',
            '@id': 'https://bricklabor.com/privacy',
            url: 'https://bricklabor.com/privacy',
            name: TITLE,
            description: DESC,
            dateModified: LAST_UPDATED,
            isPartOf: { '@id': 'https://bricklabor.com/#website' },
          }),
        }}
      />
    </article>
  );
}

function setMeta(name: string, content: string, attr: 'name' | 'property' = 'name') {
  let el = document.querySelector<HTMLMetaElement>(`meta[${attr}="${name}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function setLink(rel: string, href: string) {
  let el = document.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', rel);
    document.head.appendChild(el);
  }
  el.setAttribute('href', href);
}
