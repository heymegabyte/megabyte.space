import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect, useState } from 'react';
import { JsonLd } from './seo/index.js';
import { TurnstileWidget } from './TurnstileWidget.js';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { propertyManagerPageCopy } from '@theme.tools/i18n-a11y/field-service/property-manager-page-copy';

interface SignupState {
  status: 'idle' | 'submitting' | 'ok' | 'error';
  message?: string;
}

/**
 * /property-managers — positions the Free-Move-Concession bundle as a tenant
 * retention product. Same signup endpoint as /partners but marketed as a
 * concierge perk attached to lease signing.
 *
 * Localized for /es + /pt: reads the locale from the path prefix, renders copy
 * from `property-manager-page-copy`, and routes every internal href through
 * `localizedPath` so a mirror-locale visitor stays in their locale. The
 * per-instance prose is locale-invariant ($50/move, (855) 82LABOR, Newark/
 * Jersey City, PODS/U-Haul/Cal.com kept verbatim).
 */
export function PropertyManagerPage(): JSX.Element {
  useThemeToolsSurface('property-manager-page');
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const copy = propertyManagerPageCopy(locale);
  const lp = (path: string): string => localizedPath(locale, path);

  useEffect(() => {
    const code = stripLocalePrefix(window.location.pathname).locale;
    const c = propertyManagerPageCopy(code);
    const canonical = `https://bricklabor.com${localizedPath(code, '/property-managers')}`;
    document.title = c.metaTitle;
    setMeta('description', c.metaDescription);
    setLink('canonical', canonical);
    setMeta('robots', 'index,follow', 'name');
    setMeta('og:title', c.metaTitle, 'property');
    setMeta('og:description', c.metaDescription, 'property');
    setMeta('og:url', canonical, 'property');
  }, []);

  const [state, setState] = useState<SignupState>({ status: 'idle' });
  const [turnstileToken, setTurnstileToken] = useState('');

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);
    const unitCountRaw = String(fd.get('unitCount') || '').trim();
    const payload = {
      name: String(fd.get('name') || '').trim(),
      contactEmail: String(fd.get('contactEmail') || '').trim(),
      companyName: String(fd.get('companyName') || '').trim(),
      unitCount: unitCountRaw ? Number(unitCountRaw) : undefined,
      notes: String(fd.get('notes') || '').trim(),
      source: 'property-managers' as const,
      turnstileToken,
    };
    setState({ status: 'submitting' });
    try {
      const res = await fetch('/api/partners/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = (await res.json()) as { ok: boolean; message?: string; error?: string };
      if (res.ok && data.ok) {
        setState({ status: 'ok', message: data.message ?? copy.okMsg });
        form.reset();
      } else {
        setState({ status: 'error', message: data.error || data.message || copy.errMsg });
      }
    } catch (err) {
      // Error tracked via Sentry
      setState({ status: 'error', message: copy.networkErrMsg });
    }
  }

  const benefits = [copy.benefits.flatRate, copy.benefits.whiteLabel, copy.benefits.addons, copy.benefits.audit];

  return (
    <article className="section">
      <div className="container-pad max-w-5xl">
        <p className="eyebrow mb-3">{copy.eyebrow}</p>
        <h1 className="text-4xl sm:text-5xl font-extrabold">
          {copy.h1Pre}
          <span className="text-brand-accent">{copy.h1Accent}</span>
          {copy.h1Post}
        </h1>
        <p className="mt-4 text-lg text-brand-mute max-w-2xl">{copy.lede}</p>

        <div className="mt-10 grid lg:grid-cols-2 gap-10">
          <section>
            <h2 className="text-2xl font-extrabold mb-3">{copy.bundleHead}</h2>
            <ul className="space-y-3 text-brand-mute leading-relaxed">
              {benefits.map((b) => (
                <li key={b.label}>
                  <strong className="text-brand-ink">{b.label}</strong> {b.body}
                </li>
              ))}
            </ul>

            <h2 className="text-2xl font-extrabold mt-10 mb-3">{copy.whyHead}</h2>
            <p className="text-brand-mute leading-relaxed">{copy.whyBody}</p>

            <h2 className="text-2xl font-extrabold mt-10 mb-3">{copy.relatedHead}</h2>
            <ul className="space-y-2 text-brand-mute">
              <li>
                {copy.related.public.pre}
                <a href={lp('/partners')} className="text-brand-accent underline-hover">
                  /partners
                </a>
                {copy.related.public.suffix}
              </li>
              <li>
                {copy.related.b2b.pre}
                <a href={lp('/b2b')} className="text-brand-accent underline-hover">
                  /b2b
                </a>
                {copy.related.b2b.suffix}
              </li>
              <li>
                {copy.related.integrations.pre}
                <a href={lp('/integrations')} className="text-brand-accent underline-hover">
                  /integrations
                </a>
                {copy.related.integrations.suffix}
              </li>
            </ul>
          </section>

          <form onSubmit={onSubmit} className="card space-y-4" aria-label={copy.formAria}>
            <h2 className="text-xl font-extrabold">{copy.formHead}</h2>
            <p className="text-sm text-brand-mute">{copy.formIntro}</p>

            <div>
              <label className="label" htmlFor="pm-name">
                {copy.labelName}
              </label>
              <input
                id="pm-name"
                name="name"
                required
                autoComplete="name"
                className="input"
                minLength={2}
                maxLength={120}
              />
            </div>

            <div>
              <label className="label" htmlFor="pm-email">
                {copy.labelEmail}
              </label>
              <input
                id="pm-email"
                name="contactEmail"
                type="email"
                required
                autoComplete="email"
                className="input"
                maxLength={160}
              />
            </div>

            <div>
              <label className="label" htmlFor="pm-company">
                {copy.labelCompany}
              </label>
              <input
                id="pm-company"
                name="companyName"
                autoComplete="organization"
                className="input"
                maxLength={160}
              />
            </div>

            <div>
              <label className="label" htmlFor="pm-units">
                {copy.labelUnits}
              </label>
              <input
                id="pm-units"
                name="unitCount"
                type="number"
                min={0}
                max={100000}
                className="input"
                placeholder={copy.unitsPlaceholder}
              />
            </div>

            <div>
              <label className="label" htmlFor="pm-notes">
                {copy.labelNotes}
              </label>
              <textarea
                id="pm-notes"
                name="notes"
                rows={3}
                maxLength={1000}
                className="input resize-y"
                placeholder={copy.notesPlaceholder}
              />
            </div>

            <TurnstileWidget onToken={setTurnstileToken} action="partner-signup" />

            <button
              type="submit"
              disabled={state.status === 'submitting'}
              className="btn-primary w-full"
            >
              {state.status === 'submitting' ? copy.submitting : copy.submitIdle}
            </button>

            {state.status === 'ok' && (
              <div
                role="status"
                className="rounded-lg border border-brand-ok/40 bg-brand-ok/10 p-3 text-sm text-brand-ok"
              >
                {state.message}
              </div>
            )}
            {state.status === 'error' && (
              <div
                role="alert"
                className="rounded-lg border border-brand-err/40 bg-brand-err/10 p-3 text-sm text-brand-err"
              >
                {state.message}
              </div>
            )}

            <p className="border-t border-brand-line pt-3 text-[11px] leading-relaxed text-brand-mute">
              {copy.termsPre}
              <a href={lp('/terms')} className="text-brand-accent underline-hover">
                {copy.termsLink}
              </a>
              {copy.termsMid}
              <a href={lp('/privacy')} className="text-brand-accent underline-hover">
                {copy.privacyLink}
              </a>
              {copy.termsPost}
            </p>
          </form>
        </div>
      </div>

      <JsonLd
        data={{
          '@context': 'https://schema.org',
          '@type': 'WebPage',
          '@id': `https://bricklabor.com${localizedPath(locale, '/property-managers')}`,
          url: `https://bricklabor.com${localizedPath(locale, '/property-managers')}`,
          name: copy.metaTitle,
          description: copy.metaDescription,
          isPartOf: { '@id': 'https://bricklabor.com/#website' },
          about: {
            '@type': 'Service',
            name: 'Brick Labor Free-Move Concierge',
            provider: { '@id': 'https://bricklabor.com/#org' },
            areaServed: 'Newark, NJ',
          },
        }}
      />
    </article>
  );
}

function setMeta(name: string, content: string, attr: 'name' | 'property' = 'name') {
  let el = document.querySelector<HTMLMetaElement>(`meta[${attr}="${name}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function setLink(rel: string, href: string) {
  let el = document.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', rel);
    document.head.appendChild(el);
  }
  el.setAttribute('href', href);
}
