import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect, useRef, useState } from 'react';
import { isPushSupported, subscribeUserToPush, type PushRole } from '../push-subscribe.js';

/**
 * PushPermissionPrompt — Wave 23
 *
 * Two-screen modal that pre-sells the value of push notifications BEFORE we
 * trigger the OS-level prompt. This double-step pattern is the industry-
 * standard fix for the "user habitually clicks Block" problem — by the time
 * the browser's prompt appears, the user already understands what they're
 * granting and has self-selected as interested.
 *
 * Screens:
 *   1. Rationale — "Get notified when your crew is on the way" (customer) or
 *      "Get the first ping when a gig matches you" (crew). Allow / Skip CTA.
 *   2. Success / failure — confirms the subscription or shows a graceful
 *      "you can enable later in your browser settings" fallback.
 *
 * Persistence: localStorage key 'bcl_push_prompted_v1' stores either
 * 'skipped' | 'granted' | 'denied' | 'error' so we never re-prompt within a
 * single deploy cycle. Bumping the v1 suffix re-opens the funnel for everyone.
 *
 * Accessibility:
 *   - role="dialog" + aria-modal + aria-labelledby
 *   - 44px tap targets (h-12 utilities)
 *   - focus-visible ring on every interactive element
 *   - Esc closes (treated as Skip)
 *   - Focus trapped on the Allow button on mount; restored to opener on close
 */

const LS_KEY = 'bcl_push_prompted_v1';

type PromptState = 'closed' | 'rationale' | 'pending' | 'granted' | 'denied';

export interface PushPermissionPromptProps {
  role: PushRole;
  /** Render the prompt automatically when conditions allow. Default true. */
  autoOpen?: boolean;
  /** Optional delay (ms) before auto-opening so it doesn't compete with page load. */
  autoOpenDelayMs?: number;
  /** Notified when the user finishes the flow (granted/denied/skipped). */
  onComplete?: (outcome: 'granted' | 'denied' | 'skipped' | 'error') => void;
}

const COPY: Record<PushRole, { eyebrow: string; title: string; body: string; allow: string }> = {
  customer: {
    eyebrow: 'Stay in the loop',
    title: 'Get notified when your crew is on the way',
    body: 'Real-time arrival pings, ETA updates, and crew confirmations — straight to your device. No marketing blasts, just job updates.',
    allow: 'Enable notifications',
  },
  crew: {
    eyebrow: 'First in line',
    title: 'Get the first ping when a gig matches you',
    body: 'New gigs in your area surface here within seconds. Accept or decline straight from the notification — no app to open.',
    allow: 'Turn on gig alerts',
  },
};

function readStored(): string | null {
  try {
    return localStorage.getItem(LS_KEY);
  } catch {
    return null;
  }
}

function writeStored(value: string): void {
  try {
    localStorage.setItem(LS_KEY, value);
  } catch {
    /* private-mode browsers — silently no-op */
  }
}

export function PushPermissionPrompt({
  role,
  autoOpen = true,
  autoOpenDelayMs = 12_000,
  onComplete,
}: PushPermissionPromptProps) {
  useThemeToolsSurface('push-permission-prompt');
  const [state, setState] = useState<PromptState>('closed');
  const allowBtnRef = useRef<HTMLButtonElement>(null);
  const openerRef = useRef<HTMLElement | null>(null);
  const copy = COPY[role];

  useEffect(() => {
    if (!autoOpen) return;
    if (!isPushSupported()) return;
    if (typeof Notification === 'undefined') return;
    if (Notification.permission === 'denied') return;
    if (Notification.permission === 'granted') return;
    const prior = readStored();
    if (prior) return;

    const t = window.setTimeout(() => {
      openerRef.current = (document.activeElement as HTMLElement) || null;
      setState('rationale');
    }, autoOpenDelayMs);
    return () => window.clearTimeout(t);
  }, [autoOpen, autoOpenDelayMs]);

  useEffect(() => {
    if (state === 'rationale') {
      // Defer focus until the dialog mounts.
      const t = window.setTimeout(() => allowBtnRef.current?.focus(), 30);
      return () => window.clearTimeout(t);
    }
  }, [state]);

  useEffect(() => {
    if (state === 'closed') return;
    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') handleSkip();
    }
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);

  function close(outcome: 'granted' | 'denied' | 'skipped' | 'error') {
    setState('closed');
    writeStored(outcome);
    if (openerRef.current) {
      try {
        openerRef.current.focus();
      } catch {
        /* opener may have unmounted */
      }
    }
    onComplete?.(outcome);
  }

  function handleSkip() {
    close('skipped');
  }

  async function handleAllow() {
    setState('pending');
    let ok = false;
    try {
      ok = await subscribeUserToPush(role);
    } catch {
      ok = false;
    }
    if (ok) {
      setState('granted');
      // Auto-dismiss success state after a brief confirmation.
      window.setTimeout(() => close('granted'), 1_800);
      return;
    }
    setState('denied');
    window.setTimeout(
      () =>
        close(
          typeof Notification !== 'undefined' && Notification.permission === 'denied'
            ? 'denied'
            : 'error',
        ),
      2_400,
    );
  }

  if (state === 'closed') return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="bcl-push-prompt-title"
      className="fixed inset-0 z-[120] flex items-end justify-center bg-black/60 p-4 backdrop-blur-sm sm:items-center"
      onClick={(e) => {
        if (e.target === e.currentTarget) handleSkip();
      }}
    >
      <div className="w-full max-w-md rounded-2xl bg-neutral-900 text-white shadow-2xl ring-1 ring-white/10">
        {state === 'rationale' && (
          <div className="p-6 sm:p-7">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-amber-300">
              {copy.eyebrow}
            </p>
            <h2
              id="bcl-push-prompt-title"
              className="mt-2 text-xl font-bold leading-snug sm:text-2xl"
            >
              {copy.title}
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-neutral-300">{copy.body}</p>
            <ul className="mt-4 space-y-1.5 text-sm text-neutral-200">
              <li className="flex items-start gap-2">
                <span aria-hidden="true" className="mt-0.5 text-amber-300">
                  ✓
                </span>
                <span>Tap Accept or Decline straight from the alert</span>
              </li>
              <li className="flex items-start gap-2">
                <span aria-hidden="true" className="mt-0.5 text-amber-300">
                  ✓
                </span>
                <span>Works even when the browser is closed</span>
              </li>
              <li className="flex items-start gap-2">
                <span aria-hidden="true" className="mt-0.5 text-amber-300">
                  ✓
                </span>
                <span>Turn off anytime in browser settings</span>
              </li>
            </ul>

            <div className="mt-6 flex flex-col gap-2 sm:flex-row-reverse">
              <button
                ref={allowBtnRef}
                type="button"
                onClick={handleAllow}
                className="inline-flex h-12 min-h-[44px] flex-1 items-center justify-center rounded-lg bg-amber-400 px-4 text-sm font-semibold text-neutral-900 transition hover:bg-amber-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-200 focus-visible:ring-offset-2 focus-visible:ring-offset-neutral-900"
                data-bcl-cta="push-allow"
                data-bcl-role={role}
              >
                {copy.allow}
              </button>
              <button
                type="button"
                onClick={handleSkip}
                className="inline-flex h-12 min-h-[44px] flex-1 items-center justify-center rounded-lg border border-white/15 bg-transparent px-4 text-sm font-medium text-neutral-200 transition hover:bg-white/5 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/40 focus-visible:ring-offset-2 focus-visible:ring-offset-neutral-900"
                data-bcl-cta="push-skip"
                data-bcl-role={role}
              >
                Not now
              </button>
            </div>
          </div>
        )}

        {state === 'pending' && (
          <div className="p-7 text-center">
            <h2 id="bcl-push-prompt-title" className="text-lg font-semibold">
              Waiting for permission…
            </h2>
            <p className="mt-2 text-sm text-neutral-300">
              Confirm in the browser prompt to finish enabling alerts.
            </p>
          </div>
        )}

        {state === 'granted' && (
          <div className="p-7 text-center">
            <div
              className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-amber-400 text-2xl text-neutral-900"
              aria-hidden="true"
            >
              ✓
            </div>
            <h2 id="bcl-push-prompt-title" className="mt-3 text-lg font-semibold">
              You're all set.
            </h2>
            <p className="mt-2 text-sm text-neutral-300">
              We'll ping you the moment something needs your attention.
            </p>
          </div>
        )}

        {state === 'denied' && (
          <div className="p-7 text-center">
            <h2 id="bcl-push-prompt-title" className="text-lg font-semibold">
              No problem.
            </h2>
            <p className="mt-2 text-sm text-neutral-300">
              You can enable notifications later from your browser's site settings.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

export default PushPermissionPrompt;
