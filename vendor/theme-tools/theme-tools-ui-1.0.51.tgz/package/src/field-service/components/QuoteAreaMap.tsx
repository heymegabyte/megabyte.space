import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { useEffect, useRef, useState, type JSX } from 'react';

/**
 * QuoteAreaMap — small service-area pin for the /quote landing page.
 *
 * Loaded lazily via IntersectionObserver so the Maps JS script doesn't block
 * LCP. Pulls /api/maps/config for the API key (same wire as MapInner) and
 * shows a graceful fallback when Maps is offline. The map is decorative
 * here — clicking it deep-links into the booking funnel.
 */
interface MapsConfig {
  ok: boolean;
  apiKey: string;
  mapId: string;
}

let sdkPromise: Promise<typeof google> | null = null;

function loadSdk(apiKey: string): Promise<typeof google> {
  if (typeof window !== 'undefined' && (window as { google?: typeof google }).google?.maps) {
    return Promise.resolve((window as { google: typeof google }).google);
  }
  if (sdkPromise) return sdkPromise;
  sdkPromise = new Promise((resolve, reject) => {
    const cbName = `__bcl_quote_gmaps_cb_${Date.now()}`;
    (window as unknown as Record<string, unknown>)[cbName] = () => {
      delete (window as unknown as Record<string, unknown>)[cbName];
      resolve((window as { google: typeof google }).google);
    };
    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(
      apiKey,
    )}&v=weekly&loading=async&libraries=marker&callback=${cbName}`;
    script.async = true;
    script.defer = true;
    script.onerror = () => reject(new Error('gmaps-load-failed'));
    document.head.appendChild(script);
  });
  return sdkPromise;
}

export function QuoteAreaMap(): JSX.Element {
  useThemeToolsSurface('quote-area-map');
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapDivRef = useRef<HTMLDivElement | null>(null);
  const [inView, setInView] = useState(false);
  const [status, setStatus] = useState<'idle' | 'loading' | 'ready' | 'error'>('idle');

  // IntersectionObserver — only kick the loader when the container is near
  // the viewport. Keeps LCP fast on a marketing landing where the map sits
  // below the fold.
  useEffect(() => {
    if (!containerRef.current) return;
    if (typeof IntersectionObserver === 'undefined') {
      setInView(true);
      return;
    }
    const el = containerRef.current;
    const io = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            setInView(true);
            io.disconnect();
            break;
          }
        }
      },
      { rootMargin: '200px 0px' },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    if (!inView || status !== 'idle') return;
    let cancelled = false;
    setStatus('loading');
    (async () => {
      try {
        const r = await fetch('/api/maps/config');
        const cfg = (await r.json().catch(() => null)) as MapsConfig | null;
        if (cancelled) return;
        if (!cfg || !cfg.ok || !cfg.apiKey) {
          setStatus('error');
          return;
        }
        await loadSdk(cfg.apiKey);
        if (cancelled || !mapDivRef.current) return;
        const { Map: GMap } = (await google.maps.importLibrary('maps')) as google.maps.MapsLibrary;
        const { AdvancedMarkerElement } = (await google.maps.importLibrary(
          'marker',
        )) as google.maps.MarkerLibrary;
        if (cancelled || !mapDivRef.current) return;
        const opts: google.maps.MapOptions = {
          center: { lat: 40.7357, lng: -74.1724 }, // Newark
          zoom: 10,
          gestureHandling: 'cooperative',
          streetViewControl: false,
          mapTypeControl: false,
          fullscreenControl: false,
          clickableIcons: false,
          zoomControl: true,
          backgroundColor: '#0a0e14',
        };
        if (cfg.mapId) opts.mapId = cfg.mapId;
        const map = new GMap(mapDivRef.current, opts);
        const pin = document.createElement('div');
        pin.style.cssText =
          'width:22px;height:22px;border-radius:50%;background:#FF6B1A;border:3px solid #0A0E14;box-shadow:0 1px 4px rgba(0,0,0,0.4)';
        new AdvancedMarkerElement({
          position: { lat: 40.7357, lng: -74.1724 },
          map,
          title: 'Newark, NJ — home base',
          content: pin,
        });
        if (!cancelled) setStatus('ready');
      } catch (err) {
        // Error tracked via Sentry
        if (!cancelled) setStatus('error');
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [inView, status]);

  return (
    <div
      ref={containerRef}
      data-quote-map
      data-status={status}
      className="relative h-[280px] w-full overflow-hidden rounded-2xl border border-brand-line bg-bg-elevated/40"
      aria-label="Service area map — Newark and the NJ-NY corridor"
    >
      <div ref={mapDivRef} className="absolute inset-0" />
      {status !== 'ready' && (
        <div className="absolute inset-0 flex items-center justify-center text-brand-mute font-mono text-sm">
          <div className="flex items-center gap-3">
            <span className="inline-block h-2 w-2 rounded-full bg-brand-accent animate-pulse" />
            {status === 'error'
              ? 'Map offline — call (855) 82LABOR for coverage'
              : status === 'loading'
                ? 'Loading service area…'
                : 'Service area · Newark + NJ-NY corridor'}
          </div>
        </div>
      )}
    </div>
  );
}
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
