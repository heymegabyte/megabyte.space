import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { useEffect, useState } from 'react';

// Renders /quote/<id>. A saved quote is no longer a standalone summary page — it
// redirects straight INTO the /book form on the Confirm step (#4) with the full
// saved scope pre-filled (via sessionStorage `bcl-quote-prefill` + the
// `fromQuote` marker), so whoever opens the link picks up exactly where the
// sender left off — every earlier step pre-filled + back-navigable. Only an
// expired/typo'd link stays here, showing a lead-recovery CTA into a fresh quote.

const TITLE = 'Your Quote — Brick Labor';
const DESC =
  'Reopen your saved Brick Labor quote — pre-filled and ready to confirm at $50/hr per person, no nonsense.';

interface StoredQuote {
  id: string;
  createdAt: string;
  data: Record<string, unknown>;
  totalCents: number;
}

interface Props {
  id: string;
}

export function QuoteShare({ id }: Props) {
  useThemeToolsSurface('quote-share');
  const [error, setError] = useState<string>('');

  useEffect(() => {
    document.title = TITLE;
    setMeta('description', DESC);
    setMeta('robots', 'noindex,follow');
    setLink('canonical', `https://bricklabor.com/quote/${id}`);
  }, [id]);

  useEffect(() => {
    let stopped = false;
    const controller = new AbortController();
    fetch(`/api/quote/${id}`, {
      headers: { Accept: 'application/json' },
      signal: controller.signal,
    })
      .then(async (r) => {
        if (stopped) return;
        // The endpoint self-gates to 200 even for an expired/typo'd link
        // (returns {ok:false}); a real 5xx (corrupt blob) still surfaces.
        if (!r.ok) {
          setError('Could not load that quote. Try again in a moment.');
          return;
        }
        const json = (await r.json()) as { ok?: boolean; quote?: StoredQuote };
        if (json.ok && json.quote) {
          // Stash the full saved scope + the fromQuote marker, then hand off to
          // the booking form — it hydrates every field and opens on Confirm (#4).
          try {
            sessionStorage.setItem(
              'bcl-quote-prefill',
              // Carry the QUOTED price (fire-72) so /book can DISCLOSE a change if its live-clock
              // recompute (surge + same-day rush) diverges — never silently charge more than quoted.
              JSON.stringify({ ...json.quote.data, fromQuote: true, quotedTotalCents: json.quote.totalCents }),
            );
          } catch {
            /* private mode — the /book form still loads, just unfilled */
          }
          window.location.replace('/book');
          return;
        }
        setError('That quote link has expired or was never saved.');
      })
      .catch(() => {
        if (!stopped && !controller.signal.aborted) setError('Network issue loading the quote.');
      });
    return () => {
      stopped = true;
      controller.abort();
    };
  }, [id]);

  return (
    <article className="section">
      <div className="container-pad max-w-2xl">
        <p className="eyebrow mb-3">Quote</p>
        <h1 className="text-4xl sm:text-5xl font-extrabold mb-2">
          {error ? 'That quote link expired' : 'Opening your quote…'}
        </h1>
        {!error && (
          <p className="text-brand-mute mb-8" role="status" aria-live="polite">
            Reopening your saved quote in the booking form — one moment. If nothing happens,{' '}
            <a href="/book" className="text-brand-accent underline-hover">
              continue booking here
            </a>
            .
          </p>
        )}
        {error && (
          <div className="space-y-4">
            <div
              role="alert"
              className="rounded-lg border border-red-500/40 bg-red-500/10 p-4 text-red-200"
            >
              {error}
            </div>
            {/* Lead recovery: an expired/typo'd share link is otherwise a dead
                end. Funnel the visitor straight into the booking form. */}
            <a
              href="/book"
              className="btn btn-primary inline-flex"
              data-bcl-cta-location="quote-share-error-recovery"
            >
              Start a fresh quote →
            </a>
          </div>
        )}
      </div>
    </article>
  );
}

function setMeta(name: string, content: string, attr: 'name' | 'property' = 'name') {
  let el = document.querySelector<HTMLMetaElement>(`meta[${attr}="${name}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function setLink(rel: string, href: string) {
  let el = document.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', rel);
    document.head.appendChild(el);
  }
  el.setAttribute('href', href);
}
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
