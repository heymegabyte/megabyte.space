import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useCallback, useEffect, useState } from 'react';
import { stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { reviewCopy, type ReviewCopy } from '@theme.tools/i18n-a11y/field-service/review-copy';
import { shouldShowGoogleReviewCta } from '@theme.tools/crm/field-service/review-google-cta';
import { useRovingRadio } from '../use-roving-radio.js';
import { charCounterState, type CharCounterTone } from '@theme.tools/i18n-a11y/field-service/char-counter';
import { ReviewErrorPanel } from './ReviewErrorPanel.js';

const NOTES_MAX = 800;

/** Brand-token color per counter urgency band (text-contrast safe on the dark card). */
const COUNTER_TONE_CLASS: Record<CharCounterTone, string> = {
  ok: 'text-brand-mute',
  warn: 'text-amber-400',
  limit: 'text-red-300',
};

interface CrewMember {
  id: string;
  first_name: string;
  last_name: string;
  avatar_r2_key: string | null;
}

interface CrewPayload {
  gigId: string;
  customerName: string;
  crew: CrewMember[];
  alreadyReviewed: string[];
  referralCode: string;
  referralUrl: string;
  googleReviewUrl: string | null;
}

interface DraftReview {
  stars: number;
  body: string;
  tipDollars: string;
  flagKind?: '' | 'no_show' | 'rude' | 'unsafe' | 'property_damage' | 'quality' | 'other';
  submitting: boolean;
  submitted: boolean;
  // True ONLY for a rating submitted in THIS session. `submitted` alone can come
  // from a prior-visit review (`alreadyReviewed`), whose `stars` is just the UI
  // default — never trust that placeholder for the Google-review CTA.
  ratedThisSession?: boolean;
  error?: string;
  // Wave 2B — post-service add-ons. Tip is unlocked only after the rating is
  // in (no upfront tipping). preferenceKind tracks the customer's "request
  // again" / "block this crew" choice.
  tipSubmitting?: boolean;
  tipSubmitted?: boolean;
  tipError?: string;
  preferenceKind?: 'prefer' | 'block' | '';
  preferenceSubmitting?: boolean;
  preferenceError?: string;
}

/** Fill `{name}` (and any other `{token}`) placeholders in a localized string. */
function fmt(template: string, vars: Record<string, string | number>): string {
  return template.replace(/\{(\w+)\}/g, (_, k: string) => String(vars[k] ?? ''));
}

/** Localized flag-reason options, ordered to match the rating form. */
function flagLabels(
  t: ReviewCopy,
): Array<{ value: NonNullable<DraftReview['flagKind']>; label: string }> {
  return [
    { value: '', label: t.flags.none },
    { value: 'no_show', label: t.flags.noShow },
    { value: 'rude', label: t.flags.rude },
    { value: 'unsafe', label: t.flags.unsafe },
    { value: 'property_damage', label: t.flags.propertyDamage },
    { value: 'quality', label: t.flags.quality },
    { value: 'other', label: t.flags.other },
  ];
}

interface Props {
  gigId: string;
}

/** Read the /es|/pt mirror locale the customer landed on (App.tsx strips the prefix). */
function currentLocale(): string {
  return stripLocalePrefix(window.location.pathname).locale;
}

export function RateCrew({ gigId }: Props) {
  useThemeToolsSurface('rate-crew');
  const t = reviewCopy(currentLocale());
  const [payload, setPayload] = useState<CrewPayload | null>(null);
  const [error, setError] = useState<string>('');
  // fire-37: transient (5xx/network) errors expose a one-click retry; dead/expired
  // links don't (a retry can't fix them). Drives <ReviewErrorPanel canRetry>.
  const [errorRetryable, setErrorRetryable] = useState(false);
  const [loading, setLoading] = useState(true);
  const [drafts, setDrafts] = useState<Record<string, DraftReview>>({});
  const [copied, setCopied] = useState(false);
  const token = new URLSearchParams(window.location.search).get('token') ?? '';

  useEffect(() => {
    document.title = t.metaTitle;
    setMeta('description', t.metaDesc);
    setMeta('robots', 'noindex,nofollow');
  }, [t]);

  // fire-37: the fetch is a retriable `load()` so the error panel's "Try again"
  // can re-run it (not a full page reload). Closure `cancelled` preserves the
  // original dep-change cancellation; the effect runs load and uses its cleanup.
  const load = useCallback(() => {
    if (!token) {
      setError(t.errMissingToken);
      setErrorRetryable(false);
      setLoading(false);
      return () => {};
    }
    setError('');
    setErrorRetryable(false);
    setLoading(true);
    let cancelled = false;
    fetch(`/api/work/reviews/customer/${gigId}?token=${encodeURIComponent(token)}`)
      .then(async (r) => {
        if (cancelled) return;
        // A genuine server fault still 5xxs (stays observable); an invalid/
        // expired link self-gates to 200 {ok:false} so no console error fires.
        if (!r.ok) {
          setError(t.errLoad);
          setErrorRetryable(true); // transient — a retry may succeed
          return;
        }
        const json = (await r.json()) as Partial<CrewPayload> & { ok?: boolean };
        if (json.ok === false || !json.crew) {
          setError(t.errInvalidLink);
          setErrorRetryable(false); // bad/expired link — a retry won't help
          return;
        }
        const data = json as CrewPayload;
        setPayload(data);
        const initial: Record<string, DraftReview> = {};
        for (const w of data.crew) {
          initial[w.id] = {
            stars: 5,
            body: '',
            tipDollars: '',
            flagKind: '',
            submitting: false,
            submitted: data.alreadyReviewed.includes(w.id),
            ratedThisSession: false,
            tipSubmitting: false,
            tipSubmitted: false,
            preferenceKind: '',
            preferenceSubmitting: false,
          };
        }
        setDrafts(initial);
      })
      .catch(() => {
        if (!cancelled) {
          setError(t.errNetwork);
          setErrorRetryable(true); // network hiccup — a retry may succeed
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [gigId, token, t]);

  useEffect(() => load(), [load]);

  const updateDraft = (workerId: string, patch: Partial<DraftReview>) => {
    setDrafts((prev) => ({ ...prev, [workerId]: { ...prev[workerId]!, ...patch } }));
  };

  const submit = async (worker: CrewMember) => {
    const draft = drafts[worker.id];
    if (!draft || draft.submitting) return;

    updateDraft(worker.id, { submitting: true, error: undefined });
    try {
      const res = await fetch(`/api/work/reviews/customer/${gigId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          workerId: worker.id,
          stars: draft.stars,
          body: draft.body.trim() || undefined,
          flagKind: draft.flagKind || undefined,
        }),
      });
      if (!res.ok) {
        const json = (await res.json().catch(() => ({}))) as { code?: string };
        if (json.code === 'already_reviewed') {
          updateDraft(worker.id, { submitting: false, submitted: true });
          return;
        }
        updateDraft(worker.id, {
          submitting: false,
          error: t.submitError,
        });
        return;
      }
      updateDraft(worker.id, { submitting: false, submitted: true, ratedThisSession: true });
    } catch {
      // Rating-submit network failure → rating error copy (NOT the tip's).
      updateDraft(worker.id, { submitting: false, error: t.submitError });
    }
  };

  /**
   * Post-rating tip submission. Tips never appear before the rating is
   * submitted (TCPA-adjacent fairness: never coerce a tip at booking time).
   * 100% of the tip goes to the worker — no platform cut.
   */
  const submitTip = async (worker: CrewMember) => {
    const draft = drafts[worker.id];
    if (!draft || draft.tipSubmitting) return;
    const tipDollars = parseFloat(draft.tipDollars || '0');
    const tipCents = Number.isFinite(tipDollars) ? Math.round(tipDollars * 100) : 0;
    if (tipCents <= 0) {
      updateDraft(worker.id, { tipError: t.tipErrEnter });
      return;
    }
    updateDraft(worker.id, { tipSubmitting: true, tipError: undefined });
    try {
      const res = await fetch(`/api/work/reviews/customer/${gigId}/tip`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, workerId: worker.id, tipCents }),
      });
      if (!res.ok) {
        updateDraft(worker.id, {
          tipSubmitting: false,
          tipError: t.tipErrRecord,
        });
        return;
      }
      updateDraft(worker.id, { tipSubmitting: false, tipSubmitted: true });
    } catch {
      updateDraft(worker.id, {
        tipSubmitting: false,
        tipError: t.tipErrNetwork,
      });
    }
  };

  /**
   * Record a crew preference (request-again or block) for this customer ↔ crew
   * pair. Backed by /api/claims-board/preferences (see claims-board.ts route).
   */
  const submitPreference = async (worker: CrewMember, kind: 'prefer' | 'block') => {
    const draft = drafts[worker.id];
    if (!draft || draft.preferenceSubmitting) return;
    updateDraft(worker.id, { preferenceSubmitting: true, preferenceError: undefined });
    try {
      const res = await fetch('/api/claims-board/preferences', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ crewUserId: worker.id, kind }),
      });
      if (res.status === 401) {
        updateDraft(worker.id, {
          preferenceSubmitting: false,
          preferenceError: t.prefErrSignIn,
        });
        return;
      }
      if (!res.ok) {
        updateDraft(worker.id, {
          preferenceSubmitting: false,
          preferenceError: t.prefErrSave,
        });
        return;
      }
      updateDraft(worker.id, { preferenceSubmitting: false, preferenceKind: kind });
    } catch {
      updateDraft(worker.id, {
        preferenceSubmitting: false,
        preferenceError: t.prefErrNetwork,
      });
    }
  };

  return (
    <article className="section">
      <div className="container-pad max-w-2xl">
        <p className="eyebrow mb-3">{t.eyebrow}</p>
        <h1 className="text-4xl sm:text-5xl font-extrabold mb-2">{t.h1}</h1>
        <p className="text-brand-mute mb-8">{t.lede}</p>

        {loading && <p className="text-brand-mute">{t.loading}</p>}

        {error && (
          <ReviewErrorPanel
            message={error}
            canRetry={errorRetryable}
            onRetry={load}
            copy={t}
          />
        )}

        {payload && payload.crew.length === 0 && (
          <p className="text-brand-mute">{t.noCrew}</p>
        )}

        {payload && payload.crew.length > 0 && (
          <div className="space-y-6">
            {payload.crew.map((w) => {
              const draft = drafts[w.id];
              if (!draft) return null;
              const fullName = `${w.first_name} ${w.last_name}`.trim();
              return (
                <div
                  key={w.id}
                  className="rounded-lg border border-brand-line bg-brand-card p-6 space-y-4"
                >
                  <div className="flex items-center gap-4">
                    {w.avatar_r2_key ? (
                      <img
                        src={`/api/work/upload/avatar/${w.id}`}
                        alt={fullName}
                        className="w-14 h-14 rounded-full object-cover border border-brand-line"
                      />
                    ) : (
                      <div className="w-14 h-14 rounded-full bg-brand-line/40 flex items-center justify-center text-xl font-bold text-brand-ink">
                        {(w.first_name[0] || '?').toUpperCase()}
                      </div>
                    )}
                    <div>
                      <p className="text-lg font-semibold text-brand-ink">{fullName}</p>
                      <p className="text-brand-mute text-sm">{t.workerRole}</p>
                    </div>
                  </div>

                  {draft.submitted ? (
                    <PostRatingActions
                      t={t}
                      worker={w}
                      draft={draft}
                      updateDraft={updateDraft}
                      submitTip={submitTip}
                      submitPreference={submitPreference}
                    />
                  ) : (
                    <>
                      <StarRating
                        t={t}
                        value={draft.stars}
                        onChange={(s) => updateDraft(w.id, { stars: s })}
                        labelId={`stars-${w.id}`}
                      />

                      <label className="block">
                        <span className="text-brand-mute text-sm font-medium block mb-1">
                          {t.notesLabel}
                        </span>
                        <textarea
                          rows={3}
                          maxLength={NOTES_MAX}
                          value={draft.body}
                          onChange={(e) => updateDraft(w.id, { body: e.target.value })}
                          placeholder={t.notesPlaceholder}
                          aria-describedby={`notes-count-${w.id}`}
                          className="w-full rounded-md border border-brand-line bg-brand-bg p-2 text-sm text-brand-ink"
                        />
                        {(() => {
                          const cc = charCounterState(draft.body.length, NOTES_MAX);
                          return (
                            <span
                              id={`notes-count-${w.id}`}
                              data-testid={`notes-char-count-${w.id}`}
                              aria-live="polite"
                              className={`mt-1 block text-right text-xs tabular-nums transition-colors duration-[333ms] ${COUNTER_TONE_CLASS[cc.tone]}`}
                            >
                              {fmt(t.notesCharsLeft, { n: cc.remaining })}
                            </span>
                          );
                        })()}
                      </label>

                      <label className="block">
                        <span className="text-brand-mute text-sm font-medium block mb-1">
                          {t.wrongLabel}
                        </span>
                        <select
                          value={draft.flagKind}
                          onChange={(e) =>
                            updateDraft(w.id, {
                              flagKind: e.target.value as DraftReview['flagKind'],
                            })
                          }
                          className="w-full rounded-md border border-brand-line bg-brand-bg p-2 text-sm text-brand-ink"
                        >
                          {flagLabels(t).map((f) => (
                            <option key={f.value} value={f.value}>
                              {f.label}
                            </option>
                          ))}
                        </select>
                      </label>

                      {draft.error && <p className="text-red-300 text-sm">{draft.error}</p>}

                      <p className="text-brand-mute text-xs">{t.tipsUnlockedNote}</p>

                      <button
                        type="button"
                        onClick={() => submit(w)}
                        disabled={draft.submitting}
                        className="btn btn-primary w-full disabled:opacity-50"
                      >
                        {draft.submitting
                          ? t.submitting
                          : fmt(t.submitRatingFor, { name: w.first_name })}
                      </button>
                    </>
                  )}
                </div>
              );
            })}

            <p className="text-brand-mute text-xs">
              {t.payoutPre}
              <a href="/terms" className="text-brand-accent underline-hover">
                {t.termsLabel}
              </a>
              {t.payoutMid}
              <a href="/privacy" className="text-brand-accent underline-hover">
                {t.privacyLabel}
              </a>
              .
            </p>

            {renderPostSubmit({ t, payload, drafts, copied, setCopied })}

            <div className="mt-8 rounded-lg border border-brand-line bg-bg-elevated/40 p-5 text-sm text-brand-mute">
              <p className="font-display font-bold text-brand-ink mb-2">{t.needAgainTitle}</p>
              <p>
                {t.needAgainPre}
                <a href="/#pricing" className="text-brand-accent underline-hover">
                  {t.priceLabel}
                </a>
                {t.needAgainAcross}
                <a href="/services/power-washing" className="text-brand-accent underline-hover">
                  {t.svcPowerWashing}
                </a>
                ,{' '}
                <a href="/services/lawn-care" className="text-brand-accent underline-hover">
                  {t.svcLawnCare}
                </a>
                ,{' '}
                <a href="/services/hauling" className="text-brand-accent underline-hover">
                  {t.svcHauling}
                </a>
                , {t.and}{' '}
                <a href="/services/light-repairs" className="text-brand-accent underline-hover">
                  {t.svcLightRepairs}
                </a>
                .
              </p>
              <div className="mt-3 flex flex-wrap gap-2 text-xs">
                <a href="/book" className="btn-primary">
                  {t.bookCrewCta}
                </a>
                <a href="/blog" className="btn-ghost">
                  {t.readBlog}
                </a>
                <a href="/#testimonials" className="btn-ghost">
                  {t.moreReviews}
                </a>
              </div>
            </div>
          </div>
        )}
      </div>
    </article>
  );
}

interface PostSubmitProps {
  t: ReviewCopy;
  payload: CrewPayload;
  drafts: Record<string, DraftReview>;
  copied: boolean;
  setCopied: (v: boolean) => void;
}

function renderPostSubmit({ t, payload, drafts, copied, setCopied }: PostSubmitProps) {
  const submittedDrafts = payload.crew
    .map((w) => drafts[w.id])
    .filter((d): d is DraftReview => Boolean(d?.submitted));
  if (submittedDrafts.length === 0) return null;

  // Reputation guard: only a 5-star rating GIVEN THIS SESSION unlocks the public
  // Google-review CTA — never a prior-visit placeholder defaulted to 5 stars.
  const showGoogleCta = shouldShowGoogleReviewCta(
    payload.crew.map((w) => drafts[w.id]).filter((d): d is DraftReview => Boolean(d)),
    payload.crew.length,
    Boolean(payload.googleReviewUrl),
  );

  const shareText = fmt(t.shareText, {
    code: payload.referralCode,
    url: payload.referralUrl,
  });

  const copyCode = async () => {
    try {
      await navigator.clipboard.writeText(payload.referralCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2200);
    } catch {
      /* clipboard blocked — fall through */
    }
  };

  const smsHref = `sms:?&body=${encodeURIComponent(shareText)}`;
  const waHref = `https://wa.me/?text=${encodeURIComponent(shareText)}`;

  return (
    <div className="mt-8 space-y-6">
      {showGoogleCta && (
        <div className="rounded-lg border border-amber-400/50 bg-amber-500/10 p-5 space-y-3">
          <p className="text-amber-200 font-semibold">{t.googleTitle}</p>
          <p className="text-brand-ink text-sm">{t.googleBody}</p>
          <a
            href={payload.googleReviewUrl ?? '#'}
            target="_blank"
            rel="noopener noreferrer"
            className="btn btn-primary inline-block"
          >
            {t.googleBtn}
          </a>
        </div>
      )}

      <div className="rounded-lg border border-brand-line bg-brand-card p-5 space-y-4">
        <div>
          <p className="eyebrow mb-1">{t.referralEyebrow}</p>
          <p className="text-brand-ink font-semibold text-lg">{t.referralTitle}</p>
          <p className="text-brand-mute text-sm">{t.referralBody}</p>
        </div>

        <div className="flex items-center gap-2">
          <code
            data-testid="referral-code"
            className="flex-1 rounded-md border border-brand-line bg-brand-bg px-3 py-2 font-mono text-brand-accent font-bold tracking-wide"
          >
            {payload.referralCode}
          </code>
          <button
            type="button"
            onClick={copyCode}
            className="btn btn-secondary text-sm whitespace-nowrap"
            aria-live="polite"
          >
            {copied ? t.copied : t.copyCode}
          </button>
        </div>

        <div className="flex flex-wrap gap-2">
          <a href={smsHref} className="btn btn-secondary text-sm" data-testid="share-sms">
            {t.textFriend}
          </a>
          <a
            href={waHref}
            target="_blank"
            rel="noopener noreferrer"
            className="btn btn-secondary text-sm"
            data-testid="share-whatsapp"
          >
            {t.whatsapp}
          </a>
          <button
            type="button"
            onClick={() => {
              navigator.clipboard?.writeText(shareText).then(() => {
                setCopied(true);
                setTimeout(() => setCopied(false), 2200);
              });
            }}
            className="btn btn-secondary text-sm"
            data-testid="share-copy-link"
          >
            {t.copyShareLink}
          </button>
        </div>
      </div>
    </div>
  );
}

interface StarRatingProps {
  t: ReviewCopy;
  value: number;
  onChange: (n: number) => void;
  labelId: string;
}

function StarRating({ t, value, onChange, labelId }: StarRatingProps) {
  // ARIA roving-tabindex keyboard contract for the custom star radiogroup
  // (axe-blind interaction gap — see use-roving-radio). Stars are indices 0..4.
  const starRadio = useRovingRadio(5, (i) => onChange(i + 1));
  return (
    <div role="radiogroup" aria-labelledby={labelId} className="flex items-center gap-1">
      <span id={labelId} className="text-brand-mute text-sm font-medium mr-2">
        {t.ratingLabel}
      </span>
      {[1, 2, 3, 4, 5].map((n) => {
        const filled = n <= value;
        return (
          <button
            key={n}
            type="button"
            role="radio"
            aria-checked={value === n}
            aria-label={fmt(n === 1 ? t.starAria : t.starsAria, { n })}
            onClick={() => onChange(n)}
            {...starRadio(n - 1, value >= 1 ? value === n : n === 1)}
            className={`text-3xl leading-none rounded transition-colors duration-[333ms] focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent ${
              filled ? 'text-amber-400' : 'text-brand-mute/40 hover:text-amber-400/60'
            }`}
          >
            ★
          </button>
        );
      })}
    </div>
  );
}

interface PostRatingActionsProps {
  t: ReviewCopy;
  worker: CrewMember;
  draft: DraftReview;
  updateDraft: (workerId: string, patch: Partial<DraftReview>) => void;
  submitTip: (worker: CrewMember) => Promise<void>;
  submitPreference: (worker: CrewMember, kind: 'prefer' | 'block') => Promise<void>;
}

/**
 * Post-rating block. Renders three independent sub-actions in this order:
 *   1. Thank-you confirmation.
 *   2. Optional tip (POST-service only — never upfront).
 *   3. "Request this crew again" / "Don't assign me to this crew" CTAs.
 * Each sub-action is independently submittable; failures isolate to that row.
 */
function PostRatingActions({
  t,
  worker,
  draft,
  updateDraft,
  submitTip,
  submitPreference,
}: PostRatingActionsProps) {
  const name = worker.first_name;
  return (
    <div className="space-y-4">
      <p className="text-emerald-300 text-sm font-medium" data-testid="rating-confirmed">
        {fmt(t.ratingConfirmed, { name })}
      </p>

      {/* Tipping is post-service only. Skipping is always fine. */}
      {draft.tipSubmitted ? (
        <p className="text-emerald-300 text-sm" data-testid="tip-confirmed">
          {fmt(t.tipConfirmed, { name })}
        </p>
      ) : (
        <div className="rounded-md border border-brand-line/60 bg-brand-bg/40 p-4 space-y-3">
          <p className="text-brand-ink text-sm font-semibold">{fmt(t.addTipTitle, { name })}</p>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-brand-ink font-semibold">$</span>
            <input
              type="number"
              min="0"
              max="1000"
              step="1"
              value={draft.tipDollars}
              onChange={(e) => updateDraft(worker.id, { tipDollars: e.target.value })}
              placeholder="0"
              aria-label={fmt(t.tipAmountAria, { name })}
              className="w-24 rounded-md border border-brand-line bg-brand-bg p-2 text-sm text-brand-ink"
            />
            <div className="flex gap-1">
              {[10, 20, 40].map((amt) => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => updateDraft(worker.id, { tipDollars: String(amt) })}
                  className="rounded border border-brand-line bg-brand-bg px-3 py-1 text-xs text-brand-ink hover:bg-brand-line/30"
                >
                  ${amt}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={() => submitTip(worker)}
              disabled={draft.tipSubmitting}
              className="btn btn-secondary text-sm disabled:opacity-50"
              data-testid="submit-tip"
            >
              {draft.tipSubmitting ? t.sending : t.sendTip}
            </button>
          </div>
          {draft.tipError && (
            <p className="text-red-300 text-xs" role="alert">
              {draft.tipError}
            </p>
          )}
          <p className="text-brand-mute text-xs">{t.tipOptionalNote}</p>
        </div>
      )}

      {/* "Request this crew again" — backed by /api/claims-board/preferences. */}
      {draft.preferenceKind ? (
        <p className="text-brand-accent text-sm" data-testid="preference-confirmed">
          {draft.preferenceKind === 'prefer'
            ? fmt(t.preferConfirmedPrefer, { name })
            : fmt(t.preferConfirmedBlock, { name })}
        </p>
      ) : (
        <div className="rounded-md border border-brand-line/60 bg-brand-bg/40 p-4 space-y-2">
          <p className="text-brand-ink text-sm font-semibold">{fmt(t.wantAgainTitle, { name })}</p>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => submitPreference(worker, 'prefer')}
              disabled={draft.preferenceSubmitting}
              className="btn btn-primary text-sm disabled:opacity-50"
              data-testid="prefer-crew"
            >
              {draft.preferenceSubmitting ? t.saving : fmt(t.requestAgain, { name })}
            </button>
            <button
              type="button"
              onClick={() => submitPreference(worker, 'block')}
              disabled={draft.preferenceSubmitting}
              className="btn btn-ghost text-sm disabled:opacity-50"
              data-testid="block-crew"
            >
              {fmt(t.dontAssign, { name })}
            </button>
          </div>
          {draft.preferenceError && (
            <p className="text-red-300 text-xs" role="alert">
              {draft.preferenceError}
            </p>
          )}
        </div>
      )}
    </div>
  );
}

function setMeta(name: string, content: string) {
  let el = document.querySelector<HTMLMetaElement>(`meta[name="${name}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute('name', name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}
