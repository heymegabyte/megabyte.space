import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useId } from 'react';

interface RecommendationItem {
  label: string;
  action: string;
  reason?: string;
}

interface RecommendationChipsProps {
  items: RecommendationItem[];
  onAction?: (action: string) => void;
  /** Cap visible chips. Defaults to 5. */
  maxItems?: number;
}

/**
 * Renders an array of AI-recommended action chips as rounded brand-accent
 * pills. Clicking a chip fires `onAction(item.action)`. If `reason` is
 * present, it renders an `.anchor-tip` tooltip via CSS Anchor Positioning
 * (Chrome 133+/Safari 18+) and falls back to a native `title` attribute on
 * browsers without anchor-name support. Each chip carries
 * `data-bcl-action="recommendation_clicked"` + `data-bcl-rec-action={action}`
 * so the global analytics delegate picks them up without per-call wiring.
 */
export function RecommendationChips({
  items,
  onAction,
  maxItems = 5,
}: RecommendationChipsProps): JSX.Element | null {
  useThemeToolsSurface('recommendation-chips');
  const baseId = useId();
  const visible = items.slice(0, maxItems);
  if (visible.length === 0) return null;
  return (
    <ul className="flex flex-wrap gap-2" aria-label="Recommended actions">
      {visible.map((item, idx) => {
        const anchorName = `--bcl-rec-${baseId.replace(/[^a-zA-Z0-9_-]/g, '')}-${idx}`;
        const tipId = `${baseId}-tip-${idx}`;
        return (
          <li key={`${item.action}-${idx}`} className="relative">
            <button
              type="button"
              onClick={() => onAction?.(item.action)}
              title={item.reason ?? undefined}
              aria-describedby={item.reason ? tipId : undefined}
              data-bcl-action="recommendation_clicked"
              data-bcl-rec-action={item.action}
              style={{ anchorName }}
              className="group inline-flex items-center gap-1.5 rounded-full border border-brand-accent bg-bg-elevated px-3 py-1.5 text-xs font-medium text-brand-ink transition hover:bg-brand-accent/10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-accent"
            >
              <span aria-hidden className="text-brand-accent">
                ✦
              </span>
              <span>{item.label}</span>
            </button>
            {item.reason && (
              <span
                id={tipId}
                role="tooltip"
                className="anchor-tip opacity-0 group-hover:opacity-100 group-focus-within:opacity-100"
                style={{ positionAnchor: anchorName } as React.CSSProperties}
              >
                {item.reason}
              </span>
            )}
          </li>
        );
      })}
    </ul>
  );
}
