import { useMemo, useRef, useState } from 'react';
import {
  RECURRING_DISCOUNT_FACTORS,
  recurringFactor,
  type RecurringCadence,
} from '@theme.tools/billing/field-service/surge';
import { nextRadioIndex, rovingTabIndex } from '@theme.tools/i18n-a11y/field-service/radio-keynav';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { useThemeToolsSurface } from '../../field-service-primitives.js';

// 12-week savings visualizer for the four recurring cadences. CSS-only bar
// chart — no library — so it ships in the React bundle without weight. Pure:
// given a cadence + base fare, returns the saved-per-occurrence + the rolled
// 12-week total. Hooked to the Booking flow's RECURRING_PLANS table via
// RECURRING_DISCOUNT_FACTORS in src/shared/surge.ts.

export interface RecurringDiscountWidgetProps {
  // Default cadence to highlight. The user can switch via the segmented control.
  cadence?: RecurringCadence;
  // Base fare per occurrence in dollars (default $300 — 2 crew × 3 hr × $50).
  baseFare?: number;
  // Hide the segmented control and lock the visualizer to `cadence`.
  locked?: boolean;
  // Booking deep-link for the "Book a standing crew" CTA. Locale-aware callers pass
  // `lp('/book')` so a /es·/pt mirror visitor stays localized; defaults to the canonical
  // `/book` (recurring cadence is picked inline there — the standalone /recurring form was
  // retired 2026-09-25 and 301s to /book).
  bookHref?: string;
}

function formatUsd(amount: number): string {
  return amount.toLocaleString('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  });
}

interface WeekBar {
  weekIndex: number;
  occurrences: number;
  saved: number;
}

function buildWeeklyBars(cadence: RecurringCadence, baseFare: number): WeekBar[] {
  const factor = recurringFactor(cadence);
  const savedPerOccurrence = baseFare * (factor.discountPct / 100);
  const bars: WeekBar[] = [];
  for (let week = 1; week <= 12; week += 1) {
    let occurrences = 0;
    if (cadence === 'daily')
      occurrences = 5; // weekdays only
    else if (cadence === 'weekly') occurrences = 1;
    else if (cadence === 'bi-weekly') occurrences = week % 2 === 0 ? 1 : 0;
    else if (cadence === 'monthly') occurrences = week % 4 === 0 ? 1 : 0;
    bars.push({ weekIndex: week, occurrences, saved: occurrences * savedPerOccurrence });
  }
  return bars;
}

export function RecurringDiscountWidget(props: RecurringDiscountWidgetProps) {
  const {
    cadence: initialCadence = 'weekly',
    baseFare = 300,
    locked = false,
    bookHref = '/book',
  } = props;
  const [cadence, setCadence] = useState<RecurringCadence>(initialCadence);
  const factor = recurringFactor(cadence);
  const radioRefs = useRef<(HTMLButtonElement | null)[]>([]);

  // ARIA radio-group keyboard contract: arrow/Home/End move selection AND focus
  // between options (the group is a single tab stop via rovingTabIndex below).
  const onRadioKeyDown = (e: React.KeyboardEvent<HTMLButtonElement>, index: number) => {
    const target = nextRadioIndex(index, RECURRING_DISCOUNT_FACTORS.length, e.key);
    if (target === null) return;
    e.preventDefault();
    const opt = RECURRING_DISCOUNT_FACTORS[target];
    if (!opt) return;
    setCadence(opt.cadence);
    radioRefs.current[target]?.focus();
  };

  const bars = useMemo(() => buildWeeklyBars(cadence, baseFare), [cadence, baseFare]);
  const totalSaved = useMemo(() => bars.reduce((acc, b) => acc + b.saved, 0), [bars]);
  const totalOccurrences = useMemo(() => bars.reduce((acc, b) => acc + b.occurrences, 0), [bars]);
  const maxBar = Math.max(...bars.map((b) => b.saved), 1);
  // Headline discount for the CTA — the best standing-cadence rate (daily 12%), derived from the
  // canonical factors so the copy never drifts from the data.
  const maxDiscountPct = Math.max(...RECURRING_DISCOUNT_FACTORS.map((f) => f.discountPct));
  const pricingStandard = useMemo(
    () =>
      evaluateHourlyLaborPricingStandard({
        crewSize: 2,
        hours: 3,
        cadence: cadence === 'bi-weekly' ? 'biweekly' : cadence,
      }),
    [cadence],
  );

  const surfaceProps = useThemeToolsSurface('recurring-discount-widget', [
    '@theme.tools/ui',
    '@theme.tools/billing',
  ]);

  return (
    <section
      aria-label="Recurring discount savings, 12-week projection"
      className="rounded-lg border border-brand-line bg-bg-primary/60 p-4 sm:p-5"
      data-testid="recurring-discount-widget"
      data-theme-tools-surface={surfaceProps['data-theme-tools-surface']}
      data-theme-tools-pricing-model={surfaceProps['data-theme-tools-pricing-model']}
      data-theme-tools-packages={surfaceProps['data-theme-tools-packages']}
    >
      <header className="mb-3 flex flex-col gap-2 sm:flex-row sm:items-baseline sm:justify-between">
        <h3 className="font-display text-base font-bold text-brand-ink">
          12-week savings: <span className="text-brand-accent">{formatUsd(totalSaved)}</span>
        </h3>
        <p className="text-xs text-brand-mute">
          Base {formatUsd(baseFare)} × {totalOccurrences} jobs · {factor.discountPct}% off each
        </p>
      </header>

      {!locked && (
        <div role="radiogroup" aria-label="Recurring cadence" className="mb-4 flex flex-wrap gap-2">
          {RECURRING_DISCOUNT_FACTORS.map((opt, index) => {
            const active = opt.cadence === cadence;
            return (
              <button
                key={opt.cadence}
                ref={(el) => {
                  radioRefs.current[index] = el;
                }}
                type="button"
                role="radio"
                aria-checked={active}
                tabIndex={rovingTabIndex(active)}
                onClick={() => setCadence(opt.cadence)}
                onKeyDown={(e) => onRadioKeyDown(e, index)}
                className={`rounded-full border px-3 py-1.5 text-xs font-medium transition ${
                  active
                    ? 'border-brand-accent bg-brand-accent/10 text-brand-accent'
                    : 'border-brand-line bg-bg-primary text-brand-mute hover:text-brand-ink'
                }`}
              >
                {opt.label} −{opt.discountPct}%
              </button>
            );
          })}
        </div>
      )}

      <ol
        className="grid grid-cols-12 items-end gap-1 h-32"
        aria-label={`Weekly savings bars for ${factor.label} cadence`}
      >
        {bars.map((b) => {
          const heightPct = b.saved > 0 ? Math.max(6, (b.saved / maxBar) * 100) : 2;
          return (
            <li
              key={b.weekIndex}
              className="flex flex-col items-center justify-end h-full"
              title={`Week ${b.weekIndex}: ${formatUsd(b.saved)} saved (${b.occurrences} job${
                b.occurrences === 1 ? '' : 's'
              })`}
            >
              <div
                className={`w-full rounded-t ${
                  b.saved > 0 ? 'bg-brand-accent/70' : 'bg-brand-line/40'
                }`}
                style={{ height: `${heightPct}%` }}
                aria-hidden
              />
              <span className="mt-1 text-[10px] font-mono text-brand-mute">{b.weekIndex}</span>
            </li>
          );
        })}
      </ol>
      <p className="mt-3 text-xs text-brand-mute">
        Week index along the x-axis. Hover/tap a bar for that week's saved amount.{' '}
        <span className="text-brand-ink">Locked rate.</span> 1 free skip per season on weekly plans.
      </p>
      <p
        data-testid="recurring-effective-hourly-rate"
        className="mt-2 font-mono text-[11px] text-brand-mute"
      >
        Standard rate: ${(pricingStandard.hourlyRatePerPersonCents / 100).toFixed(0)}/hr per crew ·
        15-min increments (${(pricingStandard.quarterHourIncrementCents / 100).toFixed(2)}) · 80% to
        crew (${(pricingStandard.completionBalanceCents / 100).toFixed(0)}/visit payout)
      </p>

      {/* CTA shown at EVERY breakpoint. Deep-links to /book, where the One-time/Subscription scheduler
          now renders on mobile+tablet too (fire-69 dual-mount) — so this is no longer a mobile dead-end.
          It was desktop-scoped in fire-68 ONLY while mobile recurring booking was still unbuilt (fire-70
          dropped the `hidden lg:` scope once fire-69 shipped). The savings visualizer renders everywhere. */}
      <a
        href={bookHref}
        data-testid="recurring-book-cta"
        className="mt-4 inline-flex items-center gap-1.5 rounded-md bg-brand-accent px-4 py-2 text-sm font-semibold text-black transition hover:brightness-110 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-accent"
      >
        Book a standing crew — save up to {maxDiscountPct}%<span aria-hidden="true">→</span>
      </a>
    </section>
  );
}
