import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect } from 'react';

/**
 * /refer — Crew + customer referral landing (idea #18).
 *
 * Two-rail referral page. Crew rail extends the existing referral.ts /
 * crew-referrals.ts plumbing — a crew member gets $25 per signed friend
 * via Stripe Connect payout. Customer rail: $25 credit per referred
 * neighbor's first paid booking.
 */
export function ReferPage() {
  useThemeToolsSurface('refer-page');
  useEffect(() => {
    document.title = 'Refer & Earn $25 · Brick Labor NJ';
    return () => {
      document.title = 'Brick Labor · $50/hr Property Crew Newark NJ';
    };
  }, []);

  return (
    <main className="bg-bg-primary min-h-screen pb-24">
      <section className="mx-auto max-w-3xl px-4 pt-12">
        <p className="mb-3 font-mono text-[11px] uppercase tracking-[0.18em] text-brand-accent">
          Referrals
        </p>
        <h1 className="mb-3 text-3xl font-bold leading-tight text-brand-ink sm:text-4xl">
          Both sides get $25.
        </h1>
        <p className="mb-8 text-brand-mute">
          Refer a neighbor or a crew member who'd be a fit. They get $25 off their first booking,
          you get $25 credit (or a Stripe Connect payout if you're crew).
        </p>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <article className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
            <p className="mb-2 font-mono text-[10px] uppercase tracking-widest text-brand-accent">
              For customers
            </p>
            <h2 className="mb-2 text-xl font-bold text-brand-ink">Refer a neighbor</h2>
            <p className="mb-4 text-sm text-brand-mute">
              You'll get a unique link from your dashboard after your first completed booking. Every
              neighbor who books through it = $25 off your next service.
            </p>
            <a
              href="/me"
              data-bcl-action="refer_customer_dashboard"
              className="inline-flex items-center rounded-md bg-brand-accent px-3 py-2 text-sm font-semibold text-black hover:brightness-110"
            >
              Open my dashboard →
            </a>
          </article>

          <article className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
            <p className="mb-2 font-mono text-[10px] uppercase tracking-widest text-brand-accent">
              For crew
            </p>
            <h2 className="mb-2 text-xl font-bold text-brand-ink">Refer a crew member</h2>
            <p className="mb-4 text-sm text-brand-mute">
              Get a Stripe Connect payout of $25 per referred crew that completes their first 3
              gigs. Bigger payouts as they tier up.
            </p>
            <a
              href="/work"
              data-bcl-action="refer_crew_dashboard"
              className="inline-flex items-center rounded-md bg-brand-accent px-3 py-2 text-sm font-semibold text-black hover:brightness-110"
            >
              Open crew dashboard →
            </a>
          </article>
        </div>

        <section className="mt-10 rounded-2xl border border-brand-line bg-bg-elevated/40 p-5">
          <p className="mb-2 font-mono text-[10px] uppercase tracking-widest text-brand-mute">
            The fine print
          </p>
          <ul className="list-disc space-y-1 pl-5 text-sm text-brand-mute">
            <li>Referral credit lands after the referred booking is paid + complete.</li>
            <li>Customer credit is one-time per neighbor; stacks across referrals.</li>
            <li>Crew payouts via Stripe Connect Express — set up in your crew dashboard.</li>
            <li>No self-referrals; we audit. No bot referrals; rate limited.</li>
          </ul>
        </section>
      </section>
    </main>
  );
}
