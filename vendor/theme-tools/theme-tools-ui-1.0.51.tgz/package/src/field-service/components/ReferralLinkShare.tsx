import { useThemeToolsSurface } from '../../field-service-primitives.js';
/**
 * ReferralLinkShare.tsx — Dub referral link sharing card.
 *
 * Flag-gated by `dub_referral_links`. Fetches GET /api/referral/links to
 * surface the user's branded short link. Falls back to static referral code
 * display when the endpoint doesn't exist yet.
 *
 * States:
 *   1. Loading — skeleton pulse while the API resolves
 *   2. Loaded — branded URL + copy-to-clipboard + SMS/email/share buttons
 *   3. Error/No-endpoint — static fallback showing the referral code
 */
import { useEffect, useState, type JSX } from 'react';
import { useFeatureFlag } from '../use-feature-flag.js';
import { track } from '../analytics.js';

interface ReferralLinksResponse {
  ok: boolean;
  links?: Array<{
    code: string;
    url: string;
    shortUrl: string;
    views: number;
    clicks: number;
  }>;
  code?: string;
}

const BRAND_SHORT_DOMAIN = 'bricklabor.com';

export function ReferralLinkShare(): JSX.Element | null {
  useThemeToolsSurface('referral-link-share');
  const flagOn = useFeatureFlag('dub_referral_links');
  const [data, setData] = useState<ReferralLinksResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!flagOn) {
      setLoading(false);
      return;
    }
    const controller = new AbortController();
    (async () => {
      try {
        const r = await fetch('/api/referral/links', { signal: controller.signal });
        if (!r.ok) {
          // 404 = no endpoint yet → fallback to static code display
          if (r.status === 404) {
            setData({ ok: false });
          } else {
            setError(r.status === 401 ? 'unauthorized' : `http_${r.status}`);
          }
          setLoading(false);
          return;
        }
        const j = (await r.json()) as ReferralLinksResponse;
        setData(j);
      } catch {
        if (controller.signal.aborted) return;
        setError('network');
      } finally {
        if (!controller.signal.aborted) setLoading(false);
      }
    })();
    return () => controller.abort();
  }, [flagOn]);

  if (!flagOn) return null;

  // Loading state
  if (loading) {
    return (
      <div
        data-testid="referral-link-share"
        className="rounded-2xl border border-brand-line bg-bg-elevated p-5"
      >
        <div className="h-5 w-40 animate-pulse rounded bg-brand-line" />
        <div className="mt-3 h-4 w-3/4 animate-pulse rounded bg-brand-line" />
        <div className="mt-4 h-10 w-full animate-pulse rounded-lg bg-brand-line" />
      </div>
    );
  }

  // Static fallback when the endpoint returned nothing or errored.
  if (!data?.links?.length) {
    return (
      <StaticFallbackShare code={data?.code ?? null} error={error} />
    );
  }

  // Loaded — we have live referral links from the API.
  const link = data.links[0]!;
  if (!link) return <StaticFallbackShare code={data.code ?? null} error={null} />;

  const fullUrl = link.shortUrl || `${BRAND_SHORT_DOMAIN}/r/${link.code}`;
  const shareText = `Use my Brick Labor referral code ${link.code} for $25 off your first service: ${fullUrl}`;
  const smsUrl = `sms:?body=${encodeURIComponent(shareText)}`;
  const mailtoUrl = `mailto:?subject=${encodeURIComponent('Brick Labor — $25 off')}&body=${encodeURIComponent(shareText)}`;

  async function onCopy(): Promise<void> {
    try {
      await navigator.clipboard.writeText(fullUrl);
      setCopied(true);
      track('referral_link_copy', { code: link.code });
      setTimeout(() => setCopied(false), 2000);
    } catch {
      /* ignore */
    }
  }

  async function onNativeShare(): Promise<void> {
    if (typeof navigator === 'undefined' || !('share' in navigator)) return;
    try {
      await navigator.share({ title: 'Brick Labor — $25 off', text: shareText, url: fullUrl });
      track('referral_link_share_native', { code: link.code });
    } catch {
      /* user dismissed */
    }
  }

  return (
    <section
      data-testid="referral-link-share"
      data-bcl-surface="referral-link-share"
      className="rounded-2xl border border-brand-accent/30 bg-gradient-to-br from-brand-accent/5 to-transparent p-6"
      aria-labelledby="rls-h2"
    >
      <header className="mb-4">
        <p className="eyebrow mb-1">Your referral link</p>
        <h2 id="rls-h2" className="font-display text-xl font-extrabold">
          Share and earn
        </h2>
        {(link.views > 0 || link.clicks > 0) && (
          <div className="mt-1 flex gap-4 text-xs text-brand-mute">
            {link.views > 0 && <span>{link.views} views</span>}
            {link.clicks > 0 && <span>{link.clicks} clicks</span>}
          </div>
        )}
      </header>

      {/* URL + copy row */}
      <div className="mb-3 flex items-center gap-2 rounded-lg border border-brand-line bg-bg-primary px-3 py-2 font-mono text-xs sm:text-sm">
        <span className="truncate text-brand-ink">{fullUrl}</span>
        <button
          type="button"
          onClick={onCopy}
          className="ml-auto shrink-0 rounded-md bg-brand-accent px-3 py-1.5 text-xs font-bold text-bg-primary"
          data-bcl-action="referral_copy"
        >
          {copied ? 'Copied ✓' : 'Copy'}
        </button>
      </div>

      <p className="mb-4 text-sm text-brand-mute leading-relaxed">
        Share your link with friends and neighbors. When they book through it, they get{' '}
        <strong className="text-brand-ink">$25 off</strong> and you earn a
        <strong className="text-brand-ink"> $25 credit</strong>.
      </p>

      <div className="flex flex-wrap gap-2">
        <a
          href={smsUrl}
          className="inline-flex min-h-[44px] items-center justify-center rounded-lg border border-brand-line bg-bg-elevated px-4 py-2 text-sm font-bold text-brand-ink"
          data-bcl-action="referral_share_sms"
        >
          Share via SMS
        </a>
        <a
          href={mailtoUrl}
          className="inline-flex min-h-[44px] items-center justify-center rounded-lg border border-brand-line bg-bg-elevated px-4 py-2 text-sm font-bold text-brand-ink"
          data-bcl-action="referral_share_email"
        >
          Share via email
        </a>
        <button
          type="button"
          onClick={onNativeShare}
          className="inline-flex min-h-[44px] items-center justify-center rounded-lg bg-brand-accent px-4 py-2 text-sm font-extrabold text-bg-primary"
          data-bcl-action="referral_share_native"
        >
          Share...
        </button>
      </div>
    </section>
  );
}

/**
 * Static fallback shown when the API endpoint doesn't exist or errors.
 * Displays the referral code without a minted link.
 */
function StaticFallbackShare({
  code,
  error,
}: {
  code: string | null;
  error: string | null;
}): JSX.Element {
  const displayCode = code || 'BCL-XXXXXX';
  const [copied, setCopied] = useState(false);

  async function onCopy(): Promise<void> {
    try {
      await navigator.clipboard.writeText(displayCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      /* ignore */
    }
  }

  return (
    <section
      data-testid="referral-link-share"
      data-bcl-surface="referral-link-share"
      className="rounded-2xl border border-brand-line bg-bg-elevated p-6"
      aria-labelledby="rls-static-h2"
    >
      <p className="eyebrow mb-1">Referral code</p>
      <h2 id="rls-static-h2" className="font-display text-xl font-extrabold">
        Your shareable code
      </h2>
      <p className="mt-2 text-sm text-brand-mute leading-relaxed">
        {error
          ? 'Could not load your referral links right now.'
          : `Share your code for $25 off each other’s first booking.`}
      </p>

      <div className="mt-4 flex items-center gap-2 rounded-lg border border-brand-line bg-bg-primary px-3 py-2 font-mono text-sm">
        <span className="text-brand-ink">{displayCode}</span>
        <button
          type="button"
          onClick={onCopy}
          className="ml-auto shrink-0 rounded-md bg-brand-accent px-3 py-1.5 text-xs font-bold text-bg-primary"
          data-bcl-action="referral_code_copy"
        >
          {copied ? 'Copied ✓' : 'Copy'}
        </button>
      </div>

      {!code && !error && (
        <p className="mt-3 text-xs text-brand-mute">
          Complete your first booking and you'll receive a personalized code.
        </p>
      )}
      {error === 'unauthorized' && (
        <p role="alert" className="mt-3 text-sm text-amber-300">
          Please sign in to see your referral code.
        </p>
      )}
    </section>
  );
}
