import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { type PricingFact, type ServiceAreaFact, sourceById, SOURCES } from '../data/research.js';
import { stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { researchPanelCopy } from '@theme.tools/i18n-a11y/field-service/research-panel-copy';

interface PanelProps {
  /**
   * Benchmark rows. `value` + `citationId` are locale-invariant (sourced from
   * `data/research.ts`); the prose label/detail are localized by `citationId`
   * via `researchPanelCopy(locale)`, falling back to the row's own strings.
   */
  facts: Array<PricingFact | ServiceAreaFact>;
}

export function ResearchPanel({ facts }: PanelProps) {
  useThemeToolsSurface('research-panel');
  // SSR renders `en`; the SPA re-reads the locale from the path on hydration so
  // `/es` + `/pt` swap the eyebrow / headline / intro / per-row prose / refs.
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const c = researchPanelCopy(locale);
  const refIds = Array.from(new Set(facts.map((f) => f.citationId)));
  return (
    <section
      aria-labelledby="research-panel-heading"
      className="section-tight bg-bg-elevated/30 border-y border-brand-line"
    >
      <div className="container-pad">
        <div className="mb-8 max-w-3xl" data-animate="fade-up">
          <p className="eyebrow mb-3">{c.eyebrow}</p>
          <h2 id="research-panel-heading" className="text-3xl sm:text-4xl font-extrabold">
            {c.title}
          </h2>
          <p className="mt-3 text-base text-brand-mute leading-relaxed">{c.intro}</p>
        </div>

        <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3" data-stagger="80">
          {facts.map((f) => {
            const src = sourceById(f.citationId);
            const refIndex = refIds.indexOf(f.citationId) + 1;
            const fc = c.facts[f.citationId];
            const label = fc?.label ?? f.label;
            const detail = fc?.detail ?? f.detail;
            return (
              <li
                key={`${f.citationId}-${f.value}`}
                data-animate="fade-up"
                className="rounded-xl border border-brand-line bg-bg-primary p-5"
              >
                <div className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
                  {label}
                </div>
                <div className="mt-2 font-display text-3xl font-extrabold text-brand-accent">
                  {f.value}
                </div>
                <p className="mt-2 text-sm text-brand-mute leading-snug">{detail}</p>
                <p className="mt-3 font-mono text-[10px] uppercase tracking-widest">
                  <a
                    href={`#ref-${src.id}`}
                    className="text-brand-mute underline-hover hover:text-brand-accent"
                    aria-label={`${c.sourceLabel} ${refIndex}`}
                  >
                    {c.sourceLabel} [{refIndex}]
                  </a>
                </p>
              </li>
            );
          })}
        </ul>

        <p className="mt-7 font-mono text-xs text-brand-mute border-l-2 border-brand-accent pl-4 max-w-3xl">
          {c.contextNote}
        </p>

        <ReferencesList ids={refIds} heading={c.referencesHeading} />
      </div>
    </section>
  );
}

interface ReferencesListProps {
  ids: Array<keyof typeof SOURCES>;
  /** Localized "References (APA 7th ed.)" heading; defaults to English. */
  heading?: string;
}

export function ReferencesList({ ids, heading = 'References (APA 7th ed.)' }: ReferencesListProps) {
  if (ids.length === 0) return null;
  return (
    <aside
      aria-labelledby="references-heading"
      className="mt-10 rounded-xl border border-brand-line bg-bg-primary p-5 sm:p-6"
    >
      <h3
        id="references-heading"
        className="font-mono text-[11px] uppercase tracking-widest text-brand-accent"
      >
        {heading}
      </h3>
      <ol className="mt-4 space-y-2.5 text-sm text-brand-mute">
        {ids.map((id, i) => {
          const s = sourceById(id);
          return (
            <li key={s.id} id={`ref-${s.id}`} className="pl-8 -indent-8 leading-relaxed">
              <span className="font-mono text-[11px] text-brand-accent mr-2">[{i + 1}]</span>
              {s.apa}{' '}
              <a
                href={s.url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-brand-accent underline-hover break-words"
              >
                {s.url}
              </a>
            </li>
          );
        })}
      </ol>
    </aside>
  );
}
