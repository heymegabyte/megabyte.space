import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { PHONE_DISPLAY, PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';

interface Props {
  readonly message: string;
  /** Transient errors (5xx / network) get a one-click retry; dead/expired links don't. */
  readonly canRetry: boolean;
  readonly onRetry: () => void;
  readonly copy: {
    readonly errTryAgain: string;
    readonly errCallUs: string;
    readonly errBackHome: string;
  };
}

/**
 * Pure error-recovery panel for the `/review/:gigId` page (the LITERAL terminus of
 * the customer money loop: book → pay → track → review). Pairs the error message
 * with a one-click retry (transient 5xx/network errors only — a retry can't fix a
 * dead/expired link) + a STANDING contact fallback (call/text the canonical line,
 * never a fabricated number) + a home link, so a customer whose review link failed
 * is never dead-ended. Extracted pure so the effect-driven error state is covered
 * by a node-env static-markup test (same constraint as ReferralErrorPanel /
 * FloatingCallButton). Unflagged — an error-recovery affordance must reach EVERY
 * customer who hits the error.
 */
export function ReviewErrorPanel({ message, canRetry, onRetry, copy }: Props) {
  useThemeToolsSurface('review-error-panel');
  return (
    <div
      data-testid="review-error"
      role="alert"
      className="rounded-lg border border-red-500/40 bg-red-500/10 p-4 text-red-200"
    >
      <p className="mb-3">{message}</p>
      <div className="flex flex-wrap items-center gap-3">
        {canRetry && (
          <button
            type="button"
            data-testid="review-error-retry"
            onClick={onRetry}
            className="inline-flex min-h-[44px] items-center justify-center rounded-md bg-brand-accent px-4 py-2 font-semibold text-bg-primary transition-colors hover:bg-brand-accent/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent focus-visible:ring-offset-2 focus-visible:ring-offset-brand-card"
          >
            {copy.errTryAgain}
          </button>
        )}
        <a
          data-testid="review-error-call"
          href={PHONE_TEL_HREF}
          className="inline-flex min-h-[44px] items-center justify-center rounded-md border border-brand-line px-4 py-2 font-semibold text-brand-ink transition-colors hover:border-brand-accent hover:text-brand-accent"
        >
          {copy.errCallUs} {PHONE_DISPLAY}
        </a>
        <a
          data-testid="review-error-home"
          href="/"
          className="text-sm text-brand-mute underline transition-colors hover:text-brand-ink"
        >
          {copy.errBackHome}
        </a>
      </div>
    </div>
  );
}
