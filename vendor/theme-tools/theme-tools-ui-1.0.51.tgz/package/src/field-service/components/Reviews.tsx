import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect, useState } from 'react';

// Pulls live Google Business reviews via /api/reviews (server-side cached
// 24h in KV). Renders nothing when the endpoint reports the integration is
// disabled — keeps the homepage clean while the place ID is being set up.

interface Review {
  author: string;
  rating: number;
  text: string;
  relativeTime: string;
  profilePhotoUrl?: string;
}

interface ReviewsPayload {
  ok: boolean;
  disabled?: boolean;
  rating?: number;
  ratingCount?: number;
  reviews?: Review[];
  cachedAt?: string;
}

export function Reviews() {
  useThemeToolsSurface('reviews');
  const [data, setData] = useState<ReviewsPayload | null>(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    let stopped = false;
    fetch('/api/reviews', { headers: { Accept: 'application/json' } })
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error(String(r.status)))))
      .then((json: ReviewsPayload) => {
        if (!stopped) setData(json);
      })
      .catch(() => {
        if (!stopped) setError(true);
      });
    return () => {
      stopped = true;
    };
  }, []);

  if (error || !data || data.disabled || !data.reviews?.length) return null;

  const rating = data.rating ?? 0;
  const count = data.ratingCount ?? 0;

  return (
    <section id="reviews" className="section bg-bg-secondary">
      <div className="container-pad">
        <div className="mb-10 max-w-3xl" data-animate="fade-up">
          <p className="eyebrow mb-3">Google reviews</p>
          <h2 className="text-4xl sm:text-5xl font-extrabold">
            <span className="text-gradient">{rating.toFixed(1)}★</span> across {count} reviews
          </h2>
          <p className="mt-4 text-lg text-brand-mute">
            Pulled live from Google Business — updated daily, no cherry-picking.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {data.reviews.slice(0, 6).map((r, i) => (
            <article
              key={`${r.author}-${i}`}
              className="card flex flex-col gap-3"
              data-animate="fade-up"
              data-animate-delay={i * 50}
            >
              <header className="flex items-center gap-3">
                {r.profilePhotoUrl ? (
                  <img
                    src={r.profilePhotoUrl}
                    alt=""
                    width={40}
                    height={40}
                    loading="lazy"
                    className="size-10 rounded-full bg-brand-line object-cover"
                  />
                ) : (
                  <span
                    className="size-10 rounded-full bg-brand-line text-brand-mute grid place-items-center font-mono"
                    aria-hidden="true"
                  >
                    {r.author.charAt(0).toUpperCase()}
                  </span>
                )}
                <div>
                  <p className="font-semibold text-brand-ink leading-tight">{r.author}</p>
                  <p className="text-xs text-brand-mute">{r.relativeTime}</p>
                </div>
              </header>
              <Stars rating={r.rating} />
              <p className="text-sm text-brand-mute leading-relaxed">{r.text}</p>
            </article>
          ))}
        </div>

        <p className="mt-8 text-center">
          <a
            href="https://www.google.com/maps/search/Brick+Labor+Newark+NJ/"
            target="_blank"
            rel="noopener noreferrer"
            className="text-brand-accent underline-hover"
          >
            See all Google reviews →
          </a>
        </p>
      </div>
    </section>
  );
}

function Stars({ rating }: { rating: number }) {
  const full = Math.round(rating);
  return (
    <div className="flex gap-0.5" aria-label={`${rating} out of 5`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <span
          key={i}
          aria-hidden="true"
          className={i < full ? 'text-brand-accent' : 'text-brand-line'}
        >
          ★
        </span>
      ))}
    </div>
  );
}
