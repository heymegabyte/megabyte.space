import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect, useRef, useState } from 'react';

interface RollingCounterProps {
  value: number;
  decimals?: number;
  prefix?: string;
  suffix?: string;
  /** Animation duration in ms. Defaults to 1200. */
  durationMs?: number;
  /** BCP-47 locale tag for Intl.NumberFormat. Defaults to 'en-US'. */
  locale?: string;
}

/**
 * Animated count-up. Eases from the previously rendered value (or 0 on first
 * mount) to `value` using `requestAnimationFrame` + ease-out-quart, formatted
 * via `Intl.NumberFormat`. `font-variant-numeric: tabular-nums` so digits
 * don't reflow mid-animation. `prefers-reduced-motion: reduce` snaps to the
 * final value instantly. `aria-label` always reflects the FINAL formatted
 * value so screen readers announce truth on focus, not the rolling
 * intermediate.
 */
export function RollingCounter({
  value,
  decimals = 0,
  prefix = '',
  suffix = '',
  durationMs = 1200,
  locale = 'en-US',
}: RollingCounterProps): JSX.Element {
  useThemeToolsSurface('rolling-counter');
  const [display, setDisplay] = useState<number>(value);
  const prevRef = useRef<number>(0);
  const firstMountRef = useRef<boolean>(true);

  const formatter = new Intl.NumberFormat(locale, {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
  const finalText = `${prefix}${formatter.format(value)}${suffix}`;

  useEffect(() => {
    const reduce =
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const from = firstMountRef.current ? 0 : prevRef.current;
    firstMountRef.current = false;
    if (reduce || from === value || durationMs <= 0) {
      setDisplay(value);
      prevRef.current = value;
      return;
    }
    const start = performance.now();
    let raf = 0;
    function tick(now: number): void {
      const t = Math.min(1, (now - start) / durationMs);
      // ease-out-quart
      const eased = 1 - Math.pow(1 - t, 4);
      const current = from + (value - from) * eased;
      setDisplay(current);
      if (t < 1) {
        raf = requestAnimationFrame(tick);
      } else {
        prevRef.current = value;
      }
    }
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value, durationMs]);

  return (
    <span aria-label={finalText} style={{ fontVariantNumeric: 'tabular-nums' }}>
      {prefix}
      {formatter.format(display)}
      {suffix}
    </span>
  );
}
