import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
/**
 * SameDayPricingCard.tsx — Tier-S idea #9 "Same-day with surge transparency".
 *
 * Displayed inside the booking summary card when the customer's preferred date
 * resolves to "today" AND today's surge multiplier > 1.0. Shows side-by-side:
 *
 *   Today        | Tomorrow
 *   $X (with surge) | $Y (no surge)
 *
 * with a one-tap "Switch to tomorrow" CTA that hands the new date back to the
 * parent via `onSwitchToTomorrow`. Also surfaces an explicit "Why?" link that
 * opens the existing SurgeExplainerModal — transparency is the lever, not
 * sticker shock.
 *
 * Research backing (see _ideas-50-research-backed.md #9): voice-AI response-
 * time studies show no-show rates drop 60% (12-18% → 4-7%) when customers see
 * the urgency tradeoff up-front; the FSR 2026 study cites instant ETA
 * visibility as the lever. Same pattern here: surface the price tradeoff and
 * let the customer self-select.
 *
 * Flag-gated by `same_day_transparency`. Render-null when off.
 */
import { useFeatureFlag } from '../use-feature-flag.js';
import { computeSurge, surgeCents, type SurgeContext } from '@theme.tools/billing/field-service/surge';
import { usd0 } from '@theme.tools/billing/field-service/money';
import { evaluateCurbAndParkingClearance } from '@theme.tools/scheduling/field-service/theme-tools-field-service-bridge';

interface Props {
  /** Current SurgeContext (date + time + services) — same shape Booking.tsx feeds computeSurge. */
  context: SurgeContext;
  /** Pre-surge subtotal in dollars (base × crew × hours). */
  subtotalDollars: number;
  /** ISO YYYY-MM-DD for tomorrow (caller computes — keeps the component pure). */
  tomorrowIso: string;
  /** Fires when the user clicks "Switch to tomorrow". Parent updates the form. */
  onSwitchToTomorrow: () => void;
  /** Optional callback to open the SurgeExplainerModal — wires "Why this price?". */
  onOpenWhy?: () => void;
}

// Whole-dollar fares, grouped — `$2,560`, never a commaless "$2560".
function formatUsd(dollars: number): string {
  return usd0(Math.round(dollars * 100));
}

function isTodayET(preferredDate?: string, nowIso?: string): boolean {
  if (!preferredDate) return false;
  const now = nowIso ? new Date(nowIso) : new Date();
  const offset = 5 * 60 * 60 * 1000;
  const shifted = new Date(now.getTime() - offset);
  const todayIso = `${shifted.getUTCFullYear()}-${String(shifted.getUTCMonth() + 1).padStart(2, '0')}-${String(shifted.getUTCDate()).padStart(2, '0')}`;
  return preferredDate === todayIso;
}

export function SameDayPricingCard(props: Props): JSX.Element | null {
  useThemeToolsSurface('same-day-pricing-card');
  const enabled = useFeatureFlag('same_day_transparency');
  if (!enabled) return null;

  const { context, subtotalDollars, tomorrowIso, onSwitchToTomorrow, onOpenWhy } = props;

  if (!isTodayET(context.preferredDate, context.nowIso)) return null;

  const subtotalCents = Math.round(subtotalDollars * 100);
  const todaySurge = computeSurge(context);
  // Compare the SAME job booked tomorrow — same time of day, shifted +24h. Two traps
  // this avoids, both of which kept this transparency card DARK on prod (SCAN-34):
  //   (1) spreading `...context` carries today's startAt, and parseServiceStart
  //       (surge.ts) prefers startAt over preferredDate → the "tomorrow" calc reuses
  //       TODAY's instant → tomorrowSurge === todaySurge → savings 0 → card null.
  //   (2) merely clearing startAt falls back to a 09:00 default — and "same-day" surge
  //       is "booked <24h before service" (surge.ts:94), NOT "date == today". On an
  //       AFTERNOON now, tomorrow 09:00 is still <24h out → the same-day band fires for
  //       tomorrow too → savings 0 again.
  // Shifting the real slot instant by exactly +24h guarantees tomorrow lands in the
  // genuine next-day band (24–48h), so the saving is real and the card renders whenever
  // a same-day future slot is selected.
  const tomorrowStartAt = context.startAt
    ? new Date(new Date(context.startAt).getTime() + 86_400_000).toISOString()
    : undefined;
  const tomorrowSurge = computeSurge({
    ...context,
    preferredDate: tomorrowIso,
    preferredTime: undefined,
    startAt: tomorrowStartAt,
  });

  const todaySurgeCents = surgeCents(subtotalCents, todaySurge);
  const tomorrowSurgeCents = surgeCents(subtotalCents, tomorrowSurge);

  const todayTotal = (subtotalCents + todaySurgeCents) / 100;
  const tomorrowTotal = (subtotalCents + tomorrowSurgeCents) / 100;
  const savings = todayTotal - tomorrowTotal;

  // Don't render the card when there's no meaningful tradeoff. Saves visual
  // noise when the customer's booking falls outside any surge window today.
  if (savings <= 5) return null;

  const todayPct = Math.round((todaySurge.multiplier - 1) * 100);
  const tomorrowPct = Math.round((tomorrowSurge.multiplier - 1) * 100);

  return (
    <div
      data-testid="same-day-pricing-card"
      data-bcl-surface="same-day-card"
      className="mt-3 rounded-xl border border-amber-300/30 bg-amber-50/5 p-3 text-sm"
      role="region"
      aria-label="Same-day pricing comparison"
    >
      <div className="mb-2 flex items-center justify-between gap-2">
        <div className="font-semibold text-amber-300">
          You can save {formatUsd(savings)} by booking tomorrow
        </div>
        {onOpenWhy ? (
          <button
            type="button"
            onClick={onOpenWhy}
            className="text-xs text-brand-mute underline underline-offset-2 hover:text-brand-ink"
            data-bcl-action="surge_why_click"
          >
            Why?
          </button>
        ) : null}
      </div>
      <div className="grid grid-cols-2 gap-2">
        <div className="rounded-lg border border-amber-300/40 bg-amber-100/5 p-2">
          <div className="text-xs uppercase tracking-wider text-amber-300/80">Today</div>
          <div className="mt-1 font-display text-xl font-extrabold text-brand-ink">
            {formatUsd(todayTotal)}
          </div>
          <div className="mt-0.5 text-[11px] text-amber-300/90">
            {todayPct > 0 ? `+${todayPct}% same-day surge` : 'No surge'}
          </div>
        </div>
        <div className="rounded-lg border border-emerald-300/40 bg-emerald-100/5 p-2">
          <div className="text-xs uppercase tracking-wider text-emerald-300/80">Tomorrow</div>
          <div className="mt-1 font-display text-xl font-extrabold text-brand-ink">
            {formatUsd(tomorrowTotal)}
          </div>
          <div className="mt-0.5 text-[11px] text-emerald-300/90">
            {tomorrowPct > 0 ? `+${tomorrowPct}% standard surge` : 'No surge'}
          </div>
        </div>
      </div>
      <button
        type="button"
        onClick={onSwitchToTomorrow}
        data-bcl-action="switch_to_tomorrow"
        data-bcl-surface="same-day-card"
        className="mt-3 inline-flex w-full min-h-[44px] items-center justify-center gap-1 rounded-lg bg-brand-accent px-3 py-2 text-sm font-extrabold text-bg-primary"
      >
        Switch to tomorrow → save {formatUsd(savings)}
      </button>
      <p className="mt-2 text-[11px] leading-snug text-brand-mute">
        Same-day rush pricing reflects the cost of holding a crew slot on zero notice. Tomorrow gets
        standard rates and the same crew quality.
      </p>
      <p
        data-testid="same-day-category-readiness"
        className="mt-1.5 text-[11px] font-mono text-amber-200/80"
      >
        Curb readiness: reserve{' '}
        {
          evaluateCurbAndParkingClearance({
            categorySlug: context.services?.[0] ?? 'moving-help',
          }).requiredCurbLengthFt
        }{' '}
        ft curb space (high-rise COI buildings require 24h+ notice).
      </p>
    </div>
  );
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
