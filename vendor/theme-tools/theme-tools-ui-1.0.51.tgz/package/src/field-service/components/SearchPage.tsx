import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useCallback, useEffect, useRef, useState } from 'react';

import { useFeatureFlag } from '../use-feature-flag.js';

type SearchDocType = 'service' | 'blog' | 'neighborhood';

interface SearchResult {
  id: string;
  type: SearchDocType;
  title: string;
  url: string;
  snippet: string;
}

const TYPE_LABEL: Record<SearchDocType, string> = {
  service: 'Service',
  blog: 'Article',
  neighborhood: 'Coverage area',
};

/**
 * `/search` — edge-native full-text search over services, articles, and
 * coverage areas. Backed by `GET /api/search` (Orama in the Worker). Gated by
 * the `edge_search` flag: when off, the API 404s and we show a notice.
 *
 * Brand-locked dark-first surface: `brand-*` tokens, 0.333s transitions,
 * staggered `bcl-reveal-up` entrance (motion-safe-gated), type pills, and a
 * pulsing card skeleton while a query is in flight — so the page matches the
 * marketing chrome the moment `edge_search` is promoted.
 */
export function SearchPage() {
  useThemeToolsSurface('search-page');
  const enabled = useFeatureFlag('edge_search');
  const [q, setQ] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [state, setState] = useState<'idle' | 'loading' | 'done' | 'unavailable' | 'error'>('idle');
  const reqId = useRef(0);

  const seedFromUrl = useCallback(() => {
    const params = new URLSearchParams(window.location.search);
    const initial = params.get('q') ?? '';
    if (initial) setQ(initial);
  }, []);

  useEffect(() => {
    seedFromUrl();
  }, [seedFromUrl]);

  useEffect(() => {
    const term = q.trim();
    if (!term) {
      setResults([]);
      setState('idle');
      return;
    }
    const id = ++reqId.current;
    const controller = new AbortController();
    setState('loading');
    const handle = window.setTimeout(async () => {
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(term)}`, {
          signal: controller.signal,
        });
        if (id !== reqId.current) return;
        if (res.status === 404) {
          setResults([]);
          setState('unavailable');
          return;
        }
        if (!res.ok) throw new Error(`Search request failed with ${res.status}`);
        const data = (await res.json()) as { results?: SearchResult[] };
        setResults(data.results ?? []);
        setState('done');
      } catch (error) {
        if (error instanceof DOMException && error.name === 'AbortError') return;
        if (id === reqId.current) {
          setResults([]);
          setState('error');
        }
      }
    }, 180);
    return () => {
      window.clearTimeout(handle);
      controller.abort();
    };
  }, [q]);

  return (
    <main className="section" aria-labelledby="search-h1">
      <div className="container-pad max-w-2xl">
        <p className="eyebrow mb-3">Find it fast</p>
        <h1
          id="search-h1"
          className="text-4xl font-extrabold tracking-tight text-brand-ink sm:text-5xl"
        >
          Search Brick Labor
        </h1>
        <p className="mt-2 text-brand-mute">Services, articles, and the neighborhoods we cover.</p>

        <label htmlFor="site-search" className="sr-only">
          Search the site
        </label>
        <input
          id="site-search"
          type="search"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          autoFocus
          placeholder="Try “junk removal”, “Ironbound”, or “moving help”…"
          className="mt-7 w-full rounded-xl border border-brand-line bg-bg-elevated/60 px-4 py-3.5 text-base text-brand-ink shadow-sm outline-none transition-all duration-[333ms] placeholder:text-brand-mute/70 focus:border-brand-accent focus:ring-2 focus:ring-brand-accent/30"
          aria-describedby="search-status"
        />

        <p
          id="search-status"
          role="status"
          className="mt-3 min-h-[1.25rem] text-sm text-brand-mute"
        >
          {state === 'unavailable' && 'Search is not available yet.'}
          {state === 'error' && 'Search is temporarily unavailable. Try again.'}
          {state === 'loading' && 'Searching…'}
          {state === 'done' && (
            <span>
              <span className="font-semibold text-brand-accent">{results.length}</span> result
              {results.length === 1 ? '' : 's'}.
            </span>
          )}
          {!enabled && state === 'idle' && 'Search is not available yet.'}
        </p>

        {state === 'loading' ? (
          <ul className="mt-3 flex flex-col gap-3" aria-hidden="true">
            {[0, 1, 2].map((i) => (
              <li
                key={i}
                className="animate-pulse rounded-xl border border-brand-line bg-bg-elevated/50 p-4"
              >
                <div className="h-3 w-20 rounded-full bg-brand-mute/20" />
                <div className="mt-3 h-4 w-2/3 rounded bg-brand-mute/20" />
                <div className="mt-2 h-3 w-full rounded bg-brand-mute/10" />
              </li>
            ))}
          </ul>
        ) : (
          <ul className="mt-3 flex flex-col gap-3">
            {results.map((r, i) => (
              <li
                key={r.id}
                style={{ animationDelay: `${i * 50}ms` }}
                className="motion-safe:[animation:bcl-reveal-up_0.4s_ease-out_both]"
              >
                <a
                  href={r.url}
                  className="group block rounded-xl border border-brand-line bg-bg-elevated/60 p-4 transition-all duration-[333ms] hover:-translate-y-0.5 hover:border-brand-accent/50 hover:bg-bg-elevated focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent/60"
                >
                  <span className="inline-block rounded-full border border-brand-accent/30 bg-brand-accent/10 px-2.5 py-0.5 text-[11px] font-medium uppercase tracking-wide text-brand-accent">
                    {TYPE_LABEL[r.type]}
                  </span>
                  <span className="mt-2 block text-base font-semibold text-brand-ink group-hover:text-brand-accent">
                    {r.title}
                  </span>
                  {r.snippet ? (
                    <span className="mt-1 block text-sm text-brand-mute">{r.snippet}</span>
                  ) : null}
                </a>
              </li>
            ))}
          </ul>
        )}

        {state === 'done' && results.length === 0 && q.trim() ? (
          <p className="mt-6 text-sm text-brand-mute">
            No matches. Try a broader term — or{' '}
            <a href="/book" className="font-medium text-brand-accent underline-hover">
              book a job
            </a>{' '}
            and tell us what you need.
          </p>
        ) : null}
      </div>
    </main>
  );
}

export default SearchPage;
