import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { POWER_WASH_PROTOCOLS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { useEffect } from 'react';
import {
  SERVICE_GUARANTEE_COVERED,
  SERVICE_GUARANTEE_EXCLUDED,
  SERVICE_GUARANTEE_HEADLINE,
  SERVICE_GUARANTEE_RESPONSE_WINDOW,
} from '@theme.tools/crm/field-service/service-guarantee';
import { PHONE_SMS_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';

/**
 * /guarantee — Public service guarantee page. Every refund is reviewed against
 * the booking, photos, and audit log, then returned to the original card via
 * Square. Covered/excluded scope renders from the `service-guarantee` SSOT so
 * this page, the Terms contract, and the booking-form promise can never drift.
 */
export function ServiceGuaranteePage() {
  useThemeToolsSurface('service-guarantee-page');
  useEffect(() => {
    document.title = 'Service Guarantee · Brick Labor NJ';
    return () => {
      document.title = 'Brick Labor · $50/hr Property Crew Newark NJ';
    };
  }, []);
  return (
    <main className="bg-bg-primary min-h-screen pb-24">
      <section className="mx-auto max-w-3xl px-4 pt-12">
        <p className="mb-3 font-mono text-[11px] uppercase tracking-[0.18em] text-brand-accent">
          Service guarantee
        </p>
        <h1 className="mb-3 text-4xl font-bold leading-tight text-brand-ink">
          {SERVICE_GUARANTEE_HEADLINE}
        </h1>
        <p className="mb-8 text-brand-mute text-lg">
          If a job genuinely falls short, you get your money back. Every request is reviewed against
          the booking, the photos, and the audit log — and gets a personal decision{' '}
          {SERVICE_GUARANTEE_RESPONSE_WINDOW}.
        </p>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <Step n="1" title="Tell us">
            Open the AI chat on any page, hit "Refund" on your booking in{' '}
            <a href="/me" className="text-brand-accent underline">
              /me
            </a>
            , or text the owner at{' '}
            <a href={PHONE_SMS_HREF} className="text-brand-accent underline">
              (855) 82LABOR
            </a>
            .
          </Step>
          <Step n="2" title="We review">
            We judge the request against the booking, the photos, and the audit log — then reply with
            a personal decision {SERVICE_GUARANTEE_RESPONSE_WINDOW}.
          </Step>
          <Step n="3" title="Refund returns">
            Once approved, Square pushes the refund back to the same card you paid with. No store
            credit, no gift cards, no friction.
          </Step>
        </div>

        <h2 className="mt-10 mb-3 text-2xl font-bold text-brand-ink">What's covered</h2>
        <ul className="space-y-2 text-sm text-brand-ink">
          {SERVICE_GUARANTEE_COVERED.map((s) => (
            <Bullet key={s.id}>{s.text}</Bullet>
          ))}
        </ul>

        <h2 className="mt-8 mb-3 text-2xl font-bold text-brand-ink">What's not covered</h2>
        <ul className="space-y-2 text-sm text-brand-mute">
          {SERVICE_GUARANTEE_EXCLUDED.map((s) => (
            <Bullet key={s.id} muted>
              {s.text}
            </Bullet>
          ))}
        </ul>

        <div className="mt-10 rounded-2xl border border-brand-accent bg-brand-accent/10 p-5">
          <p className="text-brand-ink">
            Already have a booking that needs reviewing?{' '}
            <a
              href="/me#refund"
              data-bcl-action="guarantee_cta_click"
              className="font-semibold text-brand-accent underline"
            >
              Open the refund form →
            </a>
          </p>
        </div>

        <h2 className="mt-10 mb-3 text-2xl font-bold text-brand-ink">FAQ</h2>
        <Faq q="How do I start a refund?">
          Use the in-page AI chat, hit "Refund" on the booking in your account, or text the owner at
          (855) 82LABOR. Tell us what went wrong — we pull the booking, photos, and audit log to
          review it.
        </Faq>
        <Faq q="What if my request is declined and I disagree?">
          Reply "Escalate" and it goes straight to the owner's queue for a personal second look,
          answered {SERVICE_GUARANTEE_RESPONSE_WINDOW}.
        </Faq>
        <Faq q="When does the refund hit my card?">
          We process the refund through Square as soon as it is approved; your bank then takes 1-7
          business days to post it, depending on the issuer.
        </Faq>
      </section>

      <script
        type="application/ld+json"
        // eslint-disable-next-line react/no-danger
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'WebPage',
            name: 'Service Guarantee · Brick Labor',
            url: 'https://bricklabor.com/guarantee',
            description:
              'Brick Labor service guarantee — 100% satisfaction or your money back. Every refund is reviewed against the booking, photos, and audit log, then returned to your original card via Square, with a personal decision within one business day.',
          }),
        }}
      />
    </main>
  );
}

function Step({ n, title, children }: { n: string; title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
      <p className="font-mono text-[10px] uppercase tracking-widest text-brand-accent">Step {n}</p>
      <h3 className="mt-1 text-lg font-bold text-brand-ink">{title}</h3>
      <p className="mt-2 text-sm text-brand-mute leading-relaxed">{children}</p>
    </div>
  );
}

function Bullet({ children, muted }: { children: React.ReactNode; muted?: boolean }) {
  return (
    <li className="flex items-start gap-2">
      <span
        aria-hidden
        className={`mt-1 inline-block h-1.5 w-1.5 shrink-0 rounded-full ${muted ? 'bg-brand-mute' : 'bg-brand-accent'}`}
      />
      <span>{children}</span>
    </li>
  );
}

function Faq({ q, children }: { q: string; children: React.ReactNode }) {
  return (
    <details className="mb-2 rounded-lg border border-brand-line bg-bg-elevated p-4">
      <summary className="cursor-pointer font-semibold text-brand-ink">{q}</summary>
      <p className="mt-2 text-sm text-brand-mute leading-relaxed">{children}</p>
    </details>
  );
}
export const THEME_TOOLS_POWER_WASH_PROTOCOLS_COUNT = Object.keys(POWER_WASH_PROTOCOLS).length;
