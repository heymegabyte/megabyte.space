import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { buildComprehensiveCategoryDiagnostic } from '@theme.tools/scheduling/field-service/theme-tools-field-service-bridge';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { servicesCopy } from '@theme.tools/i18n-a11y/field-service/services-copy';
import { CITIES } from '../data/cities.js';
import { DashboardCallout } from './DashboardCallout.js';

/**
 * Structural service data — locale-invariant. Icons, hub routes, images, and the
 * per-example hrefs live here; all visitor-facing text (title, description,
 * example labels, image alt, guide footer) comes from `services-copy` keyed by
 * `key`, so a Spanish/Portuguese visitor reads the section in-language after
 * hydration (per [[feedback_integrated_means_renders_not_just_prerendered]]).
 */
interface ServiceStruct {
  /** Stable slug — the key into `servicesCopy(locale).services`. */
  key: string;
  icon: string;
  hubHref?: string;
  image?: string; // slug under /services/<slug>.{jpg,webp}
  /** Hrefs positionally matched to the locale bundle's `examples` labels (undefined = plain pill). */
  exampleHrefs: (string | undefined)[];
}

const SERVICES: ServiceStruct[] = [
  {
    key: 'power-washing',
    icon: 'wash',
    hubHref: '/services/power-washing',
    image: 'power-washing',
    exampleHrefs: [
      '/blog/driveway-power-washing-equipment',
      undefined,
      undefined,
      undefined,
      undefined,
    ],
  },
  {
    key: 'lawn-care',
    icon: 'lawn',
    hubHref: '/services/lawn-care',
    image: 'lawn-care',
    exampleHrefs: [
      '/blog/lawn-mowing-pricing-newark',
      undefined,
      undefined,
      undefined,
      '/blog/pulling-weeds-from-the-roots',
    ],
  },
  {
    key: 'hauling',
    icon: 'haul',
    hubHref: '/services/hauling',
    image: 'hauling',
    exampleHrefs: [
      '/blog/sofa-haul-away-as-low-as-200',
      '/blog/appliance-haul-away-newark',
      undefined,
      undefined,
    ],
  },
  {
    key: 'light-repairs',
    icon: 'tool',
    hubHref: '/services/light-repairs',
    image: 'light-repairs',
    exampleHrefs: [
      '/blog/fence-repair-newark-light-carpentry',
      '/blog/gutter-cleaning-newark',
      undefined,
      undefined,
    ],
  },
  {
    key: 'cleanout',
    icon: 'box',
    hubHref: '/services/apartment-cleanout',
    image: 'cleanout',
    exampleHrefs: [undefined, undefined, undefined, undefined],
  },
  {
    key: 'seasonal',
    icon: 'leaf',
    image: 'seasonal',
    exampleHrefs: [
      '/blog/snow-shoveling-newark-on-call',
      undefined,
      '/blog/gutter-cleaning-newark',
      '/blog/spring-property-prep-newark',
    ],
  },
];

const ICONS: Record<string, JSX.Element> = {
  wash: <path pathLength={1} d="M12 2v6m0 0c-3 3-6 6-6 9a6 6 0 0 0 12 0c0-3-3-6-6-9zm-3 11h6" />,
  lawn: <path pathLength={1} d="M3 20h18M5 20V8m7 12V4m7 16v-9" />,
  haul: (
    <path
      pathLength={1}
      d="M3 17h13V6H3v11zm13-7h4l2 4v3h-6m-7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm10 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4z"
    />
  ),
  tool: (
    <path
      pathLength={1}
      d="M14 6l4 4M5 19l8-8m1-3a3 3 0 1 0 4 4l-1 1 3 3-3 3-3-3 1-1a3 3 0 0 0-4-4z"
    />
  ),
  box: <path pathLength={1} d="M3 7l9-4 9 4v10l-9 4-9-4V7zm9 4v10M3 7l9 4 9-4" />,
  leaf: <path pathLength={1} d="M5 19c10 0 14-4 14-14C9 5 5 9 5 19zm0 0L19 5" />,
};

export function Services() {
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  // Keep a mirror-locale visitor in /es · /pt: localize internal `/` hrefs;
  // leave mailto:/tel:/external + static-asset paths bare.
  const lp = (p: string) => (p.startsWith('/') ? localizedPath(locale, p) : p);
  const t = servicesCopy(locale);
  const surfaceProps = useThemeToolsSurface('services-section', [
    '@theme.tools/ui',
    '@theme.tools/scheduling',
    '@theme.tools/forms',
  ]);
  const primaryDiagnostic = buildComprehensiveCategoryDiagnostic('power-washing');

  return (
    <section
      id="services"
      className="section"
      data-animate="fade-right"
      data-theme-tools-surface={surfaceProps['data-theme-tools-surface']}
      data-theme-tools-pricing-model={surfaceProps['data-theme-tools-pricing-model']}
      data-hourly-rate-usd={primaryDiagnostic.hourlyRatePerPersonUsd}
    >
      <div className="container-pad">
        <div className="mb-14 max-w-3xl" data-animate="fade-up">
          <p className="eyebrow mb-3">{t.eyebrow}</p>
          <h2 className="text-4xl sm:text-5xl font-extrabold">
            {t.headlineMain} <span className="text-gradient">{t.headlineAccent}</span>
          </h2>
          <p className="mt-4 text-lg text-brand-mute">
            {t.leadPre}
            <a href="#contact" className="text-brand-accent underline-hover">
              {t.askAnyway}
            </a>
            .
          </p>
        </div>
        <div
          className="mb-8 flex flex-col gap-3 rounded-xl border border-brand-accent/40 bg-brand-accent/5 p-5 sm:flex-row sm:items-center sm:justify-between"
          data-animate="fade-up"
        >
          <div className="text-sm leading-relaxed text-brand-mute sm:max-w-2xl">
            <strong className="text-brand-ink">{t.twoWaysLead}</strong>
            {t.twoWaysBody1}
            <strong className="text-brand-ink">{t.twoWaysBodyBold}</strong>
            {t.twoWaysBody2}
          </div>
          <a href="#contact" className="btn-secondary shrink-0 self-start sm:self-auto">
            {t.customQuote}
          </a>
        </div>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3" data-stagger="80">
          {SERVICES.map((s, idx) => {
            const c = t.services[s.key] ?? servicesCopy('en').services[s.key];
            if (!c) return null;
            return (
              <article
                key={s.key}
                className="card-hover group overflow-hidden"
                data-animate="fade-up"
                data-card="service"
              >
                {s.image && (
                  <div className="relative -mx-6 -mt-6 mb-5 aspect-[3/2] overflow-hidden border-b border-brand-line">
                    <picture>
                      <source srcSet={`/services/${s.image}.webp`} type="image/webp" />
                      <img
                        src={`/services/${s.image}.jpg`}
                        alt={c.imageAlt}
                        loading="lazy"
                        decoding="async"
                        width={1536}
                        height={1024}
                        className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.04]"
                      />
                    </picture>
                    <div
                      aria-hidden
                      className="pointer-events-none absolute inset-0"
                      style={{
                        background:
                          'linear-gradient(180deg, rgba(6,6,16,0.0) 40%, rgba(6,6,16,0.55) 100%)',
                      }}
                    />
                    <img
                      src={`/brand/glyphs/0${idx + 1}-96.webp`}
                      alt=""
                      aria-hidden="true"
                      loading="lazy"
                      decoding="async"
                      width={96}
                      height={96}
                      className="pointer-events-none absolute right-3 top-3 h-14 w-14 drop-shadow-[0_4px_12px_rgba(0,0,0,0.55)] transition-transform duration-500 group-hover:rotate-[-4deg] group-hover:scale-105"
                    />
                  </div>
                )}
                <div className="flex items-start gap-4">
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-brand-accent/15 text-brand-accent">
                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth={1.8}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="bcl-svc-icon h-6 w-6"
                      aria-hidden
                    >
                      {ICONS[s.icon]}
                    </svg>
                  </div>
                  <div className="min-w-0">
                    <h3 className="font-display text-xl font-bold">
                      {s.hubHref ? (
                        <a href={lp(s.hubHref)} className="underline-hover hover:text-brand-accent">
                          {c.title}
                        </a>
                      ) : (
                        c.title
                      )}
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-brand-mute">{c.desc}</p>
                    <ul className="mt-4 flex flex-wrap gap-1.5">
                      {c.examples.map((label, i) => {
                        const href = s.exampleHrefs[i];
                        return (
                          <li key={label}>
                            {href ? (
                              <a
                                href={lp(href)}
                                className="inline-flex min-h-[24px] items-center rounded-md border border-brand-line bg-bg-primary px-2.5 py-1 font-mono text-[11px] text-brand-mute transition-colors hover:border-brand-accent hover:text-brand-accent"
                              >
                                {label}
                              </a>
                            ) : (
                              <span className="inline-flex min-h-[24px] items-center rounded-md border border-brand-line bg-bg-primary px-2.5 py-1 font-mono text-[11px] text-brand-mute">
                                {label}
                              </span>
                            )}
                          </li>
                        );
                      })}
                    </ul>
                    {s.hubHref && (
                      <p className="mt-4 font-mono text-[11px] uppercase tracking-widest">
                        <a
                          href={lp(s.hubHref)}
                          className="text-brand-accent underline-hover hover:text-brand-accent-bright"
                        >
                          {c.guide}
                        </a>
                      </p>
                    )}
                  </div>
                </div>
              </article>
            );
          })}
        </div>

        <div
          className="mt-10 flex flex-wrap items-baseline justify-between gap-4 rounded-xl border border-brand-line bg-bg-elevated/40 p-5"
          data-animate="fade-up"
        >
          <p className="text-sm text-brand-mute">
            <span className="text-brand-ink font-semibold">{t.cityBold}</span> {t.cityRest}
          </p>
          <div className="flex flex-wrap gap-2 font-mono text-[11px]">
            <a
              href={lp('/services/power-washing')}
              className="rounded-md border border-brand-line bg-bg-primary px-3 py-1.5 text-brand-mute underline-hover hover:text-brand-accent"
            >
              {t.linkPowerWashing}
            </a>
            <a
              href={lp('/services/lawn-care')}
              className="rounded-md border border-brand-line bg-bg-primary px-3 py-1.5 text-brand-mute underline-hover hover:text-brand-accent"
            >
              {t.linkLawnCare}
            </a>
            <a
              href={lp('/services/hauling')}
              className="rounded-md border border-brand-line bg-bg-primary px-3 py-1.5 text-brand-mute underline-hover hover:text-brand-accent"
            >
              {t.linkHauling}
            </a>
            <a
              href={lp('/services/light-repairs')}
              className="rounded-md border border-brand-line bg-bg-primary px-3 py-1.5 text-brand-mute underline-hover hover:text-brand-accent"
            >
              {t.linkLightRepairs}
            </a>
            <a
              href={lp('/services/moving-labor')}
              className="rounded-md border border-brand-line bg-bg-primary px-3 py-1.5 text-brand-mute underline-hover hover:text-brand-accent"
            >
              {t.linkMovingLabor}
            </a>
            <a
              href={lp('/services/furniture-removal')}
              className="rounded-md border border-brand-line bg-bg-primary px-3 py-1.5 text-brand-mute underline-hover hover:text-brand-accent"
            >
              {t.linkFurnitureRemoval}
            </a>
            <a
              href={lp('/services/apartment-cleanout')}
              className="rounded-md border border-brand-line bg-bg-primary px-3 py-1.5 text-brand-mute underline-hover hover:text-brand-accent"
            >
              {t.linkApartmentCleanout}
            </a>
            <a
              href={lp('/services/paint-scraping')}
              className="rounded-md border border-brand-line bg-bg-primary px-3 py-1.5 text-brand-mute underline-hover hover:text-brand-accent"
            >
              {t.linkPaintScraping}
            </a>
            <a
              href={lp('/services/loading-unloading')}
              className="rounded-md border border-brand-line bg-bg-primary px-3 py-1.5 text-brand-mute underline-hover hover:text-brand-accent"
            >
              {t.linkLoadingUnloading}
            </a>
          </div>
        </div>

        <div
          className="mt-6 rounded-xl border border-brand-line bg-bg-elevated/40 p-5"
          data-animate="fade-up"
        >
          <p className="text-sm text-brand-mute">
            <span className="text-brand-ink font-semibold">{t.jumpBold}</span>{' '}
            <a href={lp('/c/newark')} className="text-brand-accent underline-hover">
              Newark
            </a>{' '}
            ·{' '}
            <a href={lp('/c/jersey-city')} className="text-brand-accent underline-hover">
              Jersey City
            </a>{' '}
            ·{' '}
            <a href={lp('/c/paterson')} className="text-brand-accent underline-hover">
              Paterson
            </a>{' '}
            ·{' '}
            <a href={lp('/c/elizabeth')} className="text-brand-accent underline-hover">
              Elizabeth
            </a>{' '}
            ·{' '}
            <a href={lp('/c/east-orange')} className="text-brand-accent underline-hover">
              East Orange
            </a>{' '}
            ·{' '}
            <a href={lp('/c/irvington')} className="text-brand-accent underline-hover">
              Irvington
            </a>{' '}
            ·{' '}
            <a href={lp('/c/bloomfield')} className="text-brand-accent underline-hover">
              Bloomfield
            </a>{' '}
            ·{' '}
            <a href={lp('/c/hoboken')} className="text-brand-accent underline-hover">
              Hoboken
            </a>{' '}
            ·{' '}
            <a href={lp('/c/clifton')} className="text-brand-accent underline-hover">
              Clifton
            </a>{' '}
            ·{' '}
            <a href={lp('/#coverage')} className="text-brand-accent underline-hover">
              {t.allCities.replace('{n}', String(CITIES.length))}
            </a>
          </p>
          <p className="mt-3 text-xs text-brand-mute">
            {t.alreadyPre}
            <a href={lp('/book')} className="text-brand-accent underline-hover">
              {t.bookingWord}
            </a>
            {t.alreadyMid1}
            <a href="#pricing" className="text-brand-accent underline-hover">
              {t.pricingWord}
            </a>
            {t.alreadyMid2}
            <a href="#faq" className="text-brand-accent underline-hover">
              {t.faqWord}
            </a>
            {t.alreadyMid3}
            <a href={lp('/blog')} className="text-brand-accent underline-hover">
              {t.fieldNotesWord}
            </a>
            .
          </p>
        </div>
        <DashboardCallout source="services" context="a job" />
      </div>
    </section>
  );
}
