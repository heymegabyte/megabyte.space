import { useEffect, type JSX } from 'react';
import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { buildComprehensiveCategoryDiagnostic } from '@theme.tools/scheduling/field-service/theme-tools-field-service-bridge';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { servicesIndexCopy } from '@theme.tools/i18n-a11y/field-service/services-index-copy';
import { FAQ } from './FAQ.js';
import { PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';

/**
 * Service index page at /services — landing surface listing all service hubs.
 * Each card links to the canonical /services/<slug> hub. SEO meta + JSON-LD
 * ItemList for crawler discoverability. Keep the file small (declarative
 * cards); per-service depth lives on the hub pages themselves.
 *
 * Renders in-language on /es + /pt: the page chrome, the nine card labels, and
 * the per-route meta read from `services-index-copy`; nav hrefs carry the locale
 * prefix (`localizedPath`) so a /es visitor stays in /es after clicking through.
 * Service slugs, icon glyphs, the $50/hr rate, and the (855) 82LABOR phone stay
 * locale-invariant in this component.
 */

interface ServiceCard {
  readonly slug: string;
  readonly accent: string; // icon glyph
}

const SERVICES: ReadonlyArray<ServiceCard> = [
  { slug: 'moving-labor', accent: '📦' },
  { slug: 'furniture-removal', accent: '🛋️' },
  { slug: 'apartment-cleanout', accent: '🧹' },
  { slug: 'loading-unloading', accent: '🚚' },
  { slug: 'hauling', accent: '🗑️' },
  { slug: 'power-washing', accent: '💧' },
  { slug: 'lawn-care', accent: '🌿' },
  { slug: 'paint-scraping', accent: '🎨' },
  { slug: 'light-repairs', accent: '🔧' },
];

function setMeta(name: string, content: string, key: 'name' | 'property' = 'name'): void {
  let el = document.head.querySelector<HTMLMetaElement>(`meta[${key}="${name}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(key, name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function injectItemListJsonLd(localePrefix: (path: string) => string): void {
  const existing = document.getElementById('services-index-jsonld');
  if (existing) existing.remove();
  const copy = servicesIndexCopy(
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale,
  );
  const data = {
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    name: copy.ogTitle,
    itemListElement: SERVICES.map((s, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      url: `https://bricklabor.com${localePrefix(`/services/${s.slug}`)}`,
      name: copy.cards[s.slug]?.name ?? s.slug,
    })),
  };
  const script = document.createElement('script');
  script.type = 'application/ld+json';
  script.id = 'services-index-jsonld';
  script.textContent = JSON.stringify(data);
  document.head.appendChild(script);
}

export function ServicesIndex(): JSX.Element {
  // SSR/prerender is locale-stamped per route; on the client we read the URL so
  // hydration renders the right language even though every mirror prerenders the
  // same shell.
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const copy = servicesIndexCopy(locale);
  const lp = (path: string): string => localizedPath(locale, path);
  const surfaceProps = useThemeToolsSurface('services-index', [
    '@theme.tools/ui',
    '@theme.tools/scheduling',
    '@theme.tools/forms',
  ]);
  const leadDiagnostic = buildComprehensiveCategoryDiagnostic('moving-labor');

  useEffect(() => {
    document.title = copy.metaTitle;
    setMeta('description', copy.metaDescription);
    setMeta('og:title', copy.ogTitle, 'property');
    setMeta('og:description', copy.ogDescription, 'property');
    setMeta('og:url', `https://bricklabor.com${lp('/services')}`, 'property');
    let canonical = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.rel = 'canonical';
      document.head.appendChild(canonical);
    }
    canonical.href = `https://bricklabor.com${lp('/services')}`;
    injectItemListJsonLd(lp);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [locale]);

  return (
    <div
      data-theme-tools-surface={surfaceProps['data-theme-tools-surface']}
      data-theme-tools-pricing-model={surfaceProps['data-theme-tools-pricing-model']}
      data-theme-tools-packages={surfaceProps['data-theme-tools-packages']}
      data-hourly-rate-usd={leadDiagnostic.hourlyRatePerPersonUsd}
    >
      <section className="py-14 sm:py-20 border-b border-brand-line">
        <div className="container-pad max-w-4xl">
          <p className="font-mono text-[11px] uppercase tracking-wider text-brand-accent mb-3">
            {copy.eyebrow}
          </p>
          <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight mb-5">
            {copy.headline}
          </h1>
          <p className="text-lg sm:text-xl text-brand-mute mb-8 max-w-prose">{copy.lede}</p>
          <div className="flex flex-wrap items-center gap-3">
            <a href={lp('/schedule')} className="btn-primary px-6 py-3 text-base">
              {copy.scheduleCta}
            </a>
            <a href={lp('/quote')} className="btn-ghost px-5 py-3 text-base">
              {copy.quoteCta}
            </a>
          </div>
          <p className="mt-5 inline-flex items-center gap-2 rounded-full border border-brand-line bg-bg-primary/50 px-3.5 py-1.5 font-mono text-[11px] uppercase tracking-[0.16em] text-brand-mute">
            <span aria-hidden>◧</span>
            <a href={lp('/me?panel=calendar')} className="underline-hover text-brand-ink">
              {copy.calendarPill}
            </a>
          </p>
        </div>
      </section>

      <section className="py-12 sm:py-16">
        <div className="container-pad">
          <ul className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {SERVICES.map((svc) => {
              const card = copy.cards[svc.slug];
              return (
                <li key={svc.slug}>
                  <a
                    href={lp(`/services/${svc.slug}`)}
                    className="group block h-full rounded-lg border border-brand-line bg-bg-elevated/40 hover:border-brand-accent hover:bg-bg-elevated/80 transition-colors p-6"
                    data-bcl-service-card={svc.slug}
                  >
                    <div className="text-3xl mb-3" aria-hidden>
                      {svc.accent}
                    </div>
                    <h2 className="font-display text-xl font-semibold tracking-tight mb-1 group-hover:text-brand-accent transition-colors">
                      {card?.name ?? svc.slug}
                    </h2>
                    <p className="font-mono text-[11px] uppercase tracking-wider text-brand-accent mb-3">
                      {card?.headline ?? ''}
                    </p>
                    <p className="text-sm text-brand-mute leading-relaxed">{card?.summary ?? ''}</p>
                    <p className="mt-4 text-sm font-medium text-brand-ink group-hover:text-brand-accent">
                      {copy.readMore}
                    </p>
                  </a>
                </li>
              );
            })}
          </ul>
        </div>
      </section>

      {/* GEO/AI-search: the services hub is a top organic landing page, so it
          carries the same FAQPage answer block home + city pages do. <FAQ/>
          renders the real localized Q&A as visible text AND emits FAQPage
          JSON-LD (reuses the already-live `faq-copy` answers — no fabrication),
          and sits right before the final CTA where intent is highest. */}
      <FAQ />

      <section className="py-14 sm:py-20 bg-bg-elevated/40 border-y border-brand-line">
        <div className="container-pad text-center">
          <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight mb-4">
            {copy.outroHeadline}
          </h2>
          <p className="text-brand-mute mb-8 max-w-prose mx-auto">{copy.outroBody}</p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <a
              href={PHONE_TEL_HREF}
              className="btn-primary px-6 py-3 text-base"
              data-bcl-phone-cta="services-index"
              data-bcl-cta-location="services-index-cta-band"
            >
              📞 (855) 82LABOR
            </a>
            <a href={lp('/quote')} className="btn-ghost px-5 py-3 text-base">
              {copy.describeCta}
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
