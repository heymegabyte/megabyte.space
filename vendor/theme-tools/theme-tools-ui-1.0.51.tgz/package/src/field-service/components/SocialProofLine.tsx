import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect, useState } from 'react';
import { socialProofCount } from '@theme.tools/crm/field-service/social-proof';
import { htmlLangFor, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { trustBandCopy } from '@theme.tools/i18n-a11y/field-service/trust-band-copy';
import { RollingCounter } from './RollingCounter.js';

// Real social-proof at the point of conversion (P2-37). Surfaces the REAL
// booked-jobs count from /api/stats (`totalMoves`, D1-derived) right beneath the
// hero "Book crew" CTA — gated through `socialProofCount` so a thin/unconvincing
// figure never shows and a number is NEVER hardcoded at the CTA.
//
// Renders nothing until the live count clears the credibility floor: honest
// absence beats a weak claim, and there is zero fabrication risk. Localized
// (en/es/pt) via the same trust-band copy the rest of the homepage reads, so a
// Spanish/Portuguese visitor doesn't read the proof line in English.

interface StatsPayload {
  totalMoves: number;
  repeatPct: number;
  since: string;
  ownerReplyMedianHours: number | null;
}

interface Props {
  className?: string;
}

export function SocialProofLine({ className }: Props) {
  useThemeToolsSurface('social-proof-line');
  const [count, setCount] = useState<number | null>(null);

  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const t = trustBandCopy(locale);
  const numLocale = htmlLangFor(locale);

  useEffect(() => {
    let cancelled = false;
    fetch('/api/stats', { headers: { Accept: 'application/json' } })
      .then(async (res) => {
        if (cancelled || !res.ok) return;
        const json = (await res.json()) as { ok?: boolean; stats?: StatsPayload };
        if (json.ok && json.stats) setCount(socialProofCount(json.stats.totalMoves));
      })
      .catch(() => {
        /* offline / blocked / cold-start — leave null, render nothing */
      });
    return () => {
      cancelled = true;
    };
  }, []);

  // Below the credibility floor (or pre-fetch) → render nothing. No reserved
  // box, so there is no CLS when it does appear inline in the hero column.
  if (count === null) return null;

  return (
    <p
      data-testid="social-proof-line"
      data-animate="fade-up"
      data-delay="380"
      className={
        className ??
        'mt-4 inline-flex items-center gap-2 text-sm text-brand-mute'
      }
    >
      <span aria-hidden className="text-brand-accent">
        ★
      </span>
      <span>
        <strong className="text-brand-ink font-extrabold">
          <RollingCounter value={count} locale={numLocale} />
        </strong>{' '}
        {t.socialProofJobs}
      </span>
    </p>
  );
}
