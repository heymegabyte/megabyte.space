import { useThemeToolsSurface } from '../../field-service-primitives.js';
/**
 * SosButton.tsx — Wave 27 #43 — Floating SOS button.
 *
 * Two-tap confirmation: first tap reveals the three SOS-type options
 * (panic / medical / unsafe). Second tap on the chosen type fires
 * `POST /api/sos` with `navigator.geolocation` (best-effort).
 *
 * UI flag-gated via `useFeatureFlag('sos_button')`. When the flag is
 * off, the button does not render — BUT the server endpoint stays online
 * so the user can still call (855) 82LABOR or fire SOS from a Capacitor
 * app shell. Brian's directive: SOS server-side is the one flag exception.
 *
 * Render targets: /track/:id (customer view) + /work/dashboard (crew).
 * Bottom-right floating placement, never blocks the bottom nav.
 *
 * Reduced motion + WCAG 2.2 compliant focus ring, role="dialog" on the
 * expanded picker, Esc to close.
 *
 * SCAN-20 (2026-09-29) — SAFETY-CRITICAL focus containment: the picker is a
 * true modal dialog, so it reuses the canonical shared a11y kit
 * (`useFocusManagement` moves focus INTO the panel on open + restores it to the
 * trigger on close; `useTabTrap` keeps Tab/Shift+Tab cycling inside — a
 * `fixed`-position picker otherwise lets Tab escape to the page behind it, which
 * axe-core cannot detect). Labelled via `aria-labelledby` pointing at a visible
 * title. No duplicated primitive.
 */

import { useEffect, useRef, useState } from 'react';
import { useFeatureFlag } from '../use-feature-flag.js';
import { useFocusManagement, useTabTrap } from '../use-dialog-a11y.js';

type SosType = 'panic' | 'medical' | 'unsafe';

interface SosButtonProps {
  /** Optional gig/booking id — included in the SOS payload so operators can route. */
  gigId?: string;
  /** Who's firing. Defaults to 'anonymous' (customer track view). */
  userKind?: 'customer' | 'crew' | 'anonymous';
}

export function SosButton({ gigId, userKind = 'anonymous' }: SosButtonProps) {
  useThemeToolsSurface('sos-button');
  const enabled = useFeatureFlag('sos_button');
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState<SosType | null>(null);
  const [confirmedId, setConfirmedId] = useState<string | null>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const lastFocusRef = useRef<HTMLElement | null>(null);

  // SCAN-20 — shared dialog a11y kit moves focus INTO the picker on open and
  // traps Tab/Shift+Tab inside it (wrap first↔last, yank back any escapee).
  useFocusManagement(open, panelRef, lastFocusRef);
  const onDialogKeyDown = useTabTrap(panelRef);

  // Focus restore on close: the trigger lives in the `else` branch, so it
  // UNMOUNTS while the picker is open and REMOUNTS on close — the shared kit's
  // restore would target the stale (detached) node. Explicitly refocus the
  // freshly-mounted trigger when the picker closes (WCAG 2.4.3). Runs after the
  // shared effect (registered later), so it wins the focus.
  const wasOpenRef = useRef(false);
  useEffect(() => {
    if (wasOpenRef.current && !open) triggerRef.current?.focus();
    wasOpenRef.current = open;
  }, [open]);

  // Esc closes the picker (focus restore handled by the effect above).
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  if (!enabled) return null;

  async function fire(type: SosType) {
    if (busy) return;
    setBusy(type);
    let lat: number | undefined;
    let lng: number | undefined;
    try {
      const pos = await new Promise<GeolocationPosition>((resolve, reject) => {
        if (!('geolocation' in navigator)) {
          reject(new Error('no geolocation'));
          return;
        }
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 4000,
          maximumAge: 60_000,
        });
      });
      lat = pos.coords.latitude;
      lng = pos.coords.longitude;
    } catch {
      // Geolocation may be denied — still fire SOS without coords.
    }

    try {
      const r = await fetch('/api/sos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, gigId, userKind, lat, lng }),
      });
      const j = (await r.json()) as { ok?: boolean; sosId?: string };
      if (j.ok && j.sosId) {
        setConfirmedId(j.sosId);
      }
    } catch (err) {
      // Error tracked via Sentry
    } finally {
      setBusy(null);
      setOpen(false);
    }
  }

  const labels: Record<SosType, { icon: string; label: string; body: string }> = {
    panic: { icon: '🚨', label: 'Panic', body: 'I feel unsafe — call operator NOW' },
    medical: { icon: '⛑', label: 'Medical', body: 'Medical emergency — call for help' },
    unsafe: { icon: '⚠️', label: 'Unsafe', body: 'Situation feels off — log + alert' },
  };

  return (
    <div
      style={{
        position: 'fixed',
        bottom: 'max(24px, env(safe-area-inset-bottom, 24px))',
        right: '24px',
        zIndex: 90,
      }}
    >
      {confirmedId ? (
        <div
          role="status"
          aria-live="polite"
          style={{
            background: 'var(--color-success-solid)',
            color: 'var(--color-on-emphasis)',
            padding: '10px 14px',
            borderRadius: '12px',
            fontSize: '13px',
            maxWidth: '260px',
            boxShadow: '0 8px 24px rgba(0,0,0,0.25)',
          }}
        >
          SOS received ({confirmedId.slice(-6)}). Operator notified.
        </div>
      ) : open ? (
        <div
          ref={panelRef}
          role="dialog"
          aria-modal="true"
          aria-labelledby="sos-picker-title"
          onKeyDown={onDialogKeyDown}
          style={{
            background: 'var(--color-surface-sunken)',
            border: '2px solid var(--color-danger-solid)',
            borderRadius: '14px',
            padding: '12px',
            boxShadow: '0 12px 28px rgba(0,0,0,0.4)',
            display: 'flex',
            flexDirection: 'column',
            gap: '8px',
            minWidth: '220px',
          }}
        >
          <p
            id="sos-picker-title"
            style={{
              margin: '0 0 2px',
              fontSize: '13px',
              fontWeight: 700,
              color: 'var(--color-danger-solid)',
              textTransform: 'uppercase',
              letterSpacing: '0.06em',
            }}
          >
            Emergency SOS
          </p>
          {(Object.keys(labels) as SosType[]).map((k) => (
            <button
              key={k}
              type="button"
              onClick={() => fire(k)}
              disabled={busy !== null}
              aria-label={`Send ${labels[k].label} SOS`}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                background: 'var(--color-surface-raised)',
                color: 'var(--color-on-emphasis)',
                border: 'none',
                borderRadius: '10px',
                padding: '10px 12px',
                fontSize: '14px',
                cursor: busy ? 'wait' : 'pointer',
                textAlign: 'left',
                minHeight: '44px',
              }}
            >
              <span aria-hidden="true" style={{ fontSize: '20px' }}>
                {labels[k].icon}
              </span>
              <span>
                <strong style={{ display: 'block' }}>
                  {busy === k ? 'Sending…' : labels[k].label}
                </strong>
                <span style={{ fontSize: '11px', color: 'var(--color-text-dim-2)' }}>
                  {labels[k].body}
                </span>
              </span>
            </button>
          ))}
          <button
            type="button"
            onClick={() => setOpen(false)}
            style={{
              background: 'transparent',
              color: 'var(--color-text-dim)',
              border: 'none',
              fontSize: '12px',
              padding: '4px',
              minHeight: '32px',
              cursor: 'pointer',
            }}
          >
            Cancel · Esc
          </button>
        </div>
      ) : (
        <button
          ref={triggerRef}
          type="button"
          onClick={() => setOpen(true)}
          aria-label="Open SOS safety menu"
          aria-haspopup="dialog"
          style={{
            background: 'var(--color-danger-solid)',
            color: 'var(--color-on-emphasis)',
            border: '2px solid var(--color-on-emphasis)',
            borderRadius: '50%',
            width: '56px',
            height: '56px',
            fontSize: '24px',
            fontWeight: 'bold',
            cursor: 'pointer',
            boxShadow: '0 8px 24px rgba(185,28,28,0.4)',
            minHeight: '44px',
            minWidth: '44px',
          }}
        >
          SOS
        </button>
      )}
    </div>
  );
}
