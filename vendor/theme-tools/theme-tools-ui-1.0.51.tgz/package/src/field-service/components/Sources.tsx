import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect } from 'react';
import { REFERENCES } from '@theme.tools/seo-geo/field-service/citations';
import { JsonLd, personBrian } from './seo/index.js';

const TITLE = 'Sources & Citations · Brick Labor — APA References';
const DESC =
  'Every wage, price, and licensing claim on bricklabor.com cited APA 7th-ed. BLS, U.S. Census, NJ Consumer Affairs, U-Haul, HomeAdvisor — full receipts.';

const TYPE_LABEL: Record<string, string> = {
  gov: 'Government / Regulator',
  industry: 'Industry pricing data',
  article: 'Article / Press',
  archive: 'Archive',
  data: 'Primary data',
};

function groupedRefs() {
  const groups: Record<string, typeof REFERENCES> = {};
  for (const r of REFERENCES) {
    (groups[r.type] ||= []).push(r);
  }
  return Object.entries(groups).sort(([a], [b]) => a.localeCompare(b));
}

export function Sources() {
  useThemeToolsSurface('sources');
  useEffect(() => {
    document.title = TITLE;
    setMeta('description', DESC);
    setLink('canonical', 'https://bricklabor.com/sources');
    setMeta('robots', 'index,follow', 'name');
  }, []);

  return (
    <article className="section">
      <div className="container-pad max-w-4xl">
        <p className="eyebrow mb-3">Receipts</p>
        <h1 className="text-4xl sm:text-5xl font-extrabold mb-3">Sources & Citations</h1>
        <p className="text-brand-mute mb-2 max-w-2xl leading-relaxed">
          Every quantitative claim on this site cites its source inline as{' '}
          <code className="font-mono text-brand-accent">(Author, Year)</code>. Full APA 7th-edition
          bibliography below, sorted by source type. Hyperlinks open the primary source in a new
          tab.
        </p>
        <p className="text-sm text-brand-mute mb-10">
          Last updated: 2026-05-11 · {REFERENCES.length} references
        </p>

        <div className="space-y-10">
          {groupedRefs().map(([type, refs]) => (
            <section key={type}>
              <h2 className="font-display text-xl font-bold text-brand-ink mb-4">
                <span className="text-brand-accent">{TYPE_LABEL[type] || type}</span>
                <span className="ml-3 font-mono text-xs text-brand-mute">({refs.length})</span>
              </h2>
              <ol className="space-y-4">
                {refs.map((r) => (
                  <li
                    key={r.id}
                    id={r.id}
                    className="rounded-lg border border-brand-line bg-bg-elevated/40 px-5 py-4 text-sm leading-relaxed text-brand-mute scroll-mt-24"
                    style={{ textIndent: '-1.5rem', paddingLeft: 'calc(1.25rem + 1.5rem)' }}
                  >
                    {r.apa.replace(/https?:\/\/\S+$/, '').trim()}{' '}
                    <a
                      href={r.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-brand-accent underline-hover break-all"
                    >
                      {r.url}
                    </a>
                  </li>
                ))}
              </ol>
            </section>
          ))}
        </div>

        <div className="mt-12 rounded-xl border border-brand-line bg-bg-elevated/40 px-6 py-5">
          <p className="font-display text-sm font-bold uppercase tracking-wider text-brand-ink">
            Where these cites appear
          </p>
          <ul className="mt-3 grid gap-2 text-sm sm:grid-cols-2">
            <li>
              <a
                href="/#pricing"
                className="text-brand-mute underline-hover hover:text-brand-accent"
              >
                → Pricing — BLS NJ wage benchmarks
              </a>
            </li>
            <li>
              <a href="/#faq" className="text-brand-mute underline-hover hover:text-brand-accent">
                → FAQ — NJ contractor licensing
              </a>
            </li>
            <li>
              <a href="/#faq" className="text-brand-mute underline-hover hover:text-brand-accent">
                → FAQ — U-Haul published rates
              </a>
            </li>
            <li>
              <a
                href="/blog/fifty-dollar-hour-per-person-philosophy"
                className="text-brand-mute underline-hover hover:text-brand-accent"
              >
                → Blog — Why $50/hr, per person
              </a>
            </li>
            <li>
              <a
                href="/blog/casual-labor-vs-licensed-contractor"
                className="text-brand-mute underline-hover hover:text-brand-accent"
              >
                → Blog — Casual labor vs licensed contractor
              </a>
            </li>
            <li>
              <a
                href="/blog/driveway-power-washing-equipment"
                className="text-brand-mute underline-hover hover:text-brand-accent"
              >
                → Blog — Pressure-washer PSI specs
              </a>
            </li>
            <li>
              <a
                href="/services/power-washing"
                className="text-brand-mute underline-hover hover:text-brand-accent"
              >
                → Services — Power washing rate context
              </a>
            </li>
            <li>
              <a
                href="/c/newark"
                className="text-brand-mute underline-hover hover:text-brand-accent"
              >
                → Newark — Local market wage data
              </a>
            </li>
          </ul>
        </div>

        <p className="mt-10 text-xs text-brand-mute">
          Spotted an out-of-date number?{' '}
          <a
            href="mailto:hey@bricklabor.com?subject=Citation%20update"
            className="text-brand-accent underline-hover"
          >
            hey@bricklabor.com
          </a>
          . Replacement source must be peer-reviewed, .gov/.edu, primary data, or established
          industry research — no AI-summary articles. Read the{' '}
          <a href="/privacy" className="text-brand-accent underline-hover">
            privacy policy
          </a>{' '}
          and{' '}
          <a href="/terms" className="text-brand-accent underline-hover">
            terms
          </a>
          , or head back to the{' '}
          <a href="/" className="text-brand-accent underline-hover">
            homepage
          </a>{' '}
          and{' '}
          <a href="/book" className="text-brand-accent underline-hover">
            book the crew
          </a>
          .
        </p>
      </div>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'WebPage',
            '@id': 'https://bricklabor.com/sources',
            url: 'https://bricklabor.com/sources',
            name: TITLE,
            description: DESC,
            isPartOf: { '@id': 'https://bricklabor.com/#website' },
            citation: REFERENCES.map((r) => ({
              '@type': 'CreativeWork',
              '@id': `https://bricklabor.com/sources#${r.id}`,
              name: r.apa,
              url: r.url,
            })),
          }),
        }}
      />
      <JsonLd data={personBrian()} />
    </article>
  );
}

function setMeta(name: string, content: string, attr: 'name' | 'property' = 'name') {
  let el = document.querySelector<HTMLMetaElement>(`meta[${attr}="${name}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function setLink(rel: string, href: string) {
  let el = document.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', rel);
    document.head.appendChild(el);
  }
  el.setAttribute('href', href);
}
