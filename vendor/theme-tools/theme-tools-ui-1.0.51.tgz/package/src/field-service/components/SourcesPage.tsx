import { useThemeToolsSurface } from '../../field-service-primitives.js';
/**
 * /sources — Trust page (idea #15).
 *
 * Public reference page that backs every quantitative claim AI fair-market,
 * city pricing, and seasonal-demand surfaces make. Builds the credibility
 * skeptics need before they trust the AI estimator.
 */
import { useEffect } from 'react';

export function SourcesPage() {
  useThemeToolsSurface('sources-page');
  useEffect(() => {
    const prev = document.title;
    document.title = 'Our Sources — Brick Labor Newark NJ';
    return () => {
      document.title = prev;
    };
  }, []);

  return (
    <main className="bg-bg-primary min-h-screen pb-24">
      <section className="mx-auto max-w-3xl px-4 pt-12">
        <p className="mb-3 font-mono text-[11px] uppercase tracking-[0.18em] text-brand-accent">
          Sources
        </p>
        <h1 className="mb-3 text-3xl font-bold leading-tight text-brand-ink sm:text-4xl">
          Where our numbers come from.
        </h1>
        <p className="mb-8 text-brand-mute">
          Every market range, ZIP-level pricing, and "the typical Newark job costs $X" you see on
          this site is backed by a real source. Here they are.
        </p>

        <Section title="Wage + labor data">
          <Ref
            label="BLS Occupational Employment Statistics (May 2024)"
            href="https://www.bls.gov/oes/current/oes372011.htm"
          >
            New Jersey median wage for "Laborers + Freight, Stock + Material Movers" anchors our
            $50/hr flat-rate. Updated annually.
          </Ref>
          <Ref
            label="NJ Department of Labor Wage Reports"
            href="https://www.nj.gov/labor/lwdhome/wageandhour/wagereports.shtml"
          >
            Cross-checks BLS for North Jersey metro premium.
          </Ref>
        </Section>

        <Section title="Pricing + market comparison">
          <Ref label="HomeAdvisor State of Home Spending" href="https://www.homeadvisor.com">
            Source of competitor median project prices for the AI fair-market estimator.
          </Ref>
          <Ref label="Angi True Cost Report" href="https://www.angi.com/research/">
            Cross-reference for cleanout, moving, and power-wash bands per region.
          </Ref>
        </Section>

        <Section title="Demographics + service area">
          <Ref
            label="U.S. Census ACS B16001 Language Spoken at Home"
            href="https://data.census.gov"
          >
            Drives the upcoming Spanish + Portuguese site mirrors for Newark's Hispanic +
            Brazilian-American population.
          </Ref>
          <Ref label="NJ Open Data Portal" href="https://data.nj.gov">
            Building permits, zoning, school districts — feeds neighborhood pages with real local
            context, not generic templates.
          </Ref>
        </Section>

        <Section title="Weather + seasonal demand">
          <Ref label="Open-Meteo (free, no key)" href="https://open-meteo.com">
            Per-ZIP hourly forecasts power the AI weather-reschedule advisor so outdoor gigs don't
            get rained out without a heads-up.
          </Ref>
          <Ref label="NOAA Climate Data Online" href="https://www.ncdc.noaa.gov/cdo-web/">
            Historical baselines for surge-pricing seasonal multipliers.
          </Ref>
        </Section>

        <Section title="Compliance + licensing">
          <Ref label="NJ Division of Consumer Affairs" href="https://www.njconsumeraffairs.gov">
            All crew licensing verified here. License numbers shown on each crew profile.
          </Ref>
          <Ref
            label="Square Web Payments SDK"
            href="https://developer.squareup.com/docs/web-payments/overview"
          >
            Every accepted payment is PCI-compliant via Square's hosted checkout — we never see card
            numbers.
          </Ref>
          <Ref
            label="TCPA (47 U.S.C. § 227)"
            href="https://www.fcc.gov/general/telemarketing-and-robocall-rules"
          >
            All SMS includes "Reply STOP to opt out" per federal rule. Every opt-out is honored
            within minutes.
          </Ref>
        </Section>

        <Section title="AI + model details">
          <Ref
            label="Cloudflare Workers AI — Llama 3.3 70B (FP8)"
            href="https://developers.cloudflare.com/workers-ai/models/"
          >
            Powers the AI dispatcher, exit-rescue, weekly digest, and fair-market estimator. Outputs
            are post-validated server-side; we never trust raw LLM totals or links.
          </Ref>
          <Ref
            label="OpenAI Whisper Large v3 Turbo (via Workers AI)"
            href="https://developers.cloudflare.com/workers-ai/models/whisper-large-v3-turbo/"
          >
            Transcribes inbound call recordings for the call-summarizer.
          </Ref>
          <Ref label="Cloudflare Vectorize" href="https://developers.cloudflare.com/vectorize/">
            Crew skill embeddings (1024-dim cosine, bge-m3) for AI dispatcher crew matching.
          </Ref>
        </Section>

        <p className="mt-12 rounded-2xl border border-brand-line bg-bg-elevated p-5 text-sm text-brand-mute">
          Found a number on this site you'd like a citation for?{' '}
          <a href="mailto:hey@bricklabor.com" className="text-brand-accent underline">
            Email us
          </a>{' '}
          and we'll add the source here.
        </p>
      </section>
    </main>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-8">
      <h2 className="mb-3 text-xl font-bold text-brand-ink">{title}</h2>
      <ul className="space-y-3">{children}</ul>
    </section>
  );
}

function Ref({
  label,
  href,
  children,
}: {
  label: string;
  href: string;
  children: React.ReactNode;
}) {
  return (
    <li className="rounded-lg border border-brand-line bg-bg-elevated p-4">
      <a
        href={href}
        target="_blank"
        rel="noopener noreferrer"
        className="text-brand-accent underline decoration-dotted underline-offset-4 hover:no-underline"
      >
        {label}
      </a>
      <p className="mt-1 text-sm text-brand-mute">{children}</p>
    </li>
  );
}
