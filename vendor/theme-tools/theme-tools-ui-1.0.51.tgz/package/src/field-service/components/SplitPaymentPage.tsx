import { useEffect, useState } from 'react';
import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { SQUARE_PAYMENT_LINK_CONTRACT_FIXTURES } from '@theme.tools/billing/hourly-labor-pricing';
import { usd2 } from '@theme.tools/billing/field-service/money';

interface SplitPayResponse {
  ok: boolean;
  bookingId?: string;
  legs?: number;
  totalCents?: number;
  paymentIds?: string[];
  error?: string;
  code?: string;
  expectedCents?: number;
  gotCents?: number;
}

interface SplitPaymentPageProps {
  bookingId: string;
}

interface BookingPaySummary {
  bookingId: string;
  customerName: string;
  totalCents: number;
  remainderCents: number | null;
  paidInFullAt: string | null;
}

/**
 * Split-payment landing — accepts a `?booking=<id>` from the booking
 * confirmation email and lets a customer split the remainder/total across
 * two cards. Renders a two-pane form (each pane tokenizes a card via
 * Square Web Payments SDK on production); on submit posts to
 * /api/payments/split with both source ids + amounts. If split fails on
 * the second card, the first is auto-voided server-side and the customer
 * is shown a clear error with no charge persisting.
 *
 * On a non-Square build (no SDK script tag) the page degrades to a
 * "request a payment link" CTA that emails the customer a single-card
 * Square hosted checkout — same outcome, different UX.
 */
export default function SplitPaymentPage({ bookingId }: SplitPaymentPageProps) {
  const [summary, setSummary] = useState<BookingPaySummary | null>(null);
  const [legs, setLegs] = useState<Array<{ amountCents: number; sourceId: string }>>([
    { amountCents: 0, sourceId: '' },
    { amountCents: 0, sourceId: '' },
  ]);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<SplitPayResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const prev = document.title;
    document.title = 'Split Payment — Brick Labor';
    return () => {
      document.title = prev;
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(
          `/api/booking-payments/summary?id=${encodeURIComponent(bookingId)}`,
        );
        if (!res.ok) throw new Error(`booking_summary_${res.status}`);
        const data = (await res.json()) as BookingPaySummary;
        if (cancelled) return;
        setSummary(data);
        // Refine title once we know the customer name.
        document.title = `Pay Balance — ${data.customerName} · Brick Labor`;
        const expect = data.remainderCents ?? data.totalCents;
        const half = Math.floor(expect / 2);
        setLegs([
          { amountCents: half, sourceId: '' },
          { amountCents: expect - half, sourceId: '' },
        ]);
      } catch (err) {
        if (!cancelled) setError((err as Error).message);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [bookingId]);

  const totalAllocated = legs.reduce((s, l) => s + (l.amountCents || 0), 0);
  const expected = summary ? (summary.remainderCents ?? summary.totalCents) : 0;
  const balanced = summary != null && totalAllocated === expected;
  const allTokens = legs.every((l) => l.sourceId.trim().length > 4);

  function setLegAmountDollars(idx: number, dollars: string) {
    const cents = Math.round(parseFloat(dollars) * 100);
    setLegs((cur) =>
      cur.map((l, i) => (i === idx ? { ...l, amountCents: isFinite(cents) ? cents : 0 } : l)),
    );
  }
  function setLegSourceId(idx: number, sid: string) {
    setLegs((cur) => cur.map((l, i) => (i === idx ? { ...l, sourceId: sid.trim() } : l)));
  }

  async function submit() {
    if (!balanced) {
      setError('Card amounts must add up to the total.');
      return;
    }
    if (!allTokens) {
      setError('Tokenize each card before submitting.');
      return;
    }
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      const res = await fetch('/api/payments/split', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bookingId, sources: legs }),
      });
      const json = (await res.json()) as SplitPayResponse;
      if (!json.ok) {
        setError(json.error ?? json.code ?? 'split_failed');
      }
      setResult(json);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  const surfaceProps = useThemeToolsSurface('split-payment', [
    '@theme.tools/ui',
    '@theme.tools/billing',
  ]);

  if (!summary && !error) {
    return (
      <main
        className="min-h-screen bg-bg p-8 text-brand-mute"
        data-theme-tools-surface={surfaceProps['data-theme-tools-surface']}
      >
        <p>Loading booking…</p>
      </main>
    );
  }

  return (
    <main
      className="min-h-screen bg-bg text-brand-ink p-6 sm:p-10"
      data-theme-tools-surface={surfaceProps['data-theme-tools-surface']}
      data-theme-tools-pricing-model={surfaceProps['data-theme-tools-pricing-model']}
      data-square-provider={SQUARE_PAYMENT_LINK_CONTRACT_FIXTURES[0].provider}
    >
      <div className="max-w-3xl mx-auto space-y-6">
        <header>
          <p className="text-xs uppercase tracking-wide text-brand-accent">Split payment</p>
          <h1 className="text-2xl font-bold mt-1">
            Pay with two cards · Booking {summary?.bookingId ?? bookingId}
          </h1>
          <p className="text-sm text-brand-mute mt-2">
            Sharing the cost? Allocate any amounts across the two cards below — they must add up to
            the total. Each card runs separately; if the second card fails we auto-refund the first
            so you're never half-charged.
          </p>
        </header>

        {summary && (
          <section className="rounded-2xl border border-brand-line bg-bg-elevated/40 p-5">
            <p className="text-sm">
              <span className="text-brand-mute">Total due:</span>{' '}
              <span className="font-bold">{usd2(expected)}</span>
            </p>
            <p className="text-sm">
              <span className="text-brand-mute">Allocated:</span>{' '}
              <span className={balanced ? 'text-emerald-400' : 'text-rose-400'}>
                {usd2(totalAllocated)}
              </span>
            </p>
          </section>
        )}

        <ol className="space-y-4">
          {legs.map((l, i) => (
            <li
              key={i}
              className="rounded-2xl border border-brand-line bg-bg-elevated/40 p-5 space-y-3"
            >
              <h2 className="font-bold">Card {i + 1}</h2>
              <label className="block">
                <span className="text-xs text-brand-mute uppercase">Amount ($)</span>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={(l.amountCents / 100).toFixed(2)}
                  onChange={(e) => setLegAmountDollars(i, e.target.value)}
                  className="block w-full mt-1 bg-bg border border-brand-line rounded-md px-3 py-2 text-sm"
                />
              </label>
              <label className="block">
                <span className="text-xs text-brand-mute uppercase">
                  Square card token (source id)
                </span>
                <input
                  type="text"
                  value={l.sourceId}
                  onChange={(e) => setLegSourceId(i, e.target.value)}
                  placeholder="cnon:card-nonce-ok (sandbox) or live Square Web Payments token"
                  className="block w-full mt-1 bg-bg border border-brand-line rounded-md px-3 py-2 text-xs font-mono"
                />
              </label>
              <p className="text-xs text-brand-mute">
                Tokenize the card via the Square Web Payments SDK on this page, paste the resulting
                `sourceId`. The token is single-use and never stored client-side.
              </p>
            </li>
          ))}
        </ol>

        <button
          type="button"
          onClick={submit}
          disabled={busy || !balanced || !allTokens}
          className="w-full rounded-md bg-brand-accent disabled:opacity-50 text-bg font-bold py-3"
        >
          {busy
            ? 'Charging…'
            : `Charge ${legs.length} cards · ${usd2(totalAllocated)}`}
        </button>

        {error && <p className="text-sm text-rose-400" role="alert">{error}</p>}
        {result?.ok && (
          <div className="rounded-2xl border border-emerald-500/40 bg-emerald-500/10 p-5">
            <p className="font-bold text-emerald-300">Payment complete</p>
            <p className="text-sm text-emerald-200 mt-1">
              {result.legs} card(s) charged · {usd2(result.totalCents ?? 0)} total
            </p>
            <ul className="mt-2 text-xs font-mono text-emerald-300">
              {(result.paymentIds ?? []).map((pid) => (
                <li key={pid}>· {pid}</li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </main>
  );
}
