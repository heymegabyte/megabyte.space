import { useEffect, useState } from 'react';
import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { htmlLangFor, localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { trustBandCopy } from '@theme.tools/i18n-a11y/field-service/trust-band-copy';
import { RollingCounter } from './RollingCounter.js';

// Wave 2B — small horizontal strip rendered on the homepage (wired into
// App.tsx by the integrator). "Since 2024 · N moves · X% repeat customers".
// Pulls from /api/stats (KV-cached 1h) and degrades gracefully to copy-only
// when the network request fails or returns zeros (cold-start, no bookings).
//
// Localized for the /es + /pt mirrors via trust-band-copy (the numbers stay
// numeric; only the surrounding labels translate) — same URL-locale read as
// Hero.tsx / TrustBadges.tsx so a Spanish/Portuguese visitor doesn't read the
// track-record strip in English.

interface StatsPayload {
  totalMoves: number;
  repeatPct: number;
  since: string;
  ownerReplyMedianHours: number | null;
}

interface Props {
  className?: string;
}

export function StatStrip({ className }: Props) {
  const [stats, setStats] = useState<StatsPayload | null>(null);

  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const t = trustBandCopy(locale);
  // BCP-47 tag so the count-up groups thousands per the visitor's locale
  // (en `1,200` · es-US `1,200` · pt-BR `1.200`) instead of always en-US.
  const numLocale = htmlLangFor(locale);

  useEffect(() => {
    let cancelled = false;
    fetch('/api/stats', { headers: { Accept: 'application/json' } })
      .then(async (res) => {
        if (cancelled || !res.ok) return;
        const json = (await res.json()) as { ok?: boolean; stats?: StatsPayload };
        if (json.ok && json.stats) setStats(json.stats);
      })
      .catch(() => {
        /* offline / blocked — leave as null, render fallback */
      });
    return () => {
      cancelled = true;
    };
  }, []);

  // Gate each stat on a real value — never render "0 moves booked" / "0% repeat"
  // before the first completed move (live `/api/stats` is all-zero until then).
  const moves = stats && stats.totalMoves > 0 ? stats.totalMoves : null;
  const since = stats?.since ?? '2024';
  const repeat = stats && stats.repeatPct > 0 ? stats.repeatPct : null;
  const reply =
    stats && stats.ownerReplyMedianHours !== null && stats.ownerReplyMedianHours > 0
      ? stats.ownerReplyMedianHours
      : null;

  const surfaceProps = useThemeToolsSurface('stat-strip', [
    '@theme.tools/ui',
    '@theme.tools/telemetry',
  ]);

  return (
    <section
      aria-label={t.trackRecord}
      data-testid="stat-strip"
      data-animate="fade-in"
      data-theme-tools-surface={surfaceProps['data-theme-tools-surface']}
      data-theme-tools-pricing-model={surfaceProps['data-theme-tools-pricing-model']}
      className={
        className ?? 'border-y border-brand-line bg-bg-elevated/30 py-4 text-sm text-brand-mute'
      }
    >
      <div
        className="container-pad flex flex-wrap items-center gap-x-6 gap-y-2 justify-center text-center"
        data-stagger="70"
      >
        <span
          className="font-mono text-xs uppercase tracking-wider text-brand-accent"
          data-animate="fade-up"
        >
          {t.sincePrefix} {since}
        </span>
        {moves !== null && (
          <span data-animate="fade-up">
            <strong className="text-brand-ink font-extrabold">
              <RollingCounter value={moves} locale={numLocale} />
            </strong>{' '}
            {t.movesBooked}
          </span>
        )}
        {repeat !== null && (
          <span data-animate="fade-up">
            <strong className="text-brand-ink font-extrabold">
              <RollingCounter value={repeat} suffix="%" locale={numLocale} />
            </strong>{' '}
            {t.repeatCustomers}
          </span>
        )}
        {reply !== null && (
          <span data-animate="fade-up">
            {t.ownerRepliesMedian}{' '}
            <strong className="text-brand-ink font-extrabold">
              <RollingCounter value={reply} decimals={1} suffix="h" locale={numLocale} />
            </strong>
          </span>
        )}
        <a
          href={localizedPath(locale, '/claims')}
          className="text-brand-accent underline-hover hidden sm:inline"
          data-animate="fade-up"
        >
          {t.seeClaims}
        </a>
      </div>
    </section>
  );
}
