import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect, useState } from 'react';
import {
  componentLabel,
  componentStyle,
  componentsSummary,
  overallBanner,
  timeAgo,
  type StatusSnapshot,
} from '@theme.tools/crm/field-service/status-display';

/**
 * /status — Public status page. Renders the REAL `/api/status` backend:
 * per-component probes (D1 / KV / R2 / payments / SMS / push / maps) + active
 * and recently-resolved incidents from `status_incidents`. Also probes
 * `/api/health` every 60s for a live API-latency read. No placeholders — every
 * tile and incident reflects what the worker actually reports.
 */

type Overall = 'ok' | 'degraded' | 'outage';

interface HealthSnapshot {
  status: Overall;
  apiLatencyMs: number;
  checkedAt: string;
}

const POLL_MS = 60_000;

export function StatusPage() {
  useThemeToolsSurface('status-page');
  const [snap, setSnap] = useState<HealthSnapshot | null>(null);
  const [status, setStatus] = useState<StatusSnapshot | null>(null);

  useEffect(() => {
    document.title = 'System Status · Brick Labor';
    return () => {
      document.title = 'Brick Labor · $50/hr Property Crew Newark NJ';
    };
  }, []);

  useEffect(() => {
    let cancelled = false;

    const probe = async () => {
      // Latency read from the lightweight health endpoint.
      const t0 = Date.now();
      try {
        const res = await fetch('/api/health');
        const ms = Date.now() - t0;
        if (!cancelled) {
          setSnap({
            status: res.ok ? (ms < 800 ? 'ok' : 'degraded') : 'outage',
            apiLatencyMs: ms,
            checkedAt: new Date().toISOString(),
          });
        }
      } catch {
        if (!cancelled) {
          setSnap({ status: 'outage', apiLatencyMs: -1, checkedAt: new Date().toISOString() });
        }
      }

      // Real per-component + incident snapshot.
      try {
        const res = await fetch('/api/status');
        if (res.ok) {
          const data = (await res.json()) as StatusSnapshot;
          if (!cancelled) setStatus(data);
        }
      } catch {
        /* keep the last good snapshot; the banner falls back to /api/health */
      }
    };

    void probe();
    const t = window.setInterval(() => void probe(), POLL_MS);
    return () => {
      cancelled = true;
      window.clearInterval(t);
    };
  }, []);

  // Prefer the real aggregate; fall back to the latency probe before /api/status lands.
  const healthFallback =
    snap?.status === 'outage' ? 'down' : snap?.status === 'degraded' ? 'degraded' : 'operational';
  const overall = status?.status ?? healthFallback;
  const banner = overallBanner(overall);

  const components = status?.components ?? [];
  const active = status?.incidents_active ?? [];
  const recent = status?.incidents_recent ?? [];
  const now = status?.generated_at ?? Math.floor(Date.now() / 1000);

  // Mount a <link rel="alternate" type="application/atom+xml"> so the page is
  // discoverable as a feed by RSS readers (Feedly, Newsblur, NetNewsWire).
  useEffect(() => {
    const existing = document.querySelector('link[rel="alternate"][type="application/atom+xml"]');
    if (existing) return;
    const link = document.createElement('link');
    link.rel = 'alternate';
    link.type = 'application/atom+xml';
    link.href = '/api/status/rss';
    link.setAttribute('data-status-feed', '');
    document.head.appendChild(link);
    return () => {
      const el = document.querySelector('link[data-status-feed]');
      if (el && el.parentNode) el.parentNode.removeChild(el);
    };
  }, []);

  return (
    <main className="bg-bg-primary min-h-screen pb-24">
      <section className="mx-auto max-w-3xl px-4 pt-12">
        <p className="mb-3 font-mono text-[11px] uppercase tracking-[0.18em] text-brand-accent">
          Status
        </p>
        <h1 className="mb-3 text-3xl font-bold leading-tight text-brand-ink sm:text-4xl">
          System status
        </h1>
        <p className="mb-6 text-brand-mute">
          Live component health + incidents, refreshed every 60 seconds straight from the worker.
        </p>

        <div
          className={`rounded-2xl border p-5 transition-colors duration-300 ${banner.color}`}
          data-enter
          role="status"
          aria-live="polite"
        >
          <p className="text-xl font-bold">{banner.text}</p>
          {snap && (
            <p className="mt-1 text-xs">
              API: {snap.apiLatencyMs < 0 ? 'unreachable' : `${snap.apiLatencyMs}ms`} · last checked{' '}
              {new Date(snap.checkedAt).toLocaleTimeString()}
            </p>
          )}
        </div>

        <section className="mt-8">
          <div className="mb-3 flex items-baseline justify-between gap-3">
            <h2 className="text-xl font-bold text-brand-ink">Components</h2>
            {components.length > 0 && (
              <span className="text-xs text-brand-mute">{componentsSummary(components)}</span>
            )}
          </div>
          {components.length === 0 ? (
            <p className="text-sm text-brand-mute">Fetching live component health…</p>
          ) : (
            <ul className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {components.map((comp) => {
                const style = componentStyle(comp.status);
                return (
                  <li
                    key={comp.name}
                    className={`flex items-center gap-2 rounded-lg border px-3 py-2 transition-colors duration-300 ${style.tile}`}
                  >
                    <span aria-hidden className={`h-2 w-2 shrink-0 rounded-full ${style.dot}`} />
                    <span className="min-w-0 flex-1 truncate text-sm text-brand-ink">
                      {componentLabel(comp.name)}
                    </span>
                    <span className="sr-only">{style.label}</span>
                  </li>
                );
              })}
            </ul>
          )}
        </section>

        <section className="mt-8">
          <h2 className="mb-3 text-xl font-bold text-brand-ink">Incidents</h2>
          {active.length === 0 && recent.length === 0 ? (
            <div className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
              <p className="text-sm text-brand-mute">
                No incidents reported. We post here the moment anything affects bookings, payments,
                or dispatch.
              </p>
            </div>
          ) : (
            <ul className="space-y-3">
              {active.map((i) => (
                <li
                  key={`active-${i.id}`}
                  className="rounded-2xl border border-amber-500/40 bg-amber-500/5 p-4"
                >
                  <div className="flex items-center gap-2">
                    <span className="rounded-full bg-amber-500/20 px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-amber-300">
                      {i.status}
                    </span>
                    <span className="text-xs text-brand-mute">{timeAgo(i.started_at, now)}</span>
                  </div>
                  <p className="mt-2 font-semibold text-brand-ink">{i.title}</p>
                  {i.body && <p className="mt-1 text-sm text-brand-mute">{i.body}</p>}
                </li>
              ))}
              {recent.map((i) => (
                <li
                  key={`recent-${i.id}`}
                  className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
                >
                  <div className="flex items-center gap-2">
                    <span className="rounded-full bg-emerald-500/15 px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-emerald-300">
                      Resolved
                    </span>
                    <span className="text-xs text-brand-mute">
                      {timeAgo(i.resolved_at ?? i.started_at, now)}
                    </span>
                  </div>
                  <p className="mt-2 font-semibold text-brand-ink">{i.title}</p>
                  {i.body && <p className="mt-1 text-sm text-brand-mute">{i.body}</p>}
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="mt-8 rounded-2xl border border-brand-line bg-bg-elevated p-5">
          <h2 className="mb-2 text-lg font-bold text-brand-ink">Subscribe to status updates</h2>
          <p className="mb-4 text-sm text-brand-mute">
            Follow the live Atom feed in any RSS reader (Feedly, NetNewsWire, Slack) to get every
            incident the moment it&rsquo;s posted — no account, no email required.
          </p>
          <a
            href="/api/status/rss"
            data-bcl-action="status_subscribe_feed"
            className="inline-flex items-center gap-2 rounded-md bg-brand-accent px-4 py-2 text-sm font-semibold text-black transition-[filter] duration-300 hover:brightness-110"
            aria-label="Open the Brick Labor status Atom feed"
          >
            <span aria-hidden>📡</span> Follow the status feed
          </a>
        </section>
      </section>
    </main>
  );
}
