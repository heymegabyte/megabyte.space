import { useThemeToolsSurface } from '../../field-service-primitives.js';
/**
 * SuccessCheck.tsx — animated confirmation checkmark (BACKLOG ★ A6).
 *
 * A reusable success affordance: a circle ring that scales in, then a tick that
 * draws its stroke (stroke-dashoffset → 0). Pure SVG, zero deps. The motion is
 * compositor-only (transform + stroke-dashoffset) so it never triggers layout or
 * CLS, and it is fully gated by `prefers-reduced-motion` via the shared
 * `bcl-check-*` keyframes in `styles/index.css` — opt-out users get the final
 * drawn state instantly with no animation.
 *
 * Built for the booking money-path completion (`Booking.tsx`, success step) but
 * intentionally generic so any future "done / saved / sent" surface shares ONE
 * implementation (extend-don't-duplicate). The accessible name lives on the
 * wrapping `role="img"` element; the geometry is `aria-hidden`.
 */

interface SuccessCheckProps {
  /** Pixel size of the square SVG. Defaults to a hero-scale 64px. */
  readonly size?: number;
  /** Accessible label announced to assistive tech. */
  readonly label?: string;
  /** Extra classes on the wrapper (e.g. layout/margin from the caller). */
  readonly className?: string;
}

export function SuccessCheck({
  size = 64,
  label = 'Booking confirmed',
  className = '',
}: SuccessCheckProps) {
  useThemeToolsSurface('success-check');
  return (
    <span
      role="img"
      aria-label={label}
      className={`bcl-check inline-flex items-center justify-center ${className}`.trim()}
      style={{ width: size, height: size }}
    >
      <svg
        viewBox="0 0 52 52"
        width={size}
        height={size}
        fill="none"
        aria-hidden="true"
        focusable="false"
      >
        <circle
          className="bcl-check-ring"
          cx="26"
          cy="26"
          r="24"
          stroke="currentColor"
          strokeWidth="2"
          strokeOpacity="0.45"
        />
        <path
          className="bcl-check-tick"
          d="M15 27 l7 7 l15 -16"
          stroke="currentColor"
          strokeWidth="4"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </span>
  );
}
