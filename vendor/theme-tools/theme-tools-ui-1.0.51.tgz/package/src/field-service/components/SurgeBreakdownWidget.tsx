import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useMemo } from 'react';
import { computeSurge, surgeCents, type SurgeContext, type SurgeResult } from '@theme.tools/billing/field-service/surge';

// Per-quote deterministic surge breakdown. Renders a definition list of each
// contributing factor with its multiplier, the running total (capped at 1.6×),
// and a side-by-side comparison of the non-surge fare. Drops into Pricing.tsx
// as a sample and into Booking.tsx receipts as a transparency surface.
//
// Inputs are the same SurgeContext that computeSurge takes — pass through what
// the booking flow has (preferredDate, preferredTime, supply, …) and the
// widget renders the exact math the server will apply.

export interface SurgeBreakdownWidgetProps {
  ctx: SurgeContext;
  // Base hourly rate per person in dollars (default $50, our flat rate).
  baseHourlyRate?: number;
  // Crew size — used for the side-by-side total line.
  crewSize?: number;
  // Hours for the job (default 2).
  hours?: number;
  // Optional pre-computed surge — skip if you already called computeSurge upstream.
  precomputed?: SurgeResult;
  // Tag for analytics / dom id grouping.
  variant?: 'inline' | 'card';
}

function formatUsd(amount: number): string {
  return amount.toLocaleString('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

function formatMultiplier(m: number): string {
  return `×${m.toFixed(3).replace(/0+$/, '').replace(/\.$/, '')}`;
}

export function SurgeBreakdownWidget(props: SurgeBreakdownWidgetProps) {
  useThemeToolsSurface('surge-breakdown-widget');
  const {
    ctx,
    baseHourlyRate = 50,
    crewSize = 2,
    hours = 3,
    precomputed,
    variant = 'card',
  } = props;

  const result = useMemo<SurgeResult>(() => precomputed ?? computeSurge(ctx), [ctx, precomputed]);

  const baseFareCents = Math.round(baseHourlyRate * crewSize * hours * 100);
  const addedCents = surgeCents(baseFareCents, result);
  const totalCents = baseFareCents + addedCents;
  const surgedHourly = Math.round(baseHourlyRate * result.multiplier * 100) / 100;
  const capped = result.multiplier >= 1.6;

  const wrapperClass =
    variant === 'card'
      ? 'rounded-lg border border-brand-line bg-bg-primary/60 p-4 sm:p-5 text-sm'
      : 'text-sm';

  return (
    <section
      aria-label="Surge pricing breakdown"
      className={wrapperClass}
      data-testid="surge-breakdown-widget"
    >
      <header className="mb-3 flex items-baseline justify-between gap-3">
        <h3 className="font-display text-base font-bold text-brand-ink">
          Surge math, line by line
        </h3>
        <span className="font-mono text-xs text-brand-mute">deterministic</span>
      </header>

      {result.reasons.length === 0 ? (
        <p className="text-brand-mute">
          No surge factors active. You pay the base{' '}
          <strong className="text-brand-ink">{formatUsd(baseHourlyRate)}/hr</strong> per person.
        </p>
      ) : (
        <dl className="grid grid-cols-[1fr_auto] gap-x-4 gap-y-2">
          {result.reasons.map((r) => {
            const pct = Math.round((r.factor - 1) * 100);
            return (
              <div className="contents" key={`${r.kind}-${r.label}`}>
                <dt className="text-brand-ink">
                  <span className="font-medium">{r.label}</span>{' '}
                  <span className="text-brand-mute">+{pct}%</span>
                  <span className="block text-xs text-brand-mute">{r.detail}</span>
                </dt>
                <dd className="font-mono text-brand-accent tabular-nums">
                  {formatMultiplier(r.factor)}
                </dd>
              </div>
            );
          })}
        </dl>
      )}

      <div className="mt-4 border-t border-brand-line pt-3">
        <p className="text-brand-ink">
          <strong>Total:</strong>{' '}
          <span className="font-mono tabular-nums">{formatMultiplier(result.multiplier)}</span>{' '}
          {capped && (
            <span className="text-xs text-brand-mute">(capped at ×1.6 — hard ceiling)</span>
          )}
        </p>
        <p className="mt-1 text-brand-ink">
          Base: <span className="font-mono">{formatUsd(baseHourlyRate)}/hr</span> →{' '}
          <span className="font-mono text-brand-accent">{formatUsd(surgedHourly)}/hr</span>
        </p>
      </div>

      <div className="mt-3 grid gap-2 sm:grid-cols-2">
        <div className="rounded border border-brand-line bg-bg-elevated/30 px-3 py-2">
          <p className="text-xs uppercase tracking-wider text-brand-mute">Without surge</p>
          <p className="mt-1 font-mono text-base text-brand-ink tabular-nums">
            {formatUsd(baseFareCents / 100)}
          </p>
          <p className="text-xs text-brand-mute">
            {crewSize} crew × {hours} hr × ${baseHourlyRate}/hr
          </p>
        </div>
        <div className="rounded border border-brand-accent/40 bg-brand-accent/5 px-3 py-2">
          <p className="text-xs uppercase tracking-wider text-brand-accent">This job total</p>
          <p className="mt-1 font-mono text-base text-brand-ink tabular-nums">
            {formatUsd(totalCents / 100)}
          </p>
          <p className="text-xs text-brand-mute">base + {formatUsd(addedCents / 100)} surge</p>
        </div>
      </div>
    </section>
  );
}
