import { useThemeToolsSurface } from '../../field-service-primitives.js';
/**
 * SurgeExplainerModal.tsx — Wave 27 #16 "Why this price right now" modal.
 *
 * Opens via a "Why this price?" link on the booking screen. Shows a plain-
 * language breakdown of every active surge factor + a horizontal bar chart
 * weighted by factor strength so the customer can SEE which component drove
 * the increase. No surprises = no chargebacks.
 *
 * Imports `computeSurge` from `src/shared/surge.ts` so the worker + this UI
 * agree on the multiplier and reasons. Pure function, no I/O — deterministic.
 *
 * A7 (animation system): the dialog follows the ARIA APG modal pattern —
 * backdrop fades + panel slides/scales in with a back-out settle, Esc plays an
 * exit animation before closing, and focus is restored to whatever opened the
 * dialog. All motion is reduced-motion gated and collapses to an instant
 * open/close.
 *
 * SCAN-34 (2026-09-29): Tab-containment + focus-into-open + focus-restore now
 * come from the CANONICAL shared dialog a11y kit (`use-dialog-a11y` →
 * `useFocusManagement` + `useTabTrap`, strict pure math in `shared/focus-trap`),
 * the SAME primitive SosButton + AiChat + ExitIntentRescue use — this was the
 * LAST hand-rolled focus-trap in the app. `useTabTrap` drives focus EXPLICITLY on
 * every Tab via `nextTrapTarget` (never trusting the browser mid-ring), so the
 * mobile cross-viewport escape SCAN-21 fixed can't reappear here. The trigger
 * ("Why?" in SameDayPricingCard) stays mounted while open, so the shared kit's
 * restore lands back on it — no bespoke restore effect needed. axe is blind to
 * all of this; the shared kit is the only guard.
 *
 * Gated by `surge_explainer_modal`. Returns null until flag is on AND
 * the parent passes a non-null `open` prop.
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import { useFeatureFlag } from '../use-feature-flag.js';
import { computeSurge, type SurgeContext, type SurgeReason } from '@theme.tools/billing/field-service/surge';
import { useFocusManagement, useTabTrap } from '../use-dialog-a11y.js';
import { MODAL_EXIT_MS, prefersReducedMotion } from '../use-modal-motion.js';

interface Props {
  open: boolean;
  onClose: () => void;
  context: SurgeContext;
}

function friendlyExplanation(r: SurgeReason): string {
  switch (r.kind) {
    case 'same-day':
      return 'Same-day bookings cost more because we hold a fresh crew slot for you on zero notice.';
    case 'next-day':
      return 'Next-day priority dispatch — we lock in your slot ahead of new bookings.';
    case 'weekend':
      return 'Saturday and Sunday demand spikes; we pay our crew premium rates to work them.';
    case 'peak-hours':
      return 'Outside the 7am–7pm window we dispatch off-shift crew at a higher rate.';
    case 'peak-season':
      return 'Spring + early-fall are peak moving months. Demand outruns supply.';
    case 'low-supply':
      return 'Few crews are available for this exact slot — pricing reflects real scarcity.';
    default:
      return r.detail;
  }
}

function pctOver(factor: number): number {
  return Math.round((factor - 1) * 100);
}

export function SurgeExplainerModal({ open, onClose, context }: Props): JSX.Element | null {
  useThemeToolsSurface('surge-explainer-modal');
  const enabled = useFeatureFlag('surge_explainer_modal');
  const panelRef = useRef<HTMLDivElement>(null);
  const lastFocusRef = useRef<HTMLElement | null>(null);
  const [closing, setClosing] = useState(false);

  // Keep onClose in a ref so requestClose stays referentially stable even when
  // the parent passes a fresh arrow each render (avoids the open effect
  // re-firing mid-Tab).
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  const requestClose = useCallback(() => {
    if (prefersReducedMotion()) {
      onCloseRef.current();
      return;
    }
    setClosing(true);
    window.setTimeout(() => onCloseRef.current(), MODAL_EXIT_MS);
  }, []);

  // SCAN-34 — shared dialog a11y kit (no bespoke trap): focus moves INTO the
  // panel on open + restores to the trigger on close (useFocusManagement — the
  // "Why?" trigger stays mounted, so restore lands back on it); Tab / Shift+Tab
  // stay contained, wrapping first↔last via the strict nextTrapTarget math
  // (useTabTrap). Same primitive SosButton + AiChat + ExitIntentRescue use.
  useFocusManagement(open, panelRef, lastFocusRef);
  const onPanelKeyDown = useTabTrap(panelRef);

  // Clear the closing flag whenever we (re)open so a prior exit animation can't
  // leave the panel stuck mid-dismiss.
  useEffect(() => {
    if (open) setClosing(false);
  }, [open]);

  // Esc → animated close (Tab-containment + focus into/out is owned by the
  // shared kit above; this only routes Esc through the exit-animation path).
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        requestClose();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, requestClose]);

  if (!enabled) return null;
  if (!open) return null;

  const { multiplier, reasons } = computeSurge(context);
  const totalPct = pctOver(multiplier);

  return (
    <div
      role="presentation"
      data-closing={closing ? 'true' : undefined}
      className="bcl-modal-backdrop fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
      onClick={requestClose}
    >
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="surge-explainer-title"
        data-closing={closing ? 'true' : undefined}
        className="bcl-modal-panel max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-bg-primary p-6 ring-1 ring-white/10"
        onClick={(e) => e.stopPropagation()}
        onKeyDown={onPanelKeyDown}
        data-testid="surge-explainer-modal"
      >
        <header className="mb-4 flex items-start justify-between gap-4">
          <div>
            <h2 id="surge-explainer-title" className="text-xl font-semibold">
              Why this price right now?
            </h2>
            <p className="mt-1 text-sm text-white/60">
              Current adjustment:{' '}
              <span className="font-semibold text-brand-accent">
                {totalPct > 0 ? `+${totalPct}%` : 'No surge applied'}
              </span>
            </p>
          </div>
          <button
            type="button"
            onClick={requestClose}
            aria-label="Close"
            className="min-h-[44px] min-w-[44px] rounded-full bg-white/10 text-2xl transition-[transform,background-color] duration-[333ms] hover:scale-105 hover:bg-white/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
          >
            ×
          </button>
        </header>

        {reasons.length === 0 ? (
          <p className="text-sm text-white/80">
            No surge factors are active for your selected date and time. You&apos;re paying our
            standard rate.
          </p>
        ) : (
          <ul className="space-y-4">
            {reasons.map((r) => {
              const pct = pctOver(r.factor);
              const barWidth = Math.min(100, Math.max(5, pct * 4));
              return (
                <li key={r.kind}>
                  <div className="mb-1 flex items-baseline justify-between">
                    <span className="font-semibold">{r.label}</span>
                    <span className="text-sm text-brand-accent">+{pct}%</span>
                  </div>
                  <div aria-hidden className="h-2 w-full overflow-hidden rounded-full bg-white/10">
                    <div
                      className="bcl-surge-bar h-full rounded-full bg-brand-accent"
                      style={{ width: `${barWidth}%` }}
                    />
                  </div>
                  <p className="mt-2 text-sm leading-relaxed text-white/70">
                    {friendlyExplanation(r)}
                  </p>
                </li>
              );
            })}
          </ul>
        )}

        <footer className="mt-6 border-t border-white/10 pt-4 text-xs text-white/70">
          Adjustments stack multiplicatively and are capped at +60% no matter what. Move to a
          weekday daytime slot to reduce or remove surge.
        </footer>
      </div>
    </div>
  );
}
