import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
// Public "What crew keeps" explainer at /take-rate. EEAT-aligned — visible
// breakdown of where each customer dollar goes, who gets what slice, and
// what the platform 22% actually pays for. Pair with footer link.

import { useEffect } from 'react';

interface TakeRow {
  label: string;
  pct: number;
  detail: string;
  recipient: 'crew' | 'platform';
}

const ROWS: TakeRow[] = [
  {
    label: 'Crew take-home',
    pct: 78,
    recipient: 'crew',
    detail: 'Direct to the worker via Stripe Connect — base pay + any rush, after-hours, and tip.',
  },
  {
    label: 'Liability insurance',
    pct: 5,
    recipient: 'platform',
    detail: '$2M general liability + $1M auto on the dispatch policy. COI sent on request.',
  },
  {
    label: 'Workers comp + payroll',
    pct: 4,
    recipient: 'platform',
    detail: 'NJ workers-comp premium per gig-hour + payroll tax employer share.',
  },
  {
    label: 'Stripe + Square fees',
    pct: 3,
    recipient: 'platform',
    detail: 'Card processing + payout transfer fees. We pay full cost — never marked up.',
  },
  {
    label: 'Dispatch + ops',
    pct: 5,
    recipient: 'platform',
    detail:
      'Phones answered 7am–9pm, SMS dispatch, customer support, manual review of flagged jobs.',
  },
  {
    label: 'Software + infra',
    pct: 3,
    recipient: 'platform',
    detail: 'Twilio SMS, Resend email, Sentry monitoring, Cloudflare Workers, D1 + R2 storage.',
  },
  {
    label: 'Reserves + reinvestment',
    pct: 2,
    recipient: 'platform',
    detail: 'Refund pool, owner profit, gear replacement, training modules.',
  },
];

function shareClass(recipient: TakeRow['recipient']): string {
  return recipient === 'crew' ? 'text-brand-accent' : 'text-brand-ink';
}

export function TakeRatePage() {
  useThemeToolsSurface('take-rate-page');
  useEffect(() => {
    document.title = 'Crew Take Rate · 78% Goes Directly to Crew · Brick Labor';
    return () => {
      document.title = 'Brick Labor · $50/hr Property Crew Newark NJ';
    };
  }, []);

  const crewTotal = ROWS.filter((r) => r.recipient === 'crew').reduce((a, r) => a + r.pct, 0);
  const platformTotal = ROWS.filter((r) => r.recipient === 'platform').reduce(
    (a, r) => a + r.pct,
    0,
  );

  return (
    <main className="section">
      <div className="container-pad max-w-4xl">
        <p className="eyebrow mb-3">Transparency</p>
        <h1 className="text-4xl sm:text-5xl font-extrabold">
          What crew keeps. <span className="text-gradient">Where the platform 22% goes.</span>
        </h1>
        <p className="mt-4 text-lg text-brand-mute">
          Every dollar a customer pays gets split two ways. The crew on your job gets{' '}
          <strong className={shareClass('crew')}>{crewTotal}%</strong>. The platform keeps{' '}
          <strong className="text-brand-ink">{platformTotal}%</strong> — and every cent of that pays
          for the insurance, payroll, dispatch, payments, and software that make Brick Labor
          not-a-Craigslist-handshake.
        </p>

        <section className="mt-10 rounded-xl border border-brand-line bg-bg-elevated/40 p-5 sm:p-6">
          <h2 className="font-display text-2xl font-bold">Per-dollar breakdown</h2>
          <p className="mt-1 text-sm text-brand-mute">
            On a $100 customer charge, this is who gets what. Percentages are blended averages
            across job types — actual job-by-job math varies by hours, crew size, and rentals.
          </p>
          <div className="mt-5 overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-xs uppercase tracking-wider text-brand-mute">
                <tr className="border-b border-brand-line">
                  <th className="py-2 pr-3">Line item</th>
                  <th className="py-2 pr-3">Recipient</th>
                  <th className="py-2 pr-3 text-right">% of charge</th>
                  <th className="py-2 pr-3 text-right">Per $100</th>
                </tr>
              </thead>
              <tbody>
                {ROWS.map((row) => (
                  <tr key={row.label} className="border-b border-brand-line/50 align-top">
                    <td className="py-3 pr-3">
                      <p className="font-medium text-brand-ink">{row.label}</p>
                      <p className="mt-0.5 text-xs text-brand-mute">{row.detail}</p>
                    </td>
                    <td className="py-3 pr-3 text-xs uppercase tracking-wider">
                      <span
                        className={`rounded-full border px-2 py-0.5 ${
                          row.recipient === 'crew'
                            ? 'border-brand-accent/40 text-brand-accent'
                            : 'border-brand-line text-brand-mute'
                        }`}
                      >
                        {row.recipient === 'crew' ? 'Crew' : 'Platform'}
                      </span>
                    </td>
                    <td className="py-3 pr-3 text-right font-mono tabular-nums">{row.pct}%</td>
                    <td className="py-3 pr-3 text-right font-mono tabular-nums text-brand-mute">
                      ${row.pct.toFixed(2)}
                    </td>
                  </tr>
                ))}
                <tr className="font-bold text-brand-ink">
                  <td className="py-3 pr-3">Total</td>
                  <td className="py-3 pr-3" />
                  <td className="py-3 pr-3 text-right font-mono tabular-nums">100%</td>
                  <td className="py-3 pr-3 text-right font-mono tabular-nums">$100.00</td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>

        <section className="mt-10 grid gap-5 sm:grid-cols-2">
          <div className="rounded-xl border border-brand-line bg-bg-primary p-5">
            <h3 className="font-display text-lg font-bold text-brand-ink">Why this is high</h3>
            <p className="mt-2 text-sm text-brand-mute">
              Industry app marketplaces routinely take 30–40% (TaskRabbit, Bellhop, Handy). We run
              leaner because we don't pay app-install or paid-search ads — every booking is
              word-of-mouth or organic search. That savings flows straight to crew.
            </p>
          </div>
          <div className="rounded-xl border border-brand-line bg-bg-primary p-5">
            <h3 className="font-display text-lg font-bold text-brand-ink">What this is not</h3>
            <p className="mt-2 text-sm text-brand-mute">
              This is not a 1099-vs-W-2 dodge. Crew are paid as W-2 employees with workers comp, not
              as independent contractors. The platform absorbs the employer-side payroll tax and
              benefits — listed above so you can see exactly what your dollar covers.
            </p>
          </div>
        </section>

        <section className="mt-10 rounded-xl border border-brand-accent/40 bg-brand-accent/5 p-5 sm:p-6">
          <h2 className="font-display text-2xl font-bold text-brand-ink">
            Want to verify? Ask for the books.
          </h2>
          <p className="mt-2 text-sm text-brand-mute">
            Brian (owner) will email last-quarter's P&amp;L on request to any customer or crew
            member, redacted for individual employee detail. The split has not changed since launch.{' '}
            <a href="mailto:hey@bricklabor.com" className="text-brand-accent underline-hover">
              hey@bricklabor.com
            </a>
            .
          </p>
        </section>
      </div>
    </main>
  );
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
