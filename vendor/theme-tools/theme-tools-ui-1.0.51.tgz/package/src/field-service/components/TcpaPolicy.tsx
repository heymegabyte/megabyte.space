import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect } from 'react';
import { PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';

// Wave 2B — TCPA / SMS policy page rendered at /tcpa.
// Spelled-out revocation flow (STOP / UNSUBSCRIBE / CANCEL / REMOVE / QUIT / END)
// mirrors the keywords honored by /api/sms-inbound (see Wave 1D `sms_revocations`).

const TITLE = 'SMS / TCPA Policy — Brick Labor';
const DESC =
  'How Brick Labor handles SMS: opt-in, opt-out keywords (STOP / UNSUBSCRIBE / CANCEL / REMOVE / QUIT / END), what we send, how often, and how to reach a human.';

const REVOCATION_KEYWORDS: ReadonlyArray<string> = [
  'STOP',
  'UNSUBSCRIBE',
  'CANCEL',
  'REMOVE',
  'QUIT',
  'END',
];

export function TcpaPolicy() {
  useThemeToolsSurface('tcpa-policy');
  useEffect(() => {
    document.title = TITLE;
    setMeta('description', DESC);
    setLink('canonical', 'https://bricklabor.com/tcpa');
  }, []);

  return (
    <article className="section" data-testid="tcpa-policy">
      <div className="container-pad max-w-3xl">
        <p className="eyebrow mb-3">Legal · TCPA</p>
        <h1 className="text-4xl sm:text-5xl font-extrabold mb-3">SMS / TCPA policy</h1>
        <p className="text-brand-mute text-base mb-8 max-w-2xl">
          Plain-English summary of how we use text messages, what you can expect, and exactly which
          words to text us to stop. Last updated 2026-05-19.
        </p>

        <div className="prose prose-invert prose-headings:font-display prose-h2:text-2xl prose-h2:font-extrabold prose-h2:text-brand-ink prose-p:text-brand-mute prose-strong:text-brand-ink prose-a:text-brand-accent space-y-6 max-w-none">
          <section>
            <h2>What we text you</h2>
            <p>
              Booking confirmations, crew dispatch updates ("crew is on the way", "arrived on site",
              "job complete"), payment receipts, and the one-link review request after the job. We
              never sell or share your phone number with anyone, and we never text marketing without
              an explicit second opt-in.
            </p>
          </section>

          <section>
            <h2>How often</h2>
            <p>
              At most ~6 messages per booking — confirmation, deposit receipt, dispatch ping,
              en-route, complete, and review. Recurring service customers get one reminder text per
              upcoming visit and one review link after.
            </p>
          </section>

          <section>
            <h2>How you opted in</h2>
            <p>
              You either (a) checked the SMS opt-in box on the booking form, or (b) replied with
              your initials to a quote text. Either way, we keep a record of when you opted in and
              how. Ask us anytime and we'll send you a copy.
            </p>
          </section>

          <section data-testid="revocation-block">
            <h2>How to stop</h2>
            <p>
              Reply with any of these single-word keywords (case doesn't matter) to the most recent
              text from us:
            </p>
            <ul className="grid grid-cols-2 sm:grid-cols-3 gap-2 not-prose">
              {REVOCATION_KEYWORDS.map((kw) => (
                <li
                  key={kw}
                  className="rounded-md border border-brand-line bg-brand-card px-3 py-2 text-brand-ink font-mono text-sm text-center"
                  data-revocation-keyword={kw}
                >
                  {kw}
                </li>
              ))}
            </ul>
            <p>
              We confirm the opt-out with a single reply ("You've been opted out. Reply START to
              resume."), then never text you again unless you re-opt-in with the keyword START.
            </p>
            <p>
              You can also email <a href="mailto:hey@bricklabor.com">hey@bricklabor.com</a> with the
              subject "remove me" and we'll process it within one business day. Or call{' '}
              <a href={PHONE_TEL_HREF}>(855) 82LABOR</a> and ask for the owner.
            </p>
          </section>

          <section>
            <h2>How to get help</h2>
            <p>
              Reply <strong>HELP</strong> to any text and we'll send back our business hours, email,
              and the owner's direct line. We aim to reply to real humans (not bots) in under 2
              hours during business hours and under 12 hours otherwise.
            </p>
          </section>

          <section>
            <h2>Message + data rates</h2>
            <p>
              Standard message and data rates may apply per your carrier plan. We never charge for
              SMS — Twilio bills us, not you.
            </p>
          </section>

          <section>
            <h2>Compliance + carrier rules</h2>
            <p>
              We're registered under the CTIA + carrier 10DLC rules with Twilio. Our messaging
              follows the TCPA (Telephone Consumer Protection Act) and FCC opt-out requirements. We
              log every opt-in and opt-out event in our audit trail; ask any time and we'll show you
              yours.
            </p>
          </section>

          <section>
            <h2>Where this fits</h2>
            <p>
              Read alongside our <a href="/privacy">privacy policy</a>,{' '}
              <a href="/terms">terms of service</a>, and the{' '}
              <a href="/claims">public claims board</a>. The whole stack is built so you can leave
              any time without paperwork.
            </p>
          </section>
        </div>
      </div>
    </article>
  );
}

function setMeta(name: string, content: string) {
  let el = document.querySelector<HTMLMetaElement>(`meta[name="${name}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute('name', name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function setLink(rel: string, href: string) {
  let el = document.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', rel);
    document.head.appendChild(el);
  }
  el.setAttribute('href', href);
}
