import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect } from 'react';
import { PROHIBITED_ITEMS, PROHIBITED_ACK_LINE } from '@theme.tools/crm/field-service/prohibited-items';
import {
  SERVICE_GUARANTEE_COVERED,
  SERVICE_GUARANTEE_EXCLUDED,
  SERVICE_GUARANTEE_PATH,
  SERVICE_GUARANTEE_RESPONSE_WINDOW,
} from '@theme.tools/crm/field-service/service-guarantee';
import { PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';

const TITLE = 'Terms of Service · Brick Labor — Newark NJ Crew Booking';
const DESC =
  'Booking, cancellation, payment, and liability terms for casual property work hired through Brick Labor. Casual help, not a licensed contractor.';
const LAST_UPDATED = '2026-06-25';

export function Terms() {
  useThemeToolsSurface('terms');
  useEffect(() => {
    document.title = TITLE;
    setMeta('description', DESC);
    setLink('canonical', 'https://bricklabor.com/terms');
    setMeta('robots', 'index,follow', 'name');
  }, []);

  return (
    <article className="section">
      <div className="container-pad max-w-3xl">
        <p className="eyebrow mb-3">Legal</p>
        <h1 className="text-4xl sm:text-5xl font-extrabold mb-2 text-brand-ink">
          Terms of Service
        </h1>
        <p className="text-brand-mute mb-6">Last updated: {LAST_UPDATED}</p>

        <aside
          role="note"
          aria-label="Attorney review recommended"
          className="mb-10 rounded-md border border-amber-400/40 bg-amber-400/10 p-4 text-amber-100"
        >
          <p className="text-sm leading-relaxed">
            <strong className="font-bold">Heads up:</strong> This document was drafted with AI
            assistance. We strongly recommend having a licensed attorney review it before relying on
            it for your business or as a binding contract for yours.
          </p>
        </aside>

        <nav
          aria-label="On this page"
          className="mb-10 rounded-md border border-brand-line bg-bg-elevated/40 p-5 text-sm"
        >
          <p className="eyebrow mb-3">On this page</p>
          <ol className="grid gap-1 sm:grid-cols-2">
            <li>
              <a href="#service" className="text-brand-accent underline-hover">
                1. Service description &amp; parties
              </a>
            </li>
            <li>
              <a href="#eligibility" className="text-brand-accent underline-hover">
                2. Eligibility
              </a>
            </li>
            <li>
              <a href="#accounts" className="text-brand-accent underline-hover">
                3. Accounts &amp; sessions
              </a>
            </li>
            <li>
              <a href="#payment" className="text-brand-accent underline-hover">
                4. Payment, pricing &amp; surge
              </a>
            </li>
            <li>
              <a href="#cancellation" className="text-brand-accent underline-hover">
                5. Cancellation &amp; reschedule
              </a>
            </li>
            <li>
              <a href="#refunds" className="text-brand-accent underline-hover">
                6. Refunds &amp; disputes
              </a>
            </li>
            <li>
              <a href="#no-show" className="text-brand-accent underline-hover">
                7. No-shows &amp; late arrivals
              </a>
            </li>
            <li>
              <a href="#weather" className="text-brand-accent underline-hover">
                8. Weather
              </a>
            </li>
            <li>
              <a href="#access" className="text-brand-accent underline-hover">
                9. Property access &amp; customer obligations
              </a>
            </li>
            <li>
              <a href="#prohibited" className="text-brand-accent underline-hover">
                10. Prohibited &amp; excluded items
              </a>
            </li>
            <li>
              <a href="#crew-insurance" className="text-brand-accent underline-hover">
                11. Crew insurance disclaimer
              </a>
            </li>
            <li>
              <a href="#sms-consent" className="text-brand-accent underline-hover">
                12. Automated SMS (TCPA)
              </a>
            </li>
            <li>
              <a href="#damages" className="text-brand-accent underline-hover">
                13. Damages &amp; claims
              </a>
            </li>
            <li>
              <a href="#liability" className="text-brand-accent underline-hover">
                14. Indemnification &amp; liability
              </a>
            </li>
            <li>
              <a href="#arbitration" className="text-brand-accent underline-hover">
                15. Arbitration agreement
              </a>
            </li>
            <li>
              <a href="#law" className="text-brand-accent underline-hover">
                16. Governing law
              </a>
            </li>
            <li>
              <a href="#changes" className="text-brand-accent underline-hover">
                17. Changes to these terms
              </a>
            </li>
          </ol>
        </nav>

        <div className="space-y-10 text-brand-mute leading-relaxed [text-wrap:pretty]">
          <section id="service">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">
              1. Service description &amp; parties
            </h2>
            <p>
              Brick Labor ("<strong>BCL</strong>", "we", "us") operates a Newark NJ
              labor-booking platform that pairs customers with independent crew members for property
              services — power washing, hauling, lawn care, cleanouts, light repairs, and similar
              exterior work. BCL is the platform. <strong>Customers</strong> are end-users who book
              a job. <strong>Crew members</strong> are independent contractors who claim and perform
              gigs through the platform. BCL is not a party to the labor contract between a customer
              and a crew member, except where these Terms expressly say so (payment processing,
              dispute mediation, platform safety).
            </p>
            <p className="mt-3">
              These Terms govern your use of the website, the booking app, the crew dashboard, and
              every email or SMS we send you. By booking a job, claiming a gig, or creating an
              account, you agree to these Terms and to our{' '}
              <a href="/privacy" className="text-brand-accent underline-hover">
                Privacy Policy
              </a>
              .
            </p>
          </section>

          <section id="eligibility">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">2. Eligibility</h2>
            <p>To use BCL you must:</p>
            <ul className="mt-3 list-disc space-y-2 pl-6">
              <li>Be 18 years of age or older.</li>
              <li>
                Have a valid US-reachable phone number and a working email address, so we can send
                booking confirmations, dispatch notices, and receipts.
              </li>
              <li>
                Provide a real service address inside our coverage area when you book — we do not
                accept ghost addresses, virtual mailboxes, or PO boxes for on-site work.
              </li>
              <li>
                Have the legal authority to authorize work at the property (owner, tenant with
                landlord permission, or authorized agent).
              </li>
            </ul>
          </section>

          <section id="accounts">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">
              3. Accounts &amp; sessions
            </h2>
            <p>
              We use passwordless magic-link authentication delivered by email or SMS. There is no
              password to remember and no password to steal. After you authenticate, we set a
              session cookie:
            </p>
            <ul className="mt-3 list-disc space-y-2 pl-6">
              <li>
                <code className="rounded bg-bg-elevated px-1.5 py-0.5 text-brand-ink">
                  bcl_cust_sid
                </code>{' '}
                — customer session, 14-day lifetime, used at <code>/me</code> and during checkout.
              </li>
              <li>
                <code className="rounded bg-bg-elevated px-1.5 py-0.5 text-brand-ink">
                  bcl_work_sid
                </code>{' '}
                — crew session, 30-day lifetime, used at <code>/work/dashboard</code> and during gig
                accept.
              </li>
            </ul>
            <p className="mt-3">
              Both cookies are HttpOnly, Secure, SameSite=Lax. You are responsible for the security
              of the device that holds your session. If you suspect a session was used without your
              permission, email{' '}
              <a href="mailto:hey@bricklabor.com" className="text-brand-accent underline-hover">
                hey@bricklabor.com
              </a>{' '}
              and we will revoke it.
            </p>
          </section>

          <section id="payment">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">
              4. Payment, pricing &amp; surge
            </h2>
            <p>
              BCL uses <strong>Square</strong> to process customer payments (deposit, balance, and
              tips). BCL uses <strong>Stripe Connect</strong> to send weekly payouts to crew
              members. We do not store full card numbers — Square holds the card on file under its
              PCI-compliant vault and BCL receives only the last four digits and a customer ID.
            </p>
            <p className="mt-3">
              <strong>Pricing transparency.</strong> The checkout screen shows the flat hourly rate
              per crew member multiplied by the crew size you chose and the hours you estimated. Any
              surge multiplier in effect at the time of booking is disclosed line-item on the
              checkout screen before you confirm. Surge factors include:
            </p>
            <ul className="mt-3 list-disc space-y-2 pl-6">
              <li>
                <strong>Same-day demand</strong> — booking for today inside peak hours.
              </li>
              <li>
                <strong>Weekend</strong> — Saturday and Sunday work.
              </li>
              <li>
                <strong>Peak season</strong> — spring power-wash season, fall cleanout season.
              </li>
              <li>
                <strong>Low supply</strong> — when fewer crew members are claiming gigs in your area
                on your requested window.
              </li>
            </ul>
            <p className="mt-3">
              The surge multiplier is capped at 1.6x the base rate. If you do not see a multiplier
              line item on checkout, no surge is in effect for that booking. Tips are optional, are
              charged separately by Square, and pass through 100% to the crew member.
            </p>
          </section>

          <section id="cancellation">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">
              5. Cancellation &amp; reschedule
            </h2>
            <p>You may cancel or reschedule any booking on these terms:</p>
            <ul className="mt-3 list-disc space-y-2 pl-6">
              <li>
                <strong>More than 24 hours before the scheduled start</strong> — free cancellation,
                free reschedule, full refund of any deposit.
              </li>
              <li>
                <strong>Inside 24 hours of the scheduled start</strong> — 50% of the booking total
                is non-refundable. The other 50% is refunded to your original payment method.
              </li>
              <li>
                <strong>No-show or cancellation after the crew has been dispatched</strong> — the
                full booking total is charged.
              </li>
            </ul>
            <p className="mt-3">
              Use the cancel or reschedule link in your confirmation email, your{' '}
              <a href="/me" className="text-brand-accent underline-hover">
                customer dashboard
              </a>
              , or reply to any BCL SMS with the word <strong>RESCHEDULE</strong> or{' '}
              <strong>CANCEL</strong>.
            </p>
          </section>

          <section id="refunds">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">
              6. Refunds &amp; disputes
            </h2>
            <p>
              Square refunds are returned to the original payment method. Refund processing time is
              controlled by Square and your bank — credit card refunds typically post in 5 to 10
              business days, ACH bank-debit refunds typically in 3 to 5 business days. When a refund
              is outside Square's automated window, BCL may issue a discretionary platform credit
              instead, applicable to a future booking, valid for 12 months from issuance.
            </p>
            <p className="mt-3">
              If you believe a charge is wrong, contact us at{' '}
              <a href="mailto:hey@bricklabor.com" className="text-brand-accent underline-hover">
                hey@bricklabor.com
              </a>{' '}
              before filing a chargeback with your card issuer. Chargebacks filed without giving us
              a chance to resolve the dispute first may result in account suspension.
            </p>

            <h3 className="mt-6 mb-3 text-lg font-bold text-brand-ink">
              6.1 Service guarantee — 100% satisfaction or your money back
            </h3>
            <p>
              If a job genuinely falls short, you may request a refund through the in-app AI chat,
              your bookings page, or by texting (855) 82LABOR. Every request is reviewed against the
              booking, the photos, and the audit log; approved refunds are returned to your original
              payment method through Square. We aim to issue a personal decision{' '}
              {SERVICE_GUARANTEE_RESPONSE_WINDOW}. Full details live on the{' '}
              <a href={SERVICE_GUARANTEE_PATH} className="text-brand-accent underline-hover">
                Service Guarantee page
              </a>
              .
            </p>
            <p className="mt-3 font-semibold text-brand-ink">A refund is on the table when:</p>
            <ul className="mt-2 list-disc space-y-1 pl-6">
              {SERVICE_GUARANTEE_COVERED.map((s) => (
                <li key={s.id}>{s.text}</li>
              ))}
            </ul>
            <p className="mt-3 font-semibold text-brand-ink">The guarantee does not cover:</p>
            <ul className="mt-2 list-disc space-y-1 pl-6">
              {SERVICE_GUARANTEE_EXCLUDED.map((s) => (
                <li key={s.id}>{s.text}</li>
              ))}
            </ul>
          </section>

          <section id="no-show">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">
              7. No-shows &amp; late arrivals
            </h2>
            <p>The policy runs both directions:</p>
            <ul className="mt-3 list-disc space-y-2 pl-6">
              <li>
                <strong>Crew is more than 30 minutes late</strong> — you may cancel the booking for
                a full refund or request a discount of 10% per additional 15 minutes of delay (up to
                40%), at your option.
              </li>
              <li>
                <strong>
                  Crew arrives but the customer is not reachable at the property after three contact
                  attempts within 30 minutes
                </strong>{' '}
                — the booking is recorded as a customer no-show and the full booking total is
                charged. The first 30 minutes of dispatched-crew time is paid to the crew member out
                of that charge.
              </li>
              <li>
                <strong>Customer cancels after crew dispatch but before arrival</strong> — a
                dispatch fee equal to one hour at the booked rate is charged; the remainder is
                refunded.
              </li>
            </ul>
          </section>

          <section id="weather">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">8. Weather</h2>
            <p>
              Outdoor work depends on safe conditions. Either party — BCL on behalf of crew safety,
              or the customer for any reason — may reschedule a booking without penalty when the
              National Weather Service forecast for the service ZIP at the start time includes:
            </p>
            <ul className="mt-3 list-disc space-y-2 pl-6">
              <li>Active severe-weather watch or warning (thunderstorm, tornado, flood, ice).</li>
              <li>
                Sustained winds above 30 mph or wind-chill below 20°F (limits power-washing and
                roof-adjacent work specifically).
              </li>
              <li>Heat index at or above 100°F (limits exertional outdoor labor).</li>
              <li>Lightning observed within 10 miles inside the prior 30 minutes.</li>
            </ul>
            <p className="mt-3">
              Weather reschedules are free for both sides and roll to the next mutually-available
              slot. We will text you no later than two hours before dispatch when weather is the
              reason.
            </p>
          </section>

          <section id="access">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">
              9. Property access &amp; customer obligations
            </h2>
            <p>You are responsible for ensuring the crew can do the job you booked:</p>
            <ul className="mt-3 list-disc space-y-2 pl-6">
              <li>
                <strong>Gate and door access</strong> — unlock gates, disable alarms, restrain pets,
                and clear a path to the work area before the scheduled start time.
              </li>
              <li>
                <strong>Parking</strong> — provide a legal parking spot within 200 feet of the work
                area, or notify us in advance if street parking is the only option.
              </li>
              <li>
                <strong>Utilities for the job</strong> — power washing requires an outdoor spigot
                with water pressure of at least 40 PSI and a 120V outlet within 100 feet; light
                repairs may require power at the work location. Tell us in advance if either is
                unavailable.
              </li>
              <li>
                <strong>Materials</strong> — unless the booking explicitly includes "BCL-supplied
                materials", you are responsible for providing job-specific supplies (mulch,
                fasteners, paint, trash bags).
              </li>
              <li>
                <strong>Authorization</strong> — you confirm that you have the legal authority to
                authorize the work and to consent to crew presence on the property.
              </li>
            </ul>
          </section>

          <section id="prohibited">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">
              10. Prohibited &amp; excluded items
            </h2>
            <p>
              Brick Labor is casual hourly labor — not a licensed hazmat, abatement, or
              regulated-waste hauler. By booking, you agree the crew will not load, haul, or handle
              the materials below. NJ DEP and EPA rules require a licensed vendor for each. This is
              the same list you acknowledge at checkout, so the contract and the job site never
              disagree:
            </p>
            <ul className="mt-4 grid gap-3 sm:grid-cols-2" aria-label="Materials the crew will not handle">
              {PROHIBITED_ITEMS.map((item) => (
                <li
                  key={item.id}
                  className="rounded-r-md border-l-4 border-amber-400/70 bg-amber-400/5 p-4 transition-colors duration-[0.333s] hover:bg-amber-400/10"
                >
                  <p className="font-bold text-brand-ink">{item.label}</p>
                  <p className="mt-1 text-sm text-brand-mute">{item.examples}</p>
                  <p className="mt-2 text-xs font-medium uppercase tracking-wider text-amber-300/90">
                    {item.reason}
                  </p>
                </li>
              ))}
            </ul>
            <p className="mt-4">
              If the crew arrives and the job requires handling any prohibited material, they will
              decline that portion of the work and you remain responsible for the one-hour booking
              minimum. We will point you to the correct licensed vendor — we would rather
              refer you than do a job we are not equipped to do safely.
            </p>
            <p className="mt-3 rounded-md border border-brand-line bg-bg-elevated/40 p-4 text-sm italic text-brand-ink/90">
              “{PROHIBITED_ACK_LINE}”
            </p>
          </section>

          <aside
            id="crew-insurance"
            role="note"
            aria-labelledby="crew-insurance-heading"
            className="rounded-r-md border-l-4 border-amber-400 bg-amber-400/5 p-4"
          >
            <h2
              id="crew-insurance-heading"
              className="mt-0 mb-3 text-2xl font-extrabold text-brand-ink"
            >
              11. Crew insurance disclaimer
            </h2>
            <p className="text-brand-ink/90">
              <strong>
                Crew members are independent contractors. They are NOT insured by Brick Labor.
              </strong>{' '}
              BCL does not provide commercial general liability coverage, workers' compensation
              coverage, or property-damage coverage for work performed by crew members at customer
              properties.
            </p>
            <p className="mt-3 text-brand-ink/90">
              <strong>Customers retain full responsibility</strong> for their own property insurance
              and any general-liability coverage they require for third parties working on their
              premises. Before booking, confirm that your homeowner's, renter's, or
              commercial-property policy covers contractor-performed exterior work and any equipment
              brought onsite by a contractor.
            </p>
            <p className="mt-3 text-brand-ink/90">
              BCL maintains general-liability coverage for the operation of the booking platform
              itself (website, dispatch software, payments). That coverage <strong>does NOT</strong>{' '}
              extend to property damage, bodily injury, or financial loss caused by a crew member
              acting in scope of a booked job. Claims arising from crew conduct must be addressed to
              the crew member directly or through the dispute-resolution process in Section 13.
            </p>
            <p className="mt-3 text-brand-ink/90">
              If you require certificate-of-insurance evidence before allowing work to begin, do not
              book through BCL — book through a licensed and insured general contractor instead. We
              are casual labor, priced accordingly, and we are honest about the trade-off.
            </p>
          </aside>

          <aside
            id="sms-consent"
            role="note"
            aria-labelledby="sms-consent-heading"
            className="rounded-r-md border-l-4 border-amber-400 bg-amber-400/5 p-4"
          >
            <h2
              id="sms-consent-heading"
              className="mt-0 mb-3 text-2xl font-extrabold text-brand-ink"
            >
              12. Automated SMS notifications (TCPA consent)
            </h2>
            <p className="text-brand-ink/90">
              The phone number you provide at booking triggers automated SMS messages from BCL. For
              customers, this includes: booking confirmation, day-before reminder, dispatch
              notification when the crew is en route with live ETA, arrival ping, post-job receipt,
              and a one-time review request. For crew members, this includes: gig invites with
              accept-by-reply, schedule reminders, dispatch-handoff messages, and weekly payout
              notifications.
            </p>
            <p className="mt-3 text-brand-ink/90">
              <strong>
                By submitting a booking or claiming a gig, you expressly consent under the Telephone
                Consumer Protection Act (TCPA, 47 U.S.C. § 227)
              </strong>{' '}
              to receive these automated SMS messages at the number you provided. Consent is not a
              condition of purchase — you may opt out at any time without losing access to the
              booked service (we will fall back to email and phone calls).
            </p>
            <p className="mt-3 text-brand-ink/90">
              <strong>Opt-out:</strong> reply <code>STOP</code> to any BCL SMS to immediately and
              permanently stop all marketing and transactional SMS to that number. Reply{' '}
              <code>HELP</code> for our contact information. Standard message and data rates from
              your carrier apply. Message frequency varies by booking activity; typical customer
              flow is 4 to 7 messages per booking, typical crew flow is 5 to 15 messages per gig.
            </p>
          </aside>

          <section id="damages">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">
              13. Damages &amp; claims
            </h2>
            <p>
              If you believe a crew member caused property damage during a booked job, file a claim
              within <strong>15 days</strong> of the job completion date via the claims form at{' '}
              <code>/claims</code> or by email to{' '}
              <a href="mailto:hey@bricklabor.com" className="text-brand-accent underline-hover">
                hey@bricklabor.com
              </a>{' '}
              with the subject <code>CLAIM</code>. Include the booking ID, dated photos of the
              damage, and a written description.
            </p>
            <p className="mt-3">
              <strong>BCL mediates.</strong> We will review the claim within 7 business days,
              contact the crew member named in the booking, and attempt to facilitate a resolution.
              As stated in Section 11, BCL does not underwrite crew liability — any monetary
              settlement is between you and the crew member, with BCL acting as a neutral
              intermediary. If mediation fails, the dispute escalates to the arbitration process in
              Section 15.
            </p>
          </section>

          <section id="liability">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">
              14. Indemnification &amp; limitation of liability
            </h2>
            <p>
              You agree to indemnify, defend, and hold harmless BCL, its officers, employees, and
              contractors against any claim, loss, damage, or expense (including reasonable
              attorneys' fees) arising from: (a) your use of the platform; (b) your breach of these
              Terms; (c) your violation of any law or third-party right; or (d) any work authorized
              at a property you do not have the legal right to authorize work at.
            </p>
            <p className="mt-3">
              <strong>Limitation of liability.</strong> To the maximum extent permitted by law,
              BCL's aggregate liability to you for any claim arising from these Terms or the service
              is capped at the total amount you paid BCL for the specific booking that gave rise to
              the claim. BCL is not liable for indirect, incidental, consequential, punitive, or
              special damages, including lost profits, lost goodwill, or loss of data, even if BCL
              was advised of the possibility of such damages.
            </p>
            <p className="mt-3">
              You waive any right to bring a claim against BCL more than one year after the event
              giving rise to the claim, except where a longer period is required by applicable
              consumer-protection law.
            </p>
          </section>

          <section id="arbitration">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">
              15. Arbitration agreement
            </h2>
            <p>
              Any dispute, claim, or controversy arising out of or relating to these Terms, the
              service, or any booking — that is not first resolved through the mediation process in
              Section 13 — shall be resolved exclusively through{' '}
              <strong>binding individual arbitration</strong> administered by the American
              Arbitration Association ("AAA") under its Commercial Arbitration Rules. The
              arbitration shall be conducted in Essex County, New Jersey, in English, by a single
              arbitrator selected per the AAA rules. Judgment on the award may be entered in any
              court of competent jurisdiction.
            </p>
            <p className="mt-3">
              <strong>Class-action waiver.</strong> You and BCL agree that each may bring claims
              against the other only in your or its individual capacity, and not as a plaintiff or
              class member in any purported class or representative proceeding.
            </p>
            <p className="mt-3">
              <strong>30-day opt-out.</strong> You may opt out of this arbitration agreement by
              sending written notice within 30 days of first accepting these Terms (or of any future
              modification to this section) to{' '}
              <a href="mailto:hey@bricklabor.com" className="text-brand-accent underline-hover">
                hey@bricklabor.com
              </a>{' '}
              with the subject <code>ARBITRATION OPT-OUT</code> and your full name, email, and phone
              number on the account. Opting out does not affect any other part of these Terms.
            </p>
          </section>

          <section id="law">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">16. Governing law</h2>
            <p>
              These Terms are governed by the laws of the State of New Jersey, without regard to its
              conflict-of-laws principles. To the extent any claim is not subject to arbitration
              under Section 15, the exclusive venue is the state and federal courts located in Essex
              County, New Jersey, and you consent to personal jurisdiction there.
            </p>
          </section>

          <section id="changes">
            <h2 className="mt-12 mb-4 text-2xl font-extrabold text-brand-ink">
              17. Changes to these terms
            </h2>
            <p>
              BCL may update these Terms from time to time. For non-material changes (formatting,
              link updates, clarifications) we will update the "Last updated" date at the top of
              this page. For <strong>material changes</strong> (pricing model, refund policy,
              dispute resolution, SMS practices, liability), we will provide at least{' '}
              <strong>30 days' notice</strong> by email to the address on your account and by an
              in-app banner the next time you sign in. Continued use of the service after the
              effective date of a material change constitutes acceptance of the revised Terms.
            </p>
            <p className="mt-3">
              If you do not agree to a material change, stop using the service, request deletion of
              your account per the{' '}
              <a href="/privacy" className="text-brand-accent underline-hover">
                Privacy Policy
              </a>
              , and request refund of any unused deposit.
            </p>
          </section>

          <section id="contact" className="border-t border-brand-line pt-8">
            <h2 className="mt-0 mb-4 text-2xl font-extrabold text-brand-ink">Contact</h2>
            <p>
              Brick Labor · Brian Zalewski (founder) · Newark, NJ ·{' '}
              <a href="mailto:hey@bricklabor.com" className="text-brand-accent underline-hover">
                hey@bricklabor.com
              </a>{' '}
              ·{' '}
              <a href={PHONE_TEL_HREF} className="text-brand-accent underline-hover">
                (855) 825-2267
              </a>
              .
            </p>
            <p className="mt-3 text-sm">
              See also:{' '}
              <a href="/privacy" className="text-brand-accent underline-hover">
                Privacy Policy
              </a>
              ,{' '}
              <a href="/sources" className="text-brand-accent underline-hover">
                how we cite our facts
              </a>
              , and the{' '}
              <a href="/#faq" className="text-brand-accent underline-hover">
                FAQ
              </a>
              .
            </p>
          </section>
        </div>
      </div>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'WebPage',
            '@id': 'https://bricklabor.com/terms',
            url: 'https://bricklabor.com/terms',
            name: TITLE,
            description: DESC,
            dateModified: LAST_UPDATED,
            isPartOf: { '@id': 'https://bricklabor.com/#website' },
          }),
        }}
      />
    </article>
  );
}

function setMeta(name: string, content: string, attr: 'name' | 'property' = 'name') {
  let el = document.querySelector<HTMLMetaElement>(`meta[${attr}="${name}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function setLink(rel: string, href: string) {
  let el = document.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', rel);
    document.head.appendChild(el);
  }
  el.setAttribute('href', href);
}
