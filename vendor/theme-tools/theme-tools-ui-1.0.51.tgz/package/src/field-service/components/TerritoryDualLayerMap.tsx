import { useThemeToolsSurface } from '../../field-service-primitives.js';
import {
  NEWARK_HUB_ORIGIN,
  TERRITORY_07054_100MI_BREAKDOWN,
  ZIP_07054_ORIGIN,
  type WikipediaTownHeritage,
} from '@theme.tools/seo-geo/field-service/matrix-3d-engine';

export interface TerritoryDualLayerMapProps {
  readonly town: WikipediaTownHeritage;
  readonly workTypeName?: string;
  readonly modifierTitle?: string;
  readonly bookingUrl?: string;
}

/**
 * Dual-Layer Styled Service-Region Map (`@theme.tools/ui/field-service/components/TerritoryDualLayerMap`).
 *
 * Renders two explicitly labeled, color-differentiated geographic regions on every
 * geography-backed landing page:
 *   1. Lighter Gray Outer Shaded Region (`data-testid="outer-service-region-layer"`):
 *      "All of New Jersey (564 Municipalities) + Within 100 Miles of 07054 Parsippany-Troy Hills
 *       (1,450 Municipalities Across NJ, NY, PA, CT & DE)"
 *   2. Transparent Brand-Orange Shaded Region (`data-testid="target-geography-shaded-region"`):
 *      Highlighted polygon, coordinates, and radial vector for the active target municipality
 *      and county, with $0 travel fee verification and direct CTA to `https://bricklabor.com/book`.
 */
export function TerritoryDualLayerMap({
  town,
  workTypeName = 'Moving & Property Labor',
  modifierTitle = 'Hourly Crew Dispatch',
  bookingUrl = 'https://bricklabor.com/book',
}: TerritoryDualLayerMapProps) {
  useThemeToolsSurface('territory-dual-layer-map');

  // Project lat/lng around 07054 (40.8579, -74.4259) onto the 640x400 SVG canvas
  const centerX = 310;
  const centerY = 195;
  const dx = (town.lng - ZIP_07054_ORIGIN.lng) * 135;
  const dy = (ZIP_07054_ORIGIN.lat - town.lat) * 165;
  const targetX = Math.max(95, Math.min(545, Math.round(centerX + dx)));
  const targetY = Math.max(70, Math.min(325, Math.round(centerY + dy)));

  const newarkX = Math.round(centerX + (NEWARK_HUB_ORIGIN.lng - ZIP_07054_ORIGIN.lng) * 135);
  const newarkY = Math.round(centerY + (ZIP_07054_ORIGIN.lat - NEWARK_HUB_ORIGIN.lat) * 165);

  return (
    <section
      data-testid="territory-dual-layer-map"
      aria-label={`Service Area Map for ${town.townName}, ${town.state} and New Jersey`}
      className="tt-card mb-10 rounded-2xl border border-brand-line bg-bg-elevated p-6 sm:p-8"
    >
      <div className="flex flex-wrap items-start justify-between gap-4 mb-6">
        <div>
          <p className="font-mono text-xs uppercase tracking-[0.18em] text-brand-accent mb-1">
            LOCAL SERVICE AREA · $0 TRAVEL FEE IN {town.townName.toUpperCase()}
          </p>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-brand-ink">
            {town.townName}, {town.state} &amp; New Jersey Service Area Map
          </h2>
          <p className="mt-1 text-sm text-brand-mute max-w-3xl">
            Our crew is based right in Newark and serves every neighborhood in <strong className="text-brand-ink">{town.townName}</strong> ({town.county} County, ZIPs {town.primaryZipCodes.join(', ')}) plus <strong className="text-brand-ink">all of New Jersey and surrounding towns within 100 miles</strong> at a flat $50/hr per worker with $0 travel fee.
          </p>
        </div>
        <a
          href={bookingUrl}
          data-testid="map-book-cta"
          className="tt-btn tt-btn--primary inline-flex items-center justify-center rounded-xl bg-brand-accent px-5 py-3 font-mono text-xs font-extrabold uppercase tracking-wider text-bg-primary hover:opacity-90 transition-opacity"
        >
          Book {town.townName} Crew ($0 Travel Fee) →
        </a>
      </div>

      <div className="grid gap-6 lg:grid-cols-12 lg:items-center">
        {/* Clean Dual-Layer Service Area Map */}
        <div className="lg:col-span-7 rounded-2xl border border-brand-line bg-[#060810] p-4">
          <svg
            viewBox="0 0 640 360"
            className="w-full h-auto rounded-xl"
            role="img"
            aria-label={`Service area map showing ${town.townName}, ${town.state} highlighted in orange inside our New Jersey and 100-mile regional coverage area`}
          >
            <defs>
              <radialGradient id="outerRegionGrad" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#9ca3af" stopOpacity="0.18" />
                <stop offset="100%" stopColor="#6b7280" stopOpacity="0.10" />
              </radialGradient>
              <radialGradient id="targetZoneGrad" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#ff6b1a" stopOpacity="0.40" />
                <stop offset="100%" stopColor="#ff6b1a" stopOpacity="0.16" />
              </radialGradient>
            </defs>

            {/* LAYER 1: Lighter Gray Shaded Region for Entire Service Region (All of NJ + 100-Mile Radius) */}
            <g data-testid="outer-service-region-layer">
              <circle
                cx={centerX}
                cy={centerY - 15}
                r="140"
                fill="url(#outerRegionGrad)"
                stroke="#9ca3af"
                strokeOpacity="0.45"
                strokeWidth="1.5"
                strokeDasharray="6 4"
              />
              <polygon
                points="265,95 355,95 385,205 340,335 275,325 250,225"
                fill="#9ca3af"
                fillOpacity="0.14"
                stroke="#9ca3af"
                strokeOpacity="0.4"
                strokeWidth="1.5"
              />
              <rect
                x="20"
                y="14"
                width="600"
                height="28"
                rx="8"
                fill="#111827"
                fillOpacity="0.92"
                stroke="#6b7280"
                strokeOpacity="0.5"
              />
              <text
                x="34"
                y="32"
                fill="#d1d5db"
                fontFamily="system-ui, -apple-system, sans-serif"
                fontSize="12"
                fontWeight="600"
              >
                Outer Gray Area: All of New Jersey (564 Towns) + 100-Mile Service Area
              </text>
            </g>

            {/* LAYER 2: Transparent Shaded Target Region for Active Town */}
            <g data-testid="target-geography-shaded-region">
              <circle
                cx={targetX}
                cy={targetY - 15}
                r="34"
                fill="url(#targetZoneGrad)"
                stroke="#ff6b1a"
                strokeWidth="2"
              />
              <circle cx={targetX} cy={targetY - 15} r="7" fill="#ff6b1a" />
              <text
                x={targetX + 14}
                y={targetY - 10}
                fill="#ffffff"
                fontFamily="system-ui, -apple-system, sans-serif"
                fontSize="14"
                fontWeight="800"
              >
                {town.townName}, {town.state}
              </text>
              <rect
                x="20"
                y="312"
                width="600"
                height="34"
                rx="8"
                fill="#1c1008"
                fillOpacity="0.94"
                stroke="#ff6b1a"
                strokeWidth="1.5"
              />
              <text
                x="34"
                y="333"
                fill="#ff8a47"
                fontFamily="system-ui, -apple-system, sans-serif"
                fontSize="12.5"
                fontWeight="700"
              >
                {`Orange Highlight: ${town.townName}, ${town.state} (${town.county} County) · $50/hr Per Worker · $0 Travel Fee`}
              </text>
            </g>
          </svg>
        </div>

        {/* Clean Plain-English Coverage Summary */}
        <div className="lg:col-span-5 space-y-4">
          <div className="rounded-xl border border-brand-accent/50 bg-brand-accent/10 p-4">
            <div className="flex items-center gap-2.5">
              <span className="inline-block h-3.5 w-3.5 rounded-full bg-brand-accent" />
              <span className="font-mono text-xs font-bold uppercase tracking-wider text-brand-accent">
                Local Town Coverage ($0 Travel Fee)
              </span>
            </div>
            <p className="mt-1.5 text-base font-bold text-brand-ink">
              {town.townName}, {town.state} ({town.county} County)
            </p>
            <p className="mt-1 text-xs sm:text-sm text-brand-mute leading-relaxed">
              Covers ZIP codes {town.primaryZipCodes.join(', ')} and neighborhoods around {town.iconicLandmarks.slice(0, 3).join(', ')}. Same-week morning, afternoon, and evening slots available.
            </p>
          </div>

          <div className="rounded-xl border border-brand-line bg-bg-primary/70 p-4">
            <div className="flex items-center gap-2.5">
              <span className="inline-block h-3.5 w-3.5 rounded-full bg-gray-400/50 border border-gray-400" />
              <span className="font-mono text-xs font-bold uppercase tracking-wider text-gray-300">
                Full Regional Service Area
              </span>
            </div>
            <p className="mt-1.5 text-xs sm:text-sm text-brand-mute leading-relaxed">
              Have a second home, rental property, or family member elsewhere in New Jersey or the tri-state area? We cover all {TERRITORY_07054_100MI_BREAKDOWN[0]?.municipalityCount ?? 564} NJ towns plus surrounding NY, PA, CT, and DE communities at the exact same $50/hr per-worker rate.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
export default TerritoryDualLayerMap;
