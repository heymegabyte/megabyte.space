import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { testimonialsCopy } from '@theme.tools/i18n-a11y/field-service/testimonials-copy';

/**
 * Structural scenario data — locale-invariant. hrefs + the neighbor-city tag
 * stay constant across locales; the visitor-facing body, role persona, and
 * service-link label come from `testimonialsCopy(locale).quotes[key]`, zipped on
 * by stable slug. See `src/shared/testimonials-copy.mjs`.
 *
 * These are ILLUSTRATIVE, representative job scenarios — NOT collected customer
 * reviews. Brick Labor has no verified reviews yet, so this section carries NO
 * fabricated named author, NO star rating, and NO `Review`/`aggregateRating`
 * JSON-LD — that markup would be a Google review-snippet policy violation + FTC
 * fake-endorsement risk + a duplicate `#org` node. Real, verified ratings come
 * ONLY from the live Google integration in `Reviews.tsx`. The truth boundary is
 * locked by `scripts/validate-review-schema-truth.mjs`.
 */
interface QuoteStruct {
  /** Stable slug — the key into `testimonialsCopy(locale).quotes`. */
  readonly key: string;
  readonly serviceHref: string;
  readonly cityHref: string;
  readonly cityLabel: string;
}

const QUOTES: readonly QuoteStruct[] = [
  {
    key: 'reyes',
    serviceHref: '/services/power-washing',
    cityHref: '/c/newark',
    cityLabel: 'Newark',
  },
  {
    key: 'patel',
    serviceHref: '/services/lawn-care',
    cityHref: '/c/jersey-city',
    cityLabel: 'Jersey City',
  },
  {
    key: 'johnson',
    serviceHref: '/services/hauling',
    cityHref: '/c/newark',
    cityLabel: 'Newark',
  },
];

export function Testimonials() {
  useThemeToolsSurface('testimonials');
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  // Keep a mirror-locale visitor in /es · /pt: localize internal `/` hrefs;
  // leave mailto:/tel:/external + static-asset paths bare.
  const lp = (p: string) => (p.startsWith('/') ? localizedPath(locale, p) : p);
  const t = testimonialsCopy(locale);

  return (
    <section id="testimonials" aria-label={t.sectionAria} className="section bg-bg-elevated/30">
      <div className="container-pad">
        <div className="mb-12 max-w-2xl" data-animate="fade-up">
          <p className="eyebrow mb-3">{t.eyebrow}</p>
          <h2 className="text-4xl sm:text-5xl font-extrabold">
            {t.headlineMain}
            <span className="text-gradient">{t.headlineAccent}</span>
          </h2>
        </div>

        <ul className="grid md:grid-cols-3 gap-5" data-stagger="100">
          {QUOTES.map((q) => {
            const c = t.quotes[q.key] ?? testimonialsCopy('en').quotes[q.key]!;
            return (
              <li
                key={q.key}
                className="card flex flex-col gap-4 reveal-on-view"
                data-animate="fade-up"
              >
                <blockquote className="text-brand-ink leading-relaxed">"{c.body}"</blockquote>
                <footer className="mt-auto pt-3 border-t border-brand-line text-sm">
                  <div className="font-display font-semibold text-brand-mute">{c.role}</div>
                  <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1 text-[11px] font-mono">
                    <a href={lp(q.serviceHref)} className="text-brand-accent underline-hover">
                      {c.serviceLabel} →
                    </a>
                    <a href={lp(q.cityHref)} className="text-brand-accent underline-hover">
                      {q.cityLabel} →
                    </a>
                  </div>
                </footer>
              </li>
            );
          })}
        </ul>

        <p className="mt-6 text-xs text-brand-mute" data-animate="fade-in">
          {t.footnote}
        </p>

        <div
          className="mt-10 rounded-2xl border border-brand-line bg-bg-elevated/40 p-6 text-center max-w-3xl mx-auto"
          data-animate="fade-up"
        >
          <p className="text-sm text-brand-mute">
            {t.moreReviewsPre}
            <a
              href="https://www.google.com/search?q=Brick+Labor+Newark+NJ+reviews"
              target="_blank"
              rel="noopener"
              className="text-brand-accent underline-hover"
            >
              Google
            </a>
            {t.reviewsAnd}
            <a
              href="https://www.facebook.com/brickcitylabor"
              target="_blank"
              rel="noopener"
              className="text-brand-accent underline-hover"
            >
              Facebook
            </a>
            {t.nextNeighborQuestion}
            <a href={lp('/book')} className="text-brand-accent underline-hover font-bold">
              {t.bookCrew}
            </a>
          </p>
          <div className="mt-4 flex flex-wrap justify-center gap-3 text-xs">
            <a href={lp('/services/power-washing')} className="text-brand-accent underline-hover">
              {t.linkPowerWashing}
            </a>
            <a href={lp('/services/lawn-care')} className="text-brand-accent underline-hover">
              {t.linkLawnCare}
            </a>
            <a href={lp('/services/hauling')} className="text-brand-accent underline-hover">
              {t.linkHauling}
            </a>
            <a href={lp('/services/light-repairs')} className="text-brand-accent underline-hover">
              {t.linkLightRepairs}
            </a>
            <a href={lp('/blog')} className="text-brand-accent underline-hover">
              {t.linkBlog}
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
