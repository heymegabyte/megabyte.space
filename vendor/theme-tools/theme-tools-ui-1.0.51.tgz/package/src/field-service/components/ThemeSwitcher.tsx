import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useCallback, useEffect, useState } from 'react';
import { useRovingRadio } from '../use-roving-radio.js';

export type Theme = 'light' | 'dark' | 'auto';

const STORAGE_KEY = 'bcl_theme';

/**
 * Apply the chosen theme to `<html>` by setting `data-theme` + the inline
 * `color-scheme` style. For `auto`, follow the OS `prefers-color-scheme`.
 *
 * NOTE: this project's CSS variables are currently dark-only. The toggle
 * sets the attribute so the plumbing is in place; the light-mode `:root[data-theme='light']`
 * variable overrides land in a subsequent design pass. Until then, the
 * toggle is effectively a no-op visually but ready to switch instantly the
 * moment the light tokens ship.
 */
function applyTheme(theme: Theme): void {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;
  const resolved: 'light' | 'dark' =
    theme === 'auto'
      ? window.matchMedia('(prefers-color-scheme: dark)').matches
        ? 'dark'
        : 'light'
      : theme;
  root.setAttribute('data-theme', resolved);
  root.style.colorScheme = resolved;
}

function readStored(): Theme {
  if (typeof window === 'undefined') return 'dark';
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (raw === 'light' || raw === 'dark' || raw === 'auto') return raw;
  } catch {
    /* noop */
  }
  return 'dark';
}

const ICONS: Record<Theme, JSX.Element> = {
  light: (
    <svg
      viewBox="0 0 24 24"
      width="14"
      height="14"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <circle cx="12" cy="12" r="4" />
      <path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41" />
    </svg>
  ),
  dark: (
    <svg
      viewBox="0 0 24 24"
      width="14"
      height="14"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79Z" />
    </svg>
  ),
  auto: (
    <svg
      viewBox="0 0 24 24"
      width="14"
      height="14"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <circle cx="12" cy="12" r="9" />
      <path d="M12 3v18M3 12h18" />
    </svg>
  ),
};

const LABELS: Record<Theme, string> = { light: 'Light', dark: 'Dark', auto: 'Auto' };

/**
 * Three-option theme switcher (Light / Dark / Auto). Persists the choice to
 * `localStorage[bcl_theme]` and writes `data-theme` + `color-scheme` to
 * `<html>`. In `auto` mode it listens to `matchMedia` and re-applies on OS
 * theme change.
 *
 * @example
 *   <ThemeSwitcher />
 */
export function ThemeSwitcher(): JSX.Element {
  useThemeToolsSurface('theme-switcher');
  const [theme, setTheme] = useState<Theme>(() => readStored());

  // Apply on mount + whenever the user picks a new option.
  useEffect(() => {
    applyTheme(theme);
    try {
      window.localStorage.setItem(STORAGE_KEY, theme);
    } catch {
      /* noop */
    }
  }, [theme]);

  // In auto mode, re-apply when the OS preference changes.
  useEffect(() => {
    if (theme !== 'auto' || typeof window === 'undefined') return;
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const onChange = (): void => applyTheme('auto');
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, [theme]);

  const pick = useCallback((t: Theme) => () => setTheme(t), []);
  // ARIA roving-tabindex: single tab stop + arrow/Home/End move selection (axe-blind).
  const themeRadio = useRovingRadio(3, (i) => setTheme((['light', 'dark', 'auto'] as const)[i]!));

  return (
    <div
      role="radiogroup"
      aria-label="Color theme"
      className="inline-flex items-center gap-0.5 rounded-lg border border-brand-line bg-bg-elevated p-0.5"
    >
      {(['light', 'dark', 'auto'] as const).map((t, i) => {
        const active = theme === t;
        return (
          <button
            key={t}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={pick(t)}
            {...themeRadio(i, active)}
            title={LABELS[t]}
            className={`inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-xs transition-colors ${active ? 'bg-brand-accent/15 text-brand-accent' : 'text-brand-mute hover:text-brand-ink'}`}
          >
            {ICONS[t]}
            <span>{LABELS[t]}</span>
          </button>
        );
      })}
    </div>
  );
}
