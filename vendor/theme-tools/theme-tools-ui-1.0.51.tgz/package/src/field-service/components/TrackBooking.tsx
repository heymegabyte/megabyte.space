import { useEffect, useRef, useState } from 'react';
import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { evaluateCrewArrivalVerification } from '@theme.tools/forms/field-service-checklists';
import {
  humanizeStatus,
  statusAnnouncement,
  statusDescription,
  type StatusLocale,
} from '@theme.tools/scheduling/field-service/booking-status';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { normalizeToBookingTile } from '@theme.tools/seo-geo/field-service/service-slug-aliases';
import { arrivalWindow } from '@theme.tools/scheduling/field-service/arrival-window';
import { trackCopy, type TrackCopy } from '@theme.tools/i18n-a11y/field-service/track-copy';
import { trackFreshnessLabel } from '@theme.tools/scheduling/field-service/track-freshness';
import {
  trackErrorBannerVisible,
  reviewWindowRemainingFraction,
  confirmAnnounceMessage,
} from '@theme.tools/scheduling/field-service/track-ui';
import { subscribeTrackEvents } from '@theme.tools/scheduling/field-service/track-live';
import { usd2 } from '@theme.tools/billing/field-service/money';
import { buildRebookHref } from '@theme.tools/crm/field-service/rebook-prefill';
import { CalendarExportButton } from './customer/CalendarExportButton.js';
import { TipJar } from './customer/TipJar.js';
import { LiveEtaTracker } from './LiveEtaTracker.js';
import { LiveCrewTrackMap, type TrackLiveMap } from './LiveCrewTrackMap.js';
import { LiveCrewMapPage } from './LiveCrewMapPage.js';
import AddonShopModal from './wave29/AddonShopModal.js';
import { PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';
import { liveEtaDropoff } from '../live-eta-dropoff.js';
import { useFeatureFlag } from '../use-feature-flag.js';
import { SosButton } from './SosButton.js';
import { PredictiveEtaBadge } from './PredictiveEtaBadge.js';
import { CancelByTextPrompt } from './CancelByTextPrompt.js';
import { ArrivalPrepChecklist } from './booking/ArrivalPrepChecklist.js';

// Public-facing booking status page rendered at /track/<id>?t=<cancel_token>
// (and its /es/track + /pt/track locale mirrors — App.tsx strips the prefix and
// sets <html lang>). Polls GET /api/track/:id and GET /api/ontheway/:id every
// 30s while the booking is in a transient state (pending_payment, confirmed,
// en_route). Falls back to a polite "needs link" view when the t= token is
// missing. All visitor copy is localized via `trackCopy(locale)`; the status
// badge + description come from `booking-status.ts` with the same locale.

interface CrewMember {
  workerId: string;
  firstName: string;
  lastInitial: string;
  avatarUrl: string | null;
  ratingAvg: number | null;
  ratingCount: number | null;
  isLead: boolean;
  claimStatus: string;
  checkedInAt: string | null;
  // Wave 2B — crew identity is revealed at confirmation, not day-of.
  priorJobCount?: number | null;
  bio?: string | null;
  role?: 'driver' | 'lead' | 'crew' | null;
}

interface DispatchStage {
  kind: string;
  at: string;
  actorFirstName?: string;
  detail?: string;
}

interface TrackPayload {
  id: string;
  status: string;
  customerFirstName: string;
  preferredDate: string;
  preferredTime: string;
  hours: number;
  crewCount?: number;
  totalCents: number;
  services: string[];
  city: string;
  timeline: {
    scheduledAt: string | null;
    paidAt: string | null;
    paidInFullAt: string | null;
    completedAt: string | null;
    canceledAt: string | null;
  };
  crew?: CrewMember[];
  dispatchStage?: DispatchStage | null;
  gigId?: string | null;
  finalCharge?: FinalCharge | null;
  liveMap?: TrackLiveMap | null;
  // SCAN-57: refund recorded on cancellation (cents), drives the canceled+refund
  // badge on this page. null/absent when not canceled or no refund was owed.
  refundCents?: number | null;
}

interface FinalCharge {
  status: 'paid_in_full' | 'awaiting_completion' | 'in_review' | 'disputed' | 'finalized';
  balanceCents: number;
  due: boolean;
  customerConfirmed?: boolean;
  reviewWindow: { closesAt: string | null; secondsRemaining: number } | null;
  disputed?: boolean;
  reviewWindowHours?: number;
  closeOutEnabled?: boolean;
}

interface EtaPayload {
  id: string;
  status: string;
  customerFirstName: string;
  enRoute: boolean;
  completed: boolean;
}

interface Props {
  id: string;
}

const POLL_MS = 30_000;
const PUSH_POLL_MIN_MS = 5_000;
const TERMINAL = new Set(['completed', 'canceled']);
// fire-102: SVG circumference for the /track review-window progress ring (r=15.5 in a 36 viewBox).
const REVIEW_RING_CIRCUMFERENCE = 2 * Math.PI * 15.5;

type ResendState = 'idle' | 'sending' | 'sent' | 'failed';

function currentLocale(): StatusLocale {
  if (typeof window === 'undefined') return 'en';
  return stripLocalePrefix(window.location.pathname).locale as StatusLocale;
}

export function TrackBooking({ id }: Props) {
  const locale = currentLocale();
  const t = trackCopy(locale);

  // Uber-grade live tracking surface. When the `live_crew_map` flag resolves on
  // (off by default in prod — this is the rollback-safe static page), the whole
  // /track/<id> view is replaced by the full-screen live map. LiveCrewMapPage
  // fetches its own snapshot from /api/live-crew-map/<id> (no cancel token
  // required), so it works from a deep link the way Uber's tracking link does.
  const liveCrewMapOn = useFeatureFlag('live_crew_map');
  const arrivalPrepOn = useFeatureFlag('arrival_prep_checklist');

  const [token, setToken] = useState<string>('');
  const [booking, setBooking] = useState<TrackPayload | null>(null);
  const [eta, setEta] = useState<EtaPayload | null>(null);
  const [error, setError] = useState<string>('');
  // fire-122: sr-only success announcement after the customer confirms job completion. Set on
  // confirm success (the card otherwise swaps silently — only the FAILURE had role="alert").
  const [confirmAnnounce, setConfirmAnnounce] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [resendState, setResendState] = useState<ResendState>('idle');
  const [resendError, setResendError] = useState<string>('');
  // When the live snapshot last refreshed (epoch ms) + a coarse clock tick so the
  // "Updated Xs ago" freshness label stays current between 30s polls. 0 = never
  // loaded yet (suppresses the indicator until the first successful fetch).
  const [lastUpdatedAt, setLastUpdatedAt] = useState<number>(0);
  const [nowTick, setNowTick] = useState<number>(() => Date.now());
  // SCAN-15: live-connection health for the tracking page. `online` mirrors
  // navigator.onLine (+ the window online/offline events); `pollFailed` flips true
  // when a snapshot poll throws (device lost signal / server unreachable) and back
  // to false on the next success. While the booking is still-polling, EITHER being
  // offline OR a failed poll swaps the green "Live · Updated Xs ago" pill for a
  // "Reconnecting…" cue, so a paying customer never watches a silently-frozen clock.
  const [online, setOnline] = useState<boolean>(() =>
    typeof navigator === 'undefined' ? true : navigator.onLine,
  );
  const [pollFailed, setPollFailed] = useState<boolean>(false);

  // Screen-reader announcement for status TRANSITIONS only (WCAG 2.2 SC 4.1.3).
  // Empty until the booking's status (or the en_route dispatch flag) actually
  // changes, so the live region stays silent on the initial page read (the
  // visible badge covers that) and announces exactly once per real transition.
  const [announcement, setAnnouncement] = useState<string>('');
  const prevStatusKeyRef = useRef<string | null>(null);

  // Holds the freshest snapshot-refetch so the live SSE effect can trigger an
  // immediate poll without owning the poll closure's deps.
  const pollRef = useRef<(force?: boolean) => void>(() => {});
  const pollInFlightRef = useRef(false);
  const lastPollStartedAtRef = useRef(0);
  // A successful poll replaces the booking object. Effects must not depend on
  // that object or every response tears down/restarts polling + SSE, whose
  // `onopen` callback immediately polls again and forms a retry storm. Keep only
  // the terminal decision in a ref so stable connections remain stable.
  const bookingStatusRef = useRef<string | null>(null);
  bookingStatusRef.current = booking?.status ?? null;
  const isTerminalBooking = Boolean(booking && TERMINAL.has(booking.status));

  async function handleResend() {
    if (resendState === 'sending') return;
    setResendState('sending');
    setResendError('');
    try {
      const res = await fetch('/api/booking/resend-confirmation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, t: token }),
      });
      const data = (await res.json().catch(() => ({}))) as { ok?: boolean; error?: string };
      if (res.ok && data.ok) {
        setResendState('sent');
      } else {
        setResendState('failed');
        setResendError(
          data.error === 'not_found_or_unauthorized' ? t.resendErrNotFound : t.resendErrGeneric,
        );
      }
    } catch {
      setResendState('failed');
      setResendError(t.resendErrConn);
    }
  }

  useEffect(() => {
    document.title = t.metaTitle;
    setMeta('description', t.metaDesc);
    setMeta('robots', 'noindex,nofollow');
    setLink('canonical', `https://bricklabor.com/track/${id}`);
  }, [id, t]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const fromQuery = params.get('t') || '';
    const fromHash = window.location.hash.startsWith('#t=') ? window.location.hash.slice(3) : '';
    setToken(fromQuery || fromHash);
  }, []);

  useEffect(() => {
    if (!token) {
      setLoading(false);
      return undefined;
    }
    let stopped = false;

    const poll = async (force = false) => {
      const now = Date.now();
      if (pollInFlightRef.current) return;
      if (!force && now - lastPollStartedAtRef.current < PUSH_POLL_MIN_MS) return;
      pollInFlightRef.current = true;
      lastPollStartedAtRef.current = now;
      try {
        const [trackRes, etaRes] = await Promise.all([
          fetch(`/api/track/${id}?t=${encodeURIComponent(token)}`, {
            headers: { Accept: 'application/json' },
          }),
          fetch(`/api/ontheway/${id}?t=${encodeURIComponent(token)}`, {
            headers: { Accept: 'application/json' },
          }),
        ]);
        if (stopped) return;

        // /api/track + /api/ontheway return 200 {ok:false, reason} (not 4xx)
        // for a missing booking or an expired/bad token, so an invalid email
        // link never logs a "Failed to load resource" console error. Read the
        // body's `reason` for the right copy instead of the HTTP status.
        const trackJson = (await trackRes.json().catch(() => ({}))) as {
          ok?: boolean;
          booking?: TrackPayload;
          reason?: string;
        };
        if (trackJson.ok && trackJson.booking) {
          bookingStatusRef.current = trackJson.booking.status;
          setBooking(trackJson.booking);
          setError('');
          setPollFailed(false); // SCAN-15: a good snapshot clears the reconnecting cue.
          setLastUpdatedAt(Date.now());
          setNowTick(Date.now());
        } else if (!trackJson.ok) {
          setError(t.errInvalidLink);
          setLoading(false);
          return;
        }

        if (etaRes.ok) {
          const etaJson = (await etaRes.json()) as { ok?: boolean; booking?: EtaPayload };
          if (etaJson.ok && etaJson.booking) setEta(etaJson.booking);
        }
      } catch {
        // SCAN-15: a thrown poll = the live connection is down (lost signal /
        // server unreachable). Flag it so the live pill becomes a "Reconnecting…"
        // cue. We keep the existing `booking` rendered (last-known snapshot) rather
        // than blanking the page — the cue tells the customer it's stale-but-trying.
        if (!stopped) {
          setPollFailed(true);
          setError(t.errConn);
        }
      } finally {
        pollInFlightRef.current = false;
        if (!stopped) setLoading(false);
      }
    };

    pollRef.current = (force = false) => {
      if (stopped) return;
      const status = bookingStatusRef.current;
      if (status && TERMINAL.has(status)) return;
      void poll(force);
    };

    void poll(true);
    const handle = window.setInterval(() => {
      const status = bookingStatusRef.current;
      if (status && TERMINAL.has(status)) return;
      void poll(true);
    }, POLL_MS);

    return () => {
      stopped = true;
      pollRef.current = () => {};
      window.clearInterval(handle);
    };
  }, [id, token, t]);

  // Live dispatch push — subscribe to the worker's SSE stream and re-poll the
  // snapshot the instant a crew transition lands, so the post-pay customer sees
  // "on the way" the moment it happens instead of waiting out the poll interval.
  // The interval poll above stays as the fallback heartbeat. No-op without a
  // token (anonymous links can't open the token-gated stream), and we stop once
  // the booking reaches a terminal state — nothing left to push.
  useEffect(() => {
    if (!token) return undefined;
    if (isTerminalBooking) return undefined;
    return subscribeTrackEvents({ id, token, onChange: () => pollRef.current() });
  }, [id, token, isTerminalBooking]);

  // Announce a status transition to assistive tech the instant it lands. The
  // key folds the status + the live en_route dispatch flag so a flag-only flip
  // (SMS fires before the row commits) still announces. First observed value
  // seeds the ref WITHOUT announcing — the initial page read already conveys it.
  useEffect(() => {
    if (!booking) return;
    const enRoute = eta?.enRoute || false;
    const key = `${booking.status}|${enRoute ? '1' : '0'}`;
    if (prevStatusKeyRef.current === null) {
      prevStatusKeyRef.current = key;
      return;
    }
    if (prevStatusKeyRef.current !== key) {
      prevStatusKeyRef.current = key;
      setAnnouncement(statusAnnouncement(booking.status, enRoute, locale));
    }
  }, [booking, eta?.enRoute, locale]);

  // Keep the "Updated Xs ago" freshness label honest between the 30s polls — a
  // 15s coarse tick re-renders the relative-time without touching the network.
  // Only runs while the booking is in a transient (still-polling) state; once
  // terminal there's nothing left to refresh, so the timer is torn down.
  const isLiveTracking = !!booking && !TERMINAL.has(booking.status);
  useEffect(() => {
    if (!isLiveTracking) return undefined;
    const handle = window.setInterval(() => setNowTick(Date.now()), 15_000);
    return () => window.clearInterval(handle);
  }, [isLiveTracking]);

  // SCAN-15: track the browser's online/offline state so the live pill can flip to
  // a "Reconnecting…" cue the instant the device drops signal — the exact
  // phone-loses-signal-mid-job case. Recycles the proven navigator.onLine idiom
  // from InstallBanner.OfflineIndicator (extend-don't-duplicate). On reconnect we
  // immediately fire one snapshot poll so the freshness pill returns without waiting
  // out the 30s interval; `pollRef` guards terminal/stopped internally.
  useEffect(() => {
    if (typeof window === 'undefined') return undefined;
    setOnline(window.navigator.onLine);
    const goOnline = () => {
      setOnline(true);
      pollRef.current(true);
    };
    const goOffline = () => setOnline(false);
    window.addEventListener('online', goOnline);
    window.addEventListener('offline', goOffline);
    return () => {
      window.removeEventListener('online', goOnline);
      window.removeEventListener('offline', goOffline);
    };
  }, []);

  // Flag-on → render the live crew map IN PLACE of the static tracking page —
  // but ONLY for an actually-live ride (crew dispatched: en_route / in_progress,
  // or the ontheway eta says enRoute). An UPCOMING booking has NO ride_state, so
  // `/api/live-crew-map/:id` 404s → LiveCrewMapPage renders "Ride not found" for a
  // perfectly valid upcoming booking — the exact surface the confirmation + 24h
  // reminder deep-link at. Falling through to the static summary branch below
  // shows the booking (summary + Timeline + arrival-prep checklist + payment card),
  // the correct pre-dispatch view. (Before this gate, live_crew_map=ON replaced
  // ALL /track with the map, breaking every pre-dispatch /track AND darkening the
  // arrival-prep checklist mounted in the summary branch.) Err toward the summary
  // (always valid) over the map (404s pre-dispatch). Placed after every hook above
  // so React's hook order stays stable across renders.
  const trackSurfaceProps = useThemeToolsSurface('track-booking', [
    '@theme.tools/ui',
    '@theme.tools/forms',
    '@theme.tools/scheduling',
  ]);
  const arrivalVerificationGate = evaluateCrewArrivalVerification({
    distanceFromJobSiteFeet: 120,
    uploadedPhotos: [],
  });
  const isLiveRide =
    !!eta?.enRoute || booking?.status === 'en_route' || booking?.status === 'in_progress';
  if (liveCrewMapOn && isLiveRide) {
    return <LiveCrewMapPage rideId={id} token={token} />;
  }

  return (
    <article
      className="section"
      data-theme-tools-surface={trackSurfaceProps['data-theme-tools-surface']}
      data-theme-tools-pricing-model={trackSurfaceProps['data-theme-tools-pricing-model']}
      data-geofence-max-feet={arrivalVerificationGate.maxAllowedGeofenceFeet}
    >
      {/* Floating SOS safety button — flag-gated (sos_button, default off →
          renders null). On the live-track page a customer with an active job
          can two-tap panic/medical/unsafe → POST /api/sos (operator SMS +
          best-effort geolocation). Fed the booking id so operators can route. */}
      <SosButton gigId={id} userKind="customer" />
      <div className="container-pad max-w-2xl">
        <p className="eyebrow mb-3">{t.eyebrow}</p>
        <h1 className="text-4xl sm:text-5xl font-extrabold mb-2">{t.h1}</h1>
        <p className="text-brand-mute mb-8">
          {t.bookingIdLabel} <code className="text-brand-ink">{id}</code>
        </p>

        {!token && !loading && (
          <div
            className="rounded-2xl border border-brand-line bg-brand-card p-8 sm:p-10"
            data-testid="track-empty-state"
          >
            <p className="font-mono text-[11px] font-bold uppercase tracking-[0.18em] text-brand-accent">
              {t.secureLinkNeeded}
            </p>
            <h2 className="mt-3 text-3xl font-extrabold text-brand-ink">{t.openFromEmail}</h2>
            <p className="mt-3 text-brand-mute leading-relaxed">{t.emptyBody}</p>

            <div className="mt-6 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={handleResend}
                disabled={resendState === 'sending' || resendState === 'sent'}
                className="inline-flex items-center justify-center gap-2 rounded-md border border-brand-accent bg-brand-accent px-5 py-3 font-mono text-[12px] font-bold uppercase tracking-wider text-bg-primary hover:bg-brand-accent/90 transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
                data-testid="track-resend-confirmation"
              >
                {resendState === 'sending'
                  ? t.resendSending
                  : resendState === 'sent'
                    ? t.resendSent
                    : t.resendCta}
              </button>
              <a
                href="/book"
                className="inline-flex items-center justify-center gap-2 rounded-md border border-brand-line px-5 py-3 font-mono text-[12px] font-bold uppercase tracking-wider text-brand-ink hover:border-brand-accent hover:text-brand-accent transition-colors"
              >
                {t.bookAnother}
              </a>
            </div>

            {resendState === 'failed' && (
              <p className="mt-4 rounded-md border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-200">
                {resendError}
              </p>
            )}
            {resendState === 'sent' && (
              <p className="mt-4 rounded-md border border-emerald-500/40 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-200">
                {t.resentSuccess}
              </p>
            )}

            <p className="mt-6 text-sm text-brand-mute">
              {t.preferHuman}{' '}
              <a href={PHONE_TEL_HREF} className="text-brand-accent underline-hover">
                (855) 82LABOR
              </a>{' '}
              ·{' '}
              <a href="mailto:hey@bricklabor.com" className="text-brand-accent underline-hover">
                hey@bricklabor.com
              </a>
            </p>
          </div>
        )}

        {loading && token && <p className="text-brand-mute">{t.loadingStatus}</p>}

        {/* fire-93: suppress the hard error banner once a booking is on screen — a transient poll
            blip is carried by the "Reconnecting…" live pill, not an alarming red box. */}
        {trackErrorBannerVisible(!!error, !!booking) && (
          <div className="rounded-lg border border-red-500/40 bg-red-500/10 p-4 text-red-200">
            {error}
          </div>
        )}

        {booking && (
          <div className="space-y-6">
            <div className="space-y-2">
              {/* Visually-hidden live region — announces status TRANSITIONS to
                  assistive tech (WCAG 2.2 SC 4.1.3). Excludes the freshness tick
                  so a screen reader hears the status change, not the 15s clock. */}
              <p
                className="sr-only"
                role="status"
                aria-live="polite"
                data-testid="track-status-announce"
              >
                {announcement}
              </p>
              {/* fire-122: confirm-complete success announce. Always-mounted (empty until the
                  customer confirms) so the aria-live region PRE-EXISTS and reliably announces the
                  content change — the FinalCharge card early-returns per status, so an in-card live
                  region would mount-with-content and not announce on some screen readers. */}
              <p
                className="sr-only"
                role="status"
                aria-live="polite"
                data-testid="track-confirm-announce"
              >
                {confirmAnnounce}
              </p>
              <StatusBadge
                status={booking.status}
                enRoute={eta?.enRoute || false}
                locale={locale}
              />
              {statusDescription(booking.status, locale) && (
                <p className="text-sm text-brand-mute leading-snug max-w-prose">
                  {statusDescription(booking.status, locale)}
                </p>
              )}
              {/* SCAN-15: while the booking is live-tracking, show the green
                  "Live · Updated Xs ago" pill ONLY when the connection is healthy.
                  If the device is offline OR the last poll failed, swap in the
                  "Reconnecting…" cue instead of a silently-frozen freshness clock —
                  showing "Live" during an outage would be a lie. */}
              {isLiveTracking &&
                (online && !pollFailed ? (
                  lastUpdatedAt > 0 && (
                    <LiveFreshness
                      updatedAt={lastUpdatedAt}
                      now={Math.max(nowTick, lastUpdatedAt)}
                      t={t}
                    />
                  )
                ) : (
                  <TrackOfflineIndicator t={t} />
                ))}
              <PredictiveEtaBadge rideId={booking.id} locale={locale} />
            </div>

            {/* SCAN-57: a canceled booking is NOT a dead-end. Show a clear canceled +
                refund confirmation so a customer who canceled (owed money) sees exactly
                what's happening to their card — never the "no longer valid" error. The
                refund figure comes straight from the store (never fabricated); when no
                refund was recorded we show the reassuring no-refund line instead. */}
            {booking.status === 'canceled' && (
              <CanceledRefundCard refundCents={booking.refundCents ?? null} t={t} locale={locale} />
            )}

            <div className="rounded-lg border border-brand-line bg-brand-card p-6 space-y-3">
              <h2 className="text-xl font-extrabold text-brand-ink">
                {t.hey.replace('{name}', booking.customerFirstName)}
              </h2>
              <Row label={t.rowDate} value={formatDate(booking.preferredDate, t.dateLocale)} />
              <ArrivalRow time={booking.preferredTime} t={t} />
              <Row label={t.rowHours} value={`${booking.hours}h`} />
              <Row label={t.rowCity} value={booking.city || '—'} />
              <ServicePills services={booking.services} t={t} />
              <Row label={t.rowTotal} value={usd2(booking.totalCents)} />
            </div>

            <Timeline timeline={booking.timeline} status={booking.status} t={t} />

            {/* fire-78: the "get ready for your crew" prep checklist the 24h reminder promises at
                the /track deep-link. Service-aware, client-only (localStorage), flag-gated. Shown only
                while the job is still AHEAD. Gate = !TERMINAL (hides completed/canceled) AND !completedAt.
                The extra completedAt guard matters because `paid_in_full` is NOT in TERMINAL yet is set in
                TWO cases: (a) prepaid-in-full with the job still upcoming (no completedAt → SHOW — this
                customer needs prep most) and (b) paid in full at job-end (completedAt set → HIDE, the
                job's over). completedAt is the codebase's own "job done" signal (track.ts:144/488/624). */}
            {arrivalPrepOn && !TERMINAL.has(booking.status) && !booking.timeline.completedAt && (
              <ArrivalPrepChecklist
                bookingId={booking.id}
                services={booking.services}
                city={booking.city}
              />
            )}

            {booking.finalCharge && (
              <PaymentCard
                finalCharge={booking.finalCharge}
                t={t}
                id={id}
                token={token}
                onConfirmed={(fc) => {
                  setBooking((b) => (b ? { ...b, finalCharge: fc } : b));
                  // Announce the resulting state — mirrors the card's own title (WCAG 4.1.3).
                  setConfirmAnnounce(confirmAnnounceMessage(fc.status, t));
                }}
              />
            )}

            {booking.crew && booking.crew.length > 0 && (
              <CrewPanel
                crew={booking.crew}
                dispatchStage={booking.dispatchStage ?? null}
                bookingStatus={booking.status}
                t={t}
              />
            )}

            {booking.liveMap?.enabled && (
              <LiveCrewTrackMap liveMap={booking.liveMap} locale={locale} />
            )}

            {booking.gigId && (
              <LiveEtaTracker
                gigId={booking.gigId}
                locale={locale}
                dropoffLat={liveEtaDropoff(booking)?.lat}
                dropoffLng={liveEtaDropoff(booking)?.lng}
              />
            )}

            {(booking.status === 'confirmed' || booking.status === 'en_route') && (
              <CalendarExportButton bookingId={booking.id} />
            )}

            {(booking.status === 'confirmed' || booking.status === 'en_route') && (
              <AddonShopModal bookingId={booking.id} />
            )}

            {(booking.status === 'completed' || booking.status === 'paid_in_full') && (
              <TipJar
                bookingId={id}
                crewName={
                  booking.crew?.find((c) => c.isLead)?.firstName ?? booking.crew?.[0]?.firstName
                }
              />
            )}

            {(booking.status === 'completed' || booking.status === 'paid_in_full') && (
              <RebookCta booking={booking} t={t} locale={locale} />
            )}

            <div className="rounded-lg border border-brand-line bg-brand-card p-6 space-y-3">
              <p className="text-brand-mute text-sm">
                {t.needChange}{' '}
                <a href={PHONE_TEL_HREF} className="text-brand-accent underline-hover">
                  {t.callCta}
                </a>{' '}
                {locale === 'en' ? 'or' : locale === 'es' ? 'o' : 'ou'}{' '}
                <a href="mailto:hey@bricklabor.com" className="text-brand-accent underline-hover">
                  {t.emailUs}
                </a>
                .
              </p>
              {!TERMINAL.has(booking.status) && (
                <p
                  data-bcl-cancel-policy
                  className="border-l-2 border-brand-accent/50 pl-3 text-brand-mute text-xs"
                >
                  {t.cancelPolicy}
                </p>
              )}
              {!TERMINAL.has(booking.status) && <CancelByTextPrompt bookingRef={booking.id} />}
              <p className="text-brand-mute text-xs">
                {t.whileYouWaitPre}
                <a
                  href={localizedPath(locale, '/blog')}
                  className="text-brand-accent underline-hover"
                >
                  {t.fieldNotesBlog}
                </a>
                {locale === 'en' ? ', peek at ' : locale === 'es' ? ', mira las ' : ', veja as '}
                <a
                  href={localizedPath(locale, '/#testimonials')}
                  className="text-brand-accent underline-hover"
                >
                  {t.pastReviews}
                </a>
                {locale === 'en' ? ', or check ' : locale === 'es' ? ', o revisa ' : ', ou veja '}
                <a
                  href={localizedPath(locale, '/#pricing')}
                  className="text-brand-accent underline-hover"
                >
                  {t.pricingMath}
                </a>
                . {t.alreadyHappy}{' '}
                <a
                  href={localizedPath(locale, '/book')}
                  className="text-brand-accent underline-hover"
                >
                  {t.bookAnotherSlot}
                </a>
              </p>
            </div>
          </div>
        )}
      </div>
    </article>
  );
}

// Live-freshness pill — a pulsing dot + localized "Live · Updated Xs ago" so a
// paying customer watching the page KNOWS it is auto-refreshing (the snapshot
// re-polls every 30s + on every SSE crew transition). Only mounts while the
// booking is in a transient, still-polling state. The radar ping is gated by
// `motion-reduce:animate-none`; the dot itself stays visible for reduced-motion
// users. The relative-time copy comes from the shared, unit-tested formatter so
// it can never drift or leak English on /es + /pt.
function LiveFreshness({ updatedAt, now, t }: { updatedAt: number; now: number; t: TrackCopy }) {
  return (
    <div
      data-testid="track-live-freshness"
      className="flex items-center gap-2 text-xs font-medium text-brand-mute"
      aria-live="polite"
    >
      <span className="relative flex h-2 w-2" aria-hidden="true">
        <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75 animate-ping motion-reduce:animate-none" />
        <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
      </span>
      <span className="text-emerald-300">{t.liveLabel}</span>
      <span aria-hidden="true">·</span>
      <span>{trackFreshnessLabel(Math.max(0, now - updatedAt), t)}</span>
    </div>
  );
}

// SCAN-15: offline/reconnecting cue — replaces the green "Live" freshness pill the
// moment the tracking connection drops (device offline OR a poll failed) so a
// paying customer watching /track never stares at a silently-frozen "Updated Xs
// ago". Brand ORANGE (not the healthy green) with an amber-style pulsing dot to
// read as "attention, but recovering". `role=status`+`aria-live=polite` announces
// the state change to assistive tech; the ping is gated by `motion-reduce`. All
// copy is localized (en/es/pt) via the shared, prerender-safe TRACK_COPY constant.
function TrackOfflineIndicator({ t }: { t: TrackCopy }) {
  return (
    <div
      data-testid="track-offline-indicator"
      role="status"
      aria-live="polite"
      className="flex items-start gap-2.5 rounded-lg border border-brand-accent/40 bg-brand-accent/10 px-3.5 py-2.5"
    >
      <span className="relative mt-0.5 flex h-2 w-2 shrink-0" aria-hidden="true">
        <span className="absolute inline-flex h-full w-full rounded-full bg-brand-accent opacity-75 animate-ping motion-reduce:animate-none" />
        <span className="relative inline-flex h-2 w-2 rounded-full bg-brand-accent" />
      </span>
      <div className="min-w-0">
        <p className="text-xs font-bold text-brand-accent">
          {t.offlineTitle} <span className="font-semibold">· {t.reconnectingLabel}</span>
        </p>
        <p className="mt-0.5 text-[11px] leading-snug text-brand-mute">{t.offlineHint}</p>
      </div>
    </div>
  );
}

// SCAN-57: canceled-booking confirmation card. A canceled tracking link used to
// read as a dead-end ("no longer valid"); on the money path that's alarming for a
// customer who just canceled + is owed a refund. This card states plainly that the
// booking is canceled and — when a refund was recorded — shows the REAL amount +
// when it lands, so there's zero ambiguity. Refund figure comes from the store
// (`refundCents`); a positive amount shows the refund line, otherwise the neutral
// no-refund reassurance. Brand ORANGE accent, locale-safe copy.
function CanceledRefundCard({
  refundCents,
  t,
  locale,
}: {
  refundCents: number | null;
  t: TrackCopy;
  locale: StatusLocale;
}) {
  const hasRefund = typeof refundCents === 'number' && refundCents > 0;
  return (
    <div
      data-testid="track-canceled-badge"
      role="status"
      className="rounded-lg border border-brand-accent/40 bg-brand-accent/10 p-5 sm:p-6"
    >
      <p className="font-mono text-[11px] font-bold uppercase tracking-[0.18em] text-brand-accent">
        {t.tlCanceled}
      </p>
      <h2 className="mt-2 text-2xl font-extrabold text-brand-ink">{t.canceledTitle}</h2>
      <p className="mt-2 text-sm leading-relaxed text-brand-mute">
        {hasRefund
          ? t.canceledRefundLine.replace('{amount}', usd2(refundCents))
          : t.canceledNoRefundLine}
      </p>
      <a
        href={localizedPath(locale, '/book')}
        className="mt-4 inline-flex items-center gap-2 font-mono text-[12px] font-bold uppercase tracking-wider text-brand-accent underline-hover"
      >
        {t.canceledRebook}
      </a>
    </div>
  );
}

function RebookCta({
  booking,
  t,
  locale,
}: {
  booking: TrackPayload;
  t: TrackCopy;
  locale: StatusLocale;
}) {
  const href = localizedPath(
    locale,
    buildRebookHref({
      service: booking.services[0],
      crew: booking.crewCount,
      hours: booking.hours,
    }),
  );
  const pills: string[] = [];
  if (booking.services[0]) pills.push(serviceLabel(booking.services[0], t));
  if (typeof booking.crewCount === 'number' && booking.crewCount > 0)
    pills.push(`${booking.crewCount}×`);
  if (booking.hours > 0) pills.push(`${booking.hours}h`);
  return (
    <div
      data-testid="track-rebook-cta"
      className="rounded-lg border border-brand-line bg-brand-card p-6 space-y-4 border-l-2 border-l-brand-accent"
    >
      <div className="flex flex-wrap items-baseline justify-between gap-3">
        <h2 className="text-xl font-extrabold text-brand-ink">{t.alreadyHappy}</h2>
        {pills.length > 0 && (
          <ul role="list" aria-label={t.rowServices} className="flex flex-wrap gap-1.5">
            {pills.map((p, i) => (
              <li
                key={p}
                style={{ animationDelay: `${i * 60}ms` }}
                className="rounded-full bg-brand-accent/10 border border-brand-accent/30 px-2.5 py-0.5 text-xs font-medium text-brand-accent transition-all duration-[333ms] hover:-translate-y-0.5 hover:bg-brand-accent/20 hover:shadow-sm"
              >
                {p}
              </li>
            ))}
          </ul>
        )}
      </div>
      <a
        href={href}
        data-bcl-rebook="track"
        className="inline-flex items-center justify-center gap-2 rounded-md border border-brand-accent bg-brand-accent px-5 py-3 font-mono text-[12px] font-bold uppercase tracking-wider text-bg-primary transition-all duration-[333ms] hover:-translate-y-0.5 hover:bg-brand-accent/90 hover:shadow-md"
      >
        {t.bookAnother}
      </a>
    </div>
  );
}

function StatusBadge({
  status,
  enRoute,
  locale,
}: {
  status: string;
  enRoute: boolean;
  locale: StatusLocale;
}) {
  const label = labelFor(status, enRoute, locale);
  const tone = toneFor(status);
  return (
    <div
      className={`inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold ${tone}`}
    >
      <span className="size-2 rounded-full bg-current" aria-hidden="true" />
      {label}
    </div>
  );
}

// Format a remaining-seconds countdown as a compact "Xh Ym" / "Ym" string.
function formatRemaining(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

// Post-job payment card: shows the balance owed + the server-selected review
// countdown before it finalizes. Driven by the shared money state machine via
// the worker's buildFinalChargeView (SPEC priority #3, customer-facing half).
function PaymentCard({
  finalCharge,
  t,
  id,
  token,
  onConfirmed,
}: {
  finalCharge: FinalCharge;
  t: TrackCopy;
  id: string;
  token: string;
  onConfirmed: (fc: FinalCharge) => void;
}) {
  const [confirming, setConfirming] = useState(false);
  const [confirmError, setConfirmError] = useState('');
  const [disputeOpen, setDisputeOpen] = useState(false);
  const [disputeReason, setDisputeReason] = useState('');
  const [disputing, setDisputing] = useState(false);
  const [disputeError, setDisputeError] = useState('');
  const [disputed, setDisputed] = useState(
    finalCharge.disputed || finalCharge.status === 'disputed',
  );

  useEffect(() => {
    setDisputed(finalCharge.disputed || finalCharge.status === 'disputed');
  }, [finalCharge.disputed, finalCharge.status]);

  async function confirmComplete() {
    if (confirming) return;
    setConfirming(true);
    setConfirmError('');
    try {
      const res = await fetch(`/api/track/${encodeURIComponent(id)}/confirm`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ t: token }),
      });
      const data = (await res.json().catch(() => ({}))) as {
        ok?: boolean;
        finalCharge?: FinalCharge;
      };
      if (data.ok && data.finalCharge) onConfirmed(data.finalCharge);
      else setConfirmError(t.payConfirmError);
    } catch {
      setConfirmError(t.payConfirmError);
    } finally {
      setConfirming(false);
    }
  }

  async function reportProblem() {
    if (disputing) return;
    setDisputing(true);
    setDisputeError('');
    try {
      const res = await fetch(`/api/track/${encodeURIComponent(id)}/dispute`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          t: token,
          ...(disputeReason.trim() ? { reason: disputeReason.trim() } : {}),
        }),
      });
      const data = (await res.json().catch(() => ({}))) as { ok?: boolean; disputed?: boolean };
      if (!res.ok || !data.ok || !data.disputed) throw new Error('dispute_failed');
      setDisputed(true);
      setDisputeOpen(false);
    } catch {
      setDisputeError(t.payDisputeError);
    } finally {
      setDisputing(false);
    }
  }

  if (finalCharge.status === 'paid_in_full') {
    return (
      <div className="rounded-lg border border-brand-line bg-brand-card p-6 space-y-1">
        <p className="text-brand-accent font-mono text-xs uppercase tracking-wider">
          {t.payEyebrow}
        </p>
        <p className="text-brand-ink font-semibold">{t.payPaidInFull}</p>
      </div>
    );
  }

  const title = disputed
    ? t.payDisputedTitle
    : finalCharge.status === 'awaiting_completion'
      ? t.payAwaitingTitle
      : finalCharge.status === 'in_review'
        ? t.payInReviewTitle
        : t.payFinalizedTitle;
  const body = disputed
    ? t.payDisputedBody
    : finalCharge.status === 'awaiting_completion'
      ? t.payAwaitingBody
      : finalCharge.status === 'in_review'
        ? t.payInReviewBody
        : t.payFinalizedBody;

  return (
    <div className="rounded-lg border border-brand-line bg-brand-card p-6 space-y-3 border-l-2 border-l-brand-accent">
      <p className="text-brand-accent font-mono text-xs uppercase tracking-wider">{t.payEyebrow}</p>
      <div className="flex items-baseline justify-between gap-4">
        <span className="text-brand-ink font-semibold">{title}</span>
        <span className="text-brand-ink font-semibold text-right tabular-nums">
          {usd2(finalCharge.balanceCents)}
        </span>
      </div>
      <p className="text-brand-mute text-sm">{body}</p>
      {finalCharge.reviewWindow && (
        <div className="flex items-center gap-2.5" data-testid="review-window">
          <svg
            viewBox="0 0 36 36"
            className="h-9 w-9 shrink-0 -rotate-90"
            aria-hidden="true"
            data-testid="review-window-ring"
          >
            <circle
              cx="18"
              cy="18"
              r="15.5"
              fill="none"
              stroke="currentColor"
              strokeWidth="3"
              className="text-brand-line"
            />
            <circle
              cx="18"
              cy="18"
              r="15.5"
              fill="none"
              stroke="currentColor"
              strokeWidth="3"
              strokeLinecap="round"
              className="text-brand-accent transition-[stroke-dashoffset] duration-[0.333s] motion-reduce:transition-none"
              strokeDasharray={REVIEW_RING_CIRCUMFERENCE}
              strokeDashoffset={
                REVIEW_RING_CIRCUMFERENCE *
                (1 -
                  reviewWindowRemainingFraction(
                    finalCharge.reviewWindow.secondsRemaining,
                    (finalCharge.reviewWindowHours ?? 24) * 3600,
                  ))
              }
            />
          </svg>
          <p className="text-brand-mute text-xs tabular-nums">
            {t.payClosesIn.replace(
              '{time}',
              formatRemaining(finalCharge.reviewWindow.secondsRemaining),
            )}
          </p>
        </div>
      )}
      {disputed && (
        <p
          role="status"
          className="rounded-md border border-amber-400/40 bg-amber-400/10 p-3 text-sm text-brand-ink"
        >
          {t.payDisputedStatus}
        </p>
      )}
      {finalCharge.status === 'in_review' && !finalCharge.customerConfirmed && !disputed && (
        <div data-bcl-confirm-complete className="pt-1 space-y-2">
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={confirmComplete}
              disabled={confirming || disputing}
              data-bcl="confirm-job-complete"
              className="inline-flex min-h-[44px] items-center justify-center rounded-lg bg-brand-accent px-4 py-2 font-semibold text-brand-bg transition-[transform,opacity] duration-[0.333s] hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent focus-visible:ring-offset-2 focus-visible:ring-offset-brand-card disabled:opacity-60 motion-reduce:transition-none motion-reduce:hover:translate-y-0"
            >
              {confirming ? t.payConfirming : t.payConfirmCta}
            </button>
            {finalCharge.closeOutEnabled && (
              <button
                type="button"
                onClick={() => setDisputeOpen((value) => !value)}
                disabled={confirming || disputing}
                aria-expanded={disputeOpen}
                className="inline-flex min-h-[44px] items-center justify-center rounded-lg border border-brand-line px-4 py-2 font-semibold text-brand-ink hover:border-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent disabled:opacity-60"
              >
                {t.payDisputeCta}
              </button>
            )}
          </div>
          <p className="text-brand-mute text-xs">{t.payConfirmHint}</p>
          {disputeOpen && (
            <div
              className="space-y-2 rounded-lg border border-brand-line bg-brand-bg/60 p-3"
              data-testid="close-out-dispute-form"
            >
              <label
                className="block text-sm font-medium text-brand-ink"
                htmlFor={`close-out-reason-${id}`}
              >
                {t.payDisputeReasonLabel}
              </label>
              <textarea
                id={`close-out-reason-${id}`}
                value={disputeReason}
                maxLength={1000}
                rows={3}
                onChange={(event) => setDisputeReason(event.currentTarget.value)}
                className="w-full rounded-md border border-brand-line bg-brand-card p-2 text-sm text-brand-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
              />
              <button
                type="button"
                onClick={() => void reportProblem()}
                disabled={disputing}
                className="min-h-[44px] rounded-lg bg-red-500 px-4 py-2 font-semibold text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-400 disabled:opacity-60"
              >
                {disputing ? t.payDisputing : t.payDisputeSubmit}
              </button>
            </div>
          )}
          {confirmError && (
            <p role="alert" className="text-xs text-red-400">
              {confirmError}
            </p>
          )}
          {disputeError && (
            <p role="alert" className="text-xs text-red-400">
              {disputeError}
            </p>
          )}
        </div>
      )}
    </div>
  );
}

function Timeline({
  timeline,
  status,
  t,
}: {
  timeline: TrackPayload['timeline'];
  status: string;
  t: TrackCopy;
}) {
  const steps: Array<{ label: string; at: string | null; done: boolean }> = [
    {
      label: t.tlBooked,
      at: timeline.scheduledAt,
      done: !!timeline.scheduledAt || status !== 'pending_payment',
    },
    { label: t.tlDepositPaid, at: timeline.paidAt, done: !!timeline.paidAt },
    {
      label: t.tlCrewDispatched,
      at: null,
      done: status === 'en_route' || status === 'completed',
    },
    { label: t.tlJobComplete, at: timeline.completedAt, done: !!timeline.completedAt },
    { label: t.tlPaidInFull, at: timeline.paidInFullAt, done: !!timeline.paidInFullAt },
  ];
  if (timeline.canceledAt) {
    return (
      <div className="rounded-lg border border-brand-line bg-brand-card p-6">
        <p className="text-brand-ink font-semibold mb-1">{t.tlCanceled}</p>
        <p className="text-brand-mute text-sm">
          {formatDateTime(timeline.canceledAt, t.dateLocale)}
        </p>
      </div>
    );
  }
  return (
    <ol className="rounded-lg border border-brand-line bg-brand-card p-6 space-y-3">
      {steps.map((s) => (
        <li key={s.label} className="flex items-start gap-3">
          <span
            className={`mt-1 size-3 rounded-full border ${
              s.done ? 'bg-brand-accent border-brand-accent' : 'bg-transparent border-brand-line'
            }`}
            aria-hidden="true"
          />
          <span className="flex-1">
            <span className={s.done ? 'text-brand-ink font-semibold' : 'text-brand-mute'}>
              {s.label}
            </span>
            {s.at && (
              <span className="block text-brand-mute text-xs mt-0.5">
                {formatDateTime(s.at, t.dateLocale)}
              </span>
            )}
          </span>
        </li>
      ))}
    </ol>
  );
}

function CrewPanel({
  crew,
  dispatchStage,
  bookingStatus,
  t,
}: {
  crew: CrewMember[];
  dispatchStage: DispatchStage | null;
  bookingStatus: string;
  t: TrackCopy;
}) {
  // Wave 2B — crew identity is revealed at confirmation, NOT day-of. As soon as
  // a booking lands in `confirmed`/`paid`/`paid_in_full`, customers can see
  // each crew member's photo, name, rating, prior-job count, and role badge.
  const isPreDispatch =
    bookingStatus === 'confirmed' || bookingStatus === 'paid' || bookingStatus === 'paid_in_full';
  const headerCopy = isPreDispatch ? t.crewMeet : t.crewYour;
  return (
    <section
      aria-label={t.crewYour}
      data-testid="crew-panel"
      className="rounded-lg border border-brand-line bg-brand-card p-6 space-y-4"
    >
      <div className="flex items-baseline justify-between gap-3">
        <h2 className="text-xl font-extrabold text-brand-ink">{headerCopy}</h2>
        <span className="text-brand-mute text-xs">
          {crew.length} {isPreDispatch ? t.crewAssigned : t.crewDispatched}
        </span>
      </div>

      {isPreDispatch && (
        <p className="text-brand-mute text-xs leading-snug">
          {t.crewNote}
          <a href="/tcpa" className="text-brand-accent underline-hover">
            {t.crewSmsPolicy}
          </a>
          .
        </p>
      )}

      {dispatchStage && <DispatchStageLine stage={dispatchStage} t={t} />}

      <ul className="space-y-3">
        {crew.map((w) => (
          <li
            key={w.workerId}
            data-testid="crew-member"
            data-worker-id={w.workerId}
            className="flex items-center gap-4"
          >
            {w.avatarUrl ? (
              <img
                src={w.avatarUrl}
                alt={`${w.firstName} ${w.lastInitial}`}
                className="size-12 rounded-full object-cover border border-brand-line"
                loading="lazy"
                decoding="async"
              />
            ) : (
              <div
                aria-hidden
                className="size-12 rounded-full bg-brand-line/40 flex items-center justify-center text-base font-bold text-brand-ink"
              >
                {(w.firstName[0] || '?').toUpperCase()}
              </div>
            )}
            <div className="flex-1 min-w-0">
              <p className="text-brand-ink font-semibold truncate">
                {w.firstName} {w.lastInitial}.
                {(w.isLead || w.role === 'lead') && (
                  <span className="ml-2 inline-flex items-center rounded bg-brand-accent/15 px-2 py-0.5 text-xs font-medium text-brand-accent">
                    {t.badgeShiftLead}
                  </span>
                )}
                {w.role === 'driver' && (
                  <span className="ml-2 inline-flex items-center rounded bg-amber-500/15 px-2 py-0.5 text-xs font-medium text-amber-200">
                    {t.badgeDriver}
                  </span>
                )}
              </p>
              <p className="text-brand-mute text-xs">
                {w.ratingAvg ? (
                  <>
                    ★ {w.ratingAvg.toFixed(1)} · {w.ratingCount}{' '}
                    {w.ratingCount === 1 ? t.reviewSingular : t.reviewPlural}
                  </>
                ) : (
                  t.crewNew
                )}
                {typeof w.priorJobCount === 'number' && w.priorJobCount > 0 && (
                  <>
                    {' · '}
                    {w.priorJobCount}{' '}
                    {w.priorJobCount === 1 ? t.priorJobSingular : t.priorJobPlural}
                  </>
                )}
                {w.checkedInAt && (
                  <>
                    {' · '}
                    <span className="text-emerald-300">
                      {t.checkedIn.replace('{ago}', timeAgo(w.checkedInAt, t))}
                    </span>
                  </>
                )}
              </p>
              {w.bio && <p className="text-brand-mute text-xs mt-1 line-clamp-2">{w.bio}</p>}
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}

function DispatchStageLine({ stage, t }: { stage: DispatchStage; t: TrackCopy }) {
  const label = stageLabel(stage, t);
  // A scope-change stage carries the crew's reason — surface it so the customer
  // can actually REVIEW what changed (the notification promised "review and approve").
  const detail =
    stage.kind === 'scope_change' && stage.detail
      ? t.stageScopeChangeDetail.replace('{reason}', stage.detail)
      : null;
  return (
    <div className="rounded-md border border-brand-accent/30 bg-brand-accent/5 px-3 py-2 text-sm text-brand-ink">
      <p>
        <span className="font-semibold">{label}</span>
        <span className="text-brand-mute"> · {timeAgo(stage.at, t)}</span>
      </p>
      {detail && <p className="mt-1 text-brand-mute">{detail}</p>}
    </div>
  );
}

function stageLabel(stage: DispatchStage, t: TrackCopy): string {
  const who = stage.actorFirstName ? `${stage.actorFirstName} ` : t.stageDefaultWho;
  switch (stage.kind) {
    case 'en_route':
      return t.stageOnWay.replace('{who}', who);
    case 'arrived':
      return t.stageArrived.replace('{who}', who);
    case 'complete':
      return t.stageComplete.replace('{who}', who);
    case 'claimed':
      return t.stageClaimed.replace('{who}', who);
    case 'scope_change':
      return t.stageScopeChange.replace('{who}', who);
    default:
      return `${who}${stage.kind.replace(/_/g, ' ')}`;
  }
}

function timeAgo(iso: string, t: TrackCopy): string {
  const dt = new Date(iso);
  if (Number.isNaN(dt.getTime())) return iso;
  const diffMs = Date.now() - dt.getTime();
  const mins = Math.round(diffMs / 60_000);
  if (mins < 1) return t.justNow;
  if (mins < 60) return t.minAgo.replace('{n}', String(mins));
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return t.hrAgo.replace('{n}', String(hrs));
  return dt.toLocaleDateString(t.dateLocale, { month: 'short', day: 'numeric' });
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-4 border-b border-brand-line/40 pb-2 last:border-0 last:pb-0">
      <span className="text-brand-mute text-sm">{label}</span>
      <span className="text-brand-ink font-semibold text-right">{value}</span>
    </div>
  );
}

/**
 * Time row that promises an honest 2-hour ARRIVAL WINDOW from the booked slot
 * (P2-38) — "Arrival window · 9:00 – 11:00 AM" + a muted reassurance sublabel —
 * instead of an exact minute a crew driving across Newark can't hit. Falls back
 * to the plain "Time / flexible" row when the slot has no parseable clock time.
 */
function ArrivalRow({ time, t }: { time: string; t: TrackCopy }) {
  const win = arrivalWindow(time);
  if (!win) return <Row label={t.rowTime} value={time} />;
  return (
    <div className="flex justify-between gap-4 border-b border-brand-line/40 pb-2">
      <span className="text-brand-mute text-sm">{t.rowArrivalWindow}</span>
      <span className="text-right">
        <span className="block text-brand-ink font-semibold tabular-nums">{win.label}</span>
        <span className="block text-brand-mute text-xs mt-0.5">{t.arrivalWindowNote}</span>
      </span>
    </div>
  );
}

/** Maps a service slug to its localized label, falling back to the raw slug. */
function serviceLabel(slug: string, t: TrackCopy): string {
  const normalized = normalizeToBookingTile(slug) ?? slug;
  switch (normalized) {
    case 'power-wash':
      return t.svcPowerWash;
    case 'lawn':
      return t.svcLawn;
    case 'haul':
      return t.svcHaul;
    case 'repairs':
      return t.svcRepairs;
    case 'cleanout':
      return t.svcCleanout;
    case 'seasonal':
      return t.svcSeasonal;
    case 'other':
      return t.svcOther;
    default:
      return slug;
  }
}

/** Renders booking services as styled pills — one per service, never CSV text. */
function ServicePills({ services, t }: { services: string[]; t: TrackCopy }) {
  if (!services.length)
    return (
      <div className="flex justify-between gap-4 border-b border-brand-line/40 pb-2">
        <span className="text-brand-mute text-sm">{t.rowServices}</span>
        <span className="text-brand-ink font-semibold">—</span>
      </div>
    );
  return (
    <div className="flex justify-between items-start gap-4 border-b border-brand-line/40 pb-2 last:border-0 last:pb-0">
      <span className="text-brand-mute text-sm shrink-0">{t.rowServices}</span>
      <ul role="list" aria-label={t.rowServices} className="flex flex-wrap justify-end gap-1.5">
        {services.map((s, i) => (
          <li
            key={s}
            style={{ animationDelay: `${i * 60}ms` }}
            className="rounded-full bg-brand-accent/10 border border-brand-accent/30 px-2.5 py-0.5 text-xs font-medium text-brand-accent transition-all duration-[333ms] hover:-translate-y-0.5 hover:bg-brand-accent/20 hover:shadow-sm"
          >
            {serviceLabel(s, t)}
          </li>
        ))}
      </ul>
    </div>
  );
}

function labelFor(status: string, enRoute: boolean, locale: StatusLocale): string {
  // enRoute overlay reads "Crew on the way" even if status hasn't transitioned
  // yet (ontheway dispatch SMS flips a flag before the status update commits).
  if (enRoute && status !== 'canceled' && status !== 'completed')
    return humanizeStatus('en_route', locale);
  return humanizeStatus(status, locale);
}

function toneFor(status: string): string {
  if (status === 'canceled') return 'bg-red-500/10 text-red-300 border border-red-500/30';
  if (status === 'completed' || status === 'paid_in_full')
    return 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30';
  if (status === 'en_route') return 'bg-amber-500/10 text-amber-200 border border-amber-500/30';
  return 'bg-brand-accent/10 text-brand-accent border border-brand-accent/30';
}

function formatDate(d: string, dateLocale: string): string {
  if (!d) return '—';
  const dt = new Date(`${d}T00:00:00`);
  if (Number.isNaN(dt.getTime())) return d;
  return dt.toLocaleDateString(dateLocale, { weekday: 'short', month: 'short', day: 'numeric' });
}

function formatDateTime(iso: string, dateLocale: string): string {
  const dt = new Date(iso);
  if (Number.isNaN(dt.getTime())) return iso;
  return dt.toLocaleString(dateLocale, {
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  });
}

function setMeta(name: string, content: string, attr: 'name' | 'property' = 'name') {
  let el = document.querySelector<HTMLMetaElement>(`meta[${attr}="${name}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function setLink(rel: string, href: string) {
  let el = document.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', rel);
    document.head.appendChild(el);
  }
  el.setAttribute('href', href);
}
