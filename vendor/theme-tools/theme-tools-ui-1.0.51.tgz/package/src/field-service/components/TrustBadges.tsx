import { useEffect, useState } from 'react';
import {
  DEFAULT_FIELD_SERVICE_TRUST_BADGES,
  useThemeToolsSurface,
} from '../../field-service-primitives.js';
import {
  fetchInsuranceProof,
  formatCoverageLine,
  formatLicenseLine,
  hasActiveCoverage,
  type InsuranceProof,
} from '../insurance-proof.js';
import { stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { trustBandCopy } from '@theme.tools/i18n-a11y/field-service/trust-band-copy';

// Wave 2B + Wave 1B — bento trust grid with LIVE insurance proof in the hero
// tile. The hero pulls USDOT / MC# / coverage from /api/stats/insurance via
// insurance-proof.ts; every value carries a `data-eeat="..."` attribute so
// SEO + AI-search crawlers can pluck the proof straight from the DOM (matches
// the Wave 1A EEAT scheme). Mobile reorder is achieved via `col-span-2
// sm:row-span-2` so the loud hero tile still leads on phones. No stock imagery.
//
// Localized for the /es + /pt mirrors: the SPA strips the locale prefix to
// route, so without locale-aware copy a Spanish/Portuguese visitor reads this
// band in English. Reads the locale off the URL (SSR-safe default 'en') and
// renders the matching trust-band bundle — same pattern as Hero.tsx.

interface Badge {
  readonly icon: string;
  readonly label: string;
  readonly sub: string;
}

export function TrustBadges() {
  const [proof, setProof] = useState<InsuranceProof | null>(null);

  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const t = trustBandCopy(locale);

  const supportingBadges: ReadonlyArray<Badge> = [
    { icon: '📍', label: t.badgeNewarkCrew, sub: t.badgeNewarkCrewSub },
    { icon: '📞', label: t.badgeOwnerReads, sub: t.badgeOwnerReadsSub },
    { icon: '⚡', label: t.badgeSameWeek, sub: t.badgeSameWeekSub },
    { icon: '🔨', label: t.badgeJobsCompleted, sub: t.badgeJobsCompletedSub },
    { icon: '💵', label: t.badgeFlexPay, sub: t.badgeFlexPaySub },
  ];

  useEffect(() => {
    let cancelled = false;
    fetchInsuranceProof().then((p) => {
      if (!cancelled) setProof(p);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  // The "insured for property work" stance is canonical (city FAQ + the
  // license-claim gate), so the LABEL stays "Fully Insured". But specific
  // coverage NUMBERS, the COI link, and the "verified" date may only render
  // when a REAL policy is on file — otherwise the launch-day state fabricates
  // "$1M liability · $100k cargo" / a certificate that does not exist. When no
  // INSURANCE_* secret is set the sub-line falls back to the honest
  // photo-documented + dispute-window trust line. Self-arms the moment a real
  // carrier + COI land in the worker secrets.
  const active = proof ? hasActiveCoverage(proof) : false;
  const licenseLine = proof ? formatLicenseLine(proof) : t.loadingCredentials;
  const coverageLine = active && proof ? formatCoverageLine(proof) : t.protectedSub;
  const surfaceProps = useThemeToolsSurface('trust-badges', [
    '@theme.tools/ui',
    '@theme.tools/billing',
  ]);

  return (
    <section
      aria-label={t.whyHire}
      className="border-y border-brand-line bg-bg-elevated/40"
      data-theme-tools-surface={surfaceProps['data-theme-tools-surface']}
      data-theme-tools-pricing-model={surfaceProps['data-theme-tools-pricing-model']}
      data-theme-tools-trust-count={DEFAULT_FIELD_SERVICE_TRUST_BADGES.length}
    >
      <div className="container-pad py-10">
        <div
          className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4"
          data-stagger="80"
          data-bento="trust"
        >
          <article
            data-animate="fade-up"
            data-eeat="insured"
            className="col-span-2 sm:col-span-2 sm:row-span-2 reveal-on-view rounded-xl border border-brand-accent/40 bg-brand-accent/5 p-5 flex flex-col gap-3 min-h-[140px]"
          >
            <header className="flex items-center gap-3">
              <span aria-hidden className="text-3xl">
                🛡️
              </span>
              <div>
                <p className="font-display font-bold text-brand-ink leading-tight text-pretty">
                  {t.insuredBadge}
                </p>
                <p
                  className="text-xs font-mono text-brand-accent tracking-wider uppercase"
                  data-eeat="usdot"
                  data-eeat-mc={proof?.mcNumber ?? ''}
                  data-eeat-usdot={proof?.usdot ?? ''}
                >
                  {licenseLine}
                </p>
              </div>
            </header>
            <div className="text-sm text-brand-mute leading-snug text-pretty" data-eeat="coverage">
              {coverageLine}
            </div>
            <footer className="mt-auto flex flex-wrap items-center gap-3 text-xs">
              {active && proof?.certificateOfInsuranceUrl ? (
                <a
                  href={proof.certificateOfInsuranceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  data-eeat="coi"
                  className="text-brand-accent underline-hover font-semibold"
                >
                  {t.viewCoi}
                </a>
              ) : (
                <span className="text-brand-mute italic" data-eeat="coi">
                  {t.coiOnRequestPre}{' '}
                  <a href="mailto:hey@bricklabor.com" className="text-brand-accent underline-hover">
                    hey@bricklabor.com
                  </a>
                </span>
              )}
              {active && proof?.asOf && (
                <span className="text-brand-mute" data-eeat="as-of">
                  {t.verifiedPrefix} {proof.asOf}
                </span>
              )}
            </footer>
          </article>

          {supportingBadges.map((b) => (
            <article
              key={b.label}
              className="reveal-on-view rounded-xl border border-brand-line bg-brand-card/60 p-4 flex items-start gap-3"
              data-animate="fade-up"
            >
              <span aria-hidden className="text-2xl">
                {b.icon}
              </span>
              <div className="min-w-0">
                <p className="font-display font-semibold text-brand-ink leading-tight">{b.label}</p>
                <p className="text-xs text-brand-mute leading-tight">{b.sub}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
