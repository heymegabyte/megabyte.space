import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect, useRef, useState } from 'react';

/**
 * Cloudflare Turnstile widget — the front-end half of BACKLOG P0-2.
 *
 * Reads the PUBLIC site key from `VITE_TURNSTILE_SITE_KEY` at build time. When the
 * key is absent (current bring-up state) the component renders nothing and never
 * fires `onToken`, so wiring it into a form is a guaranteed no-op — the server
 * stays soft-open (`verifyTurnstile` → `!TURNSTILE_SITE_KEY`). The instant the key
 * is provided on BOTH sides (worker var + Vite build), every wired form mints a
 * token AND the server flips to fail-closed on empty tokens. No further code change.
 *
 * Strict-dynamic CSP safe: the official `api.js` is injected at runtime by this
 * component (a nonce-trusted script context), so its child scripts inherit trust
 * without a static `script-src` allowlist entry. `frame-src` already allows
 * `challenges.cloudflare.com` (see `worker/lib/csp.ts`).
 */

// Public Turnstile sitekey for bricklabor.com (Cloudflare exposes it in widget HTML — not a secret).
// Build-time VITE_TURNSTILE_SITE_KEY overrides; the fallback is the INVISIBLE-mode widget
// (`0x4AAAAAAFE30twYn48rbmTE`) so forms — the /book form especially — never render a visible
// Cloudflare challenge/badge. The old managed key (`0x4AAAAAADNDdoIom4vnvqHZ`) showed a box.
const SITE_KEY =
  (import.meta.env?.VITE_TURNSTILE_SITE_KEY as string | undefined) ??
  '0x4AAAAAAFE30twYn48rbmTE';
const SCRIPT_SRC = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';

interface TurnstileApi {
  render: (
    el: HTMLElement,
    opts: {
      sitekey: string;
      action?: string;
      theme?: 'auto' | 'light' | 'dark';
      appearance?: 'always' | 'execute' | 'interaction-only';
      callback: (token: string) => void;
      'error-callback'?: () => void;
      'expired-callback'?: () => void;
    },
  ) => string;
  remove: (widgetId: string) => void;
}

declare global {
  interface Window {
    turnstile?: TurnstileApi;
  }
}

let scriptPromise: Promise<void> | null = null;

/** Inject the Turnstile script once per page; resolve when `window.turnstile` is ready. */
function loadTurnstileScript(): Promise<void> {
  if (typeof window === 'undefined') return Promise.resolve();
  if (window.turnstile) return Promise.resolve();
  if (scriptPromise) return scriptPromise;

  scriptPromise = new Promise<void>((resolve, reject) => {
    const s = document.createElement('script');
    s.src = SCRIPT_SRC;
    s.async = true;
    s.defer = true;
    s.onload = () => resolve();
    s.onerror = () => reject(new Error('turnstile script failed to load'));
    document.head.appendChild(s);
  });
  return scriptPromise;
}

interface TurnstileWidgetProps {
  /** Called with the verification token; called with '' when expired/errored. */
  onToken: (token: string) => void;
  /** Optional Turnstile action label for analytics (e.g. 'contact', 'booking'). */
  action?: string;
  /**
   * Widget visibility. `interaction-only` is the TRANSPARENT implementation — the
   * challenge stays invisible and only surfaces a UI if Cloudflare decides an
   * interaction is genuinely required. Defaults to `always` (the visible box).
   */
  appearance?: 'always' | 'execute' | 'interaction-only';
  className?: string;
}

export function TurnstileWidget({ onToken, action, appearance, className }: TurnstileWidgetProps) {
  useThemeToolsSurface('turnstile-widget');
  const ref = useRef<HTMLDivElement>(null);
  const [armed, setArmed] = useState(false);

  // Turnstile's challenge payload can exceed 1.5 MB. Loading it for every
  // below-the-fold form during initial paint dominated the homepage's mobile
  // transfer budget and delayed LCP even when the visitor never approached a
  // form. Arm shortly before the widget reaches the viewport; browsers without
  // IntersectionObserver retain the safe eager behavior.
  useEffect(() => {
    const host = ref.current;
    if (!SITE_KEY || !host || armed) return;
    if (!('IntersectionObserver' in window)) {
      setArmed(true);
      return;
    }
    const observer = new IntersectionObserver(
      (entries) => {
        if (!entries.some((entry) => entry.isIntersecting)) return;
        setArmed(true);
        observer.disconnect();
      },
      { rootMargin: '200px 0px' },
    );
    observer.observe(host);
    return () => observer.disconnect();
  }, [armed]);

  useEffect(() => {
    if (!SITE_KEY || !armed || !ref.current) return;
    const host = ref.current;
    let widgetId: string | undefined;
    let cancelled = false;

    loadTurnstileScript()
      .then(() => {
        if (cancelled || !window.turnstile || !host) return;
        widgetId = window.turnstile.render(host, {
          sitekey: SITE_KEY,
          action,
          theme: 'auto',
          appearance,
          callback: (token) => onToken(token),
          'error-callback': () => onToken(''),
          'expired-callback': () => onToken(''),
        });
      })
      .catch((_err) => {
        // Fail visible-but-soft: no token sent → server soft-open path handles it.
        // Error tracked via Sentry
      });

    return () => {
      cancelled = true;
      if (widgetId && window.turnstile) {
        try {
          window.turnstile.remove(widgetId);
        } catch {
          /* widget already gone */
        }
      }
    };
  }, [onToken, action, appearance, armed]);

  // No site key configured → render nothing; the form behaves exactly as before.
  if (!SITE_KEY) return null;

  // `role="group"` makes the `aria-label` a valid accessible name — a bare <div>
  // has the implicit generic role, on which `aria-label` is prohibited (axe
  // `aria-prohibited-attr`, serious). The group also reads the injected Turnstile
  // iframe as a named "Human verification challenge" region to AT users.
  return (
    <div ref={ref} className={className} role="group" aria-label="Human verification challenge" />
  );
}
