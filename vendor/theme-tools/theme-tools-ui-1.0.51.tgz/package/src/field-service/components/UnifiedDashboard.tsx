import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { lazy, Suspense, useEffect, useMemo, useState } from 'react';
import { usd0 } from '@theme.tools/billing/field-service/money';
import { startSafeViewTransition } from '../../field-service-primitives.js';

/**
 * Unified dashboard — one /dashboard route, role-aware sections.
 *
 * Replaces the historical split between /admin, /work, /me by detecting the
 * caller's role via /api/auth/whoami and rendering a tabbed shell with
 * sections gated by role:
 *
 *   guest      → hero + "sign in" CTAs
 *   customer   → next service / subscriptions / referrals / photos
 *   crew       → today's run / payouts / tap-to-pay / streak
 *   admin      → KPIs / activity feed / AI tool suite / subscriptions admin
 *   super_admin → everything + system tools
 *
 * Dual-role accounts (one human is both customer AND crew) see both rails
 * with a switcher chip at the top. Existing legacy routes (/admin, /work,
 * /me) keep working — this is additive, not a forced migration.
 */

type Role = 'guest' | 'customer' | 'crew' | 'admin' | 'super_admin';

interface WhoAmI {
  role: Role;
  roles: Array<'customer' | 'crew' | 'admin' | 'super_admin'>;
  displayName: string | null;
  email: string | null;
  workerId: string | null;
  isAdmin: boolean;
  isSuperAdmin: boolean;
}

interface FeedEvent {
  id: string;
  kind: string;
  title: string;
  subtitle: string;
  at: string;
  ago: string;
  severity: 'info' | 'success' | 'warn' | 'error';
  href?: string;
}

const MySubscriptions = lazy(() =>
  import('./customer/MySubscriptions.js').then((m) => ({ default: m.MySubscriptions })),
);
const NextServiceCard = lazy(() =>
  import('./customer/NextServiceCard.js').then((m) => ({ default: m.NextServiceCard })),
);
const SpendInsights = lazy(() =>
  import('./customer/SpendInsights.js').then((m) => ({ default: m.SpendInsights })),
);
const TodaysRun = lazy(() => import('./work/TodaysRun.js'));
const EarningsTicker = lazy(() => import('./work/EarningsTicker.js'));
const NextGigOfferTimer = lazy(() => import('./work/NextGigOfferTimer.js'));
const DispatchBoard = lazy(() =>
  import('./admin/DispatchBoard.js').then((m) => ({ default: m.DispatchBoard })),
);
const InboxTriageQueue = lazy(() =>
  import('./admin/InboxTriageQueue.js').then((m) => ({ default: m.InboxTriageQueue })),
);
const AuditLogSearch = lazy(() =>
  import('./admin/AuditLogSearch.js').then((m) => ({ default: m.AuditLogSearch })),
);
const RecommendationChips = lazy(() =>
  import('./RecommendationChips.js').then((m) => ({ default: m.RecommendationChips })),
);
const PhotoGallery = lazy(() =>
  import('./customer/PhotoGallery.js').then((m) => ({ default: m.PhotoGallery })),
);
const ReferralProgress = lazy(() =>
  import('./customer/ReferralProgress.js').then((m) => ({ default: m.ReferralProgress })),
);
const CalendarExport = lazy(() =>
  import('./customer/CalendarExport.js').then((m) => ({ default: m.CalendarExport })),
);
const RecurringSchedulePreview = lazy(() =>
  import('./customer/RecurringSchedulePreview.js').then((m) => ({
    default: m.RecurringSchedulePreview,
  })),
);
const StreakWidget = lazy(() => import('./work/StreakWidget.js'));
const CrewBadgeCollection = lazy(() => import('./work/CrewBadgeCollection.js'));
const RevenueWaterfallChart = lazy(() =>
  import('./admin/RevenueWaterfallChart.js').then((m) => ({ default: m.RevenueWaterfallChart })),
);
const CrewScoreboard = lazy(() =>
  import('./admin/CrewScoreboard.js').then((m) => ({ default: m.CrewScoreboard })),
);
const HeatmapCalendar = lazy(() =>
  import('./admin/HeatmapCalendar.js').then((m) => ({ default: m.HeatmapCalendar })),
);
const KeyboardShortcutsOverlay = lazy(() =>
  import('./admin/KeyboardShortcutsOverlay.js').then((m) => ({ default: m.KeyboardShortcutsOverlay })),
);
const ThemeSwitcher = lazy(() =>
  import('./ThemeSwitcher.js').then((m) => ({ default: m.ThemeSwitcher })),
);
const DensityToggle = lazy(() =>
  import('./DensityToggle.js').then((m) => ({ default: m.DensityToggle })),
);
const SystemHealthPanel = lazy(() =>
  import('./admin/SystemHealthPanel.js').then((m) => ({ default: m.SystemHealthPanel })),
);
const FeatureFlagsPanel = lazy(() =>
  import('./admin/FeatureFlagsPanel.js').then((m) => ({ default: m.FeatureFlagsPanel })),
);
const BackupRestorePanel = lazy(() =>
  import('./admin/BackupRestorePanel.js').then((m) => ({ default: m.BackupRestorePanel })),
);
const SqlCopilotPanel = lazy(() =>
  import('./admin/SqlCopilotPanel.js').then((m) => ({ default: m.SqlCopilotPanel })),
);

const KEY_BEARER = 'bcl_owner_invoice_key';

function readBearer(): string {
  try {
    return localStorage.getItem(KEY_BEARER) ?? '';
  } catch {
    return '';
  }
}

export function UnifiedDashboard() {
  useThemeToolsSurface('unified-dashboard');
  const [bearer, setBearer] = useState<string>(readBearer());
  const [me, setMe] = useState<WhoAmI | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeSection, setActiveSection] = useState<string>('overview');
  const [feed, setFeed] = useState<FeedEvent[]>([]);
  const [stats, setStats] = useState<Record<string, number | string>>({});
  const [refreshKey, setRefreshKey] = useState(0);
  const [shortcutsOpen, setShortcutsOpen] = useState(false);

  // Cmd+/ (or Ctrl+/) → open the keyboard shortcuts overlay from anywhere.
  // Esc handling lives inside KeyboardShortcutsOverlay itself.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === '/') {
        e.preventDefault();
        setShortcutsOpen((v) => !v);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  // Fetch whoami on mount + whenever bearer changes.
  useEffect(() => {
    const headers: HeadersInit = bearer ? { authorization: `Bearer ${bearer}` } : {};
    void (async () => {
      setLoading(true);
      try {
        const res = await fetch('/api/auth/whoami', { headers, credentials: 'include' });
        const json = (await res.json()) as { ok: boolean; whoami?: WhoAmI };
        if (json.ok && json.whoami) setMe(json.whoami);
      } finally {
        setLoading(false);
      }
    })();
  }, [bearer]);

  // Activity feed — polled every 30s. View Transitions wrap the swap so the
  // list cross-fades instead of pop-replaces.
  useEffect(() => {
    if (!me || me.role === 'guest') return;
    let cancelled = false;
    const headers: HeadersInit = bearer ? { authorization: `Bearer ${bearer}` } : {};
    async function load() {
      try {
        const res = await fetch('/api/dashboard/feed', { headers, credentials: 'include' });
        const json = (await res.json()) as { ok: boolean; events?: FeedEvent[] };
        if (cancelled) return;
        if (json.ok && json.events) {
          if (!startSafeViewTransition(document, () => setFeed(json.events!))) setFeed(json.events);
        }
      } catch {
        /* silent — polling will retry */
      }
    }
    void load();
    const t = window.setInterval(() => void load(), 30_000);
    return () => {
      cancelled = true;
      window.clearInterval(t);
    };
  }, [me, bearer, refreshKey]);

  // Admin: pull subscription stats for the KPI strip.
  useEffect(() => {
    if (!me?.isAdmin || !bearer) return;
    void (async () => {
      try {
        const res = await fetch('/api/admin/subscriptions/stats', {
          headers: { authorization: `Bearer ${bearer}` },
        });
        const json = (await res.json()) as { ok: boolean; stats?: Record<string, number> };
        if (json.ok && json.stats) {
          setStats({
            MRR: usd0((json.stats.mrrCents as number) ?? 0),
            'Active subs': (json.stats.activeCount as number) ?? 0,
            'Churn 30d': `${((json.stats.churnRate30d as number) ?? 0).toFixed(1)}%`,
            Pending: (json.stats.pendingCount as number) ?? 0,
          });
        }
      } catch {
        /* ignore */
      }
    })();
  }, [me, bearer, refreshKey]);

  const sections = useMemo(() => buildSections(me), [me]);

  function setStoredBearer(v: string): void {
    try {
      if (v) localStorage.setItem(KEY_BEARER, v);
      else localStorage.removeItem(KEY_BEARER);
    } catch {
      /* ignore */
    }
    setBearer(v);
  }

  if (loading) {
    return (
      <main className="bg-bg-primary min-h-screen p-8 text-brand-mute">Loading dashboard…</main>
    );
  }

  if (!me || me.role === 'guest') {
    return <GuestView onAdminBearer={setStoredBearer} bearer={bearer} />;
  }

  return (
    <main className="bg-bg-primary min-h-screen">
      <header
        className="sticky top-0 z-30 border-b border-brand-line bg-bg-primary/90 backdrop-blur"
        style={{ viewTransitionName: 'bcl-dash-header' }}
      >
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3">
          <div className="flex items-center gap-3">
            <RoleBadge role={me.role} />
            <p className="text-sm font-semibold text-brand-ink">{me.displayName ?? 'Welcome'}</p>
            {me.roles.length > 1 && (
              <div className="hidden gap-1 sm:flex">
                {me.roles.map((r) => (
                  <span
                    key={r}
                    className="rounded-md border border-brand-line bg-bg-elevated px-2 py-0.5 font-mono text-[9px] uppercase tracking-widest text-brand-mute"
                  >
                    {r}
                  </span>
                ))}
              </div>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setRefreshKey((k) => k + 1)}
              className="rounded-md border border-brand-line bg-bg-elevated px-3 py-1.5 text-xs text-brand-mute hover:text-brand-ink"
            >
              Refresh
            </button>
            <kbd className="hidden rounded border border-brand-line bg-bg-elevated px-2 py-1 font-mono text-[10px] text-brand-mute sm:inline">
              Cmd K
            </kbd>
          </div>
        </div>
      </header>

      <div className="mx-auto flex max-w-7xl flex-col gap-6 px-4 py-6 lg:flex-row">
        <nav
          aria-label="Dashboard sections"
          className="flex shrink-0 gap-2 overflow-x-auto lg:w-56 lg:flex-col"
        >
          {sections.map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => {
                if (!startSafeViewTransition(document, () => setActiveSection(s.id))) {
                  setActiveSection(s.id);
                }
              }}
              aria-pressed={activeSection === s.id}
              className={`flex items-center gap-2 whitespace-nowrap rounded-lg border px-3 py-2 text-sm transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-accent ${
                activeSection === s.id
                  ? 'border-brand-accent bg-brand-accent/10 text-brand-ink'
                  : 'border-brand-line bg-bg-elevated text-brand-mute hover:text-brand-ink'
              }`}
            >
              <span aria-hidden>{s.icon}</span>
              <span>{s.label}</span>
              {s.badge && (
                <span className="ml-auto rounded-full bg-brand-accent px-1.5 py-0.5 font-mono text-[9px] text-black">
                  {s.badge}
                </span>
              )}
            </button>
          ))}
        </nav>

        <section
          className="min-w-0 flex-1 space-y-4"
          style={{ viewTransitionName: 'bcl-dash-main' }}
        >
          {Object.keys(stats).length > 0 && activeSection === 'overview' && (
            <KpiStrip stats={stats} />
          )}

          {activeSection === 'overview' && <OverviewPanel me={me} feed={feed} bearer={bearer} />}
          {activeSection === 'subscriptions' && me.email && (
            <Suspense fallback={<p className="text-sm text-brand-mute">Loading…</p>}>
              <MySubscriptions customerEmail={me.email} />
            </Suspense>
          )}
          {activeSection === 'next-service' && me.email && (
            <Suspense fallback={<p className="text-sm text-brand-mute">Loading…</p>}>
              <NextServiceCard customerEmail={me.email} />
            </Suspense>
          )}
          {activeSection === 'spend-insights' && me.email && (
            <Suspense fallback={<p className="text-sm text-brand-mute">Loading…</p>}>
              <SpendInsights customerEmail={me.email} />
            </Suspense>
          )}
          {activeSection === 'admin-subs' && me.isAdmin && <AdminSubsPanel bearer={bearer} />}
          {activeSection === 'dispatch' && me.isAdmin && (
            <Suspense fallback={<p className="text-sm text-brand-mute">Loading…</p>}>
              <DispatchBoard bearer={bearer} />
            </Suspense>
          )}
          {activeSection === 'inbox' && me.isAdmin && (
            <Suspense fallback={<p className="text-sm text-brand-mute">Loading…</p>}>
              <InboxTriageQueue bearer={bearer} />
            </Suspense>
          )}
          {activeSection === 'audit-search' && me.isAdmin && (
            <Suspense fallback={<p className="text-sm text-brand-mute">Loading…</p>}>
              <AuditLogSearch bearer={bearer} />
            </Suspense>
          )}
          {activeSection === 'revenue' && me.isAdmin && (
            <Suspense fallback={<p className="text-sm text-brand-mute">Loading…</p>}>
              <RevenueWaterfallChart bearer={bearer} />
            </Suspense>
          )}
          {activeSection === 'scoreboard' && me.isAdmin && (
            <Suspense fallback={<p className="text-sm text-brand-mute">Loading…</p>}>
              <CrewScoreboard bearer={bearer} />
            </Suspense>
          )}
          {activeSection === 'heatmap' && me.isAdmin && (
            <Suspense fallback={<p className="text-sm text-brand-mute">Loading…</p>}>
              <HeatmapCalendar bearer={bearer} />
            </Suspense>
          )}
          {activeSection === 'sys-health' && me.isSuperAdmin && (
            <Suspense fallback={<p className="text-sm text-brand-mute">Loading…</p>}>
              <SystemHealthPanel bearer={bearer} />
            </Suspense>
          )}
          {activeSection === 'feature-flags' && me.isSuperAdmin && (
            <Suspense fallback={<p className="text-sm text-brand-mute">Loading…</p>}>
              <FeatureFlagsPanel bearer={bearer} />
            </Suspense>
          )}
          {activeSection === 'backup-restore' && me.isSuperAdmin && (
            <Suspense fallback={<p className="text-sm text-brand-mute">Loading…</p>}>
              <BackupRestorePanel bearer={bearer} />
            </Suspense>
          )}
          {activeSection === 'sql-copilot' && me.isSuperAdmin && (
            <Suspense fallback={<p className="text-sm text-brand-mute">Loading…</p>}>
              <SqlCopilotPanel bearer={bearer} />
            </Suspense>
          )}
          {activeSection === 'ai-tools' && me.isAdmin && (
            <a
              href="/admin/ai"
              className="inline-flex items-center rounded-md bg-brand-accent px-4 py-2 text-sm font-semibold text-black hover:brightness-110"
            >
              Open AI Tool Suite →
            </a>
          )}
          {activeSection === 'today' && me.workerId && (
            <Suspense fallback={<p className="text-sm text-brand-mute">Loading…</p>}>
              <TodaysRun />
            </Suspense>
          )}
          {activeSection === 'earnings' && me.workerId && (
            <Suspense fallback={<p className="text-sm text-brand-mute">Loading…</p>}>
              <EarningsTicker />
              <NextGigOfferTimer />
            </Suspense>
          )}
          {activeSection === 'streak' && me.workerId && (
            <Suspense fallback={<p className="text-sm text-brand-mute">Loading…</p>}>
              <StreakWidget />
              <CrewBadgeCollection />
            </Suspense>
          )}
          {activeSection === 'photos' && me.email && (
            <Suspense fallback={<p className="text-sm text-brand-mute">Loading…</p>}>
              <PhotoGallery customerEmail={me.email} />
            </Suspense>
          )}
          {activeSection === 'referrals' && me.email && (
            <Suspense fallback={<p className="text-sm text-brand-mute">Loading…</p>}>
              <ReferralProgress customerEmail={me.email} />
            </Suspense>
          )}
          {activeSection === 'calendar-export' && me.email && (
            <Suspense fallback={<p className="text-sm text-brand-mute">Loading…</p>}>
              <CalendarExport customerEmail={me.email} />
            </Suspense>
          )}
          {activeSection === 'recurring-preview' && me.email && (
            <Suspense fallback={<p className="text-sm text-brand-mute">Loading…</p>}>
              <RecurringSchedulePreview customerEmail={me.email} />
            </Suspense>
          )}
          {activeSection === 'me' && me.email && (
            <a
              href="/me"
              className="inline-flex items-center rounded-md bg-brand-accent px-4 py-2 text-sm font-semibold text-black hover:brightness-110"
            >
              Open full customer page →
            </a>
          )}
          {activeSection === 'plans' && (
            <a
              href="/plans"
              className="inline-flex items-center rounded-md bg-brand-accent px-4 py-2 text-sm font-semibold text-black hover:brightness-110"
            >
              Browse maintenance plans →
            </a>
          )}
          {activeSection === 'settings' && (
            <SettingsPanel bearer={bearer} onBearerChange={setStoredBearer} me={me} />
          )}
        </section>
      </div>

      <Suspense fallback={null}>
        <KeyboardShortcutsOverlay open={shortcutsOpen} onClose={() => setShortcutsOpen(false)} />
      </Suspense>
    </main>
  );
}

// ───── Sub-components ─────────────────────────────────────────────────────

function buildSections(me: WhoAmI | null): Array<{
  id: string;
  label: string;
  icon: string;
  badge?: string;
}> {
  if (!me || me.role === 'guest') return [];
  const sections: Array<{ id: string; label: string; icon: string; badge?: string }> = [
    { id: 'overview', label: 'Overview', icon: '◆' },
  ];
  if (me.isAdmin) {
    sections.push(
      { id: 'admin-subs', label: 'Subscriptions', icon: '↻' },
      { id: 'dispatch', label: 'Dispatch', icon: '⬡' },
      { id: 'revenue', label: 'Revenue', icon: '▲' },
      { id: 'scoreboard', label: 'Crew scoreboard', icon: '◈' },
      { id: 'heatmap', label: 'Booking heatmap', icon: '▦' },
      { id: 'inbox', label: 'Inbox triage', icon: '✉' },
      { id: 'audit-search', label: 'Audit search', icon: '⌖' },
      { id: 'ai-tools', label: 'AI tools', icon: '✦' },
    );
  }
  if (me.isSuperAdmin) {
    sections.push(
      { id: 'sys-health', label: 'System health', icon: '◉' },
      { id: 'feature-flags', label: 'Feature flags', icon: '⌥' },
      { id: 'backup-restore', label: 'Backup restore', icon: '↺' },
      { id: 'sql-copilot', label: 'SQL copilot', icon: '⌘' },
    );
  }
  if (me.workerId) {
    sections.push(
      { id: 'today', label: "Today's run", icon: '◐' },
      { id: 'earnings', label: 'Earnings', icon: '$' },
      { id: 'streak', label: 'Streak + badges', icon: '✧' },
    );
  }
  if (me.email) {
    sections.push(
      { id: 'next-service', label: 'Next service', icon: '◔' },
      { id: 'subscriptions', label: 'My plans', icon: '↺' },
      { id: 'recurring-preview', label: 'Schedule preview', icon: '☷' },
      { id: 'photos', label: 'Photos', icon: '◇' },
      { id: 'spend-insights', label: 'My spend', icon: '◓' },
      { id: 'referrals', label: 'Referrals', icon: '↗' },
      { id: 'calendar-export', label: 'Calendar export', icon: '◰' },
      { id: 'me', label: 'My page', icon: '☉' },
    );
  }
  sections.push({ id: 'plans', label: 'Plans catalog', icon: '☷' });
  sections.push({ id: 'settings', label: 'Settings', icon: '⚙' });
  return sections;
}

function RoleBadge({ role }: { role: Role }) {
  const colors: Record<Role, string> = {
    super_admin: 'border-purple-500/50 bg-purple-500/10 text-purple-300',
    admin: 'border-brand-accent/50 bg-brand-accent/10 text-brand-accent',
    crew: 'border-emerald-500/50 bg-emerald-500/10 text-emerald-300',
    customer: 'border-blue-500/50 bg-blue-500/10 text-blue-300',
    guest: 'border-brand-line bg-bg-elevated text-brand-mute',
  };
  return (
    <span
      className={`rounded-md border px-2 py-1 font-mono text-[10px] uppercase tracking-widest ${colors[role]}`}
    >
      {role.replace('_', ' ')}
    </span>
  );
}

function KpiStrip({ stats }: { stats: Record<string, number | string> }) {
  return (
    <dl className="grid grid-cols-2 gap-2 sm:grid-cols-4">
      {Object.entries(stats).map(([k, v]) => (
        <div
          key={k}
          className="rounded-2xl border border-brand-line bg-bg-elevated p-3"
          style={{ viewTransitionName: `bcl-kpi-${k.replace(/\W+/g, '-').toLowerCase()}` }}
        >
          <dt className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">{k}</dt>
          <dd className="mt-1 text-2xl font-bold text-brand-ink">{v}</dd>
        </div>
      ))}
    </dl>
  );
}

function OverviewPanel({ me, feed, bearer }: { me: WhoAmI; feed: FeedEvent[]; bearer: string }) {
  void bearer;
  const greeting =
    me.role === 'admin' || me.role === 'super_admin'
      ? 'Ops console'
      : me.role === 'crew'
        ? 'Welcome back, crew'
        : 'Welcome back';

  // AI-generated next-action chips. Built from the most recent feed entries
  // so the suggestion is grounded in real activity, not vibes. Fails silent
  // if the AI route is unavailable.
  const [suggestions, setSuggestions] = useState<
    Array<{ label: string; action: string; reason: string }>
  >([]);
  useEffect(() => {
    if (feed.length === 0) return;
    const summary = feed
      .slice(0, 8)
      .map((e) => `${e.kind}: ${e.title} — ${e.subtitle} (${e.ago})`)
      .join('\n');
    void (async () => {
      try {
        const res = await fetch('/api/ai/smart-suggestions', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ role: me.role, recentActivitySummary: summary }),
        });
        const json = (await res.json()) as {
          ok: boolean;
          suggestions?: Array<{ label: string; action: string; reason: string }>;
        };
        if (json.ok && Array.isArray(json.suggestions)) setSuggestions(json.suggestions);
      } catch {
        /* silent */
      }
    })();
  }, [feed, me.role]);

  return (
    <div className="space-y-4">
      <header className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
        <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-brand-accent">
          {greeting}
        </p>
        <h1 className="mt-1 text-2xl font-bold text-brand-ink">{me.displayName ?? 'Dashboard'}</h1>
        <p className="mt-1 text-sm text-brand-mute">
          Role-aware controls below. Use <kbd className="rounded bg-bg-primary px-1">Cmd+K</kbd> for
          the command palette.
        </p>
        {suggestions.length > 0 && (
          <Suspense fallback={null}>
            <div className="mt-4">
              <p className="mb-2 font-mono text-[10px] uppercase tracking-widest text-brand-mute">
                AI suggests
              </p>
              <RecommendationChips
                items={suggestions}
                onAction={(action) => {
                  // Action strings are slash-paths (/book, /admin/ai, etc).
                  if (action.startsWith('/')) window.location.assign(action);
                }}
              />
            </div>
          </Suspense>
        )}
      </header>

      <section
        className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
        aria-labelledby="feed-title"
      >
        <div className="mb-3 flex items-baseline justify-between gap-3">
          <h2
            id="feed-title"
            className="font-mono text-[11px] uppercase tracking-[0.18em] text-brand-accent"
          >
            Activity
          </h2>
          <p className="text-xs text-brand-mute">{feed.length} events</p>
        </div>
        {feed.length === 0 ? (
          <p className="text-sm text-brand-mute" data-enter>
            No activity yet. New bookings + subscriptions show up here in real time.
          </p>
        ) : (
          <ul className="space-y-2">
            {feed.slice(0, 12).map((e) => (
              <li
                key={e.id}
                data-enter
                className="flex items-start gap-3 rounded-lg border border-brand-line bg-bg-primary p-3"
                style={{ viewTransitionName: `bcl-feed-${e.id}` }}
              >
                <span
                  aria-hidden
                  className={`mt-1 inline-block h-2 w-2 shrink-0 rounded-full ${
                    e.severity === 'error'
                      ? 'bg-red-400'
                      : e.severity === 'warn'
                        ? 'bg-amber-400'
                        : e.severity === 'success'
                          ? 'bg-emerald-400'
                          : 'bg-brand-accent'
                  }`}
                />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm text-brand-ink">
                    {e.href ? (
                      <a href={e.href} className="hover:text-brand-accent">
                        {e.title}
                      </a>
                    ) : (
                      e.title
                    )}
                  </p>
                  <p className="truncate text-xs text-brand-mute">{e.subtitle}</p>
                </div>
                <span className="font-mono text-[10px] text-brand-mute">{e.ago}</span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function AdminSubsPanel({ bearer }: { bearer: string }) {
  const [data, setData] = useState<{
    activeCount: number;
    mrrCents: number;
    pendingCount: number;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    if (!bearer) {
      setLoading(false);
      return;
    }
    void (async () => {
      try {
        const res = await fetch('/api/admin/subscriptions/stats', {
          headers: { authorization: `Bearer ${bearer}` },
        });
        const json = (await res.json()) as {
          ok: boolean;
          stats?: { activeCount: number; mrrCents: number; pendingCount: number };
        };
        if (json.ok && json.stats) setData(json.stats);
      } finally {
        setLoading(false);
      }
    })();
  }, [bearer]);

  if (loading) return <p className="text-sm text-brand-mute">Loading…</p>;
  if (!data)
    return (
      <p className="text-sm text-brand-mute">
        Add the owner key in Settings to view subscription stats.
      </p>
    );
  return (
    <div className="rounded-2xl border border-brand-line bg-bg-elevated p-5 space-y-4">
      <h2 className="text-xl font-bold text-brand-ink">Subscriptions</h2>
      <dl className="grid grid-cols-3 gap-3 text-sm">
        <Stat label="Active" value={data.activeCount.toString()} />
        <Stat label="MRR" value={usd0(data.mrrCents)} />
        <Stat label="Pending" value={data.pendingCount.toString()} />
      </dl>
    </div>
  );
}

// CrewTodayPanel replaced by the lazy-loaded TodaysRun + EarningsTicker
// + NextGigOfferTimer panels imported above.

function SettingsPanel({
  bearer,
  onBearerChange,
  me,
}: {
  bearer: string;
  onBearerChange: (v: string) => void;
  me: WhoAmI;
}) {
  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-brand-line bg-bg-elevated p-5 space-y-4">
        <h2 className="text-xl font-bold text-brand-ink">Settings</h2>
        <label className="block text-sm">
          <span className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
            Owner invoice key (admin features)
          </span>
          <input
            type="password"
            value={bearer}
            onChange={(e) => onBearerChange(e.target.value.trim())}
            placeholder="bearer key — stored in this browser only"
            className="mt-1 w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink"
          />
        </label>
        <p className="text-xs text-brand-mute">
          Logged in as <strong>{me.role}</strong>
          {me.email ? ` (${me.email})` : me.workerId ? ` · ${me.workerId.slice(0, 12)}` : ''}.
        </p>
      </div>
      <div className="rounded-2xl border border-brand-line bg-bg-elevated p-5 space-y-4">
        <h3 className="text-lg font-bold text-brand-ink">Appearance</h3>
        <Suspense fallback={null}>
          <ThemeSwitcher />
          <DensityToggle />
        </Suspense>
      </div>
      <div className="rounded-2xl border border-brand-line bg-bg-elevated p-5 space-y-2">
        <h3 className="text-lg font-bold text-brand-ink">Keyboard shortcuts</h3>
        <p className="text-sm text-brand-mute">
          Press <kbd className="rounded bg-bg-primary px-1">Cmd+/</kbd> from anywhere on the
          dashboard to open the shortcuts overlay.
        </p>
      </div>
    </div>
  );
}

function GuestView({
  onAdminBearer,
  bearer,
}: {
  onAdminBearer: (v: string) => void;
  bearer: string;
}) {
  return (
    <main className="bg-bg-primary min-h-screen pb-24">
      <section className="mx-auto max-w-2xl px-4 pt-16">
        <p className="mb-3 font-mono text-[11px] uppercase tracking-[0.18em] text-brand-accent">
          Dashboard
        </p>
        <h1 className="mb-3 text-3xl font-bold leading-tight text-brand-ink sm:text-4xl">
          Sign in to see your dashboard.
        </h1>
        <p className="mb-8 text-brand-mute">
          Customers + crew + operators all land here. Choose your sign-in.
        </p>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <a
            href="/login/customer"
            className="rounded-2xl border border-brand-line bg-bg-elevated p-5 hover:border-brand-accent"
          >
            <p className="font-mono text-[10px] uppercase tracking-widest text-brand-accent">
              Customer
            </p>
            <p className="mt-1 text-lg font-bold text-brand-ink">Sign in →</p>
          </a>
          <a
            href="/login/crew"
            className="rounded-2xl border border-brand-line bg-bg-elevated p-5 hover:border-brand-accent"
          >
            <p className="font-mono text-[10px] uppercase tracking-widest text-brand-accent">
              Crew
            </p>
            <p className="mt-1 text-lg font-bold text-brand-ink">Sign in →</p>
          </a>
        </div>
        <details className="mt-8 rounded-2xl border border-brand-line bg-bg-elevated p-5">
          <summary className="cursor-pointer font-mono text-[10px] uppercase tracking-widest text-brand-mute">
            Operator access
          </summary>
          <label className="mt-3 block text-sm">
            <span className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
              Owner invoice key
            </span>
            <input
              type="password"
              value={bearer}
              onChange={(e) => onAdminBearer(e.target.value.trim())}
              placeholder="paste once — stored in this browser only"
              className="mt-1 w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink"
            />
          </label>
        </details>
      </section>
    </main>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-brand-line bg-bg-primary px-3 py-2">
      <dt className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">{label}</dt>
      <dd className="mt-1 text-base text-brand-ink">{value}</dd>
    </div>
  );
}
