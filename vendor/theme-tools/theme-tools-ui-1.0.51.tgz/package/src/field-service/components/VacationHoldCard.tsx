import { useThemeToolsSurface } from '../../field-service-primitives.js';
/**
 * VacationHoldCard.tsx — drop-in card for /me letting a recurring-subscription
 * customer "snooze" their plan for 14/30/60 days (or pick a custom return
 * date). Gated by feature flag `vacation_hold`; renders `null` when off.
 *
 * The component is intentionally NOT wired into App.tsx — it's a self-contained
 * surface a parent screen can drop into its render tree. Submission goes
 * straight to `POST /api/vacation-hold/pause` and the parent receives an
 * `onPaused` callback when the hold lands.
 */
import { useState } from 'react';
import { useFeatureFlag } from '../use-feature-flag.js';

interface Props {
  /** The recurring_subscriptions.id we want to pause. */
  recurringSubscriptionId: string;
  /** Human-readable label of the plan (e.g. "Weekly lawn care"). */
  planLabel: string;
  /** Called once the server returns ok=true so the parent can refresh its list. */
  onPaused?: (holdId: string, pausedUntilYmd: string) => void;
}

interface ActiveHold {
  id: string;
  pausedUntil: string;
}

const PRESETS: ReadonlyArray<{ label: string; days: number }> = [
  { label: 'Snooze 14 days', days: 14 },
  { label: 'Snooze 30 days', days: 30 },
  { label: 'Snooze 60 days', days: 60 },
];

function todayYmd(): string {
  return new Date().toISOString().slice(0, 10);
}

function addDaysYmd(ymd: string, days: number): string {
  const t = Date.parse(`${ymd}T00:00:00Z`);
  return new Date(t + days * 86_400_000).toISOString().slice(0, 10);
}

export function VacationHoldCard(props: Props): JSX.Element | null {
  useThemeToolsSurface('vacation-hold-card');
  const enabled = useFeatureFlag('vacation_hold');
  const [submitting, setSubmitting] = useState<number | 'custom' | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [customUntil, setCustomUntil] = useState<string>(addDaysYmd(todayYmd(), 30));
  const [customOpen, setCustomOpen] = useState(false);
  const [activeHold, setActiveHold] = useState<ActiveHold | null>(null);

  const minUntil = addDaysYmd(todayYmd(), 1);
  const maxUntil = addDaysYmd(todayYmd(), 90);
  const customValid = customUntil >= minUntil && customUntil <= maxUntil;

  if (!enabled) return null;

  async function submit(pausedUntil: string, key: number | 'custom'): Promise<void> {
    setSubmitting(key);
    setError(null);
    try {
      const r = await fetch('/api/vacation-hold/pause', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          recurringSubscriptionId: props.recurringSubscriptionId,
          pausedFrom: todayYmd(),
          pausedUntil,
          reason: 'vacation',
        }),
      });
      const j = (await r.json()) as { ok: boolean; id?: string; error?: string };
      if (!r.ok || !j.ok || !j.id) {
        setError(
          j.error === 'hold_too_long' || j.error === 'invalid_input'
            ? 'Choose a return date within the next 90 days.'
            : 'We could not snooze this plan. Please try again.',
        );
        return;
      }
      setActiveHold({ id: j.id, pausedUntil });
      props.onPaused?.(j.id, pausedUntil);
    } catch {
      setError('We could not reach the plan service. Check your connection and try again.');
    } finally {
      setSubmitting(null);
    }
  }

  async function finishHold(action: 'resume' | 'cancel'): Promise<void> {
    if (!activeHold) return;
    setSubmitting('custom');
    setError(null);
    try {
      const r = await fetch(`/api/vacation-hold/${action}/${encodeURIComponent(activeHold.id)}`, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'content-type': 'application/json' },
        body: '{}',
      });
      const j = (await r.json().catch(() => null)) as { ok?: boolean } | null;
      if (!r.ok || !j?.ok) {
        setError(`We could not ${action} this hold. Please try again.`);
        return;
      }
      setActiveHold(null);
    } catch {
      setError('We could not reach the plan service. Check your connection and try again.');
    } finally {
      setSubmitting(null);
    }
  }

  return (
    <section
      className="rounded-xl border border-brand-line bg-bg-primary p-4"
      data-testid="vacation-hold-card"
      aria-label="Pause subscription"
    >
      <header>
        <h3 className="font-bold text-brand-ink">Heading out of town?</h3>
        <p className="text-sm text-brand-mute">{props.planLabel}</p>
      </header>
      {activeHold ? (
        <div
          className="mt-3 rounded-lg border border-emerald-500/40 bg-emerald-950/30 p-3"
          data-testid="vacation-hold-success"
          role="status"
        >
          <p className="font-semibold text-emerald-200">Plan snoozed</p>
          <p className="mt-1 text-sm text-brand-ink">
            Recurring visits resume after {activeHold.pausedUntil}.
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            <button
              type="button"
              className="btn btn-primary text-sm"
              disabled={submitting !== null}
              onClick={() => void finishHold('resume')}
              data-testid="vacation-hold-resume"
            >
              {submitting ? 'Saving…' : 'Resume now'}
            </button>
            <button
              type="button"
              className="btn btn-secondary text-sm"
              disabled={submitting !== null}
              onClick={() => void finishHold('cancel')}
              data-testid="vacation-hold-cancel"
            >
              Cancel hold
            </button>
          </div>
        </div>
      ) : (
        <div className="mt-3 flex flex-wrap gap-2" role="group" aria-label="Snooze duration">
          {PRESETS.map((preset) => (
            <button
              key={preset.days}
              type="button"
              className="btn btn-secondary text-sm"
              disabled={submitting !== null}
              onClick={() => submit(addDaysYmd(todayYmd(), preset.days), preset.days)}
              data-testid={`vacation-hold-${preset.days}`}
            >
              {submitting === preset.days ? '…' : preset.label}
            </button>
          ))}
          <button
            type="button"
            className="btn btn-secondary text-sm"
            onClick={() => setCustomOpen((v) => !v)}
            aria-expanded={customOpen}
            data-testid="vacation-hold-custom-toggle"
          >
            Custom date
          </button>
        </div>
      )}
      {customOpen && !activeHold && (
        <div className="mt-3 grid gap-2 rounded-lg border border-brand-line bg-bg-elevated p-3 sm:grid-cols-[1fr_auto] sm:items-end">
          <label className="text-sm text-brand-ink" htmlFor="vh-until">
            Resume on
            <input
              className="mt-1 block w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-brand-ink"
              id="vh-until"
              type="date"
              value={customUntil}
              min={minUntil}
              max={maxUntil}
              aria-invalid={!customValid}
              aria-describedby={!customValid ? 'vh-date-error' : undefined}
              onChange={(e) => setCustomUntil(e.target.value)}
              data-testid="vacation-hold-custom-date"
            />
          </label>
          <button
            type="button"
            className="btn btn-primary text-sm"
            onClick={() => submit(customUntil, 'custom')}
            disabled={submitting !== null || !customValid}
            data-testid="vacation-hold-custom-submit"
          >
            {submitting === 'custom' ? 'Saving…' : 'Snooze until that date'}
          </button>
          {!customValid && (
            <p id="vh-date-error" className="text-sm text-rose-300 sm:col-span-2" role="alert">
              Choose a date from tomorrow through {maxUntil}.
            </p>
          )}
        </div>
      )}
      {error && (
        <div
          className="mt-3 rounded-lg border border-rose-700/50 bg-rose-950/30 p-3 text-sm text-rose-200"
          role="alert"
          data-testid="vacation-hold-error"
        >
          {error}
        </div>
      )}
      <p className="mt-3 text-xs text-brand-mute">
        We&apos;ll skip recurring visits during the hold and move your next visit past the return
        date. Billing collection pauses with the plan and resumes when the hold ends.
      </p>
    </section>
  );
}

export default VacationHoldCard;
