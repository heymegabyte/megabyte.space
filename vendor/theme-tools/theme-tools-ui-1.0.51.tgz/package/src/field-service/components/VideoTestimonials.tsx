import { useThemeToolsSurface } from '../../field-service-primitives.js';
/**
 * VideoTestimonials — customer video review submission + showcase page.
 * Route: /testimonials (linked from /refer and post-job follow-ups).
 *
 * States: prompt → recording (placeholder until real video capture) →
 *         submitted → error. Review JSON-LD emitted for SEO.
 */
import { useState, useMemo } from 'react';
import { PHONE_DISPLAY } from '@theme.tools/i18n-a11y/field-service/contact-phone';

const REWARD_AMOUNT = 25;

export function VideoTestimonials(): JSX.Element {
  useThemeToolsSurface('video-testimonials');
  const [submitted, setSubmitted] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [reviewText, setReviewText] = useState('');
  const [rating, setRating] = useState(5);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !reviewText.trim()) return;
    setSubmitted(true);
  };

  const jsonLd = useMemo(() => ({
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    name: 'Customer Testimonials — Brick Labor',
    description: 'Real reviews from Newark NJ neighbors who booked Brick Labor for moving, cleanouts, hauling, and yard work.',
    url: 'https://bricklabor.com/testimonials',
    ...(submitted && {
      review: {
        '@type': 'Review',
        author: { '@type': 'Person', name: customerName },
        reviewBody: reviewText,
        reviewRating: { '@type': 'Rating', ratingValue: rating, bestRating: 5 },
        itemReviewed: { '@type': 'LocalBusiness', name: 'Brick Labor', address: { '@type': 'PostalAddress', addressLocality: 'Newark', addressRegion: 'NJ' } },
      },
    }),
  }), [submitted, customerName, reviewText, rating]);

  return (
    <main className="container-pad py-12 max-w-3xl mx-auto" aria-label="Customer testimonials">
      {jsonLd && (
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      )}

      <header className="mb-10">
        <div className="font-mono text-xs uppercase tracking-wider text-brand-accent">Social proof</div>
        <h1 className="mt-2 text-4xl font-bold text-brand-fg sm:text-5xl">Share your experience</h1>
        <p className="mt-4 text-lg text-brand-mute">
          Real reviews from Newark neighbors. Record a 30-second video or write a review —
          get <strong className="text-brand-accent">${REWARD_AMOUNT} off</strong> your next job.
        </p>
      </header>

      {!submitted ? (
        <div className="grid gap-8 md:grid-cols-2">
          {/* Video prompt card */}
          <div className="rounded-xl border border-brand-line bg-brand-card p-6 text-center">
            <div className="text-5xl mb-3">🎥</div>
            <h2 className="text-xl font-bold text-brand-fg mb-2">Record a video</h2>
            <p className="text-sm text-brand-mute mb-4">
              A quick 30-second clip about your experience. We'll send a recording link
              after your next booking.
            </p>
            <a href="/book" className="inline-block rounded-lg bg-brand-accent px-5 py-2.5 text-sm font-bold text-bg-primary hover:bg-brand-accent/90 transition-colors">
              Book first →
            </a>
          </div>

          {/* Written review form */}
          <div className="rounded-xl border border-brand-line bg-brand-card p-6">
            <h2 className="text-xl font-bold text-brand-fg mb-4">Write a review</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-brand-mute mb-1">Your name</label>
                <input type="text" required value={customerName} onChange={e => setCustomerName(e.target.value)}
                  className="w-full rounded-lg border border-brand-line bg-bg-primary px-3 py-2.5 text-sm text-brand-ink focus:outline-none focus:ring-2 focus:ring-brand-accent" />
              </div>
              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-brand-mute mb-1">Rating</label>
                <div className="flex gap-1 text-2xl">
                  {[1,2,3,4,5].map(n => (
                    <button key={n} type="button" onClick={() => setRating(n)}
                      className={`focus:outline-none ${n <= rating ? 'text-yellow-400' : 'text-brand-line'}`}>
                      ★
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-brand-mute mb-1">Your review</label>
                <textarea required value={reviewText} onChange={e => setReviewText(e.target.value)} rows={4}
                  placeholder="The crew showed up on time and..."
                  className="w-full rounded-lg border border-brand-line bg-bg-primary px-3 py-2.5 text-sm text-brand-ink focus:outline-none focus:ring-2 focus:ring-brand-accent resize-none" />
              </div>
              <button type="submit"
                className="w-full rounded-lg bg-brand-accent px-4 py-3 text-sm font-bold text-bg-primary hover:bg-brand-accent/90 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent focus-visible:ring-offset-2 focus-visible:ring-offset-brand-card">
                Submit review
              </button>
            </form>
          </div>
        </div>
      ) : (
        <div className="rounded-xl border border-brand-line bg-brand-card p-10 text-center">
          <div className="text-5xl mb-4">✅</div>
          <h2 className="text-2xl font-bold text-brand-fg mb-2">Thanks, {customerName}!</h2>
          <p className="text-brand-mute mb-4">
            Your review helps Newark neighbors find reliable labor.
            <strong className="text-brand-accent"> ${REWARD_AMOUNT} off</strong> your next job —
            mention it when you book.
          </p>
          <a href="/book" className="inline-block rounded-lg bg-brand-accent px-6 py-3 text-sm font-bold text-bg-primary hover:bg-brand-accent/90 transition-colors">
            Book your next job →
          </a>
        </div>
      )}

      <footer className="mt-12 border-t border-brand-line pt-6 text-sm text-brand-mute text-center">
        <p>Prefer to leave a Google review? Find us on{' '}
          <a href="https://g.page/bricklabor" target="_blank" rel="noopener noreferrer" className="underline hover:text-brand-accent">
            Google Maps
          </a>{' '}or call {PHONE_DISPLAY}.</p>
      </footer>
    </main>
  );
}
