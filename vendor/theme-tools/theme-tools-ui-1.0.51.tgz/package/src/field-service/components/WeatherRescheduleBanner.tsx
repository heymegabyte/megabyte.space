import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { useCallback, useEffect, useState } from 'react';
import { useFeatureFlag } from '../use-feature-flag.js';

interface WeatherOffer {
  id: string;
  proposedNewAt: string;
  acceptedAt: string | null;
  rejectedAt: string | null;
  opsEscalatedAt: string | null;
  forecastSummary: { notes?: readonly string[]; periodName?: string };
}

type ViewState =
  | { kind: 'loading' }
  | { kind: 'clear' }
  | { kind: 'error' }
  | { kind: 'ready'; offer: WeatherOffer };

export function WeatherRescheduleBanner({ bookingId }: { readonly bookingId: string }) {
  useThemeToolsSurface('weather-reschedule-banner');
  const enabled = useFeatureFlag('weather_reschedule_agent');
  const [view, setView] = useState<ViewState>({ kind: 'loading' });
  const [busy, setBusy] = useState<'accept' | 'reject' | null>(null);
  const [actionError, setActionError] = useState('');

  const load = useCallback(async () => {
    setView({ kind: 'loading' });
    try {
      const response = await fetch(
        `/api/weather-reschedule-agent/booking/${encodeURIComponent(bookingId)}/offer`,
        { credentials: 'include' },
      );
      if (!response.ok) { setView({ kind: 'error' }); return; }
      const body = await response.json() as { offer?: WeatherOffer | null };
      setView(body.offer?.id ? { kind: 'ready', offer: body.offer } : { kind: 'clear' });
    } catch { setView({ kind: 'error' }); }
  }, [bookingId]);

  useEffect(() => { if (enabled) void load(); }, [enabled, load]);
  if (!enabled || view.kind === 'clear') return null;
  if (view.kind === 'loading') return <p role="status" className="mt-3 text-sm text-brand-mute">Checking weather plan…</p>;
  if (view.kind === 'error') {
    return (
      <div role="alert" className="mt-3 rounded-xl border border-brand-line p-3 text-sm">
        <p>Weather plan is temporarily unavailable.</p>
        <button type="button" onClick={() => void load()} className="mt-2 min-h-[44px] rounded-md border border-brand-line px-4 font-semibold">Try again</button>
      </div>
    );
  }

  const { offer } = view;
  const resolved = offer.acceptedAt
    ? 'accepted'
    : offer.rejectedAt
      ? 'rejected'
      : offer.opsEscalatedAt
        ? 'expired'
        : null;
  const act = async (action: 'accept' | 'reject') => {
    setBusy(action); setActionError('');
    try {
      const response = await fetch(`/api/weather-reschedule-agent/${action}/${encodeURIComponent(offer.id)}`, {
        method: 'POST', credentials: 'include', headers: { 'content-type': 'application/json' },
        body: action === 'reject' ? JSON.stringify({ reason: 'Customer kept original time in dashboard' }) : '{}',
      });
      if (!response.ok && response.status !== 409) { setActionError('Could not save your choice. Try again.'); return; }
      await load();
    } catch { setActionError('Connection issue while saving your choice. Try again.'); }
    finally { setBusy(null); }
  };
  const proposed = new Date(offer.proposedNewAt).toLocaleString('en-US', {
    weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit',
  });
  const forecast = offer.forecastSummary.notes?.join(' · ') || offer.forecastSummary.periodName || 'Weather may affect this job.';

  return (
    <section aria-label="Weather reschedule offer" data-testid="weather-reschedule-banner" className="mt-3 rounded-xl border border-amber-500/40 bg-amber-500/10 p-4">
      <h4 className="font-semibold text-brand-ink">Weather plan</h4>
      {resolved === 'accepted' ? <p role="status" className="mt-1 text-sm">Rescheduled to {proposed}.</p>
        : resolved === 'rejected' ? <p role="status" className="mt-1 text-sm">Original time kept.</p>
        : resolved === 'expired' ? <p role="status" className="mt-1 text-sm">This offer expired. Your original time is still booked.</p>
        : <>
            <p className="mt-1 break-words text-sm text-brand-mute">{forecast}</p>
            <p className="mt-1 text-sm">Move to <strong>{proposed}</strong>?</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <button type="button" disabled={busy !== null} aria-busy={busy === 'accept'} onClick={() => void act('accept')} className="min-h-[44px] rounded-md bg-brand-accent px-4 font-semibold text-bg-primary disabled:opacity-60">{busy === 'accept' ? 'Rescheduling…' : 'Reschedule'}</button>
              <button type="button" disabled={busy !== null} aria-busy={busy === 'reject'} onClick={() => void act('reject')} className="min-h-[44px] rounded-md border border-brand-line px-4 font-semibold disabled:opacity-60">{busy === 'reject' ? 'Keeping…' : 'Keep original time'}</button>
            </div>
          </>}
      {actionError && <p role="alert" className="mt-2 text-sm text-red-300">{actionError}</p>}
    </section>
  );
}
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
