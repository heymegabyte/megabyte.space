import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect, useMemo, useRef, useState } from 'react';
import { CREW_TIERS, estimateCrewEarnings, type CrewTier } from '@theme.tools/billing/field-service/crew-earnings';
import { nextRadioIndex, rovingTabIndex } from '@theme.tools/i18n-a11y/field-service/radio-keynav';

const usd = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
  maximumFractionDigits: 0,
});

function capture(event: string, props?: Record<string, unknown>) {
  try {
    const w = window as unknown as {
      posthog?: { capture: (n: string, p?: Record<string, unknown>) => void };
    };
    w.posthog?.capture(event, props);
  } catch {
    /* noop */
  }
}

export function WorkLanding() {
  useThemeToolsSurface('work-landing');
  useEffect(() => {
    const path = typeof window !== 'undefined' ? window.location.pathname : '/work';
    capture('worker_application_started', { path });
  }, []);

  return (
    <>
      <article className="section">
        <div className="container-pad max-w-4xl">
          <p className="eyebrow mb-3">Crew</p>
          <h1 className="text-4xl sm:text-6xl font-extrabold mb-4">
            Weekly cash. Your gear. Our gigs.
          </h1>
          <p className="text-lg sm:text-xl text-brand-mute mb-8 leading-relaxed max-w-2xl">
            Pick up local labor jobs across Essex, Hudson, and Union counties. No platform fees. No
            call center. Apply in 60 seconds, get dispatched the same day.
          </p>
          <div className="flex flex-wrap items-center gap-3">
            <a href="/login/crew" className="btn-primary">
              Apply to join the crew →
            </a>
            <a href="#earnings" className="text-brand-mute underline-hover">
              See what you could earn
            </a>
          </div>
        </div>
      </article>

      <article id="how" className="section bg-brand-card/30">
        <div className="container-pad max-w-4xl">
          <p className="eyebrow mb-3">How it works</p>
          <h2 className="text-3xl sm:text-4xl font-extrabold mb-8">5 steps. No middlemen.</h2>
          <ol className="grid grid-cols-1 sm:grid-cols-5 gap-4">
            <Step n={1} title="Apply" body="Phone + name. We text you a code." />
            <Step n={2} title="Profile" body="Photo, radius, vehicle, optional license." />
            <Step n={3} title="Get pinged" body="SMS when a gig matches you." />
            <Step n={4} title="Clock in" body="GPS check-in at the address." />
            <Step n={5} title="Get paid" body="Direct deposit, weekly. 1099-NEC at year-end." />
          </ol>
        </div>
      </article>

      <article className="section">
        <div className="container-pad max-w-4xl">
          <p className="eyebrow mb-3">Pay & tiers</p>
          <h2 className="text-3xl sm:text-4xl font-extrabold mb-8">
            Start at $25/hr. Top out at $40/hr.
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {CREW_TIERS.map((tier) => (
              <TierCard key={tier.slug} tier={tier} accent={tier.slug === 'pro'} />
            ))}
          </div>
          <p className="text-sm text-brand-mute mt-4">
            Plus: $15 driving bonus per U-Haul rental run · $25 hauling bonus when you bring the
            truck · 1.5x on emergency callouts after 8pm.
          </p>
          <div className="mt-8 inline-flex items-center gap-3 rounded-2xl border border-brand-line bg-brand-card px-4 py-3 text-sm text-brand-mute">
            <PayoutLogo />
            <span>
              <strong className="text-brand-ink">Powered by Stripe Connect.</strong> Direct deposit
              every Friday for the prior week — or tap instant payout to your debit card, Cash App,
              Venmo, or Zelle any day (1.5% fee).
            </span>
          </div>
        </div>
      </article>

      <EarningsEstimator />

      <article className="section bg-brand-card/30">
        <div className="container-pad max-w-4xl">
          <p className="eyebrow mb-3">FAQ</p>
          <h2 className="text-3xl sm:text-4xl font-extrabold mb-8">Common questions</h2>
          <div className="space-y-6">
            <FAQItem
              q="Do I need a driver's license?"
              a="No — most gigs are labor-only. Optional for driving customer rentals (e.g. U-Haul). Upload your license front/back on your profile if you want driving work."
            />
            <FAQItem
              q="What gear do I need?"
              a="Closed-toe boots, gloves, water. Power tools and a truck are bonuses — they unlock higher-paying gigs."
            />
            <FAQItem
              q="Is this W-2 or 1099?"
              a="1099-NEC contractor. You set your own schedule, accept or decline any gig, and we issue a 1099 in January if you cross $600 for the year."
            />
            <FAQItem
              q="How fast do I get paid?"
              a="Direct deposit every Friday for the prior week's completed gigs via Stripe Connect Express — usually hits your bank Monday morning. Need it sooner? Tap instant payout to your debit card and we send it within 30 minutes (1.5% fee applies)."
            />
            <FAQItem
              q="What about insurance?"
              a="We carry general liability on every gig. You're covered while clocked in. Workers' comp is bundled — you sign the ack form on your first job."
            />
          </div>
        </div>
      </article>

      <article className="section">
        <div className="container-pad max-w-3xl text-center">
          <h2 className="text-3xl sm:text-4xl font-extrabold mb-4">Ready to clock in?</h2>
          <p className="text-brand-mute mb-6">60-second SMS sign-up. No résumé.</p>
          <a href="/login/crew" className="btn-primary">
            Apply now →
          </a>
          <p className="mt-6 text-sm text-brand-mute">
            Already on the crew?{' '}
            <a href="/work/payouts" className="text-brand-accent underline-hover">
              Manage payouts →
            </a>
          </p>
        </div>
      </article>
    </>
  );
}

/**
 * Interactive crew earnings estimator — the recruiting mirror of the customer
 * `/book` estimate sidebar. Pick a tier + drag the hours slider → live weekly +
 * monthly take-home, computed by the SHARED `estimateCrewEarnings()` so the
 * recruiting number can never drift from the canonical wage ladder.
 */
function EarningsEstimator() {
  const [slug, setSlug] = useState<CrewTier['slug']>('apprentice');
  const [hours, setHours] = useState(20);
  const radioRefs = useRef<(HTMLButtonElement | null)[]>([]);

  // ARIA radio-group keyboard contract: arrow/Home/End move selection AND focus
  // between tier options (the group is a single tab stop via rovingTabIndex below).
  // axe-core can't catch this gap — the keyboard E2E in e2e/crew-earnings-estimator
  // is the only guard against regression.
  const onTierKeyDown = (e: React.KeyboardEvent<HTMLButtonElement>, index: number) => {
    const target = nextRadioIndex(index, CREW_TIERS.length, e.key);
    if (target === null) return;
    e.preventDefault();
    const opt = CREW_TIERS[target];
    if (!opt) return;
    setSlug(opt.slug);
    capture('crew_earnings_tier_selected', { tier: opt.slug });
    radioRefs.current[target]?.focus();
  };

  const tier: CrewTier = CREW_TIERS.find((t) => t.slug === slug) ?? CREW_TIERS[0]!;
  const est = useMemo(
    () => estimateCrewEarnings({ hourlyRateCents: tier.hourlyRateCents, hoursPerWeek: hours }),
    [tier.hourlyRateCents, hours],
  );

  return (
    <article id="earnings" className="section">
      <div className="container-pad max-w-4xl">
        <p className="eyebrow mb-3">Your take-home</p>
        <h2 className="text-3xl sm:text-4xl font-extrabold mb-2">See what you could earn.</h2>
        <p className="text-brand-mute mb-8 max-w-2xl leading-relaxed">
          Pick your tier and how many hours a week you want. This is labor pay only — driving,
          hauling, after-hours, and tips all stack on top.
        </p>

        <div className="rounded-2xl border border-brand-line bg-brand-card p-6 sm:p-8">
          <fieldset>
            <legend className="text-xs uppercase tracking-wider text-brand-mute mb-3">
              Your tier
            </legend>
            <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="Crew tier">
              {CREW_TIERS.map((t, index) => {
                const selected = t.slug === slug;
                return (
                  <button
                    key={t.slug}
                    ref={(el) => {
                      radioRefs.current[index] = el;
                    }}
                    type="button"
                    role="radio"
                    aria-checked={selected}
                    tabIndex={rovingTabIndex(selected)}
                    data-bcl-tier={t.slug}
                    data-testid={`tier-${t.slug}`}
                    onClick={() => {
                      setSlug(t.slug);
                      capture('crew_earnings_tier_selected', { tier: t.slug });
                    }}
                    onKeyDown={(e) => onTierKeyDown(e, index)}
                    className={`rounded-full px-4 py-2 text-sm font-medium transition-all duration-[333ms] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent ${
                      selected
                        ? 'bg-brand-accent text-brand-bg shadow-md'
                        : 'border border-brand-line bg-brand-bg text-brand-ink hover:-translate-y-0.5 hover:border-brand-accent/50'
                    }`}
                  >
                    {t.displayName}
                    <span className="ml-1.5 tabular-nums opacity-80">
                      ${Math.round(t.hourlyRateCents / 100)}/hr
                    </span>
                  </button>
                );
              })}
            </div>
          </fieldset>

          <div className="mt-6">
            <label htmlFor="hours-range" className="flex items-baseline justify-between mb-2">
              <span className="text-xs uppercase tracking-wider text-brand-mute">Hours per week</span>
              <span className="text-base font-extrabold text-brand-ink tabular-nums">
                {hours} hrs
              </span>
            </label>
            <input
              id="hours-range"
              type="range"
              min={5}
              max={60}
              step={1}
              value={hours}
              data-testid="hours-range"
              aria-label="Hours per week"
              aria-valuetext={`${hours} hours per week`}
              onChange={(e) => setHours(Number(e.target.value))}
              onMouseUp={() => capture('crew_earnings_hours_changed', { hours, tier: slug })}
              className="w-full accent-brand-accent cursor-pointer"
            />
            <div className="flex justify-between text-xs text-brand-mute mt-1 tabular-nums">
              <span>5</span>
              <span>60</span>
            </div>
          </div>

          <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="rounded-2xl border border-brand-accent/40 bg-brand-accent/5 p-5">
              <p className="text-xs uppercase tracking-wider text-brand-mute mb-1">Per week</p>
              <p
                className="text-4xl font-extrabold text-brand-ink tabular-nums"
                data-testid="weekly-earnings"
              >
                {usd.format(est.weeklyCents / 100)}
              </p>
            </div>
            <div className="rounded-2xl border border-brand-line bg-brand-bg p-5">
              <p className="text-xs uppercase tracking-wider text-brand-mute mb-1">Per month</p>
              <p
                className="text-4xl font-extrabold text-brand-ink tabular-nums"
                data-testid="monthly-earnings"
              >
                {usd.format(est.monthlyCents / 100)}
              </p>
            </div>
          </div>

          <p className="mt-4 text-xs text-brand-mute leading-relaxed">
            Estimate at the {tier.displayName} rate (${Math.round(tier.hourlyRateCents / 100)}/hr).
            Labor pay only — surge, $15 driving / $25 hauling bonuses, after-hours 1.5x, and 100% of
            tips are on top. You set your own schedule, so weeks vary.
          </p>

          <div className="mt-6">
            <a href="/login/crew" className="btn-primary" data-bcl-cta="earnings-apply">
              Start earning →
            </a>
          </div>
        </div>
      </div>
    </article>
  );
}

function Step({ n, title, body }: { n: number; title: string; body: string }) {
  return (
    <li className="rounded-2xl border border-brand-line bg-brand-card p-4 transition-all duration-[333ms] hover:-translate-y-0.5 hover:shadow-md hover:border-brand-accent/40">
      <span className="block text-2xl font-extrabold text-brand-accent mb-1">{n}</span>
      <h3 className="font-extrabold text-brand-ink text-sm mb-1">{title}</h3>
      <p className="text-brand-mute text-xs leading-relaxed">{body}</p>
    </li>
  );
}

function TierCard({ tier, accent }: { tier: CrewTier; accent?: boolean }) {
  return (
    <div
      className={`rounded-2xl border p-5 transition-all duration-[333ms] hover:-translate-y-0.5 hover:shadow-md ${
        accent
          ? 'border-brand-accent/40 bg-brand-accent/5 hover:border-brand-accent/70'
          : 'border-brand-line bg-brand-card hover:border-brand-accent/40'
      }`}
    >
      <p className="text-xs uppercase tracking-wider text-brand-mute mb-1">{tier.displayName}</p>
      <p className="text-2xl font-extrabold text-brand-ink mb-2 tabular-nums">
        ${Math.round(tier.hourlyRateCents / 100)}/hr
      </p>
      <p className="text-sm text-brand-mute leading-relaxed">{tier.note}</p>
    </div>
  );
}

function PayoutLogo() {
  return (
    <svg
      width="22"
      height="22"
      viewBox="0 0 24 24"
      aria-hidden="true"
      className="shrink-0 text-brand-ink"
    >
      <path
        fill="currentColor"
        d="M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Zm3 5a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V9a1 1 0 0 0-1-1H8Zm1 2h6v4H9v-4Z"
      />
    </svg>
  );
}

function FAQItem({ q, a }: { q: string; a: string }) {
  return (
    <details className="rounded-2xl border border-brand-line bg-brand-card p-5">
      <summary className="cursor-pointer font-extrabold text-brand-ink">{q}</summary>
      <p className="mt-3 text-brand-mute leading-relaxed">{a}</p>
    </details>
  );
}
