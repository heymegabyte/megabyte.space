import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { usd0, usd2 } from '@theme.tools/billing/field-service/money';
import { PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';
import type { GigEarningsBreakdown } from '@theme.tools/billing/field-service/crew-earnings';
import { EarlyFinishOfferHistoryCard } from './worker/EarlyFinishOfferHistoryCard.js';
import { AffiliateProfitShareCard } from './AffiliateProfitShareCard.js';
import { useFeatureFlag } from '../use-feature-flag.js';
import { DashboardShell, type DashboardNavGroup } from './shell/DashboardShell.js';
import type { UserAvatarMenuGroup } from './shell/UserAvatarMenu.js';
import {
  AvatarSection,
  DocsList,
  DrivingCard,
  PersonalSection,
  VehicleSection,
  indexDocs,
  type ProfilePayload,
} from './WorkerProfile.js';
import TapToPayCharge from './work/TapToPayCharge.js';
import { BlocklistEditor } from './work/BlocklistEditor.js';
import { CompletenessBanner } from './work/CompletenessBanner.js';
import { DisputeBoard } from './work/DisputeBoard.js';
import { EarningsForecast } from './work/EarningsForecast.js';
import { InboxBadge } from './work/InboxBadge.js';
import { InstantPayoutOptIn } from './work/InstantPayoutOptIn.js';
import { JobAcceptCard } from './work/JobAcceptCard.js';
import { CrewJobMapCard } from './work/CrewJobMapCard.js';
import { OnboardingGateBanner } from './work/OnboardingGateBanner.js';
import { OnboardingVideo } from './work/OnboardingVideo.js';
import { PanicButton } from './work/PanicButton.js';
import { StreakCard } from './work/StreakCard.js';
import { TaxSurface } from './work/TaxSurface.js';
import { TechniqueLibrary } from './work/TechniqueLibrary.js';
import { TierProgress } from './work/TierProgress.js';

const TITLE = 'Crew dashboard — Brick Labor';
const DESC = "Your open gig invites, today's assignments, and weekly earnings.";

interface GigInvite {
  id: string;
  booking_id: string;
  status: string;
  crew_needed: number;
  crew_filled: number;
  needs_driver: number;
  hours_estimated: number;
  start_at: string;
  started_at: string | null;
  service_address: string | null;
  service_zip: string | null;
  worker_pay_cents_per_person: number;
  shift_lead_bonus_cents: number;
  rush_bonus_cents: number;
  customer_notes: string | null;
  claim_id: string;
  claim_status: 'invited' | 'accepted' | 'confirmed' | 'checked_in';
  invited_at: string;
}

interface CompletedRow {
  id: string;
  start_at: string;
  service_address: string | null;
  earnings_cents: number | null;
  tip_cents: number;
  check_in_at: string | null;
  check_out_at: string | null;
}

interface EarningsPayload {
  weekCents: number;
  weekJobs: number;
  ytdCents: number;
  ytdJobs: number;
  unpaidCents: number;
}

interface PayoutsTransfer {
  id: string;
  gig_id: string;
  earnings_cents: number | null;
  tip_cents: number;
  check_in_at: string | null;
  check_out_at: string | null;
  payout_transfer_id: string | null;
  payout_transfer_at: string | null;
  payout_transfer_status: string | null;
  start_at: string;
}

interface PayoutsPayload {
  onboarding: {
    onboarded: boolean;
    payoutsEnabled: boolean;
    wageCentsPerHour: number;
    rail: string;
  };
  balance: {
    unpostedCents: number;
    unpostedJobs: number;
    postedCents: number;
    postedJobs: number;
  };
  instant: {
    method: 'cashapp' | 'venmo' | 'zelle' | null;
    handle: string | null;
    availableCents: number;
    availableJobs: number;
    lastRequest: {
      id: string;
      amount_cents: number;
      status: string;
      method: string;
      created_at: string;
      paid_at: string | null;
    } | null;
    minCents: number;
    enabled?: boolean;
    feePreview?: { feeCents: number; absorbedByPlatform: boolean };
    feePolicy?: {
      ratePercent: number;
      capCents: number;
      absorbedUnderCents: number;
      note: string;
    };
  };
  transfers: PayoutsTransfer[];
  links: { stripeOnboard: string; stripeDashboard: string };
}

type DashboardTab = 'invites' | 'today' | 'history' | 'earnings' | 'pay' | 'settings';

function track(name: string, props?: Record<string, unknown>): void {
  if (typeof window === 'undefined') return;
  try {
    const w = window as unknown as {
      posthog?: { capture: (n: string, p?: Record<string, unknown>) => void };
    };
    w.posthog?.capture(name, props);
  } catch {
    /* noop */
  }
}

function fireConfetti(): void {
  if (typeof window === 'undefined' || typeof document === 'undefined') return;
  const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  if (reduce) return;
  const layer = document.createElement('div');
  layer.setAttribute('aria-hidden', 'true');
  layer.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:9999;overflow:hidden';
  const colors = ['#FF6B1A', '#FFB07A', '#006AFF', '#FFFFFF', '#10b981'];
  const count = 60;
  for (let i = 0; i < count; i++) {
    const p = document.createElement('span');
    const size = 6 + Math.random() * 8;
    const left = Math.random() * 100;
    const delay = Math.random() * 0.25;
    const duration = 1.4 + Math.random() * 0.9;
    const drift = -20 + Math.random() * 40;
    const rot = Math.random() * 720;
    p.style.cssText = `position:absolute;top:-12px;left:${left}%;width:${size}px;height:${size * 0.4}px;background:${colors[i % colors.length]};border-radius:1px;transform:translate3d(0,0,0) rotate(0deg);animation:bcl-confetti ${duration}s cubic-bezier(.2,.7,.3,1) ${delay}s forwards;--drift:${drift}vw;--rot:${rot}deg`;
    layer.appendChild(p);
  }
  if (!document.getElementById('bcl-confetti-keys')) {
    const style = document.createElement('style');
    style.id = 'bcl-confetti-keys';
    style.textContent =
      '@keyframes bcl-confetti{0%{transform:translate3d(0,0,0) rotate(0)}100%{transform:translate3d(var(--drift),105vh,0) rotate(var(--rot));opacity:.85}}';
    document.head.appendChild(style);
  }
  document.body.appendChild(layer);
  window.setTimeout(() => layer.remove(), 2800);
}

function readInitialTab(initialTab?: DashboardTab): DashboardTab {
  if (initialTab) return initialTab;
  if (typeof window === 'undefined') return 'invites';
  const params = new URLSearchParams(window.location.search);
  const t = params.get('tab');
  const hash = window.location.hash.replace(/^#/, '');
  const v = (t || hash) as DashboardTab;
  if (
    v === 'pay' ||
    v === 'earnings' ||
    v === 'today' ||
    v === 'history' ||
    v === 'invites' ||
    v === 'settings'
  )
    return v;
  return 'invites';
}

export function WorkerDashboard({ initialTab }: { initialTab?: DashboardTab } = {}) {
  useThemeToolsSurface('worker-dashboard');
  const affiliateProfitShareEnabled = useFeatureFlag('affiliate_profit_share');
  const [authed, setAuthed] = useState<boolean | null>(null);
  const [invites, setInvites] = useState<GigInvite[]>([]);
  const [completed, setCompleted] = useState<CompletedRow[]>([]);
  const [earnings, setEarnings] = useState<EarningsPayload | null>(null);
  const [payouts, setPayouts] = useState<PayoutsPayload | null>(null);
  const [tab, setTabState] = useState<DashboardTab>(() => readInitialTab(initialTab));
  const setTab = useCallback((next: DashboardTab) => {
    setTabState(next);
    if (typeof window === 'undefined') return;
    const target = next === 'invites' ? '/work/dashboard' : `/work/dashboard#${next}`;
    if (window.location.pathname + window.location.hash !== target) {
      window.history.replaceState(null, '', target);
    }
  }, []);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const onHash = () => {
      const v = window.location.hash.replace(/^#/, '');
      if (
        v === 'pay' ||
        v === 'earnings' ||
        v === 'today' ||
        v === 'history' ||
        v === 'invites' ||
        v === 'settings'
      ) {
        setTabState(v);
      } else if (!v) {
        setTabState('invites');
      }
    };
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const refresh = useCallback(async () => {
    setBusy(true);
    setError('');
    try {
      const [gigsRes, earnRes, payRes] = await Promise.all([
        fetch('/api/work/gigs', { headers: { Accept: 'application/json' } }),
        fetch('/api/work/gigs/earnings', { headers: { Accept: 'application/json' } }),
        fetch('/api/work/payouts', { headers: { Accept: 'application/json' } }),
      ]);
      if (gigsRes.status === 401) {
        setAuthed(false);
        return;
      }
      setAuthed(true);
      if (gigsRes.ok) {
        const data = (await gigsRes.json()) as { invites: GigInvite[]; completed: CompletedRow[] };
        setInvites(data.invites ?? []);
        setCompleted(data.completed ?? []);
      }
      if (earnRes.ok) setEarnings((await earnRes.json()) as EarningsPayload);
      if (payRes.ok) setPayouts((await payRes.json()) as PayoutsPayload);
    } catch (err) {
      setError(`Network error: ${(err as Error).message}`);
    } finally {
      setBusy(false);
    }
  }, []);

  useEffect(() => {
    document.title = TITLE;
    setMeta('description', DESC);
    setMeta('robots', 'noindex,nofollow');
    void refresh();
    const t = setInterval(() => void refresh(), 30000);
    return () => clearInterval(t);
  }, [refresh]);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    const gig = params.get('gig');
    if (gig) {
      setTab('invites');
      setTimeout(() => {
        const el = document.querySelector(`[data-gig-id="${gig}"]`);
        if (el && 'scrollIntoView' in el)
          (el as HTMLElement).scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 400);
    }
  }, [invites.length]);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (window.location.hash.replace(/^#/, '') !== tab) {
      window.history.replaceState(null, '', `${window.location.pathname}#${tab}`);
    }
    track('worker_dashboard_tab', { tab });
  }, [tab]);

  if (authed === false) {
    return (
      <article className="section">
        <div className="container-pad max-w-md text-center">
          <h1 className="text-3xl font-extrabold mb-3">Sign in to your crew dashboard</h1>
          <p className="text-brand-mute mb-6">
            We use SMS magic-codes — no password. Tap below to verify your phone.
          </p>
          <a className="btn-primary" href="/login?intent=signin&kind=crew">
            Sign in →
          </a>
        </div>
      </article>
    );
  }

  if (authed === null) {
    return (
      <article className="section">
        <div className="container-pad max-w-md text-center text-brand-mute">Loading…</div>
      </article>
    );
  }

  const todayInvites = invites.filter((i) =>
    ['accepted', 'confirmed', 'checked_in'].includes(i.claim_status),
  );
  const openInvites = invites.filter((i) => i.claim_status === 'invited');

  const greeting = (() => {
    const hr = new Date().getHours();
    if (hr < 5) return 'Late shift';
    if (hr < 12) return 'Good morning';
    if (hr < 17) return 'Good afternoon';
    if (hr < 21) return 'Good evening';
    return 'Late shift';
  })();

  const navGroups: DashboardNavGroup[] = [
    {
      items: [
        {
          key: 'invites',
          label: 'Open invites',
          icon: '✉',
          href: '#invites',
          badge: openInvites.length,
        },
        { key: 'today', label: 'Today', icon: '◎', href: '#today', badge: todayInvites.length },
        { key: 'history', label: 'History', icon: '◐', href: '#history', badge: completed.length },
        { key: 'earnings', label: 'Earnings', icon: '$', href: '#earnings' },
        { key: 'pay', label: 'Payouts', icon: '◆', href: '#pay' },
        { key: 'settings', label: 'Profile & settings', icon: '◌', href: '#settings' },
      ],
    },
  ];

  const userMenu: UserAvatarMenuGroup[] = [
    {
      items: [
        { label: 'Profile + settings', href: '#settings', icon: '◌' },
        { label: 'Payouts', href: '#pay', icon: '◆' },
        { label: 'Tax surface', href: '#earnings', icon: '$' },
      ],
    },
    {
      items: [
        { label: 'Ops support', href: 'mailto:hey@bricklabor.com', icon: '✉' },
        { label: 'Call dispatcher', href: PHONE_TEL_HREF, icon: '☎' },
      ],
    },
    {
      items: [
        { label: 'Crew home', href: '/work', icon: '←' },
        { label: 'Sign out', href: '/login?logout=1', icon: '⎋', danger: true },
      ],
    },
  ];

  // Intercept hash-anchored sidebar clicks → switch tab in-place.
  const onShellClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const a = (e.target as HTMLElement).closest<HTMLAnchorElement>('a[href^="#"]');
    if (!a) return;
    const key = a.getAttribute('href')?.slice(1);
    if (!key) return;
    if (['invites', 'today', 'history', 'earnings', 'pay', 'settings'].includes(key)) {
      e.preventDefault();
      setTab(key as DashboardTab);
    }
  };

  return (
    <div onClick={onShellClick}>
      <DashboardShell
        active={tab}
        title={`${greeting}, crew.`}
        breadcrumb={[{ label: 'Crew', href: '/work' }, { label: 'Dashboard' }]}
        nav={navGroups}
        userDisplayName="Crew member"
        userSubtitle="Signed in"
        userMenu={userMenu}
        brandBadge="CREW"
        headerActions={
          <div className="hidden md:flex items-center gap-2">
            <InboxBadge />
            <PushEnableButton />
            <button
              type="button"
              onClick={() => void refresh()}
              disabled={busy}
              className="text-xs text-brand-mute hover:text-brand-ink underline-hover px-2 py-1"
              aria-label="Refresh dashboard"
            >
              {busy ? 'Refreshing…' : '↻ Refresh'}
            </button>
          </div>
        }
      >
        <OnboardingGateBanner />
        <CompletenessBanner />

        {error && (
          <div
            role="alert"
            className="mb-4 rounded-2xl border border-red-500/40 bg-red-500/10 p-4 text-red-200"
          >
            {error}
          </div>
        )}

        <StatsStrip earnings={earnings} payouts={payouts} completedCount={completed.length} />

        {tab === 'invites' && <InvitesPanel invites={openInvites} onAction={refresh} />}
        {tab === 'today' && <TodayPanel invites={todayInvites} onAction={refresh} />}
        {tab === 'history' && (
          <div className="space-y-6">
            <HistoryPanel completed={completed} />
            <EarlyFinishOfferHistoryCard />
          </div>
        )}
        {tab === 'earnings' && (
          <div className="space-y-6">
            <EarningsPanel earnings={earnings} completed={completed} invitesAll={invites} />
            <AffiliateProfitShareCard enabled={affiliateProfitShareEnabled} />
          </div>
        )}
        {tab === 'pay' && <PayoutsPanel payouts={payouts} onAction={refresh} />}
        {tab === 'settings' && <SettingsPanel />}
      </DashboardShell>
    </div>
  );
}

function StatsStrip({
  earnings,
  payouts,
  completedCount,
}: {
  earnings: EarningsPayload | null;
  payouts: PayoutsPayload | null;
  completedCount: number;
}) {
  // Clamp at 0 — a no-jobs state with a small fee/expense adjustment can
  // produce a negative cents value that reads weirdly as "-$3" in a stat
  // strip. Floor it to $0 so the crew sees a clean baseline.
  // Grouped, $-prefixed (usd0) so a $1,450 YTD never renders as a commaless "$1450".
  const weekDollars = earnings ? usd0(Math.max(0, earnings.weekCents)) : '—';
  const ytdDollars = earnings ? usd0(Math.max(0, earnings.ytdCents)) : '—';
  const unpostedDollars = payouts
    ? usd0(Math.max(0, payouts.balance.unpostedCents + payouts.balance.postedCents))
    : '—';
  const instantAvailCents = payouts ? Math.max(0, payouts.instant.availableCents) : 0;
  const instantDollars = payouts ? usd0(instantAvailCents) : '—';
  const jobsAll = earnings ? earnings.ytdJobs : completedCount;
  return (
    <div className="mb-6 grid grid-cols-2 sm:grid-cols-5 gap-2 sm:gap-3">
      <StripCell
        label="This week"
        value={weekDollars}
        sub={earnings ? `${earnings.weekJobs} jobs` : ''}
      />
      <StripCell label="YTD" value={ytdDollars} sub={`${jobsAll} jobs`} />
      <StripCell label="Owed" value={unpostedDollars} sub="next payroll" />
      <StripCell
        label="Instant"
        value={instantDollars}
        sub="ready now"
        highlight={instantAvailCents > 0}
      />
      <StripCell
        label="Method"
        value={payouts?.instant.method ? payouts.instant.method : 'Set up'}
        sub={payouts?.instant.handle ?? 'Cash App / Venmo / Zelle'}
      />
    </div>
  );
}

function StripCell({
  label,
  value,
  sub,
  highlight,
}: {
  label: string;
  value: string;
  sub?: string;
  highlight?: boolean;
}) {
  return (
    <div
      className={`rounded-xl border px-3 py-2.5 ${
        highlight ? 'border-emerald-500/40 bg-emerald-500/10' : 'border-brand-line bg-brand-card'
      }`}
    >
      <p className="text-[10px] uppercase tracking-wider text-brand-mute">{label}</p>
      <p className={`font-extrabold text-lg ${highlight ? 'text-emerald-300' : 'text-brand-ink'}`}>
        {value}
      </p>
      {sub && <p className="text-[11px] text-brand-mute mt-0.5 truncate">{sub}</p>}
    </div>
  );
}

// Legacy TabBtn removed 2026-05-23 — tab nav now sourced from the
// DashboardShell side-menu (matches /me + /admin/* shells).

function InvitesPanel({ invites, onAction }: { invites: GigInvite[]; onAction: () => void }) {
  if (invites.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed border-brand-line p-12 text-center text-brand-mute">
        <p className="font-bold text-brand-ink mb-2">No open invites right now.</p>
        <p className="text-sm">We'll text you when a gig matches your zone.</p>
      </div>
    );
  }
  return (
    <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {invites.map((inv) => (
        <li key={inv.claim_id} data-gig-id={inv.id}>
          <InviteCard invite={inv} onAction={onAction} />
        </li>
      ))}
    </ul>
  );
}

function InviteCard({ invite, onAction }: { invite: GigInvite; onAction: () => void }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [showTransparency, setShowTransparency] = useState(false);
  const totalPay =
    invite.worker_pay_cents_per_person * invite.hours_estimated + invite.rush_bonus_cents;

  async function respond(action: 'accept' | 'decline') {
    setBusy(true);
    setError('');
    try {
      const res = await fetch(`/api/work/gigs/${invite.id}/${action}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: '{}',
      });
      if (!res.ok) {
        const data = (await res.json().catch(() => ({}))) as { code?: string };
        setError(errorLabel(data.code) || `Request failed (${res.status})`);
        return;
      }
      onAction();
    } catch (err) {
      setError(`Network: ${(err as Error).message}`);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="rounded-2xl border border-brand-line bg-brand-card p-5">
      <div className="flex items-baseline justify-between mb-3">
        <p className="text-xs uppercase tracking-wider text-brand-mute">
          {formatStart(invite.start_at)}
        </p>
        <p className="text-2xl font-extrabold text-brand-accent">{usd0(totalPay)}</p>
      </div>
      <h3 className="text-lg font-extrabold text-brand-ink mb-1">
        {invite.hours_estimated}h · {invite.service_zip ?? '—'} ·{' '}
        <span className="text-brand-mute">
          ${(invite.worker_pay_cents_per_person / 100).toFixed(0)}/hr
        </span>
      </h3>
      {invite.service_address && (
        <p className="text-sm text-brand-mute mb-2">{invite.service_address}</p>
      )}
      {invite.needs_driver === 1 && (
        <p className="text-xs font-bold text-amber-400 mb-2">
          Driving required (U-Haul rental run)
        </p>
      )}
      {invite.customer_notes && (
        <p className="text-sm text-brand-mute mb-3 italic">"{invite.customer_notes}"</p>
      )}
      <p className="text-xs text-brand-mute mb-4">
        Crew: {invite.crew_filled}/{invite.crew_needed} accepted
      </p>
      {error && (
        <p role="alert" className="text-xs text-red-400 mb-3">
          {error}
        </p>
      )}
      <div className="flex gap-2">
        <button
          type="button"
          onClick={() => respond('accept')}
          disabled={busy}
          className="btn-primary flex-1"
        >
          {busy ? '…' : 'Accept'}
        </button>
        <button
          type="button"
          onClick={() => respond('decline')}
          disabled={busy}
          className="rounded-xl border border-brand-line bg-transparent px-4 py-2 text-sm font-bold text-brand-mute hover:text-brand-ink transition-colors"
        >
          Decline
        </button>
      </div>

      <button
        type="button"
        onClick={() => setShowTransparency((v) => !v)}
        className="mt-3 text-xs text-brand-mute underline-hover"
      >
        {showTransparency ? 'Hide pre-accept details ↑' : 'Show pre-accept details ↓'}
      </button>
      {showTransparency && (
        <div className="mt-3">
          <JobAcceptCard
            gigId={invite.id}
            onAccepted={() => {
              setShowTransparency(false);
              onAction();
            }}
            onDeclined={() => {
              setShowTransparency(false);
              onAction();
            }}
          />
        </div>
      )}
    </div>
  );
}

function TodayPanel({ invites, onAction }: { invites: GigInvite[]; onAction: () => void }) {
  const activeInvite = invites.find((i) => i.claim_status === 'checked_in') ?? invites[0];
  return (
    <div className="space-y-6">
      <StreakCard />
      {invites.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-brand-line p-12 text-center text-brand-mute">
          <p className="font-bold text-brand-ink mb-2">No gigs assigned yet.</p>
          <p className="text-sm">Accept an invite — it'll show up here with check-in controls.</p>
        </div>
      ) : (
        <ul className="space-y-4">
          {invites.map((inv) => (
            <li key={inv.claim_id}>
              <ActiveGigCard invite={inv} onAction={onAction} />
            </li>
          ))}
        </ul>
      )}

      {activeInvite && (
        <TapToPayCharge bookingId={activeInvite.booking_id} onCharged={() => onAction()} />
      )}

      <OnboardingVideo />
      <TechniqueLibrary />
    </div>
  );
}

interface PhotoSummary {
  claimId: string;
  beforeCount: number;
  afterCount: number;
  canComplete: boolean;
  photos: Array<{
    id: string;
    kind: string;
    captured_at: string | null;
    distance_m: number | null;
    caption: string | null;
  }>;
}

function ActiveGigCard({ invite, onAction }: { invite: GigInvite; onAction: () => void }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [milesDriven, setMilesDriven] = useState('');
  const [photoSummary, setPhotoSummary] = useState<PhotoSummary | null>(null);
  // Itemized pay receipt returned by /complete — base + rush + lead + mileage.
  const [payReceipt, setPayReceipt] = useState<GigEarningsBreakdown | null>(null);

  const refreshPhotos = useCallback(async () => {
    try {
      const r = await fetch(`/api/work/gigs/${invite.id}/photos`);
      if (r.ok) setPhotoSummary((await r.json()) as PhotoSummary);
    } catch {
      /* ignore — UI just won't update count */
    }
  }, [invite.id]);

  useEffect(() => {
    if (invite.claim_status === 'checked_in') void refreshPhotos();
  }, [invite.claim_status, refreshPhotos]);

  async function action(path: string, body: object = {}) {
    setBusy(true);
    setError('');
    try {
      const res = await fetch(`/api/work/gigs/${invite.id}/${path}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        const data = (await res.json().catch(() => ({}))) as { code?: string };
        setError(errorLabel(data.code) || `Failed (${res.status})`);
        return;
      }
      // On completion the worker returns the itemized pay breakdown. Hold the
      // receipt on-screen (the card would otherwise unmount on refresh) so the
      // crew sees exactly how their pay was built before tapping Done.
      if (path === 'complete') {
        const data = (await res.json().catch(() => ({}))) as { breakdown?: GigEarningsBreakdown };
        if (data.breakdown) {
          setPayReceipt(data.breakdown);
          return;
        }
      }
      onAction();
    } catch (err) {
      setError(`Network: ${(err as Error).message}`);
    } finally {
      setBusy(false);
    }
  }

  async function withGeo(path: string, extra: object = {}) {
    if (!('geolocation' in navigator)) {
      await action(path, extra);
      return;
    }
    setBusy(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        await action(path, {
          ...extra,
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
        });
      },
      async () => {
        await action(path, extra);
      },
      { enableHighAccuracy: false, timeout: 8000, maximumAge: 60000 },
    );
  }

  const stage = invite.claim_status;

  if (payReceipt) {
    const lines: Array<{ label: string; cents: number }> = [
      { label: 'Base labor', cents: payReceipt.baseCents },
      { label: 'Rush bonus', cents: payReceipt.rushBonusCents },
      { label: 'Shift-lead bonus', cents: payReceipt.shiftLeadBonusCents },
      { label: 'Mileage', cents: payReceipt.mileageCents },
    ].filter((l) => l.cents > 0);
    return (
      <div
        className="rounded-2xl border border-brand-accent/40 bg-brand-accent/5 p-5"
        data-testid="gig-pay-receipt"
      >
        <p className="text-xs uppercase tracking-wider text-brand-accent mb-1">Gig complete</p>
        <h3 className="text-lg font-extrabold text-brand-ink mb-3">You earned</h3>
        <dl className="flex flex-col gap-1.5 text-sm">
          {lines.map((l) => (
            <div key={l.label} className="flex items-baseline justify-between gap-3">
              <dt className="text-brand-mute">{l.label}</dt>
              <dd className="font-mono tabular-nums text-brand-ink">{usd2(l.cents)}</dd>
            </div>
          ))}
          <div className="mt-2 flex items-baseline justify-between gap-3 border-t border-brand-line pt-2">
            <dt className="font-bold text-brand-ink">Total</dt>
            <dd className="font-mono tabular-nums text-base font-extrabold text-brand-accent">
              {usd2(payReceipt.totalCents)}
            </dd>
          </div>
        </dl>
        <button
          type="button"
          onClick={() => {
            setPayReceipt(null);
            onAction();
          }}
          className="btn-primary mt-4 w-full sm:w-auto"
        >
          Done
        </button>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-brand-line bg-brand-card p-5">
      <PanicButton gigId={invite.id} claimId={invite.claim_id} visible={stage === 'checked_in'} />
      <div className="flex flex-wrap items-baseline justify-between gap-2 mb-3">
        <div>
          <p className="text-xs uppercase tracking-wider text-brand-mute">
            {formatStart(invite.start_at)}
          </p>
          <h3 className="text-lg font-extrabold text-brand-ink">
            {invite.hours_estimated}h gig in {invite.service_zip ?? '—'}
          </h3>
        </div>
        <ClaimPill status={stage} />
      </div>
      {/* live_job_map — live map + Navigate for the accepted job (flag-gated; renders null otherwise) */}
      <CrewJobMapCard gigId={invite.id} />
      {invite.service_address && (
        <p className="text-sm text-brand-mute mb-3">
          <a
            href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(invite.service_address)}`}
            target="_blank"
            rel="noopener"
            className="underline-hover"
          >
            {invite.service_address} ↗
          </a>
        </p>
      )}
      {error && (
        <p role="alert" className="text-xs text-red-400 mb-3">
          {error}
        </p>
      )}
      <div className="flex flex-wrap gap-2">
        {stage === 'accepted' && (
          <>
            <button
              type="button"
              disabled={busy}
              onClick={() => withGeo('en-route')}
              className="btn-primary"
            >
              {busy ? '…' : "I'm en route"}
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={() => withGeo('check-in')}
              className="rounded-xl border border-brand-accent/40 bg-brand-accent/10 px-4 py-2 text-sm font-bold text-brand-accent hover:bg-brand-accent/20 transition-colors"
            >
              Check in (GPS)
            </button>
          </>
        )}
        {stage === 'confirmed' && (
          <button
            type="button"
            disabled={busy}
            onClick={() => withGeo('check-in')}
            className="btn-primary"
          >
            {busy ? '…' : 'Check in (GPS)'}
          </button>
        )}
        {stage === 'checked_in' && (
          <div className="flex flex-col gap-4 w-full">
            {/* job_started — the Domino's-tracker beat between arrival and completion.
                Tapping it stamps started_at + flips the booking to in_progress (lighting
                up the customer's /track "In Progress" state) + fires the job_started
                notification. Additive: it does NOT gate completion. */}
            {!invite.started_at ? (
              <button
                type="button"
                disabled={busy}
                onClick={() => action('start')}
                className="btn-primary w-full sm:w-auto"
                title="Tell the customer your crew has begun working"
              >
                {busy ? '…' : 'Start work'}
              </button>
            ) : (
              <p className="flex items-center gap-2 text-sm font-bold text-brand-accent">
                <span aria-hidden="true">●</span> Work in progress — customer notified
              </p>
            )}
            <PhotoCapture claimId={photoSummary?.claimId ?? ''} summary={photoSummary} onUploaded={refreshPhotos} />
            <div className="flex flex-wrap items-end gap-3">
              <label className="flex flex-col gap-1 text-xs text-brand-mute">
                Miles driven (optional)
                <input
                  type="number"
                  inputMode="decimal"
                  min={0}
                  step={0.1}
                  value={milesDriven}
                  onChange={(e) => setMilesDriven(e.target.value)}
                  className="w-28 rounded-lg border border-brand-line bg-brand-bg px-3 py-2 text-brand-ink"
                />
              </label>
              <button
                type="button"
                disabled={busy || !(photoSummary?.canComplete ?? false)}
                onClick={() =>
                  action('complete', {
                    ...(milesDriven ? { milesDriven: Number(milesDriven) } : {}),
                  })
                }
                className="btn-primary disabled:opacity-50"
                title={
                  photoSummary?.canComplete
                    ? undefined
                    : 'Upload at least 1 before + 1 after photo first'
                }
              >
                {busy ? '…' : 'Mark complete'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function PhotoCapture({
  claimId,
  summary,
  onUploaded,
}: {
  claimId: string;
  summary: PhotoSummary | null;
  onUploaded: () => void;
}) {
  const [uploading, setUploading] = useState<'before' | 'after' | null>(null);
  const [err, setErr] = useState('');

  const upload = (kind: 'before' | 'after') => async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (file.size > 12 * 1024 * 1024) {
      setErr('Photo is too large (12 MB max).');
      return;
    }
    setUploading(kind);
    setErr('');

    const send = async (lat?: number, lng?: number) => {
      try {
        const fd = new FormData();
        fd.append('file', file);
        fd.append('claimId', claimId);
        fd.append('kind', kind);
        if (typeof lat === 'number') fd.append('lat', String(lat));
        if (typeof lng === 'number') fd.append('lng', String(lng));
        const res = await fetch('/api/work/upload/gig-photo', { method: 'POST', body: fd });
        if (!res.ok) {
          const data = (await res.json().catch(() => ({}))) as { code?: string; error?: string };
          setErr(
            data.code === 'too_far'
              ? "You're too far from the job site to upload this photo."
              : data.code === 'unsupported_type'
                ? 'Use JPEG/PNG/WebP/HEIC.'
                : data.code === 'no_claim'
                  ? "This gig isn't assigned to you."
                  : `Upload failed (${res.status})`,
          );
          return;
        }
        onUploaded();
      } catch (ex) {
        setErr(`Network: ${(ex as Error).message}`);
      } finally {
        setUploading(null);
      }
    };

    if (!('geolocation' in navigator)) {
      await send();
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => void send(pos.coords.latitude, pos.coords.longitude),
      () => void send(),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 30000 },
    );
  };

  const beforeCount = summary?.beforeCount ?? 0;
  const afterCount = summary?.afterCount ?? 0;

  return (
    <div className="rounded-xl border border-brand-line bg-brand-bg/40 p-4 space-y-3">
      <div className="flex items-baseline justify-between gap-3 flex-wrap">
        <p className="text-sm font-bold text-brand-ink">Required before + after photos</p>
        <p className="text-xs text-brand-mute">
          {beforeCount} before · {afterCount} after
          {summary?.canComplete ? ' · ready' : ' · need 1 of each'}
        </p>
      </div>
      <div className="flex flex-wrap gap-2">
        <label
          className={`btn-primary cursor-pointer text-sm ${uploading === 'before' ? 'opacity-60' : ''}`}
        >
          {uploading === 'before'
            ? 'Uploading…'
            : beforeCount > 0
              ? '+ Another before'
              : 'Take before photo'}
          <input
            type="file"
            accept="image/jpeg,image/png,image/webp,image/heic,image/heif"
            capture="environment"
            disabled={uploading !== null}
            onChange={upload('before')}
            className="hidden"
          />
        </label>
        <label
          className={`rounded-xl border border-brand-accent/40 bg-brand-accent/10 px-4 py-2 text-sm font-bold text-brand-accent hover:bg-brand-accent/20 transition-colors cursor-pointer ${uploading === 'after' ? 'opacity-60' : ''}`}
        >
          {uploading === 'after'
            ? 'Uploading…'
            : afterCount > 0
              ? '+ Another after'
              : 'Take after photo'}
          <input
            type="file"
            accept="image/jpeg,image/png,image/webp,image/heic,image/heif"
            capture="environment"
            disabled={uploading !== null}
            onChange={upload('after')}
            className="hidden"
          />
        </label>
      </div>
      {err && (
        <p role="alert" className="text-xs text-red-400">
          {err}
        </p>
      )}
      <p className="text-[11px] text-brand-mute">
        We GPS-stamp each photo. Stay near the job site (within 250 m) when shooting.
      </p>
    </div>
  );
}

function HistoryPanel({ completed }: { completed: CompletedRow[] }): JSX.Element {
  const [query, setQuery] = useState('');
  const [month, setMonth] = useState<'all' | string>('all');

  const sorted = useMemo(
    () => [...completed].sort((a, b) => (a.start_at < b.start_at ? 1 : -1)),
    [completed],
  );

  const months = useMemo(() => {
    const set = new Set<string>();
    for (const c of sorted) {
      const d = new Date(c.start_at);
      if (Number.isNaN(d.getTime())) continue;
      set.add(d.toISOString().slice(0, 7));
    }
    return Array.from(set).sort().reverse();
  }, [sorted]);

  const filtered = sorted.filter((c) => {
    if (month !== 'all') {
      const d = new Date(c.start_at);
      if (Number.isNaN(d.getTime()) || d.toISOString().slice(0, 7) !== month) return false;
    }
    if (!query) return true;
    const q = query.toLowerCase();
    return (
      (c.service_address ?? '').toLowerCase().includes(q) ||
      c.id.toLowerCase().includes(q) ||
      formatStart(c.start_at).toLowerCase().includes(q)
    );
  });

  const totalCents = filtered.reduce(
    (acc, c) => acc + (c.earnings_cents ?? 0) + (c.tip_cents ?? 0),
    0,
  );

  if (completed.length === 0) {
    return (
      <div className="rounded-2xl border border-brand-line bg-bg-elevated/30 p-8 text-center text-brand-mute">
        <p className="font-mono text-[11px] uppercase tracking-wider text-brand-accent mb-2">
          No history yet
        </p>
        <p className="text-sm">
          Completed gigs show up here once you've worked one. Open invites live in the{' '}
          <strong className="text-brand-ink">Open invites</strong> tab.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end gap-3 rounded-2xl border border-brand-line bg-bg-elevated/40 p-4">
        <label className="flex flex-col gap-1 text-xs text-brand-mute flex-1 min-w-[200px]">
          Search address or job ID
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Newark, NJ · or job #abc123"
            className="rounded-lg border border-brand-line bg-brand-bg px-3 py-2 text-sm text-brand-ink"
          />
        </label>
        <label className="flex flex-col gap-1 text-xs text-brand-mute">
          Month
          <select
            value={month}
            onChange={(e) => setMonth(e.target.value)}
            className="rounded-lg border border-brand-line bg-brand-bg px-3 py-2 text-sm text-brand-ink"
          >
            <option value="all">All time</option>
            {months.map((m) => (
              <option key={m} value={m}>
                {new Date(`${m}-01T12:00:00Z`).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'long',
                })}
              </option>
            ))}
          </select>
        </label>
        <div className="text-right">
          <p className="font-mono text-[11px] uppercase tracking-wider text-brand-mute">
            {filtered.length} of {completed.length} gigs
          </p>
          <p className="text-lg font-extrabold text-brand-accent leading-tight">
            {usd0(totalCents)}
          </p>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-2xl border border-brand-line bg-bg-elevated/30 p-6 text-center text-sm text-brand-mute">
          No gigs match the current filters.
        </div>
      ) : (
        <ul className="divide-y divide-brand-line rounded-2xl border border-brand-line overflow-hidden">
          {filtered.map((c) => (
            <li
              key={c.id}
              className="flex flex-wrap items-baseline justify-between gap-3 bg-brand-card px-4 py-3 hover:bg-bg-elevated transition-colors"
            >
              <div className="min-w-0 flex-1">
                <p className="text-sm font-bold text-brand-ink">{formatStart(c.start_at)}</p>
                <p className="text-xs text-brand-mute truncate">
                  {c.service_address || 'Address withheld'} · #{c.id.slice(-6)}
                </p>
              </div>
              <p className="text-sm font-extrabold text-brand-accent whitespace-nowrap">
                {usd0(c.earnings_cents ?? 0)}
                {c.tip_cents > 0 && (
                  <span className="text-brand-mute font-normal"> + {usd0(c.tip_cents)} tip</span>
                )}
              </p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function EarningsPanel({
  earnings,
  completed,
  invitesAll,
}: {
  earnings: EarningsPayload | null;
  completed: CompletedRow[];
  invitesAll: GigInvite[];
}) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Stat
          label="This week"
          cents={earnings?.weekCents ?? 0}
          sub={`${earnings?.weekJobs ?? 0} jobs`}
        />
        <Stat
          label="Year-to-date"
          cents={earnings?.ytdCents ?? 0}
          sub={`${earnings?.ytdJobs ?? 0} jobs`}
        />
        <Stat label="Unpaid" cents={earnings?.unpaidCents ?? 0} sub="Paid out Fridays" accent />
      </div>

      <EarningsForecast />

      <AcceptanceRateCard invites={invitesAll} ytdJobs={earnings?.ytdJobs ?? 0} />

      <TaxSurface taxYearTotalCents={earnings?.ytdCents ?? 0} />

      <DisputeBoard />

      <div>
        <h2 className="text-xl font-extrabold text-brand-ink mb-3">Recent gigs</h2>
        {completed.length === 0 ? (
          <p className="text-sm text-brand-mute">No completed gigs yet.</p>
        ) : (
          <ul className="divide-y divide-brand-line rounded-2xl border border-brand-line overflow-hidden">
            {completed.map((c) => (
              <li
                key={c.id}
                className="flex items-baseline justify-between gap-3 bg-brand-card px-4 py-3"
              >
                <div>
                  <p className="text-sm font-bold text-brand-ink">{formatStart(c.start_at)}</p>
                  {c.service_address && (
                    <p className="text-xs text-brand-mute">{c.service_address}</p>
                  )}
                </div>
                <p className="text-sm font-extrabold text-brand-accent">
                  {usd0(c.earnings_cents ?? 0)}
                  {c.tip_cents > 0 && (
                    <span className="text-brand-mute font-normal"> + {usd0(c.tip_cents)} tip</span>
                  )}
                </p>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

/**
 * Wave 3A — acceptance-rate transparency.
 *
 * Computes the worker's acceptance rate from the visible invites slice
 * (accepted + declined / total). Critically, the copy makes the algorithm
 * explicit: rate does NOT affect dispatch priority. Per Human Rights Watch
 * (2025) "Gig Trap" report, hidden acceptance penalties are the #1 worker
 * trust failure across gig platforms — so we name and defuse it directly.
 */
function AcceptanceRateCard({ invites, ytdJobs }: { invites: GigInvite[]; ytdJobs: number }) {
  const accepted = invites.filter(
    (i) =>
      i.claim_status === 'accepted' ||
      i.claim_status === 'confirmed' ||
      i.claim_status === 'checked_in',
  ).length;
  const total = invites.length;
  const ratePct = total > 0 ? Math.round((accepted / total) * 100) : null;

  return (
    <div className="rounded-2xl border border-brand-line bg-brand-card p-5 space-y-2">
      <div className="flex flex-wrap items-baseline justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-wider text-brand-mute">Acceptance rate</p>
          <p className="text-3xl font-extrabold text-brand-ink">
            {ratePct === null ? '—' : `${ratePct}%`}
          </p>
          <p className="text-xs text-brand-mute">
            {total === 0
              ? 'No invites yet'
              : `${accepted} of ${total} recent invites · ${ytdJobs} jobs YTD`}
          </p>
        </div>
      </div>
      <p className="text-sm text-brand-ink">
        <strong>This does NOT affect your dispatch priority.</strong> We rank by rating, distance,
        and skill match only — never by acceptance rate. Pass on jobs that don't fit; you won't be
        penalized.
      </p>
    </div>
  );
}

function Stat({
  label,
  cents,
  sub,
  accent,
}: {
  label: string;
  cents: number;
  sub: string;
  accent?: boolean;
}) {
  return (
    <div
      className={`rounded-2xl border p-5 ${
        accent ? 'border-brand-accent/40 bg-brand-accent/5' : 'border-brand-line bg-brand-card'
      }`}
    >
      <p className="text-xs uppercase tracking-wider text-brand-mute mb-1">{label}</p>
      <p className="text-3xl font-extrabold text-brand-ink mb-1">{usd0(cents)}</p>
      <p className="text-xs text-brand-mute">{sub}</p>
    </div>
  );
}

function ClaimPill({ status }: { status: GigInvite['claim_status'] }) {
  const map: Record<GigInvite['claim_status'], { label: string; cls: string }> = {
    invited: { label: 'Pending', cls: 'bg-amber-500/15 text-amber-300' },
    accepted: { label: 'Accepted', cls: 'bg-brand-accent/15 text-brand-accent' },
    confirmed: { label: 'Confirmed', cls: 'bg-brand-accent/20 text-brand-accent' },
    checked_in: { label: 'On site', cls: 'bg-emerald-500/15 text-emerald-300' },
  };
  const conf = map[status];
  return (
    <span className={`inline-block rounded-full px-3 py-1 text-xs font-bold ${conf.cls}`}>
      {conf.label}
    </span>
  );
}

function formatStart(iso: string): string {
  try {
    return new Date(iso).toLocaleString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      timeZone: 'America/New_York',
    });
  } catch {
    return iso;
  }
}

function errorLabel(code?: string): string {
  switch (code) {
    case 'crew_full':
      return 'Sorry — the crew filled up first. Try the next gig.';
    case 'invite_state':
      return 'You already responded to this invite.';
    case 'no_invite':
      return 'Invite no longer available.';
    case 'must_check_in_first':
      return 'Check in before marking complete.';
    case 'claim_state':
      return "This gig isn't at the right stage for that action.";
    default:
      return '';
  }
}

function PayoutsPanel({
  payouts,
  onAction,
}: {
  payouts: PayoutsPayload | null;
  onAction: () => void;
}) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [wageDraft, setWageDraft] = useState('');

  useEffect(() => {
    track('worker_payouts_opened', {
      onboarded: payouts?.onboarding.onboarded ?? false,
      payoutsEnabled: payouts?.onboarding.payoutsEnabled ?? false,
      hasInstantHandle: !!(payouts?.instant.method && payouts.instant.handle),
    });
  }, [
    payouts?.onboarding.onboarded,
    payouts?.onboarding.payoutsEnabled,
    payouts?.instant.method,
    payouts?.instant.handle,
  ]);

  if (!payouts) {
    return <p className="text-sm text-brand-mute">Loading payouts…</p>;
  }

  async function refreshStatus() {
    setBusy(true);
    setErr('');
    try {
      const res = await fetch('/api/work/payouts/refresh', { method: 'POST', body: '{}' });
      if (!res.ok) {
        const data = (await res.json().catch(() => ({}))) as { code?: string };
        setErr(payoutsErrLabel(data.code) || `Failed (${res.status})`);
        return;
      }
      onAction();
    } catch (e) {
      setErr(`Network: ${(e as Error).message}`);
    } finally {
      setBusy(false);
    }
  }

  async function saveWage() {
    const cents = Math.round(Number(wageDraft) * 100);
    if (!Number.isInteger(cents) || cents < 1500 || cents > 20000) {
      setErr('Wage must be between $15.00 and $200.00 per hour.');
      return;
    }
    setBusy(true);
    setErr('');
    try {
      const res = await fetch('/api/work/payouts/wage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ wageCentsPerHour: cents }),
      });
      if (!res.ok) {
        const data = (await res.json().catch(() => ({}))) as { code?: string };
        setErr(payoutsErrLabel(data.code) || `Failed (${res.status})`);
        return;
      }
      setWageDraft('');
      onAction();
    } catch (e) {
      setErr(`Network: ${(e as Error).message}`);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-6">
      {payouts.instant.feePolicy && payouts.instant.feePreview && (
        // Wave 15 — new InstantPayoutOptIn is prop-less + self-fetches from
        // /api/work/payouts/connect/status. Legacy props are now ignored.
        <InstantPayoutOptIn />
      )}

      <InstantPayoutCard payouts={payouts} onAction={onAction} />

      {payouts.onboarding.onboarded && (
        <div className="rounded-2xl border border-brand-line bg-brand-card p-5">
          <div className="flex flex-wrap items-baseline justify-between gap-3 mb-3">
            <div>
              <p className="text-xs uppercase tracking-wider text-brand-mute mb-1">Payout status</p>
              <p className="text-lg font-extrabold text-brand-ink">
                {payouts.onboarding.payoutsEnabled ? (
                  <span className="text-emerald-300">Active — direct deposit on Fridays</span>
                ) : (
                  <span className="text-amber-300">Finish Stripe verification</span>
                )}
              </p>
            </div>
            <button
              type="button"
              disabled={busy}
              onClick={refreshStatus}
              className="text-xs text-brand-mute underline-hover"
            >
              {busy ? '…' : 'Re-check'}
            </button>
          </div>
          <p className="text-sm text-brand-mute mb-3">
            Current rate:{' '}
            <span className="font-extrabold text-brand-ink">
              ${(payouts.onboarding.wageCentsPerHour / 100).toFixed(2)}/hr
            </span>
          </p>
          <div className="flex flex-wrap items-end gap-2">
            <label className="flex flex-col gap-1 text-xs text-brand-mute">
              Request new rate ($/hr)
              <input
                type="number"
                inputMode="decimal"
                min={15}
                max={200}
                step={0.5}
                value={wageDraft}
                onChange={(e) => setWageDraft(e.target.value)}
                placeholder={(payouts.onboarding.wageCentsPerHour / 100).toFixed(2)}
                className="w-28 rounded-lg border border-brand-line bg-brand-bg px-3 py-2 text-brand-ink"
              />
            </label>
            <button
              type="button"
              disabled={busy || !wageDraft}
              onClick={saveWage}
              className="rounded-xl border border-brand-accent/40 bg-brand-accent/10 px-4 py-2 text-sm font-bold text-brand-accent hover:bg-brand-accent/20 transition-colors disabled:opacity-40"
            >
              Update rate
            </button>
          </div>
          {err && (
            <p role="alert" className="text-xs text-red-400 mt-3">
              {err}
            </p>
          )}
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Stat
          label="Pending payout"
          cents={payouts.balance.unpostedCents}
          sub={`${payouts.balance.unpostedJobs} jobs · queued for Friday payout`}
        />
        <Stat
          label="Paid via Stripe"
          cents={payouts.balance.postedCents}
          sub={`${payouts.balance.postedJobs} jobs transferred`}
          accent
        />
      </div>

      <div>
        <h2 className="text-xl font-extrabold text-brand-ink mb-3">Recent payouts</h2>
        {payouts.transfers.length === 0 ? (
          <p className="text-sm text-brand-mute">No payouts yet — complete a gig to see it here.</p>
        ) : (
          <ul className="divide-y divide-brand-line rounded-2xl border border-brand-line overflow-hidden">
            {payouts.transfers.map((s) => (
              <li
                key={s.id}
                className="flex items-baseline justify-between gap-3 bg-brand-card px-4 py-3"
              >
                <div>
                  <p className="text-sm font-bold text-brand-ink">{formatStart(s.start_at)}</p>
                  <p className="text-xs text-brand-mute">
                    {s.payout_transfer_id ? (
                      <span className="text-emerald-300">Paid via Stripe</span>
                    ) : s.payout_transfer_status === 'error' ? (
                      <span className="text-red-400">Transfer error — admin will retry</span>
                    ) : (
                      <span className="text-amber-300">Queued for next Friday payout</span>
                    )}
                  </p>
                </div>
                <p className="text-sm font-extrabold text-brand-accent">
                  {usd0(s.earnings_cents ?? 0)}
                  {s.tip_cents > 0 && (
                    <span className="text-brand-mute font-normal"> + {usd0(s.tip_cents)} tip</span>
                  )}
                </p>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="rounded-2xl border border-brand-line bg-brand-card p-4 text-sm text-brand-mute">
        <p className="mb-2">
          Crew payouts run through{' '}
          <strong className="text-brand-ink">Stripe Connect Express</strong> — direct deposit every
          Friday for the prior week's completed gigs. Paystubs, tax forms, and direct deposit
          details live in your Stripe Express dashboard (link in your Settings tab).
        </p>
        <p>
          1099-NEC issued in January for any year you earn ≥$600. Need it sooner than Friday? Use
          the Instant Payout card above to push to your debit card in ~30 minutes.
        </p>
      </div>
    </div>
  );
}

function payoutsErrLabel(code?: string): string {
  switch (code) {
    case 'email_required':
      return 'Add your email on the profile page before enrolling.';
    case 'payouts_unconfigured':
      return 'Payout setup is temporarily offline. Try again in a few minutes.';
    case 'no_account':
      return 'Set up Stripe direct deposit first.';
    case 'stripe_unreachable':
      return 'Stripe is unreachable. Try the re-check button.';
    case 'stripe_failed':
      return 'Stripe rejected the request — contact ops@bricklabor.com.';
    case 'invalid_wage':
      return 'Wage must be between $15.00 and $200.00 per hour.';
    case 'rate_limited':
      return 'Too many attempts — wait a few minutes.';
    default:
      return '';
  }
}

function setMeta(name: string, content: string) {
  let el = document.querySelector<HTMLMetaElement>(`meta[name="${name}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute('name', name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function InstantPayoutCard({
  payouts,
  onAction,
}: {
  payouts: PayoutsPayload;
  onAction: () => void;
}) {
  const [showHandleForm, setShowHandleForm] = useState(false);
  const [method, setMethod] = useState<'cashapp' | 'venmo' | 'zelle'>(
    payouts.instant.method ?? 'cashapp',
  );
  const [handle, setHandle] = useState(payouts.instant.handle ?? '');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [ok, setOk] = useState('');

  const avail = payouts.instant.availableCents;
  const min = payouts.instant.minCents;
  const hasHandle = !!(payouts.instant.method && payouts.instant.handle);

  async function saveHandle() {
    setBusy(true);
    setErr('');
    setOk('');
    try {
      const res = await fetch('/api/work/payouts/handle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ method, handle: handle.trim() }),
      });
      if (!res.ok) {
        const data = (await res.json().catch(() => ({}))) as { code?: string };
        setErr(
          data.code === 'invalid_handle'
            ? 'That handle looks off. Cash App: $tag · Venmo: @user · Zelle: email or phone.'
            : data.code === 'invalid_method'
              ? 'Pick Cash App, Venmo, or Zelle.'
              : `Save failed (${res.status})`,
        );
        return;
      }
      setOk('Handle saved.');
      setShowHandleForm(false);
      onAction();
    } catch (e) {
      setErr(`Network: ${(e as Error).message}`);
    } finally {
      setBusy(false);
    }
  }

  async function cashOut() {
    setBusy(true);
    setErr('');
    setOk('');
    try {
      const res = await fetch('/api/work/payouts/instant', {
        method: 'POST',
        body: '{}',
        headers: { 'Content-Type': 'application/json' },
      });
      const data = (await res.json().catch(() => ({}))) as {
        code?: string;
        totalCents?: number;
        claimCount?: number;
        note?: string;
      };
      if (!res.ok) {
        setErr(
          data.code === 'no_handle'
            ? 'Add a Cash App / Venmo / Zelle handle first.'
            : data.code === 'no_balance'
              ? 'No completed jobs ready for cash-out yet.'
              : data.code === 'below_minimum'
                ? `Minimum cash-out is $${(min / 100).toFixed(2)}.`
                : data.code === 'rate_limited'
                  ? 'Too many cash-outs — try again in an hour.'
                  : `Cash-out failed (${res.status})`,
        );
        return;
      }
      setOk(
        `Requested ${usd2(data.totalCents ?? 0)} across ${data.claimCount} job(s). Ops will send within minutes.`,
      );
      track('worker_instant_payout_requested', {
        totalCents: data.totalCents ?? 0,
        claimCount: data.claimCount ?? 0,
        method: payouts.instant.method,
      });
      fireConfetti();
      onAction();
    } catch (e) {
      setErr(`Network: ${(e as Error).message}`);
    } finally {
      setBusy(false);
    }
  }

  const last = payouts.instant.lastRequest;

  return (
    <div className="rounded-2xl border border-emerald-500/40 bg-gradient-to-br from-emerald-500/10 to-brand-accent/5 p-5">
      <div className="flex flex-wrap items-baseline justify-between gap-3 mb-3">
        <div>
          <p className="text-xs uppercase tracking-wider text-emerald-300 mb-1">Cash out now</p>
          <h2 className="text-lg font-extrabold text-brand-ink">
            Skip Friday — get paid in minutes
          </h2>
        </div>
        <p className="text-3xl font-extrabold text-emerald-300">{usd2(avail)}</p>
      </div>
      <p className="text-sm text-brand-mute mb-4">
        {payouts.instant.availableJobs > 0
          ? `${payouts.instant.availableJobs} completed gig${payouts.instant.availableJobs === 1 ? '' : 's'} ready. Sent via Cash App, Venmo, or Zelle (no fees).`
          : 'Finish a gig and the cash-out balance lights up here.'}
      </p>

      {!hasHandle && !showHandleForm && (
        <button
          type="button"
          className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-4 py-2 text-sm font-bold text-emerald-200 hover:bg-emerald-500/20 transition-colors"
          onClick={() => setShowHandleForm(true)}
        >
          Add your Cash App / Venmo / Zelle →
        </button>
      )}

      {(showHandleForm || (hasHandle && !showHandleForm)) && hasHandle && !showHandleForm && (
        <div className="flex flex-wrap items-center gap-3 mb-4">
          <p className="text-sm text-brand-mute">
            Paid to: <span className="font-extrabold text-brand-ink">{payouts.instant.handle}</span>{' '}
            <span className="text-xs uppercase tracking-wider">({payouts.instant.method})</span>
          </p>
          <button
            type="button"
            className="text-xs text-brand-mute underline-hover"
            onClick={() => setShowHandleForm(true)}
          >
            Change
          </button>
        </div>
      )}

      {showHandleForm && (
        <div className="rounded-xl border border-brand-line bg-brand-bg/40 p-4 mb-4 space-y-3">
          <div className="flex flex-wrap gap-3">
            <label className="flex flex-col gap-1 text-xs text-brand-mute">
              Method
              <select
                value={method}
                onChange={(e) => setMethod(e.target.value as 'cashapp' | 'venmo' | 'zelle')}
                className="rounded-lg border border-brand-line bg-brand-bg px-3 py-2 text-brand-ink"
              >
                <option value="cashapp">Cash App</option>
                <option value="venmo">Venmo</option>
                <option value="zelle">Zelle</option>
              </select>
            </label>
            <label className="flex flex-col gap-1 text-xs text-brand-mute flex-1 min-w-[200px]">
              Handle
              <input
                type="text"
                value={handle}
                onChange={(e) => setHandle(e.target.value)}
                placeholder={
                  method === 'cashapp'
                    ? '$yourcashtag'
                    : method === 'venmo'
                      ? '@yourvenmo'
                      : 'email@example.com or +15555550100'
                }
                className="rounded-lg border border-brand-line bg-brand-bg px-3 py-2 text-brand-ink"
              />
            </label>
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              disabled={busy || !handle.trim()}
              onClick={saveHandle}
              className="btn-primary disabled:opacity-50"
            >
              {busy ? '…' : 'Save handle'}
            </button>
            {hasHandle && (
              <button
                type="button"
                onClick={() => setShowHandleForm(false)}
                className="rounded-xl border border-brand-line bg-transparent px-4 py-2 text-sm font-bold text-brand-mute hover:text-brand-ink transition-colors"
              >
                Cancel
              </button>
            )}
          </div>
        </div>
      )}

      {hasHandle && !showHandleForm && (
        <button
          type="button"
          disabled={busy || avail < min}
          onClick={cashOut}
          className="btn-primary disabled:opacity-50"
          title={avail < min ? `Minimum $${(min / 100).toFixed(2)}` : undefined}
        >
          {busy
            ? 'Sending…'
            : avail < min
              ? `Need $${(min / 100).toFixed(2)} minimum`
              : `Cash out ${usd2(avail)} now`}
        </button>
      )}

      {err && (
        <p role="alert" className="text-xs text-red-400 mt-3">
          {err}
        </p>
      )}
      {ok && <p className="text-xs text-emerald-300 mt-3">{ok}</p>}

      {last && (
        <p className="text-[11px] text-brand-mute mt-4">
          Last request: <span className="text-brand-ink">{usd2(last.amount_cents)}</span> ·{' '}
          {last.status === 'paid' ? (
            <span className="text-emerald-300">
              Paid {last.paid_at ? formatStart(last.paid_at) : ''}
            </span>
          ) : (
            <span className="text-amber-300">Pending ops send</span>
          )}
        </p>
      )}
    </div>
  );
}

function PushEnableButton() {
  const [status, setStatus] = useState<'unsupported' | 'denied' | 'subscribed' | 'idle' | 'busy'>(
    'idle',
  );
  const [err, setErr] = useState('');

  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (
      !('serviceWorker' in navigator) ||
      !('PushManager' in window) ||
      !('Notification' in window)
    ) {
      setStatus('unsupported');
      return;
    }
    if (Notification.permission === 'denied') {
      setStatus('denied');
      return;
    }
    void (async () => {
      try {
        const reg = await navigator.serviceWorker.ready;
        const sub = await reg.pushManager.getSubscription();
        if (sub) setStatus('subscribed');
      } catch {
        /* ignore */
      }
    })();
  }, []);

  async function enable() {
    setErr('');
    setStatus('busy');
    try {
      const perm = await Notification.requestPermission();
      if (perm !== 'granted') {
        setStatus(perm === 'denied' ? 'denied' : 'idle');
        return;
      }
      const keyRes = await fetch('/api/work/push/key');
      if (!keyRes.ok) {
        setErr('Push not configured. Tell ops.');
        setStatus('idle');
        return;
      }
      const { publicKey } = (await keyRes.json()) as { publicKey: string };
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(publicKey) as BufferSource,
      });
      const json = sub.toJSON() as { endpoint?: string; keys?: { p256dh?: string; auth?: string } };
      const body = {
        endpoint: json.endpoint,
        p256dh: json.keys?.p256dh,
        auth: json.keys?.auth,
        userAgent: navigator.userAgent.slice(0, 300),
      };
      const r = await fetch('/api/work/push/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (!r.ok) {
        setErr(`Subscribe failed (${r.status})`);
        setStatus('idle');
        return;
      }
      setStatus('subscribed');
    } catch (e) {
      setErr((e as Error).message || 'Failed to enable push');
      setStatus('idle');
    }
  }

  if (status === 'unsupported') return null;
  if (status === 'denied') {
    return <p className="text-xs text-brand-mute">Push blocked — enable in browser settings.</p>;
  }
  if (status === 'subscribed') {
    return (
      <p className="text-xs text-emerald-300 inline-flex items-center gap-1">
        <span aria-hidden>●</span> Push on
      </p>
    );
  }
  return (
    <button
      type="button"
      onClick={enable}
      disabled={status === 'busy'}
      className="rounded-xl border border-brand-accent/40 bg-brand-accent/10 px-3 py-1.5 text-xs font-bold text-brand-accent hover:bg-brand-accent/20 transition-colors"
      title={err || 'Get a push notification when a new gig drops in your zone'}
    >
      {status === 'busy' ? 'Enabling…' : 'Enable push'}
    </button>
  );
}

function SettingsPanel() {
  const [payload, setPayload] = useState<ProfilePayload | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const refresh = useCallback(async () => {
    setBusy(true);
    setError('');
    try {
      const res = await fetch('/api/work/profile', {
        headers: { Accept: 'application/json' },
      });
      if (!res.ok) {
        setError(`Couldn't load your profile (${res.status}). Try refreshing in a moment.`);
        return;
      }
      const data = (await res.json()) as ProfilePayload;
      setPayload(data);
    } catch {
      setError('Connection issue. Try refreshing.');
    } finally {
      setBusy(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const docByKind = useMemo(() => (payload ? indexDocs(payload.documents) : new Map()), [payload]);

  if (!payload) {
    return (
      <div
        className="rounded-2xl border border-brand-line bg-brand-card p-8 text-center text-brand-mute"
        aria-live="polite"
      >
        {error || (busy ? 'Loading your profile…' : 'Loading…')}
      </div>
    );
  }

  const { worker, documents } = payload;
  const fullName = `${worker.first_name} ${worker.last_name}`.trim() || 'Crew member';
  const licenseFront = docByKind.get('license_front');
  const licenseBack = docByKind.get('license_back');
  const insurance = docByKind.get('auto_insurance_card');
  const driveReady = !!(
    licenseFront?.status === 'verified' &&
    licenseBack?.status === 'verified' &&
    insurance?.status === 'verified'
  );

  return (
    <div className="space-y-6">
      <AvatarSection workerId={worker.id} fullName={fullName} onSaved={refresh} />

      {/* Wave 4B — tier ladder + AI coach card. Self-contained; fetches /api/work/profile/tier. */}
      <TierProgress />

      <DrivingCard
        licenseFront={licenseFront}
        licenseBack={licenseBack}
        insurance={insurance}
        driveReady={driveReady}
        canDrive={worker.can_drive === 1}
        onChange={refresh}
      />

      <PersonalSection worker={worker} onSaved={refresh} />
      <VehicleSection worker={worker} onSaved={refresh} />
      <DocsList docs={documents} onChange={refresh} />

      <BlocklistEditor />

      {error && (
        <p role="alert" className="text-sm text-red-300">
          {error}
        </p>
      )}

      <div className="flex justify-end pt-2">
        <SignOutButton />
      </div>
    </div>
  );
}

function SignOutButton() {
  const [busy, setBusy] = useState(false);
  return (
    <button
      type="button"
      disabled={busy}
      onClick={async () => {
        setBusy(true);
        try {
          await fetch('/api/work/auth/logout', { method: 'POST' });
        } finally {
          window.location.assign('/work');
        }
      }}
      className="rounded-xl border border-brand-line bg-transparent px-3 py-1.5 text-sm font-bold text-brand-mute hover:text-brand-ink transition-colors disabled:opacity-50"
    >
      {busy ? 'Signing out…' : 'Log out'}
    </button>
  );
}

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const raw = atob(base64);
  const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
  return out;
}
