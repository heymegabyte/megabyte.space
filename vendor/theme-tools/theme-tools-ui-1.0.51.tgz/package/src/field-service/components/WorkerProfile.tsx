import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AddressAutocomplete } from '../places-autocomplete.js';
import { useAvatar } from '../avatar-context.js';

// Worker self-service profile — rendered inside /work/dashboard#settings.
// First load: GET /api/work/auth/me → if 401, render the login pane.
// Authenticated: render profile form + document uploaders.
// License front/back uploaders are the headline feature — required to drive
// customer rentals (e.g. U-Haul) but optional for general labor gigs.

const TITLE = 'Worker Profile — Brick Labor';
const DESC =
  'Your Brick Labor crew profile. Upload your ID, vehicle details, and payout method. Get dispatched on local labor gigs the same day.';

function track(name: string, props: Record<string, unknown> = {}): void {
  try {
    const w = window as unknown as {
      posthog?: { capture: (n: string, p?: Record<string, unknown>) => void };
    };
    w.posthog?.capture(name, props);
  } catch {
    /* noop */
  }
}

function asErrorText(value: unknown, fallback: string): string {
  if (typeof value === 'string' && value) return value;
  if (value && typeof value === 'object' && 'message' in value) {
    const m = (value as { message?: unknown }).message;
    if (typeof m === 'string' && m) return m;
  }
  return fallback;
}

export type DocStatus = 'uploaded' | 'auto_review' | 'verified' | 'rejected' | 'expired';

export type DocKind =
  | 'license_front'
  | 'license_back'
  | 'auto_insurance_card'
  | 'liability_insurance_card'
  | 'w9'
  | 'workers_comp_ack'
  | 'liability_waiver'
  | 'cdl'
  | 'osha10'
  | 'first_aid'
  | 'epa_rrp'
  | 'lead_safe'
  | 'trade_license'
  | 'vehicle_registration'
  | 'vehicle_photo'
  | 'background_check_consent'
  | 'direct_deposit_form'
  | 'other';

export interface WorkerDoc {
  id: string;
  kind: DocKind;
  mime: string;
  size_bytes: number;
  status: DocStatus;
  license_number: string | null;
  license_state: string | null;
  license_expiry: string | null;
  license_dob: string | null;
  license_full_name: string | null;
  ocr_clarity_score: number | null;
  ocr_warnings: string | null;
  ocr_extracted_at: string | null;
  expires_at: string | null;
  rejection_reason: string | null;
  created_at: string;
}

export interface WorkerRow {
  id: string;
  status: string;
  tier: string;
  first_name: string;
  last_name: string;
  phone: string;
  email: string | null;
  preferred_pronouns: string | null;
  preferred_languages: string | null;
  address1: string | null;
  address2: string | null;
  city: string | null;
  state: string | null;
  zip: string | null;
  service_radius_miles: number | null;
  can_drive: number;
  vehicle_make: string | null;
  vehicle_model: string | null;
  vehicle_year: number | null;
  vehicle_color: string | null;
  vehicle_plate: string | null;
  vehicle_size: string | null;
  bio: string | null;
  public_profile_opt_in: number;
  public_slug: string | null;
  rating_avg: number | null;
  rating_count: number;
  jobs_completed: number;
  emergency_name: string | null;
  emergency_phone: string | null;
  emergency_relation: string | null;
}

export interface ProfilePayload {
  worker: WorkerRow;
  documents: WorkerDoc[];
  skills: { skill: string; years: number; self_rated: number }[];
}

export function WorkerProfile() {
  useThemeToolsSurface('worker-profile');
  const [authed, setAuthed] = useState<boolean | null>(null);
  const [payload, setPayload] = useState<ProfilePayload | null>(null);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    document.title = TITLE;
    setMeta('description', DESC);
    setMeta('robots', 'noindex,nofollow');
    setLink('canonical', 'https://bricklabor.com/work/dashboard#settings');
    track('worker_profile_viewed');
  }, []);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch('/api/work/profile', { headers: { Accept: 'application/json' } });
      if (res.status === 401) {
        setAuthed(false);
        return;
      }
      if (!res.ok) {
        setError(`Couldn't load your profile (${res.status}). Try again in a moment.`);
        return;
      }
      const data = (await res.json()) as ProfilePayload;
      setPayload(data);
      setAuthed(true);
    } catch {
      setError('Connection issue. Retrying might help.');
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  if (authed === null) {
    return (
      <article className="section">
        <div className="container-pad max-w-3xl">
          <p className="text-brand-mute">Loading…</p>
        </div>
      </article>
    );
  }

  if (authed === false) {
    return <LoginPane onAuthed={refresh} />;
  }

  if (!payload) {
    return (
      <article className="section">
        <div className="container-pad max-w-3xl">
          <p className="text-red-300">{error || 'Profile not available.'}</p>
        </div>
      </article>
    );
  }

  return <ProfilePane payload={payload} onChange={refresh} />;
}

function LoginPane({ onAuthed }: { onAuthed: () => void }) {
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [stage, setStage] = useState<'phone' | 'code'>('phone');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [intent, setIntent] = useState<'login' | 'signup'>('login');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const start = async () => {
    setBusy(true);
    setError('');
    try {
      const res = await fetch('/api/work/auth/start', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          phone,
          intent,
          firstName: firstName.trim() || undefined,
          lastName: lastName.trim() || undefined,
        }),
      });
      if (!res.ok) {
        const j = (await res.json().catch(() => ({}))) as { code?: string; error?: unknown };
        track('worker_application_start_failed', { intent, code: j.code ?? 'unknown' });
        if (j.code === 'not_found') {
          setError(
            "We don't have a worker with that number. Tap 'Apply' below to start a new application.",
          );
        } else if (j.code === 'name_required') {
          setError('Add your first and last name to apply.');
        } else if (j.code === 'rate_limited') {
          setError('Too many requests. Wait a minute and try again.');
        } else {
          setError(asErrorText(j.error, 'Could not send code.'));
        }
        return;
      }
      track('worker_application_submitted', { intent, hasName: Boolean(firstName && lastName) });
      setStage('code');
    } catch {
      track('worker_application_start_failed', { intent, code: 'network' });
      setError('Connection issue. Try again.');
    } finally {
      setBusy(false);
    }
  };

  const verify = async () => {
    setBusy(true);
    setError('');
    try {
      const res = await fetch('/api/work/auth/verify', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ phone, code }),
      });
      if (!res.ok) {
        const j = (await res.json().catch(() => ({}))) as { code?: string; error?: string };
        track('worker_application_verify_failed', { intent, code: j.code ?? 'unknown' });
        setError(
          j.code === 'invalid_code'
            ? 'That code did not match.'
            : asErrorText(j.error, 'Could not verify.'),
        );
        return;
      }
      track('worker_application_verified', { intent });
      onAuthed();
    } catch {
      track('worker_application_verify_failed', { intent, code: 'network' });
      setError('Connection issue. Try again.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <article className="section">
      <div className="container-pad max-w-md">
        <p className="eyebrow mb-3">Crew</p>
        <h1 className="text-4xl sm:text-5xl font-extrabold mb-2">
          {intent === 'signup' ? 'Apply to work with us' : 'Log in'}
        </h1>
        <p className="text-brand-mute mb-8">
          {intent === 'signup'
            ? 'Same-day SMS dispatch. Weekly direct deposit via Stripe Connect Express — or instant payout to your debit card. Bring your gear, we bring the gigs.'
            : 'We text you a 6-digit code. No password to remember.'}
        </p>

        {stage === 'phone' && (
          <div className="space-y-4">
            {intent === 'signup' && (
              <div className="grid grid-cols-2 gap-3">
                <label className="block">
                  <span className="block text-sm text-brand-mute mb-1">First name</span>
                  <input
                    type="text"
                    autoComplete="given-name"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    className="w-full rounded-md border border-brand-line bg-brand-card px-3 py-2 text-brand-ink"
                  />
                </label>
                <label className="block">
                  <span className="block text-sm text-brand-mute mb-1">Last name</span>
                  <input
                    type="text"
                    autoComplete="family-name"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    className="w-full rounded-md border border-brand-line bg-brand-card px-3 py-2 text-brand-ink"
                  />
                </label>
              </div>
            )}
            <label className="block">
              <span className="block text-sm text-brand-mute mb-1">Mobile phone</span>
              <input
                type="tel"
                inputMode="tel"
                autoComplete="tel"
                placeholder="(973) 555-0123"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full rounded-md border border-brand-line bg-brand-card px-3 py-2 text-brand-ink"
              />
            </label>
            <button
              type="button"
              onClick={start}
              disabled={busy || !phone}
              className="btn-primary w-full"
            >
              {busy ? 'Sending…' : 'Send code'}
            </button>
            <p className="text-center text-sm text-brand-mute">
              {intent === 'login' ? (
                <>
                  New here?{' '}
                  <button
                    type="button"
                    onClick={() => setIntent('signup')}
                    className="text-brand-accent underline-hover"
                  >
                    Apply →
                  </button>
                </>
              ) : (
                <>
                  Already on the crew?{' '}
                  <button
                    type="button"
                    onClick={() => setIntent('login')}
                    className="text-brand-accent underline-hover"
                  >
                    Log in →
                  </button>
                </>
              )}
            </p>
          </div>
        )}

        {stage === 'code' && (
          <div className="space-y-4">
            <p className="text-brand-mute text-sm">
              Sent a 6-digit code to <strong className="text-brand-ink">{phone}</strong>. It expires
              in 10 minutes.
            </p>
            <label className="block">
              <span className="block text-sm text-brand-mute mb-1">Verification code</span>
              <input
                type="text"
                inputMode="numeric"
                autoComplete="one-time-code"
                maxLength={6}
                pattern="\d{6}"
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                className="w-full rounded-md border border-brand-line bg-brand-card px-3 py-2 text-brand-ink text-center text-2xl tracking-widest"
              />
            </label>
            <button
              type="button"
              onClick={verify}
              disabled={busy || code.length !== 6}
              className="btn-primary w-full"
            >
              {busy ? 'Verifying…' : 'Verify'}
            </button>
            <button
              type="button"
              onClick={() => setStage('phone')}
              className="block w-full text-center text-sm text-brand-mute underline-hover"
            >
              ← Use a different number
            </button>
          </div>
        )}

        {error && (
          <div className="mt-4 rounded-md border border-red-500/40 bg-red-500/10 p-3 text-red-200 text-sm">
            {error}
          </div>
        )}
      </div>
    </article>
  );
}

function ProfilePane({ payload, onChange }: { payload: ProfilePayload; onChange: () => void }) {
  const { worker, documents } = payload;
  const fullName = `${worker.first_name} ${worker.last_name}`;
  const docByKind = useMemo(() => indexDocs(documents), [documents]);

  const licenseFront = docByKind.get('license_front');
  const licenseBack = docByKind.get('license_back');
  const insurance = docByKind.get('auto_insurance_card');

  const driveReady = !!(
    licenseFront?.status === 'verified' &&
    licenseBack?.status === 'verified' &&
    insurance?.status === 'verified'
  );

  return (
    <article className="section">
      <div className="container-pad max-w-3xl space-y-10">
        <header className="flex items-center justify-between gap-4">
          <div>
            <p className="eyebrow mb-2">Crew · {worker.tier}</p>
            <h1 className="text-3xl sm:text-4xl font-extrabold">{fullName}</h1>
            <p className="text-brand-mute text-sm mt-1">
              Status: <span className="text-brand-ink">{labelStatus(worker.status)}</span>
              {worker.jobs_completed > 0 && (
                <>
                  {' '}
                  · {worker.jobs_completed} job{worker.jobs_completed === 1 ? '' : 's'} done
                </>
              )}
              {worker.rating_avg && (
                <>
                  {' '}
                  · ★ {worker.rating_avg.toFixed(2)} ({worker.rating_count})
                </>
              )}
            </p>
          </div>
          <button
            type="button"
            onClick={async () => {
              await fetch('/api/work/auth/logout', { method: 'POST' });
              window.location.assign('/work');
            }}
            className="text-sm text-brand-mute underline-hover"
          >
            Log out
          </button>
        </header>

        <AvatarSection workerId={worker.id} fullName={fullName} onSaved={onChange} />

        <DrivingCard
          licenseFront={licenseFront}
          licenseBack={licenseBack}
          insurance={insurance}
          driveReady={driveReady}
          canDrive={worker.can_drive === 1}
          onChange={onChange}
        />

        <PersonalSection worker={worker} onSaved={onChange} />
        <VehicleSection worker={worker} onSaved={onChange} />
        <DocsList docs={documents} onChange={onChange} />
      </div>
    </article>
  );
}

export function AvatarSection({
  workerId,
  fullName,
  onSaved,
}: {
  workerId: string;
  fullName: string;
  onSaved: () => void;
}) {
  const { bust, bumpAvatar, setWorkerId } = useAvatar();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [missing, setMissing] = useState(false);
  const [cropping, setCropping] = useState<{ url: string; mime: string } | null>(null);

  // Hydrate the shared avatar bus so Header + sibling mounts can render this
  // worker's headshot without each refetching `/api/work/auth/me`.
  useEffect(() => {
    if (workerId) setWorkerId(workerId);
  }, [workerId, setWorkerId]);

  const src = missing ? '' : `/api/work/upload/avatar/${workerId}?v=${bust}`;
  const initials = fullName
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase() ?? '')
    .join('');

  const pickFile = (file: File) => {
    setError('');
    if (!/^image\/(jpeg|png|webp|heic)$/.test(file.type)) {
      setError('Use JPG, PNG, WebP, or HEIC.');
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setError('Keep it under 10 MB.');
      return;
    }
    if (cropping) URL.revokeObjectURL(cropping.url);
    setCropping({ url: URL.createObjectURL(file), mime: file.type });
  };

  const closeCropper = useCallback(() => {
    setCropping((prev) => {
      if (prev) URL.revokeObjectURL(prev.url);
      return null;
    });
  }, []);

  const upload = async (blob: Blob) => {
    setBusy(true);
    setError('');
    try {
      const form = new FormData();
      form.append('file', blob, 'headshot.jpg');
      const res = await fetch('/api/work/upload/avatar', { method: 'POST', body: form });
      if (!res.ok) {
        const j = (await res.json().catch(() => ({}))) as { code?: string; error?: string };
        setError(
          j.code === 'too_large'
            ? 'Image too large (max 5 MB).'
            : j.code === 'unsupported_mime'
              ? 'Use JPG, PNG, WebP, or HEIC.'
              : asErrorText(j.error, 'Upload failed.'),
        );
        return;
      }
      track('worker_avatar_uploaded');
      setMissing(false);
      bumpAvatar(workerId);
      closeCropper();
      onSaved();
    } catch {
      setError('Connection issue. Try again.');
    } finally {
      setBusy(false);
    }
  };

  const reCrop = () => {
    setError('');
    // Use the current shared `bust` so the cropper opens the freshest R2
    // object — not a duplicate that bypasses the bus.
    const url = `/api/work/upload/avatar/${workerId}?v=${bust}`;
    setCropping({ url, mime: 'image/jpeg' });
  };

  const remove = async () => {
    if (!confirm('Remove your headshot?')) return;
    setBusy(true);
    setError('');
    try {
      const res = await fetch('/api/work/upload/avatar', { method: 'DELETE' });
      if (res.ok) {
        track('worker_avatar_removed');
        setMissing(true);
        bumpAvatar(workerId);
        onSaved();
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="rounded-2xl border border-brand-line bg-brand-card p-6 sm:p-8">
      <div className="flex items-start gap-5">
        <div className="relative shrink-0">
          <div className="h-24 w-24 sm:h-28 sm:w-28 overflow-hidden rounded-full border border-brand-line bg-brand-bg/60 flex items-center justify-center">
            {!missing ? (
              <img
                src={src}
                alt={`${fullName} headshot`}
                className="block h-full w-full object-cover"
                onError={() => setMissing(true)}
              />
            ) : (
              <span className="text-2xl font-extrabold text-brand-mute">{initials || '?'}</span>
            )}
          </div>
        </div>
        <div className="flex-1 min-w-0">
          <h2 className="text-2xl font-extrabold text-brand-ink mb-1">Headshot</h2>
          <p className="text-brand-mute text-sm mb-3">
            Customers see this on the tracking page. Smile, good light, face centered. 1:1 square
            works best.
          </p>
          <div className="flex flex-wrap items-center gap-3">
            <label className="inline-block">
              <span className="sr-only">Upload headshot</span>
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp,image/heic"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) pickFile(f);
                  e.target.value = '';
                }}
                disabled={busy}
                className="block text-sm text-brand-mute file:mr-3 file:rounded-md file:border-0 file:bg-brand-accent file:px-3 file:py-1.5 file:text-sm file:font-semibold file:text-brand-bg hover:file:opacity-90 disabled:opacity-50"
              />
            </label>
            {!missing && (
              <button
                type="button"
                onClick={reCrop}
                disabled={busy}
                className="text-sm text-brand-ink underline-hover disabled:opacity-50"
              >
                Crop current
              </button>
            )}
            {!missing && (
              <button
                type="button"
                onClick={remove}
                disabled={busy}
                className="text-sm text-red-300 underline-hover disabled:opacity-50"
              >
                Remove
              </button>
            )}
          </div>
          {busy && <p className="mt-2 text-xs text-brand-mute">Uploading…</p>}
          {error && <p className="mt-2 text-xs text-red-300">{error}</p>}
        </div>
      </div>
      {cropping && (
        <AvatarCropperModal
          src={cropping.url}
          busy={busy}
          onCancel={closeCropper}
          onConfirm={upload}
        />
      )}
    </section>
  );
}

// Pure crop-math helper — kept exported for unit tests.
export function clampCropOffset(
  raw: { x: number; y: number },
  scale: number,
  natural: { w: number; h: number },
  frameSize: number,
): { x: number; y: number } {
  const drawW = natural.w * scale;
  const drawH = natural.h * scale;
  const maxX = Math.max(0, (drawW - frameSize) / 2);
  const maxY = Math.max(0, (drawH - frameSize) / 2);
  return {
    x: Math.min(maxX, Math.max(-maxX, raw.x)),
    y: Math.min(maxY, Math.max(-maxY, raw.y)),
  };
}

// Minimum scale that keeps the image fully covering the (square) crop frame.
export function computeMinCropScale(natural: { w: number; h: number }, frameSize: number): number {
  return Math.max(frameSize / natural.w, frameSize / natural.h);
}

function AvatarCropperModal({
  src,
  busy,
  onCancel,
  onConfirm,
}: {
  src: string;
  busy: boolean;
  onCancel: () => void;
  onConfirm: (blob: Blob) => Promise<void> | void;
}) {
  const imgRef = useRef<HTMLImageElement | null>(null);
  const frameRef = useRef<HTMLDivElement | null>(null);
  const cancelBtnRef = useRef<HTMLButtonElement | null>(null);
  const confirmBtnRef = useRef<HTMLButtonElement | null>(null);
  const [natural, setNatural] = useState<{ w: number; h: number } | null>(null);
  const [frameSize, setFrameSize] = useState(320);
  const [scale, setScale] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [minScale, setMinScale] = useState(1);
  const [loadError, setLoadError] = useState('');
  const [cropError, setCropError] = useState('');
  const dragRef = useRef<{ startX: number; startY: number; baseX: number; baseY: number } | null>(
    null,
  );
  const [working, setWorking] = useState(false);

  // Body scroll lock — restored on unmount.
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  // Initial focus moves to Cancel so Esc + Tab work immediately for keyboard users.
  useEffect(() => {
    cancelBtnRef.current?.focus();
  }, []);

  useEffect(() => {
    const onResize = () => {
      const w = Math.min(window.innerWidth - 64, 380);
      setFrameSize(Math.max(220, Math.floor(w)));
    };
    onResize();
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (!working) onCancel();
        return;
      }
      // Two-button focus trap — Tab cycles between Cancel and Save crop.
      if (e.key === 'Tab') {
        const cancel = cancelBtnRef.current;
        const save = confirmBtnRef.current;
        if (!cancel || !save) return;
        const active = document.activeElement;
        if (e.shiftKey && active === cancel) {
          e.preventDefault();
          save.focus();
        } else if (!e.shiftKey && active === save) {
          e.preventDefault();
          cancel.focus();
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onCancel, working]);

  const onImgLoad = () => {
    const img = imgRef.current;
    if (!img) return;
    const w = img.naturalWidth;
    const h = img.naturalHeight;
    if (!w || !h) {
      setLoadError("Couldn't read this image. Try a JPG, PNG, or WebP file.");
      return;
    }
    setLoadError('');
    setNatural({ w, h });
    const min = computeMinCropScale({ w, h }, frameSize);
    setMinScale(min);
    setScale(min);
    setOffset({ x: 0, y: 0 });
  };

  const onImgError = () => {
    // HEIC on Chromium + corrupt files land here. Surface a useful message
    // instead of stalling in "Save crop" disabled forever.
    setLoadError(
      "Your browser can't open this image. Try a JPG, PNG, or WebP — HEIC works on iOS/Safari only.",
    );
  };

  useEffect(() => {
    if (!natural) return;
    const min = computeMinCropScale(natural, frameSize);
    setMinScale(min);
    setScale((s) => (s < min ? min : s));
  }, [frameSize, natural]);

  const clampOffset = useCallback(
    (raw: { x: number; y: number }, sc: number) => {
      if (!natural) return raw;
      return clampCropOffset(raw, sc, natural, frameSize);
    },
    [natural, frameSize],
  );

  const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    (e.target as Element).setPointerCapture?.(e.pointerId);
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      baseX: offset.x,
      baseY: offset.y,
    };
  };
  const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!dragRef.current) return;
    const dx = e.clientX - dragRef.current.startX;
    const dy = e.clientY - dragRef.current.startY;
    setOffset(clampOffset({ x: dragRef.current.baseX + dx, y: dragRef.current.baseY + dy }, scale));
  };
  const onPointerUp = () => {
    dragRef.current = null;
  };

  const onZoom = (next: number) => {
    const sc = Math.max(minScale, Math.min(minScale * 4, next));
    setScale(sc);
    setOffset((o) => clampOffset(o, sc));
  };

  const confirm = async () => {
    const img = imgRef.current;
    if (!img || !natural) return;
    setWorking(true);
    setCropError('');
    try {
      const out = 512;
      const canvas = document.createElement('canvas');
      canvas.width = out;
      canvas.height = out;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        setCropError("Couldn't initialize canvas. Reload and try again.");
        return;
      }
      const drawW = natural.w * scale;
      const drawH = natural.h * scale;
      const left = frameSize / 2 - drawW / 2 + offset.x;
      const top = frameSize / 2 - drawH / 2 + offset.y;
      const sx = -left / scale;
      const sy = -top / scale;
      const sSize = frameSize / scale;
      ctx.imageSmoothingQuality = 'high';
      try {
        ctx.drawImage(img, sx, sy, sSize, sSize, 0, 0, out, out);
      } catch {
        setCropError("Couldn't read this image (security). Re-upload from your device.");
        return;
      }
      const blob: Blob | null = await new Promise((resolve) =>
        canvas.toBlob((b) => resolve(b), 'image/jpeg', 0.92),
      );
      if (!blob) {
        setCropError(
          "Couldn't export the cropped image. Try a different photo or re-upload from your device.",
        );
        return;
      }
      await onConfirm(blob);
    } finally {
      setWorking(false);
    }
  };

  const disabled = busy || working || !natural || !!loadError;

  return (
    <div
      role="dialog"
      aria-label="Crop your headshot"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      data-testid="avatar-cropper"
    >
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={() => {
          if (!working) onCancel();
        }}
        aria-hidden
      />
      <div className="relative z-10 w-full max-w-md rounded-2xl border border-brand-line bg-brand-card p-5 sm:p-6 shadow-2xl">
        <h3 className="text-xl font-extrabold text-brand-ink mb-1">Crop your headshot</h3>
        <p className="text-brand-mute text-sm mb-4">Drag to position. Use the slider to zoom.</p>
        <div className="flex flex-col items-center gap-4">
          <div
            ref={frameRef}
            className="relative overflow-hidden rounded-full border border-brand-line bg-brand-bg/70 touch-none select-none cursor-grab active:cursor-grabbing"
            style={{ width: frameSize, height: frameSize }}
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerCancel={onPointerUp}
          >
            <img
              ref={imgRef}
              src={src}
              alt=""
              draggable={false}
              onLoad={onImgLoad}
              onError={onImgError}
              style={{
                position: 'absolute',
                left: '50%',
                top: '50%',
                transform: `translate(calc(-50% + ${offset.x}px), calc(-50% + ${offset.y}px)) scale(${scale})`,
                transformOrigin: 'center',
                maxWidth: 'none',
                userSelect: 'none',
                pointerEvents: 'none',
              }}
            />
            <div
              className="pointer-events-none absolute inset-0 rounded-full"
              style={{ boxShadow: 'inset 0 0 0 2px rgba(255,107,26,0.7)' }}
            />
          </div>
          <label className="block w-full">
            <span className="block text-xs uppercase tracking-wider text-brand-mute mb-1.5">
              Zoom
            </span>
            <input
              type="range"
              min={minScale}
              max={minScale * 4}
              step={0.01}
              value={scale}
              onChange={(e) => onZoom(Number(e.target.value))}
              disabled={!natural || !!loadError}
              className="w-full accent-brand-accent disabled:opacity-50"
            />
          </label>
        </div>
        {loadError && (
          <p role="alert" className="mt-3 text-xs text-red-300">
            {loadError}
          </p>
        )}
        {cropError && (
          <p role="alert" className="mt-3 text-xs text-red-300">
            {cropError}
          </p>
        )}
        <div className="mt-5 flex flex-wrap items-center justify-end gap-3">
          <button
            ref={cancelBtnRef}
            type="button"
            onClick={onCancel}
            disabled={working}
            className="text-sm text-brand-mute hover:text-brand-ink disabled:opacity-50"
          >
            Cancel
          </button>
          <button
            ref={confirmBtnRef}
            type="button"
            onClick={confirm}
            disabled={disabled}
            className="inline-flex items-center rounded-md bg-brand-accent px-4 py-2 text-sm font-semibold text-brand-bg hover:opacity-90 disabled:opacity-50"
          >
            {working ? 'Saving…' : 'Save crop'}
          </button>
        </div>
      </div>
    </div>
  );
}

export function DrivingCard({
  licenseFront,
  licenseBack,
  insurance,
  driveReady,
  canDrive,
  onChange,
}: {
  licenseFront: WorkerDoc | undefined;
  licenseBack: WorkerDoc | undefined;
  insurance: WorkerDoc | undefined;
  driveReady: boolean;
  canDrive: boolean;
  onChange: () => void;
}) {
  return (
    <section className="rounded-2xl border border-brand-line bg-brand-card p-6 sm:p-8">
      <div className="flex items-start justify-between gap-4 mb-2">
        <div>
          <h2 className="text-2xl font-extrabold text-brand-ink">Driving credentials</h2>
          <p className="text-brand-mute text-sm mt-1">
            Optional. Required to drive customer rentals (e.g. U-Haul) or earn the driving bonus.
          </p>
        </div>
        <span
          className={`shrink-0 rounded-full px-3 py-1 text-xs font-semibold ${
            canDrive
              ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30'
              : driveReady
                ? 'bg-amber-500/10 text-amber-200 border border-amber-500/30'
                : 'bg-brand-line/40 text-brand-mute border border-brand-line'
          }`}
        >
          {canDrive
            ? '✓ Cleared to drive'
            : driveReady
              ? 'Pending dispatcher OK'
              : 'Not driving-eligible'}
        </span>
      </div>

      <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
        <LicenseSlot
          kind="license_front"
          label="License — front"
          doc={licenseFront}
          onChange={onChange}
          collectMetadata
        />
        <LicenseSlot
          kind="license_back"
          label="License — back"
          doc={licenseBack}
          onChange={onChange}
        />
      </div>

      <div className="mt-4">
        <LicenseSlot
          kind="auto_insurance_card"
          label="Auto insurance card"
          doc={insurance}
          onChange={onChange}
          collectExpiry
        />
      </div>

      {!driveReady && (
        <p className="mt-4 text-xs text-brand-mute">
          You only need these if you want driving gigs. Skip and you'll still get general labor
          work.
        </p>
      )}
    </section>
  );
}

function LicenseSlot({
  kind,
  label,
  doc,
  collectMetadata,
  collectExpiry,
  onChange,
}: {
  kind: DocKind;
  label: string;
  doc: WorkerDoc | undefined;
  collectMetadata?: boolean;
  collectExpiry?: boolean;
  onChange: () => void;
}) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [manualOpen, setManualOpen] = useState(false);
  const [expiresAt, setExpiresAt] = useState(doc?.expires_at?.slice(0, 10) ?? '');
  const [licenseNumber, setLicenseNumber] = useState(doc?.license_number ?? '');
  const [licenseState, setLicenseState] = useState(doc?.license_state ?? 'NJ');
  const [licenseExpiry, setLicenseExpiry] = useState(doc?.license_expiry ?? '');

  const isImage = doc?.mime?.startsWith('image/');
  const isPdf = doc?.mime === 'application/pdf';
  const clarity = doc?.ocr_clarity_score;
  const blurry = clarity != null && clarity < 60;
  const warnings = (doc?.ocr_warnings ?? '').split('|').filter(Boolean);
  const ocrDone = !!doc?.ocr_extracted_at;
  const showExtracted =
    collectMetadata &&
    (doc?.license_number ||
      doc?.license_state ||
      doc?.license_expiry ||
      doc?.license_dob ||
      doc?.license_full_name);

  useEffect(() => {
    setLicenseNumber(doc?.license_number ?? '');
    setLicenseState(doc?.license_state ?? 'NJ');
    setLicenseExpiry(doc?.license_expiry ?? '');
    setExpiresAt(doc?.expires_at?.slice(0, 10) ?? '');
  }, [doc?.id, doc?.license_number, doc?.license_state, doc?.license_expiry, doc?.expires_at]);

  const upload = async (file: File) => {
    setBusy(true);
    setError('');
    try {
      const form = new FormData();
      form.append('kind', kind);
      form.append('file', file);
      if (collectMetadata) {
        if (licenseNumber) form.append('licenseNumber', licenseNumber);
        if (licenseState) form.append('licenseState', licenseState);
        if (licenseExpiry) form.append('licenseExpiry', licenseExpiry);
      }
      if (collectExpiry && expiresAt) form.append('expiresAt', expiresAt);
      const res = await fetch('/api/work/upload', { method: 'POST', body: form });
      if (!res.ok) {
        const j = (await res.json().catch(() => ({}))) as { code?: string; error?: string };
        setError(
          j.code === 'too_large'
            ? 'File too large (max 8 MB).'
            : asErrorText(j.error, 'Upload failed.'),
        );
        return;
      }
      onChange();
    } catch {
      setError('Connection issue. Try again.');
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!doc) return;
    if (!confirm(`Remove ${label}? You can re-upload anytime.`)) return;
    const res = await fetch(`/api/work/upload/${doc.id}`, { method: 'DELETE' });
    if (res.ok) onChange();
  };

  const saveManual = async () => {
    if (!doc) return;
    setBusy(true);
    setError('');
    try {
      const res = await fetch(`/api/work/upload/${doc.id}/metadata`, {
        method: 'PATCH',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          licenseNumber: licenseNumber || null,
          licenseState: licenseState || null,
          licenseExpiry: licenseExpiry || null,
        }),
      });
      if (res.ok) {
        setManualOpen(false);
        onChange();
      } else {
        setError('Could not save. Try again.');
      }
    } catch {
      setError('Connection issue. Try again.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="rounded-lg border border-brand-line bg-brand-bg/40 p-4">
      <div className="flex items-center justify-between gap-3 mb-3">
        <span className="font-semibold text-brand-ink text-sm">{label}</span>
        <StatusPill status={doc?.status} />
      </div>

      {doc && isImage && (
        <div className="mb-3 overflow-hidden rounded-md border border-brand-line bg-brand-bg">
          <img
            src={`/api/work/upload/${doc.id}`}
            alt={`${label} preview`}
            className="block w-full aspect-[1.586/1] object-cover"
          />
        </div>
      )}
      {doc && isPdf && (
        <div className="mb-3 flex items-center gap-2 rounded-md border border-brand-line bg-brand-bg px-3 py-2 text-xs text-brand-mute">
          <span className="text-brand-ink">PDF</span> · {(doc.size_bytes / 1024).toFixed(0)} KB
        </div>
      )}

      {collectMetadata && doc && ocrDone && (
        <div className="mb-3 rounded-md border border-brand-line bg-brand-card/60 p-3">
          {blurry ? (
            <p className="text-xs text-amber-200 mb-2">
              Photo quality {clarity}/100 — please re-shoot in better light, no glare.
            </p>
          ) : (
            <p className="text-[10px] uppercase tracking-wider text-brand-mute mb-2">
              Auto-read · clarity {clarity ?? '—'}/100
            </p>
          )}
          {showExtracted ? (
            <dl className="grid grid-cols-2 gap-x-3 gap-y-1.5 text-xs">
              {doc.license_full_name && <ReadField label="Name" value={doc.license_full_name} />}
              {doc.license_number && <ReadField label="License #" value={doc.license_number} />}
              {doc.license_state && <ReadField label="State" value={doc.license_state} />}
              {doc.license_expiry && <ReadField label="Expires" value={doc.license_expiry} />}
              {doc.license_dob && <ReadField label="DOB" value={doc.license_dob} />}
            </dl>
          ) : (
            <p className="text-xs text-brand-mute">Couldn't auto-read. Fill in below.</p>
          )}
          {warnings.length > 0 && (
            <p className="mt-2 text-[10px] text-brand-mute">Notes: {warnings.join(', ')}</p>
          )}
          <button
            type="button"
            onClick={() => setManualOpen((v) => !v)}
            className="mt-2 text-xs text-brand-accent underline-hover"
          >
            {manualOpen ? 'Hide manual edit' : 'Edit manually'}
          </button>
        </div>
      )}

      {collectMetadata && (manualOpen || !ocrDone) && (
        <div className="grid grid-cols-3 gap-2 mb-3">
          <label className="block col-span-2">
            <span className="block text-xs text-brand-mute mb-1">License #</span>
            <input
              type="text"
              value={licenseNumber}
              onChange={(e) => setLicenseNumber(e.target.value.toUpperCase())}
              className="w-full rounded-md border border-brand-line bg-brand-card px-2 py-1.5 text-brand-ink text-sm"
            />
          </label>
          <label className="block">
            <span className="block text-xs text-brand-mute mb-1">State</span>
            <input
              type="text"
              maxLength={2}
              value={licenseState}
              onChange={(e) => setLicenseState(e.target.value.toUpperCase())}
              className="w-full rounded-md border border-brand-line bg-brand-card px-2 py-1.5 text-brand-ink text-sm"
            />
          </label>
          <label className="block col-span-3">
            <span className="block text-xs text-brand-mute mb-1">Expires</span>
            <input
              type="date"
              value={licenseExpiry}
              onChange={(e) => setLicenseExpiry(e.target.value)}
              className="w-full rounded-md border border-brand-line bg-brand-card px-2 py-1.5 text-brand-ink text-sm"
            />
          </label>
          {manualOpen && doc && (
            <button
              type="button"
              onClick={saveManual}
              disabled={busy}
              className="col-span-3 mt-1 rounded-md bg-brand-accent px-3 py-1.5 text-sm font-semibold text-brand-bg hover:opacity-90 disabled:opacity-50"
            >
              {busy ? 'Saving…' : 'Save manual edits'}
            </button>
          )}
        </div>
      )}

      {collectExpiry && (
        <label className="block mb-3">
          <span className="block text-xs text-brand-mute mb-1">Insurance expires</span>
          <input
            type="date"
            value={expiresAt}
            onChange={(e) => setExpiresAt(e.target.value)}
            className="w-full rounded-md border border-brand-line bg-brand-card px-2 py-1.5 text-brand-ink text-sm"
          />
        </label>
      )}

      <label className="block">
        <span className="block text-xs text-brand-mute mb-1">
          {doc ? (blurry ? 'Re-shoot photo' : 'Replace photo') : 'Upload photo'}
        </span>
        <input
          type="file"
          accept="image/jpeg,image/png,image/webp,image/heic,application/pdf"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) upload(f);
            e.target.value = '';
          }}
          disabled={busy}
          className="block w-full text-sm text-brand-mute file:mr-3 file:rounded-md file:border-0 file:bg-brand-accent file:px-3 file:py-1.5 file:text-sm file:font-semibold file:text-brand-bg hover:file:opacity-90 disabled:opacity-50"
        />
      </label>

      {doc && (
        <div className="mt-2 flex items-center justify-between text-xs">
          <span className="text-brand-mute">
            {(doc.size_bytes / 1024).toFixed(0)} KB · uploaded {formatDateShort(doc.created_at)}
          </span>
          {doc.status !== 'verified' && (
            <button type="button" onClick={remove} className="text-red-300 underline-hover">
              Remove
            </button>
          )}
        </div>
      )}

      {doc?.rejection_reason && doc.status === 'rejected' && (
        <p className="mt-2 text-xs text-red-300">Rejected: {doc.rejection_reason}</p>
      )}

      {error && <p className="mt-2 text-xs text-red-300">{error}</p>}
      {busy && <p className="mt-2 text-xs text-brand-mute">Working…</p>}
    </div>
  );
}

function ReadField({ label, value }: { label: string; value: string }) {
  return (
    <>
      <dt className="text-brand-mute">{label}</dt>
      <dd className="text-brand-ink font-mono">{value}</dd>
    </>
  );
}

function StatusPill({ status }: { status: DocStatus | undefined }) {
  if (!status) {
    return (
      <span className="rounded-full border border-brand-line bg-brand-line/30 px-2 py-0.5 text-[10px] uppercase tracking-wider text-brand-mute">
        Missing
      </span>
    );
  }
  const tone = toneFor(status);
  return (
    <span className={`rounded-full px-2 py-0.5 text-[10px] uppercase tracking-wider ${tone}`}>
      {labelDocStatus(status)}
    </span>
  );
}

export function PersonalSection({ worker, onSaved }: { worker: WorkerRow; onSaved: () => void }) {
  const [state, setState] = useState({
    firstName: worker.first_name ?? '',
    lastName: worker.last_name ?? '',
    email: worker.email ?? '',
    address1: worker.address1 ?? '',
    address2: worker.address2 ?? '',
    city: worker.city ?? '',
    stateAbbr: worker.state ?? 'NJ',
    zip: worker.zip ?? '',
    serviceRadiusMiles: worker.service_radius_miles ?? 15,
    bio: worker.bio ?? '',
    emergencyName: worker.emergency_name ?? '',
    emergencyPhone: worker.emergency_phone ?? '',
    emergencyRelation: worker.emergency_relation ?? '',
  });
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState(false);

  const save = async () => {
    setBusy(true);
    setSaved(false);
    const res = await fetch('/api/work/profile', {
      method: 'PUT',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        firstName: state.firstName.trim() || undefined,
        lastName: state.lastName.trim() || undefined,
        email: state.email || undefined,
        address1: state.address1 || undefined,
        address2: state.address2 || undefined,
        city: state.city || undefined,
        state: state.stateAbbr || undefined,
        zip: state.zip || undefined,
        serviceRadiusMiles: state.serviceRadiusMiles,
        bio: state.bio || undefined,
        emergencyName: state.emergencyName || undefined,
        emergencyPhone: state.emergencyPhone || undefined,
        emergencyRelation: state.emergencyRelation || undefined,
      }),
    });
    if (res.ok) {
      setSaved(true);
      onSaved();
    }
    setBusy(false);
  };

  return (
    <section className="rounded-2xl border border-brand-line bg-brand-card p-6 sm:p-8">
      <h2 className="text-2xl font-extrabold text-brand-ink mb-1">Contact & service area</h2>
      <p className="text-brand-mute text-sm mb-6">
        We dispatch to ZIPs within your radius. Bigger radius, more gigs.
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <Field
          label="First name"
          value={state.firstName}
          onChange={(v) => setState({ ...state, firstName: v })}
          autoComplete="given-name"
        />
        <Field
          label="Last name"
          value={state.lastName}
          onChange={(v) => setState({ ...state, lastName: v })}
          autoComplete="family-name"
        />
        <Field
          label="Email"
          value={state.email}
          onChange={(v) => setState({ ...state, email: v })}
          type="email"
        />
        <Field
          label="Service radius (mi)"
          value={String(state.serviceRadiusMiles)}
          onChange={(v) => setState({ ...state, serviceRadiusMiles: Number(v) || 15 })}
          type="number"
        />
        <div className="sm:col-span-2">
          <AddressAutocomplete
            label="Address"
            value={state.address1}
            onChange={(v) => setState({ ...state, address1: v })}
            onSelect={(r) =>
              setState((prev) => ({
                ...prev,
                address1: r.address1 || prev.address1,
                city: r.city || prev.city,
                stateAbbr: r.state || prev.stateAbbr,
                zip: r.zip || prev.zip,
              }))
            }
          />
        </div>
        <Field
          label="Apt / unit"
          value={state.address2}
          onChange={(v) => setState({ ...state, address2: v })}
        />
        <Field label="City" value={state.city} onChange={(v) => setState({ ...state, city: v })} />
        <Field
          label="State"
          value={state.stateAbbr}
          onChange={(v) => setState({ ...state, stateAbbr: v.toUpperCase().slice(0, 2) })}
        />
        <Field
          label="ZIP"
          value={state.zip}
          onChange={(v) => setState({ ...state, zip: v.replace(/\D/g, '').slice(0, 5) })}
        />
      </div>

      <label className="block mt-4">
        <span className="block text-sm text-brand-mute mb-1">
          Short bio (shown on public profile if you opt in)
        </span>
        <textarea
          maxLength={600}
          rows={3}
          value={state.bio}
          onChange={(e) => setState({ ...state, bio: e.target.value })}
          className="w-full rounded-md border border-brand-line bg-brand-bg/40 px-3 py-2 text-brand-ink"
        />
        <span className="block text-xs text-brand-mute mt-1">{state.bio.length}/600</span>
      </label>

      <h3 className="text-lg font-extrabold text-brand-ink mt-6 mb-2">Emergency contact</h3>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <Field
          label="Name"
          value={state.emergencyName}
          onChange={(v) => setState({ ...state, emergencyName: v })}
        />
        <Field
          label="Phone"
          value={state.emergencyPhone}
          onChange={(v) => setState({ ...state, emergencyPhone: v })}
          type="tel"
        />
        <Field
          label="Relation"
          value={state.emergencyRelation}
          onChange={(v) => setState({ ...state, emergencyRelation: v })}
        />
      </div>

      <div className="mt-6 flex items-center gap-3">
        <button type="button" onClick={save} disabled={busy} className="btn-primary">
          {busy ? 'Saving…' : 'Save'}
        </button>
        {saved && <span className="text-emerald-300 text-sm">✓ Saved</span>}
      </div>
    </section>
  );
}

export function VehicleSection({ worker, onSaved }: { worker: WorkerRow; onSaved: () => void }) {
  const [state, setState] = useState({
    vehicleMake: worker.vehicle_make ?? '',
    vehicleModel: worker.vehicle_model ?? '',
    vehicleYear: worker.vehicle_year ?? null,
    vehicleColor: worker.vehicle_color ?? '',
    vehiclePlate: worker.vehicle_plate ?? '',
    vehicleSize: worker.vehicle_size ?? '',
  });
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState(false);

  const save = async () => {
    setBusy(true);
    setSaved(false);
    const res = await fetch('/api/work/profile', {
      method: 'PUT',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        vehicleMake: state.vehicleMake || undefined,
        vehicleModel: state.vehicleModel || undefined,
        vehicleYear: state.vehicleYear || undefined,
        vehicleColor: state.vehicleColor || undefined,
        vehiclePlate: state.vehiclePlate || undefined,
        vehicleSize: state.vehicleSize || undefined,
      }),
    });
    if (res.ok) {
      setSaved(true);
      onSaved();
    }
    setBusy(false);
  };

  return (
    <section className="rounded-2xl border border-brand-line bg-brand-card p-6 sm:p-8">
      <h2 className="text-2xl font-extrabold text-brand-ink mb-1">Vehicle</h2>
      <p className="text-brand-mute text-sm mb-6">
        For driving + hauling gigs. Pickup or cargo van earns the hauling bonus.
      </p>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        <Field
          label="Make"
          value={state.vehicleMake}
          onChange={(v) => setState({ ...state, vehicleMake: v })}
        />
        <Field
          label="Model"
          value={state.vehicleModel}
          onChange={(v) => setState({ ...state, vehicleModel: v })}
        />
        <Field
          label="Year"
          value={state.vehicleYear ? String(state.vehicleYear) : ''}
          onChange={(v) => setState({ ...state, vehicleYear: Number(v) || null })}
          type="number"
        />
        <Field
          label="Color"
          value={state.vehicleColor}
          onChange={(v) => setState({ ...state, vehicleColor: v })}
        />
        <Field
          label="Plate"
          value={state.vehiclePlate}
          onChange={(v) => setState({ ...state, vehiclePlate: v.toUpperCase() })}
        />
        <label className="block">
          <span className="block text-sm text-brand-mute mb-1">Size</span>
          <select
            value={state.vehicleSize}
            onChange={(e) => setState({ ...state, vehicleSize: e.target.value })}
            className="w-full rounded-md border border-brand-line bg-brand-bg/40 px-3 py-2 text-brand-ink"
          >
            <option value="">—</option>
            <option value="compact">Compact</option>
            <option value="sedan">Sedan</option>
            <option value="suv">SUV</option>
            <option value="pickup">Pickup</option>
            <option value="cargo_van">Cargo van</option>
            <option value="box_truck">Box truck</option>
            <option value="other">Other</option>
          </select>
        </label>
      </div>
      <div className="mt-6 flex items-center gap-3">
        <button type="button" onClick={save} disabled={busy} className="btn-primary">
          {busy ? 'Saving…' : 'Save'}
        </button>
        {saved && <span className="text-emerald-300 text-sm">✓ Saved</span>}
      </div>
    </section>
  );
}

export function DocsList({ docs, onChange }: { docs: WorkerDoc[]; onChange: () => void }) {
  const otherDocs = docs.filter(
    (d) => !['license_front', 'license_back', 'auto_insurance_card'].includes(d.kind),
  );
  return (
    <section className="rounded-2xl border border-brand-line bg-brand-card p-6 sm:p-8">
      <h2 className="text-2xl font-extrabold text-brand-ink mb-1">Other documents</h2>
      <p className="text-brand-mute text-sm mb-6">
        Optional certs and forms. Upload anything that helps you qualify for more gigs.
      </p>

      <DocUploader onUploaded={onChange} />

      {otherDocs.length > 0 && (
        <ul className="mt-6 space-y-2">
          {otherDocs.map((d) => (
            <li
              key={d.id}
              className="flex items-center justify-between gap-3 rounded-md border border-brand-line bg-brand-bg/40 px-3 py-2"
            >
              <div>
                <span className="block font-semibold text-brand-ink text-sm">
                  {labelKind(d.kind)}
                </span>
                <span className="block text-xs text-brand-mute">
                  {(d.size_bytes / 1024).toFixed(0)} KB · {formatDateShort(d.created_at)}
                </span>
              </div>
              <StatusPill status={d.status} />
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function DocUploader({ onUploaded }: { onUploaded: () => void }) {
  const [kind, setKind] = useState<DocKind>('w9');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const upload = async (file: File) => {
    setBusy(true);
    setError('');
    const form = new FormData();
    form.append('kind', kind);
    form.append('file', file);
    const res = await fetch('/api/work/upload', { method: 'POST', body: form });
    if (!res.ok) {
      const j = (await res.json().catch(() => ({}))) as { error?: string };
      setError(asErrorText(j.error, 'Upload failed.'));
    } else {
      onUploaded();
    }
    setBusy(false);
  };

  return (
    <div className="rounded-lg border border-brand-line bg-brand-bg/40 p-4">
      <div className="flex flex-col sm:flex-row gap-3">
        <select
          value={kind}
          onChange={(e) => setKind(e.target.value as DocKind)}
          className="rounded-md border border-brand-line bg-brand-card px-3 py-2 text-brand-ink text-sm"
        >
          <option value="w9">W-9</option>
          <option value="workers_comp_ack">Workers' comp ack</option>
          <option value="liability_waiver">Liability waiver</option>
          <option value="liability_insurance_card">Liability insurance card</option>
          <option value="cdl">CDL</option>
          <option value="osha10">OSHA 10</option>
          <option value="first_aid">First aid cert</option>
          <option value="epa_rrp">EPA RRP</option>
          <option value="lead_safe">Lead-safe cert</option>
          <option value="trade_license">Trade license</option>
          <option value="vehicle_registration">Vehicle registration</option>
          <option value="vehicle_photo">Vehicle photo</option>
          <option value="background_check_consent">Background check consent</option>
          <option value="direct_deposit_form">Direct deposit form</option>
          <option value="other">Other</option>
        </select>
        <input
          type="file"
          accept="image/jpeg,image/png,image/webp,image/heic,application/pdf"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) upload(f);
            e.target.value = '';
          }}
          disabled={busy}
          className="flex-1 text-sm text-brand-mute file:mr-3 file:rounded-md file:border-0 file:bg-brand-accent file:px-3 file:py-1.5 file:text-sm file:font-semibold file:text-brand-bg hover:file:opacity-90 disabled:opacity-50"
        />
      </div>
      {error && <p className="mt-2 text-xs text-red-300">{error}</p>}
      {busy && <p className="mt-2 text-xs text-brand-mute">Uploading…</p>}
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = 'text',
  autoComplete,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  autoComplete?: string;
}) {
  return (
    <label className="block">
      <span className="block text-sm text-brand-mute mb-1">{label}</span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        autoComplete={autoComplete}
        className="w-full rounded-md border border-brand-line bg-brand-bg/40 px-3 py-2 text-brand-ink"
      />
    </label>
  );
}

export function indexDocs(docs: WorkerDoc[]): Map<DocKind, WorkerDoc> {
  // Most-recent doc per kind wins.
  const map = new Map<DocKind, WorkerDoc>();
  for (const d of docs) {
    const existing = map.get(d.kind);
    if (!existing || new Date(d.created_at).getTime() > new Date(existing.created_at).getTime()) {
      map.set(d.kind, d);
    }
  }
  return map;
}

export function labelStatus(s: string): string {
  return s.replace(/_/g, ' ');
}

function labelDocStatus(s: DocStatus): string {
  if (s === 'auto_review') return 'reviewing';
  if (s === 'uploaded') return 'pending';
  return s;
}

function toneFor(status: DocStatus): string {
  if (status === 'verified')
    return 'border border-emerald-500/30 bg-emerald-500/10 text-emerald-300';
  if (status === 'rejected') return 'border border-red-500/30 bg-red-500/10 text-red-300';
  if (status === 'expired') return 'border border-red-500/30 bg-red-500/10 text-red-300';
  if (status === 'auto_review' || status === 'uploaded')
    return 'border border-amber-500/30 bg-amber-500/10 text-amber-200';
  return 'border border-brand-line bg-brand-line/30 text-brand-mute';
}

function labelKind(k: DocKind): string {
  return k
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (m) => m.toUpperCase())
    .replace(/Cdl/, 'CDL')
    .replace(/W9/, 'W-9')
    .replace(/Osha10/, 'OSHA 10')
    .replace(/Epa Rrp/, 'EPA RRP');
}

function formatDateShort(iso: string): string {
  const dt = new Date(iso);
  if (Number.isNaN(dt.getTime())) return iso;
  return dt.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

function setMeta(name: string, content: string) {
  let el = document.querySelector<HTMLMetaElement>(`meta[name="${name}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute('name', name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function setLink(rel: string, href: string) {
  let el = document.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', rel);
    document.head.appendChild(el);
  }
  el.setAttribute('href', href);
}
