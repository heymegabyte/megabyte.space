import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useEffect, useState, type JSX, type ReactNode } from 'react';
import { SuperAdminGuard } from './SuperAdminGuard.js';
import {
  DashboardShell,
  type DashboardBreadcrumb,
  type DashboardNavGroup,
} from '../shell/DashboardShell.js';
import type { UserAvatarMenuGroup } from '../shell/UserAvatarMenu.js';

/**
 * AdminShell — operations console shell. Thin wrapper around DashboardShell
 * that wires the admin nav grouping, live polling badges (unread events /
 * fraud / open gigs), the top-right user avatar with admin-specific menu
 * (Impersonate / Sign out), and SuperAdminGuard so anonymous visitors get
 * redirected to /admin/login.
 *
 * Usage from App.tsx is unchanged — same `section` + `title` + `breadcrumb`
 * props as the previous standalone shell.
 */

type AdminSectionKey =
  | 'overview'
  | 'jobs'
  | 'customers'
  | 'workers'
  | 'applicants'
  | 'finance'
  | '1099'
  | 'fraud'
  | 'channels'
  | 'marketing'
  | 'notifications'
  | 'rules'
  | 'widgets'
  | 'wave20'
  | 'safety'
  | 'ops'
  | 'super-admin';

export interface AdminShellProps {
  readonly section: AdminSectionKey;
  readonly title: string;
  readonly breadcrumb?: ReadonlyArray<DashboardBreadcrumb>;
  readonly headerActions?: ReactNode;
  readonly children: ReactNode;
}

interface AdminNavItem {
  readonly key: AdminSectionKey;
  readonly label: string;
  readonly href: string;
  readonly icon: string;
  readonly badgeKey?: 'unread' | 'fraud' | 'open';
}

interface AdminNavGroup {
  readonly label?: string;
  readonly items: ReadonlyArray<AdminNavItem>;
}

const NAV: ReadonlyArray<AdminNavGroup> = [
  {
    label: 'Overview',
    items: [
      { key: 'overview', label: 'Today', href: '/admin/super-admin', icon: '◎' },
      {
        key: 'notifications',
        label: 'Notifications',
        href: '/admin/notifications',
        icon: '◍',
        badgeKey: 'unread',
      },
      { key: 'wave20', label: 'Feature grid', href: '/admin/wave20', icon: '▦' },
    ],
  },
  {
    label: 'Operations',
    items: [
      { key: 'jobs', label: 'Jobs', href: '/admin/jobs', icon: '◇', badgeKey: 'open' },
      { key: 'customers', label: 'Customers', href: '/admin/customers', icon: '◌' },
      { key: 'workers', label: 'Crew', href: '/admin/workers', icon: '◈' },
      { key: 'applicants', label: 'Applicants', href: '/admin/applicants', icon: '☷' },
      { key: 'channels', label: 'Channels', href: '/admin/channels', icon: '☶' },
    ],
  },
  {
    label: 'Finance',
    items: [
      { key: 'finance', label: 'Finance', href: '/admin/finance', icon: '$' },
      {
        key: 'fraud',
        label: 'Fraud queue',
        href: '/admin/finance/fraud',
        icon: '⚠',
        badgeKey: 'fraud',
      },
    ],
  },
  {
    label: 'Marketing',
    items: [{ key: 'marketing', label: 'Marketing studio', href: '/admin/marketing', icon: '◐' }],
  },
  {
    label: 'System',
    items: [
      { key: 'rules', label: 'AI rules', href: '/admin/rules', icon: '◬' },
      { key: 'widgets', label: 'Widgets', href: '/admin/widgets', icon: '☐' },
      { key: 'safety', label: 'Safety', href: '/admin/safety', icon: '☗' },
      { key: 'ops', label: 'Ops health', href: '/admin/ops', icon: '☱' },
      { key: 'super-admin', label: 'Super-admin', href: '/admin/super-admin', icon: '◆' },
    ],
  },
];

interface AdminBadges {
  readonly unread: number;
  readonly fraud: number;
  readonly open: number;
}

const EMPTY_BADGES: AdminBadges = { unread: 0, fraud: 0, open: 0 };

function getOwnerKey(): string {
  if (typeof window === 'undefined') return '';
  return window.localStorage.getItem('bcl_owner_key') ?? '';
}

async function fetchBadges(): Promise<AdminBadges> {
  const key = getOwnerKey();
  if (!key) return EMPTY_BADGES;
  try {
    const res = await fetch('/api/admin/today', {
      headers: { Authorization: `Bearer ${key}` },
      credentials: 'include',
    });
    if (!res.ok) return EMPTY_BADGES;
    const data = (await res.json().catch(() => null)) as {
      unreadEvents24h?: number;
      fraudQueueOpen?: number;
      openGigs?: number;
    } | null;
    if (!data) return EMPTY_BADGES;
    return {
      unread: data.unreadEvents24h ?? 0,
      fraud: data.fraudQueueOpen ?? 0,
      open: data.openGigs ?? 0,
    };
  } catch {
    return EMPTY_BADGES;
  }
}

function adminLogout(): void {
  try {
    localStorage.removeItem('bcl_admin_token');
    localStorage.removeItem('bcl_owner_key');
  } catch {
    /* ignore */
  }
  window.location.href = '/admin/login';
}

export function AdminShell({
  section,
  title,
  breadcrumb,
  headerActions,
  children,
}: AdminShellProps): JSX.Element {
  useThemeToolsSurface('admin-shell');
  return (
    <SuperAdminGuard>
      <ShellInner
        section={section}
        title={title}
        breadcrumb={breadcrumb}
        headerActions={headerActions}
      >
        {children}
      </ShellInner>
    </SuperAdminGuard>
  );
}

function ShellInner({
  section,
  title,
  breadcrumb,
  headerActions,
  children,
}: AdminShellProps): JSX.Element {
  const [badges, setBadges] = useState<AdminBadges>(EMPTY_BADGES);

  useEffect(() => {
    let cancelled = false;
    void fetchBadges().then((b) => {
      if (!cancelled) setBadges(b);
    });
    const timer = window.setInterval(() => {
      void fetchBadges().then((b) => {
        if (!cancelled) setBadges(b);
      });
    }, 45_000);
    return () => {
      cancelled = true;
      window.clearInterval(timer);
    };
  }, []);

  const navGroups: DashboardNavGroup[] = NAV.map((group) => ({
    label: group.label,
    items: group.items.map((item) => ({
      key: item.key,
      label: item.label,
      href: item.href,
      icon: item.icon,
      badge:
        item.badgeKey === 'unread'
          ? badges.unread
          : item.badgeKey === 'fraud'
            ? badges.fraud
            : item.badgeKey === 'open'
              ? badges.open
              : undefined,
      danger: item.badgeKey === 'fraud',
    })),
  }));

  const userMenu: UserAvatarMenuGroup[] = [
    {
      items: [
        { label: 'Operations cockpit', href: '/admin/super-admin', icon: '◎' },
        { label: 'Notifications', href: '/admin/notifications', icon: '◍' },
      ],
    },
    {
      label: 'Other dashboards',
      items: [
        { label: 'Customer view', href: '/me', icon: '◌' },
        { label: 'Crew view', href: '/work/dashboard', icon: '◈' },
      ],
    },
    {
      items: [
        { label: 'Back to public site', href: '/', icon: '←', external: false },
        { label: 'Sign out', onClick: adminLogout, icon: '⎋', danger: true },
      ],
    },
  ];

  return (
    <DashboardShell
      active={section}
      title={title}
      breadcrumb={breadcrumb}
      nav={navGroups}
      userDisplayName="Operator"
      userSubtitle="Super-admin"
      userMenu={userMenu}
      headerActions={headerActions}
      brandBadge="ADMIN"
    >
      {children}
    </DashboardShell>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
