import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useEffect, useState } from 'react';

interface InsightSummary {
  bookings: number;
  paid: number;
  revenueCents: number;
  completion: number;
  topErrors: Array<{ kind: string; count: number }>;
}

/**
 * Daily insights summarizer. The card derives a quick narrative from the
 * birds-eye KPI snapshot — no separate endpoint needed. When ANTHROPIC_API_KEY
 * is available server-side, we can extend this to call /api/admin/insights
 * for a longer LLM-written brief; for now we stay deterministic.
 */
export function AiInsightsCard({ headers }: { headers: HeadersInit }) {
  useThemeToolsSurface('ai-insights-card');
  const [data, setData] = useState<InsightSummary | null>(null);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    let cancelled = false;
    fetch('/api/admin/birds-eye', { headers })
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error(`status_${r.status}`))))
      .then(
        (json: {
          today: {
            bookingsCreated: number;
            bookingsPaid: number;
            revenueCents: number;
            completionRatePct: number;
          };
          topErrors: Array<{ kind: string; count: number }>;
        }) => {
          if (cancelled) return;
          setData({
            bookings: json.today.bookingsCreated,
            paid: json.today.bookingsPaid,
            revenueCents: json.today.revenueCents,
            completion: json.today.completionRatePct,
            topErrors: json.topErrors,
          });
        },
      )
      .catch((err: Error) => {
        if (!cancelled) setError(err.message);
      });
    return () => {
      cancelled = true;
    };
  }, [headers]);

  if (error) return <p className="text-sm text-red-300">{error}</p>;
  if (!data) return <p className="text-brand-mute text-sm">Crunching the day…</p>;

  const conversion = data.bookings > 0 ? Math.round((data.paid / data.bookings) * 100) : null;

  return (
    <div className="space-y-3" data-testid="ai-insights">
      <p className="leading-relaxed">
        Today: <strong>{data.bookings}</strong> new bookings, <strong>{data.paid}</strong> paid
        deposits ({conversion == null ? '—' : `${conversion}% same-day conversion`}),{' '}
        <strong>${(data.revenueCents / 100).toFixed(0)}</strong> collected. 30-day completion sits
        at <strong>{data.completion}%</strong>.
      </p>
      {data.topErrors.length > 0 ? (
        <div className="rounded border border-amber-500/30 bg-amber-500/10 p-3 text-sm">
          <strong>Watch:</strong>{' '}
          <span className="inline-flex flex-wrap gap-1.5 align-middle">
            {data.topErrors.map((e) => (
              <span
                key={e.kind}
                className="inline-flex items-center gap-1 rounded-full bg-amber-500/20 px-2.5 py-0.5 text-xs font-medium text-amber-200 transition-all duration-[333ms] hover:-translate-y-px hover:bg-amber-500/35 hover:shadow-sm"
              >
                {e.kind}
                <span className="font-bold text-amber-100">×{e.count}</span>
              </span>
            ))}
          </span>{' '}
          in the last 24h. Investigate before they normalize.
        </div>
      ) : (
        <p className="text-emerald-300 text-sm">No error spikes in the last 24h.</p>
      )}
      <p className="text-brand-mute text-xs">
        Insight derived from /api/admin/birds-eye — refresh page for the next snapshot.
      </p>
    </div>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
