import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useState, type JSX } from 'react';

/**
 * ApplicantsBrowser — operator review surface for crew-intake applicants.
 * Lists applicants (filterable by status), opens a detail drawer (verification,
 * answers, AI dispatch profile, driver path, missing items), and moves them
 * through review statuses. Calls `/api/admin/applicants` with the super-admin
 * session cookie (ownerOrSuperAdmin gate). The server refuses `dispatch_ready`
 * until every required check clears.
 */

interface ListRow {
  id: string;
  status: string;
  name: string;
  city: string;
  wantsDriver: boolean;
  emailVerified: boolean;
  phoneVerified: boolean;
  submittedAt: string | null;
  updatedAt: string;
}

interface ChecklistItem {
  key: string;
  label: string;
  done: boolean;
  applicable: boolean;
}

interface AdminApplicant {
  id: string;
  status: string;
  legalFirstName: string;
  legalLastName: string;
  email: string;
  phone: string;
  city: string;
  zip: string;
  emailVerified: boolean;
  phoneVerified: boolean;
  wantsDriver: boolean;
  aiSummary: string | null;
  aiDispatchProfile: string | null;
  aiTags: string[];
  aiSafetyNotes: string[];
  aiMissingInfo: string[];
  aiDriverProfile: string | null;
  aiCrewLeadPotential: string | null;
  driver: {
    licenseState: string | null;
    frontUploaded: boolean;
    backUploaded: boolean;
    identityStatus: string | null;
    mvrStatus: string | null;
  };
  background: { status: string | null };
  checklist: ChecklistItem[];
  adminNotes: string | null;
}

const STATUS_FILTERS = [
  '',
  'profile_complete',
  'needs_phone_screen',
  'conditionally_approved',
  'background_check_invited',
  'driver_docs_needed',
  'dispatch_ready',
  'rejected',
];

async function aj<T>(
  path: string,
  method: 'GET' | 'POST',
  body?: unknown,
): Promise<{ ok: boolean; data: T }> {
  const res = await fetch(`/api/admin/applicants${path}`, {
    method,
    credentials: 'include',
    headers: body ? { 'content-type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = (await res.json().catch(() => ({}))) as T;
  return { ok: res.ok, data };
}

export function ApplicantsBrowser(): JSX.Element {
  useThemeToolsSurface('applicants-browser');
  const [rows, setRows] = useState<ListRow[]>([]);
  const [status, setStatus] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selected, setSelected] = useState<AdminApplicant | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    const r = await aj<{ ok: boolean; applicants?: ListRow[] }>(
      status ? `?status=${encodeURIComponent(status)}` : '',
      'GET',
    );
    setLoading(false);
    if (!r.ok || !r.data.applicants) {
      setError('Sign in as an operator to view applicants.');
      return;
    }
    setRows(r.data.applicants);
  }, [status]);

  useEffect(() => {
    void load();
  }, [load]);

  const open = async (id: string) => {
    const r = await aj<{ ok: boolean; applicant?: AdminApplicant }>(`/${id}`, 'GET');
    if (r.ok && r.data.applicant) setSelected(r.data.applicant);
  };

  const transition = async (to: string) => {
    if (!selected) return;
    const r = await aj<{
      ok: boolean;
      applicant?: AdminApplicant;
      blockers?: string[];
      code?: string;
    }>(`/${selected.id}/transition`, 'POST', { to });
    if (!r.ok) {
      setError(
        r.data.code === 'dispatch_blocked'
          ? `Blocked: ${(r.data.blockers ?? []).join(', ')}`
          : 'Transition not allowed.',
      );
      return;
    }
    if (r.data.applicant) setSelected(r.data.applicant);
    void load();
  };

  const inviteBackground = async () => {
    if (!selected) return;
    const r = await aj<{ ok: boolean; applicant?: AdminApplicant }>(
      `/${selected.id}/background/invite`,
      'POST',
    );
    if (r.ok && r.data.applicant) setSelected(r.data.applicant);
    void load();
  };

  return (
    <div className="grid gap-4" data-testid="admin-applicants">
      <div className="flex flex-wrap items-center gap-2">
        {STATUS_FILTERS.map((s) => (
          <button
            key={s || 'all'}
            type="button"
            onClick={() => setStatus(s)}
            className={`rounded-full border px-3 py-1 text-xs ${status === s ? 'border-brand-accent bg-brand-accent/10 text-brand-ink' : 'border-brand-line text-brand-mute'}`}
          >
            {s ? s.replace(/_/g, ' ') : 'all'}
          </button>
        ))}
      </div>

      {loading && <p className="text-sm text-brand-mute">Loading applicants…</p>}
      {error && (
        <p className="text-sm text-amber-400" role="status">
          {error}
        </p>
      )}

      {!loading && !error && (
        <table className="w-full text-left text-sm">
          <thead className="text-xs uppercase tracking-wider text-brand-mute">
            <tr>
              <th className="py-2">Name</th>
              <th>City</th>
              <th>Status</th>
              <th>Verified</th>
              <th>Driver</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr
                key={r.id}
                className="border-t border-brand-line hover:bg-brand-accent/5 focus-within:bg-brand-accent/5"
              >
                <td className="py-2 font-medium text-brand-ink">
                  <button
                    type="button"
                    onClick={() => void open(r.id)}
                    aria-label={`Open applicant ${r.name || r.id}`}
                    data-testid="applicant-open"
                    className="rounded text-left hover:text-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
                  >
                    {r.name || '—'}
                  </button>
                </td>
                <td className="text-brand-mute">{r.city}</td>
                <td>
                  <span className="font-mono text-xs">{r.status}</span>
                </td>
                <td className="text-xs">
                  {r.emailVerified ? '✉︎' : '·'} {r.phoneVerified ? '☎︎' : '·'}
                </td>
                <td className="text-xs">{r.wantsDriver ? 'yes' : '—'}</td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr>
                <td colSpan={5} className="py-6 text-center text-brand-mute">
                  No applicants in this status.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      )}

      {selected && (
        <div
          className="rounded-xl border border-brand-line bg-brand-card p-4"
          data-testid="applicant-detail"
        >
          <div className="flex items-start justify-between gap-3">
            <div>
              <h3 className="text-lg font-semibold text-brand-ink">
                {selected.legalFirstName} {selected.legalLastName}
              </h3>
              <p className="text-xs text-brand-mute">
                {selected.email} · {selected.phone} · {selected.city} {selected.zip}
              </p>
              <p className="mt-1 font-mono text-xs text-brand-accent">{selected.status}</p>
            </div>
            <button
              type="button"
              onClick={() => setSelected(null)}
              className="text-xs text-brand-mute"
            >
              close ✕
            </button>
          </div>

          {selected.aiDispatchProfile && (
            <div className="mt-3 rounded-lg border border-brand-line bg-bg-primary p-3">
              <p className="text-[10px] uppercase tracking-wider text-brand-mute">
                AI dispatch profile · crew-lead {selected.aiCrewLeadPotential}
              </p>
              <p className="mt-1 text-sm text-brand-ink">{selected.aiDispatchProfile}</p>
              {selected.aiSafetyNotes.length > 0 && (
                <ul className="mt-2 text-xs text-amber-400">
                  {selected.aiSafetyNotes.map((n, i) => (
                    <li key={i}>⚠ {n}</li>
                  ))}
                </ul>
              )}
            </div>
          )}

          {selected.wantsDriver && (
            <p className="mt-3 text-xs text-brand-mute">
              Driver: {selected.driver.licenseState ?? '—'} · front{' '}
              {selected.driver.frontUploaded ? '✓' : '✗'} · back{' '}
              {selected.driver.backUploaded ? '✓' : '✗'} · identity{' '}
              {selected.driver.identityStatus ?? '—'} · mvr {selected.driver.mvrStatus ?? '—'}
            </p>
          )}

          <div className="mt-3">
            <p className="text-[10px] uppercase tracking-wider text-brand-mute">Checklist</p>
            <ul className="mt-1 grid grid-cols-2 gap-1 text-xs">
              {selected.checklist
                .filter((c) => c.applicable)
                .map((c) => (
                  <li key={c.key} className={c.done ? 'text-emerald-400' : 'text-brand-mute'}>
                    {c.done ? '✓' : '○'} {c.label}
                  </li>
                ))}
            </ul>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            <Action label="Phone screen done" onClick={() => transition('needs_phone_screen')} />
            <Action
              label="Conditionally approve"
              onClick={() => transition('conditionally_approved')}
            />
            <Action label="Invite background" onClick={inviteBackground} />
            <Action
              label="Background review"
              onClick={() => transition('background_check_review')}
            />
            <Action label="Approve driver" onClick={() => transition('driver_approved')} />
            <Action label="Dispatch-ready" onClick={() => transition('dispatch_ready')} primary />
            <Action label="Reject" onClick={() => transition('rejected')} danger />
            <Action label="Deactivate" onClick={() => transition('inactive')} />
          </div>
        </div>
      )}
    </div>
  );
}

function Action({
  label,
  onClick,
  primary,
  danger,
}: {
  label: string;
  onClick: () => void;
  primary?: boolean;
  danger?: boolean;
}): JSX.Element {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-md px-3 py-1.5 text-xs font-medium ${
        primary
          ? 'bg-brand-accent text-bg-primary'
          : danger
            ? 'border border-red-500/40 text-red-300'
            : 'border border-brand-line text-brand-mute hover:text-brand-ink'
      }`}
    >
      {label}
    </button>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
