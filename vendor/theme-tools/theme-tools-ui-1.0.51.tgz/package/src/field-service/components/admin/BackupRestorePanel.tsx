import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useEffect, useState } from 'react';

/**
 * Backup restore panel — super-admin only. Two paths:
 *   1) R2 manifest restore: list timestamped JSONL backups, dry-run diff,
 *      execute with literal RESTORE-{ts} confirm input.
 *   2) D1 Time Travel: paste a bookmark, POST → Cloudflare REST API.
 */

interface Manifest {
  backupTimestamp: string;
  triggeredBy: string;
  totalRows: number;
  totalBytes: number;
  tables: Record<string, { rows: number; bytes: number; r2Key: string }>;
}

interface DiffRow {
  table: string;
  currentRows: number;
  backupRows: number;
  delta: number;
}

export function BackupRestorePanel({ bearer }: { bearer: string }) {
  useThemeToolsSurface('backup-restore-panel');
  const [backups, setBackups] = useState<Manifest[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedTs, setSelectedTs] = useState<string>('');
  const [diff, setDiff] = useState<DiffRow[] | null>(null);
  const [confirmInput, setConfirmInput] = useState('');
  const [restoring, setRestoring] = useState(false);
  const [restoreLog, setRestoreLog] = useState('');
  const [bookmark, setBookmark] = useState('');
  const [bookmarkBusy, setBookmarkBusy] = useState(false);

  useEffect(() => {
    if (!bearer) {
      setLoading(false);
      setError('Add the SUPER_ADMIN_TOKEN in Settings to view backups.');
      return;
    }
    void (async () => {
      try {
        const res = await fetch('/api/super-admin/backups/list', {
          headers: { authorization: `Bearer ${bearer}` },
        });
        const json = (await res.json()) as { ok: boolean; backups?: Manifest[]; error?: string };
        if (json.ok && json.backups) setBackups(json.backups);
        else setError(json.error ?? `HTTP ${res.status}`);
      } catch (err) {
        setError((err as Error).message);
      } finally {
        setLoading(false);
      }
    })();
  }, [bearer]);

  async function loadDiff(ts: string) {
    setSelectedTs(ts);
    setConfirmInput('');
    setDiff(null);
    try {
      const res = await fetch('/api/super-admin/backups/restore-dry-run', {
        method: 'POST',
        headers: { authorization: `Bearer ${bearer}`, 'content-type': 'application/json' },
        body: JSON.stringify({ backupTimestamp: ts }),
      });
      const json = (await res.json()) as { ok: boolean; diff?: DiffRow[]; error?: string };
      if (json.ok && json.diff) setDiff(json.diff);
      else setError(json.error ?? `HTTP ${res.status}`);
    } catch (err) {
      setError((err as Error).message);
    }
  }

  async function executeRestore() {
    if (!selectedTs || !diff) return;
    if (confirmInput !== `RESTORE-${selectedTs}`) {
      setError(`Type RESTORE-${selectedTs} to confirm.`);
      return;
    }
    setRestoring(true);
    setRestoreLog('Restoring…');
    try {
      const tables = diff.filter((d) => d.delta !== 0).map((d) => d.table);
      const res = await fetch('/api/super-admin/backups/restore-execute', {
        method: 'POST',
        headers: { authorization: `Bearer ${bearer}`, 'content-type': 'application/json' },
        body: JSON.stringify({ backupTimestamp: selectedTs, tables, confirmToken: confirmInput }),
      });
      const json = (await res.json()) as {
        ok: boolean;
        restored?: Array<{ table: string; insertedRows: number }>;
        error?: string;
      };
      if (json.ok && json.restored) {
        const sum = json.restored.reduce((s, r) => s + Math.max(0, r.insertedRows), 0);
        setRestoreLog(
          `Restored ${sum} rows across ${json.restored.length} tables. Refresh to see new state.`,
        );
      } else setRestoreLog(json.error ?? `Failed: HTTP ${res.status}`);
    } catch (err) {
      setRestoreLog((err as Error).message);
    } finally {
      setRestoring(false);
    }
  }

  async function executeTimeTravel() {
    if (
      !bookmark ||
      !confirm(`D1 Time Travel restore to bookmark ${bookmark}? This is irreversible.`)
    )
      return;
    setBookmarkBusy(true);
    try {
      const res = await fetch('/api/super-admin/backups/d1-time-travel/restore', {
        method: 'POST',
        headers: { authorization: `Bearer ${bearer}`, 'content-type': 'application/json' },
        body: JSON.stringify({ bookmark }),
      });
      const json = (await res.json()) as { ok: boolean; message?: string; error?: string };
      alert(json.ok ? (json.message ?? 'OK') : (json.error ?? 'Failed'));
    } catch (err) {
      alert((err as Error).message);
    } finally {
      setBookmarkBusy(false);
    }
  }

  if (loading) return <p className="text-sm text-brand-mute">Loading backups…</p>;
  if (error && backups.length === 0) return <p className="text-sm text-red-400">{error}</p>;

  return (
    <div className="space-y-4">
      <section className="rounded-2xl border border-brand-line bg-bg-elevated p-5" data-enter>
        <h2 className="mb-3 text-xl font-bold text-brand-ink">R2 backups</h2>
        {backups.length === 0 ? (
          <p className="text-sm text-brand-mute">
            No backups yet. Trigger the loop via Settings → "Start D1 backup loop".
          </p>
        ) : (
          <ul className="space-y-2">
            {backups.map((b) => (
              <li
                key={b.backupTimestamp}
                className={`rounded-lg border p-3 ${
                  selectedTs === b.backupTimestamp
                    ? 'border-brand-accent bg-brand-accent/10'
                    : 'border-brand-line bg-bg-primary'
                }`}
              >
                <button
                  type="button"
                  onClick={() => void loadDiff(b.backupTimestamp)}
                  className="flex w-full items-baseline justify-between gap-3 text-left"
                >
                  <span className="font-mono text-xs text-brand-ink">{b.backupTimestamp}</span>
                  <span className="text-xs text-brand-mute">
                    {b.totalRows} rows · {(b.totalBytes / 1024).toFixed(1)}KB ·{' '}
                    {Object.keys(b.tables).length} tables
                  </span>
                </button>
                {selectedTs === b.backupTimestamp && diff && (
                  <div className="mt-3 space-y-2">
                    <table className="w-full text-xs">
                      <thead>
                        <tr className="text-left text-brand-mute">
                          <th className="pb-1">Table</th>
                          <th className="pb-1 text-right">Current</th>
                          <th className="pb-1 text-right">Backup</th>
                          <th className="pb-1 text-right">Δ</th>
                        </tr>
                      </thead>
                      <tbody>
                        {diff.map((d) => (
                          <tr key={d.table}>
                            <td className="text-brand-ink">{d.table}</td>
                            <td className="text-right text-brand-mute">{d.currentRows}</td>
                            <td className="text-right text-brand-mute">{d.backupRows}</td>
                            <td
                              className={`text-right font-semibold ${
                                d.delta === 0
                                  ? 'text-brand-mute'
                                  : d.delta > 0
                                    ? 'text-emerald-400'
                                    : 'text-red-400'
                              }`}
                            >
                              {d.delta > 0 ? '+' : ''}
                              {d.delta}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    <label className="block text-xs">
                      <span className="font-mono text-[10px] uppercase tracking-widest text-red-400">
                        Type <code className="bg-bg-primary px-1">RESTORE-{selectedTs}</code> to
                        enable restore
                      </span>
                      <input
                        type="text"
                        value={confirmInput}
                        onChange={(e) => setConfirmInput(e.target.value)}
                        spellCheck={false}
                        className="mt-1 w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 font-mono text-xs text-brand-ink"
                      />
                    </label>
                    <button
                      type="button"
                      onClick={() => void executeRestore()}
                      disabled={confirmInput !== `RESTORE-${selectedTs}` || restoring}
                      className="rounded-md bg-red-500 px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-30"
                    >
                      {restoring ? 'Restoring…' : 'Execute restore'}
                    </button>
                    {restoreLog && <p className="text-xs text-brand-mute">{restoreLog}</p>}
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="rounded-2xl border border-amber-500/30 bg-amber-500/5 p-5">
        <h3 className="text-lg font-bold text-amber-300">D1 Time Travel</h3>
        <p className="mt-1 mb-3 text-xs text-brand-mute">
          Point-in-time recovery within the last 30 days. Run{' '}
          <code className="bg-bg-primary px-1">wrangler d1 time-travel info brickcity</code> for a
          bookmark.
        </p>
        <input
          type="text"
          value={bookmark}
          onChange={(e) => setBookmark(e.target.value.trim())}
          placeholder="00000088-0000031e-00004cba-..."
          spellCheck={false}
          className="w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 font-mono text-xs text-brand-ink"
        />
        <button
          type="button"
          onClick={() => void executeTimeTravel()}
          disabled={!bookmark || bookmarkBusy}
          className="mt-2 rounded-md bg-amber-500 px-4 py-2 text-sm font-semibold text-black hover:brightness-110 disabled:opacity-30"
        >
          {bookmarkBusy ? 'Restoring…' : 'Restore from bookmark'}
        </button>
      </section>
    </div>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
