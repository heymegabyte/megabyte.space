import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useEffect, useState } from 'react';
import { useFeatureFlag } from '../../use-feature-flag.js';

interface CompetitorSummary {
  slug: string;
  name: string;
  reviewCount: number;
  averageRating: number | null;
  weaknesses: string[];
  opportunities: string[];
  takeaway: string;
}

interface CompetitorReport {
  id: string;
  week_iso: string;
  competitor_summaries: string;
  digest_markdown: string | null;
  brian_email_sent_at: string | null;
  total_competitors: number;
  total_reviews_scraped: number;
  created_at: string;
}

interface ApiResponse {
  ok: boolean;
  report: CompetitorReport | null;
}

/**
 * Admin card showing the latest competitor-intel digest snapshot.
 * Fetches GET /api/competitor-intel/latest and renders a compact table
 * of competitor ratings, pricing, and recency.
 *
 * States: loading (skeleton rows), loaded (table), error (null).
 * Flag-gated via `competitor_intel` — renders null when off.
 */
export function CompetitorIntelCard({ headers }: { headers: HeadersInit }) {
  useThemeToolsSurface('competitor-intel-card');
  const flagOn = useFeatureFlag('competitor_intel');
  const [data, setData] = useState<CompetitorReport | null>(null);
  const [summaries, setSummaries] = useState<CompetitorSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!flagOn) return;
    let cancelled = false;
    setLoading(true);
    fetch('/api/competitor-intel/latest', { headers })
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error(`status_${r.status}`))))
      .then((json: ApiResponse) => {
        if (cancelled) return;
        if (!json.report) {
          setData(null);
          setSummaries([]);
          return;
        }
        setData(json.report);
        try {
          const parsed: CompetitorSummary[] = JSON.parse(json.report.competitor_summaries ?? '[]');
          setSummaries(parsed);
        } catch {
          setSummaries([]);
        }
      })
      .catch((err: Error) => {
        if (!cancelled) setError(err.message);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [flagOn, headers]);

  if (!flagOn) return null;
  if (error) return null;

  const formatRating = (v: number | null) => (v != null ? v.toFixed(1) : '—');

  return (
    <section data-testid="competitor-intel-card">
      <h3 className="mb-3 text-sm font-semibold uppercase tracking-wider text-white/70">
        Competitor Intel {data ? `(w/c ${data.week_iso})` : ''}
      </h3>
      {loading ? (
        <div className="space-y-2">
          {[1, 2, 3].map((i) => (
            <div
              key={i}
              className="h-8 animate-pulse rounded bg-white/5"
              data-testid="competitor-intel-skeleton"
            />
          ))}
        </div>
      ) : !data || summaries.length === 0 ? (
        <p className="text-brand-mute text-xs">
          No competitor report yet. Run the intel workflow to generate one.
        </p>
      ) : (
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="border-b border-white/10 text-brand-mute">
              <th className="pb-1.5 pr-2 font-medium">Competitor</th>
              <th className="pb-1.5 pr-2 font-medium">Rating</th>
              <th className="pb-1.5 pr-2 font-medium">Reviews</th>
              <th className="pb-1.5 font-medium">Takeaway</th>
            </tr>
          </thead>
          <tbody>
            {summaries.map((s) => (
              <tr key={s.slug} className="border-b border-white/5 last:border-0">
                <td className="py-1.5 pr-2 font-medium text-white">{s.name}</td>
                <td className="py-1.5 pr-2">{formatRating(s.averageRating)}</td>
                <td className="py-1.5 pr-2">{s.reviewCount}</td>
                <td className="py-1.5 text-brand-mute leading-tight">{s.takeaway || '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </section>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
