import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useEffect, useState } from 'react';
import { useFeatureFlag } from '../../use-feature-flag.js';

/* ──────────────────────────────────────────────────────────────────────────
 * CrewSentimentCard — admin card showing per-crew sentiment scores based on
 * recent customer ratings (reviews, SMS, claim notes). Flag-gated behind
 * `crew_sentiment_rotation`.
 *
 * Fetches /api/crew-sentiment-rotation/summary and renders a compact table:
 * crew name · recent rating avg · status · neg-ratio vs. pause threshold.
 *
 * States: loading (skeleton rows), loaded (table with data), error (null —
 * administrative tool, don't show broken UI).
 *
 * Mounted inside the "Workers" tab of <Admin />.
 * ────────────────────────────────────────────────────────────────────────── */

interface CrewSentimentEntry {
  crew_id: string;
  first_name: string;
  last_name: string;
  avg_rating: number | null;
  recent_neg_ratio: number;
  total_msgs: number;
  status: 'active' | 'paused';
  paused_until: string | null;
  auto_paused: boolean;
}

interface SummaryResponse {
  ok: boolean;
  crews: CrewSentimentEntry[];
}

const PAUSE_THRESHOLD = 0.4;
const MIN_MSGS_THRESHOLD = 5;

export function CrewSentimentCard({
  token,
  onUnauthorized,
}: {
  token: string;
  onUnauthorized: () => void;
}) {
  const enabled = useFeatureFlag('crew_sentiment_rotation');
  const [data, setData] = useState<CrewSentimentEntry[] | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!token || !enabled) return;
    let cancelled = false;
    setLoading(true);

    fetch('/api/crew-sentiment-rotation/summary', {
      headers: { authorization: `Bearer ${token}` },
    })
      .then((r) => {
        if (r.status === 401) {
          onUnauthorized();
          return null;
        }
        if (!r.ok) return null;
        return r.json() as Promise<SummaryResponse>;
      })
      .then((json) => {
        if (cancelled) return;
        if (json?.ok) setData(json.crews ?? []);
        else setData([]);
      })
      .catch(() => {
        if (!cancelled) setData([]);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [token, enabled, onUnauthorized]);

  /* Hidden when flag is off. */
  if (!enabled) return null;

  /* Loading — skeleton rows. */
  if (loading) {
    return (
      <div
        data-testid="crew-sentiment-card"
        className="mb-6 rounded-2xl border border-brand-line bg-bg-elevated p-5"
      >
        <h3 className="mb-3 text-sm font-semibold text-brand-mute">Crew Sentiment</h3>
        <div className="space-y-2">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-7 animate-pulse rounded bg-white/5" />
          ))}
        </div>
      </div>
    );
  }

  /* Error — administrative tool, don't show broken UI. */
  if (!data) return null;

  return (
    <div
      data-testid="crew-sentiment-card"
      className="mb-6 rounded-2xl border border-brand-line bg-bg-elevated p-5"
    >
      <h3 className="mb-3 text-sm font-semibold text-brand-mute">Crew Sentiment</h3>

      {data.length === 0 ? (
        <p className="text-xs text-brand-mute">No sentiment data yet.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-brand-line text-left text-[10px] uppercase tracking-wider text-brand-mute">
                <th className="pb-2 pr-2 font-medium">Crew</th>
                <th className="pb-2 pr-2 text-right font-medium">Rating</th>
                <th className="pb-2 px-2 text-center font-medium">Status</th>
                <th className="pb-2 pl-2 text-right font-medium">Neg ratio</th>
              </tr>
            </thead>
            <tbody>
              {data.map((c) => {
                const ratioExceeded =
                  c.recent_neg_ratio >= PAUSE_THRESHOLD &&
                  c.total_msgs >= MIN_MSGS_THRESHOLD;
                return (
                  <tr
                    key={c.crew_id}
                    className="border-b border-brand-line/40 align-top"
                  >
                    <td className="py-2 pr-2 font-medium text-brand-ink">
                      {c.first_name} {c.last_name}
                    </td>
                    <td className="py-2 pr-2 text-right text-brand-ink">
                      {c.avg_rating != null ? c.avg_rating.toFixed(1) : '—'}
                    </td>
                    <td className="px-2 py-2 text-center">
                      <span
                        className={`inline-block rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                          c.status === 'paused'
                            ? 'border border-red-500/30 bg-red-500/10 text-red-300'
                            : ratioExceeded
                              ? 'border border-amber-500/30 bg-amber-500/10 text-amber-200'
                              : 'border border-emerald-500/30 bg-emerald-500/10 text-emerald-300'
                        }`}
                      >
                        {c.status}
                        {ratioExceeded && c.status === 'active' ? '*' : ''}
                      </span>
                    </td>
                    <td className="py-2 pl-2 text-right">
                      <span
                        className={
                          ratioExceeded
                            ? 'font-semibold text-red-300'
                            : 'text-brand-mute'
                        }
                      >
                        {(c.recent_neg_ratio * 100).toFixed(0)}%
                        {ratioExceeded ? ' ↑' : ''}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      <p className="mt-3 text-[10px] text-brand-mute">
        Neg ratio threshold: {(PAUSE_THRESHOLD * 100).toFixed(0)}% &middot; min{' '}
        {MIN_MSGS_THRESHOLD} msgs &middot; auto-pause for 24h when exceeded
        {data.some((c) => c.auto_paused) ? ' • ★ auto-paused crews bolded' : ''}
      </p>
    </div>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
