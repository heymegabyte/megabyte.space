import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useState } from 'react';
import { adminFetch, formatCents, formatDate, formatRelative } from '@theme.tools/crm/field-service/admin-api';

/**
 * Wave 17 — Customer profile drawer.
 * Joins bookings + Wave 16 ai_rules + Wave 19 comm_log (both soft-imported —
 * empty arrays when those tables don't exist yet).
 */

interface CustomerDetailProps {
  phone: string;
  onClose: () => void;
  onMutated: () => void;
}

interface CustomerPayload {
  ok: true;
  phone: string;
  profile: {
    name?: string;
    email?: string;
    lastCity?: string;
    lastZip?: string;
  };
  bookings: Array<Record<string, unknown>>;
  summary: {
    lifetimeCents: number;
    bookingCount: number;
    completedJobs: number;
    firstSeen: string;
    lastSeen: string;
    churnRisk: number;
  };
  rules: Array<Record<string, unknown>>;
  commLog: Array<Record<string, unknown>>;
}

export function CustomerDetail({ phone, onClose, onMutated }: CustomerDetailProps) {
  useThemeToolsSurface('customer-detail');
  const [data, setData] = useState<CustomerPayload | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    const res = await adminFetch<CustomerPayload>(`/customers/${encodeURIComponent(phone)}`);
    if (!res.ok) {
      setError(res.error);
      return;
    }
    setData(res.data);
  }, [phone]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  return (
    <div
      role="dialog"
      aria-label="Customer detail"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-stretch justify-end bg-black/60 backdrop-blur-sm"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="ml-auto h-full w-full max-w-3xl overflow-y-auto bg-bg-primary border-l border-brand-cyan/20 shadow-2xl">
        <header className="sticky top-0 z-10 flex items-center justify-between border-b border-brand-cyan/15 bg-bg-primary/95 px-5 py-3 backdrop-blur">
          <div>
            <h3 className="text-lg font-bold text-brand-cyan">
              {data?.profile?.name || 'Customer'}
            </h3>
            <p className="text-xs text-brand-mute">
              <a href={`tel:${phone}`} className="hover:text-brand-cyan">
                {phone}
              </a>{' '}
              {data?.profile?.email && (
                <>
                  ·{' '}
                  <a href={`mailto:${data.profile.email}`} className="hover:text-brand-cyan">
                    {data.profile.email}
                  </a>
                </>
              )}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded border border-white/10 px-3 py-1 text-sm text-brand-mute hover:text-white"
            aria-label="Close"
          >
            Close ✕
          </button>
        </header>

        {error && (
          <div
            role="alert"
            className="m-5 rounded border border-red-500/40 bg-red-950/30 p-3 text-sm text-red-300"
          >
            {error}
          </div>
        )}

        {!data && !error && <div className="p-10 text-center text-brand-mute">Loading…</div>}

        {data && (
          <div className="space-y-6 p-5">
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Stat label="LTV" value={formatCents(data.summary.lifetimeCents)} />
              <Stat label="Bookings" value={String(data.summary.bookingCount)} />
              <Stat label="Completed" value={String(data.summary.completedJobs)} />
              <Stat
                label="Churn risk"
                value={`${data.summary.churnRisk}%`}
                tone={
                  data.summary.churnRisk >= 70
                    ? 'red'
                    : data.summary.churnRisk >= 40
                      ? 'amber'
                      : 'green'
                }
              />
            </div>

            <Section title={`AI rules (${data.rules.length})`}>
              {data.rules.length === 0 ? (
                <Empty>
                  No customer-scoped rules. Wave 16 (AI rules) wires here once that table ships.
                </Empty>
              ) : (
                <ul className="space-y-1 text-sm">
                  {data.rules.map((r) => (
                    <li key={String(r.id)} className="rounded border border-white/5 bg-white/5 p-2">
                      <div className="text-white">{String(r.name ?? r.action ?? 'rule')}</div>
                      <div className="text-xs text-brand-mute">{String(r.description ?? '')}</div>
                    </li>
                  ))}
                </ul>
              )}
            </Section>

            <Section title={`Bookings (${data.bookings.length})`}>
              {data.bookings.length === 0 ? (
                <Empty>No bookings on file.</Empty>
              ) : (
                <div className="overflow-x-auto rounded border border-white/5">
                  <table className="w-full text-sm">
                    <thead className="bg-white/5 text-left text-xs uppercase text-brand-mute">
                      <tr>
                        <th className="px-3 py-2">Date</th>
                        <th className="px-3 py-2">Status</th>
                        <th className="px-3 py-2">Address</th>
                        <th className="px-3 py-2 text-right">Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.bookings.slice(0, 50).map((b) => (
                        <tr key={String(b.id)} className="border-t border-white/5">
                          <td className="px-3 py-1.5 text-white">
                            {String(b.preferred_date ?? '—')}
                          </td>
                          <td className="px-3 py-1.5 text-brand-mute">
                            {String(
                              b.deleted_at
                                ? 'deleted'
                                : b.archived_at
                                  ? 'archived'
                                  : (b.status ?? ''),
                            )}
                          </td>
                          <td className="px-3 py-1.5 text-brand-mute">
                            {[b.address, b.city, b.zip].filter(Boolean).join(', ')}
                          </td>
                          <td className="px-3 py-1.5 text-right text-white">
                            {formatCents(Number(b.total_cents))}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </Section>

            <Section title={`Communications (${data.commLog.length})`}>
              {data.commLog.length === 0 ? (
                <Empty>
                  No comm log yet. Wave 19 (channels) populates this once that table ships.
                </Empty>
              ) : (
                <ul className="space-y-1 text-sm">
                  {data.commLog.map((m) => (
                    <li
                      key={String(m.id)}
                      className="flex justify-between border-b border-white/5 py-1"
                    >
                      <span className="text-white">{String(m.channel ?? '')}</span>
                      <span className="text-brand-mute">
                        {formatRelative(String(m.created_at))}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </Section>

            <p className="text-xs text-brand-mute">
              First seen {formatDate(data.summary.firstSeen)} · Last seen{' '}
              {formatDate(data.summary.lastSeen)} ·{' '}
              <button
                type="button"
                onClick={() => {
                  onMutated();
                  void load();
                }}
                className="text-brand-cyan hover:underline"
              >
                Refresh
              </button>
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

function Stat({
  label,
  value,
  tone = 'plain',
}: {
  label: string;
  value: string;
  tone?: 'plain' | 'red' | 'amber' | 'green';
}) {
  const color =
    tone === 'red'
      ? 'text-red-300'
      : tone === 'amber'
        ? 'text-amber-300'
        : tone === 'green'
          ? 'text-emerald-300'
          : 'text-white';
  return (
    <div className="rounded border border-brand-cyan/15 bg-white/5 p-3">
      <div className="text-xs uppercase text-brand-mute">{label}</div>
      <div className={`text-xl font-bold ${color}`}>{value}</div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h4 className="mb-2 text-xs font-bold uppercase tracking-wide text-brand-cyan/80">{title}</h4>
      {children}
    </div>
  );
}

function Empty({ children }: { children: React.ReactNode }) {
  return (
    <p className="rounded border border-dashed border-white/10 p-3 text-sm text-brand-mute">
      {children}
    </p>
  );
}

export default CustomerDetail;
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
