import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useEffect, useState } from 'react';

interface AtRiskCustomer {
  customer_email: string;
  customer_name: string;
  last_booking_at: string;
  total_lifetime_cents: number;
  bookings_count: number;
  five_star_count: number;
}

interface ApiResponse {
  ok: true;
  customers: AtRiskCustomer[];
}

export function CustomersAtRisk({ headers }: { headers: HeadersInit }) {
  useThemeToolsSurface('customers-at-risk');
  const [rows, setRows] = useState<AtRiskCustomer[]>([]);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    let cancelled = false;
    fetch('/api/admin/customers/at-risk', { headers })
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error(`status_${r.status}`))))
      .then((json: ApiResponse) => {
        if (!cancelled) setRows(json.customers);
      })
      .catch((err: Error) => {
        if (!cancelled) setError(err.message);
      });
    return () => {
      cancelled = true;
    };
  }, [headers]);

  if (error) return <p className="text-sm text-red-300">{error}</p>;
  if (rows.length === 0) {
    return <p className="text-brand-mute text-sm">No at-risk customers — everyone's fresh.</p>;
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left text-sm" data-testid="customers-at-risk">
        <thead className="text-brand-mute text-xs uppercase">
          <tr>
            <th className="py-2 pr-2">Customer</th>
            <th className="px-2 py-2">Email</th>
            <th className="px-2 py-2">Last booking</th>
            <th className="px-2 py-2">Bookings</th>
            <th className="px-2 py-2">★5 history</th>
            <th className="px-2 py-2">Lifetime</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((c) => (
            <tr key={c.customer_email} className="border-t border-white/5">
              <td className="py-2 pr-2">{c.customer_name}</td>
              <td className="px-2 py-2 text-xs">{c.customer_email}</td>
              <td className="px-2 py-2 text-xs">{daysAgo(c.last_booking_at)}</td>
              <td className="px-2 py-2 tabular-nums">{c.bookings_count}</td>
              <td className="px-2 py-2 tabular-nums">{c.five_star_count}</td>
              <td className="px-2 py-2 tabular-nums">
                ${(c.total_lifetime_cents / 100).toFixed(0)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function daysAgo(iso: string): string {
  try {
    const days = Math.floor((Date.now() - new Date(iso).getTime()) / 86_400_000);
    return `${days}d ago`;
  } catch {
    return iso;
  }
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
