import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useRef, useState } from 'react';
import { adminFetch, formatCents, formatRelative, getAdminToken, pushLocalRecent } from '@theme.tools/crm/field-service/admin-api';
import { CustomerDetail } from './CustomerDetail.js';
import { RecentlyViewed } from './RecentlyViewed.js';

/**
 * Wave 17 — Customers browser.
 * Master list keyed on phone (E.164), sortable by LTV / last booking / churn / name.
 */

type Sort = 'ltv' | 'recent' | 'churn' | 'name';

interface CustomerRow {
  phone: string;
  name: string;
  email: string | null;
  bookings: number;
  ltv_cents: number;
  last_seen: string;
  first_seen: string;
  last_city: string | null;
  last_zip: string | null;
  completed_jobs: number;
  canceled_jobs: number;
  churn_risk: number;
}

interface CustomersListResponse {
  ok: true;
  customers: CustomerRow[];
  sort: Sort;
}

const SORTS: Array<{ id: Sort; label: string }> = [
  { id: 'ltv', label: 'Highest LTV' },
  { id: 'recent', label: 'Most recent' },
  { id: 'churn', label: 'Churn risk' },
  { id: 'name', label: 'Name A→Z' },
];

export function CustomersBrowser() {
  useThemeToolsSurface('customers-browser');
  const [q, setQ] = useState('');
  const [sort, setSort] = useState<Sort>('ltv');
  const [rows, setRows] = useState<CustomerRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const load = useCallback(async () => {
    abortRef.current?.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    setLoading(true);
    setError(null);
    const params = new URLSearchParams({ sort, limit: '100' });
    if (q.trim()) params.set('q', q.trim());
    const res = await adminFetch<CustomersListResponse>(`/customers?${params.toString()}`, {
      signal: ctrl.signal,
    });
    if (!res.ok) {
      if (res.error === 'aborted') return;
      setError(res.error);
      setLoading(false);
      return;
    }
    setRows(res.data.customers);
    setLoading(false);
  }, [q, sort]);

  useEffect(() => {
    const t = setTimeout(() => void load(), 200);
    return () => clearTimeout(t);
  }, [load]);

  return (
    <section className="space-y-4">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-extrabold text-brand-cyan">Customers</h2>
          <p className="text-sm text-brand-mute">
            Master list. Sort by LTV, recency, churn risk, or name.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as Sort)}
            aria-label="Sort customers"
            className="rounded border border-brand-cyan/30 bg-black/60 px-2 py-1.5 text-sm text-white focus:border-brand-cyan focus:outline-none"
          >
            {SORTS.map((s) => (
              <option key={s.id} value={s.id}>
                {s.label}
              </option>
            ))}
          </select>
          <input
            type="search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search name, email, phone…"
            className="rounded border border-brand-cyan/30 bg-black/60 px-3 py-1.5 text-sm text-white placeholder:text-brand-mute focus:border-brand-cyan focus:outline-none w-72"
            aria-label="Search customers"
          />
        </div>
      </header>

      {error && (
        <div
          role="alert"
          className="rounded border border-red-500/40 bg-red-950/30 p-3 text-sm text-red-300"
        >
          {error}
        </div>
      )}

      <div className="overflow-x-auto rounded border border-brand-cyan/15">
        <table className="w-full text-sm">
          <thead className="bg-white/5 text-left text-xs uppercase text-brand-mute">
            <tr>
              <th className="px-3 py-2">Customer</th>
              <th className="px-3 py-2">Contact</th>
              <th className="px-3 py-2 text-right">LTV</th>
              <th className="px-3 py-2 text-right">Bookings</th>
              <th className="px-3 py-2 text-right">Last seen</th>
              <th className="px-3 py-2 text-right">Churn</th>
              <th className="px-3 py-2 text-right">Impersonate</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && !loading && (
              <tr>
                <td colSpan={7} className="px-3 py-12 text-center text-brand-mute">
                  No customers match.
                </td>
              </tr>
            )}
            {rows.map((c) => (
              <tr
                key={c.phone}
                onClick={() => {
                  setSelected(c.phone);
                  pushLocalRecent('customer', c.phone, `${c.name} · ${c.phone}`);
                }}
                className="cursor-pointer border-t border-white/5 hover:bg-brand-cyan/5"
              >
                <td className="px-3 py-2">
                  <div className="text-white">{c.name || 'Unnamed'}</div>
                  <div className="text-xs text-brand-mute">
                    {[c.last_city, c.last_zip].filter(Boolean).join(', ') || '—'}
                  </div>
                </td>
                <td className="px-3 py-2 text-brand-mute">
                  <div>{c.phone}</div>
                  <div className="text-xs">{c.email || '—'}</div>
                </td>
                <td className="px-3 py-2 text-right text-white">{formatCents(c.ltv_cents)}</td>
                <td className="px-3 py-2 text-right text-brand-mute">
                  {c.bookings}
                  <span className="ml-1 text-xs">({c.completed_jobs}✓)</span>
                </td>
                <td className="px-3 py-2 text-right text-brand-mute">
                  {formatRelative(c.last_seen)}
                </td>
                <td className="px-3 py-2 text-right">
                  <ChurnPill score={c.churn_risk} />
                </td>
                <td className="px-3 py-2 text-right" onClick={(e) => e.stopPropagation()}>
                  <ImpersonateButton
                    contact={c.email || c.phone}
                    channel={c.email ? 'email' : 'sms'}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {loading && <div className="text-center text-xs text-brand-mute">Loading…</div>}

      {selected && (
        <CustomerDetail
          phone={selected}
          onClose={() => setSelected(null)}
          onMutated={() => void load()}
        />
      )}

      <RecentlyViewed
        onOpen={(kind, id) => {
          if (kind === 'customer') setSelected(id);
        }}
      />
    </section>
  );
}

/**
 * Wave 21C — start impersonation of a customer. Prompts for an audit reason
 * (required), POSTs to /api/admin/impersonate/start, and on success redirects
 * the browser to /me where the operator now appears as that customer.
 */
function ImpersonateButton({ contact, channel }: { contact: string; channel: 'email' | 'sms' }) {
  const [busy, setBusy] = useState(false);
  const onClick = async () => {
    const reason = window.prompt(`Impersonate ${contact}? Type a one-line reason (audited).`);
    if (!reason || reason.trim().length < 3) return;
    setBusy(true);
    try {
      const token = getAdminToken();
      const res = await fetch('/api/admin/impersonate/start', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          ...(token ? { authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ contact, channel, reason: reason.trim() }),
      });
      const data = (await res.json()) as { ok: boolean; redirect?: string; error?: string };
      if (!res.ok || !data.ok) {
        window.alert(`Impersonate failed: ${data.error || res.status}`);
        return;
      }
      window.location.href = data.redirect || '/me';
    } finally {
      setBusy(false);
    }
  };
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={busy || !contact}
      className="rounded border border-fuchsia-500/40 px-2 py-0.5 text-xs text-fuchsia-200 hover:bg-fuchsia-950/30 disabled:opacity-30"
      title={contact ? `Impersonate as ${contact}` : 'No contact available'}
    >
      {busy ? '…' : 'Open as'}
    </button>
  );
}

function ChurnPill({ score }: { score: number }) {
  const color =
    score >= 70
      ? 'bg-red-950/50 text-red-300'
      : score >= 40
        ? 'bg-amber-950/50 text-amber-300'
        : 'bg-emerald-950/50 text-emerald-300';
  return (
    <span className={`inline-block rounded px-2 py-0.5 text-xs font-medium ${color}`}>
      {score}%
    </span>
  );
}

export default CustomersBrowser;
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
