import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useState } from 'react';
import { adminFetch, formatCents, formatDate, formatRelative } from '@theme.tools/crm/field-service/admin-api';

/**
 * Wave 17 — Single-job detail drawer.
 * Loads /admin/entities/jobs/:id, renders booking + crew + photos placeholder +
 * payments + dispatch history + audit trail, exposes archive / unarchive /
 * soft-delete / restore actions.
 */

interface JobDetailProps {
  jobId: string;
  onClose: () => void;
  onMutated: () => void;
}

interface JobDetailPayload {
  ok: true;
  booking: Record<string, unknown> & {
    id: string;
    customer_name?: string;
    customer_email?: string;
    customer_phone?: string;
    address?: string;
    city?: string;
    zip?: string;
    preferred_date?: string;
    preferred_time?: string;
    status?: string;
    services_csv?: string;
    notes?: string;
    notes_internal?: string;
    hours?: number;
    crew?: number;
    total_cents?: number;
    paid_at?: string | null;
    completed_at?: string | null;
    canceled_at?: string | null;
    archived_at?: number | null;
    deleted_at?: number | null;
  };
  gigs: Array<Record<string, unknown>>;
  claims: Array<Record<string, unknown>>;
  events: Array<Record<string, unknown>>;
  audit: Array<Record<string, unknown>>;
  payouts: Array<Record<string, unknown>>;
}

export function JobDetail({ jobId, onClose, onMutated }: JobDetailProps) {
  useThemeToolsSurface('job-detail');
  const [data, setData] = useState<JobDetailPayload | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setError(null);
    const res = await adminFetch<JobDetailPayload>(`/jobs/${jobId}`);
    if (!res.ok) {
      setError(res.error);
      return;
    }
    setData(res.data);
  }, [jobId]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  const act = async (action: 'archive' | 'unarchive' | 'soft-delete' | 'restore') => {
    if (busy) return;
    if (
      action === 'soft-delete' &&
      !confirm('Soft-delete this job? You can restore from the Deleted tab.')
    ) {
      return;
    }
    setBusy(true);
    const res = await adminFetch<{ ok: true }>(`/jobs/${jobId}/${action}`, { method: 'POST' });
    setBusy(false);
    if (!res.ok) {
      setError(res.error);
      return;
    }
    await load();
    onMutated();
  };

  return (
    <div
      role="dialog"
      aria-label="Job detail"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-stretch justify-end bg-black/60 backdrop-blur-sm"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="ml-auto h-full w-full max-w-3xl overflow-y-auto bg-bg-primary border-l border-brand-cyan/20 shadow-2xl">
        <header className="sticky top-0 z-10 flex items-center justify-between gap-3 border-b border-brand-cyan/15 bg-bg-primary/95 px-5 py-3 backdrop-blur">
          <div>
            <h3 className="text-lg font-bold text-brand-cyan">Job {jobId.slice(0, 8)}</h3>
            <p className="text-xs text-brand-mute">
              {data?.booking?.customer_name ?? '…'} · {data?.booking?.preferred_date ?? '—'}{' '}
              {data?.booking?.preferred_time ?? ''}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded border border-white/10 px-3 py-1 text-sm text-brand-mute hover:text-white"
            aria-label="Close"
          >
            Close ✕
          </button>
        </header>

        {error && (
          <div
            role="alert"
            className="m-5 rounded border border-red-500/40 bg-red-950/30 p-3 text-sm text-red-300"
          >
            {error}
          </div>
        )}

        {!data && !error && <div className="p-10 text-center text-brand-mute">Loading…</div>}

        {data && (
          <div className="space-y-6 p-5">
            <div className="flex flex-wrap gap-2">
              {!data.booking.archived_at && !data.booking.deleted_at && (
                <button
                  type="button"
                  onClick={() => act('archive')}
                  disabled={busy}
                  className="rounded border border-zinc-600 px-3 py-1.5 text-sm text-zinc-300 hover:bg-zinc-800"
                >
                  Archive
                </button>
              )}
              {data.booking.archived_at && !data.booking.deleted_at && (
                <button
                  type="button"
                  onClick={() => act('unarchive')}
                  disabled={busy}
                  className="rounded border border-emerald-600 px-3 py-1.5 text-sm text-emerald-300 hover:bg-emerald-950/40"
                >
                  Unarchive
                </button>
              )}
              {!data.booking.deleted_at && (
                <button
                  type="button"
                  onClick={() => act('soft-delete')}
                  disabled={busy}
                  className="rounded border border-red-600 px-3 py-1.5 text-sm text-red-300 hover:bg-red-950/40"
                >
                  Soft-delete
                </button>
              )}
              {data.booking.deleted_at && (
                <button
                  type="button"
                  onClick={() => act('restore')}
                  disabled={busy}
                  className="rounded border border-brand-cyan px-3 py-1.5 text-sm text-brand-cyan hover:bg-brand-cyan/10"
                >
                  Restore
                </button>
              )}
            </div>

            <DetailGrid
              rows={[
                ['Status', String(data.booking.status ?? '—')],
                ['Customer', String(data.booking.customer_name ?? '—')],
                ['Phone', String(data.booking.customer_phone ?? '—')],
                ['Email', String(data.booking.customer_email ?? '—')],
                [
                  'Address',
                  [data.booking.address, data.booking.city, data.booking.zip]
                    .filter(Boolean)
                    .join(', ') || '—',
                ],
                ['Services', String(data.booking.services_csv ?? '—')],
                ['Crew · Hours', `${data.booking.crew ?? 0} × ${data.booking.hours ?? 0}h`],
                ['Total', formatCents(data.booking.total_cents)],
                ['Paid', data.booking.paid_at ? formatDate(data.booking.paid_at) : '—'],
                [
                  'Completed',
                  data.booking.completed_at ? formatDate(data.booking.completed_at) : '—',
                ],
                ['Canceled', data.booking.canceled_at ? formatDate(data.booking.canceled_at) : '—'],
                ['Notes', String(data.booking.notes ?? '—')],
              ]}
            />

            <Section title={`Crew (${data.gigs.length} gig${data.gigs.length === 1 ? '' : 's'})`}>
              {data.gigs.length === 0 ? (
                <Empty>No gigs dispatched.</Empty>
              ) : (
                <ul className="space-y-2">
                  {data.gigs.map((g) => (
                    <li
                      key={String(g.id)}
                      className="rounded border border-white/5 bg-white/5 p-3 text-sm"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-white">{String(g.status)}</span>
                        <span className="text-brand-mute">{formatDate(g.start_at)}</span>
                      </div>
                      <div className="text-xs text-brand-mute">
                        {Number(g.crew_filled ?? 0)}/{Number(g.crew_needed ?? 0)} filled ·{' '}
                        {String(g.service_zip ?? '')}
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </Section>

            <Section title={`Dispatch history (${data.claims.length})`}>
              {data.claims.length === 0 ? (
                <Empty>No worker invitations sent.</Empty>
              ) : (
                <ul className="space-y-1 text-sm">
                  {data.claims.slice(0, 25).map((cl) => (
                    <li
                      key={String(cl.id)}
                      className="flex justify-between border-b border-white/5 py-1.5"
                    >
                      <span className="text-white">{String(cl.status)}</span>
                      <span className="text-brand-mute">
                        {String(cl.worker_id).slice(0, 8)} · {formatRelative(String(cl.invited_at))}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </Section>

            <Section title={`Payments (${data.payouts.length})`}>
              {data.payouts.length === 0 ? (
                <Empty>No payouts tied to this job yet.</Empty>
              ) : (
                <ul className="space-y-1 text-sm">
                  {data.payouts.map((p) => (
                    <li
                      key={String(p.id)}
                      className="flex justify-between border-b border-white/5 py-1.5"
                    >
                      <span className="text-white">{formatCents(Number(p.amount_cents))}</span>
                      <span className="text-brand-mute">
                        {String(p.method)} · {String(p.status)} ·{' '}
                        {formatRelative(String(p.created_at))}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </Section>

            <Section title={`Audit trail (${data.audit.length})`}>
              {data.audit.length === 0 ? (
                <Empty>No audit entries.</Empty>
              ) : (
                <ul className="space-y-1 text-xs">
                  {data.audit.slice(0, 25).map((a) => (
                    <li
                      key={String(a.id)}
                      className="flex justify-between border-b border-white/5 py-1"
                    >
                      <span className="text-white">{String(a.action)}</span>
                      <span className="text-brand-mute">
                        {formatRelative(String(a.created_at))}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </Section>

            <Section title="Photos">
              <Empty>
                Photos surface via the existing Wave 12 photo viewer — link out from here.
              </Empty>
            </Section>
          </div>
        )}
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h4 className="mb-2 text-xs font-bold uppercase tracking-wide text-brand-cyan/80">{title}</h4>
      {children}
    </div>
  );
}

function Empty({ children }: { children: React.ReactNode }) {
  return (
    <p className="rounded border border-dashed border-white/10 p-3 text-sm text-brand-mute">
      {children}
    </p>
  );
}

function DetailGrid({ rows }: { rows: Array<[string, string]> }) {
  return (
    <dl className="grid grid-cols-1 gap-y-1 text-sm sm:grid-cols-3">
      {rows.map(([k, v]) => (
        <div key={k} className="contents">
          <dt className="text-brand-mute">{k}</dt>
          <dd className="col-span-2 text-white">{v}</dd>
        </div>
      ))}
    </dl>
  );
}

export default JobDetail;
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
