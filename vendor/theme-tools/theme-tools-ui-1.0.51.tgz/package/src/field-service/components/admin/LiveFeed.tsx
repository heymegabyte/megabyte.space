import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useMemo } from 'react';
import { useEventSource, type SseConnectionState } from '../../admin-sse.js';

interface AdminEventWire {
  id: string;
  ts: number;
  kind: string;
  severity: 'info' | 'warn' | 'error' | 'critical';
  actor: string | null;
  targetType: string | null;
  targetId: string | null;
  summary: string;
  details: Record<string, unknown> | null;
}

const SEVERITY_DOT: Record<AdminEventWire['severity'], string> = {
  info: 'bg-sky-400',
  warn: 'bg-amber-400',
  error: 'bg-red-400',
  critical: 'bg-fuchsia-500',
};

const STATE_LABEL: Record<SseConnectionState, string> = {
  connecting: 'Connecting…',
  open: 'Live',
  closed: 'Closed',
  error: 'Reconnecting…',
};

/**
 * Live feed — auto-reconnecting SSE consumer for /api/admin/feed. Newest
 * events bubble to the top; sticky scrollbar capped at 200 events.
 */
export function LiveFeed({ token }: { token: string }) {
  useThemeToolsSurface('live-feed');
  const url = useMemo(() => `/api/admin/feed?since=${Date.now()}`, []);
  const { events, state } = useEventSource<AdminEventWire>({
    url,
    eventName: 'admin_event',
    authToken: token,
    maxBufferedEvents: 200,
  });

  return (
    <section
      className="flex h-[640px] flex-col rounded-2xl border border-white/10 bg-white/[0.03] p-4"
      data-testid="live-feed"
    >
      <header className="mb-3 flex items-center justify-between">
        <h2 className="text-sm font-semibold uppercase tracking-wide">Live Feed</h2>
        <span
          className={[
            'inline-flex items-center gap-1.5 text-xs',
            state === 'open' ? 'text-emerald-300' : 'text-brand-mute',
          ].join(' ')}
          aria-live="polite"
        >
          <span
            className={[
              'inline-block h-2 w-2 rounded-full',
              state === 'open'
                ? 'animate-pulse bg-emerald-400'
                : state === 'error'
                  ? 'bg-red-400'
                  : 'bg-white/40',
            ].join(' ')}
          />
          {STATE_LABEL[state]}
        </span>
      </header>
      <ol className="-mr-2 flex-1 space-y-2 overflow-y-auto pr-2">
        {events.length === 0 && (
          <li className="text-brand-mute text-sm">No events yet. Waiting for the next mutation…</li>
        )}
        {events.map((ev) => (
          <li
            key={ev.id}
            className="group rounded-lg border border-white/5 bg-white/[0.02] p-2.5 text-sm transition hover:border-white/15"
          >
            <div className="flex items-center gap-2">
              <span
                className={['h-2 w-2 flex-none rounded-full', SEVERITY_DOT[ev.severity]].join(' ')}
                aria-label={ev.severity}
              />
              <span className="text-brand-mute font-mono text-[10px] uppercase">{ev.kind}</span>
              <span className="text-brand-mute ml-auto text-[10px]">{relTime(ev.ts)}</span>
            </div>
            <div className="mt-1 text-sm leading-snug">{ev.summary}</div>
            {ev.targetType && ev.targetId && (
              <div className="text-brand-mute mt-0.5 font-mono text-[10px]">
                {ev.targetType}:{ev.targetId}
              </div>
            )}
          </li>
        ))}
      </ol>
    </section>
  );
}

function relTime(ts: number): string {
  const delta = Date.now() - ts;
  if (delta < 60_000) return `${Math.max(1, Math.floor(delta / 1000))}s`;
  if (delta < 3_600_000) return `${Math.floor(delta / 60_000)}m`;
  if (delta < 86_400_000) return `${Math.floor(delta / 3_600_000)}h`;
  return `${Math.floor(delta / 86_400_000)}d`;
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
