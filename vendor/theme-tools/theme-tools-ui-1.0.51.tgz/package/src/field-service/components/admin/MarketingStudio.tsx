import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { ReviewResponseQueue } from './ReviewResponseQueue.js';
import { SeoGapFinder } from './SeoGapFinder.js';
import { PseoBuilder } from './PseoBuilder.js';

/**
 * MarketingStudio — Wave 6 super-admin surface. Single-page sub-app the
 * integrator wires under /admin#marketing. Sections (top-to-bottom):
 *
 *   1. Content Studio       — generate buttons per kind
 *   2. Recent Runs          — paginated list with R2 preview drawer
 *   3. Lead Scoring board   — ranked inbound leads
 *   4. Win-back queue       — churned customers + enqueued SMS preview
 *   5. Audience Exporter    — hashed-CSV for paid social
 *   6. Press Distribution   — contacts list + release blaster
 *   7. Review Response Q    — AI drafts for incoming reviews
 *   8. SEO Gap Finder       — competitor URL → topic gap markdown table
 *   9. pSEO Builder         — bulk city × service with uniqueness gate
 *
 * Auth: caller passes a Bearer token (already in scope at /admin). All fetches
 * include it as Authorization: Bearer <token>. The token lives in localStorage
 * as `bcl-admin-key-v1` — Admin.tsx hydrates it on mount.
 */

const ENDPOINTS = {
  generate: (kind: string) => `/api/admin/marketing/generate/${kind}`,
  runs: '/api/admin/marketing/runs',
  preview: (runId: string) => `/api/admin/marketing/runs/${runId}/preview`,
  post: (runId: string) => `/api/admin/marketing/post/${runId}`,
  leads: '/api/admin/leads/scored',
  audienceExport: (platform: string) => `/api/admin/audience/export/${platform}`,
  pressContacts: '/api/admin/press/contacts',
  pressDistribute: '/api/admin/press/distribute',
} as const;

const KINDS = [
  { id: 'city_blog', label: 'City blog' },
  { id: 'social_post', label: 'Social post' },
  { id: 'reel_script', label: 'Reel script' },
  { id: 'review_response', label: 'Review reply' },
  { id: 'press_release', label: 'Press release' },
  { id: 'newsletter', label: 'Newsletter' },
  { id: 'seo_gap', label: 'SEO gap' },
  { id: 'pseo_page', label: 'pSEO page' },
] as const;

interface Run {
  id: string;
  kind: string;
  input_summary: string;
  model: string;
  tokens_in: number;
  tokens_out: number;
  output_r2_key: string | null;
  status: string;
  error: string | null;
  created_at: string;
  updated_at: string;
}

interface Lead {
  id: string;
  lead_phone: string | null;
  lead_email: string | null;
  score: number;
  signals: Record<string, number>;
  classified_at: string;
}

interface PressContact {
  id: string;
  name: string;
  outlet: string;
  email: string;
  beat: string | null;
  last_emailed_at: string | null;
  unsubscribed_at: string | null;
}

interface MarketingStudioProps {
  readonly token: string;
}

export function MarketingStudio({ token }: MarketingStudioProps): JSX.Element {
  useThemeToolsSurface('marketing-studio');
  const headers = useMemo(
    () => ({ Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }),
    [token],
  );

  if (!token) {
    return (
      <section className="rounded-2xl border border-amber-500/40 bg-amber-50/30 p-6 text-amber-900">
        Paste your admin Bearer key in the header to use the Marketing Studio.
      </section>
    );
  }

  return (
    <div className="space-y-8">
      <ContentStudio headers={headers} />
      <RecentRuns headers={headers} />
      <LeadBoard headers={headers} />
      <AudienceExporter headers={headers} />
      <PressPanel headers={headers} />
      <ReviewResponseQueue token={token} />
      <SeoGapFinder token={token} />
      <PseoBuilder token={token} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Content Studio
// ─────────────────────────────────────────────────────────────────────────────

function ContentStudio({ headers }: { headers: HeadersInit }): JSX.Element {
  const [activeKind, setActiveKind] = useState<string>('city_blog');
  const [payloadJson, setPayloadJson] = useState<string>(samplePayload('city_blog'));
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ runId: string; preview: string } | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setPayloadJson(samplePayload(activeKind));
  }, [activeKind]);

  const submit = useCallback(async () => {
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      const body = JSON.parse(payloadJson || '{}');
      const res = await fetch(ENDPOINTS.generate(activeKind), {
        method: 'POST',
        headers,
        body: JSON.stringify(body),
      });
      const data = (await res.json()) as {
        ok: boolean;
        error?: string;
        runId?: string;
        contentPreview?: string;
      };
      if (!data.ok || !data.runId) {
        setError(data.error || `generate failed (${res.status})`);
        return;
      }
      setResult({ runId: data.runId, preview: data.contentPreview ?? '' });
    } catch (err) {
      setError((err as Error).message || 'invalid JSON');
    } finally {
      setBusy(false);
    }
  }, [activeKind, payloadJson, headers]);

  return (
    <section className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-sm">
      <h2 className="text-xl font-semibold">Content Studio</h2>
      <p className="mt-1 text-sm text-neutral-600">
        Generate AI-drafted marketing content. Without ANTHROPIC_API_KEY the worker falls back to
        deterministic templates.
      </p>
      <div className="mt-4 flex flex-wrap gap-2">
        {KINDS.map((k) => (
          <button
            key={k.id}
            type="button"
            onClick={() => setActiveKind(k.id)}
            className={`rounded-full border px-3 py-1 text-sm ${
              activeKind === k.id
                ? 'border-neutral-900 bg-neutral-900 text-white'
                : 'border-neutral-300 text-neutral-700 hover:border-neutral-400'
            }`}
            data-testid={`kind-${k.id}`}
          >
            {k.label}
          </button>
        ))}
      </div>
      <label className="mt-4 block text-sm font-medium text-neutral-700">
        Payload JSON
        <textarea
          value={payloadJson}
          onChange={(e) => setPayloadJson(e.target.value)}
          rows={6}
          className="mt-1 block w-full rounded-md border border-neutral-300 p-2 font-mono text-xs"
          spellCheck={false}
        />
      </label>
      <div className="mt-3 flex items-center gap-3">
        <button
          type="button"
          onClick={submit}
          disabled={busy}
          className="rounded-md bg-neutral-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
        >
          {busy ? 'Generating…' : `Generate ${KINDS.find((k) => k.id === activeKind)?.label}`}
        </button>
        {error ? <span className="text-sm text-red-700">{error}</span> : null}
        {result ? (
          <span className="text-sm text-emerald-700">Saved as run {result.runId.slice(0, 8)}…</span>
        ) : null}
      </div>
      {result?.preview ? (
        <pre className="mt-3 max-h-64 overflow-auto rounded-md bg-neutral-50 p-3 text-xs">
          {result.preview}
        </pre>
      ) : null}
    </section>
  );
}

function samplePayload(kind: string): string {
  switch (kind) {
    case 'city_blog':
      return JSON.stringify(
        { citySlug: 'belleville', cityName: 'Belleville', service: 'estate cleanout' },
        null,
        2,
      );
    case 'social_post':
      return JSON.stringify(
        { jobId: 'demo-123', channel: 'ig', service: 'office move', cityName: 'Newark' },
        null,
        2,
      );
    case 'reel_script':
      return JSON.stringify(
        { beforeR2: 'jobs/demo/before.jpg', afterR2: 'jobs/demo/after.jpg', voice: 'witty' },
        null,
        2,
      );
    case 'review_response':
      return JSON.stringify(
        {
          reviewText: 'Crew was on time, super friendly.',
          rating: 5,
          customerName: 'Maria',
          platform: 'google',
        },
        null,
        2,
      );
    case 'press_release':
      return JSON.stringify(
        { topic: 'Brick Labor expands to Hudson County', angle: 'flat-rate, same-day' },
        null,
        2,
      );
    case 'newsletter':
      return JSON.stringify({ topic: 'Spring cleanout pricing locked through May' }, null, 2);
    case 'seo_gap':
      return JSON.stringify(
        {
          competitorUrls: ['https://www.taskrabbit.com', 'https://www.bellhop.com'],
          ourTopics: ['moving', 'hauling'],
        },
        null,
        2,
      );
    case 'pseo_page':
      return JSON.stringify(
        { city: 'Maplewood', service: 'lawn cleanup', cityPopulation: 25665 },
        null,
        2,
      );
    default:
      return '{}';
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Recent Runs
// ─────────────────────────────────────────────────────────────────────────────

function RecentRuns({ headers }: { headers: HeadersInit }): JSX.Element {
  const [runs, setRuns] = useState<Run[]>([]);
  const [open, setOpen] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(ENDPOINTS.runs, { headers });
      const data = (await res.json()) as { ok: boolean; runs?: Run[] };
      if (data.ok && data.runs) setRuns(data.runs);
    } finally {
      setLoading(false);
    }
  }, [headers]);

  useEffect(() => {
    void load();
  }, [load]);

  const preview = useCallback(
    async (runId: string) => {
      if (open[runId]) {
        setOpen((prev) => {
          const next = { ...prev };
          delete next[runId];
          return next;
        });
        return;
      }
      const res = await fetch(ENDPOINTS.preview(runId), { headers });
      const data = (await res.json()) as { ok: boolean; content?: string };
      if (data.ok && data.content) {
        setOpen((prev) => ({ ...prev, [runId]: data.content! }));
      }
    },
    [headers, open],
  );

  const publish = useCallback(
    async (runId: string) => {
      await fetch(ENDPOINTS.post(runId), {
        method: 'POST',
        headers,
        body: JSON.stringify({}),
      });
      await load();
    },
    [headers, load],
  );

  return (
    <section className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-sm">
      <header className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">Recent Runs</h2>
        <button type="button" onClick={load} className="text-sm text-neutral-600 hover:underline">
          {loading ? 'Loading…' : 'Refresh'}
        </button>
      </header>
      <ul className="mt-4 divide-y divide-neutral-200">
        {runs.length === 0 ? (
          <li className="py-4 text-sm text-neutral-500">No runs yet — generate something above.</li>
        ) : null}
        {runs.map((r) => (
          <li key={r.id} className="py-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <div className="text-sm font-medium">
                  {r.kind} <span className="text-neutral-500">· {r.status}</span>
                </div>
                <div className="text-xs text-neutral-500">
                  {new Date(r.created_at).toLocaleString()} · {r.tokens_in}/{r.tokens_out} tok
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => preview(r.id)}
                  className="rounded-md border border-neutral-300 px-3 py-1 text-xs hover:border-neutral-400"
                >
                  {open[r.id] ? 'Hide' : 'Preview'}
                </button>
                <button
                  type="button"
                  onClick={() => publish(r.id)}
                  className="rounded-md bg-neutral-900 px-3 py-1 text-xs text-white"
                >
                  Publish
                </button>
              </div>
            </div>
            {open[r.id] ? (
              <pre className="mt-2 max-h-64 overflow-auto rounded-md bg-neutral-50 p-3 text-xs">
                {open[r.id]}
              </pre>
            ) : null}
            {r.error ? <div className="mt-1 text-xs text-red-700">{r.error}</div> : null}
          </li>
        ))}
      </ul>
    </section>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Lead board
// ─────────────────────────────────────────────────────────────────────────────

function LeadBoard({ headers }: { headers: HeadersInit }): JSX.Element {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [minScore, setMinScore] = useState(40);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const res = await fetch(`${ENDPOINTS.leads}?minScore=${minScore}`, { headers });
      const data = (await res.json()) as { ok: boolean; leads?: Lead[] };
      if (!cancelled && data.ok && data.leads) setLeads(data.leads);
    })();
    return () => {
      cancelled = true;
    };
  }, [headers, minScore]);

  return (
    <section className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-sm">
      <header className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-xl font-semibold">Lead Scoring</h2>
        <label className="text-sm text-neutral-600">
          Min score:
          <input
            type="number"
            min={0}
            max={100}
            value={minScore}
            onChange={(e) => setMinScore(Math.max(0, Math.min(100, Number(e.target.value) || 0)))}
            className="ml-2 w-16 rounded-md border border-neutral-300 px-2 py-1"
          />
        </label>
      </header>
      <table className="mt-3 w-full text-sm">
        <thead>
          <tr className="border-b border-neutral-200 text-left text-xs uppercase tracking-wide text-neutral-500">
            <th className="py-2 pr-2">Score</th>
            <th className="py-2 pr-2">Contact</th>
            <th className="py-2 pr-2">Signals</th>
            <th className="py-2 pr-2">When</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-neutral-100">
          {leads.length === 0 ? (
            <tr>
              <td colSpan={4} className="py-4 text-center text-neutral-500">
                No leads above {minScore} yet.
              </td>
            </tr>
          ) : null}
          {leads.map((l) => (
            <tr key={l.id}>
              <td className="py-2 pr-2 font-mono font-semibold">{l.score}</td>
              <td className="py-2 pr-2">{l.lead_email || l.lead_phone || '—'}</td>
              <td className="py-2 pr-2">
                <SignalPills signals={l.signals} />
              </td>
              <td className="py-2 pr-2 text-xs text-neutral-500">
                {new Date(l.classified_at).toLocaleString()}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}

/** Renders each signal key:value pair as its own styled pill — never as joined text. */
function SignalPills({ signals }: { signals: Record<string, number> }): JSX.Element {
  if (!signals || typeof signals !== 'object') return <></>;
  const entries = Object.entries(signals);
  if (entries.length === 0) return <span className="text-xs text-neutral-400">—</span>;
  return (
    <ul
      aria-label="Signals"
      className="flex flex-wrap gap-1"
      style={{ listStyle: 'none', margin: 0, padding: 0 }}
    >
      {entries.map(([k, v], i) => (
        <li
          key={k}
          style={{ animationDelay: `${i * 50}ms` }}
          className="inline-flex animate-[pill-enter_0.35s_ease_both] motion-reduce:animate-none items-center gap-1 rounded-full border border-neutral-200 bg-neutral-50 px-2 py-0.5 font-mono text-[11px] font-medium text-neutral-700 transition-all duration-[333ms] hover:-translate-y-0.5 hover:border-neutral-400 hover:bg-neutral-100 hover:shadow-sm"
        >
          <span className="text-neutral-500">{k}</span>
          <span className="font-semibold text-neutral-800">{v}</span>
        </li>
      ))}
    </ul>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Audience exporter
// ─────────────────────────────────────────────────────────────────────────────

function AudienceExporter({ headers }: { headers: HeadersInit }): JSX.Element {
  const [platform, setPlatform] = useState<'meta' | 'tiktok' | 'google'>('meta');
  const [minSpendCents, setMinSpendCents] = useState(20000);
  const [sinceDays, setSinceDays] = useState(365);
  const [result, setResult] = useState<{ count: number; downloadUrl: string } | null>(null);
  const [busy, setBusy] = useState(false);

  const run = useCallback(async () => {
    setBusy(true);
    setResult(null);
    const res = await fetch(ENDPOINTS.audienceExport(platform), {
      method: 'POST',
      headers,
      body: JSON.stringify({ minSpendCents, sinceDays }),
    });
    const data = (await res.json()) as { ok: boolean; count?: number; downloadUrl?: string };
    if (data.ok && data.downloadUrl) {
      setResult({ count: data.count ?? 0, downloadUrl: data.downloadUrl });
    }
    setBusy(false);
  }, [headers, platform, minSpendCents, sinceDays]);

  return (
    <section className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-sm">
      <h2 className="text-xl font-semibold">Audience Exporter</h2>
      <p className="mt-1 text-sm text-neutral-600">
        SHA-256 hashed email CSV for Meta / TikTok / Google Customer Match.
      </p>
      <div className="mt-3 flex flex-wrap items-center gap-3">
        <select
          value={platform}
          onChange={(e) => setPlatform(e.target.value as 'meta' | 'tiktok' | 'google')}
          className="rounded-md border border-neutral-300 px-2 py-1 text-sm"
        >
          <option value="meta">Meta</option>
          <option value="tiktok">TikTok</option>
          <option value="google">Google</option>
        </select>
        <label className="text-sm">
          Min spend ($):
          <input
            type="number"
            min={0}
            value={minSpendCents / 100}
            onChange={(e) => setMinSpendCents(Math.max(0, Number(e.target.value) || 0) * 100)}
            className="ml-2 w-24 rounded-md border border-neutral-300 px-2 py-1"
          />
        </label>
        <label className="text-sm">
          Since (days):
          <input
            type="number"
            min={1}
            max={720}
            value={sinceDays}
            onChange={(e) =>
              setSinceDays(Math.max(1, Math.min(720, Number(e.target.value) || 365)))
            }
            className="ml-2 w-20 rounded-md border border-neutral-300 px-2 py-1"
          />
        </label>
        <button
          type="button"
          onClick={run}
          disabled={busy}
          className="rounded-md bg-neutral-900 px-3 py-1 text-sm text-white disabled:opacity-50"
        >
          {busy ? 'Building…' : 'Export'}
        </button>
      </div>
      {result ? (
        <div className="mt-3 rounded-md border border-emerald-200 bg-emerald-50 p-3 text-sm">
          Exported <strong>{result.count}</strong> hashed emails.{' '}
          <a href={result.downloadUrl} className="text-emerald-700 underline" download>
            Download CSV
          </a>
        </div>
      ) : null}
    </section>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Press distribution
// ─────────────────────────────────────────────────────────────────────────────

function PressPanel({ headers }: { headers: HeadersInit }): JSX.Element {
  const [contacts, setContacts] = useState<PressContact[]>([]);
  const [draft, setDraft] = useState({ subject: '', bodyText: '' });
  const [adding, setAdding] = useState({ name: '', outlet: '', email: '', beat: '' });
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState<number | null>(null);

  const load = useCallback(async () => {
    const res = await fetch(ENDPOINTS.pressContacts, { headers });
    const data = (await res.json()) as { ok: boolean; contacts?: PressContact[] };
    if (data.ok && data.contacts) setContacts(data.contacts);
  }, [headers]);

  useEffect(() => {
    void load();
  }, [load]);

  const addContact = useCallback(async () => {
    if (!adding.name || !adding.outlet || !adding.email) return;
    await fetch(ENDPOINTS.pressContacts, {
      method: 'POST',
      headers,
      body: JSON.stringify(adding),
    });
    setAdding({ name: '', outlet: '', email: '', beat: '' });
    await load();
  }, [headers, adding, load]);

  const distribute = useCallback(async () => {
    setBusy(true);
    setSent(null);
    const res = await fetch(ENDPOINTS.pressDistribute, {
      method: 'POST',
      headers,
      body: JSON.stringify(draft),
    });
    const data = (await res.json()) as { ok: boolean; sent?: number; count?: number };
    if (data.ok) setSent(data.sent ?? data.count ?? 0);
    setBusy(false);
  }, [headers, draft]);

  return (
    <section className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-sm">
      <h2 className="text-xl font-semibold">Press Distribution</h2>
      <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-2">
        <div>
          <h3 className="text-sm font-medium text-neutral-700">Contacts ({contacts.length})</h3>
          <ul className="mt-2 max-h-48 overflow-auto divide-y divide-neutral-100 text-sm">
            {contacts.map((c) => (
              <li key={c.id} className="py-2">
                <div className="font-medium">
                  {c.name} <span className="text-neutral-500">— {c.outlet}</span>
                </div>
                <div className="text-xs text-neutral-500">
                  {c.email}
                  {c.beat ? ` · ${c.beat}` : ''}
                </div>
              </li>
            ))}
          </ul>
          <div className="mt-3 space-y-2">
            <input
              placeholder="Name"
              value={adding.name}
              onChange={(e) => setAdding({ ...adding, name: e.target.value })}
              className="block w-full rounded-md border border-neutral-300 px-2 py-1 text-sm"
            />
            <input
              placeholder="Outlet"
              value={adding.outlet}
              onChange={(e) => setAdding({ ...adding, outlet: e.target.value })}
              className="block w-full rounded-md border border-neutral-300 px-2 py-1 text-sm"
            />
            <input
              placeholder="Email"
              value={adding.email}
              onChange={(e) => setAdding({ ...adding, email: e.target.value })}
              className="block w-full rounded-md border border-neutral-300 px-2 py-1 text-sm"
            />
            <input
              placeholder="Beat (optional)"
              value={adding.beat}
              onChange={(e) => setAdding({ ...adding, beat: e.target.value })}
              className="block w-full rounded-md border border-neutral-300 px-2 py-1 text-sm"
            />
            <button
              type="button"
              onClick={addContact}
              className="rounded-md border border-neutral-300 px-3 py-1 text-sm hover:border-neutral-400"
            >
              Add contact
            </button>
          </div>
        </div>
        <div>
          <h3 className="text-sm font-medium text-neutral-700">Blast a release</h3>
          <input
            placeholder="Subject"
            value={draft.subject}
            onChange={(e) => setDraft({ ...draft, subject: e.target.value })}
            className="mt-2 block w-full rounded-md border border-neutral-300 px-2 py-1 text-sm"
          />
          <textarea
            placeholder="Body (plain text)"
            rows={8}
            value={draft.bodyText}
            onChange={(e) => setDraft({ ...draft, bodyText: e.target.value })}
            className="mt-2 block w-full rounded-md border border-neutral-300 px-2 py-1 text-sm"
          />
          <button
            type="button"
            onClick={distribute}
            disabled={busy || draft.subject.length < 3 || draft.bodyText.length < 20}
            className="mt-2 rounded-md bg-neutral-900 px-3 py-1 text-sm text-white disabled:opacity-50"
          >
            {busy ? 'Sending…' : 'Distribute'}
          </button>
          {sent !== null ? (
            <p className="mt-2 text-sm text-emerald-700">Sent / queued {sent} contacts.</p>
          ) : null}
        </div>
      </div>
    </section>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
