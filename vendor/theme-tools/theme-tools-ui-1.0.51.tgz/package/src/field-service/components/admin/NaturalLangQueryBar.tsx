import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useState } from 'react';

interface QueryResponse {
  ok: boolean;
  sql?: string;
  rows?: Array<Record<string, unknown>>;
  error?: string;
  code?: string;
  provider?: 'anthropic' | 'mock';
}

const EXAMPLES = [
  'How many bookings came in today?',
  'Top 10 workers by jobs completed',
  'Bookings in Newark this week',
  'Disputes opened in the last 7 days',
];

/**
 * Natural-language query bar. Sends English to /api/admin/query, displays
 * the generated SQL + result table side-by-side. Server enforces SELECT-only
 * and rejects DROP/DELETE/UPDATE/INSERT/etc — we render the rejection
 * inline so the operator can refine.
 */
export function NaturalLangQueryBar({ headers }: { headers: HeadersInit }) {
  useThemeToolsSurface('natural-lang-query-bar');
  const [question, setQuestion] = useState('');
  const [result, setResult] = useState<QueryResponse | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(ev: React.FormEvent<HTMLFormElement>): Promise<void> {
    ev.preventDefault();
    if (!question.trim()) return;
    setLoading(true);
    setResult(null);
    try {
      const res = await fetch('/api/admin/query', {
        method: 'POST',
        headers: { ...headers, 'content-type': 'application/json' },
        body: JSON.stringify({ question }),
      });
      const json = (await res.json()) as QueryResponse;
      setResult(json);
    } catch (err) {
      setResult({ ok: false, error: (err as Error).message });
    } finally {
      setLoading(false);
    }
  }

  const columns = result?.rows?.[0] ? Object.keys(result.rows[0]) : [];

  return (
    <div className="space-y-4" data-testid="nl-query">
      <form onSubmit={submit} className="space-y-2">
        <label htmlFor="nl-q" className="text-brand-mute block text-xs uppercase">
          Ask in plain English
        </label>
        <div className="flex gap-2">
          <input
            id="nl-q"
            type="text"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="e.g. revenue by city last 30 days"
            className="input flex-1"
            autoComplete="off"
            spellCheck={false}
          />
          <button type="submit" className="btn-primary" disabled={loading || !question.trim()}>
            {loading ? 'Translating…' : 'Run'}
          </button>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {EXAMPLES.map((ex) => (
            <button
              key={ex}
              type="button"
              onClick={() => setQuestion(ex)}
              className="text-brand-mute rounded border border-white/10 bg-white/5 px-2 py-0.5 text-xs hover:bg-white/10"
            >
              {ex}
            </button>
          ))}
        </div>
      </form>

      {result && (
        <div className="space-y-3">
          {result.sql && (
            <pre className="overflow-x-auto rounded bg-black/40 p-3 text-xs leading-relaxed text-cyan-200">
              <code>{result.sql}</code>
            </pre>
          )}
          {!result.ok && (
            <p className="rounded border border-red-500/40 bg-red-500/10 p-2 text-sm text-red-200">
              {result.error} {result.code && <em className="text-xs">({result.code})</em>}
            </p>
          )}
          {result.ok && result.rows && result.rows.length > 0 && (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="text-brand-mute uppercase">
                  <tr>
                    {columns.map((c) => (
                      <th key={c} className="px-2 py-1.5">
                        {c}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {result.rows.slice(0, 100).map((r, i) => (
                    <tr key={i} className="border-t border-white/5">
                      {columns.map((c) => (
                        <td key={c} className="px-2 py-1 font-mono">
                          {formatCell(r[c])}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
              <p className="text-brand-mute mt-2 text-xs">
                {result.rows.length} row{result.rows.length === 1 ? '' : 's'} ·{' '}
                {result.provider ?? 'mock'} translator
              </p>
            </div>
          )}
          {result.ok && (!result.rows || result.rows.length === 0) && (
            <p className="text-brand-mute text-sm">No rows.</p>
          )}
        </div>
      )}
    </div>
  );
}

function formatCell(v: unknown): string {
  if (v == null) return '—';
  if (typeof v === 'object') return JSON.stringify(v);
  return String(v);
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
