import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { getAdminToken, formatRelative } from '@theme.tools/crm/field-service/admin-api';

/**
 * Wave 21C — `/admin/notifications`. Paginated list of admin_events rows
 * (last 30 days by default), filterable by kind and severity.
 *
 * Pairs with the live SSE feed on /admin/super-admin — this view is the
 * "what-happened" history; the SSE feed is the "what-is-happening-now".
 */

interface NotificationRow {
  id: string;
  ts: number;
  kind: string;
  severity: 'info' | 'warn' | 'error' | 'critical';
  actor: string | null;
  targetType: string | null;
  targetId: string | null;
  summary: string;
  details: unknown;
}

interface KindRow {
  kind: string;
  count: number;
  top_severity: string;
}

interface ListResponse {
  ok: true;
  events: NotificationRow[];
  nextCursor: number | null;
  since: number;
  until: number;
}

interface KindsResponse {
  ok: true;
  kinds: KindRow[];
}

const SEVERITY_STYLES: Record<NotificationRow['severity'], string> = {
  info: 'bg-white/5 text-brand-mute border-white/10',
  warn: 'bg-amber-950/30 text-amber-200 border-amber-500/30',
  error: 'bg-red-950/30 text-red-200 border-red-500/30',
  critical: 'bg-red-950/50 text-red-100 border-red-500/60',
};

export function NotificationsInbox() {
  useThemeToolsSurface('notifications-inbox');
  const [kind, setKind] = useState<string>('');
  const [severity, setSeverity] = useState<string>('');
  const [rows, setRows] = useState<NotificationRow[]>([]);
  const [cursor, setCursor] = useState<number | null>(null);
  const [nextCursor, setNextCursor] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [kinds, setKinds] = useState<KindRow[]>([]);
  const [expanded, setExpanded] = useState<string | null>(null);

  const headers = useMemo<HeadersInit>(() => {
    const token = getAdminToken();
    const out: Record<string, string> = {};
    if (token) out.authorization = `Bearer ${token}`;
    return out;
  }, []);

  const load = useCallback(
    async (mode: 'reset' | 'append') => {
      setLoading(true);
      setError(null);
      const params = new URLSearchParams({ limit: '50' });
      if (kind) params.set('kind', kind);
      if (severity) params.set('severity', severity);
      if (mode === 'append' && cursor) params.set('cursor', String(cursor));
      try {
        const res = await fetch(`/api/admin/notifications?${params.toString()}`, { headers });
        if (!res.ok) {
          setError(`HTTP ${res.status}`);
          setLoading(false);
          return;
        }
        const data = (await res.json()) as ListResponse;
        setRows((prev) => (mode === 'append' ? [...prev, ...data.events] : data.events));
        setNextCursor(data.nextCursor);
      } catch (e) {
        setError((e as Error).message);
      } finally {
        setLoading(false);
      }
    },
    [kind, severity, cursor, headers],
  );

  // Load the kind list once for the filter dropdown.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(`/api/admin/notifications/kinds`, { headers });
        if (!res.ok) return;
        const data = (await res.json()) as KindsResponse;
        if (!cancelled) setKinds(data.kinds);
      } catch {
        /* ignore */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [headers]);

  useEffect(() => {
    setCursor(null);
    void load('reset');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [kind, severity]);

  return (
    <section className="section">
      <div className="container-pad space-y-6">
        <header className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="eyebrow mb-1">Admin · ops log</p>
            <h1 className="text-3xl font-extrabold">Notifications</h1>
            <p className="text-brand-mute mt-1 text-sm">
              Every admin event from the last 30 days — refunds, overrides, impersonations, dispatch
              failures.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <select
              value={kind}
              onChange={(e) => setKind(e.target.value)}
              className="rounded border border-brand-cyan/30 bg-black/60 px-3 py-1.5 text-sm text-white"
              aria-label="Filter by kind"
            >
              <option value="">All kinds ({kinds.reduce((a, k) => a + k.count, 0)})</option>
              {kinds.map((k) => (
                <option key={k.kind} value={k.kind}>
                  {k.kind} ({k.count})
                </option>
              ))}
            </select>
            <select
              value={severity}
              onChange={(e) => setSeverity(e.target.value)}
              className="rounded border border-brand-cyan/30 bg-black/60 px-3 py-1.5 text-sm text-white"
              aria-label="Filter by severity"
            >
              <option value="">All severities</option>
              <option value="info">Info</option>
              <option value="warn">Warn</option>
              <option value="error">Error</option>
              <option value="critical">Critical</option>
            </select>
          </div>
        </header>

        {error && (
          <div
            role="alert"
            className="rounded border border-red-500/40 bg-red-950/30 p-3 text-sm text-red-300"
          >
            {error}
          </div>
        )}

        <ul className="space-y-2">
          {rows.length === 0 && !loading && (
            <li className="rounded border border-dashed border-white/10 p-6 text-center text-brand-mute">
              No events in this window.
            </li>
          )}
          {rows.map((r) => {
            const isOpen = expanded === r.id;
            return (
              <li
                key={r.id}
                className={`rounded-xl border p-3 text-sm transition ${SEVERITY_STYLES[r.severity]}`}
              >
                <button
                  type="button"
                  onClick={() => setExpanded(isOpen ? null : r.id)}
                  className="flex w-full items-start justify-between gap-3 text-left"
                  aria-expanded={isOpen}
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-baseline gap-x-2 gap-y-0.5">
                      <span className="font-mono text-xs uppercase tracking-wide opacity-70">
                        {r.kind}
                      </span>
                      <span className="text-xs opacity-60">·</span>
                      <span className="text-xs opacity-60">{r.actor || 'system'}</span>
                      {r.targetType && (
                        <>
                          <span className="text-xs opacity-60">·</span>
                          <span className="text-xs opacity-60">
                            {r.targetType}:{(r.targetId ?? '').slice(0, 12)}
                          </span>
                        </>
                      )}
                    </div>
                    <div className="mt-1 font-medium">{r.summary}</div>
                  </div>
                  <time
                    dateTime={new Date(r.ts).toISOString()}
                    className="shrink-0 whitespace-nowrap text-xs opacity-70"
                  >
                    {formatRelative(new Date(r.ts).toISOString())}
                  </time>
                </button>
                {isOpen && r.details != null && (
                  <pre className="mt-3 max-h-72 overflow-auto rounded bg-black/40 p-3 text-xs opacity-90">
                    {JSON.stringify(r.details, null, 2)}
                  </pre>
                )}
              </li>
            );
          })}
        </ul>

        {nextCursor && (
          <div className="flex justify-center">
            <button
              type="button"
              onClick={() => {
                setCursor(nextCursor);
                void load('append');
              }}
              disabled={loading}
              className="rounded border border-brand-cyan/30 px-4 py-1.5 text-sm text-brand-cyan hover:bg-brand-cyan/10 disabled:opacity-50"
            >
              {loading ? 'Loading…' : 'Load older'}
            </button>
          </div>
        )}
      </div>
    </section>
  );
}

export default NotificationsInbox;
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
