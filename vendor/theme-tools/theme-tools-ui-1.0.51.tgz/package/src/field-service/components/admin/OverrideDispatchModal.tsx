import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useState } from 'react';
import { getAdminToken } from '@theme.tools/crm/field-service/admin-api';

/**
 * Wave 21C — Override-dispatch modal. Opens from JobsBrowser's "Override"
 * button on any pending/open gig.
 *
 * Two-step shape: (1) operator types a substring of the worker's name/phone,
 * picks a candidate from the live list of dispatchable workers; (2) writes a
 * one-line reason; (3) fires. We pull dispatchable workers from the existing
 * `/admin/entities/workers` endpoint with a `dispatchable` status filter so we
 * never offer a paused or suspended worker.
 */

interface WorkerHit {
  id: string;
  first_name: string;
  last_name: string;
  phone: string;
  tier: string;
  status: string;
  rating_avg: number | null;
  jobs_completed: number;
}

interface WorkersResponse {
  ok: true;
  workers: WorkerHit[];
}

export function OverrideDispatchModal({
  bookingId,
  customerName,
  onClose,
  onSuccess,
}: {
  bookingId: string;
  customerName: string;
  onClose: () => void;
  onSuccess: () => void;
}) {
  const [gigId, setGigId] = useState<string | null>(null);
  const [gigError, setGigError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [hits, setHits] = useState<WorkerHit[]>([]);
  const [picked, setPicked] = useState<WorkerHit | null>(null);
  const [reason, setReason] = useState('');
  const [asShiftLead, setAsShiftLead] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  // Resolve the active (open|dispatched|partial) gig for this booking. We do
  // this server-fetch on mount rather than threading the gig id through the
  // JobRow shape so the existing browsers don't need a schema change.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const token = getAdminToken();
      try {
        const res = await fetch(`/admin/entities/jobs/${bookingId}`, {
          headers: token ? { authorization: `Bearer ${token}` } : {},
        });
        if (!res.ok) {
          if (!cancelled) setGigError(`Couldn't load gig: HTTP ${res.status}`);
          return;
        }
        const data = (await res.json()) as { gigs?: Array<{ id: string; status: string }> };
        const open = (data.gigs ?? []).find((g) =>
          ['open', 'dispatched', 'partial'].includes(g.status),
        );
        if (!cancelled) {
          if (!open) setGigError('No open gig on this booking — nothing to override.');
          else setGigId(open.id);
        }
      } catch (e) {
        if (!cancelled) setGigError((e as Error).message);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [bookingId]);

  useEffect(() => {
    if (search.trim().length < 2) {
      setHits([]);
      return;
    }
    const token = getAdminToken();
    const ctrl = new AbortController();
    const t = window.setTimeout(async () => {
      try {
        const res = await fetch(
          `/admin/entities/workers?q=${encodeURIComponent(search.trim())}&active=true&limit=15`,
          {
            headers: token ? { authorization: `Bearer ${token}` } : {},
            signal: ctrl.signal,
          },
        );
        if (!res.ok) return;
        const data = (await res.json()) as WorkersResponse;
        // Only show actually-dispatchable workers (active|verified). The list
        // endpoint returns archived/paused too — filter client-side so we
        // never let an operator pick an inactive worker by accident.
        setHits((data.workers ?? []).filter((w) => ['active', 'verified'].includes(w.status)));
      } catch {
        /* abort/network — ignore */
      }
    }, 200);
    return () => {
      window.clearTimeout(t);
      ctrl.abort();
    };
  }, [search]);

  const submit = useCallback(async () => {
    if (!gigId || !picked) return;
    setSubmitting(true);
    setSubmitError(null);
    const token = getAdminToken();
    try {
      const res = await fetch('/api/admin/dispatch/override', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          ...(token ? { authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          gigId,
          workerId: picked.id,
          reason: reason.trim(),
          asShiftLead,
        }),
      });
      const data = (await res.json()) as { ok: boolean; error?: string };
      if (!res.ok || !data.ok) {
        setSubmitError(data.error || `HTTP ${res.status}`);
        setSubmitting(false);
        return;
      }
      onSuccess();
    } catch (e) {
      setSubmitError((e as Error).message);
      setSubmitting(false);
    }
  }, [gigId, picked, reason, asShiftLead, onSuccess]);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="override-dispatch-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-lg rounded-2xl border border-amber-500/30 bg-bg-primary p-6 shadow-2xl">
        <header className="mb-3 flex items-center justify-between">
          <h3 id="override-dispatch-title" className="text-lg font-bold text-amber-200">
            Override dispatch
          </h3>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="inline-flex min-h-[24px] min-w-[24px] items-center justify-center rounded border border-white/10 px-2 py-0.5 text-xs leading-none text-brand-mute transition-colors hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
          >
            ✕
          </button>
        </header>
        <p className="text-brand-mute mb-4 text-sm">
          Force-assign a worker to {customerName}'s job. Bypasses the AI rules engine — use only
          when you have a reason (regular customer, requested worker, dispatch deadlock).
        </p>

        {gigError && (
          <div className="mb-3 rounded border border-red-500/40 bg-red-950/30 p-3 text-sm text-red-300">
            {gigError}
          </div>
        )}

        <label className="block text-xs uppercase tracking-wide text-brand-mute">
          Worker (search by name or phone)
        </label>
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Start typing…"
          className="mt-1 w-full rounded border border-brand-cyan/30 bg-black/60 px-3 py-1.5 text-sm text-white"
          disabled={!!gigError || !gigId}
        />
        {hits.length > 0 && !picked && (
          <ul className="mt-2 max-h-48 overflow-y-auto rounded border border-white/10 bg-black/40">
            {hits.map((w) => (
              <li key={w.id}>
                <button
                  type="button"
                  onClick={() => setPicked(w)}
                  className="flex w-full items-center justify-between px-3 py-2 text-left text-sm hover:bg-white/5"
                >
                  <span className="text-white">
                    {w.first_name} {w.last_name}
                  </span>
                  <span className="text-xs text-brand-mute">
                    {w.tier} · {w.jobs_completed} jobs · {w.rating_avg ?? '—'}★
                  </span>
                </button>
              </li>
            ))}
          </ul>
        )}
        {picked && (
          <div className="mt-2 flex items-center justify-between rounded border border-amber-500/40 bg-amber-950/20 p-2 text-sm">
            <span className="text-amber-100">
              {picked.first_name} {picked.last_name} · {picked.tier}
            </span>
            <button
              type="button"
              onClick={() => setPicked(null)}
              className="text-xs text-amber-300 underline"
            >
              change
            </button>
          </div>
        )}

        <label className="mt-3 block text-xs uppercase tracking-wide text-brand-mute">
          Reason (audited)
        </label>
        <textarea
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          rows={2}
          placeholder="Why override the AI? (required)"
          className="mt-1 w-full rounded border border-brand-cyan/30 bg-black/60 px-3 py-1.5 text-sm text-white"
        />

        <label className="mt-3 flex items-center gap-2 text-sm text-white">
          <input
            type="checkbox"
            checked={asShiftLead}
            onChange={(e) => setAsShiftLead(e.target.checked)}
          />
          Assign as shift lead (gets the lead bonus)
        </label>

        {submitError && (
          <div className="mt-3 rounded border border-red-500/40 bg-red-950/30 p-3 text-sm text-red-300">
            {submitError}
          </div>
        )}

        <footer className="mt-5 flex justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="rounded border border-white/10 px-3 py-1.5 text-sm text-brand-mute hover:text-white"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => void submit()}
            disabled={!gigId || !picked || reason.trim().length < 3 || submitting}
            className="rounded bg-amber-500 px-3 py-1.5 text-sm font-semibold text-black hover:bg-amber-400 disabled:opacity-40"
            data-testid="override-dispatch-confirm"
          >
            {submitting ? 'Assigning…' : 'Override + dispatch'}
          </button>
        </footer>
      </div>
    </div>
  );
}

export default OverrideDispatchModal;
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
