import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useCallback, useMemo, useState } from 'react';

/**
 * PseoBuilder — bulk-generate city × service pSEO drafts. Picks each cell in
 * the grid, asks the worker to draft the page, and stages it locally for
 * review. The worker enforces the uniqueness gate (Jaccard trigram ≥0.75) by
 * receiving previously-accepted drafts in the `corpus` field of the request.
 *
 * Output stays in component state — never auto-committed. Admin downloads
 * everything as a single markdown bundle when ready.
 */

interface Props {
  readonly token: string;
}

interface Cell {
  city: string;
  service: string;
  status: 'pending' | 'running' | 'done' | 'rejected' | 'failed';
  body?: string;
  error?: string;
}

const DEFAULT_CITIES = [
  'Newark',
  'Belleville',
  'Bloomfield',
  'East Orange',
  'Irvington',
  'Jersey City',
  'Maplewood',
];
const DEFAULT_SERVICES = ['moving help', 'junk hauling', 'estate cleanout', 'lawn cleanup'];

export function PseoBuilder({ token }: Props): JSX.Element {
  useThemeToolsSurface('pseo-builder');
  const [citiesText, setCitiesText] = useState(DEFAULT_CITIES.join('\n'));
  const [servicesText, setServicesText] = useState(DEFAULT_SERVICES.join('\n'));
  const [cells, setCells] = useState<Cell[]>([]);
  const [running, setRunning] = useState(false);
  const [activeIdx, setActiveIdx] = useState<number | null>(null);

  const cities = useMemo(
    () =>
      citiesText
        .split(/\n+/)
        .map((s) => s.trim())
        .filter(Boolean),
    [citiesText],
  );
  const services = useMemo(
    () =>
      servicesText
        .split(/\n+/)
        .map((s) => s.trim())
        .filter(Boolean),
    [servicesText],
  );

  const buildPlan = useCallback(() => {
    const next: Cell[] = [];
    for (const city of cities) {
      for (const service of services) {
        next.push({ city, service, status: 'pending' });
      }
    }
    setCells(next);
    setActiveIdx(null);
  }, [cities, services]);

  const run = useCallback(async () => {
    if (cells.length === 0) return;
    setRunning(true);
    const corpus: string[] = [];
    const next: Cell[] = [...cells];
    for (let i = 0; i < next.length; i++) {
      const cell = next[i]!;
      next[i] = { ...cell, status: 'running' };
      setCells([...next]);
      try {
        const res = await fetch('/api/admin/marketing/generate/pseo_page', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ city: cell.city, service: cell.service, corpus }),
        });
        const data = (await res.json()) as {
          ok: boolean;
          error?: string;
          contentPreview?: string;
        };
        if (!data.ok) {
          next[i] = {
            ...cell,
            status: data.error?.includes('uniqueness') ? 'rejected' : 'failed',
            error: data.error,
          };
        } else {
          next[i] = { ...cell, status: 'done', body: data.contentPreview ?? '' };
          if (data.contentPreview) corpus.push(data.contentPreview);
        }
      } catch (err) {
        next[i] = { ...cell, status: 'failed', error: (err as Error).message };
      }
      setCells([...next]);
    }
    setRunning(false);
  }, [token, cells]);

  const bundle = useMemo(() => {
    return cells
      .filter((c) => c.status === 'done' && c.body)
      .map((c) => `<!-- ${c.city} × ${c.service} -->\n\n${c.body}\n\n---\n`)
      .join('\n');
  }, [cells]);

  const downloadBundle = useCallback(() => {
    const blob = new Blob([bundle], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pseo-bundle-${Date.now()}.md`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }, [bundle]);

  return (
    <section className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-sm">
      <h2 className="text-xl font-semibold">pSEO Builder</h2>
      <p className="mt-1 text-sm text-neutral-600">
        Bulk-generate city × service pages. Uniqueness gate rejects near-duplicates (Jaccard ≥
        0.75).
      </p>
      <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2">
        <label className="block text-sm font-medium text-neutral-700">
          Cities (one per line)
          <textarea
            rows={6}
            value={citiesText}
            onChange={(e) => setCitiesText(e.target.value)}
            className="mt-1 block w-full rounded-md border border-neutral-300 p-2 font-mono text-xs"
            spellCheck={false}
          />
        </label>
        <label className="block text-sm font-medium text-neutral-700">
          Services (one per line)
          <textarea
            rows={6}
            value={servicesText}
            onChange={(e) => setServicesText(e.target.value)}
            className="mt-1 block w-full rounded-md border border-neutral-300 p-2 font-mono text-xs"
            spellCheck={false}
          />
        </label>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        <button
          type="button"
          onClick={buildPlan}
          className="rounded-md border border-neutral-300 px-3 py-1 text-sm hover:border-neutral-400"
        >
          Build plan ({cities.length * services.length} cells)
        </button>
        <button
          type="button"
          onClick={run}
          disabled={running || cells.length === 0}
          className="rounded-md bg-neutral-900 px-3 py-1 text-sm text-white disabled:opacity-50"
        >
          {running ? 'Running…' : 'Run generator'}
        </button>
        <button
          type="button"
          onClick={downloadBundle}
          disabled={bundle.length === 0}
          className="rounded-md border border-neutral-300 px-3 py-1 text-sm disabled:opacity-50"
        >
          Download bundle
        </button>
      </div>

      {cells.length > 0 ? (
        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-neutral-200 text-left uppercase text-neutral-500">
                <th className="py-1 pr-2">City</th>
                <th className="py-1 pr-2">Service</th>
                <th className="py-1 pr-2">Status</th>
                <th className="py-1 pr-2">Length</th>
                <th className="py-1 pr-2" />
              </tr>
            </thead>
            <tbody>
              {cells.map((c, i) => (
                <tr key={`${c.city}-${c.service}`} className="border-b border-neutral-100">
                  <td className="py-1 pr-2">{c.city}</td>
                  <td className="py-1 pr-2">{c.service}</td>
                  <td className="py-1 pr-2">
                    <span className={statusClass(c.status)}>{c.status}</span>
                    {c.error ? <span className="ml-1 text-red-700">· {c.error}</span> : null}
                  </td>
                  <td className="py-1 pr-2">{c.body?.length ?? 0}</td>
                  <td className="py-1 pr-2">
                    {c.body ? (
                      <button
                        type="button"
                        onClick={() => setActiveIdx(activeIdx === i ? null : i)}
                        className="text-xs text-neutral-700 underline"
                      >
                        {activeIdx === i ? 'hide' : 'view'}
                      </button>
                    ) : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}

      {activeIdx !== null && cells[activeIdx]?.body ? (
        <pre className="mt-3 max-h-80 overflow-auto rounded-md bg-neutral-50 p-3 text-xs">
          {cells[activeIdx]?.body}
        </pre>
      ) : null}
    </section>
  );
}

function statusClass(status: Cell['status']): string {
  switch (status) {
    case 'done':
      return 'text-emerald-700';
    case 'running':
      return 'text-amber-700';
    case 'rejected':
      return 'text-orange-700';
    case 'failed':
      return 'text-red-700';
    default:
      return 'text-neutral-500';
  }
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
