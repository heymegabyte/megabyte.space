import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useEffect, useRef, useState } from 'react';

type JumpTab = 'gigs' | 'workers' | 'customers' | 'revenue' | 'disputes' | 'insights' | 'query';

interface Props {
  headers: HeadersInit;
  onClose: () => void;
  onJump: (tab: JumpTab) => void;
}

interface Action {
  label: string;
  hint: string;
  run: () => void | Promise<void>;
}

/**
 * Cmd+K command palette. Jumps between tabs and triggers admin-only ops
 * (refund + SMS blast). Focus traps the input on open; Esc closes.
 */
export function QuickActionPalette({ headers, onClose, onJump }: Props) {
  useThemeToolsSurface('quick-action-palette');
  const inputRef = useRef<HTMLInputElement>(null);
  const [query, setQuery] = useState('');
  const [busyMessage, setBusyMessage] = useState<string>('');

  useEffect(() => {
    requestAnimationFrame(() => {
      inputRef.current?.focus({ preventScroll: true });
    });
  }, []);

  async function blast(segment: 'paid_today' | 'completed_last_30d'): Promise<void> {
    const body = window.prompt(`SMS body for segment "${segment}" (max 320 chars):`);
    if (!body) return;
    setBusyMessage(`Sending blast to ${segment}…`);
    try {
      const res = await fetch('/api/admin/action/sms-blast', {
        method: 'POST',
        headers: { ...headers, 'content-type': 'application/json' },
        body: JSON.stringify({ segment, body, dryRun: false }),
      });
      const json = (await res.json()) as {
        ok: boolean;
        sent?: number;
        failed?: number;
        error?: string;
      };
      setBusyMessage(
        json.ok ? `Sent ${json.sent} · failed ${json.failed}` : `Failed: ${json.error}`,
      );
    } catch (err) {
      setBusyMessage(`Failed: ${(err as Error).message}`);
    }
  }

  async function refund(): Promise<void> {
    const bookingId = window.prompt('Booking ID to refund:');
    if (!bookingId) return;
    const amount = window.prompt('Amount in cents:');
    if (!amount || !/^\d+$/.test(amount)) return;
    const reason = window.prompt('Refund reason (≥3 chars):') ?? '';
    if (reason.length < 3) return;
    setBusyMessage('Recording refund…');
    try {
      const res = await fetch('/api/admin/action/refund', {
        method: 'POST',
        headers: { ...headers, 'content-type': 'application/json' },
        body: JSON.stringify({ bookingId, amountCents: Number(amount), reason }),
      });
      const json = (await res.json()) as { ok: boolean; error?: string };
      setBusyMessage(json.ok ? 'Refund recorded.' : `Failed: ${json.error}`);
    } catch (err) {
      setBusyMessage(`Failed: ${(err as Error).message}`);
    }
  }

  const actions: ReadonlyArray<Action> = [
    { label: 'Jump → Active Gigs', hint: 'g', run: () => onJump('gigs') },
    { label: 'Jump → Leaderboard', hint: 'w', run: () => onJump('workers') },
    { label: 'Jump → At-Risk Customers', hint: 'c', run: () => onJump('customers') },
    { label: 'Jump → Revenue', hint: 'r', run: () => onJump('revenue') },
    { label: 'Jump → Disputes', hint: 'd', run: () => onJump('disputes') },
    { label: 'Jump → AI Insights', hint: 'i', run: () => onJump('insights') },
    { label: 'Jump → NL Query', hint: 'q', run: () => onJump('query') },
    { label: 'SMS blast — paid today', hint: 'blast', run: () => void blast('paid_today') },
    {
      label: 'SMS blast — completed last 30d',
      hint: 'blast',
      run: () => void blast('completed_last_30d'),
    },
    { label: 'Record manual refund', hint: 'refund', run: () => void refund() },
  ];

  const filtered = query
    ? actions.filter((a) => a.label.toLowerCase().includes(query.toLowerCase()))
    : actions;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Quick action palette"
      className="fixed inset-0 z-50 flex items-start justify-center bg-black/70 p-4 pt-24"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-xl border border-white/10 bg-zinc-900 p-4 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Type to filter actions…"
          className="input w-full"
          data-testid="palette-input"
        />
        <ul className="mt-3 max-h-80 overflow-y-auto">
          {filtered.length === 0 && (
            <li className="text-brand-mute p-2 text-sm">No matching action.</li>
          )}
          {filtered.map((a) => (
            <li key={a.label}>
              <button
                type="button"
                onClick={() => void a.run()}
                className="flex w-full items-center justify-between rounded p-2 text-left text-sm hover:bg-white/10"
              >
                <span>{a.label}</span>
                <kbd className="text-brand-mute text-[10px] uppercase">{a.hint}</kbd>
              </button>
            </li>
          ))}
        </ul>
        {busyMessage && (
          <p className="text-brand-mute mt-2 border-t border-white/10 pt-2 text-xs">
            {busyMessage}
          </p>
        )}
      </div>
    </div>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
