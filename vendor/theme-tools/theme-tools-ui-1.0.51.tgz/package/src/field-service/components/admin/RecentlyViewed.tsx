import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useEffect, useState } from 'react';
import { adminFetch, formatRelative, readLocalRecent } from '@theme.tools/crm/field-service/admin-api';

/**
 * Wave 17 — Sticky bottom bar across the admin browsers.
 * Hydrates instantly from localStorage, refreshes from /entities/recently-viewed
 * in the background so cross-device viewing also surfaces.
 */

type Kind = 'job' | 'customer' | 'worker';

interface RecentEntry {
  kind: string;
  id: string;
  label: string;
  ts: number;
}

interface ServerRecent {
  ok: true;
  recent: Array<{
    entity_kind: Kind;
    entity_id: string;
    entity_label: string;
    last_viewed_at: string;
    view_count: number;
  }>;
}

export function RecentlyViewed({ onOpen }: { onOpen: (kind: Kind, id: string) => void }) {
  const [entries, setEntries] = useState<RecentEntry[]>(() => readLocalRecent());

  useEffect(() => {
    const refresh = () => setEntries(readLocalRecent());
    window.addEventListener('bcl-admin-recent-changed', refresh);
    return () => window.removeEventListener('bcl-admin-recent-changed', refresh);
  }, []);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const res = await adminFetch<ServerRecent>('/recently-viewed');
      if (cancelled || !res.ok) return;
      const merged: RecentEntry[] = res.data.recent.map((r) => ({
        kind: r.entity_kind,
        id: r.entity_id,
        label: r.entity_label,
        ts: Date.parse(r.last_viewed_at) || 0,
      }));
      // Prefer server entries (cross-device) but keep any local-only ones below.
      const seen = new Set(merged.map((m) => `${m.kind}:${m.id}`));
      const local = readLocalRecent().filter((l) => !seen.has(`${l.kind}:${l.id}`));
      setEntries([...merged, ...local].slice(0, 20));
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (entries.length === 0) return null;

  return (
    <aside
      aria-label="Recently viewed"
      className="sticky bottom-0 left-0 right-0 mt-6 -mx-4 sm:-mx-6 border-t border-brand-cyan/20 bg-bg-primary/95 backdrop-blur px-4 py-2"
    >
      <div className="flex items-center gap-2 overflow-x-auto">
        <span className="text-xs uppercase tracking-wider text-brand-mute shrink-0">Recent:</span>
        {entries.slice(0, 12).map((e) => (
          <button
            key={`${e.kind}:${e.id}`}
            type="button"
            onClick={() => onOpen(e.kind as Kind, e.id)}
            className="shrink-0 rounded border border-brand-cyan/20 bg-white/5 px-2 py-1 text-xs text-white hover:bg-brand-cyan/10 hover:border-brand-cyan/40"
            title={`${e.kind} · ${formatRelative(new Date(e.ts).toISOString())}`}
          >
            <span className="mr-1 text-brand-cyan/70">{kindGlyph(e.kind)}</span>
            {truncate(e.label || e.id, 28)}
          </button>
        ))}
      </div>
    </aside>
  );
}

function kindGlyph(kind: string): string {
  if (kind === 'job') return '▣';
  if (kind === 'customer') return '◉';
  if (kind === 'worker') return '◆';
  return '·';
}

function truncate(s: string, n: number): string {
  return s.length <= n ? s : s.slice(0, n - 1) + '…';
}

export default RecentlyViewed;
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
