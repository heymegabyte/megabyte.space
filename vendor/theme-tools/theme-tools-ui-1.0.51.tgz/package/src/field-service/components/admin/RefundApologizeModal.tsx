import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useCallback, useState } from 'react';
import { formatCents, getAdminToken } from '@theme.tools/crm/field-service/admin-api';

/**
 * Wave 21C — One-click refund + apologize modal.
 *
 * Operator picks a refund amount (preset $25/$50/full, or custom), pastes the
 * reason, fires. Backend:
 *   1. Square Refunds API (idempotent on payment_id + amount).
 *   2. Resend email to customer w/ apology.
 *   3. Twilio SMS to customer w/ apology.
 *   4. audit_logs + admin_events.
 */

const PRESETS = [
  { label: '$25', cents: 2500 },
  { label: '$50', cents: 5000 },
  { label: '$100', cents: 10_000 },
];

export function RefundApologizeModal({
  bookingId,
  customerName,
  totalCents,
  onClose,
  onSuccess,
}: {
  bookingId: string;
  customerName: string;
  totalCents: number;
  onClose: () => void;
  onSuccess: () => void;
}) {
  const [amountCents, setAmountCents] = useState<number>(2500);
  const [customDollars, setCustomDollars] = useState<string>('');
  const [reason, setReason] = useState('');
  const [skipNotify, setSkipNotify] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<{
    ok: boolean;
    refundId?: string | null;
    emailSent?: boolean;
    smsSent?: boolean;
    error?: string;
  } | null>(null);

  const setCustom = (val: string) => {
    setCustomDollars(val);
    const n = Math.round(Number(val) * 100);
    if (Number.isFinite(n) && n > 0) setAmountCents(n);
  };

  const submit = useCallback(async () => {
    setSubmitting(true);
    setResult(null);
    const token = getAdminToken();
    try {
      const res = await fetch('/api/admin/refund-and-apologize', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          ...(token ? { authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          bookingId,
          amountCents,
          reason: reason.trim(),
          skipNotify,
        }),
      });
      const data = (await res.json()) as {
        ok: boolean;
        refundId?: string | null;
        emailSent?: boolean;
        smsSent?: boolean;
        error?: string;
      };
      setResult(data);
      if (data.ok) {
        // Brief success display, then close.
        window.setTimeout(() => {
          onSuccess();
        }, 1400);
      }
    } catch (e) {
      setResult({ ok: false, error: (e as Error).message });
    } finally {
      setSubmitting(false);
    }
  }, [bookingId, amountCents, reason, skipNotify, onSuccess]);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="refund-apologize-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-lg rounded-2xl border border-red-500/30 bg-bg-primary p-6 shadow-2xl">
        <header className="mb-3 flex items-center justify-between">
          <h3 id="refund-apologize-title" className="text-lg font-bold text-red-200">
            Refund + apologize
          </h3>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="inline-flex min-h-[24px] min-w-[24px] items-center justify-center rounded border border-white/10 px-2 py-0.5 text-xs leading-none text-brand-mute transition-colors hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
          >
            ✕
          </button>
        </header>
        <p className="text-brand-mute mb-4 text-sm">
          Refund {customerName} from booking #{bookingId.slice(0, 8)} (total{' '}
          {formatCents(totalCents)}) and send a templated apology by email + SMS.
        </p>

        <label className="block text-xs uppercase tracking-wide text-brand-mute">
          Refund amount
        </label>
        <div className="mt-1 flex flex-wrap gap-2">
          {PRESETS.map((p) => (
            <button
              key={p.label}
              type="button"
              onClick={() => {
                setAmountCents(p.cents);
                setCustomDollars('');
              }}
              className={`rounded border px-3 py-1.5 text-sm transition ${
                amountCents === p.cents && !customDollars
                  ? 'border-red-400 bg-red-950/30 text-red-100'
                  : 'border-white/10 text-brand-mute hover:text-white'
              }`}
            >
              {p.label}
            </button>
          ))}
          <button
            type="button"
            onClick={() => {
              setAmountCents(totalCents);
              setCustomDollars('');
            }}
            className={`rounded border px-3 py-1.5 text-sm transition ${
              amountCents === totalCents && !customDollars
                ? 'border-red-400 bg-red-950/30 text-red-100'
                : 'border-white/10 text-brand-mute hover:text-white'
            }`}
          >
            Full ({formatCents(totalCents)})
          </button>
          <div className="flex items-center gap-1">
            <span className="text-brand-mute text-sm">$</span>
            <input
              type="number"
              min={1}
              step="0.01"
              value={customDollars}
              onChange={(e) => setCustom(e.target.value)}
              placeholder="custom"
              className="w-24 rounded border border-brand-cyan/30 bg-black/60 px-2 py-1 text-sm text-white"
            />
          </div>
        </div>

        <label className="mt-4 block text-xs uppercase tracking-wide text-brand-mute">
          Reason (audited)
        </label>
        <textarea
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          rows={3}
          placeholder="Late arrival, scope mismatch, broken item, etc."
          className="mt-1 w-full rounded border border-brand-cyan/30 bg-black/60 px-3 py-1.5 text-sm text-white"
        />

        <label className="mt-3 flex items-center gap-2 text-sm text-white">
          <input
            type="checkbox"
            checked={skipNotify}
            onChange={(e) => setSkipNotify(e.target.checked)}
          />
          Skip customer email + SMS (refund silently)
        </label>

        {result && (
          <div
            className={`mt-3 rounded border p-3 text-sm ${
              result.ok
                ? 'border-emerald-500/40 bg-emerald-950/20 text-emerald-200'
                : 'border-red-500/40 bg-red-950/30 text-red-200'
            }`}
            role="status"
          >
            {result.ok ? (
              <>
                Refunded — Square id {String(result.refundId).slice(0, 14)}…
                <br />
                {!skipNotify && (
                  <span className="text-xs opacity-80">
                    Email {result.emailSent ? '✓ sent' : '✗ skipped/failed'} · SMS{' '}
                    {result.smsSent ? '✓ sent' : '✗ skipped/failed'}
                  </span>
                )}
              </>
            ) : (
              <>Refund failed: {result.error}</>
            )}
          </div>
        )}

        <footer className="mt-5 flex justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="rounded border border-white/10 px-3 py-1.5 text-sm text-brand-mute hover:text-white"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => void submit()}
            disabled={amountCents <= 0 || reason.trim().length < 3 || submitting || result?.ok}
            className="rounded bg-red-500 px-3 py-1.5 text-sm font-semibold text-white hover:bg-red-400 disabled:opacity-40"
            data-testid="refund-confirm"
          >
            {submitting
              ? 'Refunding…'
              : result?.ok
                ? 'Done'
                : `Refund ${formatCents(amountCents)} + apologize`}
          </button>
        </footer>
      </div>
    </div>
  );
}

export default RefundApologizeModal;
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
