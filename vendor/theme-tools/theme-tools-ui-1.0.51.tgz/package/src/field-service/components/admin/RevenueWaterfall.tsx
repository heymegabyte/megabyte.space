import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useEffect, useState } from 'react';

interface WaterfallStep {
  step: string;
  count: number;
  valueCents: number;
}

interface ApiResponse {
  ok: true;
  range: string;
  steps: WaterfallStep[];
}

const STEP_LABELS: Record<string, string> = {
  visits_with_quote: 'Quoted',
  paid_deposit: 'Paid deposit',
  dispatched: 'Dispatched',
  completed: 'Completed',
  review_received: 'Reviewed',
};

export function RevenueWaterfall({ headers }: { headers: HeadersInit }) {
  useThemeToolsSurface('revenue-waterfall');
  const [range, setRange] = useState<'7d' | '30d' | '90d'>('30d');
  const [data, setData] = useState<ApiResponse | null>(null);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    let cancelled = false;
    setData(null);
    fetch(`/api/admin/revenue/waterfall?range=${range}`, { headers })
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error(`status_${r.status}`))))
      .then((json: ApiResponse) => {
        if (!cancelled) setData(json);
      })
      .catch((err: Error) => {
        if (!cancelled) setError(err.message);
      });
    return () => {
      cancelled = true;
    };
  }, [headers, range]);

  const max = data ? Math.max(1, ...data.steps.map((s) => s.count)) : 1;

  return (
    <div className="space-y-4" data-testid="revenue-waterfall">
      <div className="flex items-center gap-2">
        {(['7d', '30d', '90d'] as const).map((r) => (
          <button
            key={r}
            type="button"
            onClick={() => setRange(r)}
            className={[
              'rounded px-2.5 py-1 text-xs uppercase',
              range === r ? 'bg-white/20 font-semibold' : 'bg-white/5 hover:bg-white/10',
            ].join(' ')}
          >
            {r}
          </button>
        ))}
      </div>
      {error && <p className="text-sm text-red-300">{error}</p>}
      {!data && !error && <p className="text-brand-mute text-sm">Loading…</p>}
      {data && (
        <ul className="space-y-2">
          {data.steps.map((s, i) => {
            const pct = (s.count / max) * 100;
            const prev = data.steps[i - 1];
            const dropoff =
              prev && prev.count > 0 ? Math.round((1 - s.count / prev.count) * 100) : null;
            return (
              <li key={s.step}>
                <div className="mb-1 flex items-center justify-between text-xs">
                  <span className="font-semibold">{STEP_LABELS[s.step] ?? s.step}</span>
                  <span className="text-brand-mute tabular-nums">
                    {s.count.toLocaleString()}{' '}
                    {s.valueCents > 0 && <>· ${(s.valueCents / 100).toLocaleString()}</>}
                    {dropoff != null && dropoff > 0 && (
                      <span className="ml-1 text-amber-300">−{dropoff}%</span>
                    )}
                  </span>
                </div>
                <div className="h-3 rounded bg-white/5">
                  <div
                    className="h-full rounded bg-cyan-400/70"
                    style={{ width: `${Math.max(2, pct)}%` }}
                  />
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
