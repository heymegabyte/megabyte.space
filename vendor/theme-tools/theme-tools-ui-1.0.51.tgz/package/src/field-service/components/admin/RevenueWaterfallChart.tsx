import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useMemo, useState } from 'react';

/**
 * RevenueWaterfallChart — animated 7-day revenue bar chart.
 *
 * Aggregates the last 7 days of revenue from the admin dashboard feed and
 * renders a vertical bar per day with proportional height + dollar label.
 * Bars animate in via the shared `[data-enter]` + `@starting-style` pattern
 * (see `src/web/styles/index.css`).
 *
 * Below the chart: an "AI Explain" button POSTs the series to
 * `/api/ai/explain-chart` and renders the returned insight inline.
 *
 * Data source: `/api/dashboard/feed` (admin firehose contains `booking`
 * events with `$NNN` totals embedded in the title). Falls back to an empty
 * state when no paid bookings landed in the window.
 *
 * NOTE — the legacy `RevenueWaterfall.tsx` is a funnel-style chart still
 * mounted by SuperAdminDashboard. This is the new daily-bar chart variant.
 */

interface FeedEvent {
  id: string;
  kind: string;
  title: string;
  subtitle: string;
  at: string;
  severity: string;
}

interface DayPoint {
  label: string; // e.g. "Mon 5/19"
  iso: string; // YYYY-MM-DD
  revenue: number;
  count: number;
}

interface Highlight {
  label: string;
  value: number;
  reason: string;
}

function dayLabel(d: Date): string {
  const wk = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][d.getDay()] ?? '';
  return `${wk} ${d.getMonth() + 1}/${d.getDate()}`;
}

function isoDay(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
    d.getDate(),
  ).padStart(2, '0')}`;
}

/** Parse `$1,234` or `$45` out of a feed-event title — returns 0 on miss. */
function parseDollars(title: string): number {
  const m = title.match(/\$([\d,]+(?:\.\d+)?)/);
  if (!m) return 0;
  return Number(m[1]!.replace(/,/g, '')) || 0;
}

export function RevenueWaterfallChart({ bearer }: { bearer: string }) {
  useThemeToolsSurface('revenue-waterfall-chart');
  const [days, setDays] = useState<DayPoint[]>([]);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState('');
  const [insight, setInsight] = useState<string>('');
  const [highlight, setHighlight] = useState<Highlight | null>(null);
  const [explaining, setExplaining] = useState(false);

  const headers = useCallback(
    (): HeadersInit => ({
      'content-type': 'application/json',
      authorization: `Bearer ${bearer}`,
    }),
    [bearer],
  );

  const load = useCallback(async () => {
    if (!bearer) return;
    setLoading(true);
    setStatus('');
    setInsight('');
    setHighlight(null);
    try {
      const res = await fetch('/api/dashboard/feed', { headers: headers() });
      const json = (await res.json()) as { ok: boolean; events?: FeedEvent[]; error?: string };
      if (!res.ok || !json.ok) {
        setStatus(json.error ?? `HTTP ${res.status}`);
        setLoading(false);
        return;
      }
      // Build 7 days, today at the right.
      const buckets = new Map<string, DayPoint>();
      const now = new Date();
      for (let i = 6; i >= 0; i--) {
        const d = new Date(now);
        d.setDate(d.getDate() - i);
        d.setHours(0, 0, 0, 0);
        const iso = isoDay(d);
        buckets.set(iso, { label: dayLabel(d), iso, revenue: 0, count: 0 });
      }
      for (const ev of json.events ?? []) {
        if (ev.kind !== 'booking') continue;
        const t = new Date(ev.at);
        if (Number.isNaN(t.getTime())) continue;
        t.setHours(0, 0, 0, 0);
        const iso = isoDay(t);
        const bucket = buckets.get(iso);
        if (!bucket) continue;
        bucket.revenue += parseDollars(ev.title);
        bucket.count += 1;
      }
      setDays(Array.from(buckets.values()));
    } catch (err) {
      setStatus((err as Error).message);
    } finally {
      setLoading(false);
    }
  }, [bearer, headers]);

  useEffect(() => {
    void load();
  }, [load]);

  const maxRev = useMemo(() => Math.max(1, ...days.map((d) => d.revenue)), [days]);
  const totalRev = useMemo(() => days.reduce((s, d) => s + d.revenue, 0), [days]);
  const hasData = totalRev > 0;

  async function explain() {
    if (!hasData) return;
    setExplaining(true);
    setStatus('');
    try {
      const res = await fetch('/api/ai/explain-chart', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          chartTitle: '7-day revenue',
          dataPoints: days.map((d) => ({ label: d.label, value: d.revenue })),
        }),
      });
      const json = (await res.json()) as {
        ok: boolean;
        insight?: string;
        highlight?: Highlight | null;
        error?: string;
      };
      if (!res.ok || !json.ok) {
        setStatus(json.error ?? `AI HTTP ${res.status}`);
      } else {
        setInsight(json.insight ?? '');
        setHighlight(json.highlight ?? null);
      }
    } catch (err) {
      setStatus((err as Error).message);
    } finally {
      setExplaining(false);
    }
  }

  if (!bearer) {
    return (
      <section className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
        <h2 className="text-xl font-bold text-brand-ink">Revenue waterfall</h2>
        <p className="mt-2 text-sm text-brand-mute">
          Add the owner key above to load 7-day revenue.
        </p>
      </section>
    );
  }

  return (
    <section className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-brand-ink">Revenue waterfall</h2>
          <p className="mt-1 text-sm text-brand-mute">
            Last 7 days · ${totalRev.toLocaleString()} total
          </p>
        </div>
        <button
          type="button"
          onClick={() => void load()}
          disabled={loading}
          className="rounded-md border border-brand-line bg-bg-primary px-3 py-1.5 text-xs text-brand-ink hover:border-brand-accent disabled:opacity-50"
        >
          {loading ? 'Loading…' : 'Refresh'}
        </button>
      </div>

      {status && <p className="mt-3 text-xs text-red-400">{status}</p>}

      {!hasData && !loading ? (
        <p className="mt-4 rounded-md border border-dashed border-brand-line p-6 text-center text-sm text-brand-mute">
          Last week was quiet. Try the AI quote optimizer to see what bumped the curve →
        </p>
      ) : (
        <div
          className="mt-5 flex h-56 items-end justify-between gap-2"
          role="img"
          aria-label={`7-day revenue chart, total $${totalRev.toLocaleString()}`}
        >
          {days.map((d, idx) => {
            const pct = Math.max(2, Math.round((d.revenue / maxRev) * 100));
            return (
              <div
                key={d.iso}
                className="flex h-full flex-1 flex-col items-center justify-end gap-1"
              >
                <span className="font-mono text-[10px] text-brand-ink">
                  ${d.revenue.toLocaleString()}
                </span>
                <div
                  data-enter
                  style={{
                    height: `${pct}%`,
                    transitionDelay: `${idx * 70}ms`,
                  }}
                  className="w-full rounded-t-md bg-brand-accent/80 ring-1 ring-brand-accent"
                  title={`${d.label}: $${d.revenue.toLocaleString()} (${d.count} booking${
                    d.count === 1 ? '' : 's'
                  })`}
                />
                <span className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
                  {d.label}
                </span>
              </div>
            );
          })}
        </div>
      )}

      <div className="mt-5 flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={() => void explain()}
          disabled={!hasData || explaining}
          className="rounded-md bg-brand-accent px-3 py-2 text-sm font-semibold text-black hover:brightness-110 disabled:opacity-50"
        >
          {explaining ? 'Asking AI…' : 'AI Explain'}
        </button>
        {insight && <p className="flex-1 min-w-[200px] text-sm text-brand-ink">{insight}</p>}
      </div>
      {highlight && (
        <div className="mt-3 rounded-md border border-brand-accent/40 bg-brand-accent/10 p-3 text-sm">
          <p className="font-mono text-[10px] uppercase tracking-widest text-brand-accent">
            Highlight
          </p>
          <p className="mt-1 text-brand-ink">
            <span className="font-semibold">{highlight.label}</span> · $
            {highlight.value.toLocaleString()}
          </p>
          <p className="mt-1 text-brand-mute">{highlight.reason}</p>
        </div>
      )}
    </section>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
