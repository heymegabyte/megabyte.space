import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useCallback, useState } from 'react';

/**
 * ReviewResponseQueue — admin surface to paste a customer review, get an
 * AI-drafted reply from /api/admin/marketing/generate/review_response, edit
 * in place, and copy-publish to Google / BBB / Yelp.
 *
 * "Queue" in the UX sense: each pasted review becomes a row; the row carries
 * its draft + final + posted_at locally until the admin clicks Mark posted.
 * Posting to the third-party platform itself is manual (no Google reviews
 * API for SMB tier) — the row stays in the queue with the polished draft so
 * the admin can paste it into the platform's reply box.
 */

interface QueueRow {
  id: string;
  platform: 'google' | 'bbb' | 'yelp' | 'facebook' | 'other';
  rating: number;
  customerName: string;
  reviewText: string;
  draft: string;
  posted: boolean;
}

interface Props {
  readonly token: string;
}

export function ReviewResponseQueue({ token }: Props): JSX.Element {
  useThemeToolsSurface('review-response-queue');
  const [rows, setRows] = useState<QueueRow[]>([]);
  const [busy, setBusy] = useState(false);
  const [draftInput, setDraftInput] = useState<QueueRow>({
    id: '',
    platform: 'google',
    rating: 5,
    customerName: '',
    reviewText: '',
    draft: '',
    posted: false,
  });

  const generateReply = useCallback(async () => {
    if (!draftInput.reviewText || draftInput.reviewText.length < 5) return;
    setBusy(true);
    try {
      const res = await fetch('/api/admin/marketing/generate/review_response', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          reviewText: draftInput.reviewText,
          rating: draftInput.rating,
          customerName: draftInput.customerName || undefined,
          platform: draftInput.platform,
        }),
      });
      const data = (await res.json()) as { ok: boolean; runId?: string; contentPreview?: string };
      if (data.ok && data.runId) {
        const row: QueueRow = {
          ...draftInput,
          id: data.runId,
          draft: data.contentPreview ?? '',
        };
        setRows((prev) => [row, ...prev]);
        setDraftInput({
          id: '',
          platform: draftInput.platform,
          rating: 5,
          customerName: '',
          reviewText: '',
          draft: '',
          posted: false,
        });
      }
    } finally {
      setBusy(false);
    }
  }, [token, draftInput]);

  const updateDraft = useCallback((id: string, draft: string) => {
    setRows((prev) => prev.map((r) => (r.id === id ? { ...r, draft } : r)));
  }, []);

  const markPosted = useCallback((id: string) => {
    setRows((prev) => prev.map((r) => (r.id === id ? { ...r, posted: true } : r)));
  }, []);

  const copy = useCallback(async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      /* clipboard may be denied */
    }
  }, []);

  return (
    <section className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-sm">
      <h2 className="text-xl font-semibold">Review Response Queue</h2>
      <p className="mt-1 text-sm text-neutral-600">
        Paste a review, get a drafted reply, edit, then copy-paste into the platform.
      </p>

      <div className="mt-4 rounded-lg border border-neutral-200 p-3">
        <div className="grid grid-cols-1 gap-2 md:grid-cols-3">
          <select
            value={draftInput.platform}
            onChange={(e) =>
              setDraftInput({ ...draftInput, platform: e.target.value as QueueRow['platform'] })
            }
            className="rounded-md border border-neutral-300 px-2 py-1 text-sm"
          >
            <option value="google">Google</option>
            <option value="bbb">BBB</option>
            <option value="yelp">Yelp</option>
            <option value="facebook">Facebook</option>
            <option value="other">Other</option>
          </select>
          <select
            value={draftInput.rating}
            onChange={(e) => setDraftInput({ ...draftInput, rating: Number(e.target.value) })}
            className="rounded-md border border-neutral-300 px-2 py-1 text-sm"
          >
            {[1, 2, 3, 4, 5].map((n) => (
              <option key={n} value={n}>
                {n} star{n === 1 ? '' : 's'}
              </option>
            ))}
          </select>
          <input
            placeholder="Customer name (optional)"
            value={draftInput.customerName}
            onChange={(e) => setDraftInput({ ...draftInput, customerName: e.target.value })}
            className="rounded-md border border-neutral-300 px-2 py-1 text-sm"
          />
        </div>
        <textarea
          rows={4}
          placeholder="Paste the review text…"
          value={draftInput.reviewText}
          onChange={(e) => setDraftInput({ ...draftInput, reviewText: e.target.value })}
          className="mt-2 block w-full rounded-md border border-neutral-300 px-2 py-1 text-sm"
        />
        <button
          type="button"
          onClick={generateReply}
          disabled={busy || draftInput.reviewText.length < 5}
          className="mt-2 rounded-md bg-neutral-900 px-3 py-1 text-sm text-white disabled:opacity-50"
        >
          {busy ? 'Drafting…' : 'Draft reply'}
        </button>
      </div>

      <ul className="mt-4 space-y-3">
        {rows.length === 0 ? <li className="text-sm text-neutral-500">Queue empty.</li> : null}
        {rows.map((r) => (
          <li key={r.id} className="rounded-md border border-neutral-200 p-3 text-sm">
            <div className="text-xs text-neutral-500">
              {r.platform} · {r.rating}★ · {r.customerName || 'anonymous'}
              {r.posted ? <span className="ml-2 text-emerald-700">posted</span> : null}
            </div>
            <div className="mt-1 text-neutral-700">&ldquo;{r.reviewText}&rdquo;</div>
            <textarea
              rows={3}
              value={r.draft}
              onChange={(e) => updateDraft(r.id, e.target.value)}
              className="mt-2 block w-full rounded-md border border-neutral-300 px-2 py-1 text-xs"
            />
            <div className="mt-2 flex gap-2">
              <button
                type="button"
                onClick={() => copy(r.draft)}
                className="rounded-md border border-neutral-300 px-3 py-1 text-xs"
              >
                Copy
              </button>
              <button
                type="button"
                onClick={() => markPosted(r.id)}
                disabled={r.posted}
                className="rounded-md bg-neutral-900 px-3 py-1 text-xs text-white disabled:opacity-50"
              >
                Mark posted
              </button>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
