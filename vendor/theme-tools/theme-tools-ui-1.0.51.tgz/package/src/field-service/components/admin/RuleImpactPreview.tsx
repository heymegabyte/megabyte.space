import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useCallback, useState } from 'react';

/**
 * RuleImpactPreview — admin dry-run match against the live rules engine.
 *
 * Given a list of worker IDs + a synthetic job, fire `POST /api/admin/rules/test`
 * and render the ranked candidates with their base score, AI score, final
 * blended score, hard-block flag, and the rules that fired. Lets an admin
 * answer "if I add this rule, who's still in?" before committing.
 */

interface JobInput {
  bookingId?: string;
  customerPhone?: string;
  customerName?: string;
  address?: string;
  city?: string;
  zip?: string;
  servicesCsv?: string;
  preferredDate?: string;
  preferredTime?: string;
  hours?: number;
  crew?: number;
  notes?: string;
  indoor?: boolean;
}

interface Ranked {
  workerId: string;
  firstName: string | null;
  tier: string;
  baseScore: number;
  aiScore: number;
  finalScore: number;
  hardBlocked: boolean;
  appliedRuleIds: string[];
  reasoning: string;
}

interface RuleSnapshot {
  id: string;
  scope: string;
  kind: string;
  priority: number;
  text: string;
}

interface ApiTest {
  ok: boolean;
  ranked?: Ranked[];
  rules?: Record<string, RuleSnapshot[]>;
  error?: string;
}

interface RuleImpactPreviewProps {
  adminToken: string;
  workerIds: string[];
  job: JobInput;
  onClose?: () => void;
}

export default function RuleImpactPreview({
  adminToken,
  workerIds,
  job,
  onClose,
}: RuleImpactPreviewProps) {
  useThemeToolsSurface('rule-impact-preview');
  const [ranked, setRanked] = useState<Ranked[] | null>(null);
  const [rules, setRules] = useState<Record<string, RuleSnapshot[]>>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const run = useCallback(async () => {
    if (workerIds.length === 0) {
      setError('Pick at least one worker to preview.');
      return;
    }
    setBusy(true);
    setError('');
    try {
      const res = await fetch('/api/admin/rules/test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify({ workerIds, job }),
      });
      const data = (await res.json()) as ApiTest;
      if (!res.ok || !data.ok) {
        setError(data.error ?? `Preview failed (${res.status}).`);
        return;
      }
      setRanked(data.ranked ?? []);
      setRules(data.rules ?? {});
    } catch {
      setError('Connection issue. Try again.');
    } finally {
      setBusy(false);
    }
  }, [adminToken, workerIds, job]);

  return (
    <section className="rounded-2xl border border-brand-line bg-brand-card p-5 space-y-4">
      <header className="flex items-start justify-between gap-3">
        <div>
          <h3 className="text-lg font-bold text-brand-ink">Rule impact preview</h3>
          <p className="text-sm text-brand-mute">
            Dry-run match against {workerIds.length} worker{workerIds.length === 1 ? '' : 's'}. Live
            rules — no dispatch is sent.
          </p>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => void run()}
            disabled={busy || workerIds.length === 0}
            className="rounded-xl bg-brand-accent px-4 py-2 text-sm font-bold text-brand-bg disabled:opacity-50"
          >
            {busy ? 'Running…' : 'Run preview'}
          </button>
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-brand-line bg-transparent px-3 py-2 text-sm text-brand-mute hover:text-brand-ink"
            >
              Close
            </button>
          )}
        </div>
      </header>

      {error && (
        <p role="alert" className="text-sm text-red-300">
          {error}
        </p>
      )}

      {ranked && (
        <ol className="space-y-3">
          {ranked.length === 0 && (
            <li className="text-sm text-brand-mute">No candidates returned.</li>
          )}
          {ranked.map((r, idx) => {
            const applied = rules[r.workerId] ?? [];
            const appliedSet = new Set(r.appliedRuleIds);
            return (
              <li
                key={r.workerId}
                className={`rounded-xl border p-3 ${
                  r.hardBlocked ? 'border-red-500/40 bg-red-500/5' : 'border-brand-line bg-brand-bg'
                }`}
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <span className="rounded-full bg-brand-accent/15 px-2 py-0.5 text-xs font-bold text-brand-accent">
                      #{idx + 1}
                    </span>
                    <span className="font-bold text-brand-ink">
                      {r.firstName ?? 'Worker'}{' '}
                      <span className="text-xs font-normal text-brand-mute">
                        ({r.workerId.slice(0, 8)} · {r.tier})
                      </span>
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-brand-mute">
                    <span>
                      base <strong className="text-brand-ink">{r.baseScore}</strong>
                    </span>
                    <span>
                      AI <strong className="text-brand-ink">{r.aiScore}</strong>
                    </span>
                    <span
                      className={`rounded-full px-2 py-0.5 font-bold ${
                        r.hardBlocked
                          ? 'bg-red-500/20 text-red-300'
                          : 'bg-brand-accent/10 text-brand-accent'
                      }`}
                    >
                      final {r.finalScore}
                    </span>
                  </div>
                </div>
                {r.reasoning && <p className="mt-2 text-xs text-brand-mute">{r.reasoning}</p>}
                {applied.length > 0 && (
                  <ul className="mt-2 space-y-1 border-t border-brand-line pt-2">
                    {applied.map((rule) => (
                      <li
                        key={rule.id}
                        className={`text-xs ${
                          appliedSet.has(rule.id) ? 'text-brand-ink' : 'text-brand-mute opacity-60'
                        }`}
                      >
                        <span className="font-bold">[{rule.kind}]</span> {rule.text}
                        <span className="opacity-50">
                          {' '}
                          — {rule.scope} · p{rule.priority}
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
              </li>
            );
          })}
        </ol>
      )}
    </section>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
