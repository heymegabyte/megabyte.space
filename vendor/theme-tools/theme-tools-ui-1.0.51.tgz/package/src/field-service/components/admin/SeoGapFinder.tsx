import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useCallback, useState } from 'react';

/**
 * SeoGapFinder — admin paste pad. Drop 1-10 competitor URLs, get an LLM-drafted
 * markdown table of topic gaps we should write about. Output is rendered as
 * monospace markdown so the admin can copy-paste into a brief.
 */

interface Props {
  readonly token: string;
}

export function SeoGapFinder({ token }: Props): JSX.Element {
  useThemeToolsSurface('seo-gap-finder');
  const [urlsText, setUrlsText] = useState(
    'https://www.taskrabbit.com\nhttps://www.bellhop.com\nhttps://www.thumbtack.com',
  );
  const [ourTopicsText, setOurTopicsText] = useState('moving, hauling, cleanouts, lawn');
  const [result, setResult] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const run = useCallback(async () => {
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      const competitorUrls = urlsText
        .split(/\n+/)
        .map((s) => s.trim())
        .filter(Boolean)
        .slice(0, 10);
      const ourTopics = ourTopicsText
        .split(/[,\n]+/)
        .map((s) => s.trim())
        .filter(Boolean)
        .slice(0, 20);
      const res = await fetch('/api/admin/marketing/generate/seo_gap', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ competitorUrls, ourTopics }),
      });
      const data = (await res.json()) as { ok: boolean; error?: string; contentPreview?: string };
      if (!data.ok) {
        setError(data.error || 'gap finder failed');
      } else {
        setResult(data.contentPreview ?? '');
      }
    } catch (err) {
      setError((err as Error).message || 'request failed');
    } finally {
      setBusy(false);
    }
  }, [token, urlsText, ourTopicsText]);

  return (
    <section className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-sm">
      <h2 className="text-xl font-semibold">SEO Gap Finder</h2>
      <p className="mt-1 text-sm text-neutral-600">
        Paste competitors. AI returns a markdown table of topic gaps + page type.
      </p>
      <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2">
        <label className="block text-sm font-medium text-neutral-700">
          Competitor URLs (one per line, max 10)
          <textarea
            rows={6}
            value={urlsText}
            onChange={(e) => setUrlsText(e.target.value)}
            className="mt-1 block w-full rounded-md border border-neutral-300 p-2 font-mono text-xs"
            spellCheck={false}
          />
        </label>
        <label className="block text-sm font-medium text-neutral-700">
          Our topics (comma-separated)
          <textarea
            rows={6}
            value={ourTopicsText}
            onChange={(e) => setOurTopicsText(e.target.value)}
            className="mt-1 block w-full rounded-md border border-neutral-300 p-2 font-mono text-xs"
            spellCheck={false}
          />
        </label>
      </div>
      <div className="mt-3 flex items-center gap-3">
        <button
          type="button"
          onClick={run}
          disabled={busy}
          className="rounded-md bg-neutral-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
        >
          {busy ? 'Finding gaps…' : 'Find gaps'}
        </button>
        {error ? <span className="text-sm text-red-700">{error}</span> : null}
      </div>
      {result ? (
        <pre className="mt-3 max-h-80 overflow-auto rounded-md bg-neutral-50 p-3 text-xs">
          {result}
        </pre>
      ) : null}
    </section>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
