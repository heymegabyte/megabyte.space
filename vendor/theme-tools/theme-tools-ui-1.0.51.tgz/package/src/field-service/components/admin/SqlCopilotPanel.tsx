import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useEffect, useState } from 'react';

/**
 * AI SQL copilot — NL → SAFE SELECT → confirm-hash → run → table view.
 * Super-admin only. Read-only enforcement on both client + server.
 */

interface Table {
  name: string;
  rowCount: number;
  columns: string[];
}

interface Draft {
  sql: string;
  explanation: string;
  estimatedRowCount: number | null;
  warnings: string[];
  confirmHash: string;
}

interface RunResult {
  columns: string[];
  rows: unknown[][];
  rowCount: number;
  truncated: boolean;
  executionMs: number;
}

interface HistoryRow {
  id: string;
  executedAt: string;
  sql: string;
  rowCount: number;
  executionMs: number;
}

async function sha256Hex12(s: string): Promise<string> {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s));
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')
    .slice(0, 12);
}

function highlight(sql: string): React.ReactNode[] {
  const keywords =
    /\b(SELECT|FROM|WHERE|JOIN|GROUP BY|ORDER BY|LIMIT|AND|OR|AS|ON|HAVING|UNION|INNER|LEFT|RIGHT|OUTER|DESC|ASC|COUNT|SUM|AVG|MIN|MAX|DISTINCT|CASE|WHEN|THEN|ELSE|END|NULL|NOT|IN|LIKE|BETWEEN|IS)\b/gi;
  const parts: React.ReactNode[] = [];
  let i = 0;
  let m: RegExpExecArray | null;
  while ((m = keywords.exec(sql)) !== null) {
    if (m.index > i) parts.push(sql.slice(i, m.index));
    parts.push(
      <span key={m.index} className="text-brand-accent">
        {m[0]}
      </span>,
    );
    i = m.index + m[0].length;
  }
  if (i < sql.length) parts.push(sql.slice(i));
  return parts;
}

export function SqlCopilotPanel({ bearer }: { bearer: string }) {
  useThemeToolsSurface('sql-copilot-panel');
  const [tables, setTables] = useState<Table[]>([]);
  const [query, setQuery] = useState('');
  const [draft, setDraft] = useState<Draft | null>(null);
  const [result, setResult] = useState<RunResult | null>(null);
  const [history, setHistory] = useState<HistoryRow[]>([]);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState<'idle' | 'drafting' | 'running'>('idle');

  useEffect(() => {
    if (!bearer) return;
    void (async () => {
      try {
        const [t, h] = await Promise.all([
          fetch('/api/super-admin/sql-copilot/schema/tables', {
            headers: { authorization: `Bearer ${bearer}` },
          }).then((r) => r.json()) as Promise<{ ok: boolean; tables?: Table[] }>,
          fetch('/api/super-admin/sql-copilot/history', {
            headers: { authorization: `Bearer ${bearer}` },
          }).then((r) => r.json()) as Promise<{ ok: boolean; history?: HistoryRow[] }>,
        ]);
        if (t.ok && t.tables) setTables(t.tables);
        if (h.ok && h.history) setHistory(h.history);
      } catch (err) {
        setError((err as Error).message);
      }
    })();
  }, [bearer]);

  async function draftSql() {
    if (!query.trim()) return;
    setBusy('drafting');
    setError('');
    setDraft(null);
    setResult(null);
    try {
      const res = await fetch('/api/super-admin/sql-copilot/draft', {
        method: 'POST',
        headers: { authorization: `Bearer ${bearer}`, 'content-type': 'application/json' },
        body: JSON.stringify({ query }),
      });
      const json = (await res.json()) as { ok: boolean; error?: string } & Partial<Draft>;
      if (!json.ok) {
        setError(json.error ?? `HTTP ${res.status}`);
      } else if (json.sql && json.confirmHash) {
        setDraft({
          sql: json.sql,
          explanation: json.explanation ?? '',
          estimatedRowCount: json.estimatedRowCount ?? null,
          warnings: json.warnings ?? [],
          confirmHash: json.confirmHash,
        });
      }
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy('idle');
    }
  }

  async function runSql() {
    if (!draft) return;
    setBusy('running');
    setError('');
    setResult(null);
    try {
      // Recompute hash client-side; server re-checks.
      const confirmHash = await sha256Hex12(draft.sql);
      const res = await fetch('/api/super-admin/sql-copilot/run', {
        method: 'POST',
        headers: { authorization: `Bearer ${bearer}`, 'content-type': 'application/json' },
        body: JSON.stringify({ sql: draft.sql, confirmHash }),
      });
      const json = (await res.json()) as { ok: boolean; error?: string } & Partial<RunResult>;
      if (!json.ok) setError(json.error ?? `HTTP ${res.status}`);
      else if (json.columns) {
        setResult({
          columns: json.columns,
          rows: json.rows ?? [],
          rowCount: json.rowCount ?? 0,
          truncated: json.truncated ?? false,
          executionMs: json.executionMs ?? 0,
        });
      }
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy('idle');
    }
  }

  if (!bearer)
    return (
      <p className="text-sm text-brand-mute">
        Add SUPER_ADMIN_TOKEN in Settings to use SQL copilot.
      </p>
    );

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-[200px_1fr_240px]">
      {/* Schema browser */}
      <aside className="rounded-2xl border border-brand-line bg-bg-elevated p-3 lg:max-h-[600px] lg:overflow-y-auto">
        <p className="mb-2 font-mono text-[10px] uppercase tracking-widest text-brand-accent">
          Schema · {tables.length} tables
        </p>
        <ul className="space-y-1">
          {tables.map((t) => (
            <li key={t.name}>
              <details className="rounded border border-brand-line bg-bg-primary px-2 py-1">
                <summary className="cursor-pointer text-xs text-brand-ink">
                  <span className="font-mono">{t.name}</span>
                  <span className="ml-1 text-brand-mute">({t.rowCount})</span>
                </summary>
                <ul className="mt-1 space-y-0.5 pl-3 text-[10px] text-brand-mute">
                  {t.columns.map((c) => (
                    <li key={c}>{c}</li>
                  ))}
                </ul>
              </details>
            </li>
          ))}
        </ul>
      </aside>

      {/* Editor + result */}
      <section className="rounded-2xl border border-brand-line bg-bg-elevated p-5 space-y-3">
        <label className="block text-sm">
          <span className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
            Ask in plain English
          </span>
          <textarea
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            rows={2}
            placeholder="e.g. how many bookings in Newark last month over $400?"
            className="mt-1 w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink"
          />
        </label>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => void draftSql()}
            disabled={busy !== 'idle' || !query.trim()}
            className="rounded-md bg-brand-accent px-3 py-2 text-sm font-semibold text-black hover:brightness-110 disabled:opacity-50"
          >
            {busy === 'drafting' ? 'Drafting…' : 'Draft SQL'}
          </button>
          {draft && (
            <button
              type="button"
              onClick={() => void runSql()}
              disabled={busy !== 'idle'}
              className="rounded-md border border-brand-accent bg-brand-accent/10 px-3 py-2 text-sm font-semibold text-brand-accent hover:bg-brand-accent/20 disabled:opacity-50"
            >
              {busy === 'running' ? 'Running…' : 'Run query (read-only)'}
            </button>
          )}
        </div>
        {error && <p className="text-sm text-red-400">{error}</p>}
        {draft && (
          <div className="rounded-lg border border-brand-line bg-bg-primary p-3">
            <p className="mb-1 text-xs text-brand-mute">{draft.explanation}</p>
            {draft.warnings.length > 0 && (
              <ul
                aria-label="SQL warnings"
                className="mb-2 flex flex-wrap gap-1"
                style={{ listStyle: 'none', margin: 0, padding: 0 }}
              >
                {draft.warnings.map((w, i) => (
                  <li
                    key={w}
                    style={{ animationDelay: `${i * 50}ms` }}
                    className="inline-flex animate-[pill-enter_0.35s_ease_both] motion-reduce:animate-none items-center rounded-full border border-amber-400/40 bg-amber-400/10 px-2 py-0.5 text-[11px] font-medium text-amber-400 transition-all duration-[333ms] hover:-translate-y-0.5 hover:bg-amber-400/20 hover:shadow-sm"
                  >
                    <span aria-hidden="true" className="mr-1">⚠</span>{w}
                  </li>
                ))}
              </ul>
            )}
            <pre className="whitespace-pre-wrap font-mono text-xs text-brand-ink">
              {highlight(draft.sql)}
            </pre>
          </div>
        )}
        {result && (
          <div className="rounded-lg border border-brand-line bg-bg-primary p-3">
            <p className="mb-2 text-xs text-brand-mute">
              {result.rowCount} rows · {result.executionMs}ms
              {result.truncated ? ' · truncated at 200' : ''}
            </p>
            <div className="overflow-auto">
              <table className="min-w-full text-xs">
                <thead>
                  <tr>
                    {result.columns.map((c) => (
                      <th
                        key={c}
                        className="border-b border-brand-line px-2 py-1 text-left font-mono text-[10px] text-brand-mute"
                      >
                        {c}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {result.rows.map((row, idx) => (
                    <tr key={idx}>
                      {row.map((cell, j) => (
                        <td
                          key={j}
                          className="border-b border-brand-line/40 px-2 py-1 text-brand-ink"
                        >
                          {cell == null ? (
                            <span className="text-brand-mute">null</span>
                          ) : (
                            String(cell).slice(0, 200)
                          )}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </section>

      {/* History */}
      <aside className="rounded-2xl border border-brand-line bg-bg-elevated p-3 lg:max-h-[600px] lg:overflow-y-auto">
        <p className="mb-2 font-mono text-[10px] uppercase tracking-widest text-brand-accent">
          History · last {history.length}
        </p>
        {history.length === 0 && <p className="text-xs text-brand-mute">No prior queries.</p>}
        <ul className="space-y-1">
          {history.map((h) => (
            <li key={h.id} className="rounded border border-brand-line bg-bg-primary p-2">
              <p className="font-mono text-[10px] text-brand-mute">
                {new Date(h.executedAt).toLocaleString()} · {h.rowCount} rows · {h.executionMs}ms
              </p>
              <button
                type="button"
                onClick={() => {
                  setQuery('');
                  setDraft({
                    sql: h.sql,
                    explanation: '(loaded from history)',
                    estimatedRowCount: null,
                    warnings: [],
                    confirmHash: '',
                  });
                }}
                className="mt-1 text-left font-mono text-[10px] text-brand-ink hover:text-brand-accent"
              >
                {h.sql.slice(0, 80)}
                {h.sql.length > 80 ? '…' : ''}
              </button>
            </li>
          ))}
        </ul>
      </aside>
    </div>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
