import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useRovingTabs } from '../../use-roving-radio.js';
import { KpiStrip } from './KpiStrip.js';
import { LiveFeed } from './LiveFeed.js';
import { GigsTable } from './GigsTable.js';
import { WorkersLeaderboard } from './WorkersLeaderboard.js';
import { CustomersAtRisk } from './CustomersAtRisk.js';
import { RevenueWaterfall } from './RevenueWaterfall.js';
import { DisputeQueue } from './DisputeQueue.js';
import { AiInsightsCard } from './AiInsightsCard.js';
import { NaturalLangQueryBar } from './NaturalLangQueryBar.js';
import { EarlyFinishOfferCard } from './EarlyFinishOfferCard.js';
import { QuickActionPalette } from './QuickActionPalette.js';
import { TodayOverview } from './TodayOverview.js';
import { CompetitorIntelCard } from './CompetitorIntelCard.js';

/**
 * Wave 4F — Brian-only birds-eye dashboard at /admin/super-admin.
 *
 * Layout:
 *   ┌──────────────────────────────────────────────────────────────────────┐
 *   │ <KpiStrip />  (6 bento cells, today + trailing 7d)                  │
 *   ├──────────────┬───────────────────────────────────────────────────────┤
 *   │ <LiveFeed /> │ Tabs: Gigs · Workers · Customers · Revenue · Disputes│
 *   │  (SSE)       │       · Insights · Query · Actions                   │
 *   └──────────────┴───────────────────────────────────────────────────────┘
 *
 * The page is gated by <SuperAdminGuard /> — without a valid owner bearer
 * token in localStorage the guard renders the auth challenge instead. Wave
 * 4A will swap the bearer for cookie+TOTP; the rest of the surface is
 * unchanged.
 *
 * Cmd+K opens <QuickActionPalette /> globally while this dashboard is
 * mounted — implemented inside the palette itself.
 */

type Tab = 'gigs' | 'workers' | 'customers' | 'revenue' | 'disputes' | 'insights' | 'query';

const TAB_LIST: ReadonlyArray<{ id: Tab; label: string }> = [
  { id: 'gigs', label: 'Active Gigs' },
  { id: 'workers', label: 'Leaderboard' },
  { id: 'customers', label: 'At-Risk' },
  { id: 'revenue', label: 'Revenue' },
  { id: 'disputes', label: 'Disputes' },
  { id: 'insights', label: 'AI Insights' },
  { id: 'query', label: 'NL Query' },
];

const STORAGE_KEY = 'bcl_super_admin_token';

export function SuperAdminGuard({ children }: { children: (token: string) => JSX.Element }) {
  const [token, setToken] = useState<string>('');
  const [draft, setDraft] = useState<string>('');
  const [error, setError] = useState<string>('');

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const stored = window.localStorage.getItem(STORAGE_KEY);
    if (stored) setToken(stored);
  }, []);

  const submit = useCallback(
    async (ev: React.FormEvent<HTMLFormElement>) => {
      ev.preventDefault();
      setError('');
      try {
        const res = await fetch('/api/admin/birds-eye', {
          headers: { authorization: `Bearer ${draft}` },
        });
        if (!res.ok) {
          setError(res.status === 401 ? 'Invalid owner token.' : `Auth failed (${res.status}).`);
          return;
        }
        window.localStorage.setItem(STORAGE_KEY, draft);
        setToken(draft);
      } catch (err) {
        setError((err as Error).message);
      }
    },
    [draft],
  );

  if (!token) {
    return (
      <article className="section">
        <div className="container-pad max-w-md">
          <p className="eyebrow mb-3">Brian only</p>
          <h1 className="mb-2 text-3xl font-extrabold">Super-Admin Birds-Eye</h1>
          <p className="text-brand-mute mb-6 text-sm">
            Paste the OWNER_INVOICE_KEY to unlock the live ops dashboard.
          </p>
          <form onSubmit={submit} className="space-y-3">
            <input
              type="password"
              autoComplete="off"
              spellCheck={false}
              placeholder="Owner bearer token"
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              className="input w-full"
            />
            <button type="submit" className="btn-primary w-full">
              Unlock
            </button>
            {error && <p className="text-sm text-red-400">{error}</p>}
          </form>
        </div>
      </article>
    );
  }
  return children(token);
}

export function SuperAdminDashboard() {
  useThemeToolsSurface('super-admin-dashboard');
  return <SuperAdminGuard>{(token) => <SuperAdminInner token={token} />}</SuperAdminGuard>;
}

function SuperAdminInner({ token }: { token: string }) {
  const [tab, setTab] = useState<Tab>('gigs');
  // ARIA roving-tabindex for the super-admin views tablist (axe-blind interaction gap).
  const viewTab = useRovingTabs(TAB_LIST.length, (i) => setTab(TAB_LIST[i]!.id));
  const [paletteOpen, setPaletteOpen] = useState(false);

  // Global Cmd+K / Ctrl+K to open palette.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setPaletteOpen((prev) => !prev);
      }
      if (e.key === 'Escape') setPaletteOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const headers = useMemo<HeadersInit>(() => ({ authorization: `Bearer ${token}` }), [token]);

  return (
    <article className="section">
      <div className="container-pad space-y-6">
        <header className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="eyebrow mb-1">Brian-only · birds-eye</p>
            <h1 className="text-3xl font-extrabold">Super-Admin</h1>
            <p className="text-brand-mute mt-1 text-sm">
              Live ops surface. <kbd className="rounded bg-white/10 px-1.5 py-0.5 text-xs">⌘K</kbd>{' '}
              to open the action palette.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setPaletteOpen(true)}
            className="rounded border border-white/10 bg-white/5 px-3 py-1.5 text-sm hover:bg-white/10"
            data-testid="open-palette"
          >
            ⌘K Palette
          </button>
        </header>

        <TodayOverview headers={headers} />
        <KpiStrip headers={headers} />

        {/* Small insight cards grid — CompetitorIntel + CrewSentiment slot */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <CompetitorIntelCard headers={headers} />
          </div>
          {/* CrewSentimentCard mounts here when built */}
        </div>

        {/* Feature insight cards */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <EarlyFinishOfferCard headers={headers} />
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-[320px_1fr]">
          <LiveFeed token={token} />
          <section className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <nav
              role="tablist"
              aria-label="Super admin views"
              className="mb-4 flex flex-wrap gap-1 border-b border-white/10"
            >
              {TAB_LIST.map((t, i) => (
                <button
                  key={t.id}
                  role="tab"
                  aria-selected={tab === t.id}
                  onClick={() => setTab(t.id)}
                  {...viewTab(i, tab === t.id)}
                  className={[
                    'rounded-t px-3 py-2 text-sm transition',
                    tab === t.id
                      ? 'bg-white/10 font-semibold text-white'
                      : 'text-brand-mute hover:text-white',
                  ].join(' ')}
                  data-testid={`tab-${t.id}`}
                >
                  {t.label}
                </button>
              ))}
            </nav>
            <div role="tabpanel">
              {tab === 'gigs' && <GigsTable headers={headers} />}
              {tab === 'workers' && <WorkersLeaderboard headers={headers} />}
              {tab === 'customers' && <CustomersAtRisk headers={headers} />}
              {tab === 'revenue' && <RevenueWaterfall headers={headers} />}
              {tab === 'disputes' && <DisputeQueue headers={headers} />}
              {tab === 'insights' && <AiInsightsCard headers={headers} />}
              {tab === 'query' && <NaturalLangQueryBar headers={headers} />}
            </div>
          </section>
        </div>
      </div>

      {paletteOpen && (
        <QuickActionPalette
          headers={headers}
          onClose={() => setPaletteOpen(false)}
          onJump={(t) => {
            setTab(t);
            setPaletteOpen(false);
          }}
        />
      )}
    </article>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
