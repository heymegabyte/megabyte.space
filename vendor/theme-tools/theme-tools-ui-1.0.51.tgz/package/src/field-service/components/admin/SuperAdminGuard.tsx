import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useEffect, type ReactNode } from 'react';
import { useAdminSession, type AdminIdentity } from '../../admin-session.js';

// Wrap any admin-only React subtree so anonymous visitors are redirected to
// `/admin/login` and authenticated supers see the children. Two render paths:
//   - status === 'checking' → spinner + aria-live="polite" message.
//   - status === 'anonymous' → side-effect redirect, render nothing.
//   - status === 'authenticated' → optionally constrain `requireRole`, then
//     render children. If `requireRole` is set and the admin's role does not
//     match, render a fallback access-denied panel instead of children.
//
// The redirect appends `?next=<current-path>` so the login screen can bounce
// back after a successful verify-code. `replace` is used so the login screen
// does not stack up in browser history.

interface Props {
  readonly children: ReactNode;
  readonly requireRole?: AdminIdentity['role'];
  readonly fallback?: ReactNode;
}

export function SuperAdminGuard({ children, requireRole = 'super', fallback }: Props) {
  useThemeToolsSurface('super-admin-guard');
  const { state } = useAdminSession();

  useEffect(() => {
    if (state.status === 'anonymous') {
      const here = window.location.pathname + window.location.search;
      const next = encodeURIComponent(here);
      window.location.replace(`/admin/login?next=${next}`);
    }
  }, [state.status]);

  if (state.status === 'checking') {
    return (
      <article className="section">
        <div className="container-pad max-w-xl">
          <p className="eyebrow mb-3">Admin</p>
          <h1 className="text-3xl font-extrabold mb-2">Checking your session…</h1>
          <div
            role="status"
            aria-live="polite"
            className="rounded-md border border-brand-line bg-brand-card p-6"
          >
            <div className="flex items-center gap-3 text-sm text-brand-mute">
              <span
                aria-hidden
                className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-brand-line border-t-brand-accent"
              />
              One moment — verifying access.
            </div>
          </div>
        </div>
      </article>
    );
  }

  if (state.status === 'anonymous') {
    // The useEffect above triggers the redirect; render nothing meanwhile.
    return null;
  }

  if (state.admin.role !== requireRole) {
    if (fallback) return <>{fallback}</>;
    return (
      <article className="section">
        <div className="container-pad max-w-xl">
          <p className="eyebrow mb-3">Admin</p>
          <h1 className="text-3xl font-extrabold mb-2">Access denied</h1>
          <p className="text-brand-mute">
            Signed in as <strong className="text-brand-ink">{state.admin.name}</strong> (
            {state.admin.role}). This surface requires the {requireRole} role.
          </p>
        </div>
      </article>
    );
  }

  return <>{children}</>;
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
