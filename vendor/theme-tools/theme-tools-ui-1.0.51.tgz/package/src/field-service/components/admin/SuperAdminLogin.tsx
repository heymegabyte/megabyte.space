import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useRef, useState } from 'react';
import { useAdminSession } from '../../admin-session.js';
import { AuthShell, AuthError, type AuthStage } from '../auth/AuthShell.js';

// Super-admin login screen. Two stages:
//   1. Contact — email OR phone, posts to `/api/admin/auth/request-code`.
//   2. Code    — 6-digit OTP, posts to `/api/admin/auth/verify-code`.
// On success the verify-code endpoint sets `bcl_admin_sid` (12h, SameSite=Strict)
// and we hard-redirect to /admin (or the `next` query param if present + safe).
//
// Distinct from `LoginPage` (crew + customer dual-pane); this surface is
// admin-only and never enumerates the admin list — unknown contacts still
// receive a generic "code sent" response. Shares the AuthShell + .field-*
// utility classes with the customer/crew screen so every auth surface looks
// identical.

const TITLE = 'Admin login — Brick Labor';
const DESC =
  'Super-admin sign-in for Brick Labor operations. Magic-code login by email or phone — 12-hour session.';
const RESEND_COOLDOWN_S = 30;

type Stage = AuthStage;

function looksLikeEmail(s: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s.trim());
}

function looksLikePhone(s: string): boolean {
  const digits = s.replace(/\D/g, '');
  return digits.length >= 10 && digits.length <= 11;
}

function asErrorText(value: unknown, fallback: string): string {
  if (typeof value === 'string' && value) return value;
  if (value && typeof value === 'object' && 'message' in value) {
    const m = (value as { message?: unknown }).message;
    if (typeof m === 'string' && m) return m;
  }
  return fallback;
}

function safeNext(raw: string | null): string | null {
  if (!raw) return null;
  if (!raw.startsWith('/') || raw.startsWith('//')) return null;
  return raw;
}

const ADMIN_FOOTER = (
  <>
    Admin access is logged. By signing in you agree to the operations policy. Contact{' '}
    <a href="mailto:security@bricklabor.com" className="underline-hover text-brand-mute">
      security@bricklabor.com
    </a>{' '}
    if you did not request a code.
  </>
);

export function SuperAdminLogin() {
  useThemeToolsSurface('super-admin-login');
  const session = useAdminSession();
  const [contact, setContact] = useState('');
  const [code, setCode] = useState('');
  const [stage, setStage] = useState<Stage>('contact');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [cooldown, setCooldown] = useState(0);
  const cooldownTimer = useRef<number | null>(null);

  useEffect(() => {
    document.title = TITLE;
    const meta = document.querySelector('meta[name="description"]');
    if (meta) meta.setAttribute('content', DESC);
  }, []);

  // Already signed in? Bounce to /admin (or `next` if supplied + safe).
  useEffect(() => {
    if (session.state.status === 'authenticated') {
      const params = new URLSearchParams(window.location.search);
      const next = safeNext(params.get('next')) ?? '/admin';
      window.location.replace(next);
    }
  }, [session.state]);

  const startCooldown = useCallback(() => {
    if (cooldownTimer.current !== null) {
      window.clearInterval(cooldownTimer.current);
      cooldownTimer.current = null;
    }
    setCooldown(RESEND_COOLDOWN_S);
    cooldownTimer.current = window.setInterval(() => {
      setCooldown((n) => {
        if (n <= 1) {
          if (cooldownTimer.current !== null) {
            window.clearInterval(cooldownTimer.current);
            cooldownTimer.current = null;
          }
          return 0;
        }
        return n - 1;
      });
    }, 1000);
  }, []);

  useEffect(
    () => () => {
      if (cooldownTimer.current !== null) window.clearInterval(cooldownTimer.current);
    },
    [],
  );

  const requestCode = useCallback(async () => {
    const trimmed = contact.trim();
    if (!looksLikeEmail(trimmed) && !looksLikePhone(trimmed)) {
      setError('Enter a valid email or 10-digit US phone number.');
      return;
    }
    setBusy(true);
    setError('');
    try {
      const res = await fetch('/api/admin/auth/request-code', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ contact: trimmed }),
      });
      if (!res.ok) {
        const j = (await res.json().catch(() => ({}))) as { code?: string; error?: unknown };
        if (j.code === 'invalid_contact') {
          setError('Enter a valid email or 10-digit US phone number.');
        } else if (j.code === 'rate_limited') {
          setError('Too many requests. Wait a minute and try again.');
        } else {
          setError(asErrorText(j.error, 'Could not send code.'));
        }
        return;
      }
      setStage('code');
      startCooldown();
    } catch {
      setError('Connection issue. Try again.');
    } finally {
      setBusy(false);
    }
  }, [contact, startCooldown]);

  const verifyCode = useCallback(
    async (codeValue?: string) => {
      const submitted = (codeValue ?? code).trim();
      if (submitted.length !== 6) return;
      setBusy(true);
      setError('');
      try {
        const res = await fetch('/api/admin/auth/verify-code', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ contact: contact.trim(), code: submitted }),
        });
        if (!res.ok) {
          const j = (await res.json().catch(() => ({}))) as { code?: string; error?: unknown };
          if (j.code === 'invalid_code') {
            setError('That code did not match. Re-enter or send a new one.');
          } else if (j.code === 'expired') {
            setError('That code expired. Send a new one.');
          } else if (j.code === 'already_used') {
            setError('That code was already used. Send a new one.');
          } else if (j.code === 'rate_limited') {
            setError('Too many attempts. Wait a minute and try again.');
          } else {
            setError(asErrorText(j.error, 'Could not verify.'));
          }
          return;
        }
        setStage('success');
        const params = new URLSearchParams(window.location.search);
        const next = safeNext(params.get('next')) ?? '/admin';
        // Short pause for the success affordance, then hard-replace so the
        // browser history does not retain the login screen.
        window.setTimeout(() => window.location.replace(next), 400);
      } catch {
        setError('Connection issue. Try again.');
      } finally {
        setBusy(false);
      }
    },
    [code, contact],
  );

  const onSubmitContact = useCallback(
    (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      if (!busy) void requestCode();
    },
    [busy, requestCode],
  );

  const onSubmitCode = useCallback(
    (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      if (!busy) void verifyCode();
    },
    [busy, verifyCode],
  );

  if (session.state.status === 'checking' || session.state.status === 'authenticated') {
    return (
      <AuthShell
        eyebrow="Admin"
        badge="Restricted"
        headline="Checking your session…"
        body="One moment — confirming admin credentials."
      >
        <div
          role="status"
          aria-live="polite"
          className="flex items-center gap-3 text-sm text-brand-mute"
        >
          <span
            aria-hidden
            className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-brand-line border-t-brand-accent"
          />
          Verifying.
        </div>
      </AuthShell>
    );
  }

  return (
    <AuthShell
      eyebrow="Super-admin"
      badge="Restricted"
      headline="Operations console."
      body={
        <>
          Magic-code sign-in by email or text. <strong className="text-brand-ink">12-hour</strong>{' '}
          session, SameSite=Strict cookie, every login logged.
        </>
      }
      stage={stage}
      stageLabels={{ contact: 'Contact', code: 'Code', success: 'Done' }}
      footer={ADMIN_FOOTER}
    >
      {stage === 'contact' && (
        <form onSubmit={onSubmitContact} noValidate className="space-y-4">
          <div>
            <label htmlFor="admin-contact" className="field-label">
              Email or phone
            </label>
            <input
              id="admin-contact"
              type="text"
              autoComplete="username"
              inputMode="email"
              autoFocus
              spellCheck={false}
              value={contact}
              onChange={(e) => setContact(e.target.value)}
              placeholder="you@bricklabor.com or (973) 555-0123"
              className="field-input"
            />
          </div>
          <button type="submit" disabled={busy} className="btn-primary w-full">
            {busy ? 'Sending…' : 'Send code'}
          </button>
        </form>
      )}

      {stage === 'code' && (
        <form onSubmit={onSubmitCode} noValidate className="space-y-4">
          <p className="text-sm text-brand-mute">
            Code sent to <strong className="text-brand-ink">{contact.trim()}</strong>. Enter the
            6-digit code — expires in 10 minutes.
          </p>
          <div>
            <label htmlFor="admin-code" className="field-label">
              6-digit code
            </label>
            <input
              id="admin-code"
              type="text"
              inputMode="numeric"
              autoComplete="one-time-code"
              maxLength={6}
              pattern="\d{6}"
              autoFocus
              value={code}
              onChange={(e) => {
                const next = e.target.value.replace(/\D/g, '').slice(0, 6);
                setCode(next);
                if (next.length === 6 && !busy) void verifyCode(next);
              }}
              className="field-input-code"
            />
          </div>
          <div className="flex items-center gap-3">
            <button
              type="submit"
              disabled={busy || code.length !== 6}
              className="btn-primary flex-1"
            >
              {busy ? 'Verifying…' : 'Verify'}
            </button>
            <button
              type="button"
              onClick={() => {
                if (cooldown === 0 && !busy) void requestCode();
              }}
              disabled={cooldown > 0 || busy}
              className="btn-secondary px-4 py-3 text-sm"
            >
              {cooldown > 0 ? `Resend in ${cooldown}s` : 'Resend'}
            </button>
          </div>
          <button
            type="button"
            onClick={() => {
              setStage('contact');
              setCode('');
              setError('');
            }}
            className="text-sm text-brand-mute underline-hover"
          >
            ← Use a different contact
          </button>
        </form>
      )}

      {stage === 'success' && (
        <div
          role="status"
          aria-live="polite"
          className="rounded-md border border-emerald-500/40 bg-emerald-500/10 p-4 text-sm text-emerald-100"
        >
          ✓ Signed in. Loading admin console…
        </div>
      )}

      <AuthError error={error} />
    </AuthShell>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
