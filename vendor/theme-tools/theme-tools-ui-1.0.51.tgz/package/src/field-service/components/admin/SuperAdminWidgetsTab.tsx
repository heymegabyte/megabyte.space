import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { Suspense, useEffect, useMemo, useState } from 'react';
import { WIDGET_REGISTRY, WIDGET_CATEGORIES } from '../../admin-widget-loader.js';

const KEY_STORAGE = 'bcl-admin-key-v1';

/**
 * Wave 12 master widget grid. Mounted at `/admin/widgets` (the App.tsx
 * integrator wires this route; this file is standalone and never imports
 * the W4F-owned `SuperAdminDashboard.tsx`).
 *
 * The grid is filterable by category and search; each tile lazy-loads its
 * own component so the initial admin payload stays under budget.
 */
export function SuperAdminWidgetsTab() {
  useThemeToolsSurface('super-admin-widgets-tab');
  const [adminKey, setAdminKey] = useState('');
  const [filter, setFilter] = useState<'all' | (typeof WIDGET_CATEGORIES)[number]>('all');
  const [q, setQ] = useState('');

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const stored = window.sessionStorage.getItem(KEY_STORAGE) ?? '';
    setAdminKey(stored);
  }, []);

  const persistKey = (v: string) => {
    setAdminKey(v);
    if (typeof window !== 'undefined') window.sessionStorage.setItem(KEY_STORAGE, v);
  };

  const visible = useMemo(() => {
    return WIDGET_REGISTRY.filter((w) => {
      if (filter !== 'all' && w.category !== filter) return false;
      if (
        q &&
        !w.title.toLowerCase().includes(q.toLowerCase()) &&
        !w.kind.includes(q.toLowerCase())
      )
        return false;
      return true;
    });
  }, [filter, q]);

  return (
    <div style={{ padding: 24, background: '#060610', color: '#e6e6f0', minHeight: '100vh' }}>
      <header style={{ marginBottom: 16 }}>
        <h1 style={{ fontSize: 24, fontWeight: 700, margin: 0 }}>Super-admin widgets</h1>
        <p style={{ fontSize: 12, color: '#888', marginTop: 4 }}>
          Wave 12 — {WIDGET_REGISTRY.length} dashboards. Filter by category, search, or open any
          widget directly.
        </p>
      </header>

      <div
        style={{
          display: 'flex',
          gap: 8,
          alignItems: 'center',
          marginBottom: 16,
          flexWrap: 'wrap',
        }}
      >
        <input
          type="password"
          value={adminKey}
          onChange={(e) => persistKey(e.target.value)}
          placeholder="OWNER_INVOICE_KEY"
          style={{
            background: 'var(--color-surface-field)',
            color: 'var(--color-field-ink)',
            border: '1px solid var(--color-field-line)',
            borderRadius: 6,
            padding: '6px 10px',
            fontSize: 12,
            minWidth: 280,
          }}
        />
        <input
          type="search"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search widgets…"
          style={{
            background: 'var(--color-surface-field)',
            color: 'var(--color-field-ink)',
            border: '1px solid var(--color-field-line)',
            borderRadius: 6,
            padding: '6px 10px',
            fontSize: 12,
            minWidth: 200,
          }}
        />
        <button type="button" onClick={() => setFilter('all')} style={tabBtn(filter === 'all')}>
          all
        </button>
        {WIDGET_CATEGORIES.map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => setFilter(cat)}
            style={tabBtn(filter === cat)}
          >
            {cat}
          </button>
        ))}
      </div>

      {!adminKey ? (
        <p style={{ color: 'var(--color-danger-soft)', fontSize: 13 }}>
          Paste your <code>OWNER_INVOICE_KEY</code> above to load widgets.
        </p>
      ) : (
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
            gap: 12,
          }}
        >
          {visible.map((w) => {
            const Component = w.Component;
            return (
              <Suspense
                key={w.kind}
                fallback={
                  <section style={cardSkeleton}>
                    <p style={{ fontSize: 12, color: '#888' }}>Loading {w.title}…</p>
                  </section>
                }
              >
                <Component adminKey={adminKey} />
              </Suspense>
            );
          })}
          {visible.length === 0 ? (
            <p style={{ color: '#888', fontSize: 12 }}>No widgets match.</p>
          ) : null}
        </div>
      )}
    </div>
  );
}

function tabBtn(active: boolean): React.CSSProperties {
  return {
    background: active ? 'var(--color-action-violet)' : 'var(--color-surface-inactive)',
    color: 'var(--color-on-emphasis)',
    border: '1px solid var(--color-field-line)',
    padding: '4px 10px',
    borderRadius: 6,
    fontSize: 11,
    cursor: 'pointer',
    textTransform: 'capitalize',
  };
}

const cardSkeleton: React.CSSProperties = {
  background: 'var(--color-surface-deep)',
  border: '1px solid var(--color-surface-line)',
  borderRadius: 12,
  padding: 16,
  minHeight: 100,
};
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
