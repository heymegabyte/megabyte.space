import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useEffect, useState } from 'react';

/**
 * System health panel — super-admin only. Polls /api/super-admin/system-health
 * every 60s. Color-codes latency: green <100ms, yellow <500ms, red >500ms.
 */

interface Health {
  d1: { writeMs: number; readMs: number; lastBackupAgo: string | null };
  ai: { reachable: boolean; lastError: string | null };
  kv: { reachable: boolean; latencyMs: number };
  r2: { reachable: boolean; latencyMs: number };
}

function latColor(ms: number): string {
  if (ms < 0) return 'border-red-500/50 bg-red-500/5 text-red-300';
  if (ms < 100) return 'border-emerald-500/50 bg-emerald-500/5 text-emerald-300';
  if (ms < 500) return 'border-amber-500/50 bg-amber-500/5 text-amber-300';
  return 'border-red-500/50 bg-red-500/5 text-red-300';
}
function reachColor(ok: boolean): string {
  return ok
    ? 'border-emerald-500/50 bg-emerald-500/5 text-emerald-300'
    : 'border-red-500/50 bg-red-500/5 text-red-300';
}

export function SystemHealthPanel({ bearer }: { bearer: string }) {
  useThemeToolsSurface('system-health-panel');
  const [data, setData] = useState<Health | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    if (!bearer) {
      setLoading(false);
      setError('Add the SUPER_ADMIN_TOKEN in Settings to view system health.');
      return;
    }
    let cancelled = false;
    const load = async () => {
      try {
        const res = await fetch('/api/super-admin/system-health', {
          headers: { authorization: `Bearer ${bearer}` },
        });
        const json = (await res.json()) as { ok: boolean; health?: Health; error?: string };
        if (cancelled) return;
        if (json.ok && json.health) setData(json.health);
        else setError(json.error ?? `HTTP ${res.status}`);
      } catch (err) {
        if (!cancelled) setError((err as Error).message);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    void load();
    const t = window.setInterval(() => void load(), 60_000);
    return () => {
      cancelled = true;
      window.clearInterval(t);
    };
  }, [bearer, refreshKey]);

  if (loading) return <p className="text-sm text-brand-mute">Probing bindings…</p>;
  if (error) return <p className="text-sm text-red-400">{error}</p>;
  if (!data) return null;

  return (
    <section
      className="rounded-2xl border border-brand-line bg-bg-elevated p-5 space-y-4"
      aria-labelledby="sys-health-title"
      data-enter
    >
      <div className="flex items-baseline justify-between gap-3">
        <h2 id="sys-health-title" className="text-xl font-bold text-brand-ink">
          System health
        </h2>
        <button
          type="button"
          onClick={() => setRefreshKey((k) => k + 1)}
          className="text-xs text-brand-mute hover:text-brand-ink"
        >
          Refresh
        </button>
      </div>
      <dl className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Tile label="D1 read" value={`${data.d1.readMs}ms`} className={latColor(data.d1.readMs)} />
        <Tile
          label="D1 write"
          value={`${data.d1.writeMs}ms`}
          className={latColor(data.d1.writeMs)}
        />
        <Tile
          label="KV"
          value={data.kv.reachable ? `${data.kv.latencyMs}ms` : 'down'}
          className={reachColor(data.kv.reachable)}
        />
        <Tile
          label="R2"
          value={data.r2.reachable ? `${data.r2.latencyMs}ms` : 'down'}
          className={reachColor(data.r2.reachable)}
        />
        <Tile
          label="Workers AI"
          value={data.ai.reachable ? 'bound' : 'unbound'}
          className={reachColor(data.ai.reachable)}
        />
        <Tile
          label="Last backup"
          value={data.d1.lastBackupAgo ?? 'never'}
          className={
            data.d1.lastBackupAgo
              ? 'border-emerald-500/50 bg-emerald-500/5 text-emerald-300'
              : 'border-amber-500/50 bg-amber-500/5 text-amber-300'
          }
        />
      </dl>
      <p className="text-xs text-brand-mute">Auto-refreshes every 60s.</p>
    </section>
  );
}

function Tile({ label, value, className }: { label: string; value: string; className: string }) {
  return (
    <div className={`rounded-lg border px-3 py-2 ${className}`}>
      <dt className="font-mono text-[10px] uppercase tracking-widest opacity-80">{label}</dt>
      <dd className="mt-1 text-base font-semibold">{value}</dd>
    </div>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
