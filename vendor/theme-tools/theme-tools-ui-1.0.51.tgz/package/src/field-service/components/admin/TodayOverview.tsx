import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useEffect, useState } from 'react';

/**
 * Wave 21C — "Today" cockpit strip at the top of /admin (Super-Admin
 * dashboard). Five headline tiles + the live INP gauge, polled every 30s.
 *
 * Pairs with the wider <KpiStrip /> below — this is the ops-action surface
 * (open work, pending money, unread alerts) while KpiStrip is the trailing
 * KPI bento.
 */

interface TodayResponse {
  ok: true;
  asOf: string;
  today: {
    openGigs: number;
    pendingPayments: number;
    unreadEventsLast24h: number;
    inpP75LastHourMs: number | null;
    revenueTodayCents: number;
    revenueTodayBreakdown: { squareCents: number; stripeCents: number };
  };
}

function dollars(cents: number): string {
  return `$${(cents / 100).toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
}

export function TodayOverview({ headers }: { headers: HeadersInit }) {
  useThemeToolsSurface('today-overview');
  const [data, setData] = useState<TodayResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    async function load(): Promise<void> {
      try {
        const res = await fetch('/api/admin/today', { headers });
        if (!res.ok) {
          if (!cancelled) setError(`HTTP ${res.status}`);
          return;
        }
        const json = (await res.json()) as TodayResponse;
        if (!cancelled) {
          setData(json);
          setError(null);
        }
      } catch (e) {
        if (!cancelled) setError((e as Error).message);
      }
    }
    void load();
    const id = window.setInterval(() => void load(), 30_000);
    return () => {
      cancelled = true;
      window.clearInterval(id);
    };
  }, [headers]);

  if (error) {
    return (
      <div
        role="alert"
        className="rounded-xl border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-200"
      >
        Today: {error}
      </div>
    );
  }
  if (!data) {
    return (
      <div className="grid animate-pulse grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="h-24 rounded-xl bg-white/5" />
        ))}
      </div>
    );
  }

  const t = data.today;
  const inpTone =
    t.inpP75LastHourMs == null
      ? 'neutral'
      : t.inpP75LastHourMs <= 200
        ? 'good'
        : t.inpP75LastHourMs <= 500
          ? 'warn'
          : 'critical';
  const tiles: ReadonlyArray<{
    label: string;
    value: string;
    sub?: string;
    href?: string;
    tone?: 'good' | 'warn' | 'critical' | 'neutral';
  }> = [
    {
      label: 'Open gigs',
      value: String(t.openGigs),
      sub: 'awaiting crew',
      href: '/admin/jobs',
      tone: t.openGigs > 5 ? 'warn' : 'neutral',
    },
    {
      label: 'Pending payments',
      value: String(t.pendingPayments),
      sub: 'unpaid + unconfirmed',
      href: '/admin/jobs',
      tone: t.pendingPayments > 0 ? 'warn' : 'good',
    },
    {
      label: 'Unread events',
      value: String(t.unreadEventsLast24h),
      sub: 'last 24h',
      href: '/admin/notifications',
      tone: t.unreadEventsLast24h > 20 ? 'warn' : 'neutral',
    },
    {
      label: 'INP p75 (1h)',
      value: t.inpP75LastHourMs == null ? '—' : `${t.inpP75LastHourMs}ms`,
      sub: 'real-user interactions',
      tone: inpTone,
    },
    {
      label: 'Revenue today',
      value: dollars(t.revenueTodayCents),
      sub: `${dollars(t.revenueTodayBreakdown.squareCents)} Sq · ${dollars(
        t.revenueTodayBreakdown.stripeCents,
      )} St`,
      tone: 'good',
    },
  ];

  return (
    <section aria-label="Today overview" className="space-y-3">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {tiles.map((tile) => {
          const className = [
            'rounded-xl border bg-white/[0.03] p-4 transition hover:bg-white/[0.06]',
            tile.tone === 'good'
              ? 'border-emerald-500/30'
              : tile.tone === 'warn'
                ? 'border-amber-500/40'
                : tile.tone === 'critical'
                  ? 'border-red-500/50'
                  : 'border-white/10',
          ].join(' ');
          const inner = (
            <>
              <div className="text-brand-mute text-xs uppercase tracking-wide">{tile.label}</div>
              <div className="mt-1 text-2xl font-extrabold tabular-nums">{tile.value}</div>
              {tile.sub && <div className="text-brand-mute mt-1 text-xs">{tile.sub}</div>}
            </>
          );
          if (tile.href) {
            return (
              <a key={tile.label} href={tile.href} className={className + ' block'}>
                {inner}
              </a>
            );
          }
          return (
            <div key={tile.label} className={className}>
              {inner}
            </div>
          );
        })}
      </div>
      <p className="text-brand-mute text-xs">
        As of {new Date(data.asOf).toLocaleTimeString()} · auto-refresh 30s
      </p>
    </section>
  );
}

export default TodayOverview;
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
