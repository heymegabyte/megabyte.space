import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import {
  NotificationPrefsTile,
  PiiRedactTile,
  VoiceMemoTile,
  ReminderCadenceTile,
  TipSuggesterTile,
  BreakTrackerTile,
  MileageTile,
  CustomerBriefTile,
  SmartScheduleTile,
  AffinityTile,
  AutofillTile,
  PayoutSplitTile,
  PhotoQualityTile,
  DamageDraftTile,
  SurgeTunerTile,
  FatigueTile,
  WeeklyPerfTile,
  NpsTile,
  JobDescTile,
  PricingFloorTile,
  CarpoolTile,
  AutoArchiveTile,
  DupBookingTile,
  PeerNotesTile,
  LeaderboardTile,
  BadgesTile,
  IncidentCategoryTile,
  NextServiceTile,
  BrandVoiceTile,
  MonthlyRecapTile,
} from './wave20/tiles.js';

/**
 * Wave 20 bento grid — admin landing page at /admin/wave20. Renders all 30
 * AI-managed feature tiles. Each tile is a self-contained MVP; the grid
 * doesn't manage shared state. Tile order is by feature priority for the
 * dashboard reader, not the migration table order.
 */

export default function Wave20FeaturesGrid() {
  useThemeToolsSurface('wave20-features-grid');
  return (
    <main className="min-h-screen bg-bg-primary px-6 py-10 text-white">
      <header className="mx-auto mb-8 max-w-6xl">
        <p className="text-xs font-medium uppercase tracking-[0.2em] text-cyan-300">
          Wave 20 · AI-managed dashboard
        </p>
        <h1 className="mt-2 text-3xl font-bold text-white sm:text-4xl">30 features. One bento.</h1>
        <p className="mt-3 max-w-2xl text-white/70">
          Notification AI, break tracker, fatigue detector, affinity, NPS, monthly recap, and 24
          more. Each tile reads from
          <code className="ml-1 font-mono text-cyan-300">/api/wave20/admin/*</code>.
        </p>
      </header>
      <section
        className="mx-auto grid max-w-6xl gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
        aria-label="Wave 20 features"
      >
        <NotificationPrefsTile />
        <PiiRedactTile />
        <VoiceMemoTile />
        <ReminderCadenceTile />
        <TipSuggesterTile />
        <BreakTrackerTile />
        <MileageTile />
        <CustomerBriefTile />
        <SmartScheduleTile />
        <AffinityTile />
        <AutofillTile />
        <PayoutSplitTile />
        <PhotoQualityTile />
        <DamageDraftTile />
        <SurgeTunerTile />
        <FatigueTile />
        <WeeklyPerfTile />
        <NpsTile />
        <JobDescTile />
        <PricingFloorTile />
        <CarpoolTile />
        <AutoArchiveTile />
        <DupBookingTile />
        <PeerNotesTile />
        <LeaderboardTile />
        <BadgesTile />
        <IncidentCategoryTile />
        <NextServiceTile />
        <BrandVoiceTile />
        <MonthlyRecapTile />
      </section>
    </main>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
