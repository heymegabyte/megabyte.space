import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useState } from 'react';
import { adminFetch, formatCents, formatDate, formatRelative } from '@theme.tools/crm/field-service/admin-api';

/**
 * Wave 17 — Worker profile drawer.
 * Loads docs, claims, payouts, reviews, AI rules (W16 soft import),
 * comm log (W19 soft import). Manual override actions are stubs that
 * surface intent — actual mutations live in W13B / W15 owners.
 */

interface WorkerDetailProps {
  workerId: string;
  onClose: () => void;
  onMutated: () => void;
}

interface WorkerPayload {
  ok: true;
  worker: Record<string, unknown> & {
    id: string;
    first_name?: string;
    last_name?: string;
    phone?: string;
    email?: string;
    tier?: string;
    status?: string;
    rating_avg?: number | null;
    rating_count?: number;
    jobs_completed?: number;
    jobs_cancelled?: number;
    no_show_count?: number;
    bio?: string;
    city?: string;
    zip?: string;
    can_drive?: number;
    archived_at?: number | null;
  };
  docs: Array<Record<string, unknown>>;
  claims: Array<Record<string, unknown>>;
  payouts: Array<Record<string, unknown>>;
  reviews: Array<Record<string, unknown>>;
  rules: Array<Record<string, unknown>>;
  commLog: Array<Record<string, unknown>>;
}

export function WorkerDetail({ workerId, onClose, onMutated }: WorkerDetailProps) {
  useThemeToolsSurface('worker-detail');
  const [data, setData] = useState<WorkerPayload | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    const res = await adminFetch<WorkerPayload>(`/workers/${workerId}`);
    if (!res.ok) {
      setError(res.error);
      return;
    }
    setData(res.data);
  }, [workerId]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  const w = data?.worker;

  return (
    <div
      role="dialog"
      aria-label="Worker detail"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-stretch justify-end bg-black/60 backdrop-blur-sm"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="ml-auto h-full w-full max-w-3xl overflow-y-auto bg-bg-primary border-l border-brand-cyan/20 shadow-2xl">
        <header className="sticky top-0 z-10 flex items-center justify-between border-b border-brand-cyan/15 bg-bg-primary/95 px-5 py-3 backdrop-blur">
          <div>
            <h3 className="text-lg font-bold text-brand-cyan">
              {w?.first_name} {w?.last_name}
            </h3>
            <p className="text-xs text-brand-mute">
              {w?.tier} · {w?.status}
              {w?.phone && (
                <>
                  {' '}
                  ·{' '}
                  <a href={`tel:${w.phone}`} className="hover:text-brand-cyan">
                    {w.phone}
                  </a>
                </>
              )}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded border border-white/10 px-3 py-1 text-sm text-brand-mute hover:text-white"
            aria-label="Close"
          >
            Close ✕
          </button>
        </header>

        {error && (
          <div
            role="alert"
            className="m-5 rounded border border-red-500/40 bg-red-950/30 p-3 text-sm text-red-300"
          >
            {error}
          </div>
        )}

        {!data && !error && <div className="p-10 text-center text-brand-mute">Loading…</div>}

        {data && w && (
          <div className="space-y-6 p-5">
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Stat label="Rating" value={w.rating_avg != null ? w.rating_avg.toFixed(2) : '—'} />
              <Stat label="Jobs done" value={String(w.jobs_completed ?? 0)} />
              <Stat
                label="No-shows"
                value={String(w.no_show_count ?? 0)}
                tone={Number(w.no_show_count ?? 0) > 0 ? 'red' : 'plain'}
              />
              <Stat label="Dispatches" value={String(data.claims.length)} />
            </div>

            {w.bio && (
              <Section title="Bio">
                <p className="rounded border border-white/5 bg-white/5 p-3 text-sm text-brand-mute">
                  {w.bio}
                </p>
              </Section>
            )}

            <Section title={`Documents (${data.docs.length})`}>
              {data.docs.length === 0 ? (
                <Empty>No documents on file.</Empty>
              ) : (
                <ul className="space-y-1 text-sm">
                  {data.docs.map((d) => (
                    <li
                      key={String(d.id)}
                      className="flex justify-between border-b border-white/5 py-1.5"
                    >
                      <span className="text-white">{String(d.kind)}</span>
                      <span className="text-brand-mute">
                        {String(d.status)} ·{' '}
                        {d.expires_at
                          ? `expires ${formatDate(d.expires_at)}`
                          : formatRelative(String(d.created_at))}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </Section>

            <Section title={`AI rules (${data.rules.length})`}>
              {data.rules.length === 0 ? (
                <Empty>No worker-scoped rules. Wave 16 wires here once that table ships.</Empty>
              ) : (
                <ul className="space-y-1 text-sm">
                  {data.rules.map((r) => (
                    <li key={String(r.id)} className="rounded border border-white/5 bg-white/5 p-2">
                      <div className="text-white">{String(r.name ?? r.action ?? 'rule')}</div>
                      <div className="text-xs text-brand-mute">{String(r.description ?? '')}</div>
                    </li>
                  ))}
                </ul>
              )}
            </Section>

            <Section title={`Recent gigs (${data.claims.length})`}>
              {data.claims.length === 0 ? (
                <Empty>No gig history.</Empty>
              ) : (
                <ul className="space-y-1 text-sm">
                  {data.claims.slice(0, 25).map((cl) => (
                    <li
                      key={String(cl.id)}
                      className="flex justify-between border-b border-white/5 py-1.5"
                    >
                      <span className="text-white">{String(cl.status)}</span>
                      <span className="text-brand-mute">
                        {String(cl.service_zip ?? '')} · {formatRelative(String(cl.invited_at))}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </Section>

            <Section title={`Payouts (${data.payouts.length})`}>
              {data.payouts.length === 0 ? (
                <Empty>No payouts yet.</Empty>
              ) : (
                <ul className="space-y-1 text-sm">
                  {data.payouts.slice(0, 25).map((p) => (
                    <li
                      key={String(p.id)}
                      className="flex justify-between border-b border-white/5 py-1.5"
                    >
                      <span className="text-white">{formatCents(Number(p.amount_cents))}</span>
                      <span className="text-brand-mute">
                        {String(p.method)} · {String(p.status)} ·{' '}
                        {formatRelative(String(p.created_at))}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </Section>

            <Section title={`Ratings (${data.reviews.length})`}>
              {data.reviews.length === 0 ? (
                <Empty>No customer ratings yet.</Empty>
              ) : (
                <ul className="space-y-1 text-sm">
                  {data.reviews.map((r) => (
                    <li
                      key={String(r.id)}
                      className="border-b border-white/5 py-1.5 text-brand-mute"
                    >
                      <span className="text-white">★ {String(r.stars ?? '?')}</span>{' '}
                      {String(r.comment ?? '')}
                    </li>
                  ))}
                </ul>
              )}
            </Section>

            <Section title={`Communications (${data.commLog.length})`}>
              {data.commLog.length === 0 ? (
                <Empty>No comm log yet. Wave 19 populates this once that table ships.</Empty>
              ) : (
                <ul className="space-y-1 text-sm">
                  {data.commLog.map((m) => (
                    <li
                      key={String(m.id)}
                      className="flex justify-between border-b border-white/5 py-1"
                    >
                      <span className="text-white">{String(m.channel ?? '')}</span>
                      <span className="text-brand-mute">
                        {formatRelative(String(m.created_at))}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </Section>

            <p className="text-xs text-brand-mute">
              Override actions (pause / suspend / promote / archive) flow through W13B + W15.{' '}
              <button
                type="button"
                onClick={() => {
                  onMutated();
                  void load();
                }}
                className="text-brand-cyan hover:underline"
              >
                Refresh
              </button>
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

function Stat({
  label,
  value,
  tone = 'plain',
}: {
  label: string;
  value: string;
  tone?: 'plain' | 'red' | 'amber' | 'green';
}) {
  const color =
    tone === 'red'
      ? 'text-red-300'
      : tone === 'amber'
        ? 'text-amber-300'
        : tone === 'green'
          ? 'text-emerald-300'
          : 'text-white';
  return (
    <div className="rounded border border-brand-cyan/15 bg-white/5 p-3">
      <div className="text-xs uppercase text-brand-mute">{label}</div>
      <div className={`text-xl font-bold ${color}`}>{value}</div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h4 className="mb-2 text-xs font-bold uppercase tracking-wide text-brand-cyan/80">{title}</h4>
      {children}
    </div>
  );
}

function Empty({ children }: { children: React.ReactNode }) {
  return (
    <p className="rounded border border-dashed border-white/10 p-3 text-sm text-brand-mute">
      {children}
    </p>
  );
}

export default WorkerDetail;
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
