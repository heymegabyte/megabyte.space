import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useRef, useState } from 'react';
import { adminFetch, formatRelative, pushLocalRecent } from '@theme.tools/crm/field-service/admin-api';
import { WorkerDetail } from './WorkerDetail.js';
import { RecentlyViewed } from './RecentlyViewed.js';

/**
 * Wave 17 — Workers (crew) browser.
 */

type Tier = 'apprentice' | 'pro' | 'shift_lead' | 'master' | '';
type ActiveFilter = '' | 'true' | 'false';

interface WorkerRow {
  id: string;
  first_name: string;
  last_name: string;
  phone: string;
  email: string | null;
  tier: 'apprentice' | 'pro' | 'shift_lead' | 'master';
  status: string;
  city: string | null;
  zip: string | null;
  can_drive: number;
  rating_avg: number | null;
  rating_count: number;
  jobs_completed: number;
  jobs_cancelled: number;
  no_show_count: number;
  archived_at: number | null;
  created_at: string;
  last_gig_at: string | null;
  dispatch_count: number;
}

interface WorkersListResponse {
  ok: true;
  workers: WorkerRow[];
}

export function WorkersBrowser() {
  useThemeToolsSurface('workers-browser');
  const [q, setQ] = useState('');
  const [tier, setTier] = useState<Tier>('');
  const [active, setActive] = useState<ActiveFilter>('true');
  const [rows, setRows] = useState<WorkerRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const load = useCallback(async () => {
    abortRef.current?.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    setLoading(true);
    setError(null);
    const params = new URLSearchParams({ limit: '200' });
    if (q.trim()) params.set('q', q.trim());
    if (tier) params.set('tier', tier);
    if (active) params.set('active', active);
    const res = await adminFetch<WorkersListResponse>(`/workers?${params.toString()}`, {
      signal: ctrl.signal,
    });
    if (!res.ok) {
      if (res.error === 'aborted') return;
      setError(res.error);
      setLoading(false);
      return;
    }
    setRows(res.data.workers);
    setLoading(false);
  }, [q, tier, active]);

  useEffect(() => {
    const t = setTimeout(() => void load(), 200);
    return () => clearTimeout(t);
  }, [load]);

  return (
    <section className="space-y-4">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-extrabold text-brand-cyan">Workers</h2>
          <p className="text-sm text-brand-mute">
            Crew roster with tier, rating, last gig, dispatch volume.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <select
            value={active}
            onChange={(e) => setActive(e.target.value as ActiveFilter)}
            aria-label="Active filter"
            className="rounded border border-brand-cyan/30 bg-black/60 px-2 py-1.5 text-sm text-white focus:border-brand-cyan focus:outline-none"
          >
            <option value="true">Active</option>
            <option value="false">Archived</option>
            <option value="">All</option>
          </select>
          <select
            value={tier}
            onChange={(e) => setTier(e.target.value as Tier)}
            aria-label="Tier filter"
            className="rounded border border-brand-cyan/30 bg-black/60 px-2 py-1.5 text-sm text-white focus:border-brand-cyan focus:outline-none"
          >
            <option value="">All tiers</option>
            <option value="apprentice">Apprentice</option>
            <option value="pro">Pro</option>
            <option value="shift_lead">Shift lead</option>
            <option value="master">Master</option>
          </select>
          <input
            type="search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search name, phone, email, city…"
            className="rounded border border-brand-cyan/30 bg-black/60 px-3 py-1.5 text-sm text-white placeholder:text-brand-mute focus:border-brand-cyan focus:outline-none w-72"
            aria-label="Search workers"
          />
        </div>
      </header>

      {error && (
        <div
          role="alert"
          className="rounded border border-red-500/40 bg-red-950/30 p-3 text-sm text-red-300"
        >
          {error}
        </div>
      )}

      <div className="overflow-x-auto rounded border border-brand-cyan/15">
        <table className="w-full text-sm">
          <thead className="bg-white/5 text-left text-xs uppercase text-brand-mute">
            <tr>
              <th className="px-3 py-2">Crew</th>
              <th className="px-3 py-2">Tier</th>
              <th className="px-3 py-2 text-right">Rating</th>
              <th className="px-3 py-2 text-right">Jobs</th>
              <th className="px-3 py-2 text-right">Dispatches</th>
              <th className="px-3 py-2 text-right">Last gig</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && !loading && (
              <tr>
                <td colSpan={6} className="px-3 py-12 text-center text-brand-mute">
                  No workers match.
                </td>
              </tr>
            )}
            {rows.map((w) => (
              <tr
                key={w.id}
                onClick={() => {
                  setSelected(w.id);
                  pushLocalRecent('worker', w.id, `${w.first_name} ${w.last_name}`);
                }}
                className="cursor-pointer border-t border-white/5 hover:bg-brand-cyan/5"
              >
                <td className="px-3 py-2">
                  <div className="text-white">
                    {w.first_name} {w.last_name}{' '}
                    {w.archived_at && (
                      <span className="ml-1 rounded bg-zinc-700/40 px-1.5 py-0.5 text-xs text-zinc-300">
                        archived
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-brand-mute">
                    {w.phone} · {[w.city, w.zip].filter(Boolean).join(', ') || '—'}
                  </div>
                </td>
                <td className="px-3 py-2">
                  <TierBadge tier={w.tier} drives={!!w.can_drive} />
                </td>
                <td className="px-3 py-2 text-right text-white">
                  {w.rating_avg != null ? w.rating_avg.toFixed(2) : '—'}
                  <span className="ml-1 text-xs text-brand-mute">({w.rating_count})</span>
                </td>
                <td className="px-3 py-2 text-right text-brand-mute">
                  {w.jobs_completed}
                  {w.no_show_count > 0 && (
                    <span className="ml-1 text-red-400">·{w.no_show_count} NS</span>
                  )}
                </td>
                <td className="px-3 py-2 text-right text-brand-mute">{w.dispatch_count}</td>
                <td className="px-3 py-2 text-right text-brand-mute">
                  {formatRelative(w.last_gig_at)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {loading && <div className="text-center text-xs text-brand-mute">Loading…</div>}

      {selected && (
        <WorkerDetail
          workerId={selected}
          onClose={() => setSelected(null)}
          onMutated={() => void load()}
        />
      )}

      <RecentlyViewed
        onOpen={(kind, id) => {
          if (kind === 'worker') setSelected(id);
        }}
      />
    </section>
  );
}

function TierBadge({ tier, drives }: { tier: string; drives: boolean }) {
  const color =
    tier === 'master'
      ? 'bg-purple-950/50 text-purple-300'
      : tier === 'shift_lead'
        ? 'bg-brand-cyan/15 text-brand-cyan'
        : tier === 'pro'
          ? 'bg-emerald-950/50 text-emerald-300'
          : 'bg-zinc-800/60 text-zinc-300';
  return (
    <div className="flex items-center gap-1">
      <span className={`inline-block rounded px-2 py-0.5 text-xs font-medium ${color}`}>
        {tier}
      </span>
      {drives && (
        <span className="inline-block rounded bg-amber-950/40 px-1.5 py-0.5 text-[10px] font-medium text-amber-300">
          drives
        </span>
      )}
    </div>
  );
}

export default WorkersBrowser;
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
