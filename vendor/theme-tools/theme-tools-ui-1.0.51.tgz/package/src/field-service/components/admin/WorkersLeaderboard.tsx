import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useEffect, useState } from 'react';

interface LeaderboardRow {
  id: string;
  first_name: string;
  last_name: string;
  tier: string;
  rating_avg: number | null;
  rating_count: number;
  jobs_completed: number;
  jobs_cancelled: number;
  no_show_count: number;
  score: number;
}

interface ApiResponse {
  ok: true;
  workers: LeaderboardRow[];
}

export function WorkersLeaderboard({ headers }: { headers: HeadersInit }) {
  useThemeToolsSurface('workers-leaderboard');
  const [rows, setRows] = useState<LeaderboardRow[]>([]);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    let cancelled = false;
    fetch('/api/admin/workers/leaderboard', { headers })
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error(`status_${r.status}`))))
      .then((json: ApiResponse) => {
        if (!cancelled) setRows(json.workers);
      })
      .catch((err: Error) => {
        if (!cancelled) setError(err.message);
      });
    return () => {
      cancelled = true;
    };
  }, [headers]);

  if (error) return <p className="text-sm text-red-300">{error}</p>;
  if (rows.length === 0) {
    return <p className="text-brand-mute text-sm">No active workers yet.</p>;
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left text-sm" data-testid="workers-leaderboard">
        <thead className="text-brand-mute text-xs uppercase">
          <tr>
            <th className="py-2 pr-2">#</th>
            <th className="px-2 py-2">Worker</th>
            <th className="px-2 py-2">Tier</th>
            <th className="px-2 py-2">Score</th>
            <th className="px-2 py-2">Rating</th>
            <th className="px-2 py-2">Jobs</th>
            <th className="px-2 py-2">Cancels</th>
            <th className="px-2 py-2">No-shows</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((w, i) => (
            <tr key={w.id} className="border-t border-white/5">
              <td className="py-2 pr-2 text-xs tabular-nums">{i + 1}</td>
              <td className="px-2 py-2">
                {w.first_name} {w.last_name}
              </td>
              <td className="px-2 py-2 text-xs uppercase">{w.tier}</td>
              <td className="px-2 py-2 tabular-nums">{w.score.toFixed(2)}</td>
              <td className="px-2 py-2 tabular-nums">
                {w.rating_avg ? w.rating_avg.toFixed(2) : '—'}{' '}
                <span className="text-brand-mute text-xs">({w.rating_count})</span>
              </td>
              <td className="px-2 py-2 tabular-nums">{w.jobs_completed}</td>
              <td className="px-2 py-2 tabular-nums text-amber-200">{w.jobs_cancelled}</td>
              <td className="px-2 py-2 tabular-nums text-red-300">{w.no_show_count}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
