import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { useState } from 'react';
import { adminFetch, formatCents } from '@theme.tools/billing/field-service/finance-shared';

/**
 * Chargeback draft inbox. Ops enters the Square dispute id + booking id +
 * amount + reason; Haiku drafts a response citing photos, time logs,
 * customer messages. Never auto-submits — the draft is for human review +
 * paste into Square's dispute UI.
 */
export default function ChargebackDrafts() {
  useThemeToolsSurface('chargeback-drafts');
  const [form, setForm] = useState({
    chargebackId: '',
    bookingId: '',
    amount: '',
    reason: '',
  });
  const [draft, setDraft] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  async function onDraft(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setDraft(null);
    setCopied(false);
    try {
      const cents = Math.round(parseFloat(form.amount) * 100);
      if (!isFinite(cents) || cents <= 0) throw new Error('Enter a valid amount.');
      const res = await adminFetch('/api/admin/finance/chargeback/draft', {
        method: 'POST',
        body: JSON.stringify({
          chargebackId: form.chargebackId.trim(),
          bookingId: form.bookingId.trim(),
          amountCents: cents,
          reason: form.reason.trim(),
        }),
      });
      const json = (await res.json()) as { ok: boolean; draft?: string; error?: string };
      if (!json.ok) throw new Error(json.error ?? 'Draft failed');
      setDraft(json.draft ?? '');
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  async function copyDraft() {
    if (!draft) return;
    try {
      await navigator.clipboard.writeText(draft);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setError('Copy failed — select the text manually.');
    }
  }

  return (
    <section className="rounded-2xl bg-slate-900/60 ring-1 ring-white/5 p-5">
      <header className="mb-4">
        <h3 className="text-base font-semibold text-white">Chargeback draft inbox</h3>
        <p className="text-xs text-slate-400 mt-0.5">
          Haiku drafts a Square dispute response; ops reviews + submits
        </p>
      </header>

      <form onSubmit={onDraft} className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
        <input
          type="text"
          value={form.chargebackId}
          onChange={(e) => setForm({ ...form, chargebackId: e.target.value })}
          placeholder="Chargeback id"
          className="bg-slate-950/70 border border-white/10 rounded-md px-3 py-2 text-sm text-white"
          required
        />
        <input
          type="text"
          value={form.bookingId}
          onChange={(e) => setForm({ ...form, bookingId: e.target.value })}
          placeholder="Booking id"
          className="bg-slate-950/70 border border-white/10 rounded-md px-3 py-2 text-sm text-white"
          required
        />
        <input
          type="number"
          step="0.01"
          min="0"
          value={form.amount}
          onChange={(e) => setForm({ ...form, amount: e.target.value })}
          placeholder="Disputed amount ($)"
          className="bg-slate-950/70 border border-white/10 rounded-md px-3 py-2 text-sm text-white"
          required
        />
        <input
          type="text"
          value={form.reason}
          onChange={(e) => setForm({ ...form, reason: e.target.value })}
          placeholder="Cardholder reason"
          className="bg-slate-950/70 border border-white/10 rounded-md px-3 py-2 text-sm text-white"
          required
        />
        <button
          type="submit"
          disabled={loading}
          className="sm:col-span-2 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 disabled:cursor-not-allowed text-slate-950 font-medium rounded-md py-2 transition-colors"
        >
          {loading ? 'Drafting…' : 'Draft response'}
        </button>
      </form>

      {error && <p className="text-sm text-rose-400 mb-3">{error}</p>}

      {draft && (
        <div className="rounded-xl bg-slate-950/60 ring-1 ring-white/10 p-4">
          <div className="flex justify-between items-center mb-3">
            <span className="text-xs text-slate-400">
              Draft for ${formatCents(Math.round(parseFloat(form.amount) * 100))} dispute
            </span>
            <button
              type="button"
              onClick={copyDraft}
              className="text-xs px-3 py-1 rounded-md bg-white/5 hover:bg-white/10 text-slate-200"
            >
              {copied ? 'Copied' : 'Copy Markdown'}
            </button>
          </div>
          <pre className="text-sm text-slate-200 whitespace-pre-wrap font-mono leading-relaxed">
            {draft}
          </pre>
        </div>
      )}
    </section>
  );
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
