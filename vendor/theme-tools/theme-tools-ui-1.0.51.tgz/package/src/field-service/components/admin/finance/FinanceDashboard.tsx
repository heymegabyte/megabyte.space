import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { lazy, Suspense } from 'react';

const RevenueForecastChart = lazy(() => import('./RevenueForecastChart.js'));
const ProfitByZip = lazy(() => import('./ProfitByZip.js'));
const ProfitByService = lazy(() => import('./ProfitByService.js'));
const WorkerProfitabilityRanking = lazy(() => import('./WorkerProfitabilityRanking.js'));
const TipReconciliation = lazy(() => import('./TipReconciliation.js'));
const RefundFraudQueue = lazy(() => import('./RefundFraudQueue.js'));
const ChargebackDrafts = lazy(() => import('./ChargebackDrafts.js'));
const PricingExperimentRunner = lazy(() => import('./PricingExperimentRunner.js'));

/**
 * /admin/finance dashboard — orchestrates the 8 finance widgets in a
 * 12-column responsive grid. Forecast + experiment runner go full-width
 * (chart-heavy); profit panels share a 2-col layout; refund + chargeback
 * stack on the right rail for an "inbox" feel.
 *
 * All inner components lazy-load to keep the initial Admin bundle slim.
 */
export default function FinanceDashboard() {
  useThemeToolsSurface('finance-dashboard');
  return (
    <main className="min-h-screen bg-slate-950 text-white">
      <header className="border-b border-white/5 bg-slate-900/40 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
          <p className="text-xs uppercase tracking-wide text-cyan-300">Admin · Finance</p>
          <h1 className="text-2xl font-semibold mt-1">Money in, money out</h1>
          <p className="text-sm text-slate-400 mt-1 max-w-2xl">
            Revenue forecasts, profit-by-ZIP + service, tips, advances, refund-fraud scoring,
            chargeback drafts, and pricing experiments — all super-admin gated.
          </p>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 grid grid-cols-1 lg:grid-cols-12 gap-5">
        <div className="lg:col-span-12">
          <Suspense fallback={<DashboardPlaceholder label="Forecast" />}>
            <RevenueForecastChart days={14} />
          </Suspense>
        </div>

        <div className="lg:col-span-6">
          <Suspense fallback={<DashboardPlaceholder label="Profit by ZIP" />}>
            <ProfitByZip />
          </Suspense>
        </div>

        <div className="lg:col-span-6">
          <Suspense fallback={<DashboardPlaceholder label="Profit by service" />}>
            <ProfitByService />
          </Suspense>
        </div>

        <div className="lg:col-span-6">
          <Suspense fallback={<DashboardPlaceholder label="Worker profitability" />}>
            <WorkerProfitabilityRanking />
          </Suspense>
        </div>

        <div className="lg:col-span-6">
          <Suspense fallback={<DashboardPlaceholder label="Tip reconciliation" />}>
            <TipReconciliation />
          </Suspense>
        </div>

        <div className="lg:col-span-12">
          <Suspense fallback={<DashboardPlaceholder label="Pricing experiment" />}>
            <PricingExperimentRunner />
          </Suspense>
        </div>

        <div className="lg:col-span-6">
          <Suspense fallback={<DashboardPlaceholder label="Refund fraud queue" />}>
            <RefundFraudQueue />
          </Suspense>
        </div>

        <div className="lg:col-span-6">
          <Suspense fallback={<DashboardPlaceholder label="Chargeback drafts" />}>
            <ChargebackDrafts />
          </Suspense>
        </div>
      </div>
    </main>
  );
}

function DashboardPlaceholder({ label }: { label: string }) {
  return (
    <section className="rounded-2xl bg-slate-900/60 ring-1 ring-white/5 p-5 animate-pulse">
      <p className="text-xs text-slate-500">Loading {label}…</p>
    </section>
  );
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
