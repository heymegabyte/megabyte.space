import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { useCallback, useEffect, useState } from 'react';
import { adminFetch, formatCents } from '@theme.tools/billing/field-service/finance-shared';

interface Form1099Row {
  id: string;
  workerId: string;
  name: string;
  email: string | null;
  phone: string;
  ein: string | null;
  amount: number;
  pdfUrl: string | null;
  status: string;
  submittedAt: string | null;
  acceptedAt: string | null;
}

/**
 * /admin/finance/1099 — 1099-NEC e-file workbench. Pick a tax year,
 * Generate to aggregate `stripe_transfers` ≥ $600/worker into draft 1099-NEC
 * rows + R2-stored printable HTML, then drill into any worker to add TIN
 * + flip to "queued" for Track1099 / TaxBandits e-filing.
 */
export default function Form1099NecPage() {
  useThemeToolsSurface('form1099-nec-page');
  const now = new Date();
  const defaultYear = now.getUTCMonth() < 1 ? now.getUTCFullYear() - 1 : now.getUTCFullYear();
  const [taxYear, setTaxYear] = useState(defaultYear);
  const [rows, setRows] = useState<Form1099Row[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    try {
      const res = await adminFetch(`/api/admin/1099-nec/year/${taxYear}`);
      const json = (await res.json()) as { ok: boolean; forms?: Form1099Row[]; error?: string };
      if (!json.ok) throw new Error(json.error ?? 'load_failed');
      setRows(json.forms ?? []);
    } catch (err) {
      setError((err as Error).message);
    }
  }, [taxYear]);

  useEffect(() => {
    void load();
  }, [load]);

  async function generate() {
    setBusy(true);
    setError(null);
    try {
      const res = await adminFetch(`/api/admin/1099-nec/year/${taxYear}/generate`, {
        method: 'POST',
        body: '{}',
      });
      const json = (await res.json()) as { ok: boolean; error?: string };
      if (!json.ok) throw new Error(json.error ?? 'generate_failed');
      await load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function setTin(formId: string, tin: string) {
    if (!tin || !/^\d{2}-?\d{7}$|^\d{3}-?\d{2}-?\d{4}$/.test(tin)) {
      setError(`TIN must be EIN (XX-XXXXXXX) or SSN (XXX-XX-XXXX) format`);
      return;
    }
    setError(null);
    const res = await adminFetch(`/api/admin/1099-nec/${formId}/tin`, {
      method: 'PUT',
      body: JSON.stringify({ tin }),
    });
    const json = (await res.json()) as { ok: boolean; error?: string };
    if (!json.ok) setError(json.error ?? 'tin_failed');
    else await load();
  }

  async function submit(formId: string) {
    const res = await adminFetch(`/api/admin/1099-nec/${formId}/submit`, {
      method: 'POST',
      body: '{}',
    });
    const json = (await res.json()) as { ok: boolean; error?: string };
    if (!json.ok) setError(json.error ?? 'submit_failed');
    else await load();
  }

  const totalCents = rows ? rows.reduce((s, r) => s + r.amount, 0) : 0;

  return (
    <main className="min-h-screen bg-slate-950 text-white">
      <header className="border-b border-white/5 bg-slate-900/40 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
          <p className="text-xs uppercase tracking-wide text-cyan-300">
            Admin · Finance · 1099-NEC
          </p>
          <h1 className="text-2xl font-semibold mt-1">Year-end 1099-NEC e-file</h1>
          <p className="text-sm text-slate-400 mt-1 max-w-2xl">
            Every worker who earned ≥ $600 via Stripe Connect transfers in the selected tax year
            gets a draft 1099-NEC. Add their TIN, hit Submit to queue for Track1099 / TaxBandits
            filing.
          </p>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
        <section className="rounded-2xl bg-slate-900/60 ring-1 ring-white/5 p-5">
          <div className="flex flex-wrap items-end gap-3">
            <label className="block">
              <span className="text-xs text-slate-400 uppercase">Tax year</span>
              <input
                type="number"
                min={2020}
                max={2099}
                value={taxYear}
                onChange={(e) => setTaxYear(Number(e.target.value) || defaultYear)}
                className="block bg-slate-950/70 border border-white/10 rounded-md px-3 py-2 text-sm text-white mt-1 w-28"
              />
            </label>
            <button
              type="button"
              onClick={generate}
              disabled={busy}
              className="bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-slate-950 font-medium rounded-md px-4 py-2"
            >
              {busy ? 'Generating…' : `Generate ${taxYear} 1099-NECs`}
            </button>
            <button
              type="button"
              onClick={load}
              className="bg-slate-800 hover:bg-slate-700 text-white rounded-md px-3 py-2 text-sm"
            >
              Refresh
            </button>
            {totalCents > 0 && (
              <p className="text-sm text-slate-400 ml-auto">
                Total Box 1 NEC:{' '}
                <span className="text-white font-semibold">{formatCents(totalCents)}</span>
              </p>
            )}
          </div>
          {error && <p className="text-sm text-rose-400 mt-3">{error}</p>}
        </section>

        <section className="rounded-2xl bg-slate-900/60 ring-1 ring-white/5 overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-950/60 text-slate-400 text-xs uppercase">
              <tr>
                <th className="px-3 py-2 text-left">Worker</th>
                <th className="px-3 py-2 text-left">Contact</th>
                <th className="px-3 py-2 text-right">Box 1 NEC</th>
                <th className="px-3 py-2 text-left">TIN</th>
                <th className="px-3 py-2 text-left">Status</th>
                <th className="px-3 py-2 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {!rows && (
                <tr>
                  <td colSpan={6} className="px-3 py-6 text-center text-slate-500">
                    Loading…
                  </td>
                </tr>
              )}
              {rows && rows.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-3 py-6 text-center text-slate-500">
                    No 1099-NECs for {taxYear}. Click Generate to build them.
                  </td>
                </tr>
              )}
              {rows?.map((r) => (
                <tr key={r.id} className="border-t border-white/5">
                  <td className="px-3 py-2 text-white">{r.name}</td>
                  <td className="px-3 py-2 text-slate-400">
                    <div>{r.email ?? '—'}</div>
                    <div className="text-xs">{r.phone}</div>
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums text-white">
                    {formatCents(r.amount)}
                  </td>
                  <td className="px-3 py-2">
                    <TinEditor current={r.ein} onSave={(v) => setTin(r.id, v)} />
                  </td>
                  <td className="px-3 py-2">
                    <StatusPill status={r.status} />
                  </td>
                  <td className="px-3 py-2 text-right space-x-2">
                    {r.pdfUrl && (
                      <a
                        href={r.pdfUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-cyan-300 hover:underline text-xs"
                      >
                        PDF
                      </a>
                    )}
                    {r.status === 'draft' && (
                      <button
                        type="button"
                        onClick={() => submit(r.id)}
                        className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-md px-2 py-1 text-xs"
                      >
                        Queue file
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      </div>
    </main>
  );
}

function TinEditor({
  current,
  onSave,
}: {
  current: string | null;
  onSave: (value: string) => void;
}) {
  const [draft, setDraft] = useState(current ?? '');
  const [editing, setEditing] = useState(false);
  if (!editing) {
    return (
      <button
        type="button"
        className="text-slate-400 hover:text-white text-xs font-mono"
        onClick={() => setEditing(true)}
      >
        {current || 'add TIN'}
      </button>
    );
  }
  return (
    <div className="flex items-center gap-2">
      <input
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        placeholder="XX-XXXXXXX"
        className="bg-slate-950 border border-white/10 rounded px-2 py-1 text-xs font-mono w-32 text-white"
      />
      <button
        type="button"
        onClick={() => {
          onSave(draft);
          setEditing(false);
        }}
        className="text-cyan-300 hover:text-white text-xs"
      >
        save
      </button>
    </div>
  );
}

function StatusPill({ status }: { status: string }) {
  const styles: Record<string, string> = {
    draft: 'bg-slate-700 text-slate-300',
    queued: 'bg-amber-500/15 text-amber-300 ring-1 ring-amber-500/30',
    accepted: 'bg-emerald-500/15 text-emerald-300 ring-1 ring-emerald-500/30',
    rejected: 'bg-rose-500/15 text-rose-300 ring-1 ring-rose-500/30',
    corrected: 'bg-violet-500/15 text-violet-300 ring-1 ring-violet-500/30',
    voided: 'bg-slate-800 text-slate-500',
  };
  return (
    <span className={`px-2 py-0.5 rounded text-xs uppercase ${styles[status] ?? styles.draft}`}>
      {status}
    </span>
  );
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
