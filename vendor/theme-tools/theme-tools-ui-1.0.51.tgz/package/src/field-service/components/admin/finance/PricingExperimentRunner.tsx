import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { useEffect, useState } from 'react';
import { adminFetch, formatCents, formatPct } from '@theme.tools/billing/field-service/finance-shared';

interface ExperimentRow {
  id: string;
  name: string;
  hypothesis: string;
  variant_a: string;
  variant_b: string;
  allocation: number;
  status: string;
  started_at: string | null;
}

interface StatusResponse {
  ok: boolean;
  status: {
    experiment: ExperimentRow | null;
    bucketA: { conversions: number; revenueCents: number };
    bucketB: { conversions: number; revenueCents: number };
  } | null;
}

/**
 * Pricing experiment console. Shows the active A/B test (if any), with
 * live bucket conversion counts + revenue. Lets ops conclude the test
 * by declaring a winner (or starting a fresh one).
 */
export default function PricingExperimentRunner() {
  useThemeToolsSurface('pricing-experiment-runner');
  const [data, setData] = useState<StatusResponse['status']>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showNew, setShowNew] = useState(false);
  const [newExp, setNewExp] = useState({
    id: '',
    name: '',
    hypothesis: '',
    factorA: '1.0',
    factorB: '1.1',
    allocation: '0.5',
  });

  async function refresh() {
    setLoading(true);
    setError(null);
    try {
      const res = await adminFetch('/api/admin/finance/pricing-experiment', {
        method: 'POST',
        body: JSON.stringify({ action: 'status' }),
      });
      const json = (await res.json()) as StatusResponse;
      setData(json.status ?? null);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void refresh();
  }, []);

  async function startExperiment(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await adminFetch('/api/admin/finance/pricing-experiment', {
        method: 'POST',
        body: JSON.stringify({
          action: 'start',
          id: newExp.id.trim() || `exp-${Date.now()}`,
          name: newExp.name.trim(),
          hypothesis: newExp.hypothesis.trim(),
          variantA: { label: 'control', factors: { 'same-day': Number(newExp.factorA) } },
          variantB: { label: 'treatment', factors: { 'same-day': Number(newExp.factorB) } },
          allocation: Number(newExp.allocation),
        }),
      });
      const json = (await res.json()) as { ok: boolean; error?: string };
      if (!json.ok) throw new Error(json.error ?? 'Start failed');
      setShowNew(false);
      await refresh();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function conclude(winner: 'a' | 'b' | 'inconclusive') {
    if (!data?.experiment) return;
    setBusy(true);
    try {
      await adminFetch('/api/admin/finance/pricing-experiment', {
        method: 'POST',
        body: JSON.stringify({ action: 'conclude', id: data.experiment.id, winner }),
      });
      await refresh();
    } finally {
      setBusy(false);
    }
  }

  const exp = data?.experiment ?? null;
  const a = data?.bucketA ?? { conversions: 0, revenueCents: 0 };
  const b = data?.bucketB ?? { conversions: 0, revenueCents: 0 };
  const totalConv = a.conversions + b.conversions;
  const winnerHint = totalConv >= 10 ? (b.revenueCents > a.revenueCents ? 'b' : 'a') : null;

  return (
    <section className="rounded-2xl bg-slate-900/60 ring-1 ring-white/5 p-5">
      <header className="flex justify-between items-center mb-4">
        <div>
          <h3 className="text-base font-semibold text-white">Pricing experiment</h3>
          <p className="text-xs text-slate-400 mt-0.5">A/B surge multiplier tests</p>
        </div>
        {!exp && !showNew && (
          <button
            type="button"
            onClick={() => setShowNew(true)}
            className="text-sm px-3 py-1.5 rounded-md bg-cyan-500/20 text-cyan-200 hover:bg-cyan-500/30 ring-1 ring-cyan-500/40"
          >
            Start experiment
          </button>
        )}
      </header>

      {loading && <p className="text-sm text-slate-400">Loading…</p>}
      {error && <p className="text-sm text-rose-400 mb-3">{error}</p>}

      {!loading && !exp && !showNew && (
        <p className="text-sm text-slate-500">
          No experiment running. Start one to A/B-test pricing.
        </p>
      )}

      {showNew && (
        <form onSubmit={startExperiment} className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
          <input
            type="text"
            value={newExp.name}
            onChange={(e) => setNewExp({ ...newExp, name: e.target.value })}
            placeholder="Name (e.g. Same-day surge 1.35 vs 1.40)"
            className="sm:col-span-2 bg-slate-950/70 border border-white/10 rounded-md px-3 py-2 text-sm text-white"
            required
          />
          <input
            type="text"
            value={newExp.hypothesis}
            onChange={(e) => setNewExp({ ...newExp, hypothesis: e.target.value })}
            placeholder="Hypothesis"
            className="sm:col-span-2 bg-slate-950/70 border border-white/10 rounded-md px-3 py-2 text-sm text-white"
            required
          />
          <label className="text-xs text-slate-400">
            Variant A same-day factor
            <input
              type="number"
              step="0.01"
              value={newExp.factorA}
              onChange={(e) => setNewExp({ ...newExp, factorA: e.target.value })}
              className="mt-1 w-full bg-slate-950/70 border border-white/10 rounded-md px-3 py-2 text-sm text-white"
            />
          </label>
          <label className="text-xs text-slate-400">
            Variant B same-day factor
            <input
              type="number"
              step="0.01"
              value={newExp.factorB}
              onChange={(e) => setNewExp({ ...newExp, factorB: e.target.value })}
              className="mt-1 w-full bg-slate-950/70 border border-white/10 rounded-md px-3 py-2 text-sm text-white"
            />
          </label>
          <label className="text-xs text-slate-400 sm:col-span-2">
            Allocation to B (0-1)
            <input
              type="number"
              step="0.05"
              min="0"
              max="1"
              value={newExp.allocation}
              onChange={(e) => setNewExp({ ...newExp, allocation: e.target.value })}
              className="mt-1 w-full bg-slate-950/70 border border-white/10 rounded-md px-3 py-2 text-sm text-white"
            />
          </label>
          <div className="sm:col-span-2 flex gap-2">
            <button
              type="submit"
              disabled={busy}
              className="bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-slate-950 font-medium rounded-md py-2 px-4 text-sm"
            >
              {busy ? 'Starting…' : 'Start'}
            </button>
            <button
              type="button"
              onClick={() => setShowNew(false)}
              className="text-sm text-slate-400 hover:text-white px-4"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      {exp && (
        <div className="space-y-4">
          <div>
            <p className="text-sm font-medium text-white">{exp.name}</p>
            <p className="text-xs text-slate-400 mt-0.5">{exp.hypothesis}</p>
            <p className="text-xs text-slate-500 mt-1">
              Allocation {formatPct(exp.allocation, 0)} to B · started{' '}
              {exp.started_at ? new Date(exp.started_at).toLocaleDateString() : '—'}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {[
              { name: 'A', stats: a, winning: winnerHint === 'a' },
              { name: 'B', stats: b, winning: winnerHint === 'b' },
            ].map((v) => (
              <div
                key={v.name}
                className={
                  'rounded-xl p-4 ring-1 ' +
                  (v.winning
                    ? 'bg-emerald-500/10 ring-emerald-500/30'
                    : 'bg-slate-950/60 ring-white/10')
                }
              >
                <p className="text-xs text-slate-400 uppercase">Variant {v.name}</p>
                <p className="text-2xl font-semibold text-white tabular-nums mt-1">
                  {v.stats.conversions}
                </p>
                <p className="text-xs text-slate-500">conversions</p>
                <p className="text-sm text-emerald-300 mt-2 tabular-nums">
                  {formatCents(v.stats.revenueCents)}
                </p>
              </div>
            ))}
          </div>

          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => conclude('a')}
              disabled={busy}
              className="text-xs px-3 py-1.5 rounded-md bg-white/5 hover:bg-white/10 text-slate-200"
            >
              Winner: A
            </button>
            <button
              type="button"
              onClick={() => conclude('b')}
              disabled={busy}
              className="text-xs px-3 py-1.5 rounded-md bg-white/5 hover:bg-white/10 text-slate-200"
            >
              Winner: B
            </button>
            <button
              type="button"
              onClick={() => conclude('inconclusive')}
              disabled={busy}
              className="text-xs px-3 py-1.5 rounded-md bg-white/5 hover:bg-white/10 text-slate-400"
            >
              Inconclusive
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
