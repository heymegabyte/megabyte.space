import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { POWER_WASH_PROTOCOLS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { useEffect, useState } from 'react';
import { adminFetch, defaultRange, formatCents } from '@theme.tools/billing/field-service/finance-shared';

interface Bucket {
  key: string;
  label: string;
  revenueCents: number;
  costCents: number;
  profitCents: number;
  bookings: number;
}

/**
 * Profit-by-service horizontal bar chart. Compares margin per service
 * slug — surfaces which services are net-positive (and which are loss
 * leaders we keep for cross-sell). Pure CSS bars, no chart lib.
 */
export default function ProfitByService() {
  useThemeToolsSurface('profit-by-service');
  const [rows, setRows] = useState<Bucket[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const range = defaultRange(30);
    adminFetch(
      `/api/admin/finance/profit-by-service?from=${encodeURIComponent(range.fromIso)}&to=${encodeURIComponent(range.toIso)}`,
    )
      .then((r) => r.json() as Promise<{ ok: boolean; buckets: Bucket[] }>)
      .then((j) => setRows(j.buckets ?? []))
      .catch((e: Error) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  const max = rows.reduce((m, r) => Math.max(m, Math.abs(r.profitCents)), 1);

  return (
    <section className="rounded-2xl bg-slate-900/60 ring-1 ring-white/5 p-5">
      <header className="mb-4">
        <h3 className="text-base font-semibold text-white">Profit by service</h3>
        <p className="text-xs text-slate-400 mt-0.5">
          Last 30 days · split evenly per multi-service job
        </p>
      </header>

      {loading && <p className="text-sm text-slate-400">Loading…</p>}
      {error && <p className="text-sm text-rose-400">{error}</p>}
      {!loading && rows.length === 0 && <p className="text-sm text-slate-500">No data yet.</p>}

      <ul className="space-y-2.5">
        {rows.slice(0, 12).map((r) => {
          const pct = (Math.abs(r.profitCents) / max) * 100;
          const positive = r.profitCents >= 0;
          return (
            <li key={r.key} className="text-sm">
              <div className="flex justify-between items-baseline mb-1">
                <span className="text-slate-200">{r.label}</span>
                <span
                  className={
                    'tabular-nums font-medium ' + (positive ? 'text-emerald-300' : 'text-rose-300')
                  }
                >
                  {formatCents(r.profitCents)}
                </span>
              </div>
              <div className="h-2 rounded-full bg-white/5 overflow-hidden">
                <div
                  className={positive ? 'h-full bg-emerald-500/70' : 'h-full bg-rose-500/70'}
                  style={{ width: `${pct.toFixed(1)}%` }}
                />
              </div>
              <div className="flex justify-between text-xs text-slate-500 mt-1">
                <span>{r.bookings} jobs</span>
                <span>
                  rev {formatCents(r.revenueCents)} · cost {formatCents(r.costCents)}
                </span>
              </div>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
export const THEME_TOOLS_POWER_WASH_PROTOCOLS_COUNT = Object.keys(POWER_WASH_PROTOCOLS).length;
