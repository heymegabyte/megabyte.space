import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { useEffect, useState } from 'react';
import { adminFetch, defaultRange, formatCents } from '@theme.tools/billing/field-service/finance-shared';

interface Bucket {
  key: string;
  label: string;
  revenueCents: number;
  costCents: number;
  profitCents: number;
  bookings: number;
}

/**
 * Profit-by-ZIP ranking — table sorted by profit descending. Top 20
 * surfaces immediate decisions ("which ZIPs deserve more ad spend?").
 */
export default function ProfitByZip() {
  useThemeToolsSurface('profit-by-zip');
  const [rows, setRows] = useState<Bucket[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const range = defaultRange(30);
    adminFetch(
      `/api/admin/finance/profit-by-zip?from=${encodeURIComponent(range.fromIso)}&to=${encodeURIComponent(range.toIso)}`,
    )
      .then((r) => r.json() as Promise<{ ok: boolean; buckets: Bucket[] }>)
      .then((j) => setRows(j.buckets ?? []))
      .catch((e: Error) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <section className="rounded-2xl bg-slate-900/60 ring-1 ring-white/5 p-5">
      <header className="mb-4">
        <h3 className="text-base font-semibold text-white">Profit by ZIP</h3>
        <p className="text-xs text-slate-400 mt-0.5">Last 30 days · top 20</p>
      </header>

      {loading && <p className="text-sm text-slate-400">Loading…</p>}
      {error && <p className="text-sm text-rose-400">{error}</p>}
      {!loading && rows.length === 0 && (
        <p className="text-sm text-slate-500">No completed jobs in range.</p>
      )}

      {rows.length > 0 && (
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="text-xs text-slate-400 uppercase tracking-wide border-b border-white/5">
              <tr>
                <th className="text-left py-2 pr-3">ZIP</th>
                <th className="text-right py-2 px-2">Jobs</th>
                <th className="text-right py-2 px-2">Revenue</th>
                <th className="text-right py-2 px-2">Cost</th>
                <th className="text-right py-2 pl-2">Profit</th>
              </tr>
            </thead>
            <tbody>
              {rows.slice(0, 20).map((r) => (
                <tr key={r.key} className="border-b border-white/5 last:border-0">
                  <td className="py-2 pr-3 font-mono text-white">{r.label}</td>
                  <td className="text-right py-2 px-2 text-slate-300 tabular-nums">{r.bookings}</td>
                  <td className="text-right py-2 px-2 text-slate-300 tabular-nums">
                    {formatCents(r.revenueCents)}
                  </td>
                  <td className="text-right py-2 px-2 text-slate-500 tabular-nums">
                    {formatCents(r.costCents)}
                  </td>
                  <td
                    className={
                      'text-right py-2 pl-2 font-semibold tabular-nums ' +
                      (r.profitCents >= 0 ? 'text-emerald-300' : 'text-rose-300')
                    }
                  >
                    {formatCents(r.profitCents)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
