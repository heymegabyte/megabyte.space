import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { useState } from 'react';
import { adminFetch, formatCents } from '@theme.tools/billing/field-service/finance-shared';

interface AnalyzeResult {
  ok: boolean;
  score: number;
  verdict: 'allow' | 'review' | 'block';
  signals: Array<{ kind: string; weight: number; detail: string }>;
  reasoning: string;
}

/**
 * Refund-fraud analysis workbench. Ops pastes booking id + customer
 * email + amount + reason, hits Analyze, sees a 0-100 risk score with
 * structured signals. LLM second opinion fires in the ambiguous middle
 * band — see refund-fraud-detector.ts.
 */
export default function RefundFraudQueue() {
  useThemeToolsSurface('refund-fraud-queue');
  const [bookingId, setBookingId] = useState('');
  const [email, setEmail] = useState('');
  const [amount, setAmount] = useState('');
  const [reason, setReason] = useState('');
  const [result, setResult] = useState<AnalyzeResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onAnalyze(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const cents = Math.round(parseFloat(amount) * 100);
      if (!isFinite(cents) || cents <= 0) throw new Error('Enter a valid amount.');
      const res = await adminFetch('/api/admin/finance/refund/analyze', {
        method: 'POST',
        body: JSON.stringify({
          bookingId: bookingId.trim(),
          customerEmail: email.trim(),
          amountCents: cents,
          reason: reason.trim(),
        }),
      });
      const json = (await res.json()) as AnalyzeResult | { error: string };
      if (!('ok' in json) || !json.ok) throw new Error((json as { error: string }).error);
      setResult(json);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  const verdictStyles: Record<string, string> = {
    allow: 'bg-emerald-500/15 text-emerald-300 ring-emerald-500/30',
    review: 'bg-amber-500/15 text-amber-300 ring-amber-500/30',
    block: 'bg-rose-500/15 text-rose-300 ring-rose-500/30',
  };

  return (
    <section className="rounded-2xl bg-slate-900/60 ring-1 ring-white/5 p-5">
      <header className="mb-4">
        <h3 className="text-base font-semibold text-white">Refund fraud analyzer</h3>
        <p className="text-xs text-slate-400 mt-0.5">
          Heuristics + Haiku second opinion for ambiguous cases (35-65)
        </p>
      </header>

      <form onSubmit={onAnalyze} className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
        <input
          type="text"
          value={bookingId}
          onChange={(e) => setBookingId(e.target.value)}
          placeholder="Booking id"
          className="bg-slate-950/70 border border-white/10 rounded-md px-3 py-2 text-sm text-white"
          required
        />
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Customer email"
          className="bg-slate-950/70 border border-white/10 rounded-md px-3 py-2 text-sm text-white"
          required
        />
        <input
          type="number"
          step="0.01"
          min="0"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="Amount ($)"
          className="bg-slate-950/70 border border-white/10 rounded-md px-3 py-2 text-sm text-white"
          required
        />
        <input
          type="text"
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="Stated reason"
          className="bg-slate-950/70 border border-white/10 rounded-md px-3 py-2 text-sm text-white"
          required
        />
        <button
          type="submit"
          disabled={loading}
          className="sm:col-span-2 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 disabled:cursor-not-allowed text-slate-950 font-medium rounded-md py-2 transition-colors"
        >
          {loading ? 'Analyzing…' : 'Analyze refund'}
        </button>
      </form>

      {error && <p className="text-sm text-rose-400 mb-3">{error}</p>}

      {result && (
        <div className="rounded-xl bg-slate-950/60 ring-1 ring-white/10 p-4">
          <div className="flex items-center justify-between mb-3">
            <div>
              <span className="text-xs text-slate-400 uppercase">Risk score</span>
              <p className="text-3xl font-semibold text-white tabular-nums">{result.score}</p>
            </div>
            <span
              className={`px-3 py-1 text-xs uppercase tracking-wide rounded-full ring-1 ${
                verdictStyles[result.verdict] ?? ''
              }`}
            >
              {result.verdict}
            </span>
          </div>

          <ul className="space-y-1.5 text-sm">
            {result.signals.map((s, i) => (
              <li
                key={i}
                className="flex justify-between gap-3 border-t border-white/5 pt-1.5 first:border-0 first:pt-0"
              >
                <span className="text-slate-300">{s.detail}</span>
                <span className="text-xs text-amber-300 tabular-nums">+{s.weight}</span>
              </li>
            ))}
            {result.signals.length === 0 && (
              <li className="text-slate-500 text-sm">No fraud signals detected.</li>
            )}
          </ul>

          {result.reasoning && (
            <p className="text-xs text-slate-400 mt-3 pt-3 border-t border-white/5">
              <span className="text-slate-500">Reasoning: </span>
              {result.reasoning}
            </p>
          )}

          {bookingId && amount && (
            <p className="text-xs text-slate-500 mt-3">
              Disputed amount:{' '}
              <span className="text-slate-300">
                {formatCents(Math.round(parseFloat(amount) * 100))}
              </span>
            </p>
          )}
        </div>
      )}
    </section>
  );
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
