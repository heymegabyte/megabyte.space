import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { useEffect, useState } from 'react';
import { adminFetch, formatCents } from '@theme.tools/billing/field-service/finance-shared';

interface ForecastPoint {
  date: string;
  cents: number;
  low: number;
  high: number;
}

interface ForecastResponse {
  ok: boolean;
  days: number;
  points: ForecastPoint[];
  totalCents: number;
}

/**
 * 14/30/90-day revenue forecast — pure SVG bar+band chart, no chart lib.
 * Tall cyan bar is the median projection; light cyan band is the ±25%
 * confidence range. Hover scrub shows the date + cents.
 */
export default function RevenueForecastChart({ days = 14 }: { days?: number }) {
  useThemeToolsSurface('revenue-forecast-chart');
  const [data, setData] = useState<ForecastResponse | null>(null);
  const [horizon, setHorizon] = useState(days);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    adminFetch(`/api/admin/finance/forecast?days=${horizon}`)
      .then((r) => r.json() as Promise<ForecastResponse | { error: string }>)
      .then((j) => {
        if (cancelled) return;
        if ('ok' in j && j.ok) setData(j);
        else setError('Forecast unavailable');
      })
      .catch((e: Error) => !cancelled && setError(e.message))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [horizon]);

  const points = data?.points ?? [];
  const maxHigh = points.reduce((m, p) => Math.max(m, p.high), 0) || 1;

  return (
    <section className="rounded-2xl bg-slate-900/60 ring-1 ring-white/5 p-5">
      <header className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-base font-semibold text-white">Revenue forecast</h3>
          <p className="text-xs text-slate-400 mt-0.5">
            90-day trailing median × day-of-week, ±25% band
          </p>
        </div>
        <div className="flex gap-1">
          {[14, 30, 90].map((d) => (
            <button
              key={d}
              type="button"
              onClick={() => setHorizon(d)}
              className={
                horizon === d
                  ? 'px-3 py-1 text-xs rounded-md bg-cyan-500/20 text-cyan-200 ring-1 ring-cyan-500/40'
                  : 'px-3 py-1 text-xs rounded-md text-slate-400 hover:text-white hover:bg-white/5'
              }
            >
              {d}d
            </button>
          ))}
        </div>
      </header>

      {loading && <p className="text-sm text-slate-400">Loading forecast…</p>}
      {error && <p className="text-sm text-rose-400">{error}</p>}

      {data && !loading && (
        <>
          <p className="text-2xl font-semibold text-cyan-300 tabular-nums mb-3">
            {formatCents(data.totalCents)}{' '}
            <span className="text-sm text-slate-400 font-normal">/ {horizon}d</span>
          </p>

          <div className="overflow-x-auto pb-2">
            <svg
              viewBox={`0 0 ${Math.max(280, points.length * 24)} 140`}
              className="w-full h-36"
              role="img"
              aria-label={`Revenue forecast for next ${horizon} days`}
            >
              {points.map((p, i) => {
                const x = i * 24 + 12;
                const yMid = 130 - (p.cents / maxHigh) * 110;
                const yHigh = 130 - (p.high / maxHigh) * 110;
                const yLow = 130 - (p.low / maxHigh) * 110;
                return (
                  <g key={p.date}>
                    <title>{`${p.date}: ${formatCents(p.cents)} (±${formatCents(p.cents - p.low)})`}</title>
                    <line
                      x1={x}
                      x2={x}
                      y1={yHigh}
                      y2={yLow}
                      stroke="rgb(34 211 238 / 0.25)"
                      strokeWidth={6}
                      strokeLinecap="round"
                    />
                    <circle cx={x} cy={yMid} r={3} fill="rgb(34 211 238)" />
                  </g>
                );
              })}
              <line x1={0} x2="100%" y1={130} y2={130} stroke="rgb(255 255 255 / 0.08)" />
            </svg>
          </div>
        </>
      )}
    </section>
  );
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
