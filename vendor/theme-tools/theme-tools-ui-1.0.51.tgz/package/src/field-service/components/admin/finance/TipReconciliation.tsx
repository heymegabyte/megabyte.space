import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { useEffect, useState } from 'react';
import { adminFetch, defaultRange, formatCents } from '@theme.tools/billing/field-service/finance-shared';

interface TipRow {
  id: string;
  booking_id: string;
  worker_id: string;
  worker_name: string | null;
  cents: number;
  channel: 'square' | 'venmo' | 'cashapp';
  settled_at: string | null;
  customer_message: string | null;
}

const CHANNEL_BADGE: Record<string, string> = {
  square: 'bg-blue-500/15 text-blue-300 ring-blue-500/30',
  venmo: 'bg-sky-500/15 text-sky-300 ring-sky-500/30',
  cashapp: 'bg-emerald-500/15 text-emerald-300 ring-emerald-500/30',
};

/**
 * Tip reconciliation table — last 30 days of recorded tips across all
 * channels. Square is webhook-driven (auto-settled); Venmo / CashApp are
 * manual reconciliations with a customer memo for context.
 */
export default function TipReconciliation() {
  useThemeToolsSurface('tip-reconciliation');
  const [tips, setTips] = useState<TipRow[]>([]);
  const [totalCents, setTotalCents] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const range = defaultRange(30);
    adminFetch(
      `/api/admin/finance/tips?from=${encodeURIComponent(range.fromIso)}&to=${encodeURIComponent(range.toIso)}`,
    )
      .then((r) => r.json() as Promise<{ ok: boolean; tips: TipRow[]; totalCents: number }>)
      .then((j) => {
        setTips(j.tips ?? []);
        setTotalCents(j.totalCents ?? 0);
      })
      .catch((e: Error) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <section className="rounded-2xl bg-slate-900/60 ring-1 ring-white/5 p-5">
      <header className="flex items-baseline justify-between mb-4">
        <div>
          <h3 className="text-base font-semibold text-white">Tip reconciliation</h3>
          <p className="text-xs text-slate-400 mt-0.5">Last 30 days · all channels</p>
        </div>
        <p className="text-lg font-semibold text-emerald-300 tabular-nums">
          {formatCents(totalCents)}
        </p>
      </header>

      {loading && <p className="text-sm text-slate-400">Loading…</p>}
      {error && <p className="text-sm text-rose-400">{error}</p>}
      {!loading && tips.length === 0 && (
        <p className="text-sm text-slate-500">No tips recorded in range.</p>
      )}

      {tips.length > 0 && (
        <div className="overflow-x-auto max-h-80 overflow-y-auto">
          <table className="min-w-full text-sm">
            <thead className="text-xs text-slate-400 uppercase tracking-wide sticky top-0 bg-slate-900/95 backdrop-blur">
              <tr>
                <th className="text-left py-2 pr-3">Date</th>
                <th className="text-left py-2 px-2">Worker</th>
                <th className="text-left py-2 px-2">Channel</th>
                <th className="text-right py-2 pl-2">Amount</th>
              </tr>
            </thead>
            <tbody>
              {tips.map((t) => (
                <tr key={t.id} className="border-b border-white/5 last:border-0">
                  <td className="py-2 pr-3 text-slate-400 text-xs">
                    {t.settled_at ? new Date(t.settled_at).toLocaleDateString() : '—'}
                  </td>
                  <td className="py-2 px-2 text-white">
                    {t.worker_name ?? t.worker_id.slice(0, 8)}
                  </td>
                  <td className="py-2 px-2">
                    <span
                      className={`inline-block px-2 py-0.5 text-xs rounded-full ring-1 ${
                        CHANNEL_BADGE[t.channel] ??
                        'bg-slate-500/15 text-slate-300 ring-slate-500/30'
                      }`}
                    >
                      {t.channel}
                    </span>
                  </td>
                  <td className="text-right py-2 pl-2 font-medium text-emerald-300 tabular-nums">
                    {formatCents(t.cents)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
