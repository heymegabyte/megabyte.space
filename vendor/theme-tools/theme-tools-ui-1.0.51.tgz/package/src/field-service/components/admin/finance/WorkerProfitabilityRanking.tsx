import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { useEffect, useState } from 'react';
import { adminFetch, defaultRange, formatCents } from '@theme.tools/billing/field-service/finance-shared';

interface Bucket {
  key: string;
  label: string;
  revenueCents: number;
  costCents: number;
  profitCents: number;
  bookings: number;
}

/**
 * Worker profitability leaderboard. Sorts by profit contribution (revenue
 * attributed via gig_claims minus wage cost). Top 10 surfaces the crew
 * who consistently bill out.
 */
export default function WorkerProfitabilityRanking() {
  useThemeToolsSurface('worker-profitability-ranking');
  const [rows, setRows] = useState<Bucket[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const range = defaultRange(30);
    adminFetch(
      `/api/admin/finance/worker-profitability?from=${encodeURIComponent(range.fromIso)}&to=${encodeURIComponent(range.toIso)}`,
    )
      .then((r) => r.json() as Promise<{ ok: boolean; buckets: Bucket[] }>)
      .then((j) => setRows(j.buckets ?? []))
      .catch((e: Error) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <section className="rounded-2xl bg-slate-900/60 ring-1 ring-white/5 p-5">
      <header className="mb-4">
        <h3 className="text-base font-semibold text-white">Worker profitability</h3>
        <p className="text-xs text-slate-400 mt-0.5">Last 30 days · revenue − wage cost</p>
      </header>

      {loading && <p className="text-sm text-slate-400">Loading…</p>}
      {error && <p className="text-sm text-rose-400">{error}</p>}
      {!loading && rows.length === 0 && (
        <p className="text-sm text-slate-500">No completed claims yet.</p>
      )}

      {rows.length > 0 && (
        <ol className="space-y-2">
          {rows.slice(0, 10).map((r, i) => (
            <li
              key={r.key}
              className="flex items-center justify-between gap-3 py-2 border-b border-white/5 last:border-0"
            >
              <div className="flex items-center gap-3">
                <span className="w-6 text-xs text-slate-500 tabular-nums">#{i + 1}</span>
                <span className="text-sm text-white">{r.label || 'Unknown'}</span>
              </div>
              <div className="text-right">
                <span className="text-sm font-semibold text-emerald-300 tabular-nums">
                  {formatCents(r.profitCents)}
                </span>
                <span className="text-xs text-slate-500 block">{r.bookings} jobs</span>
              </div>
            </li>
          ))}
        </ol>
      )}
    </section>
  );
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
