import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import type { OpsDailySummary } from '@theme.tools/crm/field-service/admin-ops-types';

interface Props {
  summary: OpsDailySummary | null;
  onGenerate?: (kind: OpsDailySummary['kind']) => void;
  generating?: boolean;
}

/**
 * AiDailySummaryCard — renders the most recent Claude-generated digest
 * (markdown-lite) with a "Generate now" button. Markdown rendering is
 * intentionally tiny — bold + bullet conversion only. The summary itself
 * is short (~200 words) so the dashboard never has to virtualize.
 */
export default function AiDailySummaryCard({ summary, onGenerate, generating }: Props) {
  useThemeToolsSurface('ai-daily-summary-card');
  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-950 p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h3 className="text-sm font-medium uppercase tracking-wide text-zinc-400">
            AI ops summary
          </h3>
          {summary && (
            <p className="text-xs text-zinc-500">
              {summary.kind.replace('_', ' ')} · {new Date(summary.generated_at).toLocaleString()}
            </p>
          )}
        </div>
        {onGenerate && (
          <div className="flex flex-wrap gap-2">
            <SummaryButton
              label="Daily"
              kind="daily"
              onGenerate={onGenerate}
              generating={generating}
            />
            <SummaryButton
              label="Weekly board"
              kind="weekly_board"
              onGenerate={onGenerate}
              generating={generating}
            />
            <SummaryButton
              label="Weekly marketing"
              kind="weekly_marketing"
              onGenerate={onGenerate}
              generating={generating}
            />
          </div>
        )}
      </div>
      {summary ? (
        <div className="prose prose-invert mt-4 max-w-none text-sm">
          {renderTinyMarkdown(summary.summary_md)}
        </div>
      ) : (
        <p className="mt-4 text-sm text-zinc-400">No summary yet — click Daily to generate one.</p>
      )}
    </div>
  );
}

function SummaryButton({
  label,
  kind,
  onGenerate,
  generating,
}: {
  label: string;
  kind: OpsDailySummary['kind'];
  onGenerate: (k: OpsDailySummary['kind']) => void;
  generating?: boolean;
}) {
  return (
    <button
      type="button"
      disabled={generating}
      onClick={() => onGenerate(kind)}
      className="rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-1.5 text-xs font-medium text-zinc-200 hover:bg-zinc-800 disabled:cursor-not-allowed disabled:opacity-50"
    >
      {generating ? 'Generating…' : label}
    </button>
  );
}

/**
 * Tiny markdown subset: paragraph splits on blank line, `**bold**`, lines
 * starting with `- ` become bullets. Anything else passes through. Kept
 * intentionally minimal — the Anthropic prompt asks for short output, so
 * full markdown parsing would be overkill.
 */
function renderTinyMarkdown(md: string): React.ReactNode {
  const blocks = md.split(/\n{2,}/);
  return blocks.map((block, i) => {
    const lines = block.split('\n');
    const isList = lines.every((l) => l.trim().startsWith('-') || l.trim() === '');
    if (isList) {
      return (
        <ul key={i} className="my-2 list-disc space-y-1 pl-5 text-zinc-200">
          {lines
            .filter((l) => l.trim().startsWith('-'))
            .map((l, j) => (
              <li key={j}>{renderInline(l.replace(/^\s*-\s*/, ''))}</li>
            ))}
        </ul>
      );
    }
    return (
      <p key={i} className="my-2 text-zinc-200">
        {renderInline(block)}
      </p>
    );
  });
}

function renderInline(text: string): React.ReactNode {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((p, i) =>
    p.startsWith('**') && p.endsWith('**') ? (
      <strong key={i} className="font-semibold text-white">
        {p.slice(2, -2)}
      </strong>
    ) : (
      <span key={i}>{p}</span>
    ),
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
