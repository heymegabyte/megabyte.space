import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import type { CostPerBooking } from '@theme.tools/crm/field-service/admin-ops-types';
import { formatCents } from '@theme.tools/crm/field-service/admin-ops-types';

interface Props {
  data: CostPerBooking | null;
}

/**
 * CostPerBookingCard — one big number with the breakdown stacked beneath.
 * Pure presentational; data comes from /api/admin/cost-per-booking.
 */
export default function CostPerBookingCard({ data }: Props) {
  useThemeToolsSurface('cost-per-booking-card');
  if (!data) {
    return (
      <div className="rounded-xl border border-zinc-800 bg-zinc-950 p-6 text-center">
        <p className="text-zinc-400">No cost-per-booking data yet.</p>
      </div>
    );
  }
  const rows = [
    { label: 'Twilio SMS', value: data.breakdown_cents.twilio, raw: data.inputs.twilio_messages },
    { label: 'Resend email', value: data.breakdown_cents.resend, raw: data.inputs.resend_emails },
    {
      label: 'Stripe fees',
      value: data.breakdown_cents.stripe_fees,
      raw: formatCents(data.inputs.stripe_charges_cents),
    },
    {
      label: 'Worker payouts',
      value: data.breakdown_cents.worker_payouts,
      raw: data.inputs.completed_bookings + ' completed',
    },
    { label: 'Ad spend', value: data.breakdown_cents.ad_spend, raw: 'manual' },
  ];
  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-950 p-4">
      <h3 className="text-sm font-medium uppercase tracking-wide text-zinc-400">
        Cost per booking
      </h3>
      <p className="mt-2 text-3xl font-semibold tabular-nums text-emerald-300">
        {formatCents(data.cost_per_booking_cents)}
        <span className="ml-2 text-xs font-normal text-zinc-500">
          / booking · {data.range_days}d window
        </span>
      </p>
      <ul className="mt-4 divide-y divide-zinc-800 text-sm">
        {rows.map((r) => (
          <li key={r.label} className="flex items-center justify-between py-2">
            <span className="text-zinc-300">{r.label}</span>
            <span className="flex items-baseline gap-2">
              <span className="text-xs text-zinc-500">{String(r.raw)}</span>
              <span className="font-mono tabular-nums text-zinc-100">{formatCents(r.value)}</span>
            </span>
          </li>
        ))}
      </ul>
      <p className="mt-3 text-xs text-zinc-500">
        Total platform cost: {formatCents(data.total_cost_cents)}
      </p>
    </div>
  );
}
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
