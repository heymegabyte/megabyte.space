import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useMemo, useState } from 'react';
import AnomalyBoard from './AnomalyBoard.js';
import ChurnRiskList from './ChurnRiskList.js';
import DemandHeatmap from './DemandHeatmap.js';
import UnitEconWaterfall from './UnitEconWaterfall.js';
import SloDashboard from './SloDashboard.js';
import AiDailySummaryCard from './AiDailySummaryCard.js';
import CostPerBookingCard from './CostPerBookingCard.js';
import type {
  Anomaly,
  ChurnRow,
  DemandCell,
  UnitEconRow,
  SloStatus,
  OpsDailySummary,
  CostPerBooking,
} from '@theme.tools/crm/field-service/admin-ops-types';

const KEY_STORAGE = 'bcl-admin-key-v1';

interface State {
  anomalies: Anomaly[];
  churn: ChurnRow[];
  demand: DemandCell[];
  unitEcon: UnitEconRow | null;
  slos: SloStatus[];
  summary: OpsDailySummary | null;
  costPerBooking: CostPerBooking | null;
}

const EMPTY: State = {
  anomalies: [],
  churn: [],
  demand: [],
  unitEcon: null,
  slos: [],
  summary: null,
  costPerBooking: null,
};

/**
 * /admin/ops dashboard — aggregates every Wave-7 surface into a single page.
 * Bearer token is read from `localStorage[bcl-admin-key-v1]` (set by the
 * existing `/admin` login form). All API calls use the `/api/admin/ops/*`
 * endpoints; data refreshes on mount + every 60s while the page is open.
 */
export default function OpsHealthDashboard() {
  useThemeToolsSurface('ops-health-dashboard');
  const [token, setToken] = useState<string>(() => {
    try {
      return localStorage.getItem(KEY_STORAGE) ?? '';
    } catch {
      return '';
    }
  });
  const [state, setState] = useState<State>(EMPTY);
  const [busy, setBusy] = useState<string | null>(null);
  const [generatingSummary, setGeneratingSummary] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const headers = useMemo(
    () => ({ Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }),
    [token],
  );

  const loadAll = useCallback(async () => {
    if (!token) return;
    setError(null);
    try {
      const [anomalies, slos, cost] = await Promise.all([
        fetch('/api/admin/ops/anomalies?status=open', { headers }).then((r) =>
          r.ok ? r.json() : { anomalies: [] },
        ),
        fetch('/api/admin/ops/health', { headers }).then((r) => (r.ok ? r.json() : { slos: [] })),
        fetch('/api/admin/cost-per-booking?range=30d', { headers }).then((r) =>
          r.ok ? r.json() : null,
        ),
      ]);
      setState((s) => ({
        ...s,
        anomalies: (anomalies?.anomalies as Anomaly[]) ?? [],
        slos: (slos?.slos as SloStatus[]) ?? [],
        costPerBooking: cost as CostPerBooking | null,
      }));
    } catch (err) {
      setError((err as Error).message);
    }
  }, [headers, token]);

  useEffect(() => {
    document.title = 'Ops Health — Brick Labor';
  }, []);

  useEffect(() => {
    void loadAll();
    if (!token) return;
    const id = window.setInterval(() => void loadAll(), 60_000);
    return () => window.clearInterval(id);
  }, [loadAll, token]);

  async function runAnomalies() {
    if (!token) return;
    setBusy('anomalies');
    try {
      await fetch('/api/admin/ops/run-anomalies', {
        method: 'POST',
        headers,
        body: JSON.stringify({}),
      });
      await loadAll();
    } finally {
      setBusy(null);
    }
  }

  async function resolveAnomaly(id: string) {
    if (!token) return;
    await fetch(`/api/admin/ops/anomalies/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      headers,
    });
    await loadAll();
  }

  async function generateSummary(kind: OpsDailySummary['kind']) {
    if (!token) return;
    setGeneratingSummary(true);
    try {
      const res = await fetch('/api/admin/ops/daily-summary', {
        method: 'POST',
        headers,
        body: JSON.stringify({ kind }),
      });
      const data = (await res.json()) as { ok: boolean; summary?: OpsDailySummary };
      if (data.ok && data.summary) {
        setState((s) => ({ ...s, summary: data.summary as OpsDailySummary }));
      }
    } finally {
      setGeneratingSummary(false);
    }
  }

  function saveToken(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new FormData(form);
    const t = String(data.get('token') ?? '');
    if (!t) return;
    try {
      localStorage.setItem(KEY_STORAGE, t);
    } catch {
      /* noop */
    }
    setToken(t);
  }

  if (!token) {
    return (
      <main className="mx-auto max-w-md p-6">
        <h1 className="mb-4 text-2xl font-semibold text-zinc-100">Ops Health</h1>
        <form onSubmit={saveToken} className="rounded-xl border border-zinc-800 bg-zinc-950 p-4">
          <label htmlFor="ops-token" className="text-sm text-zinc-400">
            Admin bearer token
          </label>
          <input
            id="ops-token"
            name="token"
            type="password"
            className="mt-2 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-zinc-100"
            autoFocus
          />
          <button
            type="submit"
            className="mt-3 w-full rounded-lg border border-emerald-700/60 bg-emerald-700/20 px-4 py-2 text-sm font-medium text-emerald-200 hover:bg-emerald-700/30"
          >
            Sign in
          </button>
        </form>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-7xl space-y-6 p-4 sm:p-6">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold text-zinc-100">Ops Health</h1>
          <p className="text-sm text-zinc-500">
            Anomalies, churn, demand, unit econ, SLO. Refreshes every minute.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            disabled={busy === 'anomalies'}
            onClick={runAnomalies}
            className="rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm font-medium text-zinc-200 hover:bg-zinc-800 disabled:opacity-50"
          >
            {busy === 'anomalies' ? 'Running…' : 'Run anomaly detectors'}
          </button>
          <button
            type="button"
            onClick={() => void loadAll()}
            className="rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm font-medium text-zinc-200 hover:bg-zinc-800"
          >
            Refresh
          </button>
        </div>
      </header>

      {error && (
        <p className="rounded-xl border border-red-700/60 bg-red-700/10 p-3 text-sm text-red-300">
          {error}
        </p>
      )}

      <section aria-labelledby="anomalies-h">
        <h2 id="anomalies-h" className="mb-2 text-lg font-medium text-zinc-200">
          Open anomalies
        </h2>
        <AnomalyBoard anomalies={state.anomalies} onResolve={resolveAnomaly} />
      </section>

      <section aria-labelledby="slo-h">
        <h2 id="slo-h" className="mb-2 text-lg font-medium text-zinc-200">
          SLOs (last hour)
        </h2>
        <SloDashboard slos={state.slos} />
      </section>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <section aria-labelledby="summary-h">
          <h2 id="summary-h" className="mb-2 text-lg font-medium text-zinc-200">
            AI ops summary
          </h2>
          <AiDailySummaryCard
            summary={state.summary}
            onGenerate={generateSummary}
            generating={generatingSummary}
          />
        </section>
        <section aria-labelledby="cost-h">
          <h2 id="cost-h" className="mb-2 text-lg font-medium text-zinc-200">
            Cost per booking
          </h2>
          <CostPerBookingCard data={state.costPerBooking} />
        </section>
      </div>

      <section aria-labelledby="econ-h">
        <h2 id="econ-h" className="mb-2 text-lg font-medium text-zinc-200">
          Unit economics
        </h2>
        <UnitEconWaterfall snapshot={state.unitEcon} />
      </section>

      <section aria-labelledby="churn-h">
        <h2 id="churn-h" className="mb-2 text-lg font-medium text-zinc-200">
          Churn risk
        </h2>
        <ChurnRiskList rows={state.churn} />
      </section>

      <section aria-labelledby="demand-h">
        <h2 id="demand-h" className="mb-2 text-lg font-medium text-zinc-200">
          Demand forecast
        </h2>
        <DemandHeatmap cells={state.demand} />
      </section>
    </main>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
