import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import type { SloStatus } from '@theme.tools/crm/field-service/admin-ops-types';

interface Props {
  slos: readonly SloStatus[];
}

/**
 * SloDashboard — one card per SLO with value vs target, breach color, and
 * the timestamp of the last observation. Sorted breached-first so the
 * operator's eye lands on what's red.
 */
export default function SloDashboard({ slos }: Props) {
  useThemeToolsSurface('slo-dashboard');
  const sorted = [...slos].sort((a, b) => Number(b.breached) - Number(a.breached));
  if (sorted.length === 0) {
    return (
      <div className="rounded-xl border border-zinc-800 bg-zinc-950 p-6 text-center">
        <p className="text-zinc-400">No SLO readings in the last hour.</p>
      </div>
    );
  }
  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
      {sorted.map((s) => {
        const ratio = s.target !== 0 ? s.value / s.target : 1;
        const pct = Math.round(ratio * 100);
        const color = s.breached
          ? 'text-red-300'
          : pct >= 95
            ? 'text-emerald-300'
            : 'text-zinc-200';
        return (
          <div
            key={s.slo}
            className={`rounded-xl border bg-zinc-950 p-4 ${
              s.breached ? 'border-red-700/60' : 'border-zinc-800'
            }`}
          >
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-medium text-zinc-300">{s.slo}</h4>
              {s.breached && (
                <span className="rounded-md border border-red-700/60 bg-red-700/20 px-2 py-0.5 text-xs text-red-300">
                  BREACHED
                </span>
              )}
            </div>
            <p className={`mt-2 text-2xl font-semibold tabular-nums ${color}`}>
              {s.value.toFixed(2)}
              <span className="ml-2 text-sm font-normal text-zinc-500">
                / {s.target.toFixed(2)}
              </span>
            </p>
            <p className="mt-1 text-xs text-zinc-500">
              {pct}% of target · {new Date(s.ts).toLocaleTimeString()}
            </p>
          </div>
        );
      })}
    </div>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
