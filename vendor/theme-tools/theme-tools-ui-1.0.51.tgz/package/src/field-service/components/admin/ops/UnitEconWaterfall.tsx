import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useMemo } from 'react';
import type { UnitEconRow } from '@theme.tools/crm/field-service/admin-ops-types';
import { formatCents } from '@theme.tools/crm/field-service/admin-ops-types';

interface Props {
  snapshot: UnitEconRow | null;
}

/**
 * UnitEconWaterfall — gross → minus COGS → minus payouts → minus ad spend
 * → net. Each bar is sized relative to the gross revenue. Negative bars
 * (deductions) render to the right of the running balance; the final NET
 * bar uses a positive/negative color.
 */
export default function UnitEconWaterfall({ snapshot }: Props) {
  useThemeToolsSurface('unit-econ-waterfall');
  const bars = useMemo(() => {
    if (!snapshot) return [];
    const gross = snapshot.gross_revenue_cents;
    if (gross <= 0) return [];
    const items = [
      { label: 'Gross revenue', value: gross, kind: 'positive' as const },
      { label: 'COGS', value: -snapshot.cogs_cents, kind: 'negative' as const },
      { label: 'Worker payouts', value: -snapshot.worker_payouts_cents, kind: 'negative' as const },
      { label: 'Ad spend', value: -snapshot.ad_spend_cents, kind: 'negative' as const },
      {
        label: 'Net',
        value: snapshot.net_cents,
        kind: (snapshot.net_cents >= 0 ? 'positive' : 'negative') as 'positive' | 'negative',
      },
    ];
    return items.map((i) => ({
      ...i,
      widthPct: Math.min(100, (Math.abs(i.value) / gross) * 100),
    }));
  }, [snapshot]);

  if (!snapshot) {
    return (
      <div className="rounded-xl border border-zinc-800 bg-zinc-950 p-6 text-center">
        <p className="text-zinc-400">No unit-economics snapshot yet.</p>
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-950 p-4">
      <h3 className="mb-1 text-sm font-medium uppercase tracking-wide text-zinc-400">
        Unit economics
      </h3>
      <p className="mb-4 text-xs text-zinc-500">
        Period: {snapshot.period} · {snapshot.bookings_count} bookings · snapshot{' '}
        {new Date(snapshot.snapshot_at).toLocaleString()}
      </p>
      <ul className="space-y-2">
        {bars.map((b) => (
          <li key={b.label} className="grid grid-cols-[120px_1fr_110px] items-center gap-3">
            <span className="text-sm text-zinc-300">{b.label}</span>
            <div className="h-3 overflow-hidden rounded-md bg-zinc-900" aria-hidden="true">
              <div
                className={b.kind === 'positive' ? 'h-full bg-emerald-500' : 'h-full bg-red-500'}
                style={{ width: `${b.widthPct}%` }}
              />
            </div>
            <span className="text-right font-mono text-sm tabular-nums text-zinc-100">
              {b.value < 0 ? `−${formatCents(Math.abs(b.value))}` : formatCents(b.value)}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
