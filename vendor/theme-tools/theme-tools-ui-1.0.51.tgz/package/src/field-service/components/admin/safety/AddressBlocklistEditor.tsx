import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useState } from 'react';

/**
 * Address blocklist editor. Lists every address we won't dispatch to,
 * with an inline form to add and a per-row remove action.
 */

interface BlocklistEntry {
  address_normalized: string;
  reason: string;
  added_at: string;
  added_by: string;
  notes: string | null;
}

export function AddressBlocklistEditor({ auth }: { readonly auth: HeadersInit }) {
  useThemeToolsSurface('address-blocklist-editor');
  const [rows, setRows] = useState<BlocklistEntry[]>([]);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const reload = useCallback(async () => {
    setError('');
    try {
      const res = await fetch('/api/admin/safety/blocklist', { headers: auth });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = (await res.json()) as { blocklist?: BlocklistEntry[] };
      setRows(data.blocklist ?? []);
    } catch (err) {
      setError((err as Error).message);
    }
  }, [auth]);

  useEffect(() => {
    void reload();
  }, [reload]);

  async function onAdd(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    try {
      const form = new FormData(e.currentTarget);
      const res = await fetch('/api/admin/safety/blocklist', {
        method: 'POST',
        headers: { ...auth, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rawAddress: String(form.get('rawAddress') ?? ''),
          reason: String(form.get('reason') ?? ''),
          notes: String(form.get('notes') ?? '') || undefined,
        }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      e.currentTarget.reset();
      await reload();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setSubmitting(false);
    }
  }

  async function remove(addr: string) {
    if (!confirm(`Remove ${addr} from blocklist?`)) return;
    try {
      await fetch(`/api/admin/safety/blocklist?address=${encodeURIComponent(addr)}`, {
        method: 'DELETE',
        headers: auth,
      });
      await reload();
    } catch (err) {
      setError((err as Error).message);
    }
  }

  return (
    <section aria-labelledby="block-h" className="space-y-3">
      <header>
        <h2 id="block-h" className="text-xl font-bold">
          Address blocklist
        </h2>
        <p className="text-brand-mute text-sm">
          Stored as normalized strings. Match logic in <code>address-blocklist.ts</code>.
        </p>
      </header>

      <form
        onSubmit={onAdd}
        className="rounded-lg border border-brand-line bg-brand-ink/40 p-4 space-y-3"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <input
            required
            name="rawAddress"
            placeholder="123 Main St, Newark NJ 07102"
            className="rounded-md border border-brand-line bg-brand-bg px-3 py-2 text-sm"
          />
          <input
            required
            name="reason"
            placeholder="Reason (e.g. fraud-confirmed)"
            className="rounded-md border border-brand-line bg-brand-bg px-3 py-2 text-sm"
          />
        </div>
        <input
          name="notes"
          placeholder="Notes (optional)"
          maxLength={500}
          className="w-full rounded-md border border-brand-line bg-brand-bg px-3 py-2 text-sm"
        />
        <button
          type="submit"
          disabled={submitting}
          className="btn btn-primary text-sm disabled:opacity-60"
        >
          {submitting ? 'Adding…' : 'Add to blocklist'}
        </button>
      </form>

      {error && <p className="text-rose-400 text-sm">{error}</p>}

      {rows.length === 0 && <p className="text-brand-mute text-sm">Blocklist is empty.</p>}
      {rows.length > 0 && (
        <ul className="space-y-1 text-sm">
          {rows.map((r) => (
            <li
              key={r.address_normalized}
              className="flex flex-wrap items-center justify-between gap-2 rounded-md border border-brand-line bg-brand-ink/40 px-3 py-2"
            >
              <span className="font-mono text-xs">{r.address_normalized}</span>
              <span className="text-brand-mute text-xs">{r.reason}</span>
              <span className="text-brand-mute text-xs">{r.added_at.slice(0, 10)}</span>
              <button
                type="button"
                onClick={() => remove(r.address_normalized)}
                className="btn btn-secondary text-xs"
              >
                Remove
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
