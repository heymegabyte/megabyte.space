import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useState } from 'react';

/**
 * Compliance audit trail viewer. Server-paged via /api/admin/compliance/audit-trail.
 * Filters by kind + severity. "Load more" follows the nextCursor.
 */

interface AuditItem {
  id: string;
  kind: string;
  severity: string;
  ts: string;
  actor: string | null;
  payload: unknown;
}

interface KindFacet {
  kind: string;
  count: number;
}

export function ComplianceAuditLog({ auth }: { readonly auth: HeadersInit }) {
  useThemeToolsSurface('compliance-audit-log');
  const [items, setItems] = useState<AuditItem[]>([]);
  const [cursor, setCursor] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [kinds, setKinds] = useState<KindFacet[]>([]);
  const [kindFilter, setKindFilter] = useState('');
  const [severityFilter, setSeverityFilter] = useState('');

  const fetchPage = useCallback(
    async (reset: boolean) => {
      setLoading(true);
      setError('');
      try {
        const params = new URLSearchParams();
        params.set('limit', '50');
        if (kindFilter) params.set('kind', kindFilter);
        if (severityFilter) params.set('severity', severityFilter);
        if (!reset && cursor) params.set('cursor', cursor);
        const res = await fetch(`/api/admin/compliance/audit-trail?${params.toString()}`, {
          headers: auth,
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = (await res.json()) as { items?: AuditItem[]; nextCursor?: string | null };
        const next = data.items ?? [];
        setItems(reset ? next : [...items, ...next]);
        setCursor(data.nextCursor ?? null);
        setHasMore(Boolean(data.nextCursor));
      } catch (err) {
        setError((err as Error).message);
      } finally {
        setLoading(false);
      }
    },
    [auth, cursor, items, kindFilter, severityFilter],
  );

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch('/api/admin/compliance/kinds', { headers: auth });
        if (!res.ok) return;
        const data = (await res.json()) as { kinds?: KindFacet[] };
        if (!cancelled) setKinds(data.kinds ?? []);
      } catch {
        /* ignore */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [auth]);

  useEffect(() => {
    setCursor(null);
    void fetchPage(true);
    // Reload page from scratch when filters change.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [kindFilter, severityFilter, auth]);

  return (
    <section aria-labelledby="audit-h" className="space-y-3">
      <header>
        <h2 id="audit-h" className="text-xl font-bold">
          Compliance audit trail
        </h2>
        <p className="text-brand-mute text-sm">Append-only. Exported as-is when regulators ask.</p>
      </header>

      <div className="flex flex-wrap items-center gap-3">
        <label className="text-xs text-brand-mute">
          Kind
          <select
            value={kindFilter}
            onChange={(e) => setKindFilter(e.target.value)}
            className="ml-2 rounded-md border border-brand-line bg-brand-bg px-2 py-1 text-sm"
          >
            <option value="">All</option>
            {kinds.map((k) => (
              <option key={k.kind} value={k.kind}>
                {k.kind} ({k.count})
              </option>
            ))}
          </select>
        </label>
        <label className="text-xs text-brand-mute">
          Severity
          <select
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value)}
            className="ml-2 rounded-md border border-brand-line bg-brand-bg px-2 py-1 text-sm"
          >
            <option value="">All</option>
            <option value="info">info</option>
            <option value="low">low</option>
            <option value="medium">medium</option>
            <option value="high">high</option>
            <option value="critical">critical</option>
          </select>
        </label>
      </div>

      {error && <p className="text-rose-400 text-sm">{error}</p>}

      <ul className="space-y-1 text-sm">
        {items.map((item) => (
          <li
            key={item.id}
            className="rounded-md border border-brand-line bg-brand-ink/40 px-3 py-2"
          >
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <span className="font-mono text-brand-mute">{item.ts}</span>
              <span className="font-medium">{item.kind}</span>
              <span
                className={
                  'rounded-full px-2 py-0.5 ' +
                  (item.severity === 'critical' || item.severity === 'high'
                    ? 'bg-rose-900/40 text-rose-200'
                    : item.severity === 'medium'
                      ? 'bg-amber-900/30 text-amber-200'
                      : 'bg-brand-line text-brand-mute')
                }
              >
                {item.severity}
              </span>
              <span className="text-brand-mute">{item.actor ?? '—'}</span>
            </div>
            {item.payload !== null && item.payload !== undefined && (
              <pre className="mt-1 max-h-40 overflow-auto whitespace-pre-wrap text-xs text-brand-mute">
                {JSON.stringify(item.payload, null, 2)}
              </pre>
            )}
          </li>
        ))}
      </ul>

      {hasMore && (
        <button
          type="button"
          onClick={() => fetchPage(false)}
          disabled={loading}
          className="btn btn-secondary text-sm disabled:opacity-60"
        >
          {loading ? 'Loading…' : 'Load more'}
        </button>
      )}
    </section>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
