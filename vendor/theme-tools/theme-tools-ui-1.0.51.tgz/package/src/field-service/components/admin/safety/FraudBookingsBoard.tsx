import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { useEffect, useState } from 'react';

/**
 * Fraud bookings board. Lists every booking_fraud_signals row sorted by
 * score descending, with a "Rescan" button per row.
 */

interface FraudRow {
  id: string;
  booking_id: string;
  score: number;
  flags: string;
  computed_at: string;
  disposition: string | null;
}

export function FraudBookingsBoard({ auth }: { readonly auth: HeadersInit }) {
  useThemeToolsSurface('fraud-bookings-board');
  const [rows, setRows] = useState<FraudRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState<string | null>(null);

  async function reload() {
    setError('');
    try {
      const res = await fetch('/api/admin/safety/fraud-list', { headers: auth });
      if (res.status === 404) {
        setRows([]);
        return;
      }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = (await res.json()) as { rows?: FraudRow[] };
      setRows(data.rows ?? []);
    } catch (err) {
      setError((err as Error).message);
    }
  }

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    (async () => {
      await reload();
      if (!cancelled) setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auth]);

  async function rescan(bookingId: string) {
    setBusyId(bookingId);
    try {
      await fetch(`/api/admin/safety/fraud-scan/${bookingId}`, {
        method: 'POST',
        headers: auth,
      });
      await reload();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusyId(null);
    }
  }

  return (
    <section aria-labelledby="fraud-h" className="space-y-3">
      <header>
        <h2 id="fraud-h" className="text-xl font-bold">
          Booking fraud signals
        </h2>
        <p className="text-brand-mute text-sm">
          Velocity + disposable email + blocklist + chargeback history.
        </p>
      </header>

      {error && <p className="text-rose-400 text-sm">{error}</p>}
      {loading && <p className="text-brand-mute text-sm">Loading…</p>}
      {!loading && rows.length === 0 && (
        <p className="text-brand-mute text-sm">No flagged bookings.</p>
      )}
      {rows.length > 0 && (
        <ul className="space-y-2">
          {rows.map((row) => {
            const flags = safeJson(row.flags);
            return (
              <li
                key={row.id}
                className="rounded-md border border-brand-line bg-brand-ink/40 p-3 text-sm"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-mono text-xs">booking {row.booking_id.slice(0, 8)}</span>
                  <span
                    className={
                      'rounded-full px-2 py-0.5 text-xs ' +
                      (row.score >= 0.6
                        ? 'bg-rose-900/40 text-rose-200'
                        : row.score >= 0.3
                          ? 'bg-amber-900/40 text-amber-200'
                          : 'bg-emerald-900/30 text-emerald-200')
                    }
                  >
                    score {row.score.toFixed(2)}
                  </span>
                  <button
                    type="button"
                    onClick={() => rescan(row.booking_id)}
                    disabled={busyId === row.booking_id}
                    className="btn btn-secondary text-xs disabled:opacity-60"
                  >
                    {busyId === row.booking_id ? 'Rescanning…' : 'Rescan'}
                  </button>
                </div>
                {Array.isArray(flags) && flags.length > 0 && (
                  <ul className="mt-2 list-disc pl-5 text-xs text-brand-mute">
                    {flags.map((f, i) => {
                      const o = f as { kind?: string; weight?: number; detail?: string };
                      return (
                        <li key={i}>
                          {o.kind} ({(o.weight ?? 0).toFixed(2)}){o.detail ? ' — ' + o.detail : ''}
                        </li>
                      );
                    })}
                  </ul>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}

function safeJson(s: string | null | undefined): unknown {
  if (!s) return null;
  try {
    return JSON.parse(s);
  } catch {
    return null;
  }
}
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
