import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useEffect, useState } from 'react';

/**
 * OSHA-10 / 30 / First Aid / CPR cert calendar — lists every cert expiring
 * inside the chosen window (default 60 days) with verify + add actions.
 */

interface CertRow {
  id: string;
  worker_id: string;
  kind: 'osha_10' | 'osha_30' | 'first_aid' | 'cpr';
  issued_at: string;
  expires_at: string;
  issuer: string | null;
  verified_at: string | null;
}

export function OshaCertCalendar({ auth }: { readonly auth: HeadersInit }) {
  useThemeToolsSurface('osha-cert-calendar');
  const [rows, setRows] = useState<CertRow[]>([]);
  const [window, setWindow] = useState(60);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [adding, setAdding] = useState(false);
  const [addResult, setAddResult] = useState('');

  async function reload() {
    setError('');
    setLoading(true);
    try {
      const res = await fetch(`/api/admin/safety/osha-certs/expiring?withinDays=${window}`, {
        headers: auth,
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = (await res.json()) as { certs?: CertRow[] };
      setRows(data.certs ?? []);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void reload();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [window, auth]);

  async function verify(id: string) {
    try {
      await fetch(`/api/admin/safety/osha-cert/${id}/verify`, { method: 'POST', headers: auth });
      await reload();
    } catch (err) {
      setError((err as Error).message);
    }
  }

  async function onAdd(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setAdding(true);
    setAddResult('');
    try {
      const form = new FormData(e.currentTarget);
      const res = await fetch('/api/admin/safety/osha-cert', {
        method: 'POST',
        headers: { ...auth, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          workerId: String(form.get('workerId') ?? ''),
          kind: String(form.get('kind') ?? 'osha_10'),
          issuedAtIso: String(form.get('issuedAt') ?? ''),
          expiresAtIso: String(form.get('expiresAt') ?? ''),
          issuer: String(form.get('issuer') ?? '') || undefined,
        }),
      });
      const data = (await res.json()) as { ok?: boolean; id?: string };
      if (!data.ok) throw new Error('add failed');
      setAddResult(`Added ${data.id}.`);
      await reload();
    } catch (err) {
      setAddResult(`Error: ${(err as Error).message}`);
    } finally {
      setAdding(false);
    }
  }

  return (
    <section aria-labelledby="osha-h" className="space-y-3">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 id="osha-h" className="text-xl font-bold">
            OSHA + CPR cert renewals
          </h2>
          <p className="text-brand-mute text-sm">Showing certs expiring within {window} days.</p>
        </div>
        <label className="text-xs text-brand-mute">
          Window
          <select
            value={window}
            onChange={(e) => setWindow(Number(e.target.value))}
            className="ml-2 rounded-md border border-brand-line bg-brand-bg px-2 py-1 text-sm"
          >
            <option value={30}>30d</option>
            <option value={60}>60d</option>
            <option value={90}>90d</option>
            <option value={180}>180d</option>
            <option value={365}>365d</option>
          </select>
        </label>
      </header>

      <form
        onSubmit={onAdd}
        className="rounded-lg border border-brand-line bg-brand-ink/40 p-4 space-y-3"
      >
        <p className="text-sm font-medium">Add cert</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <input
            required
            name="workerId"
            placeholder="Worker ID"
            className="rounded-md border border-brand-line bg-brand-bg px-3 py-2 text-sm"
          />
          <select
            name="kind"
            className="rounded-md border border-brand-line bg-brand-bg px-3 py-2 text-sm"
          >
            <option value="osha_10">OSHA 10</option>
            <option value="osha_30">OSHA 30</option>
            <option value="first_aid">First Aid</option>
            <option value="cpr">CPR</option>
          </select>
          <input
            name="issuer"
            placeholder="Issuer (optional)"
            className="rounded-md border border-brand-line bg-brand-bg px-3 py-2 text-sm"
          />
          <input
            required
            type="date"
            name="issuedAt"
            className="rounded-md border border-brand-line bg-brand-bg px-3 py-2 text-sm"
          />
          <input
            required
            type="date"
            name="expiresAt"
            className="rounded-md border border-brand-line bg-brand-bg px-3 py-2 text-sm"
          />
        </div>
        <button
          type="submit"
          disabled={adding}
          className="btn btn-primary text-sm disabled:opacity-60"
        >
          {adding ? 'Adding…' : 'Add'}
        </button>
        {addResult && <p className="text-brand-accent text-sm">{addResult}</p>}
      </form>

      {error && <p className="text-rose-400 text-sm">{error}</p>}
      {loading && <p className="text-brand-mute text-sm">Loading…</p>}
      {!loading && rows.length === 0 && (
        <p className="text-brand-mute text-sm">No certs expiring in this window.</p>
      )}
      {rows.length > 0 && (
        <ul className="space-y-1 text-sm">
          {rows.map((r) => (
            <li
              key={r.id}
              className="flex flex-wrap items-center justify-between gap-2 rounded-md border border-brand-line bg-brand-ink/40 px-3 py-2"
            >
              <span className="font-mono text-xs">{r.expires_at.slice(0, 10)}</span>
              <span>{r.kind}</span>
              <span className="text-brand-mute text-xs">worker {r.worker_id.slice(0, 8)}</span>
              <span className="text-brand-mute text-xs">{r.issuer ?? '—'}</span>
              {r.verified_at ? (
                <span className="text-emerald-400 text-xs">verified</span>
              ) : (
                <button
                  type="button"
                  onClick={() => verify(r.id)}
                  className="btn btn-secondary text-xs"
                >
                  Verify
                </button>
              )}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
