import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { IncidentSeverityMatrix } from './IncidentSeverityMatrix.js';
import { HostilityFeed } from './HostilityFeed.js';
import { BgCheckRenewalCalendar } from './BgCheckRenewalCalendar.js';
import { ForgeryFlagsBoard } from './ForgeryFlagsBoard.js';
import { CoiIssuancesBoard } from './CoiIssuancesBoard.js';
import { WcClaimDrafts } from './WcClaimDrafts.js';
import { OshaCertCalendar } from './OshaCertCalendar.js';
import { FraudBookingsBoard } from './FraudBookingsBoard.js';
import { AddressBlocklistEditor } from './AddressBlocklistEditor.js';
import { ComplianceAuditLog } from './ComplianceAuditLog.js';

/**
 * `/admin/safety` page — single-pane overview of every trust + safety
 * surface the worker route exposes. Each section is its own component so
 * the dashboard stays scannable.
 *
 * The owner key is sourced from `localStorage['bcl-admin-key-v1']` (set by
 * the main `/admin` page). When missing we render a friendly nudge to log
 * in first instead of probing every endpoint.
 */

const KEY_STORAGE = 'bcl-admin-key-v1';
const PAGE_TITLE = 'Safety + Compliance — Brick Labor';

type Section =
  | 'incidents'
  | 'hostility'
  | 'bg_checks'
  | 'forgery'
  | 'coi'
  | 'wc'
  | 'osha'
  | 'fraud'
  | 'blocklist'
  | 'audit';

interface SectionDef {
  readonly id: Section;
  readonly label: string;
  readonly hint: string;
}

const SECTIONS: SectionDef[] = [
  { id: 'incidents', label: 'Incidents', hint: 'Severity matrix + open queue' },
  { id: 'hostility', label: 'Hostility feed', hint: 'AI-flagged inbound SMS' },
  { id: 'bg_checks', label: 'BG renewals', hint: 'Criminal + MVR + identity calendar' },
  { id: 'forgery', label: 'License forgery', hint: 'AI vision flags board' },
  { id: 'coi', label: 'COIs', hint: 'Certificates of insurance' },
  { id: 'wc', label: 'WC claims', hint: 'Haiku-drafted workers comp claims' },
  { id: 'osha', label: 'OSHA + CPR', hint: 'Cert renewal calendar' },
  { id: 'fraud', label: 'Fraud', hint: 'Booking risk scores' },
  { id: 'blocklist', label: 'Blocklist', hint: 'Address blocklist editor' },
  { id: 'audit', label: 'Audit log', hint: 'Compliance audit trail' },
];

export interface SafetyDashboardProps {
  /** Override admin token (for storybook/tests). Falls back to localStorage. */
  readonly token?: string;
}

export function SafetyDashboard({ token: tokenOverride }: SafetyDashboardProps) {
  useThemeToolsSurface('safety-dashboard');
  const [token, setToken] = useState<string>(() => tokenOverride ?? readStoredKey());
  const [section, setSection] = useState<Section>(() => readSectionFromHash());

  useEffect(() => {
    document.title = PAGE_TITLE;
    const meta = document.querySelector('meta[name="robots"]');
    if (meta) meta.setAttribute('content', 'noindex,nofollow');
  }, []);

  useEffect(() => {
    function onHash() {
      setSection(readSectionFromHash());
    }
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  useEffect(() => {
    function onStorage(e: StorageEvent) {
      if (e.key === KEY_STORAGE) setToken(e.newValue ?? '');
    }
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);

  const onTokenSubmit = useCallback((e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const value = String(form.get('token') ?? '').trim();
    if (!value) return;
    try {
      localStorage.setItem(KEY_STORAGE, value);
    } catch {
      /* private mode — fine, just don't persist */
    }
    setToken(value);
  }, []);

  const auth = useMemo<HeadersInit>(
    () => (token ? ({ Authorization: `Bearer ${token}` } as Record<string, string>) : {}),
    [token],
  );

  if (!token) {
    return (
      <article className="section">
        <div className="container-pad max-w-md">
          <p className="eyebrow mb-3">Owner only</p>
          <h1 className="text-3xl font-extrabold mb-2">Safety + Compliance</h1>
          <p className="text-brand-mute mb-6 text-sm">
            Paste the owner key. Stored locally. Same key as the main admin.
          </p>
          <form onSubmit={onTokenSubmit} className="space-y-3">
            <input
              type="password"
              name="token"
              required
              autoFocus
              autoComplete="off"
              className="w-full rounded-lg border border-brand-line bg-brand-ink px-3 py-2 text-sm"
              placeholder="OWNER_INVOICE_KEY"
            />
            <button type="submit" className="btn btn-primary w-full">
              Unlock
            </button>
          </form>
        </div>
      </article>
    );
  }

  return (
    <article className="section">
      <header className="container-pad mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="eyebrow">Owner only</p>
          <h1 className="text-3xl font-extrabold tracking-tight">Safety + Compliance</h1>
          <p className="text-brand-mute mt-1 text-sm">
            Geofence, sentiment, BG renewals, forgery flags, COIs, WC drafts, OSHA, fraud,
            blocklist, audit.
          </p>
        </div>
      </header>

      <nav className="container-pad mb-6 flex flex-wrap gap-2" aria-label="Safety sections">
        {SECTIONS.map((s) => (
          <a
            key={s.id}
            href={`#${s.id}`}
            onClick={() => setSection(s.id)}
            className={
              'rounded-full border px-3 py-1.5 text-xs font-medium transition ' +
              (section === s.id
                ? 'border-brand-accent bg-brand-accent/20 text-brand-accent'
                : 'border-brand-line text-brand-mute hover:border-brand-accent hover:text-brand-accent')
            }
            title={s.hint}
          >
            {s.label}
          </a>
        ))}
      </nav>

      <div className="container-pad space-y-8" id={section}>
        {section === 'incidents' && <IncidentSeverityMatrix auth={auth} />}
        {section === 'hostility' && <HostilityFeed auth={auth} />}
        {section === 'bg_checks' && <BgCheckRenewalCalendar auth={auth} />}
        {section === 'forgery' && <ForgeryFlagsBoard auth={auth} />}
        {section === 'coi' && <CoiIssuancesBoard auth={auth} />}
        {section === 'wc' && <WcClaimDrafts auth={auth} />}
        {section === 'osha' && <OshaCertCalendar auth={auth} />}
        {section === 'fraud' && <FraudBookingsBoard auth={auth} />}
        {section === 'blocklist' && <AddressBlocklistEditor auth={auth} />}
        {section === 'audit' && <ComplianceAuditLog auth={auth} />}
      </div>
    </article>
  );
}

function readStoredKey(): string {
  try {
    return localStorage.getItem(KEY_STORAGE) || '';
  } catch {
    return '';
  }
}

function readSectionFromHash(): Section {
  try {
    const h = (window.location.hash || '').replace('#', '');
    const allowed = SECTIONS.map((s) => s.id);
    return (allowed.includes(h as Section) ? (h as Section) : 'incidents') as Section;
  } catch {
    return 'incidents';
  }
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
