import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useEffect, useState } from 'react';

/**
 * Workers-comp claim drafts. Lists every wc_claims row with its draft markdown
 * preview; expand a row to see the full draft and copy it.
 */

interface WcRow {
  id: string;
  worker_id: string;
  incident_id: string | null;
  status: 'draft' | 'review' | 'submitted' | 'accepted' | 'denied' | 'withdrawn';
  carrier_ref: string | null;
  submitted_at: string | null;
  created_at: string;
  draft_preview: string;
}

export function WcClaimDrafts({ auth }: { readonly auth: HeadersInit }) {
  useThemeToolsSurface('wc-claim-drafts');
  const [rows, setRows] = useState<WcRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [expanded, setExpanded] = useState<string | null>(null);
  const [draftingId, setDraftingId] = useState<string | null>(null);

  async function reload() {
    setError('');
    try {
      const res = await fetch('/api/admin/safety/wc-claims', { headers: auth });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = (await res.json()) as { claims?: WcRow[] };
      setRows(data.claims ?? []);
    } catch (err) {
      setError((err as Error).message);
    }
  }

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    (async () => {
      await reload();
      if (!cancelled) setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auth]);

  async function draftFor(incidentId: string, workerId: string) {
    setDraftingId(incidentId);
    try {
      await fetch('/api/admin/safety/draft-wc-claim', {
        method: 'POST',
        headers: { ...auth, 'Content-Type': 'application/json' },
        body: JSON.stringify({ incidentId, workerId }),
      });
      await reload();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setDraftingId(null);
    }
  }

  return (
    <section aria-labelledby="wc-h" className="space-y-3">
      <header>
        <h2 id="wc-h" className="text-xl font-bold">
          Workers comp drafts
        </h2>
        <p className="text-brand-mute text-sm">Haiku-drafted narratives. Never auto-submitted.</p>
      </header>

      {error && <p className="text-rose-400 text-sm">{error}</p>}
      {loading && <p className="text-brand-mute text-sm">Loading…</p>}

      {!loading && rows.length === 0 && <p className="text-brand-mute text-sm">No drafts yet.</p>}

      {rows.length > 0 && (
        <ul className="space-y-2">
          {rows.map((r) => {
            const open = expanded === r.id;
            return (
              <li
                key={r.id}
                className="rounded-md border border-brand-line bg-brand-ink/40 p-3 text-sm"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-mono text-xs">{r.id.slice(0, 10)}</span>
                  <span className="text-brand-mute text-xs">worker {r.worker_id.slice(0, 8)}</span>
                  <span
                    className={
                      'rounded-full px-2 py-0.5 text-xs ' +
                      (r.status === 'submitted'
                        ? 'bg-emerald-900/40 text-emerald-200'
                        : r.status === 'denied'
                          ? 'bg-rose-900/40 text-rose-200'
                          : 'bg-amber-900/40 text-amber-200')
                    }
                  >
                    {r.status}
                  </span>
                  {r.incident_id && (
                    <button
                      type="button"
                      onClick={() => draftFor(r.incident_id!, r.worker_id)}
                      disabled={draftingId === r.incident_id}
                      className="btn btn-secondary text-xs disabled:opacity-60"
                    >
                      {draftingId === r.incident_id ? 'Drafting…' : 'Redraft'}
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => setExpanded(open ? null : r.id)}
                    className="text-brand-accent text-xs underline"
                  >
                    {open ? 'Collapse' : 'Expand'}
                  </button>
                </div>
                {open && (
                  <pre className="mt-2 max-h-96 overflow-auto whitespace-pre-wrap rounded bg-brand-bg p-2 text-xs">
                    {r.draft_preview}
                  </pre>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
