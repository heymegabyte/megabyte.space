import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import type { ReactNode } from 'react';

/**
 * Shared tile primitive used by every Wave 20 admin/work/customer tile.
 * Same shell across surfaces — dark bento card, tight padding, a colored
 * eyebrow tag, and a slot for content. Tiles are intentionally small so
 * many fit in a single dashboard view.
 */

export interface Wave20TileProps {
  readonly title: string;
  readonly tag: string;
  readonly children: ReactNode;
  readonly accent?: 'cyan' | 'violet' | 'amber' | 'emerald' | 'rose';
}

const ACCENT_CLASS: Record<NonNullable<Wave20TileProps['accent']>, string> = {
  cyan: 'text-cyan-300',
  violet: 'text-violet-300',
  amber: 'text-amber-300',
  emerald: 'text-emerald-300',
  rose: 'text-rose-300',
};

export default function Wave20Tile({ title, tag, children, accent = 'cyan' }: Wave20TileProps) {
  useThemeToolsSurface('wave20-tile');
  return (
    <article className="rounded-2xl border border-white/10 bg-black/40 p-5 shadow-md shadow-black/30 backdrop-blur-sm transition hover:border-white/20">
      <header className="mb-3 flex items-baseline justify-between gap-3">
        <h3 className="text-base font-semibold text-white">{title}</h3>
        <span className={`text-xs font-medium uppercase tracking-wide ${ACCENT_CLASS[accent]}`}>
          {tag}
        </span>
      </header>
      <div className="text-sm leading-relaxed text-white/80">{children}</div>
    </article>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
