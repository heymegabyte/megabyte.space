import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useState } from 'react';
import Wave20Tile from './Wave20Tile.js';

/**
 * All 30 admin-facing Wave 20 tiles. Each tile is intentionally MVP — read
 * state from the worker route, render a one-line status, and provide one
 * action button. None of them block; they fail silently and show the last
 * good state. Wired up by `Wave20FeaturesGrid.tsx`.
 *
 * Style choices: each tile uses `Wave20Tile` for the shell, fetches lazily
 * on mount via `useEffect` inside its own state, and never throws across
 * the boundary — a network error renders an inline "—" instead.
 */

async function adminFetch<T>(path: string, init: RequestInit = {}): Promise<T | null> {
  try {
    const res = await fetch(`/api/wave20${path}`, {
      ...init,
      credentials: 'include',
      headers: { 'Content-Type': 'application/json', ...(init.headers ?? {}) },
    });
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch {
    return null;
  }
}

function StatusLine({ label, value }: { label: string; value: string }) {
  return (
    <p className="flex items-baseline justify-between gap-2 text-white/80">
      <span className="text-white/60">{label}</span>
      <span className="font-mono text-white">{value}</span>
    </p>
  );
}

export function NotificationPrefsTile() {
  useThemeToolsSurface('tiles');
  return (
    <Wave20Tile title="Notification AI" tag="auto-tuned" accent="cyan">
      <p>Per-user channel auto-tuned from engagement (SMS reply, email open).</p>
      <p className="mt-2 text-white/60">Override always wins. EMA-driven.</p>
    </Wave20Tile>
  );
}

export function PiiRedactTile() {
  const [count, setCount] = useState<number | null>(null);
  const [text, setText] = useState('Call John at 555-123-4567 about 123 Main Street.');
  async function run() {
    const res = await adminFetch<{ count: number; text: string }>('/admin/pii/redact', {
      method: 'POST',
      body: JSON.stringify({ surface: 'admin-tile', text }),
    });
    if (res) setCount(res.count);
  }
  return (
    <Wave20Tile title="PII Auto-Redact" tag="pre-send" accent="rose">
      <textarea
        className="h-16 w-full rounded-lg border border-white/10 bg-black/40 p-2 text-xs text-white"
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <button
        type="button"
        onClick={run}
        className="mt-2 rounded-lg bg-rose-500/20 px-3 py-1 text-xs font-medium text-rose-200 hover:bg-rose-500/30"
      >
        Scan
      </button>
      {count !== null && <p className="mt-2 text-white/60">Redacted spans: {count}</p>}
    </Wave20Tile>
  );
}

export function VoiceMemoTile() {
  return (
    <Wave20Tile title="Voice Memo Recaps" tag="whisper+haiku" accent="violet">
      <p>End-of-job 30s memo → Whisper → Haiku → customer-friendly recap.</p>
      <p className="mt-2 text-white/60">Process pending memos in admin queue.</p>
    </Wave20Tile>
  );
}

export function ReminderCadenceTile() {
  const [contact, setContact] = useState('');
  const [arm, setArm] = useState<string | null>(null);
  async function lookup() {
    if (!contact) return;
    const res = await adminFetch<{ suggestedArm: string }>(
      `/admin/reminder-cadence/${encodeURIComponent(contact)}`,
    );
    if (res) setArm(res.suggestedArm);
  }
  return (
    <Wave20Tile title="Reminder Cadence" tag="ucb1 bandit" accent="emerald">
      <input
        type="text"
        placeholder="customer@example.com"
        className="w-full rounded-lg border border-white/10 bg-black/40 px-2 py-1 text-xs text-white"
        value={contact}
        onChange={(e) => setContact(e.target.value)}
      />
      <button
        type="button"
        onClick={lookup}
        className="mt-2 rounded-lg bg-emerald-500/20 px-3 py-1 text-xs font-medium text-emerald-200 hover:bg-emerald-500/30"
      >
        Suggest arm
      </button>
      {arm && (
        <p className="mt-2 text-white/80">
          Best arm: <span className="font-mono">{arm}</span>
        </p>
      )}
    </Wave20Tile>
  );
}

export function TipSuggesterTile() {
  return (
    <Wave20Tile title="Tip Suggester" tag="haiku" accent="amber">
      <p>Low/Mid/High tip range computed per job difficulty + tip history.</p>
      <p className="mt-2 text-white/60">Shown at rating time on customer screen.</p>
    </Wave20Tile>
  );
}

export function BreakTrackerTile() {
  return (
    <Wave20Tile title="Break Tracker" tag="geofence" accent="cyan">
      <p>30-min compliance window. Auto-flag violations.</p>
      <p className="mt-2 text-white/60">Open the break-compliance dashboard for details.</p>
    </Wave20Tile>
  );
}

export function MileageTile() {
  return (
    <Wave20Tile title="Real Mileage" tag="gps" accent="emerald">
      <p>Worker phone GPS vs haversine estimate. $0.67/mi reimbursement.</p>
      <p className="mt-2 text-white/60">Auto-rolled into next payout.</p>
    </Wave20Tile>
  );
}

export function CustomerBriefTile() {
  return (
    <Wave20Tile title="Customer Vibe Brief" tag="60-word" accent="violet">
      <p>Pre-call brief sent to worker en route. Tone-aware.</p>
      <p className="mt-2 text-white/60">Read prior comm; surface key cues.</p>
    </Wave20Tile>
  );
}

export function SmartScheduleTile() {
  return (
    <Wave20Tile title="Smart Schedule" tag="recurring" accent="cyan">
      <p>Optimal recurring slot picker. Weather + crew availability.</p>
      <p className="mt-2 text-white/60">Suggested via `/customer/smart-schedule`.</p>
    </Wave20Tile>
  );
}

export function AffinityTile() {
  return (
    <Wave20Tile title="Crew Affinity" tag="rebook" accent="amber">
      <p>Top crew per customer surfaced in booking flow.</p>
      <p className="mt-2 text-white/60">Score = jobs + rating + recency.</p>
    </Wave20Tile>
  );
}

export function AutofillTile() {
  return (
    <Wave20Tile title="Booking Autofill" tag="returning" accent="emerald">
      <p>Returning customer address + service prefs prefill.</p>
      <p className="mt-2 text-white/60">Stored per contact, updated on each booking.</p>
    </Wave20Tile>
  );
}

export function PayoutSplitTile() {
  return (
    <Wave20Tile title="Payout Split AI" tag="multi-crew" accent="violet">
      <p>Suggests fair split by hours × role weight.</p>
      <p className="mt-2 text-white/60">Admin approves; one-click to apply.</p>
    </Wave20Tile>
  );
}

export function PhotoQualityTile() {
  return (
    <Wave20Tile title="Photo Quality Nag" tag="vision" accent="rose">
      <p>Score &lt; 70 → reshoot prompt. Catches dark / blurry uploads.</p>
      <p className="mt-2 text-white/60">Width × brightness × sharpness weighted.</p>
    </Wave20Tile>
  );
}

export function DamageDraftTile() {
  return (
    <Wave20Tile title="Damage Report Drafts" tag="customer" accent="rose">
      <p>AI helps customer compose damage report from observation.</p>
      <p className="mt-2 text-white/60">Suggested evidence list attached.</p>
    </Wave20Tile>
  );
}

export function SurgeTunerTile() {
  const [mult, setMult] = useState('1.15');
  const [zip, setZip] = useState('');
  const [msg, setMsg] = useState<string | null>(null);
  async function save() {
    const res = await adminFetch<{ id: string }>(`/admin/surge/override`, {
      method: 'POST',
      body: JSON.stringify({ zip: zip || undefined, multiplier: Number(mult), reason: 'manual' }),
    });
    setMsg(res ? `Saved override ${res.id.slice(0, 8)}` : 'Save failed');
  }
  return (
    <Wave20Tile title="Surge Tuner" tag="admin overrides" accent="amber">
      <div className="flex gap-2">
        <input
          type="text"
          placeholder="zip (optional)"
          value={zip}
          onChange={(e) => setZip(e.target.value)}
          className="w-24 rounded-lg border border-white/10 bg-black/40 px-2 py-1 text-xs text-white"
        />
        <input
          type="number"
          step="0.05"
          value={mult}
          onChange={(e) => setMult(e.target.value)}
          className="w-20 rounded-lg border border-white/10 bg-black/40 px-2 py-1 text-xs text-white"
        />
        <button
          type="button"
          onClick={save}
          className="rounded-lg bg-amber-500/20 px-3 py-1 text-xs font-medium text-amber-200 hover:bg-amber-500/30"
        >
          Save
        </button>
      </div>
      {msg && <p className="mt-2 text-white/60">{msg}</p>}
    </Wave20Tile>
  );
}

export function FatigueTile() {
  return (
    <Wave20Tile title="Worker Fatigue" tag="burnout" accent="rose">
      <p>Hours-7d + acceptance trend → 0-1 score. ≥0.7 flags.</p>
      <p className="mt-2 text-white/60">Daily rollup per worker.</p>
    </Wave20Tile>
  );
}

export function WeeklyPerfTile() {
  return (
    <Wave20Tile title="Weekly Perf Report" tag="friday" accent="emerald">
      <p>"This week: 8 jobs, $1,240 earned, 4.8 rating."</p>
      <p className="mt-2 text-white/60">Sent each Friday to opted-in crew.</p>
    </Wave20Tile>
  );
}

export function NpsTile() {
  const [summary, setSummary] = useState<{ nps: number; responses: number } | null>(null);
  async function load() {
    const res = await adminFetch<{ summary: { nps: number; responses: number } }>(
      '/admin/nps/summary?days=30',
    );
    if (res) setSummary(res.summary);
  }
  return (
    <Wave20Tile title="NPS Micro-Survey" tag="rolling 30d" accent="cyan">
      <button
        type="button"
        onClick={load}
        className="rounded-lg bg-cyan-500/20 px-3 py-1 text-xs font-medium text-cyan-200 hover:bg-cyan-500/30"
      >
        Refresh
      </button>
      {summary && (
        <div className="mt-2 space-y-1 text-xs">
          <StatusLine label="NPS" value={`${summary.nps}`} />
          <StatusLine label="Responses" value={`${summary.responses}`} />
        </div>
      )}
    </Wave20Tile>
  );
}

export function JobDescTile() {
  return (
    <Wave20Tile title="Job Description AI" tag="expand" accent="violet">
      <p>"yard cleanup" → detailed scope + hour estimate.</p>
      <p className="mt-2 text-white/60">Cached per service slug.</p>
    </Wave20Tile>
  );
}

export function PricingFloorTile() {
  return (
    <Wave20Tile title="Pricing Floor AI" tag="profit gate" accent="rose">
      <p>Refuses booking when total &lt; computed floor.</p>
      <p className="mt-2 text-white/60">labor + travel + 18% overhead.</p>
    </Wave20Tile>
  );
}

export function CarpoolTile() {
  return (
    <Wave20Tile title="Carpool Matcher" tag="same zip" accent="emerald">
      <p>Two workers same zip same day → coordinate ride.</p>
      <p className="mt-2 text-white/60">Driver = larger vehicle.</p>
    </Wave20Tile>
  );
}

export function AutoArchiveTile() {
  return (
    <Wave20Tile title="Auto-Archive" tag="365d" accent="cyan">
      <p>Stale customer rows → archive + win-back.</p>
      <p className="mt-2 text-white/60">Track reactivation count.</p>
    </Wave20Tile>
  );
}

export function DupBookingTile() {
  return (
    <Wave20Tile title="Duplicate Booking" tag="24h same address" accent="amber">
      <p>Two bookings same address same window → flag for merge.</p>
      <p className="mt-2 text-white/60">Customer can review + approve.</p>
    </Wave20Tile>
  );
}

export function PeerNotesTile() {
  return (
    <Wave20Tile title="Peer Notes" tag="admin-only" accent="violet">
      <p>Workers leave private notes about peers. Sentiment-tagged.</p>
      <p className="mt-2 text-white/60">Never exposed to subject.</p>
    </Wave20Tile>
  );
}

export function LeaderboardTile() {
  return (
    <Wave20Tile title="Leaderboard" tag="opt-in" accent="amber">
      <p>Top earners this week. Visible only to opted-in workers.</p>
      <p className="mt-2 text-white/60">Display name configurable.</p>
    </Wave20Tile>
  );
}

export function BadgesTile() {
  return (
    <Wave20Tile title="Customer Badges" tag="auto-award" accent="emerald">
      <p>Verified / Repeat / VIP / Referrer / Reviewer / Early-Pay.</p>
      <p className="mt-2 text-white/60">Idempotent — re-evaluate on each event.</p>
    </Wave20Tile>
  );
}

export function IncidentCategoryTile() {
  return (
    <Wave20Tile title="Incident Auto-Tag" tag="route" accent="rose">
      <p>Safety / Customer / Equipment / Payment.</p>
      <p className="mt-2 text-white/60">Routes to the right team alias.</p>
    </Wave20Tile>
  );
}

export function NextServiceTile() {
  return (
    <Wave20Tile title="Next Service" tag="suggest" accent="cyan">
      <p>After power-wash → sealing in 14 days.</p>
      <p className="mt-2 text-white/60">Pipeline lookup with rationale.</p>
    </Wave20Tile>
  );
}

export function BrandVoiceTile() {
  const [text, setText] = useState('Our innovative platform leverages cutting-edge tools.');
  const [issues, setIssues] = useState<string[] | null>(null);
  async function run() {
    const res = await adminFetch<{ result: { issues: string[]; passed: boolean } }>(
      '/admin/brand-voice/check',
      { method: 'POST', body: JSON.stringify({ channel: 'sms', text }) },
    );
    if (res) setIssues(res.result.issues);
  }
  return (
    <Wave20Tile title="Brand Voice Check" tag="pre-send" accent="rose">
      <textarea
        className="h-16 w-full rounded-lg border border-white/10 bg-black/40 p-2 text-xs text-white"
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <button
        type="button"
        onClick={run}
        className="mt-2 rounded-lg bg-rose-500/20 px-3 py-1 text-xs font-medium text-rose-200 hover:bg-rose-500/30"
      >
        Check
      </button>
      {issues && (
        <ul className="mt-2 list-inside list-disc text-xs text-white/70">
          {issues.length === 0 ? (
            <li>Clean.</li>
          ) : (
            issues.slice(0, 4).map((i) => <li key={i}>{i}</li>)
          )}
        </ul>
      )}
    </Wave20Tile>
  );
}

export function MonthlyRecapTile() {
  return (
    <Wave20Tile title="Monthly Recap" tag="end-of-month" accent="violet">
      <p>"Here is everything we did for you this month."</p>
      <p className="mt-2 text-white/60">Photo collage + spend + loyalty progress.</p>
    </Wave20Tile>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
