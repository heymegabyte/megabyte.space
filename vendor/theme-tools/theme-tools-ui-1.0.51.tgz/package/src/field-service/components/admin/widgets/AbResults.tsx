import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function AbResults({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('ab-results');
  return <GenericTable title="A/B test results" endpoint="/ab-results" adminKey={adminKey} />;
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
