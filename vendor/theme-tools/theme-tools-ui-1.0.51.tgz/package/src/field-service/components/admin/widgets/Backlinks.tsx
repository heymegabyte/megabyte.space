import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function Backlinks({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('backlinks');
  return <GenericTable title="Backlink monitor" endpoint="/backlinks" adminKey={adminKey} />;
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
