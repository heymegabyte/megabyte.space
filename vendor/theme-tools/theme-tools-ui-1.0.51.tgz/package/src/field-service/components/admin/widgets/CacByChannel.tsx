import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function CacByChannel({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('cac-by-channel');
  return <GenericTable title="CAC by channel" endpoint="/cac-by-channel" adminKey={adminKey} />;
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
