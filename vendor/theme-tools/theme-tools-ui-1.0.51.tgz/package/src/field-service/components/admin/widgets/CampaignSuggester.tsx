import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { WidgetShell } from './WidgetShell.js';

export default function CampaignSuggester({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('campaign-suggester');
  return (
    <WidgetShell
      title="AI: say this next campaign"
      endpoint="/campaign-suggester"
      adminKey={adminKey}
      render={(raw) => {
        const d = raw as { avg_stars?: number; paid_rate?: number; suggestion?: string };
        return (
          <>
            <p style={{ fontSize: 14, fontWeight: 600 }}>{d.suggestion}</p>
            <p style={{ fontSize: 11, color: '#888' }}>
              avg stars {(d.avg_stars ?? 0).toFixed(2)} · paid rate{' '}
              {((d.paid_rate ?? 0) * 100).toFixed(1)}%
            </p>
          </>
        );
      }}
    />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
