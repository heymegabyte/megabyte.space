import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { WidgetShell, tinyTable } from './WidgetShell.js';

export default function EmailDeliverability({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('email-deliverability');
  return (
    <WidgetShell
      title="Email deliverability (7d)"
      endpoint="/email-deliverability"
      adminKey={adminKey}
      render={(raw) => {
        const d = raw as { empty?: boolean; summary?: Record<string, number | null> };
        if (d.empty) return <p style={{ color: '#888' }}>No email events logged.</p>;
        return tinyTable([d.summary || {}]);
      }}
    />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
