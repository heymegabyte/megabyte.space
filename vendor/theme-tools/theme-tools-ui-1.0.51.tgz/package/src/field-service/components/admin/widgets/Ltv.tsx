import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function Ltv({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('ltv');
  return (
    <GenericTable
      title="LTV per customer"
      endpoint="/ltv"
      adminKey={adminKey}
      pickRows={(d) =>
        Array.isArray(d.customers) ? (d.customers as Array<Record<string, unknown>>) : null
      }
    />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
