import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function NegativeEscalations({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('negative-escalations');
  return (
    <GenericTable
      title="Negative escalation triggers"
      endpoint="/negative-escalations"
      adminKey={adminKey}
    />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
