import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useState } from 'react';
import { WidgetShell, tinyTable } from './WidgetShell.js';

export default function Nps({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('nps');
  const [dim, setDim] = useState<'service' | 'city' | 'crew'>('service');
  return (
    <WidgetShell
      title={`NPS by ${dim}`}
      endpoint={`/nps?dim=${dim}`}
      adminKey={adminKey}
      render={(raw) => {
        const d = raw as { empty?: boolean; groups?: Array<Record<string, unknown>> };
        return (
          <>
            <div style={{ display: 'flex', gap: 4, marginBottom: 8 }}>
              {(['service', 'city', 'crew'] as const).map((k) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => setDim(k)}
                  style={{
                    background: dim === k ? 'var(--color-action-violet)' : 'var(--color-surface-inactive)',
                    color: 'var(--color-on-emphasis)',
                    border: 'none',
                    padding: '2px 8px',
                    borderRadius: 4,
                    fontSize: 10,
                    cursor: 'pointer',
                  }}
                >
                  {k}
                </button>
              ))}
            </div>
            {d.empty ? <p style={{ color: '#888' }}>No reviews yet.</p> : tinyTable(d.groups || [])}
          </>
        );
      }}
    />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
