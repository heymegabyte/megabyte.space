import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function OnboardingPipeline({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('onboarding-pipeline');
  return (
    <GenericTable title="Onboarding pipeline" endpoint="/onboarding-pipeline" adminKey={adminKey} />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
