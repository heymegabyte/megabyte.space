import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { useState } from 'react';
import { WidgetShell, bigNumber, formatDollars } from './WidgetShell.js';

export default function PayoutQueue({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('payout-queue');
  const [msg, setMsg] = useState<string>('');
  const release = async (payoutId: string) => {
    setMsg('Releasing…');
    const res = await fetch('/api/admin/widgets/payout-queue/release', {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ payout_id: payoutId }),
    });
    const json = (await res.json()) as { ok?: boolean; error?: string };
    setMsg(json.ok ? 'Released. Refresh.' : json.error || 'Failed.');
  };
  return (
    <WidgetShell
      title="Payout queue — manual release"
      endpoint="/payout-queue"
      adminKey={adminKey}
      render={(raw) => {
        const d = raw as {
          empty?: boolean;
          total_holding_cents?: number;
          holding?: Array<Record<string, unknown> & { id: string }>;
        };
        if (d.empty) return <p style={{ color: '#888' }}>No holding payouts.</p>;
        return (
          <>
            {bigNumber('holding', formatDollars(d.total_holding_cents || 0))}
            {msg ? <p style={{ color: '#7C3AED', fontSize: 11 }}>{msg}</p> : null}
            <div style={{ marginTop: 12 }}>
              <table style={{ width: '100%', fontSize: 12, borderCollapse: 'collapse' }}>
                <tbody>
                  {(d.holding || []).slice(0, 10).map((p) => (
                    <tr key={p.id}>
                      <td style={{ padding: 4 }}>{p.id}</td>
                      <td style={{ padding: 4 }}>{formatDollars(Number(p.amount_cents) || 0)}</td>
                      <td style={{ padding: 4 }}>
                        <button
                          type="button"
                          onClick={() => release(p.id)}
                          style={{
                            background: 'var(--color-action-violet)',
                            color: 'var(--color-on-emphasis)',
                            border: 'none',
                            padding: '2px 8px',
                            borderRadius: 4,
                            fontSize: 10,
                            cursor: 'pointer',
                          }}
                        >
                          Release
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        );
      }}
    />
  );
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
