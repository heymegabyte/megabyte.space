import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { GenericTable } from './GenericTable.js';
export default function PayrollPreview({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('payroll-preview');
  return (
    <GenericTable
      title="Payroll preview (Sun→Sat)"
      endpoint="/payroll-preview"
      adminKey={adminKey}
    />
  );
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
