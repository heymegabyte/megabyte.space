import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function PerJobProfit({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('per-job-profit');
  return (
    <GenericTable title="Per-job profit (60d)" endpoint="/per-job-profit" adminKey={adminKey} />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
