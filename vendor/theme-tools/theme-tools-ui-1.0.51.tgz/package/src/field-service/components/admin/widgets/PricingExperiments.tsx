import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { GenericTable } from './GenericTable.js';
export default function PricingExperiments({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('pricing-experiments');
  return (
    <GenericTable title="Pricing experiments" endpoint="/pricing-experiments" adminKey={adminKey} />
  );
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
