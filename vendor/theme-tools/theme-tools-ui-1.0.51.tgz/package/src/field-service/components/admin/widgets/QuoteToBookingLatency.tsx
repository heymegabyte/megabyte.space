import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { GenericTable } from './GenericTable.js';
export default function QuoteToBookingLatency({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('quote-to-booking-latency');
  return (
    <GenericTable
      title="Quote → booking latency"
      endpoint="/quote-to-booking-latency"
      adminKey={adminKey}
    />
  );
}
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
