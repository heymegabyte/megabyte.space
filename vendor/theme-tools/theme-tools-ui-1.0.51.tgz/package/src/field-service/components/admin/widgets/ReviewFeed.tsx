import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function ReviewFeed({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('review-feed');
  return (
    <GenericTable
      title="Review feed (multi-platform)"
      endpoint="/review-feed"
      adminKey={adminKey}
    />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
