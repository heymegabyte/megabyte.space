import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function ReviewResponseQueue({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('review-response-queue');
  return (
    <GenericTable
      title="Review-response queue"
      endpoint="/review-response-queue"
      adminKey={adminKey}
    />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
