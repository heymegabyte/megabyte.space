import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function SavedQueries({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('saved-queries');
  return <GenericTable title="Saved admin queries" endpoint="/saved-queries" adminKey={adminKey} />;
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
