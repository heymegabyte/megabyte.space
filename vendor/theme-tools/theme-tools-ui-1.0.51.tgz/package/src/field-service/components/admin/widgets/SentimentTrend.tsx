import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function SentimentTrend({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('sentiment-trend');
  return (
    <GenericTable title="Sentiment trend (90d)" endpoint="/sentiment-trend" adminKey={adminKey} />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
