import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { WidgetShell, tinyTable } from './WidgetShell.js';

export default function SentryErrors({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('sentry-errors');
  return (
    <WidgetShell
      title="Sentry error feed"
      endpoint="/sentry-errors"
      adminKey={adminKey}
      render={(raw) => {
        const d = raw as {
          empty?: boolean;
          reason?: string;
          errors?: Array<Record<string, unknown>>;
        };
        if (d.empty) return <p style={{ color: '#888' }}>{d.reason ?? 'No errors cached.'}</p>;
        return tinyTable(d.errors || []);
      }}
    />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
