import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { WidgetShell, bigNumber } from './WidgetShell.js';

export default function SeoHealth({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('seo-health');
  return (
    <WidgetShell
      title="AI SEO health card"
      endpoint="/seo-health"
      adminKey={adminKey}
      render={(raw) => {
        const d = raw as { avg_seo_score?: number | null; notes?: string };
        return (
          <>
            {bigNumber(
              'avg SEO score (7d)',
              d.avg_seo_score == null ? '—' : String(d.avg_seo_score),
              d.notes ?? '',
            )}
          </>
        );
      }}
    />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
