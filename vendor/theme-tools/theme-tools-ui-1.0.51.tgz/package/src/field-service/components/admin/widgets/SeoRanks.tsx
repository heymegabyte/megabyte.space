import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function SeoRanks({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('seo-ranks');
  return (
    <GenericTable title="SEO ranks (city × service)" endpoint="/seo-ranks" adminKey={adminKey} />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
