import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { WidgetShell, bigNumber } from './WidgetShell.js';

export default function SmsDeliverability({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('sms-deliverability');
  return (
    <WidgetShell
      title="SMS deliverability (7d)"
      endpoint="/sms-deliverability"
      adminKey={adminKey}
      render={(raw) => {
        const d = raw as {
          empty?: boolean;
          filter_rate_pct?: number;
          summary?: { sent?: number; delivered?: number; filtered?: number; failed?: number };
        };
        if (d.empty) return <p style={{ color: '#888' }}>No SMS events logged.</p>;
        const s = d.summary ?? {};
        return (
          <>
            {bigNumber(
              'carrier filter rate',
              `${d.filter_rate_pct ?? 0}%`,
              `sent ${s.sent ?? 0} · delivered ${s.delivered ?? 0} · filtered ${s.filtered ?? 0} · failed ${s.failed ?? 0}`,
            )}
          </>
        );
      }}
    />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
