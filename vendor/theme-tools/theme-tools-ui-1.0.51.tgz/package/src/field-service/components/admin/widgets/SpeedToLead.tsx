import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { WidgetShell, bigNumber, tinyTable } from './WidgetShell.js';

export default function SpeedToLead({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('speed-to-lead');
  return (
    <WidgetShell
      title="Speed-to-lead (>5min)"
      endpoint="/speed-to-lead"
      adminKey={adminKey}
      render={(raw) => {
        const d = raw as {
          empty?: boolean;
          count_over_5min?: number;
          total?: number;
          samples?: Array<Record<string, unknown>>;
        };
        if (d.empty) return <p style={{ color: '#888' }}>No leads in window.</p>;
        return (
          <>
            {bigNumber(`slow / total leads (30d)`, `${d.count_over_5min || 0} / ${d.total || 0}`)}
            <div style={{ marginTop: 12 }}>{tinyTable(d.samples || [])}</div>
          </>
        );
      }}
    />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
