import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { WidgetShell, tinyTable, bigNumber, formatDollars } from './WidgetShell.js';

export default function SquareReconciliation({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('square-reconciliation');
  return (
    <WidgetShell
      title="Square reconciliation (30d)"
      endpoint="/square-reconciliation"
      adminKey={adminKey}
      render={(raw) => {
        const d = raw as {
          ok?: boolean;
          empty?: boolean;
          total_cents?: number;
          by_status?: Array<Record<string, unknown>>;
        };
        if (d.empty) return <p style={{ color: '#888' }}>No data yet.</p>;
        return (
          <>
            {bigNumber('total settled (30d)', formatDollars(d.total_cents || 0))}
            <div style={{ marginTop: 12 }}>{tinyTable(d.by_status || [])}</div>
          </>
        );
      }}
    />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
