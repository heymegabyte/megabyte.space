import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useState } from 'react';
import { WidgetShell } from './WidgetShell.js';

export default function SurgeSandbox({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('surge-sandbox');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('14:00');
  const [supply, setSupply] = useState('0.5');
  const [result, setResult] = useState<{
    multiplier?: number;
    reasons?: Array<{ label: string; factor: number }>;
  } | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const compute = async () => {
    setErr(null);
    try {
      const res = await fetch('/api/admin/widgets/surge-sandbox', {
        method: 'POST',
        headers: { Authorization: `Bearer ${adminKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          preferredDate: date || undefined,
          preferredTime: time || undefined,
          supply: Number(supply),
        }),
      });
      const json = (await res.json()) as {
        ok?: boolean;
        result?: { multiplier: number; reasons: Array<{ label: string; factor: number }> };
        error?: string;
      };
      if (!json.ok || !json.result) throw new Error(json.error || 'failed');
      setResult(json.result);
    } catch (e) {
      setErr((e as Error).message);
    }
  };

  return (
    <WidgetShell
      title="Surge sandbox (what-if)"
      endpoint="/surge-sandbox"
      adminKey={adminKey}
      render={() => (
        <div>
          <div
            style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 6, marginBottom: 8 }}
          >
            <input
              value={date}
              onChange={(e) => setDate(e.target.value)}
              placeholder="YYYY-MM-DD"
              style={{
                padding: 4,
                background: 'var(--color-surface-field)',
                color: 'var(--color-field-ink)',
                border: '1px solid var(--color-field-line)',
                borderRadius: 4,
              }}
            />
            <input
              value={time}
              onChange={(e) => setTime(e.target.value)}
              placeholder="HH:MM"
              style={{
                padding: 4,
                background: 'var(--color-surface-field)',
                color: 'var(--color-field-ink)',
                border: '1px solid var(--color-field-line)',
                borderRadius: 4,
              }}
            />
            <input
              value={supply}
              onChange={(e) => setSupply(e.target.value)}
              placeholder="supply 0..1"
              style={{
                padding: 4,
                background: 'var(--color-surface-field)',
                color: 'var(--color-field-ink)',
                border: '1px solid var(--color-field-line)',
                borderRadius: 4,
              }}
            />
          </div>
          <button
            type="button"
            onClick={compute}
            style={{
              background: 'var(--color-action-violet)',
              color: 'var(--color-on-emphasis)',
              border: 'none',
              padding: '4px 12px',
              borderRadius: 4,
              cursor: 'pointer',
              fontSize: 12,
            }}
          >
            Compute
          </button>
          {err ? <p style={{ color: 'var(--color-danger-soft)', fontSize: 11 }}>{err}</p> : null}
          {result ? (
            <div style={{ marginTop: 10, fontSize: 12 }}>
              <strong>Multiplier:</strong> {result.multiplier?.toFixed(3)}
              <ul style={{ paddingLeft: 16, marginTop: 4 }}>
                {(result.reasons || []).map((r, i) => (
                  <li key={i}>
                    {r.label} ({r.factor.toFixed(2)}×)
                  </li>
                ))}
              </ul>
            </div>
          ) : null}
        </div>
      )}
    />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
