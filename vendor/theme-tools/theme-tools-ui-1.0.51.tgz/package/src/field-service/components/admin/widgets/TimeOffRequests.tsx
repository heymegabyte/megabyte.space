import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function TimeOffRequests({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('time-off-requests');
  return (
    <GenericTable title="Time-off requests" endpoint="/time-off-requests" adminKey={adminKey} />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
