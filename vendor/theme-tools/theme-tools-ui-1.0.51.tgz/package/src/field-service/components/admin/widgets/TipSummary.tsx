import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { WidgetShell, tinyTable, bigNumber, formatDollars } from './WidgetShell.js';

export default function TipSummary({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('tip-summary');
  return (
    <WidgetShell
      title="Tip reconciliation (30d)"
      endpoint="/tip-summary"
      adminKey={adminKey}
      render={(raw) => {
        const d = raw as {
          empty?: boolean;
          total_tip_cents?: number;
          days?: Array<Record<string, unknown>>;
        };
        if (d.empty) return <p style={{ color: '#888' }}>No tip data yet.</p>;
        return (
          <>
            {bigNumber('total tips', formatDollars(d.total_tip_cents || 0))}
            <div style={{ marginTop: 12 }}>{tinyTable(d.days || [])}</div>
          </>
        );
      }}
    />
  );
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
