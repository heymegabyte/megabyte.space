import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function TrainingRates({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('training-rates');
  return (
    <GenericTable
      title="Training completion rates"
      endpoint="/training-rates"
      adminKey={adminKey}
    />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
