import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function WebVitals({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('web-vitals');
  return (
    <GenericTable title="Core Web Vitals per route" endpoint="/webvitals" adminKey={adminKey} />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
