import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useState } from 'react';

interface WidgetShellProps {
  title: string;
  endpoint: string;
  adminKey: string;
  render: (data: unknown) => JSX.Element;
  initialMethod?: 'GET' | 'POST';
  initialBody?: unknown;
}

/**
 * Tiny fetch+render container reused by every Wave-12 widget. Owns the loading
 * spinner, error state, empty state, and refresh button so each per-widget
 * file is ~10 lines.
 */
export function WidgetShell({
  title,
  endpoint,
  adminKey,
  render,
  initialMethod = 'GET',
  initialBody,
}: WidgetShellProps) {
  useThemeToolsSurface('widget-shell');
  const [data, setData] = useState<unknown>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setBusy(true);
    setErr(null);
    try {
      const res = await fetch(`/api/admin/widgets${endpoint}`, {
        method: initialMethod,
        headers: {
          Authorization: `Bearer ${adminKey}`,
          ...(initialMethod === 'POST' ? { 'Content-Type': 'application/json' } : {}),
        },
        body: initialMethod === 'POST' ? JSON.stringify(initialBody ?? {}) : undefined,
      });
      const json = (await res.json()) as { ok?: boolean; error?: string; empty?: boolean };
      if (!res.ok || json.ok === false) throw new Error(json.error || `HTTP ${res.status}`);
      setData(json);
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setBusy(false);
    }
  }, [endpoint, adminKey, initialMethod, initialBody]);

  useEffect(() => {
    if (!adminKey) return;
    load();
  }, [adminKey, load]);

  return (
    <section
      style={{
        background: 'var(--color-surface-deep)',
        border: '1px solid var(--color-surface-line)',
        borderRadius: 12,
        padding: 16,
        color: 'var(--color-field-ink)',
      }}
    >
      <header
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: 8,
        }}
      >
        <h3 style={{ margin: 0, fontSize: 14, fontWeight: 600, letterSpacing: '0.02em' }}>
          {title}
        </h3>
        <button
          type="button"
          onClick={load}
          disabled={busy}
          style={{
            background: 'transparent',
            color: 'var(--color-action-violet)',
            border: '1px solid var(--color-field-line)',
            padding: '4px 10px',
            borderRadius: 6,
            fontSize: 11,
            cursor: 'pointer',
          }}
        >
          {busy ? 'Loading…' : 'Refresh'}
        </button>
      </header>
      <div style={{ fontSize: 13 }}>
        {err ? (
          <p style={{ color: 'var(--color-danger-soft)' }}>{err}</p>
        ) : data ? (
          render(data)
        ) : (
          <p style={{ color: '#888' }}>Loading…</p>
        )}
      </div>
    </section>
  );
}

export function tinyTable<T extends Record<string, unknown>>(rows: T[], max = 8) {
  if (!rows || rows.length === 0) return <p style={{ color: '#888' }}>No rows.</p>;
  const cols = Object.keys(rows[0] ?? {});
  return (
    <div style={{ overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
        <thead>
          <tr>
            {cols.map((c) => (
              <th
                key={c}
                style={{
                  textAlign: 'left',
                  padding: 4,
                  borderBottom: '1px solid var(--color-field-line)',
                  color: 'var(--color-text-faint)',
                  fontWeight: 500,
                }}
              >
                {c}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.slice(0, max).map((r, i) => (
            <tr key={i}>
              {cols.map((c) => (
                <td key={c} style={{ padding: 4, borderBottom: '1px solid var(--color-surface-inactive)' }}>
                  {formatCell(r[c])}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function formatCell(v: unknown): string {
  if (v == null) return '—';
  if (typeof v === 'number') return Number.isInteger(v) ? String(v) : v.toFixed(2);
  if (typeof v === 'string') return v.length > 40 ? v.slice(0, 40) + '…' : v;
  return JSON.stringify(v);
}

export function bigNumber(label: string, value: string | number, sub?: string) {
  return (
    <div>
      <div style={{ fontSize: 28, fontWeight: 600, letterSpacing: '-0.02em' }}>{value}</div>
      <div style={{ fontSize: 12, color: '#a0a0b8' }}>{label}</div>
      {sub ? <div style={{ fontSize: 11, color: '#666', marginTop: 4 }}>{sub}</div> : null}
    </div>
  );
}

export function formatDollars(cents: number): string {
  return `$${(Math.round(cents) / 100).toFixed(2)}`;
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
