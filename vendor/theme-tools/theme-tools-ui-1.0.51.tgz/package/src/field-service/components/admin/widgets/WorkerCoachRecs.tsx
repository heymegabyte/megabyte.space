import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function WorkerCoachRecs({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('worker-coach-recs');
  return (
    <GenericTable title="AI worker-coach recs" endpoint="/worker-coach-recs" adminKey={adminKey} />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
