import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { GenericTable } from './GenericTable.js';
export default function WorkerSchedule({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('worker-schedule');
  return <GenericTable title="Worker schedule" endpoint="/worker-schedule" adminKey={adminKey} />;
}
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
