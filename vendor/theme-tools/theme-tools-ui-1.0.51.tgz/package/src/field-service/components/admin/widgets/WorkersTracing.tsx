import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme.tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function WorkersTracing({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('workers-tracing');
  return (
    <GenericTable title="Workers Tracing OTLP" endpoint="/workers-tracing" adminKey={adminKey} />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
