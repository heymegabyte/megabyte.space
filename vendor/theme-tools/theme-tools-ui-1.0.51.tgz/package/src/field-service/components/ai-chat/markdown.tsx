import { useThemeToolsSurface } from '../../../field-service-primitives.js';
/// <reference types="trusted-types" />
import { Fragment, type JSX } from 'react';
import DOMPurify from 'dompurify';

/**
 * Tiny safe markdown renderer for chat replies. Supports: bold (**x**),
 * italic (*x* / _x_), inline code (`x`), fenced code blocks (```lang ... ```),
 * bullet/number lists, blockquotes, headings (#-###), and autolinked URLs.
 * Returns React nodes so there's no `dangerouslySetInnerHTML` anywhere.
 *
 * Intentionally NOT a full CommonMark implementation — the worker enforces
 * tone+length, so we render a curated subset that covers 99% of chat output.
 *
 * Trusted Types policy `bcl-md` is registered at module load — any other
 * surface that needs to inject AI-authored HTML can call `renderTrustedHtml`
 * to get a `TrustedHTML` that satisfies `require-trusted-types-for 'script'`.
 */

interface BclMdPolicy {
  readonly createHTML?: (input: string) => string | TrustedHTML;
}

const bclMdPolicy: BclMdPolicy | undefined = (() => {
  if (typeof window === 'undefined') return undefined;
  const tt = window.trustedTypes;
  if (!tt || typeof tt.createPolicy !== 'function') return undefined;
  try {
    return tt.createPolicy('bcl-md', {
      createHTML: (s: string): string =>
        DOMPurify.sanitize(s, { RETURN_TRUSTED_TYPE: false }) as unknown as string,
    });
  } catch {
    // Policy already exists (HMR / repeated module load) — fall through.
    return undefined;
  }
})();

/**
 * Sanitize an HTML string through the `bcl-md` Trusted Types policy. Returns
 * a string (the policy result) that browsers treat as TrustedHTML when CSP's
 * `require-trusted-types-for 'script'` is active.
 */
export function renderTrustedHtml(input: string): string {
  if (bclMdPolicy?.createHTML) return bclMdPolicy.createHTML(input) as unknown as string;
  return DOMPurify.sanitize(input, { RETURN_TRUSTED_TYPE: false }) as unknown as string;
}

interface RenderOpts {
  links?: 'safe' | 'all';
}

export function renderMarkdown(text: string, opts: RenderOpts = {}): JSX.Element {
  const blocks = splitBlocks(text.trim());
  return (
    <>
      {blocks.map((block, i) => (
        <Fragment key={i}>{renderBlock(block, opts)}</Fragment>
      ))}
    </>
  );
}

interface Block {
  kind: 'p' | 'ul' | 'ol' | 'code' | 'h' | 'quote' | 'hr';
  level?: number;
  lang?: string;
  lines: string[];
}

function splitBlocks(text: string): Block[] {
  const raw = text.split(/\n/);
  const out: Block[] = [];
  let i = 0;
  while (i < raw.length) {
    const line = raw[i] ?? '';
    if (!line.trim()) {
      i++;
      continue;
    }
    if (line.startsWith('```')) {
      const lang = line.slice(3).trim();
      const lines: string[] = [];
      i++;
      while (i < raw.length && !(raw[i] ?? '').startsWith('```')) {
        lines.push(raw[i] ?? '');
        i++;
      }
      i++;
      out.push({ kind: 'code', lang, lines });
      continue;
    }
    if (/^---+$/.test(line.trim())) {
      out.push({ kind: 'hr', lines: [] });
      i++;
      continue;
    }
    const headingMatch = line.match(/^(#{1,3})\s+(.*)$/);
    if (headingMatch) {
      out.push({ kind: 'h', level: headingMatch[1]!.length, lines: [headingMatch[2]!] });
      i++;
      continue;
    }
    if (line.startsWith('>')) {
      const lines: string[] = [];
      while (i < raw.length && (raw[i] ?? '').startsWith('>')) {
        lines.push((raw[i] ?? '').replace(/^>\s?/, ''));
        i++;
      }
      out.push({ kind: 'quote', lines });
      continue;
    }
    if (/^[-*+]\s+/.test(line)) {
      const lines: string[] = [];
      while (i < raw.length && /^[-*+]\s+/.test(raw[i] ?? '')) {
        lines.push((raw[i] ?? '').replace(/^[-*+]\s+/, ''));
        i++;
      }
      out.push({ kind: 'ul', lines });
      continue;
    }
    if (/^\d+[.)]\s+/.test(line)) {
      const lines: string[] = [];
      while (i < raw.length && /^\d+[.)]\s+/.test(raw[i] ?? '')) {
        lines.push((raw[i] ?? '').replace(/^\d+[.)]\s+/, ''));
        i++;
      }
      out.push({ kind: 'ol', lines });
      continue;
    }
    const lines: string[] = [];
    while (i < raw.length) {
      const peek = raw[i] ?? '';
      if (
        !peek.trim() ||
        peek.startsWith('```') ||
        peek.startsWith('#') ||
        peek.startsWith('>') ||
        /^[-*+]\s+/.test(peek) ||
        /^\d+[.)]\s+/.test(peek)
      ) {
        break;
      }
      lines.push(peek);
      i++;
    }
    out.push({ kind: 'p', lines });
  }
  return out;
}

function renderBlock(block: Block, opts: RenderOpts): JSX.Element {
  switch (block.kind) {
    case 'code':
      return (
        <pre className="my-2 overflow-x-auto rounded-lg border border-brand-line bg-black/40 p-3 text-xs leading-relaxed">
          <code className="font-mono text-brand-ink/90">{block.lines.join('\n')}</code>
        </pre>
      );
    case 'h': {
      const cls =
        block.level === 1
          ? 'mt-2 text-lg font-bold text-brand-ink'
          : block.level === 2
            ? 'mt-2 text-base font-semibold text-brand-ink'
            : 'mt-2 text-sm font-semibold text-brand-ink';
      return <p className={cls}>{renderInline(block.lines.join(' '), opts)}</p>;
    }
    case 'quote':
      return (
        <blockquote className="my-2 border-l-2 border-brand-accent/60 pl-3 text-sm italic text-brand-ink/80">
          {block.lines.map((l, idx) => (
            <div key={idx}>{renderInline(l, opts)}</div>
          ))}
        </blockquote>
      );
    case 'ul':
      return (
        <ul className="my-1 list-disc space-y-1 pl-5 text-sm leading-relaxed text-brand-ink/90">
          {block.lines.map((l, idx) => (
            <li key={idx}>{renderInline(l, opts)}</li>
          ))}
        </ul>
      );
    case 'ol':
      return (
        <ol className="my-1 list-decimal space-y-1 pl-5 text-sm leading-relaxed text-brand-ink/90">
          {block.lines.map((l, idx) => (
            <li key={idx}>{renderInline(l, opts)}</li>
          ))}
        </ol>
      );
    case 'hr':
      return <hr className="my-3 border-brand-line" />;
    case 'p':
    default:
      return (
        <p className="my-1 text-sm leading-relaxed text-brand-ink/90">
          {block.lines.map((line, idx) => (
            <Fragment key={idx}>
              {idx > 0 ? <br /> : null}
              {renderInline(line, opts)}
            </Fragment>
          ))}
        </p>
      );
  }
}

const INLINE_RE =
  /(\*\*[^*\n]+\*\*|__[^_\n]+__|\*[^*\n]+\*|_[^_\n]+_|`[^`\n]+`|\[[^\]\n]+\]\([^)\n]+\)|https?:\/\/[^\s)]+)/g;

function renderInline(text: string, _opts: RenderOpts): JSX.Element {
  const parts: (string | JSX.Element)[] = [];
  let lastIndex = 0;
  let match: RegExpExecArray | null;
  INLINE_RE.lastIndex = 0;
  while ((match = INLINE_RE.exec(text))) {
    if (match.index > lastIndex) parts.push(text.slice(lastIndex, match.index));
    const token = match[0];
    parts.push(renderToken(token, parts.length));
    lastIndex = match.index + token.length;
  }
  if (lastIndex < text.length) parts.push(text.slice(lastIndex));
  return <>{parts}</>;
}

function renderToken(token: string, key: number): JSX.Element {
  if (
    (token.startsWith('**') && token.endsWith('**')) ||
    (token.startsWith('__') && token.endsWith('__'))
  ) {
    return (
      <strong key={key} className="font-semibold text-brand-ink">
        {token.slice(2, -2)}
      </strong>
    );
  }
  if (
    (token.startsWith('*') && token.endsWith('*')) ||
    (token.startsWith('_') && token.endsWith('_'))
  ) {
    return (
      <em key={key} className="italic">
        {token.slice(1, -1)}
      </em>
    );
  }
  if (token.startsWith('`') && token.endsWith('`')) {
    return (
      <code
        key={key}
        className="rounded border border-brand-line/60 bg-black/30 px-1 py-0.5 font-mono text-[12px]"
      >
        {token.slice(1, -1)}
      </code>
    );
  }
  const link = token.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
  if (link) {
    const safe = safeHref(link[2] ?? '');
    if (!safe) return <span key={key}>{link[1]}</span>;
    return (
      <a
        key={key}
        href={safe}
        target={safe.startsWith('http') ? '_blank' : undefined}
        rel={safe.startsWith('http') ? 'noopener noreferrer' : undefined}
        className="text-brand-accent underline-offset-2 hover:underline"
      >
        {link[1]}
      </a>
    );
  }
  if (token.startsWith('http')) {
    const safe = safeHref(token);
    if (!safe) return <span key={key}>{token}</span>;
    return (
      <a
        key={key}
        href={safe}
        target="_blank"
        rel="noopener noreferrer"
        className="text-brand-accent underline-offset-2 hover:underline"
      >
        {token}
      </a>
    );
  }
  return <span key={key}>{token}</span>;
}

/**
 * Allow only http(s):, mailto:, tel:, sms:, and same-origin relative URLs.
 * `javascript:` and `data:` are rejected — never trust LLM-generated href.
 */
export function safeHref(input: string): string | undefined {
  const v = input.trim();
  if (!v) return undefined;
  if (v.startsWith('#') || v.startsWith('/')) return v;
  if (/^(mailto:|tel:|sms:)/i.test(v)) return v;
  if (/^https?:\/\//i.test(v)) return v;
  return undefined;
}
