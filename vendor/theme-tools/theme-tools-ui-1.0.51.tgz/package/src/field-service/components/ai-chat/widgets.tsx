import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { useEffect, useRef, useState, type JSX, type ReactNode } from 'react';
import type { AiChatLink, AiChatWidget } from '@theme.tools/agent-ui/field-service/ai-chat';
import { safeHref } from './markdown.js';

/**
 * Widget renderer dispatch. Every widget kind from the shared schema has
 * exactly one renderer here — adding a new widget = add a Zod variant in
 * `src/shared/ai-chat.ts` + a `case` here. Renderers are pure JSX, no
 * `dangerouslySetInnerHTML`, all hrefs sanitized through `safeHref`.
 */

interface WidgetProps {
  widget: AiChatWidget;
  onAction?: (action: string) => void;
}

export function WidgetView({ widget, onAction }: WidgetProps): JSX.Element | null {
  useThemeToolsSurface('widgets');
  switch (widget.kind) {
    case 'cta':
      return <CtaWidget widget={widget} onAction={onAction} />;
    case 'link-card':
      return <LinkCardWidget widget={widget} />;
    case 'photo':
      return <PhotoWidget widget={widget} />;
    case 'gallery':
      return <GalleryWidget widget={widget} />;
    case 'pricing':
      return <PricingWidget widget={widget} />;
    case 'faq':
      return <FaqWidget widget={widget} />;
    case 'table':
      return <TableWidget widget={widget} />;
    case 'stat':
      return <StatWidget widget={widget} />;
    case 'status':
      return <StatusWidget widget={widget} />;
    case 'alert':
      return <AlertWidget widget={widget} />;
    case 'person':
      return <PersonWidget widget={widget} />;
    case 'testimonial':
      return <TestimonialWidget widget={widget} />;
    case 'map':
      return <MapWidget widget={widget} />;
    case 'hours':
      return <HoursWidget widget={widget} />;
    case 'booking-summary':
      return <BookingSummaryWidget widget={widget} />;
    case 'suggestions':
      return <SuggestionsWidget widget={widget} onAction={onAction} />;
    case 'citation':
      return <CitationWidget widget={widget} />;
    case 'code':
      return <CodeWidget widget={widget} />;
    case 'command-palette':
      return <CommandPaletteWidget widget={widget} onAction={onAction} />;
    case 'timeline':
      return <TimelineWidget widget={widget} />;
    case 'checklist':
      return <ChecklistWidget widget={widget} />;
    case 'progress':
      return <ProgressWidget widget={widget} />;
    case 'comparison':
      return <ComparisonWidget widget={widget} />;
    case 'video':
      return <VideoWidget widget={widget} />;
    case 'related-pages':
      return <RelatedPagesWidget widget={widget} />;
    case 'chart':
      return <ChartWidget widget={widget} />;
    case 'newsletter':
      return <NewsletterWidget widget={widget} />;
    case 'donation':
      return <DonationWidget widget={widget} />;
    case 'search-results':
      return <SearchResultsWidget widget={widget} />;
    case 'document':
      return <DocumentWidget widget={widget} />;
    case 'next-action':
      return <NextActionWidget widget={widget} />;
    case 'rating':
      return <RatingWidget widget={widget} onAction={onAction} />;
    case 'booking-action-preview':
      return <BookingActionPreviewWidget widget={widget} onAction={onAction} />;
    case 'reschedule-confirm':
      return <RescheduleConfirmWidget widget={widget} onAction={onAction} />;
    case 'claim-draft':
      return <ClaimDraftWidget widget={widget} onAction={onAction} />;
    case 'tip-dispatch':
      return <TipDispatchWidget widget={widget} onAction={onAction} />;
    case 'hire-again-preview':
      return <HireAgainPreviewWidget widget={widget} onAction={onAction} />;
    case 'human-handoff':
      return <HumanHandoffWidget widget={widget} />;
    default:
      return null;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Shared helpers
// ─────────────────────────────────────────────────────────────────────────────

function WidgetShell({
  children,
  title,
  tone,
}: {
  children: React.ReactNode;
  title?: string;
  tone?: 'default' | 'success' | 'warn' | 'error' | 'info';
}): JSX.Element {
  const ring =
    tone === 'success'
      ? 'border-emerald-500/40'
      : tone === 'warn'
        ? 'border-amber-500/40'
        : tone === 'error'
          ? 'border-red-500/40'
          : tone === 'info'
            ? 'border-sky-500/40'
            : 'border-brand-line';
  return (
    <div className={`my-2 rounded-xl border ${ring} bg-bg-elevated/60 p-3 text-sm`}>
      {title ? (
        <div className="mb-2 text-xs font-mono uppercase tracking-wider text-brand-mute">
          {title}
        </div>
      ) : null}
      {children}
    </div>
  );
}

function LinkButton({
  link,
  onAction,
}: {
  link: AiChatLink;
  onAction?: (action: string) => void;
}): JSX.Element {
  const href = safeHref(link.href);
  const base =
    link.variant === 'primary'
      ? 'inline-flex items-center justify-center rounded-lg bg-brand-accent px-3 py-1.5 text-xs font-mono font-semibold uppercase tracking-wider text-bg-primary transition-colors hover:bg-brand-accent/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent focus-visible:ring-offset-2 focus-visible:ring-offset-bg-primary'
      : link.variant === 'ghost'
        ? 'inline-flex items-center justify-center rounded-lg px-3 py-1.5 text-xs font-mono uppercase tracking-wider text-brand-ink/90 hover:bg-brand-line/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent'
        : 'inline-flex items-center justify-center rounded-lg border border-brand-line bg-bg-primary/40 px-3 py-1.5 text-xs font-mono uppercase tracking-wider text-brand-ink/90 hover:border-brand-accent/60 hover:text-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent';
  if (!href) {
    return (
      <button type="button" className={base} onClick={() => onAction?.(link.label)}>
        {link.label}
      </button>
    );
  }
  const isExternal = link.external || href.startsWith('http');
  return (
    <a
      href={href}
      target={isExternal ? '_blank' : undefined}
      rel={isExternal ? 'noopener noreferrer' : undefined}
      className={base}
    >
      {link.label}
    </a>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Concrete widgets
// ─────────────────────────────────────────────────────────────────────────────

function CtaWidget({
  widget,
  onAction,
}: {
  widget: Extract<AiChatWidget, { kind: 'cta' }>;
  onAction?: (action: string) => void;
}): JSX.Element {
  return (
    <WidgetShell>
      <div className="text-sm font-semibold text-brand-ink">{widget.title}</div>
      {widget.body ? <div className="mt-1 text-xs text-brand-mute">{widget.body}</div> : null}
      <div className="mt-2 flex flex-wrap gap-2">
        {widget.links.map((l, idx) => (
          <LinkButton key={idx} link={l} onAction={onAction} />
        ))}
      </div>
    </WidgetShell>
  );
}

function LinkCardWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'link-card' }>;
}): JSX.Element {
  const href = safeHref(widget.href);
  const inner = (
    <>
      <div className="flex items-center justify-between gap-2">
        <div className="text-sm font-semibold text-brand-ink">{widget.title}</div>
        {widget.badge ? (
          <span className="rounded-full border border-brand-accent/40 bg-brand-accent/10 px-2 py-0.5 text-[10px] font-mono uppercase tracking-wider text-brand-accent">
            {widget.badge}
          </span>
        ) : null}
      </div>
      {widget.description ? (
        <div className="mt-1 text-xs text-brand-mute">{widget.description}</div>
      ) : null}
      <div className="mt-2 text-xs font-mono uppercase tracking-wider text-brand-accent">
        Open →
      </div>
    </>
  );
  if (!href) return <WidgetShell>{inner}</WidgetShell>;
  return (
    <a
      href={href}
      target={href.startsWith('http') ? '_blank' : undefined}
      rel={href.startsWith('http') ? 'noopener noreferrer' : undefined}
      className="my-2 block rounded-xl border border-brand-line bg-bg-elevated/60 p-3 transition-colors hover:border-brand-accent/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
    >
      {inner}
    </a>
  );
}

function PhotoWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'photo' }>;
}): JSX.Element {
  const aspect =
    widget.aspect === 'square'
      ? 'aspect-square'
      : widget.aspect === 'wide'
        ? 'aspect-[21/9]'
        : widget.aspect === 'portrait'
          ? 'aspect-[3/4]'
          : 'aspect-video';
  const href = widget.href ? safeHref(widget.href) : undefined;
  const img = (
    <img
      src={widget.src}
      alt={widget.alt}
      loading="lazy"
      decoding="async"
      className={`block w-full rounded-lg border border-brand-line bg-bg-primary/40 object-cover ${aspect}`}
    />
  );
  return (
    <WidgetShell>
      {href ? (
        <a
          href={href}
          target={href.startsWith('http') ? '_blank' : undefined}
          rel={href.startsWith('http') ? 'noopener noreferrer' : undefined}
        >
          {img}
        </a>
      ) : (
        img
      )}
      {widget.caption ? (
        <div className="mt-1 text-[11px] italic text-brand-mute">{widget.caption}</div>
      ) : null}
    </WidgetShell>
  );
}

function GalleryWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'gallery' }>;
}): JSX.Element {
  return (
    <WidgetShell title={widget.title}>
      <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
        {widget.items.map((item, idx) => (
          <figure
            key={idx}
            className="overflow-hidden rounded-md border border-brand-line bg-bg-primary/40"
          >
            <img
              src={item.src}
              alt={item.alt}
              loading="lazy"
              decoding="async"
              className="block aspect-square w-full object-cover"
            />
            {item.caption ? (
              <figcaption className="px-1.5 py-1 text-[10px] text-brand-mute">
                {item.caption}
              </figcaption>
            ) : null}
          </figure>
        ))}
      </div>
    </WidgetShell>
  );
}

function PricingWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'pricing' }>;
}): JSX.Element {
  return (
    <WidgetShell title={widget.title || 'Pricing'}>
      <ul className="space-y-1.5">
        {widget.rows.map((row, idx) => (
          <li
            key={idx}
            className="flex items-center justify-between gap-3 border-b border-brand-line/40 pb-1.5 last:border-b-0 last:pb-0"
          >
            <span className="text-xs text-brand-mute">{row.label}</span>
            <span className="text-sm font-semibold text-brand-ink">{row.value}</span>
            {row.note ? <span className="ml-1 text-[10px] text-brand-mute">{row.note}</span> : null}
          </li>
        ))}
      </ul>
      {widget.cta ? (
        <div className="mt-2.5">
          <LinkButton link={widget.cta} />
        </div>
      ) : null}
    </WidgetShell>
  );
}

function FaqWidget({ widget }: { widget: Extract<AiChatWidget, { kind: 'faq' }> }): JSX.Element {
  return (
    <WidgetShell title={widget.title || 'FAQ'}>
      <div className="space-y-1.5">
        {widget.items.map((item, idx) => (
          <details
            key={idx}
            className="group rounded-md border border-brand-line/60 bg-bg-primary/40 px-2.5 py-1.5"
          >
            <summary className="cursor-pointer list-none text-xs font-semibold text-brand-ink marker:hidden">
              <span className="mr-1 inline-block text-brand-accent transition-transform group-open:rotate-90">
                ›
              </span>
              {item.question}
            </summary>
            <div className="mt-1.5 pl-3 text-xs leading-relaxed text-brand-ink/80">
              {item.answer}
            </div>
          </details>
        ))}
      </div>
    </WidgetShell>
  );
}

function TableWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'table' }>;
}): JSX.Element {
  return (
    <WidgetShell title={widget.title}>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="border-b border-brand-line">
              {widget.headers.map((h, idx) => (
                <th
                  key={idx}
                  className="px-2 py-1.5 font-mono text-[10px] uppercase tracking-wider text-brand-mute"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {widget.rows.map((row, ridx) => (
              <tr key={ridx} className="border-b border-brand-line/40 last:border-b-0">
                {row.map((cell, cidx) => (
                  <td key={cidx} className="px-2 py-1.5 text-brand-ink/90">
                    {cell}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </WidgetShell>
  );
}

function StatWidget({ widget }: { widget: Extract<AiChatWidget, { kind: 'stat' }> }): JSX.Element {
  return (
    <WidgetShell>
      <div className="grid grid-cols-2 gap-2">
        {widget.items.map((item, idx) => (
          <div key={idx} className="rounded-md border border-brand-line/60 bg-bg-primary/40 p-2">
            <div className="text-[10px] font-mono uppercase tracking-wider text-brand-mute">
              {item.label}
            </div>
            <div className="mt-0.5 text-lg font-bold text-brand-ink">{item.value}</div>
            {item.helper ? <div className="text-[10px] text-brand-mute">{item.helper}</div> : null}
          </div>
        ))}
      </div>
    </WidgetShell>
  );
}

function StatusWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'status' }>;
}): JSX.Element {
  const tone =
    widget.level === 'ok'
      ? 'success'
      : widget.level === 'error'
        ? 'error'
        : widget.level === 'warn'
          ? 'warn'
          : 'info';
  const dot =
    widget.level === 'ok'
      ? 'bg-emerald-400'
      : widget.level === 'error'
        ? 'bg-red-400'
        : widget.level === 'warn'
          ? 'bg-amber-400'
          : 'bg-sky-400';
  return (
    <WidgetShell tone={tone}>
      <div className="flex items-start gap-2">
        <span className={`mt-1 inline-block h-2 w-2 shrink-0 rounded-full ${dot}`} />
        <div className="flex-1">
          <div className="text-sm font-semibold text-brand-ink">{widget.title}</div>
          {widget.body ? <div className="mt-0.5 text-xs text-brand-mute">{widget.body}</div> : null}
        </div>
      </div>
    </WidgetShell>
  );
}

function AlertWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'alert' }>;
}): JSX.Element {
  const tone = widget.level;
  return (
    <WidgetShell tone={tone}>
      <div className="text-sm font-semibold text-brand-ink">{widget.title}</div>
      {widget.body ? <div className="mt-1 text-xs text-brand-mute">{widget.body}</div> : null}
      {widget.action ? (
        <div className="mt-2">
          <LinkButton link={widget.action} />
        </div>
      ) : null}
    </WidgetShell>
  );
}

function PersonWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'person' }>;
}): JSX.Element {
  return (
    <WidgetShell>
      <div className="flex items-start gap-3">
        {widget.photo ? (
          <img
            src={widget.photo}
            alt={widget.name}
            loading="lazy"
            decoding="async"
            className="h-12 w-12 shrink-0 rounded-full border border-brand-line object-cover"
          />
        ) : (
          <div className="grid h-12 w-12 shrink-0 place-items-center rounded-full border border-brand-line bg-bg-primary/40 text-sm font-bold text-brand-accent">
            {widget.name.slice(0, 1)}
          </div>
        )}
        <div className="flex-1">
          <div className="text-sm font-semibold text-brand-ink">{widget.name}</div>
          {widget.role ? (
            <div className="text-[11px] uppercase tracking-wider text-brand-mute">
              {widget.role}
            </div>
          ) : null}
          {widget.bio ? <div className="mt-1 text-xs text-brand-ink/80">{widget.bio}</div> : null}
        </div>
      </div>
      {widget.contacts?.length ? (
        <div className="mt-2 flex flex-wrap gap-2">
          {widget.contacts.map((c, idx) => (
            <LinkButton key={idx} link={c} />
          ))}
        </div>
      ) : null}
    </WidgetShell>
  );
}

function TestimonialWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'testimonial' }>;
}): JSX.Element {
  return (
    <WidgetShell>
      {typeof widget.rating === 'number' ? (
        <div className="mb-1 text-amber-400" aria-label={`${widget.rating} out of 5`}>
          {'★'.repeat(widget.rating)}
          <span className="text-brand-line">{'★'.repeat(5 - widget.rating)}</span>
        </div>
      ) : null}
      <blockquote className="text-sm italic text-brand-ink/90">"{widget.quote}"</blockquote>
      {widget.author || widget.source ? (
        <div className="mt-1.5 text-[11px] text-brand-mute">
          — {widget.author || 'Customer'}
          {widget.source ? ` · ${widget.source}` : ''}
        </div>
      ) : null}
    </WidgetShell>
  );
}

function MapWidget({ widget }: { widget: Extract<AiChatWidget, { kind: 'map' }> }): JSX.Element {
  const mapHref = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(widget.query)}`;
  return (
    <WidgetShell title={widget.label || 'Map'}>
      <a
        href={mapHref}
        target="_blank"
        rel="noopener noreferrer"
        className="block rounded-md border border-brand-line bg-bg-primary/40 px-3 py-2 text-xs font-mono uppercase tracking-wider text-brand-accent hover:border-brand-accent/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
      >
        Open in Google Maps · {widget.query}
      </a>
    </WidgetShell>
  );
}

function HoursWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'hours' }>;
}): JSX.Element {
  return (
    <WidgetShell title={widget.title || 'Hours'}>
      <ul className="space-y-1">
        {widget.rows.map((row, idx) => (
          <li key={idx} className="flex items-center justify-between text-xs">
            <span className="text-brand-mute">{row.label}</span>
            <span className="font-semibold text-brand-ink">{row.value}</span>
          </li>
        ))}
      </ul>
      {widget.note ? (
        <div className="mt-1.5 text-[11px] italic text-brand-mute">{widget.note}</div>
      ) : null}
    </WidgetShell>
  );
}

function BookingSummaryWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'booking-summary' }>;
}): JSX.Element {
  return (
    <WidgetShell title="Booking">
      <div className="flex items-center justify-between">
        <span className="text-xs uppercase tracking-wider text-brand-mute">{widget.status}</span>
        {typeof widget.totalDollars === 'number' ? (
          <span className="text-sm font-bold text-brand-accent">${widget.totalDollars}</span>
        ) : null}
      </div>
      <div className="mt-2 grid grid-cols-2 gap-1.5 text-xs">
        {widget.date ? (
          <div>
            <div className="text-[10px] font-mono uppercase tracking-wider text-brand-mute">
              Date
            </div>
            <div className="text-brand-ink">{widget.date}</div>
          </div>
        ) : null}
        {widget.time ? (
          <div>
            <div className="text-[10px] font-mono uppercase tracking-wider text-brand-mute">
              Time
            </div>
            <div className="text-brand-ink">{widget.time}</div>
          </div>
        ) : null}
        {typeof widget.hours === 'number' ? (
          <div>
            <div className="text-[10px] font-mono uppercase tracking-wider text-brand-mute">
              Hours
            </div>
            <div className="text-brand-ink">{widget.hours}h</div>
          </div>
        ) : null}
        {typeof widget.crew === 'number' ? (
          <div>
            <div className="text-[10px] font-mono uppercase tracking-wider text-brand-mute">
              Crew
            </div>
            <div className="text-brand-ink">{widget.crew}</div>
          </div>
        ) : null}
      </div>
      {widget.trackHref ? (
        <div className="mt-2">
          <LinkButton
            link={{ label: 'Track booking', href: widget.trackHref, variant: 'primary' }}
          />
        </div>
      ) : null}
    </WidgetShell>
  );
}

function SuggestionsWidget({
  widget,
  onAction,
}: {
  widget: Extract<AiChatWidget, { kind: 'suggestions' }>;
  onAction?: (action: string) => void;
}): JSX.Element {
  return (
    <WidgetShell title={widget.title || 'Try'}>
      <div className="flex flex-wrap gap-1.5">
        {widget.items.map((item, idx) => (
          <button
            key={idx}
            type="button"
            onClick={() => onAction?.(item)}
            className="rounded-full border border-brand-line bg-bg-primary/40 px-2.5 py-1 text-[11px] text-brand-ink/90 transition-colors hover:border-brand-accent/60 hover:text-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
          >
            {item}
          </button>
        ))}
      </div>
    </WidgetShell>
  );
}

function CitationWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'citation' }>;
}): JSX.Element {
  return (
    <WidgetShell title="Sources">
      <ol className="list-decimal space-y-1 pl-4 text-[11px] text-brand-ink/80">
        {widget.refs.map((ref, idx) => {
          const href = safeHref(ref.href);
          return (
            <li key={idx}>
              {href ? (
                <a
                  href={href}
                  target={href.startsWith('http') ? '_blank' : undefined}
                  rel={href.startsWith('http') ? 'noopener noreferrer' : undefined}
                  className="text-brand-accent underline-offset-2 hover:underline"
                >
                  {ref.label}
                </a>
              ) : (
                <span>{ref.label}</span>
              )}
              {ref.source ? <span className="ml-1 text-brand-mute">· {ref.source}</span> : null}
            </li>
          );
        })}
      </ol>
    </WidgetShell>
  );
}

function CodeWidget({ widget }: { widget: Extract<AiChatWidget, { kind: 'code' }> }): JSX.Element {
  return (
    <WidgetShell title={widget.language ? widget.language.toUpperCase() : 'Code'}>
      <pre className="overflow-x-auto rounded-md border border-brand-line bg-black/40 p-2.5 text-xs leading-relaxed">
        <code className="font-mono text-brand-ink/90">{widget.code}</code>
      </pre>
      {widget.caption ? (
        <div className="mt-1 text-[11px] italic text-brand-mute">{widget.caption}</div>
      ) : null}
    </WidgetShell>
  );
}

function CommandPaletteWidget({
  widget,
  onAction,
}: {
  widget: Extract<AiChatWidget, { kind: 'command-palette' }>;
  onAction?: (action: string) => void;
}): JSX.Element {
  return (
    <WidgetShell title={widget.title || 'Slash commands'}>
      <div className="space-y-3">
        {widget.groups.map((group, gidx) => (
          <div key={gidx}>
            <div className="mb-1 text-[10px] font-mono uppercase tracking-wider text-brand-accent">
              {group.label}
            </div>
            <ul className="space-y-1">
              {group.items.map((item, idx) => {
                const href = item.href ? safeHref(item.href) : undefined;
                const label = (
                  <>
                    <span className="font-mono text-brand-accent">/{item.command}</span>
                    <span className="ml-2 text-xs text-brand-mute">{item.description}</span>
                  </>
                );
                if (href) {
                  return (
                    <li key={idx}>
                      <a
                        href={href}
                        target={href.startsWith('http') ? '_blank' : undefined}
                        rel={href.startsWith('http') ? 'noopener noreferrer' : undefined}
                        className="flex items-baseline rounded-md px-2 py-1 hover:bg-brand-line/30 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
                      >
                        {label}
                      </a>
                    </li>
                  );
                }
                return (
                  <li key={idx}>
                    <button
                      type="button"
                      onClick={() => onAction?.(`/${item.command}`)}
                      className="flex w-full items-baseline rounded-md px-2 py-1 text-left hover:bg-brand-line/30 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
                    >
                      {label}
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </div>
    </WidgetShell>
  );
}

function TimelineWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'timeline' }>;
}): JSX.Element {
  return (
    <WidgetShell title={widget.title}>
      <ol className="relative space-y-2.5 border-l border-brand-line/60 pl-3">
        {widget.items.map((item, idx) => {
          const dot =
            item.state === 'done'
              ? 'bg-emerald-400'
              : item.state === 'current'
                ? 'bg-brand-accent'
                : 'bg-brand-line';
          return (
            <li key={idx} className="relative">
              <span
                className={`absolute -left-[1.05rem] top-1 inline-block h-2 w-2 rounded-full ${dot}`}
                aria-hidden="true"
              />
              <div className="flex items-baseline justify-between gap-2">
                <div className="text-sm font-semibold text-brand-ink">{item.title}</div>
                <div className="text-[10px] font-mono uppercase tracking-wider text-brand-mute">
                  {item.label}
                </div>
              </div>
              {item.body ? (
                <div className="mt-0.5 text-xs text-brand-ink/80">{item.body}</div>
              ) : null}
            </li>
          );
        })}
      </ol>
    </WidgetShell>
  );
}

function ChecklistWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'checklist' }>;
}): JSX.Element {
  return (
    <WidgetShell title={widget.title}>
      <ul className="space-y-1">
        {widget.items.map((item, idx) => (
          <li key={idx} className="flex items-start gap-2 text-xs">
            <span
              aria-hidden="true"
              className={`mt-0.5 inline-grid h-3.5 w-3.5 shrink-0 place-items-center rounded border ${
                item.done
                  ? 'border-emerald-400/60 bg-emerald-400/20 text-emerald-300'
                  : 'border-brand-line bg-bg-primary/40 text-transparent'
              }`}
            >
              ✓
            </span>
            <span className={item.done ? 'text-brand-mute line-through' : 'text-brand-ink/90'}>
              {item.text}
            </span>
          </li>
        ))}
      </ul>
      {widget.note ? (
        <div className="mt-1.5 text-[11px] italic text-brand-mute">{widget.note}</div>
      ) : null}
    </WidgetShell>
  );
}

function ProgressWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'progress' }>;
}): JSX.Element {
  const total = widget.steps.length;
  const current = Math.min(Math.max(widget.current, 0), total - 1);
  const pct = Math.round(((current + 1) / total) * 100);
  return (
    <WidgetShell title={widget.title}>
      <div
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={total}
        aria-valuenow={current + 1}
        aria-label={`${widget.title}: step ${current + 1} of ${total}`}
        className="mb-2 h-1.5 w-full overflow-hidden rounded-full bg-brand-line/40"
      >
        <div
          className="h-full bg-brand-accent transition-[width] duration-300"
          style={{ width: `${pct}%` }}
        />
      </div>
      <ol className="grid grid-cols-2 gap-1 sm:grid-cols-4">
        {widget.steps.map((step, idx) => {
          const state = idx < current ? 'done' : idx === current ? 'current' : 'pending';
          const tone =
            state === 'done'
              ? 'text-emerald-300'
              : state === 'current'
                ? 'text-brand-accent'
                : 'text-brand-mute';
          return (
            <li key={idx} className={`text-[11px] font-mono uppercase tracking-wider ${tone}`}>
              <span aria-hidden="true">{state === 'done' ? '✓' : `${idx + 1}.`} </span>
              {step}
            </li>
          );
        })}
      </ol>
      {widget.body ? <div className="mt-1.5 text-xs text-brand-ink/80">{widget.body}</div> : null}
    </WidgetShell>
  );
}

function ComparisonWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'comparison' }>;
}): JSX.Element {
  return (
    <WidgetShell title={widget.title}>
      <div
        className={`grid gap-2 ${widget.options.length === 3 ? 'sm:grid-cols-3' : 'sm:grid-cols-2'}`}
      >
        {widget.options.map((opt, idx) => (
          <div
            key={idx}
            className={`flex flex-col gap-1.5 rounded-md border p-2 ${
              opt.highlight
                ? 'border-brand-accent/60 bg-brand-accent/5'
                : 'border-brand-line/60 bg-bg-primary/40'
            }`}
          >
            <div className="flex items-baseline justify-between">
              <div className="text-sm font-semibold text-brand-ink">{opt.name}</div>
              {opt.price ? (
                <div className="text-sm font-bold text-brand-accent">{opt.price}</div>
              ) : null}
            </div>
            {opt.pros?.length ? (
              <ul className="space-y-0.5 text-[11px] text-emerald-300/90">
                {opt.pros.map((p, i) => (
                  <li key={i}>
                    <span aria-hidden="true">+ </span>
                    {p}
                  </li>
                ))}
              </ul>
            ) : null}
            {opt.cons?.length ? (
              <ul className="space-y-0.5 text-[11px] text-amber-300/90">
                {opt.cons.map((p, i) => (
                  <li key={i}>
                    <span aria-hidden="true">− </span>
                    {p}
                  </li>
                ))}
              </ul>
            ) : null}
            {opt.cta ? (
              <div className="mt-auto pt-1">
                <LinkButton link={opt.cta} />
              </div>
            ) : null}
          </div>
        ))}
      </div>
    </WidgetShell>
  );
}

function VideoWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'video' }>;
}): JSX.Element {
  const src = safeHref(widget.src);
  const provider = widget.provider ?? inferVideoProvider(src);
  const embedSrc = provider !== 'file' ? toEmbedUrl(src, provider) : src;
  return (
    <WidgetShell title={widget.title}>
      {embedSrc && provider !== 'file' ? (
        <div className="overflow-hidden rounded-md border border-brand-line">
          <iframe
            src={embedSrc}
            title={widget.title || 'Embedded video'}
            loading="lazy"
            allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowFullScreen
            className="aspect-video w-full"
          />
        </div>
      ) : src ? (
        <video
          src={src}
          poster={widget.poster ? safeHref(widget.poster) : undefined}
          controls
          preload="metadata"
          className="block w-full rounded-md border border-brand-line"
        >
          Your browser cannot play this video.
        </video>
      ) : (
        <div className="text-xs text-brand-mute">Video unavailable</div>
      )}
      {widget.caption ? (
        <div className="mt-1 text-[11px] italic text-brand-mute">{widget.caption}</div>
      ) : null}
    </WidgetShell>
  );
}

function inferVideoProvider(src: string | undefined): 'youtube' | 'vimeo' | 'file' {
  if (!src) return 'file';
  if (/youtube\.com|youtu\.be/.test(src)) return 'youtube';
  if (/vimeo\.com/.test(src)) return 'vimeo';
  return 'file';
}

function toEmbedUrl(
  src: string | undefined,
  provider: 'youtube' | 'vimeo' | 'file',
): string | undefined {
  if (!src) return undefined;
  if (provider === 'youtube') {
    const m = src.match(/(?:youtu\.be\/|v=|embed\/)([\w-]{6,})/);
    if (m && m[1]) return `https://www.youtube-nocookie.com/embed/${m[1]}`;
    return src;
  }
  if (provider === 'vimeo') {
    const m = src.match(/vimeo\.com\/(?:video\/)?(\d{4,})/);
    if (m && m[1]) return `https://player.vimeo.com/video/${m[1]}`;
    return src;
  }
  return src;
}

function RelatedPagesWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'related-pages' }>;
}): JSX.Element {
  return (
    <WidgetShell title={widget.title || 'Related'}>
      <ul className="space-y-1.5">
        {widget.items.map((item, idx) => {
          const href = safeHref(item.href);
          const content = (
            <>
              <div className="text-sm font-semibold text-brand-ink">{item.label}</div>
              {item.description ? (
                <div className="text-[11px] text-brand-mute">{item.description}</div>
              ) : null}
            </>
          );
          return (
            <li key={idx}>
              {href ? (
                <a
                  href={href}
                  target={href.startsWith('http') ? '_blank' : undefined}
                  rel={href.startsWith('http') ? 'noopener noreferrer' : undefined}
                  className="block rounded-md border border-brand-line/60 bg-bg-primary/40 px-2 py-1.5 transition-colors hover:border-brand-accent/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
                >
                  {content}
                </a>
              ) : (
                <div className="rounded-md border border-brand-line/60 bg-bg-primary/40 px-2 py-1.5">
                  {content}
                </div>
              )}
            </li>
          );
        })}
      </ul>
    </WidgetShell>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Chart (sparkline bar/line) — small SVG, no external lib
// ─────────────────────────────────────────────────────────────────────────────

function ChartWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'chart' }>;
}): JSX.Element {
  const max = Math.max(...widget.series.map((s) => s.value), 1);
  const min = Math.min(...widget.series.map((s) => s.value), 0);
  const range = Math.max(max - min, 1);
  const isLine = widget.variant === 'line';
  const w = 280;
  const h = 80;
  const step = widget.series.length > 1 ? w / (widget.series.length - 1) : w;
  return (
    <WidgetShell title={widget.title}>
      <div className="space-y-2">
        <svg
          viewBox={`0 0 ${w} ${h + 16}`}
          className="h-24 w-full"
          role="img"
          aria-label={widget.title ?? 'Chart'}
        >
          {isLine ? (
            <polyline
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              className="text-brand-accent"
              points={widget.series
                .map((s, i) => `${i * step},${h - ((s.value - min) / range) * h}`)
                .join(' ')}
            />
          ) : (
            widget.series.map((s, i) => {
              const bw = Math.max(w / widget.series.length - 4, 4);
              const bh = ((s.value - min) / range) * h;
              return (
                <rect
                  key={i}
                  x={i * (w / widget.series.length) + 2}
                  y={h - bh}
                  width={bw}
                  height={bh}
                  rx={2}
                  className="fill-brand-accent/70"
                />
              );
            })
          )}
        </svg>
        <ul className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-brand-mute">
          {widget.series.map((s, i) => (
            <li key={i}>
              <span className="text-brand-ink">{s.label}</span>: {s.value}
            </li>
          ))}
        </ul>
        {widget.caption ? <p className="text-xs text-brand-mute">{widget.caption}</p> : null}
      </div>
    </WidgetShell>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Newsletter signup — deep-links to existing contact form (no in-place POST)
// ─────────────────────────────────────────────────────────────────────────────

function NewsletterWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'newsletter' }>;
}): JSX.Element | null {
  const href = safeHref(widget.href);
  if (!href) return null;
  return (
    <WidgetShell title={widget.title}>
      <div className="space-y-2">
        {widget.body ? <p className="text-sm text-brand-mute">{widget.body}</p> : null}
        <form
          className="flex flex-col gap-2 sm:flex-row"
          onSubmit={(e) => {
            e.preventDefault();
            const input = e.currentTarget.querySelector(
              'input[type=email]',
            ) as HTMLInputElement | null;
            const email = input?.value?.trim() ?? '';
            const url = new URL(href, window.location.origin);
            if (email) url.searchParams.set('email', email);
            window.location.href = url.toString();
          }}
        >
          <label className="sr-only" htmlFor={`nl-${widget.id ?? 'x'}`}>
            Email address
          </label>
          <input
            id={`nl-${widget.id ?? 'x'}`}
            type="email"
            required
            inputMode="email"
            autoComplete="email"
            placeholder={widget.placeholder ?? 'you@example.com'}
            className="flex-1 rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink placeholder:text-brand-mute focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
          />
          <button
            type="submit"
            className="rounded-md bg-brand-accent px-4 py-2 text-sm font-medium text-bg-primary transition-colors hover:bg-brand-accent/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
          >
            {widget.cta ?? 'Subscribe'}
          </button>
        </form>
        {widget.consent ? <p className="text-xs text-brand-mute">{widget.consent}</p> : null}
      </div>
    </WidgetShell>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Donation — amount pills + deep link
// ─────────────────────────────────────────────────────────────────────────────

function DonationWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'donation' }>;
}): JSX.Element | null {
  const href = safeHref(widget.href);
  if (!href) return null;
  const currency = widget.currency ?? 'USD';
  const fmt = (n: number): string =>
    new Intl.NumberFormat(undefined, {
      style: 'currency',
      currency,
      maximumFractionDigits: 0,
    }).format(n);
  return (
    <WidgetShell title={widget.title}>
      <div className="space-y-2">
        {widget.body ? <p className="text-sm text-brand-mute">{widget.body}</p> : null}
        <div className="flex flex-wrap gap-2">
          {widget.amounts.map((amt, i) => {
            const u = new URL(href, window.location.origin);
            u.searchParams.set('amount', String(amt));
            return (
              <a
                key={i}
                href={u.toString()}
                className="rounded-full border border-brand-line bg-bg-primary px-3 py-1.5 text-sm text-brand-ink transition-colors hover:border-brand-accent hover:text-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
              >
                {fmt(amt)}
              </a>
            );
          })}
        </div>
        <a
          href={href}
          className="inline-block rounded-md bg-brand-accent px-4 py-2 text-sm font-medium text-bg-primary transition-colors hover:bg-brand-accent/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
        >
          {widget.cta ?? 'Donate'}
        </a>
      </div>
    </WidgetShell>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Search results — title + snippet + href cards
// ─────────────────────────────────────────────────────────────────────────────

function SearchResultsWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'search-results' }>;
}): JSX.Element {
  return (
    <WidgetShell
      title={widget.title ?? (widget.query ? `Results for “${widget.query}”` : 'Results')}
    >
      <ol className="space-y-2">
        {widget.results.map((r, i) => {
          const href = safeHref(r.href);
          if (!href) return null;
          return (
            <li key={i}>
              <a
                href={href}
                target={href.startsWith('http') ? '_blank' : undefined}
                rel={href.startsWith('http') ? 'noopener noreferrer' : undefined}
                className="block rounded-md border border-brand-line/60 bg-bg-primary/40 p-3 transition-colors hover:border-brand-accent/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
              >
                <div className="flex items-baseline justify-between gap-2">
                  <span className="text-sm font-medium text-brand-ink">{r.title}</span>
                  {r.kind ? (
                    <span className="rounded-full border border-brand-line/60 px-2 py-0.5 text-[10px] uppercase tracking-wide text-brand-mute">
                      {r.kind}
                    </span>
                  ) : null}
                </div>
                {r.snippet ? <p className="mt-1 text-xs text-brand-mute">{r.snippet}</p> : null}
              </a>
            </li>
          );
        })}
      </ol>
    </WidgetShell>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Document — download card with file type + size
// ─────────────────────────────────────────────────────────────────────────────

function DocumentWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'document' }>;
}): JSX.Element | null {
  const href = safeHref(widget.href);
  if (!href) return null;
  const sizeLabel = widget.sizeBytes ? formatBytes(widget.sizeBytes) : null;
  return (
    <WidgetShell>
      <a
        href={href}
        target={href.startsWith('http') ? '_blank' : undefined}
        rel={href.startsWith('http') ? 'noopener noreferrer' : undefined}
        download
        className="flex items-start gap-3 rounded-md border border-brand-line/60 bg-bg-primary/40 p-3 transition-colors hover:border-brand-accent/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
      >
        <span
          aria-hidden
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-brand-accent/10 text-xs font-semibold uppercase text-brand-accent"
        >
          {(widget.fileType ?? 'FILE').slice(0, 4)}
        </span>
        <span className="flex-1 min-w-0">
          <span className="block truncate text-sm font-medium text-brand-ink">{widget.title}</span>
          {widget.description ? (
            <span className="mt-0.5 block text-xs text-brand-mute">{widget.description}</span>
          ) : null}
          <span className="mt-1 block text-[11px] text-brand-mute">
            {[widget.fileType?.toUpperCase(), sizeLabel].filter(Boolean).join(' · ') || 'Download'}
          </span>
        </span>
      </a>
    </WidgetShell>
  );
}

function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  if (n < 1024 * 1024 * 1024) return `${(n / 1024 / 1024).toFixed(1)} MB`;
  return `${(n / 1024 / 1024 / 1024).toFixed(1)} GB`;
}

// ─────────────────────────────────────────────────────────────────────────────
// Next best action — single highlighted CTA card
// ─────────────────────────────────────────────────────────────────────────────

function NextActionWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'next-action' }>;
}): JSX.Element | null {
  const href = safeHref(widget.cta.href);
  if (!href) return null;
  return (
    <WidgetShell tone="info">
      <div className="space-y-2">
        <div className="text-[10px] uppercase tracking-wider text-brand-accent">Suggested next</div>
        <h4 className="text-sm font-semibold text-brand-ink">{widget.title}</h4>
        {widget.body ? <p className="text-sm text-brand-mute">{widget.body}</p> : null}
        <a
          href={href}
          className="inline-block rounded-md bg-brand-accent px-4 py-2 text-sm font-medium text-bg-primary transition-colors hover:bg-brand-accent/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
        >
          {widget.cta.label}
        </a>
        {widget.reason ? <p className="text-[11px] text-brand-mute">Why: {widget.reason}</p> : null}
      </div>
    </WidgetShell>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Rating — 1-5 stars, posts a chip-action upstream
// ─────────────────────────────────────────────────────────────────────────────

function RatingWidget({
  widget,
  onAction,
}: {
  widget: Extract<AiChatWidget, { kind: 'rating' }>;
  onAction?: (action: string) => void;
}): JSX.Element {
  return (
    <WidgetShell title={widget.title ?? 'Rate this answer'}>
      <div className="space-y-2">
        {widget.prompt ? <p className="text-sm text-brand-mute">{widget.prompt}</p> : null}
        {/* A fire-once rating: clicking submits and the widget is replaced — there
            is no persisted selected state, so this is a button group, NOT an ARIA
            radiogroup. role="group" + per-button aria-label is the honest semantic
            and each star stays an independently Tab-focusable, Enter/Space-activatable
            button (no roving-tabindex contract to satisfy). */}
        <div className="flex gap-1.5" role="group" aria-label="Rate this answer">
          {[1, 2, 3, 4, 5].map((n) => (
            <button
              key={n}
              type="button"
              aria-label={`${n} star${n > 1 ? 's' : ''}`}
              onClick={() => onAction?.(`rating:${n}`)}
              className="text-xl text-brand-mute transition-colors hover:text-amber-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
            >
              ☆
            </button>
          ))}
        </div>
      </div>
    </WidgetShell>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Wave 2C — Intent Preview action widgets.
// Render Proceed / Edit / Talk-to-human controls plus a visible countdown when
// `autoCancelSec` is present. The `onAction` callback round-trips a structured
// confirm verb back to the chat hook: `confirm:<toolUseId>:<tool>:<decision>`.
// ─────────────────────────────────────────────────────────────────────────────

interface ActionWidgetProps<W extends AiChatWidget> {
  widget: W;
  onAction?: (action: string) => void;
}

function useCountdown(autoCancelSec: number | undefined, onExpire: () => void): number | null {
  const [remaining, setRemaining] = useState<number | null>(
    typeof autoCancelSec === 'number' && autoCancelSec > 0 ? autoCancelSec : null,
  );
  const expiredRef = useRef(false);
  useEffect(() => {
    if (remaining === null) return;
    if (remaining <= 0) {
      if (!expiredRef.current) {
        expiredRef.current = true;
        onExpire();
      }
      return;
    }
    const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    if (reduce) return; // honor reduced-motion: still render number, just don't tick.
    const t = window.setTimeout(() => setRemaining((r) => (r === null ? null : r - 1)), 1000);
    return () => window.clearTimeout(t);
  }, [remaining, onExpire]);
  return remaining;
}

function ActionShell({
  title,
  summary,
  rows,
  warning,
  irreversible,
  autoCancelSec,
  state,
  toolUseId,
  tool,
  onAction,
}: {
  title: string;
  summary: string;
  rows?: { label: string; value: ReactNode }[];
  warning?: string;
  irreversible?: boolean;
  autoCancelSec?: number;
  state?: 'preview' | 'confirming' | 'executed' | 'canceled' | 'errored';
  toolUseId: string;
  tool: string;
  onAction?: (action: string) => void;
}): JSX.Element {
  const isFinal = state === 'executed' || state === 'canceled' || state === 'confirming';
  const remaining = useCountdown(isFinal ? undefined : autoCancelSec, () => {
    onAction?.(`confirm:${toolUseId}:${tool}:cancel`);
  });
  const tone = state === 'executed' ? 'success' : state === 'canceled' ? 'warn' : 'info';
  return (
    <WidgetShell tone={tone}>
      <div className="space-y-2">
        <div className="flex items-start justify-between gap-2">
          <h4 className="text-sm font-semibold text-brand-ink">{title}</h4>
          {remaining !== null && !isFinal ? (
            <span
              aria-live="polite"
              className="rounded-full border border-brand-line bg-bg-primary/60 px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider text-brand-mute"
            >
              Auto-cancel in {Math.max(0, remaining)}s
            </span>
          ) : null}
        </div>
        <p className="text-xs text-brand-mute">{summary}</p>
        {rows?.length ? (
          <dl className="grid grid-cols-[max-content_1fr] gap-x-3 gap-y-1 text-xs">
            {rows.map((r, idx) => (
              <span key={idx} className="contents">
                <dt className="text-brand-mute">{r.label}</dt>
                <dd className="text-brand-ink/90">{r.value}</dd>
              </span>
            ))}
          </dl>
        ) : null}
        {warning ? (
          <p className="rounded-md border border-amber-500/40 bg-amber-500/10 px-2 py-1 text-[11px] text-amber-200">
            {warning}
          </p>
        ) : null}
        {irreversible ? (
          <p className="text-[10px] font-mono uppercase tracking-wider text-amber-300/80">
            Irreversible — review before proceeding
          </p>
        ) : null}
        {!isFinal ? (
          <div className="mt-2 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => onAction?.(`confirm:${toolUseId}:${tool}:proceed`)}
              className="inline-flex items-center justify-center rounded-lg bg-brand-accent px-3 py-1.5 text-xs font-mono font-semibold uppercase tracking-wider text-bg-primary transition-colors hover:bg-brand-accent/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent focus-visible:ring-offset-2 focus-visible:ring-offset-bg-primary"
            >
              Proceed
            </button>
            <button
              type="button"
              onClick={() => onAction?.(`confirm:${toolUseId}:${tool}:edit`)}
              className="inline-flex items-center justify-center rounded-lg border border-brand-line bg-bg-primary/40 px-3 py-1.5 text-xs font-mono uppercase tracking-wider text-brand-ink/90 hover:border-brand-accent/60 hover:text-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
            >
              Edit
            </button>
            <button
              type="button"
              onClick={() => onAction?.('/human')}
              className="inline-flex items-center justify-center rounded-lg px-3 py-1.5 text-xs font-mono uppercase tracking-wider text-brand-mute hover:text-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
            >
              Talk to human
            </button>
          </div>
        ) : (
          <p
            className={`text-[11px] font-mono uppercase tracking-wider ${
              state === 'executed' ? 'text-emerald-400' : 'text-amber-300'
            }`}
          >
            {state === 'executed'
              ? 'Done.'
              : state === 'canceled'
                ? 'Canceled.'
                : 'Pending.'}
          </p>
        )}
      </div>
    </WidgetShell>
  );
}

function BookingActionPreviewWidget({
  widget,
  onAction,
}: ActionWidgetProps<Extract<AiChatWidget, { kind: 'booking-action-preview' }>>): JSX.Element {
  return (
    <ActionShell
      title={widget.title}
      summary={widget.summary}
      rows={widget.rows}
      warning={widget.warning}
      irreversible={widget.irreversible}
      autoCancelSec={widget.autoCancelSec}
      state={widget.state}
      toolUseId={widget.toolUseId}
      tool={widget.action}
      onAction={onAction}
    />
  );
}

function RescheduleConfirmWidget({
  widget,
  onAction,
}: ActionWidgetProps<Extract<AiChatWidget, { kind: 'reschedule-confirm' }>>): JSX.Element {
  return (
    <ActionShell
      title="Move this booking?"
      summary={`Booking #${widget.bookingId.slice(0, 8)} moves to ${widget.toDate} at ${widget.toTime}.`}
      rows={[
        { label: 'From', value: `${widget.fromDate} ${widget.fromTime}` },
        { label: 'To', value: `${widget.toDate} ${widget.toTime}` },
        ...(widget.feeDollars ? [{ label: 'Fee', value: `$${widget.feeDollars}` }] : []),
        ...(widget.note ? [{ label: 'Note', value: widget.note }] : []),
      ]}
      irreversible
      autoCancelSec={widget.autoCancelSec}
      state={widget.state}
      toolUseId={widget.toolUseId}
      tool="reschedule"
      onAction={onAction}
    />
  );
}

function ClaimDraftWidget({
  widget,
  onAction,
}: ActionWidgetProps<Extract<AiChatWidget, { kind: 'claim-draft' }>>): JSX.Element {
  return (
    <ActionShell
      title="File this claim?"
      summary={widget.description}
      rows={[
        { label: 'Booking', value: `#${widget.bookingId.slice(0, 8)}` },
        { label: 'Category', value: widget.category.replace('-', ' ') },
        ...(widget.estimatedDollars
          ? [{ label: 'Estimate', value: `$${widget.estimatedDollars}` }]
          : []),
        ...(widget.photoCount ? [{ label: 'Photos', value: String(widget.photoCount) }] : []),
      ]}
      warning="The owner reviews every claim and will reach out within 1 business day."
      autoCancelSec={widget.autoCancelSec}
      state={widget.state}
      toolUseId={widget.toolUseId}
      tool="file_claim"
      onAction={onAction}
    />
  );
}

function TipDispatchWidget({
  widget,
  onAction,
}: ActionWidgetProps<Extract<AiChatWidget, { kind: 'tip-dispatch' }>>): JSX.Element {
  return (
    <ActionShell
      title={`Tip $${widget.amountDollars}?`}
      summary={`Send a $${widget.amountDollars} tip to the crew on booking #${widget.bookingId.slice(0, 8)}.`}
      rows={[
        { label: 'Amount', value: `$${widget.amountDollars}` },
        { label: 'Split', value: widget.splitEven === false ? 'Lead only' : 'Even split' },
        ...(widget.recipient ? [{ label: 'To', value: widget.recipient }] : []),
        ...(widget.note ? [{ label: 'Note', value: widget.note }] : []),
      ]}
      warning="Charged to the card on file."
      irreversible
      autoCancelSec={widget.autoCancelSec}
      state={widget.state}
      toolUseId={widget.toolUseId}
      tool="dispatch_tip"
      onAction={onAction}
    />
  );
}

function HireAgainPreviewWidget({
  widget,
  onAction,
}: ActionWidgetProps<Extract<AiChatWidget, { kind: 'hire-again-preview' }>>): JSX.Element {
  return (
    <ActionShell
      title="Re-book the same crew?"
      summary={`${widget.crew}-person crew · ${widget.hours}h · ${widget.proposedDate} at ${widget.proposedTime}.`}
      rows={[
        { label: 'From', value: `#${widget.fromBookingId.slice(0, 8)}` },
        { label: 'Crew', value: `${widget.crew} person${widget.crew > 1 ? 's' : ''}` },
        { label: 'Hours', value: String(widget.hours) },
        { label: 'Estimate', value: `$${widget.estimateDollars}` },
        ...(widget.services?.length
          ? [
              {
                label: 'Services',
                value: (
                  <ul
                    aria-label="Services"
                    className="flex flex-wrap gap-1"
                    style={{ margin: 0, padding: 0, listStyle: 'none' }}
                  >
                    {widget.services.map((svc, i) => (
                      <li
                        key={svc}
                        className="widget-pill rounded-full border border-brand-accent/30 bg-brand-accent/10 px-2 py-0.5 text-[10px] font-medium text-brand-accent transition-all duration-[333ms] hover:-translate-y-0.5 hover:border-brand-accent/50 hover:bg-brand-accent/20 hover:shadow-sm"
                        style={{
                          animation: 'pill-enter 0.35s ease-out both',
                          animationDelay: `${i * 50}ms`,
                        }}
                      >
                        {svc}
                      </li>
                    ))}
                  </ul>
                ),
              },
            ]
          : []),
      ]}
      autoCancelSec={widget.autoCancelSec}
      state={widget.state}
      toolUseId={widget.toolUseId}
      tool="hire_again"
      onAction={onAction}
    />
  );
}

function HumanHandoffWidget({
  widget,
}: {
  widget: Extract<AiChatWidget, { kind: 'human-handoff' }>;
}): JSX.Element {
  return (
    <WidgetShell tone="info">
      <div className="space-y-2">
        <h4 className="text-sm font-semibold text-brand-ink">{widget.title}</h4>
        {widget.body ? <p className="text-xs text-brand-mute">{widget.body}</p> : null}
        <div className="flex flex-wrap gap-2">
          {widget.channels.map((ch, idx) => {
            const href = safeHref(ch.href);
            if (!href) return null;
            const primary = ch.kind === 'phone';
            return (
              <a
                key={idx}
                href={href}
                target={href.startsWith('http') ? '_blank' : undefined}
                rel={href.startsWith('http') ? 'noopener noreferrer' : undefined}
                className={`inline-flex items-center justify-center rounded-lg px-3 py-1.5 text-xs font-mono uppercase tracking-wider transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent ${
                  primary
                    ? 'bg-brand-accent text-bg-primary hover:bg-brand-accent/90'
                    : 'border border-brand-line text-brand-ink/90 hover:border-brand-accent hover:text-brand-accent'
                }`}
              >
                {ch.label}
              </a>
            );
          })}
        </div>
      </div>
    </WidgetShell>
  );
}
