import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import type { JSX, ReactNode } from 'react';
import type { AuthStage } from './AuthShell.js';

// LoginShell — compact single-card layout for /login. One small centered
// sign-in widget that fits between the header and footer with no vertical
// scroll. No oversized brand/form panels. Other auth surfaces use <AuthShell>.

interface LoginShellProps {
  readonly eyebrow: string;
  readonly headline: string;
  readonly body: ReactNode;
  readonly stage?: AuthStage;
  readonly stageLabels?: Readonly<Record<AuthStage, string>>;
  readonly footer?: ReactNode;
  readonly children: ReactNode;
  /**
   * Optional brand/value panel rendered BESIDE the form on large screens.
   * Fills the otherwise-empty desktop width with a cinematic split-hero while
   * mobile keeps the single compact card (the aside is hidden below `lg`).
   */
  readonly aside?: ReactNode;
}

const DEFAULT_STAGE_LABELS: Readonly<Record<AuthStage, string>> = {
  contact: 'Contact',
  code: 'Verify',
  success: 'Done',
};

export function LoginShell({
  eyebrow,
  headline,
  body,
  stage,
  stageLabels = DEFAULT_STAGE_LABELS,
  footer,
  children,
  aside,
}: LoginShellProps): JSX.Element {
  useThemeToolsSurface('login-shell');
  return (
    <section className="login-screen" data-testid="login-shell">
      <div
        className={
          aside
            ? 'login-split relative grid w-full max-w-[62rem] items-stretch gap-0 overflow-hidden rounded-2xl border border-brand-line bg-bg-elevated shadow-[0_28px_70px_-30px_rgba(0,0,0,0.8)] lg:grid-cols-[1.05fr_1fr]'
            : undefined
        }
        data-testid={aside ? 'login-split' : undefined}
      >
        {aside && <div className="hidden min-w-0 lg:block">{aside}</div>}
        <div
          className={aside ? 'login-card-inner reveal-in min-w-0' : 'login-card reveal-in'}
          data-testid="login-card"
        >
          <p className="eyebrow">{eyebrow}</p>
          <h1 className="font-display text-[clamp(1.375rem,1rem+1.6vw,1.85rem)] font-extrabold leading-tight tracking-tight text-brand-ink text-balance">
            {headline}
          </h1>
          <div className="mt-2 text-sm text-brand-mute leading-snug text-pretty">{body}</div>
          {stage && <StageDots stage={stage} labels={stageLabels} />}
          <div className="mt-5">{children}</div>
          {footer && <div className="mt-5 text-xs text-brand-mute leading-relaxed">{footer}</div>}
        </div>
      </div>
    </section>
  );
}

function StageDots({
  stage,
  labels,
}: {
  readonly stage: AuthStage;
  readonly labels: Readonly<Record<AuthStage, string>>;
}): JSX.Element {
  const order: ReadonlyArray<AuthStage> = ['contact', 'code', 'success'];
  const idx = order.indexOf(stage);
  return (
    <ol
      aria-label="Login progress"
      className="mt-4 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.16em] text-brand-mute"
    >
      {order.map((s, i) => {
        const reached = i <= idx;
        const isCurrent = i === idx;
        return (
          <li key={s} className="flex items-center gap-2">
            <span
              aria-current={isCurrent ? 'step' : undefined}
              className={`inline-flex h-5 w-5 items-center justify-center rounded-full border text-[10px] font-semibold transition-colors ${
                reached
                  ? 'border-brand-accent bg-brand-accent text-bg-primary'
                  : 'border-brand-line bg-bg-primary text-brand-mute'
              }`}
            >
              {i + 1}
            </span>
            <span className={isCurrent ? 'text-brand-ink' : ''}>{labels[s]}</span>
            {i < order.length - 1 && (
              <span aria-hidden className="text-brand-line">
                /
              </span>
            )}
          </li>
        );
      })}
    </ol>
  );
}
