import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { useCallback, useEffect, useState } from 'react';

/**
 * `<SignInWithAppleButton>` — official Apple-HIG-compliant button.
 *
 * Foreground wires this into `LoginPage.tsx` next to the Google sign-in
 * button, gated on the public `sign_in_with_apple` flag. The button
 * fetches `/api/sign-in-with-apple/authorize`; the Worker stores callback
 * state in an HttpOnly cookie before the browser leaves for Apple.
 *
 * Apple's button styling rules (Human Interface Guidelines):
 *   - black background + white text, OR white background + black text
 *   - 4-44 corner radius
 *   - exact button-text "Sign in with Apple" or "Continue with Apple"
 *   - logo + text together with a minimum vertical padding
 *
 * Both `light` and `dark` themes are rendered; pick via the `theme` prop.
 * Defaults to `dark` (white-on-black) which suits Brick Labor's dark-first UI.
 */

type Theme = 'light' | 'dark';
type Label = 'sign-in' | 'continue';

interface Props {
  /** White-on-black ("dark") OR black-on-white ("light"). Default `dark`. */
  theme?: Theme;
  /** "Sign in with Apple" or "Continue with Apple". Default `sign-in`. */
  label?: Label;
  /** Optional className passthrough for layout (margin/width). */
  className?: string;
  /** Visible only when this is true. Foreground passes
   *  `useFeatureFlag('sign_in_with_apple')`. */
  enabled?: boolean;
}

interface AuthorizeResponse {
  ok: boolean;
  url?: string;
  state?: string;
  nonce?: string;
  error?: string;
  code?: string;
}

export function SignInWithAppleButton({
  theme = 'dark',
  label = 'sign-in',
  className = '',
  enabled = true,
}: Props): JSX.Element | null {
  useThemeToolsSurface('sign-in-with-apple-button');
  const [busy, setBusy] = useState(false);
  const [availability, setAvailability] = useState<'checking' | 'ready' | 'unavailable'>('checking');
  const [error, setError] = useState('');

  // Probe the endpoint at mount so we can HIDE the button entirely (render
  // null) instead of showing an unfinished affordance when Apple OAuth creds
  // aren't wired in this environment. The button only appears when usable.
  useEffect(() => {
    if (!enabled) return;
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch('/api/sign-in-with-apple/authorize', {
          method: 'GET',
          credentials: 'same-origin',
        });
        if (cancelled) return;
        setAvailability(res.status === 503 ? 'unavailable' : 'ready');
      } catch {
        if (!cancelled) setAvailability('ready');
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [enabled]);

  const onClick = useCallback(async () => {
    setBusy(true);
    setError('');
    try {
      const res = await fetch('/api/sign-in-with-apple/authorize', {
        method: 'GET',
        credentials: 'same-origin',
      });
      const data = (await res.json()) as AuthorizeResponse;
      if (!res.ok || !data.ok || !data.url) {
        const msg =
          data.error === 'apple_oauth_not_configured'
            ? 'Sign in with Apple is not yet available. Try a different method.'
            : data.error || 'Could not start Apple sign-in. Try again.';
        setError(msg);
        return;
      }
      window.location.assign(data.url);
    } catch (err) {
      setError(`Network error starting Apple sign-in: ${(err as Error).message}`);
    } finally {
      setBusy(false);
    }
  }, []);

  if (!enabled) return null;

  const isDark = theme === 'dark';
  const text = label === 'continue' ? 'Continue with Apple' : 'Sign in with Apple';

  // Apple logo as inline SVG (avoids needing an asset file). Color follows
  // currentColor so we get white on dark + black on light for free.
  const apple = (
    <svg
      aria-hidden="true"
      viewBox="0 0 14 17"
      width="14"
      height="17"
      fill="currentColor"
      className="-mt-0.5"
    >
      <path d="M11.6 13.2c-.3.7-.6 1.4-1.1 2-.6.9-1.5 2-2.6 2-1 0-1.3-.7-2.7-.7s-1.7.7-2.7.7c-1.1 0-2-1-2.6-1.9C.2 13.6-.4 11 .6 9.2c.7-1.2 1.9-2 3.2-2 1 0 2 .7 2.7.7s2-.8 3.3-.7c.6 0 2.2.2 3.2 1.7-3.2 1.7-2.7 5.5.6 6.3zM9.4 4.4c.5-.6.9-1.4.8-2.3-.8 0-1.7.5-2.2 1.1-.5.5-1 1.4-.8 2.2.9.1 1.7-.4 2.2-1z" />
    </svg>
  );

  // Endpoint returned 503 (Apple OAuth creds unset) — hide the control
  // entirely rather than render an unfinished "coming soon" stub.
  if (availability === 'unavailable') return null;

  return (
    <div className="space-y-1">
    <button
      type="button"
      onClick={onClick}
      disabled={busy || availability === 'checking'}
      aria-busy={busy}
      data-testid="sign-in-with-apple-button"
      className={
        'inline-flex w-full items-center justify-center gap-2 rounded-lg border px-4 py-2.5 text-sm font-semibold transition-opacity disabled:opacity-60 ' +
        (isDark
          ? 'bg-black text-white border-white/20 hover:bg-zinc-900'
          : 'bg-white text-black border-black/20 hover:bg-zinc-100') +
        ' ' +
        className
      }
      aria-label={text}
    >
      {apple}
      <span>{availability === 'checking' ? 'Checking Apple…' : busy ? 'Connecting…' : text}</span>
    </button>
    {error && <p role="alert" className="text-xs text-red-300">{error}</p>}
    </div>
  );
}
