import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { useEffect, useRef, useState } from 'react';
import { track } from '../../analytics.js';

// Wave 36 — Apple Pay / Google Pay express checkout.
// When the booking total is >= $50 AND the device's Stripe PaymentRequest API
// reports `canMakePayment().applePay || .googlePay`, surface the native wallet
// button next to the existing card form. Two taps → booking paid.
//
// Below the $50 floor the button is hidden (wallet UX adds friction without
// meaningful typing-savings on small tickets). Above $50 but where the device
// can't make a wallet payment (desktop Firefox, incognito, no saved card), we
// also render null so the customer falls back to the card form silently.

const APPLE_GOOGLE_PAY_FLOOR_CENTS = 5_000;

export interface ApplePayGooglePayButtonsProps {
  /** Booking id this charge is associated with. */
  readonly bookingId: string;
  /** Total in cents (must be >= $5000 for the button to render). */
  readonly totalCents: number;
  /** Customer email — required for Stripe receipt + intent creation. */
  readonly customerEmail: string;
  /** Stripe publishable key — passed by the parent (read from env). */
  readonly stripePublishableKey?: string;
  /** Fired after a successful charge so the parent can refresh + flip UI. */
  readonly onCharged?: (result: {
    intentId: string;
    paymentIntentId: string;
    walletType: 'apple_pay' | 'google_pay';
  }) => void;
}

interface StripeShim {
  paymentRequest(args: Record<string, unknown>): {
    canMakePayment(): Promise<null | { applePay?: boolean; googlePay?: boolean }>;
    on(event: string, handler: (...args: unknown[]) => void): void;
    show(): void;
  };
  confirmCardPayment(
    clientSecret: string,
    args: { payment_method: string },
    options: { handleActions: boolean },
  ): Promise<{ paymentIntent?: { id: string; status: string }; error?: { message: string } }>;
}

declare global {
  interface Window {
    Stripe?: (publishableKey: string) => StripeShim;
  }
}

/**
 * Loads Stripe.js v3 from the official CDN on first mount. Resolves once
 * `window.Stripe` is available. Idempotent — the second mount reuses the
 * already-loaded script tag.
 */
async function loadStripeJs(): Promise<StripeShim | null> {
  if (typeof window === 'undefined') return null;
  if (window.Stripe) return null;
  const existing = document.querySelector<HTMLScriptElement>('script[data-stripe-js]');
  if (!existing) {
    await new Promise<void>((resolve, reject) => {
      const s = document.createElement('script');
      s.src = 'https://js.stripe.com/v3/';
      s.async = true;
      s.dataset.stripeJs = '1';
      s.onload = () => resolve();
      s.onerror = () => reject(new Error('stripe_js_load_failed'));
      document.head.appendChild(s);
    });
  }
  return null;
}

/**
 * Renders the native wallet button when:
 *   - Total >= $50 floor
 *   - Stripe publishable key is present
 *   - Device's PaymentRequest reports applePay or googlePay
 *
 * Otherwise renders `null` so the existing card form remains the only path.
 */
export function ApplePayGooglePayButtons({
  bookingId,
  totalCents,
  customerEmail,
  stripePublishableKey,
  onCharged,
}: ApplePayGooglePayButtonsProps): JSX.Element | null {
  useThemeToolsSurface('apple-pay-google-pay-buttons');
  const paymentRequestRef = useRef<ReturnType<StripeShim['paymentRequest']> | null>(null);
  const [available, setAvailable] = useState<null | 'apple_pay' | 'google_pay'>(null);
  const [checking, setChecking] = useState(totalCents >= APPLE_GOOGLE_PAY_FLOOR_CENTS);
  const [retryNonce, setRetryNonce] = useState(0);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    if (totalCents < APPLE_GOOGLE_PAY_FLOOR_CENTS) return;
    let cancelled = false;

    async function init() {
      setChecking(true);
      setError(null);
      setAvailable(null);
      try {
        let publishableKey = stripePublishableKey;
        if (!publishableKey) {
          const configRes = await fetch('/api/apple-google-pay-express/config', {
            credentials: 'same-origin',
          });
          const config = (await configRes.json().catch(() => null)) as {
            ok?: boolean;
            publishableKey?: string;
          } | null;
          if (!configRes.ok || !config?.ok || !config.publishableKey) {
            throw new Error('config_unavailable');
          }
          publishableKey = config.publishableKey;
        }
        await loadStripeJs();
        if (cancelled) return;
        const stripeFn = window.Stripe;
        if (!stripeFn) throw new Error('stripe_unavailable');
        const stripe = stripeFn(publishableKey);
        const paymentRequest = stripe.paymentRequest({
          country: 'US',
          currency: 'usd',
          total: {
            label: 'Brick Labor booking',
            amount: totalCents,
          },
          requestPayerName: true,
          requestPayerEmail: true,
        });

        const result = await paymentRequest.canMakePayment();
        if (cancelled) return;
        if (!result) {
          setAvailable(null);
          return;
        }
        const wallet: 'apple_pay' | 'google_pay' = result.applePay ? 'apple_pay' : 'google_pay';
        setAvailable(wallet);
        paymentRequestRef.current = paymentRequest;
        track('apple_google_pay_button_shown', { walletType: wallet, totalCents });

        paymentRequest.on('paymentmethod', async (...args: unknown[]) => {
          const ev = args[0] as {
            paymentMethod: { id: string };
            complete: (status: 'success' | 'fail') => void;
          };
          setBusy(true);
          setError(null);
          try {
            const intentRes = await fetch('/api/apple-google-pay-express/create-intent', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                bookingId,
                amountCents: totalCents,
                walletType: wallet,
                customerEmail,
              }),
            });
            const intentJson = (await intentRes.json()) as {
              ok: boolean;
              clientSecret?: string;
              intentId?: string;
              paymentIntentId?: string;
              error?: string;
            };
            if (!intentJson.ok || !intentJson.clientSecret || !intentJson.intentId) {
              ev.complete('fail');
              setError('Could not start express checkout. Try again or use the card option.');
              return;
            }

            const confirm = await stripe.confirmCardPayment(
              intentJson.clientSecret,
              { payment_method: ev.paymentMethod.id },
              { handleActions: false },
            );
            if (confirm.error) {
              ev.complete('fail');
              setError('The wallet did not approve the payment. Try again or use another method.');
              return;
            }
            ev.complete('success');

            const piId = confirm.paymentIntent?.id ?? intentJson.paymentIntentId!;
            const confirmRes = await fetch(
              `/api/apple-google-pay-express/confirm/${encodeURIComponent(intentJson.intentId)}`,
              {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ paymentIntentId: piId }),
              },
            );
            const confirmBody = (await confirmRes.json().catch(() => null)) as {
              ok?: boolean;
              error?: string;
            } | null;
            if (!confirmRes.ok || !confirmBody?.ok) {
              setError('We could not verify the payment. Your booking has not been marked paid.');
              return;
            }

            track('apple_google_pay_succeeded', { walletType: wallet, totalCents });
            setSuccess(true);
            onCharged?.({
              intentId: intentJson.intentId,
              paymentIntentId: piId,
              walletType: wallet,
            });
          } catch (err) {
            ev.complete('fail');
            setError('Express checkout was interrupted. Try again or use the card option.');
          } finally {
            setBusy(false);
          }
        });
      } catch (err) {
        if (!cancelled) {
          setError('Express checkout is unavailable. You can still pay by card.');
        }
      } finally {
        if (!cancelled) setChecking(false);
      }
    }
    void init();
    return () => {
      cancelled = true;
      paymentRequestRef.current = null;
    };
  }, [bookingId, customerEmail, onCharged, retryNonce, stripePublishableKey, totalCents]);

  if (totalCents < APPLE_GOOGLE_PAY_FLOOR_CENTS) return null;
  if (!available && !checking && !error) return null;

  const walletLabel = available === 'apple_pay' ? 'Apple Pay' : 'Google Pay';

  return (
    <div
      data-bcl-apple-google-pay-express
      className="rounded-xl border border-brand-line bg-bg-primary/60 p-3"
    >
      <div className="mb-2 flex items-baseline justify-between">
        <span className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
          Express checkout
        </span>
        <span className="font-mono text-[10px] uppercase tracking-wider text-brand-mute">
          Two taps · no typing
        </span>
      </div>
      {checking ? (
        <p className="py-3 text-sm text-brand-mute" role="status">
          Checking express checkout…
        </p>
      ) : error && !available ? (
        <div role="alert">
          <p className="text-sm text-brand-mute">{error}</p>
          <button
            type="button"
            className="mt-2 min-h-11 rounded-lg border border-brand-line px-4 text-sm font-semibold text-brand-ink"
            onClick={() => setRetryNonce((n) => n + 1)}
            data-testid="wallet-retry"
          >
            Try express checkout again
          </button>
        </div>
      ) : (
        <>
          <button
            type="button"
            disabled={busy || success}
            aria-label={`Pay with ${walletLabel}`}
            onClick={() => {
              if (!available || !paymentRequestRef.current) return;
              track('apple_google_pay_button_clicked', { walletType: available, totalCents });
              paymentRequestRef.current.show();
            }}
            className={[
              'flex min-h-11 w-full items-center justify-center gap-2 rounded-lg px-4 py-3',
              'text-sm font-semibold transition-all',
              success
                ? 'bg-emerald-500/20 text-emerald-300'
                : busy
                  ? 'cursor-wait bg-brand-line text-brand-mute'
                  : 'bg-brand-accent text-bg-primary hover:opacity-90',
            ].join(' ')}
          >
            {success ? '✓ Paid' : busy ? 'Processing…' : `Pay with ${walletLabel}`}
          </button>
          {error ? (
            <p className="mt-2 text-[11px] leading-snug text-red-400" role="alert">
              {error}
            </p>
          ) : (
            <p className="mt-2 text-[11px] leading-snug text-brand-mute">
              Approve with Face ID, Touch ID, or fingerprint. We never see your card number.
            </p>
          )}
        </>
      )}
    </div>
  );
}

export { APPLE_GOOGLE_PAY_FLOOR_CENTS };
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
