import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { prepItemsFor } from '@theme.tools/forms/field-service-checklists';
import {
  buildComprehensiveCategoryDiagnostic,
  evaluateCurbAndParkingClearance,
} from '@theme.tools/scheduling/field-service/theme-tools-field-service-bridge';

interface Props {
  readonly bookingId: string;
  readonly services: readonly string[];
  readonly city?: string;
}

const STORAGE_PREFIX = 'bcl-prep-';

/**
 * ArrivalPrepChecklist — the "get ready for your crew" checklist on /track (fire-78). Fulfills the
 * prep checklist the 24h-before reminder promises at the /track deep-link. Service-aware (via the
 * `prepItemsFor` SSOT), tap-to-check, progress bar, per-booking `localStorage` persistence. Pure
 * client surface — NO network. Brand ORANGE. Checkboxes are 24px (WCAG 2.5.8 target-size, per fire-76).
 */
export function ArrivalPrepChecklist({ bookingId, services, city }: Props) {
  useThemeToolsSurface('arrival-prep-checklist');
  const items = useMemo(() => prepItemsFor(services), [services]);
  const curb = useMemo(
    () =>
      evaluateCurbAndParkingClearance({
        categorySlug: services[0] ?? 'moving-help',
        cityOrMunicipality: city ?? 'Newark',
      }),
    [services, city],
  );
  const categoryDiagnostic = useMemo(
    () =>
      buildComprehensiveCategoryDiagnostic(services[0] ?? 'moving-help', {
        cityOrMunicipality: city ?? 'Newark',
      }),
    [services, city],
  );
  const storageKey = `${STORAGE_PREFIX}${bookingId}`;
  const [checked, setChecked] = useState<ReadonlySet<string>>(() => readChecked(storageKey));

  // Re-read when the booking changes (SPA nav between /track/:id links).
  useEffect(() => {
    setChecked(readChecked(storageKey));
  }, [storageKey]);

  const toggle = useCallback(
    (id: string) => {
      setChecked((prev) => {
        const next = new Set(prev);
        if (next.has(id)) next.delete(id);
        else next.add(id);
        try {
          localStorage.setItem(storageKey, JSON.stringify([...next]));
        } catch {
          /* private mode — check state just won't persist */
        }
        return next;
      });
    },
    [storageKey],
  );

  const done = items.filter((i) => checked.has(i.id)).length;
  const pct = items.length ? Math.round((done / items.length) * 100) : 0;
  const allDone = items.length > 0 && done === items.length;

  return (
    <section
      data-testid="arrival-prep-checklist"
      aria-labelledby="arrival-prep-title"
      className="rounded-2xl border border-brand-accent/30 bg-brand-accent/[0.06] p-4 sm:p-5"
    >
      <div className="flex items-baseline justify-between gap-3">
        <h2 id="arrival-prep-title" className="font-display text-base font-bold text-brand-ink">
          Get ready for your crew
        </h2>
        <span className="font-mono text-xs text-brand-accent">
          {done}/{items.length}
        </span>
      </div>
      <p className="mt-1 text-xs text-brand-mute">
        A few quick things that help the crew work faster — and keep your hourly bill lower.
      </p>
      <div
        data-testid="arrival-curb-clearance-badge"
        className="mt-2 inline-flex flex-wrap items-center gap-2 rounded-lg border border-brand-line/60 bg-bg-primary/60 px-2.5 py-1 text-[11px] font-mono text-brand-accent"
      >
        <span>Curb clearance: {curb.requiredCurbLengthFt} ft</span>
        <span aria-hidden>·</span>
        <span className="text-brand-mute">{curb.permitAuthorityLabel}</span>
      </div>
      <p
        data-testid="arrival-engineering-diagnostic"
        className="mt-1.5 text-[11px] font-mono text-brand-mute"
      >
        {categoryDiagnostic.engineeringSummary}
      </p>
      <div
        className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-brand-line/40"
        role="progressbar"
        aria-valuenow={pct}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label="Prep progress"
      >
        <div
          className="h-full rounded-full bg-brand-accent transition-all duration-300"
          style={{ width: `${pct}%` }}
        />
      </div>
      <ul className="mt-3 space-y-1">
        {items.map((item) => {
          const on = checked.has(item.id);
          return (
            <li key={item.id}>
              <label className="flex cursor-pointer items-start gap-2.5 rounded-md px-1 py-1.5 hover:bg-brand-accent/[0.06]">
                <input
                  type="checkbox"
                  checked={on}
                  onChange={() => toggle(item.id)}
                  className="mt-0.5 h-6 w-6 shrink-0 accent-brand-accent"
                />
                <span
                  className={`text-sm leading-6 ${on ? 'text-brand-mute line-through' : 'text-brand-ink'}`}
                >
                  {item.label}
                </span>
              </label>
            </li>
          );
        })}
      </ul>
      <p className="mt-3 text-[11px] text-brand-mute" role="status">
        {allDone
          ? 'All set — your crew will be in and out fast. 🧡'
          : 'Saved on this device as you check items off.'}
      </p>
    </section>
  );
}

function readChecked(key: string): ReadonlySet<string> {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return new Set();
    const arr = JSON.parse(raw) as unknown;
    return Array.isArray(arr)
      ? new Set(arr.filter((x): x is string => typeof x === 'string'))
      : new Set();
  } catch {
    return new Set();
  }
}
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
