import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { track } from '../../analytics.js';
import { useRovingTabs } from '../../use-roving-radio.js';

// Wave 2A — BNPL toggle (idea #16).
// When the job total is >= $500, surface "Pay over time" tab that switches
// the Stripe Payment Element to render Klarna + Afterpay options natively.
// Below the $500 floor the toggle is hidden (those providers reject small
// tickets anyway and showing it would be misleading).

const BNPL_FLOOR_CENTS = 50_000;

export type BnplMode = 'card' | 'bnpl';

export interface BnplToggleProps {
  readonly mode: BnplMode;
  readonly onChange: (next: BnplMode) => void;
  readonly totalCents: number;
}

/**
 * Renders nothing when the total is below the BNPL floor.
 * Renders a two-tab pill when the BNPL providers will accept the ticket.
 */
export function BnplToggle({ mode, onChange, totalCents }: BnplToggleProps): JSX.Element | null {
  useThemeToolsSurface('bnpl-toggle');
  if (totalCents < BNPL_FLOOR_CENTS) return null;
  const monthly = Math.ceil(totalCents / 4 / 100); // 4-pay estimate, rounded up
  // ARIA roving-tabindex for the card/BNPL tablist (axe-blind interaction gap).
  const payTab = useRovingTabs(2, (i) => {
    const next: BnplMode = i === 0 ? 'card' : 'bnpl';
    if (mode !== next) {
      track('booking_bnpl_toggle', { mode: next, totalCents });
      onChange(next);
    }
  });
  return (
    <div data-bcl-bnpl-toggle className="rounded-xl border border-brand-line bg-bg-primary/60 p-3">
      <div className="mb-2 flex items-baseline justify-between">
        <span className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
          Pay over time
        </span>
        <span className="text-[10px] font-mono uppercase tracking-wider text-brand-mute">
          ~${monthly}/installment · 4 payments
        </span>
      </div>
      <div
        role="tablist"
        aria-label="Payment method"
        className="grid grid-cols-2 gap-1 rounded-lg border border-brand-line bg-bg-primary p-1"
      >
        <button
          type="button"
          role="tab"
          aria-selected={mode === 'card'}
          {...payTab(0, mode === 'card')}
          onClick={() => {
            if (mode !== 'card') {
              track('booking_bnpl_toggle', { mode: 'card', totalCents });
              onChange('card');
            }
          }}
          className={[
            'rounded-md px-3 py-2 text-xs font-mono uppercase tracking-wider transition-colors',
            mode === 'card'
              ? 'bg-brand-accent text-bg-primary'
              : 'text-brand-mute hover:text-brand-accent',
          ].join(' ')}
        >
          Card · Apple · Google
        </button>
        <button
          type="button"
          role="tab"
          aria-selected={mode === 'bnpl'}
          {...payTab(1, mode === 'bnpl')}
          onClick={() => {
            if (mode !== 'bnpl') {
              track('booking_bnpl_toggle', { mode: 'bnpl', totalCents });
              onChange('bnpl');
            }
          }}
          className={[
            'rounded-md px-3 py-2 text-xs font-mono uppercase tracking-wider transition-colors',
            mode === 'bnpl'
              ? 'bg-brand-accent text-bg-primary'
              : 'text-brand-mute hover:text-brand-accent',
          ].join(' ')}
        >
          Klarna · Afterpay
        </button>
      </div>
      <p className="mt-2 text-[11px] leading-snug text-brand-mute">
        Klarna / Afterpay split the total into 4 interest-free payments. Approval is instant — soft
        credit check only.
      </p>
    </div>
  );
}

export { BNPL_FLOOR_CENTS };
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
