import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { track } from '../../analytics.js';
import { MIN_DEPOSIT_CENTS, FIRST_TIME_DEPOSIT_PCT } from '@theme.tools/billing/field-service/deposit-policy';

// Section 5 — DepositPicker (idea #59).
// Two deposit modes only (pay-after removed per the optimization brief):
//   - 20% today (minimum $50) — card held for the balance, captured T-24h
//   - 100% today — locks the slot + price up front
// Rendered as stacked rows, not three columns, for compactness.

export type DepositMode = 'partial' | 'full';

export interface DepositPickerProps {
  readonly value: DepositMode;
  readonly onChange: (next: DepositMode) => void;
  readonly totalCents: number;
  readonly depositPct?: number;
  readonly scheduledAt?: string;
}

interface Option {
  readonly id: DepositMode;
  readonly label: string;
  readonly summary: string;
  readonly footnote: string;
}

/**
 * Minimum deposit floor in cents — re-exported from the shared deposit-policy
 * canonical so Booking.tsx + the post-checkout upsell math + the worker charge
 * paths all derive the ONE $50 floor. No parallel literal can drift.
 */
export { MIN_DEPOSIT_CENTS };

/**
 * Default deposit percent shown in the picker — derived from the canonical
 * deposit-policy `FIRST_TIME_DEPOSIT_PCT` (currently 20%), never a bare `20`
 * literal. Change the policy and the picker default + every label tracks it.
 */
export const DEFAULT_DEPOSIT_PCT = Math.round(FIRST_TIME_DEPOSIT_PCT * 100);

/**
 * The deposit-floor label (e.g. `$50 min`) derived from {@link MIN_DEPOSIT_CENTS}
 * so the displayed minimum can never drift from the floor the math enforces.
 */
export function depositFloorLabel(): string {
  return `$${MIN_DEPOSIT_CENTS / 100} min`;
}

function relativeT24(scheduledAt?: string): string {
  if (!scheduledAt) return 'T-24h before move';
  const ts = new Date(scheduledAt);
  if (Number.isNaN(ts.getTime())) return 'T-24h before move';
  const captureAt = new Date(ts.getTime() - 24 * 60 * 60 * 1000);
  return captureAt.toLocaleString(undefined, {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  });
}

/**
 * Compute the deposit floor: max($50, 20% of total). Returns cents.
 * Exported for unit tests + the parent Booking math.
 */
export function depositCents(totalCents: number, depositPct = DEFAULT_DEPOSIT_PCT): number {
  const pctCents = Math.round((totalCents * depositPct) / 100);
  return Math.max(MIN_DEPOSIT_CENTS, pctCents);
}

export function DepositPicker({
  value,
  onChange,
  totalCents,
  depositPct = DEFAULT_DEPOSIT_PCT,
  scheduledAt,
}: DepositPickerProps): JSX.Element {
  useThemeToolsSurface('deposit-picker');
  const totalDollars = (totalCents / 100).toFixed(2);
  const dCents = depositCents(totalCents, depositPct);
  const dDollars = (dCents / 100).toFixed(2);
  const remainderCents = Math.max(0, totalCents - dCents);
  const remainderDollars = (remainderCents / 100).toFixed(2);
  const t24 = relativeT24(scheduledAt);
  const flooredByMin = dCents > Math.round((totalCents * depositPct) / 100);

  const options: Option[] = [
    {
      id: 'partial',
      label: `${depositPct}% today${flooredByMin ? ` (${depositFloorLabel()})` : ''}`,
      summary: `Pay $${dDollars} now, balance T-24h before move.`,
      footnote: `Card held, not charged. Auto-captures ${t24}.`,
    },
    {
      id: 'full',
      label: '100% today',
      summary: `Pay $${totalDollars} now and lock the slot.`,
      footnote: 'Refund minus 10% if you cancel inside 24h.',
    },
  ];

  return (
    <fieldset
      data-bcl-deposit-picker
      className="rounded-2xl border border-brand-line bg-bg-primary/50 p-4"
    >
      <legend className="px-2 font-mono text-[11px] uppercase tracking-widest text-brand-accent">
        Deposit
      </legend>
      {/* Section 5 — rows, not columns. Vertical stack tightens scan + lets
          long summary copy breathe on mobile. */}
      <div className="grid gap-2">
        {options.map((opt) => {
          const checked = opt.id === value;
          return (
            <label
              key={opt.id}
              className={[
                // focus-within ring: the native radio is sr-only (visually clipped),
                // so the global *:focus-visible outline lands on an invisible element
                // — keyboard users get no visible focus on the deposit choice (WCAG
                // 2.4.7, Level A; axe-blind). Ring the visible card instead.
                'cursor-pointer flex items-start gap-3 rounded-xl border px-4 py-3 text-left transition-colors focus-within:ring-2 focus-within:ring-brand-accent focus-within:ring-offset-2 focus-within:ring-offset-bg-primary',
                checked
                  ? 'border-brand-accent bg-brand-accent/10'
                  : 'border-brand-line bg-bg-primary hover:border-brand-accent/60',
              ].join(' ')}
            >
              <input
                type="radio"
                name="bcl-deposit-mode"
                value={opt.id}
                checked={checked}
                onChange={() => {
                  track('booking_deposit_mode_changed', { mode: opt.id });
                  onChange(opt.id);
                }}
                className="sr-only"
              />
              <span
                aria-hidden
                className={[
                  'mt-1.5 inline-flex h-3 w-3 shrink-0 items-center justify-center rounded-full border',
                  checked ? 'border-brand-accent bg-brand-accent' : 'border-brand-line',
                ].join(' ')}
              />
              <div className="min-w-0 flex-1">
                <div className="flex items-baseline justify-between gap-3">
                  <span
                    className={[
                      'font-display text-sm font-extrabold',
                      checked ? 'text-brand-accent' : 'text-brand-ink',
                    ].join(' ')}
                  >
                    {opt.label}
                  </span>
                  <span className="font-mono text-[11px] text-brand-mute">
                    {opt.id === 'partial' ? `$${dDollars}` : `$${totalDollars}`}
                  </span>
                </div>
                <p className="mt-1 text-[12px] text-brand-mute">{opt.summary}</p>
                <p className="mt-1 text-[10px] font-mono uppercase tracking-wider text-brand-mute/80">
                  {opt.footnote}
                </p>
              </div>
            </label>
          );
        })}
      </div>
      {value === 'partial' && (
        <p className="mt-3 rounded-md border border-emerald-400/30 bg-emerald-400/5 px-3 py-2 text-[12px] text-emerald-200/90">
          <strong className="font-semibold">
            {depositPct}% today {flooredByMin && `(${depositFloorLabel()})`} (${dDollars})
          </strong>
          {' · '}
          <span>balance ${remainderDollars} T-24h before move.</span>
        </p>
      )}
    </fieldset>
  );
}
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
