import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
/**
 * OneTapRebook.tsx — Wave 33 returning-customer one-tap rebook card.
 *
 * Renders on /me and /book when the signed-in customer has a prior paid
 * booking in the last 365 days AND a Square card-on-file token on the source booking.
 * Shows "Book the same crew + scope as last time" with one button that
 * duplicates the prior booking, charges the saved PM, and confirms in one
 * round-trip.
 *
 * Flag-gated by `one_tap_rebook`. Render-null when off or when the
 * customer is not eligible.
 */
import { useEffect, useState } from 'react';
import { useFeatureFlag } from '../../use-feature-flag.js';
import { usd } from '@theme.tools/billing/field-service/money';

interface PriorBooking {
  id: string;
  servicesCsv: string;
  hours: number;
  totalCents: number;
  preferredDate: string;
  preferredTime: string;
  city: string;
  zip: string;
  address: string;
  completedAt: string | null;
}

interface EligibilityResponse {
  ok: boolean;
  eligible: boolean;
  reason?: string;
  lastBooking?: PriorBooking;
  suggestedDate?: string;
  hasSavedPaymentMethod: boolean;
}

interface RebookResponse {
  ok: boolean;
  newBookingId?: string;
  chargedCents?: number;
  preferredDate?: string;
  preferredTime?: string;
  error?: string;
}

interface Props {
  /** Signed-in customer email. Parent (Me page / Booking page) supplies. */
  customerEmail: string;
  /** Fires after successful rebook so the parent can navigate to /track. */
  onRebooked?: (newBookingId: string) => void;
}

function fmtUsd(cents: number): string {
  return usd(cents);
}

function parseServices(csv: string): string[] {
  return csv
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)
    .map((s) => s.replace(/-/g, ' '));
}

export function OneTapRebook({ customerEmail, onRebooked }: Props): JSX.Element | null {
  useThemeToolsSurface('one-tap-rebook');
  const enabled = useFeatureFlag('one_tap_rebook');
  const [verdict, setVerdict] = useState<EligibilityResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [rebooking, setRebooking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [eligibilityError, setEligibilityError] = useState(false);
  const [retryKey, setRetryKey] = useState(0);

  useEffect(() => {
    if (!enabled || !customerEmail) {
      setLoading(false);
      return;
    }
    let cancelled = false;
    const controller = new AbortController();
    setLoading(true);
    setEligibilityError(false);
    fetch(`/api/one-tap-rebook/eligible/${encodeURIComponent(customerEmail)}`, {
      credentials: 'same-origin',
      signal: controller.signal,
    })
      .then(async (r) => {
        const j = (await r.json().catch(() => ({}))) as EligibilityResponse;
        if (cancelled) return;
        setVerdict(r.ok ? j : { ok: false, eligible: false, hasSavedPaymentMethod: false });
      })
      .catch(() => {
        if (!cancelled) {
          setEligibilityError(true);
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
      controller.abort();
    };
  }, [enabled, customerEmail, retryKey]);

  if (!enabled) return null;
  if (!customerEmail) return null;
  if (loading) {
    return (
      <section
        data-testid="one-tap-rebook-loading"
        aria-label="Checking rebook eligibility"
        className="rounded-xl border border-brand-accent/40 bg-brand-accent/5 p-4"
      >
        <p role="status" className="text-sm text-brand-mute">
          Checking your previous booking…
        </p>
      </section>
    );
  }
  if (eligibilityError) {
    return (
      <section
        data-testid="one-tap-rebook-error"
        aria-labelledby="one-tap-rebook-error-heading"
        className="rounded-xl border border-red-400/50 bg-red-950/20 p-4"
      >
        <h3 id="one-tap-rebook-error-heading" className="font-semibold text-brand-ink">
          We couldn’t check your previous booking
        </h3>
        <p role="alert" className="mt-1 text-sm text-brand-mute">
          Check your connection, then try again.
        </p>
        <button
          type="button"
          onClick={() => setRetryKey((value) => value + 1)}
          className="mt-3 min-h-11 rounded-lg border border-brand-accent px-4 py-2 text-sm font-semibold text-brand-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-accent"
        >
          Try again
        </button>
      </section>
    );
  }
  if (!verdict?.eligible || !verdict.lastBooking) return null;

  async function handleRebook() {
    setRebooking(true);
    setError(null);
    try {
      const r = await fetch('/api/one-tap-rebook/rebook', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({}),
      });
      const j = (await r.json().catch(() => ({}))) as RebookResponse;
      if (r.ok && j.ok && j.newBookingId) {
        onRebooked?.(j.newBookingId);
      } else {
        setError(
          j.error === 'payment_failed'
            ? 'We could not charge your saved card. Nothing was booked twice. Try again.'
            : 'We could not complete the rebook. Try again.',
        );
      }
    } catch (err) {
      setError('Connection lost. Check your connection and try again.');
    } finally {
      setRebooking(false);
    }
  }

  const last = verdict.lastBooking;
  const suggestedDate = verdict.suggestedDate ?? '';

  return (
    <section
      data-testid="one-tap-rebook"
      aria-labelledby="one-tap-rebook-heading"
      className="rounded-xl border border-brand-accent/60 bg-brand-accent/5 p-4 space-y-3"
    >
      <header>
        <h3
          id="one-tap-rebook-heading"
          className="font-mono text-sm font-bold uppercase tracking-widest text-brand-accent"
        >
          Book again, one tap
        </h3>
        <p className="mt-1 text-xs text-brand-mute leading-snug">
          Same crew, same scope, your saved card. Done in 5 seconds.
        </p>
      </header>

      <dl className="grid grid-cols-2 gap-2 text-xs">
        <div className="col-span-2">
          <dt className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
            Services
          </dt>
          <dd className="mt-1.5">
            <ul aria-label="Services for this booking" className="flex flex-wrap gap-1.5">
              {parseServices(last.servicesCsv).map((svc, i) => (
                <li
                  key={svc}
                  style={{ animationDelay: `${i * 50}ms` }}
                  className="inline-flex items-center rounded-full border border-brand-accent/30 bg-brand-accent/10 px-2.5 py-0.5 font-mono text-[11px] font-medium capitalize text-brand-accent transition-all duration-[333ms] hover:-translate-y-0.5 hover:border-brand-accent/60 hover:bg-brand-accent/20 hover:shadow-sm"
                >
                  {svc}
                </li>
              ))}
            </ul>
          </dd>
        </div>
        <div>
          <dt className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">Total</dt>
          <dd className="mt-0.5 font-mono text-brand-ink">{fmtUsd(last.totalCents)}</dd>
        </div>
        <div>
          <dt className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">Hours</dt>
          <dd className="mt-0.5 font-mono text-brand-ink">{last.hours}h</dd>
        </div>
        <div>
          <dt className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
            Suggested date
          </dt>
          <dd className="mt-0.5 font-mono text-brand-ink">{suggestedDate || '—'}</dd>
        </div>
      </dl>

      {error && (
        <p role="alert" className="text-xs text-red-300">
          {error}
        </p>
      )}

      <button
        type="button"
        onClick={handleRebook}
        disabled={rebooking}
        data-testid="one-tap-rebook-button"
        className="w-full rounded-lg border border-brand-accent bg-brand-accent px-4 py-3 font-mono text-sm font-bold uppercase tracking-widest text-bg-primary transition-opacity hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed"
      >
        {rebooking ? 'Booking…' : `One-tap rebook · ${fmtUsd(last.totalCents)}`}
      </button>

      <p className="text-[11px] text-brand-mute leading-snug">
        We'll charge your saved card and schedule for {suggestedDate || 'next week'}. You can
        reschedule or cancel free up to 24h before the job.
      </p>
    </section>
  );
}
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
