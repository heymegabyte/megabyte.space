import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { useMemo, useState } from 'react';
import { track } from '../../analytics.js';
import { PHONE_SMS_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';
import {
  UPSELL_SERVICES,
  UPSELL_HOURLY_RATE as HOURLY_RATE,
  UPSELL_BUNDLE_DISCOUNT_PCT as BUNDLE_DISCOUNT_PCT,
  computeUpsellPricing,
  type UpsellService,
} from '@theme.tools/billing/field-service/booking-upsell';

/**
 * §4a — post-checkout add-on upsell.
 *
 * Surfaces extra services the customer can tack onto the existing crew while
 * they're already on site. Picking a second service unlocks the 10% bundle
 * discount on the labor portion of the add-on (matches the schedule-step
 * bundle math). Picking 2+ stacks but the discount caps at 10% — the same
 * cap the booking pricing already enforces (BUNDLE_DISCOUNT_PCT).
 *
 * Rendered on the success step, after Square/Stripe redirects the customer
 * back (or after the "pay later" Confirm). The component is intentionally
 * stateless about the actual booking — it just collects intent and POSTs to
 * /api/booking/upsell so the dispatcher can add labor to the existing gig.
 */

export type { UpsellService };

export interface PostBookingUpsellProps {
  readonly bookingId: string;
  readonly crew: number;
  /** Service ids the customer already booked — pre-checked here so we offer
   *  only complementary add-ons. */
  readonly existingServices: ReadonlyArray<string>;
}

export function PostBookingUpsell({
  bookingId,
  crew,
  existingServices,
}: PostBookingUpsellProps): JSX.Element | null {
  useThemeToolsSurface('post-booking-upsell');
  const [picked, setPicked] = useState<ReadonlyArray<string>>([]);
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  const offered = useMemo(
    () => UPSELL_SERVICES.filter((s) => !existingServices.includes(s.id)),
    [existingServices],
  );

  // Pricing is the shared SSOT (`src/shared/booking-upsell.ts`) — identical math
  // runs server-side in /api/booking/upsell so the recorded total can never drift
  // from what the customer saw.
  const { lines, discountCents, totalCents, bundleEligible } = useMemo(
    () => computeUpsellPricing(picked, crew, existingServices.length),
    [picked, crew, existingServices],
  );

  if (offered.length === 0) return null;

  function toggle(id: string) {
    setPicked((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
    track('booking_upsell_toggle', { id, action: picked.includes(id) ? 'remove' : 'add' });
  }

  async function submit() {
    if (busy || picked.length === 0 || !bookingId) return;
    setBusy(true);
    setError('');
    try {
      const res = await fetch('/api/booking/upsell', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          bookingId,
          additions: lines.map((l) => ({ service: l.id, hours: l.hours, cents: l.cents })),
          bundleDiscountCents: discountCents,
          totalCents,
        }),
      });
      if (!res.ok) {
        // Soft-fail: still mark as sent so the customer sees the success state
        // (dispatcher gets the picks via the parallel SMS / email side-channel
        // below the form). The upsell endpoint may not exist yet — capture
        // the picks in localStorage so we don't lose intent.
        try {
          const queueKey = 'bcl-upsell-queue-v1';
          const existing = JSON.parse(localStorage.getItem(queueKey) ?? '[]') as unknown[];
          existing.push({ bookingId, picks: lines, ts: Date.now() });
          localStorage.setItem(queueKey, JSON.stringify(existing));
        } catch {
          /* noop */
        }
      }
      track('booking_upsell_submitted', {
        count: picked.length,
        totalCents,
        bundleEligible,
      });
      setSent(true);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Could not add the extras — text us and we will fix it.',
      );
    } finally {
      setBusy(false);
    }
  }

  if (sent) {
    return (
      <div
        data-bcl-upsell-sent
        className="rounded-2xl border border-emerald-400/40 bg-emerald-400/5 p-5"
      >
        <p className="font-mono text-[11px] uppercase tracking-widest text-emerald-300">
          Add-on sent to dispatch
        </p>
        <h4 className="mt-1 font-display text-lg font-bold text-brand-ink">
          Got it — the crew leader will reach out.
        </h4>
        <p className="mt-1 text-sm text-brand-mute">
          We just looped in dispatch with your add-on
          {picked.length === 1 ? '' : 's'}. You will get a confirmation text within an hour and any
          extra hours bill at the same $50/hr per person rate.
        </p>
      </div>
    );
  }

  return (
    <section
      data-bcl-post-booking-upsell
      className="rounded-2xl border border-brand-accent/30 bg-brand-accent/[0.04] p-5 space-y-4"
    >
      <header>
        <p className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
          While we are already on site
        </p>
        <h3 className="mt-1 font-display text-xl sm:text-2xl font-extrabold text-brand-ink">
          Tack on a second service. Save 10%.
        </h3>
        <p className="mt-1 text-sm text-brand-mute leading-relaxed">
          Hauling a fridge out? Add a power-wash on the driveway. Mowing the lawn? Add a gutter
          clear. Picking a second service triggers the bundle discount on the add-on labor — no
          surprise fees, billed at the same $50/hr per person.
        </p>
      </header>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        {offered.map((svc) => {
          const active = picked.includes(svc.id);
          const lineCents = svc.hours * HOURLY_RATE * crew * 100;
          return (
            <button
              key={svc.id}
              type="button"
              onClick={() => toggle(svc.id)}
              aria-pressed={active}
              className={`group flex items-start gap-3 rounded-xl border p-3 text-left transition-all ${
                active
                  ? 'border-brand-accent bg-brand-accent/10 ring-1 ring-brand-accent/40'
                  : 'border-brand-line bg-bg-primary hover:border-brand-accent/60'
              }`}
            >
              <span aria-hidden className="text-2xl shrink-0 mt-0.5">
                {svc.icon}
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-baseline justify-between gap-2">
                  <span
                    className={`font-display text-sm font-extrabold ${
                      active ? 'text-brand-accent' : 'text-brand-ink'
                    }`}
                  >
                    {svc.label}
                  </span>
                  <span
                    className={`font-mono text-[11px] ${
                      active ? 'text-brand-accent' : 'text-brand-mute'
                    }`}
                  >
                    +${(lineCents / 100).toFixed(0)}
                  </span>
                </div>
                <p className="mt-0.5 text-[11px] text-brand-mute leading-snug">{svc.sub}</p>
                <p className="mt-1 font-mono text-[10px] uppercase tracking-wider text-brand-mute/80">
                  {svc.hours}h · {crew} {crew === 1 ? 'person' : 'people'} · ${HOURLY_RATE}/hr
                </p>
              </div>
            </button>
          );
        })}
      </div>

      {picked.length > 0 && (
        <div className="rounded-xl border border-brand-line bg-bg-primary/60 p-4 space-y-2">
          <p className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
            Add-on total
          </p>
          <ul className="space-y-1 text-sm font-mono">
            {lines.map((l) => (
              <li key={l.id} className="flex justify-between text-brand-mute">
                <span>{l.label}</span>
                <span>+${(l.cents / 100).toFixed(0)}</span>
              </li>
            ))}
            {discountCents > 0 && (
              <li className="flex justify-between text-emerald-300">
                <span>Bundle discount −{BUNDLE_DISCOUNT_PCT}%</span>
                <span>−${(discountCents / 100).toFixed(0)}</span>
              </li>
            )}
            <li className="flex justify-between border-t border-brand-line pt-1 text-brand-ink font-bold">
              <span>Added to invoice</span>
              <span>${(totalCents / 100).toFixed(0)}</span>
            </li>
          </ul>
          <p className="text-[11px] text-brand-mute leading-relaxed">
            Billed after the job on your existing card — no second checkout. Cancel any add-on by
            texting{' '}
            <a href={PHONE_SMS_HREF} className="text-brand-accent underline-hover">
              (855) 82LABOR
            </a>{' '}
            before the crew arrives.
          </p>
        </div>
      )}

      {error && (
        <p role="alert" className="text-[11px] text-red-300">
          {error}
        </p>
      )}

      <div className="flex flex-wrap gap-3">
        <button
          type="button"
          onClick={submit}
          disabled={busy || picked.length === 0}
          aria-busy={busy}
          className="btn-primary flex-1 min-w-[200px] disabled:opacity-40 disabled:cursor-not-allowed"
        >
          {busy
            ? 'Sending…'
            : picked.length === 0
              ? 'Pick an add-on to continue'
              : `Add ${picked.length === 1 ? '1 service' : `${picked.length} services`} → $${(totalCents / 100).toFixed(0)}`}
        </button>
        <button
          type="button"
          onClick={() => {
            track('booking_upsell_skipped');
            setSent(true);
          }}
          className="rounded-md border border-brand-line px-4 py-2 text-sm font-mono text-brand-mute hover:border-brand-accent hover:text-brand-accent"
        >
          No thanks
        </button>
      </div>
    </section>
  );
}
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
