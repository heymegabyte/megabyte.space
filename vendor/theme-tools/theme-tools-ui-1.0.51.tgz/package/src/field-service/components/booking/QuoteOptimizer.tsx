import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { useEffect, useState } from 'react';
import { usd } from '@theme.tools/billing/field-service/money';

/**
 * Quote Optimizer surface (Tier 1 #10).
 *
 * Drop-in card the booking flow can render once it has enough info to
 * estimate hours. Calls POST /api/ai/quote-optimizer, shows the 6 ranked
 * combos with a "recommended / cheapest / fastest" badge per card, and
 * surfaces a one-line AI headline above the grid.
 *
 * Designed to be additive: it does not control booking state. The host wires
 * `onPick(combo)` to set crew/hours/truck in the parent's form, and the
 * parent computes the final total the normal way.
 */

export type QuoteCombo = {
  id: string;
  crewSize: 1 | 2 | 3 | 4;
  hours: number;
  truck: boolean;
  priceCents: number;
  etaLabel: string;
  label: 'cheapest' | 'fastest' | 'recommended' | 'crew_heavy' | 'with_truck' | 'budget';
  blurb: string;
};

type Props = {
  services: string[];
  estimatedHours: number;
  zip?: string;
  city?: string;
  urgency: 'same_day' | 'next_day' | 'this_week' | 'flexible';
  truckNeeded?: boolean;
  onPick?: (combo: QuoteCombo) => void;
};

const LABEL_COPY: Record<QuoteCombo['label'], string> = {
  recommended: 'Recommended',
  cheapest: 'Cheapest',
  fastest: 'Fastest',
  crew_heavy: 'Bigger crew',
  with_truck: 'With truck',
  budget: 'Budget',
};

function fmtUsd(cents: number): string {
  return usd(cents);
}

export function QuoteOptimizer(props: Props) {
  useThemeToolsSurface('quote-optimizer');
  const { services, estimatedHours, zip, city, urgency, truckNeeded, onPick } = props;
  const [combos, setCombos] = useState<QuoteCombo[]>([]);
  const [headline, setHeadline] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>('');
  const [pickedId, setPickedId] = useState<string>('');

  useEffect(() => {
    let cancelled = false;
    const ctrl = new AbortController();
    async function load() {
      setLoading(true);
      setError('');
      try {
        const res = await fetch('/api/ai/quote-optimizer', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            services,
            estimatedHours,
            zip,
            city,
            urgency,
            truckNeeded: !!truckNeeded,
          }),
          signal: ctrl.signal,
        });
        if (!res.ok) throw new Error(`status ${res.status}`);
        const json = (await res.json()) as {
          ok: boolean;
          headline?: string;
          combos?: QuoteCombo[];
        };
        if (cancelled) return;
        if (json.ok && json.combos) {
          setCombos(json.combos);
          setHeadline(json.headline ?? '');
          const rec = json.combos.find((c) => c.label === 'recommended');
          if (rec) setPickedId(rec.id);
        } else {
          setError('Pricing service is busy. Use the slider below.');
        }
      } catch (err) {
        if ((err as Error).name === 'AbortError') return;
        if (!cancelled) setError('Pricing service is busy. Use the slider below.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    void load();
    return () => {
      cancelled = true;
      ctrl.abort();
    };
  }, [services.join(','), estimatedHours, zip, city, urgency, truckNeeded]);

  if (loading) {
    return (
      <div
        className="rounded-2xl border border-brand-line bg-bg-elevated/40 p-4 text-sm text-brand-mute"
        aria-live="polite"
      >
        Mapping out 6 ways to do this job…
      </div>
    );
  }

  if (error || combos.length === 0) {
    return error ? (
      <div className="rounded-2xl border border-brand-line bg-bg-elevated/40 p-4 text-sm text-brand-mute">
        {error}
      </div>
    ) : null;
  }

  return (
    <section
      data-bcl-section="quote-optimizer"
      className="rounded-2xl border border-brand-line bg-bg-elevated/40 p-4"
      aria-labelledby="quote-optimizer-title"
    >
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <h3
          id="quote-optimizer-title"
          className="font-mono text-[11px] uppercase tracking-[0.18em] text-brand-accent"
        >
          Pick your fit
        </h3>
        {headline && <p className="text-xs text-brand-mute">{headline}</p>}
      </div>
      <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
        {combos.map((c) => {
          const picked = c.id === pickedId;
          return (
            <li key={c.id}>
              <button
                type="button"
                onClick={() => {
                  setPickedId(c.id);
                  onPick?.(c);
                }}
                data-bcl-action="quote_combo_picked"
                data-bcl-label={c.label}
                aria-pressed={picked}
                className={`flex w-full flex-col gap-1 rounded-xl border p-3 text-left transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-accent ${
                  picked
                    ? 'border-brand-accent bg-brand-accent/10'
                    : 'border-brand-line bg-bg-elevated hover:border-brand-accent/60'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-brand-accent">
                    {LABEL_COPY[c.label]}
                  </span>
                  <span className="text-base font-semibold text-brand-ink">
                    {fmtUsd(c.priceCents)}
                  </span>
                </div>
                <div className="text-sm text-brand-ink">
                  {c.crewSize}-person crew · {c.hours}h{c.truck ? ' · truck' : ''}
                </div>
                <div className="text-xs text-brand-mute">{c.blurb}</div>
              </button>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
