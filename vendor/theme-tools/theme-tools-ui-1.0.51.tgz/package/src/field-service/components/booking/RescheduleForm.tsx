import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { useEffect, useState } from 'react';
import { track } from '../../analytics.js';
import { nyToday } from '@theme.tools/scheduling/field-service/ny-time';

// Wave 2A — RescheduleForm.
// Renders on a secure /reschedule?token=… link. Posts to
// POST /api/booking/:id/reschedule with the new preferred_date + time and
// the bearer token. Server validates token + re-runs availability before
// updating bookings.scheduled_at.

export interface ReschedulePrefill {
  readonly bookingId: string;
  readonly token: string;
  readonly currentDate?: string;
  readonly currentTime?: string;
}

export interface RescheduleFormProps {
  readonly prefill: ReschedulePrefill;
  readonly onSuccess?: (next: { date: string; time: string }) => void;
}

interface AvailabilityResult {
  ok: boolean;
  slots?: Array<{ startAt: string; localTime: string }>;
  message?: string;
}

interface RescheduleResult {
  ok: boolean;
  bookingId?: string;
  scheduled_at?: string;
  message?: string;
  error?: string;
}

/**
 * Token-link page form. Tiny by design — date + time picker + submit.
 * The server is the source of truth for availability.
 */
export function RescheduleForm({ prefill, onSuccess }: RescheduleFormProps): JSX.Element {
  useThemeToolsSurface('reschedule-form');
  const [date, setDate] = useState(prefill.currentDate ?? '');
  const [time, setTime] = useState(prefill.currentTime ?? '');
  const [slots, setSlots] = useState<Array<{ startAt: string; localTime: string }>>([]);
  const [slotsLoading, setSlotsLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (!date) return;
    let cancelled = false;
    setSlotsLoading(true);
    fetch(`/api/square-availability?date=${encodeURIComponent(date)}&hours=2`)
      .then((r) => r.json() as Promise<AvailabilityResult>)
      .then((data) => {
        if (cancelled) return;
        if (data.ok && data.slots) {
          setSlots(data.slots);
        } else {
          setSlots([]);
        }
      })
      .catch(() => {
        if (!cancelled) setSlots([]);
      })
      .finally(() => {
        if (!cancelled) setSlotsLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [date]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!date || !time) {
      setSubmitError('Pick a date and a time slot.');
      return;
    }
    setSubmitting(true);
    setSubmitError('');
    track('booking_reschedule_submit', { bookingId: prefill.bookingId });
    try {
      const res = await fetch(`/api/booking-reschedule/${encodeURIComponent(prefill.bookingId)}/reschedule`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          token: prefill.token,
          preferred_date: date,
          preferred_time: time,
        }),
      });
      const data = (await res.json()) as RescheduleResult;
      if (!res.ok || !data.ok) {
        setSubmitError(data.error ?? data.message ?? 'Could not reschedule. Try again.');
        return;
      }
      setDone(true);
      track('booking_reschedule_ok', { bookingId: prefill.bookingId });
      onSuccess?.({ date, time });
    } catch {
      setSubmitError('Network hiccup. Try again.');
    } finally {
      setSubmitting(false);
    }
  }

  if (done) {
    return (
      <div
        data-bcl-reschedule-success
        className="rounded-2xl border border-emerald-400/30 bg-emerald-400/5 p-6"
      >
        <h2 className="font-display text-2xl font-extrabold text-emerald-300">Booking moved.</h2>
        <p className="mt-2 text-sm text-brand-mute">
          New date: <span className="text-brand-ink">{date}</span> · Time:{' '}
          <span className="text-brand-ink">{time}</span>. We just texted your confirmation.
        </p>
      </div>
    );
  }

  // Newark business day (NOT UTC) so the earliest selectable day matches the
  // server's same-day acceptance — UTC rolls forward an evening early.
  const today = nyToday();
  const maxDate = (() => {
    const d = new Date();
    d.setDate(d.getDate() + 60);
    return d.toISOString().slice(0, 10);
  })();

  return (
    <form
      data-bcl-reschedule-form
      onSubmit={submit}
      className="space-y-4 rounded-2xl border border-brand-line bg-bg-elevated/70 p-6"
    >
      <header>
        <p className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
          Reschedule
        </p>
        <h2 className="mt-1 font-display text-2xl font-extrabold text-brand-ink">
          Pick a new date.
        </h2>
        <p className="mt-1 text-sm text-brand-mute">
          Same crew, same price — we just shift the slot.
        </p>
      </header>

      <label className="block">
        <span className="block text-xs font-mono uppercase tracking-wider text-brand-mute mb-1">
          New date
        </span>
        <input
          type="date"
          value={date}
          min={today}
          max={maxDate}
          onChange={(e) => {
            setDate(e.target.value);
            setTime('');
          }}
          className="w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-brand-ink focus:border-brand-accent focus:outline-none"
          required
        />
      </label>

      {date && (
        <fieldset>
          <legend className="block text-xs font-mono uppercase tracking-wider text-brand-mute mb-1">
            Available start times
          </legend>
          {slotsLoading ? (
            <p className="text-sm text-brand-mute">Checking the crew calendar…</p>
          ) : slots.length === 0 ? (
            <p className="text-sm text-amber-300/90">No open slots that day — try another date.</p>
          ) : (
            <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
              {slots.map((s) => {
                const active = s.localTime === time;
                return (
                  <button
                    key={s.startAt}
                    type="button"
                    onClick={() => setTime(s.localTime)}
                    aria-pressed={active}
                    className={[
                      'rounded-md border px-2 py-2 font-mono text-xs',
                      active
                        ? 'border-brand-accent bg-brand-accent text-bg-primary'
                        : 'border-brand-line text-brand-mute hover:border-brand-accent hover:text-brand-accent',
                    ].join(' ')}
                  >
                    {s.localTime}
                  </button>
                );
              })}
            </div>
          )}
        </fieldset>
      )}

      {submitError && (
        <p
          role="alert"
          className="rounded-md border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-xs text-amber-200"
        >
          {submitError}
        </p>
      )}

      <button
        type="submit"
        disabled={submitting || !date || !time}
        className="w-full rounded-lg bg-brand-accent px-4 py-3 font-display text-base font-bold text-bg-primary hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-50"
      >
        {submitting ? 'Saving…' : 'Confirm new slot →'}
      </button>
    </form>
  );
}
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
