import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { useMemo } from 'react';
import { computeSurge } from '@theme.tools/billing/field-service/surge';
import { fmtMoney } from '@theme.tools/billing/field-service/booking-pricing';

/**
 * Customer-facing surge awareness (Tier 1 idea #13).
 *
 * Renders a strip showing the next 7 days with their surge multiplier so
 * the customer can SEE "Tuesday saves 35%" before committing to today.
 * Behavioral nudge → smooths supply + raises customer trust ("the slider
 * isn't just charging me more, it's because of demand").
 *
 * Drop-in next to the date picker. Click any day to set it as preferred.
 */

interface Props {
  hoursEstimate: number;
  selectedDate?: string;
  onPickDate?: (iso: string) => void;
  hourlyRateCents?: number;
  crewSize?: number;
  /**
   * Canonical per-day pricer — given a YYYY-MM-DD, returns the SAME total (in
   * cents) the big estimate loads when that day is picked, plus its surge
   * multiplier. Supplied by Booking.tsx (`computePricing` with `selectedSlot:
   * null`) so the peek dollar figure ALWAYS equals the estimate (Sunday +$15/hr
   * premium, same-day +$75 rush, discounts, rentals, demand surge all included).
   * Absent → falls back to the old labor×surge estimate.
   */
  priceForDate?: (iso: string) => { totalCents: number; multiplier: number };
}

const DEFAULT_HOURLY_PER_PERSON_CENTS = 5000;

function dayLabel(iso: string): string {
  const d = new Date(`${iso}T12:00:00`);
  return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
}

export function SurgeAwareDatePeek(props: Props) {
  useThemeToolsSurface('surge-aware-date-peek');
  const {
    hoursEstimate,
    selectedDate,
    onPickDate,
    hourlyRateCents = DEFAULT_HOURLY_PER_PERSON_CENTS,
    crewSize = 2,
    priceForDate,
  } = props;

  const rows = useMemo(() => {
    const fallbackSubtotalCents = hourlyRateCents * crewSize * hoursEstimate;
    const today = new Date();
    today.setHours(12, 0, 0, 0);
    const out: Array<{
      iso: string;
      label: string;
      multiplier: number;
      totalCents: number;
      reasons: string[];
      isCheapest: boolean;
    }> = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date(today.getTime() + i * 24 * 60 * 60 * 1000);
      const iso = d.toISOString().slice(0, 10);
      const surge = computeSurge({
        preferredDate: iso,
        preferredTime: '10:00',
      });
      // Prefer the canonical pricer so the dollar figure equals the big estimate
      // for that day (same-day rush, Sunday premium, discounts, rentals, surge).
      const priced = priceForDate ? priceForDate(iso) : null;
      out.push({
        iso,
        label: dayLabel(iso),
        multiplier: priced ? priced.multiplier : surge.multiplier,
        totalCents: priced ? priced.totalCents : Math.round(fallbackSubtotalCents * surge.multiplier),
        reasons: surge.reasons.map((r) => r.kind),
        isCheapest: false,
      });
    }
    // EVERY day that ties the minimum price is flagged "Best price" — the user
    // wants ALL matching-cheapest days marked (not just the earliest), so the
    // customer sees every equally-cheap option at a glance.
    const minTotal = Math.min(...out.map((r) => r.totalCents));
    return out.map((r) => ({ ...r, isCheapest: r.totalCents === minTotal }));
  }, [hoursEstimate, hourlyRateCents, crewSize, priceForDate]);

  return (
    <section
      data-bcl-section="surge-peek"
      className="rounded-2xl border border-brand-line bg-bg-elevated/40 p-4"
      aria-labelledby="surge-peek-title"
    >
      <div className="mb-2 flex items-baseline justify-between gap-3">
        <h3
          id="surge-peek-title"
          className="font-mono text-[11px] uppercase tracking-[0.18em] text-brand-accent"
        >
          Pick the cheapest day
        </h3>
        <p className="text-xs text-brand-mute">
          Same crew, same job — different demand on different days.
        </p>
      </div>
      <ul className="grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-7">
        {rows.map((r) => {
          const selected = r.iso === selectedDate;
          return (
            <li key={r.iso}>
              <button
                type="button"
                onClick={() => onPickDate?.(r.iso)}
                data-bcl-action="surge_peek_picked"
                data-bcl-date={r.iso}
                aria-pressed={selected}
                className={`flex w-full flex-col items-start gap-1 rounded-lg border p-2 text-left transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-accent ${
                  selected
                    ? 'border-brand-accent bg-brand-accent/10'
                    : r.isCheapest
                      ? 'border-emerald-500/50 bg-emerald-500/5 hover:border-emerald-500'
                      : 'border-brand-line bg-bg-elevated hover:border-brand-accent/60'
                }`}
              >
                <span className="font-mono text-[10px] uppercase tracking-[0.12em] text-brand-mute">
                  {r.label}
                </span>
                <span className="text-base font-semibold text-brand-ink">
                  ${fmtMoney(r.totalCents)}
                </span>
                <span className="text-[10px] text-brand-mute">
                  {r.multiplier === 1
                    ? 'baseline'
                    : `${((r.multiplier - 1) * 100).toFixed(0)}% ${r.multiplier > 1 ? 'surge' : 'off'}`}
                </span>
                {r.isCheapest && (
                  <span className="text-[10px] font-semibold text-emerald-400">Best price</span>
                )}
              </button>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
