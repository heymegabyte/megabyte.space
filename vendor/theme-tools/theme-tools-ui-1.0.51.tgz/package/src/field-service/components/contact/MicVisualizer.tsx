import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { useEffect, useRef } from 'react';

interface Props {
  /** Live analyser node from {@link useMicrophone}; null when the mic is off. */
  analyser: AnalyserNode | null;
  /** Whether the mic is currently capturing. */
  active: boolean;
  /** Override the default full-bleed, low-opacity background positioning. */
  className?: string;
}

/**
 * Full-bleed frequency-bar visualizer driven by a Web Audio `AnalyserNode`.
 *
 * Renders behind page content at low opacity and animates ONLY while the mic is
 * live, so a soft orange spectrum blooms up from the bottom as the user speaks.
 * Honors `prefers-reduced-motion` (renders a calm, near-static band instead of
 * reactive bars). Purely decorative → `aria-hidden`.
 */
export function MicVisualizer({ analyser, active, className }: Props) {
  useThemeToolsSurface('mic-visualizer');
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !analyser || !active) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    const bins = analyser.frequencyBinCount;
    const data = new Uint8Array(bins);

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.max(1, Math.floor(canvas.clientWidth * dpr));
      canvas.height = Math.max(1, Math.floor(canvas.clientHeight * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener('resize', resize);

    const draw = () => {
      rafRef.current = requestAnimationFrame(draw);
      analyser.getByteFrequencyData(data);
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      ctx.clearRect(0, 0, w, h);

      const barCount = Math.min(72, bins);
      const gap = 2;
      const barW = Math.max(1, w / barCount - gap);
      for (let i = 0; i < barCount; i++) {
        // Fold the spectrum outward from the center so the bloom is symmetric.
        const half = barCount / 2;
        const srcIdx = i < half ? Math.floor(half - 1 - i) : Math.floor(i - half);
        const mag = reduce ? 48 : (data[srcIdx] ?? 0);
        const barH = (mag / 255) * h * 0.92;
        const x = i * (barW + gap);
        const grad = ctx.createLinearGradient(0, h, 0, h - barH);
        grad.addColorStop(0, 'rgba(255,107,26,0.60)');
        grad.addColorStop(1, 'rgba(255,107,26,0.04)');
        ctx.fillStyle = grad;
        ctx.fillRect(x, h - barH, barW, barH);
      }
    };
    draw();

    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener('resize', resize);
    };
  }, [analyser, active]);

  if (!active) return null;
  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className={
        className ??
        'pointer-events-none absolute inset-x-0 bottom-0 z-0 h-1/2 w-full opacity-[0.16]'
      }
    />
  );
}
