import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useMemo, useState } from 'react';

/**
 * `<AddressBookCard>` — Saved-addresses surface for `/me`.
 *
 * Lists active addresses (default first), supports add / edit /
 * delete / set-default. Backed by `/api/customer-address-book/*`
 * which is gated by the `customer_address_book` flag. Foreground
 * wires this into the `/me` page beside the bookings list.
 *
 * NOT wired into Booking.tsx here — that's a separate foreground
 * change. The data model + API + this card give the booking flow
 * everything it needs to prefill move-from from `getDefaultAddress`.
 */

interface AddressRow {
  id: string;
  customer_id: string;
  label: string;
  address_line_1: string;
  address_line_2: string | null;
  city: string;
  state: string;
  zip: string;
  lat: number | null;
  lng: number | null;
  is_default: number;
  last_used_at: string | null;
  archived_at: string | null;
  created_at: string;
  updated_at: string;
}

interface Props {
  /** Customer's session contact (email or E.164 phone). Foreground
   *  passes from the resolved session. */
  customerId: string;
  /** Foreground passes `useFeatureFlag('customer_address_book')`. The
   *  card renders `null` when false. */
  enabled?: boolean;
}

type FormState = {
  label: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  state: string;
  zip: string;
  setDefault: boolean;
};

const EMPTY_FORM: FormState = {
  label: 'Home',
  addressLine1: '',
  addressLine2: '',
  city: '',
  state: 'NJ',
  zip: '',
  setDefault: false,
};

export function AddressBookCard({ customerId, enabled = true }: Props): JSX.Element | null {
  useThemeToolsSurface('address-book-card');
  const [addresses, setAddresses] = useState<AddressRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [busy, setBusy] = useState(false);
  const [pendingRemoveId, setPendingRemoveId] = useState<string | null>(null);

  function readableError(value: unknown, fallback: string): string {
    const message = value instanceof Error ? value.message : String(value || '');
    if (/401|unauthorized/i.test(message)) return 'Sign in to manage your addresses.';
    if (/network|fetch|HTTP 5\d\d/i.test(message)) {
      return 'We could not reach the address service. Check your connection and try again.';
    }
    if (/validation|invalid|HTTP 400/i.test(message)) {
      return 'Check the address fields and try again.';
    }
    return fallback;
  }

  const reload = useCallback(async () => {
    setError('');
    try {
      const res = await fetch(`/api/customer-address-book/list/${encodeURIComponent(customerId)}`, {
        credentials: 'same-origin',
      });
      if (res.status === 404) {
        // Flag off — silently behave as if no addresses exist.
        setAddresses([]);
        return;
      }
      if (res.status === 401) {
        setError('Sign in to manage your addresses.');
        return;
      }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = (await res.json()) as { ok: boolean; addresses?: AddressRow[] };
      setAddresses(data.addresses ?? []);
    } catch (err) {
      setError(readableError(err, 'We could not load your saved addresses. Please try again.'));
    }
  }, [customerId]);

  useEffect(() => {
    if (!enabled) return;
    let cancelled = false;
    setLoading(true);
    (async () => {
      await reload();
      if (!cancelled) setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [enabled, reload]);

  const defaultId = useMemo(
    () => addresses.find((a) => a.is_default === 1)?.id ?? null,
    [addresses],
  );

  function startEdit(row: AddressRow) {
    setEditingId(row.id);
    setAdding(false);
    setForm({
      label: row.label,
      addressLine1: row.address_line_1,
      addressLine2: row.address_line_2 ?? '',
      city: row.city,
      state: row.state,
      zip: row.zip,
      setDefault: row.is_default === 1,
    });
  }

  function startAdd() {
    setEditingId(null);
    setAdding(true);
    setForm(EMPTY_FORM);
  }

  function cancelEdit() {
    setEditingId(null);
    setAdding(false);
    setForm(EMPTY_FORM);
  }

  async function submit() {
    setBusy(true);
    setError('');
    try {
      const payload: Record<string, unknown> = {
        label: form.label,
        addressLine1: form.addressLine1,
        addressLine2: form.addressLine2 || undefined,
        city: form.city,
        state: form.state,
        zip: form.zip,
      };
      if (adding && form.setDefault) payload.setDefault = true;

      let res: Response;
      if (adding) {
        res = await fetch('/api/customer-address-book/add', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
      } else if (editingId) {
        res = await fetch(`/api/customer-address-book/${encodeURIComponent(editingId)}`, {
          method: 'PATCH',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
      } else {
        return;
      }
      const data = (await res.json()) as { ok?: boolean; error?: string };
      if (!data.ok) throw new Error(data.error ?? 'save_failed');
      cancelEdit();
      await reload();
    } catch (err) {
      setError(readableError(err, 'We could not save that address. Please try again.'));
    } finally {
      setBusy(false);
    }
  }

  async function archive(id: string) {
    setPendingRemoveId(null);
    setBusy(true);
    try {
      const res = await fetch(`/api/customer-address-book/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        credentials: 'same-origin',
      });
      const data = (await res.json()) as { ok?: boolean; error?: string };
      if (!data.ok) throw new Error(data.error ?? 'archive_failed');
      await reload();
    } catch (err) {
      setError(readableError(err, 'We could not remove that address. Please try again.'));
    } finally {
      setBusy(false);
    }
  }

  async function makeDefault(id: string) {
    setBusy(true);
    try {
      const res = await fetch(`/api/customer-address-book/${encodeURIComponent(id)}/set-default`, {
        method: 'POST',
        credentials: 'same-origin',
      });
      const data = (await res.json()) as { ok?: boolean; error?: string };
      if (!data.ok) throw new Error(data.error ?? 'set_default_failed');
      await reload();
    } catch (err) {
      setError(readableError(err, 'We could not change your default address. Please try again.'));
    } finally {
      setBusy(false);
    }
  }

  if (!enabled) return null;

  return (
    <article
      data-testid="address-book-card"
      className="rounded-xl border border-brand-line bg-bg-primary p-5"
    >
      <header className="mb-4 flex items-baseline justify-between gap-3">
        <h2 className="text-lg font-bold">Saved addresses</h2>
        {!adding && !editingId && (
          <button
            type="button"
            onClick={startAdd}
            className="text-brand-accent text-sm underline"
            data-testid="address-book-add-button"
          >
            + Add address
          </button>
        )}
      </header>

      {error && (
        <div
          className="mb-3 rounded-md border border-rose-900/40 bg-rose-900/20 px-3 py-2 text-sm text-rose-200"
          role="alert"
          data-testid="address-book-error"
        >
          {error}{' '}
          <button type="button" onClick={() => void reload()} className="font-semibold underline">
            Try again
          </button>
        </div>
      )}

      {loading && <p className="text-brand-mute text-sm">Loading…</p>}

      {!loading && addresses.length === 0 && !adding && (
        <p className="text-brand-mute text-sm">
          No saved addresses yet. Add one to prefill future bookings.
        </p>
      )}

      {addresses.length > 0 && (
        <ul className="space-y-2">
          {addresses.map((row) => (
            <li
              key={row.id}
              className="rounded-md border border-brand-line bg-bg-elevated p-3"
              data-testid={`address-row-${row.id}`}
            >
              {editingId === row.id ? (
                <Form
                  form={form}
                  setForm={setForm}
                  onSubmit={submit}
                  onCancel={cancelEdit}
                  busy={busy}
                  isEdit
                />
              ) : (
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold">{row.label}</span>
                      {row.id === defaultId && (
                        <span className="rounded-full bg-emerald-900/40 px-2 py-0.5 text-xs text-emerald-200">
                          Default
                        </span>
                      )}
                    </div>
                    <p className="mt-1 text-sm text-brand-mute">
                      {row.address_line_1}
                      {row.address_line_2 ? `, ${row.address_line_2}` : ''}
                      <br />
                      {row.city}, {row.state} {row.zip}
                    </p>
                  </div>
                  <div className="flex shrink-0 gap-2 text-xs">
                    {row.id !== defaultId && (
                      <button
                        type="button"
                        onClick={() => makeDefault(row.id)}
                        disabled={busy}
                        className="text-brand-accent underline disabled:opacity-60"
                      >
                        Set default
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => startEdit(row)}
                      className="text-brand-accent underline"
                    >
                      Edit
                    </button>
                    <button
                      type="button"
                      onClick={() => setPendingRemoveId(row.id)}
                      disabled={busy}
                      className="text-rose-400 underline disabled:opacity-60"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              )}
            </li>
          ))}
        </ul>
      )}

      {adding && (
        <div className="mt-4 rounded-md border border-brand-line bg-bg-elevated p-3">
          <Form
            form={form}
            setForm={setForm}
            onSubmit={submit}
            onCancel={cancelEdit}
            busy={busy}
            isEdit={false}
          />
        </div>
      )}

      {pendingRemoveId && (
        <div
          className="mt-4 rounded-md border border-rose-700/50 bg-rose-950/30 p-3"
          role="alertdialog"
          aria-modal="true"
          aria-labelledby="address-remove-title"
          aria-describedby="address-remove-description"
          data-testid="address-book-remove-confirmation"
        >
          <h3 id="address-remove-title" className="font-semibold">
            Remove address?
          </h3>
          <p id="address-remove-description" className="mt-1 text-sm text-brand-mute">
            This removes it from your saved list. You can add it again later.
          </p>
          <div className="mt-3 flex gap-2">
            <button
              type="button"
              className="btn btn-primary text-sm"
              disabled={busy}
              onClick={() => void archive(pendingRemoveId)}
            >
              {busy ? 'Removing…' : 'Remove'}
            </button>
            <button
              type="button"
              className="btn btn-secondary text-sm"
              onClick={() => setPendingRemoveId(null)}
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </article>
  );
}

interface FormProps {
  form: FormState;
  setForm: (next: FormState) => void;
  onSubmit: () => void;
  onCancel: () => void;
  busy: boolean;
  isEdit: boolean;
}

function Form({ form, setForm, onSubmit, onCancel, busy, isEdit }: FormProps): JSX.Element {
  const [touched, setTouched] = useState<ReadonlySet<keyof FormState>>(new Set());
  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm({ ...form, [key]: value });
  }
  function touch(key: keyof FormState) {
    setTouched((current) => new Set(current).add(key));
  }
  const missing = [
    ['label', 'Label'],
    ['addressLine1', 'Address line 1'],
    ['city', 'City'],
    ['state', 'State'],
    ['zip', 'ZIP'],
  ].filter(
    ([key]) => touched.has(key as keyof FormState) && !String(form[key as keyof FormState]).trim(),
  );
  const fieldA11y = (key: keyof FormState) => ({
    onBlur: () => touch(key),
    'aria-invalid': touched.has(key) && !String(form[key]).trim() ? (true as const) : undefined,
    'aria-describedby':
      touched.has(key) && !String(form[key]).trim() ? 'address-form-error' : undefined,
  });
  const disabled =
    busy ||
    !form.label.trim() ||
    !form.addressLine1.trim() ||
    !form.city.trim() ||
    !form.state.trim() ||
    !form.zip.trim();

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (!disabled) onSubmit();
      }}
      className="space-y-3"
    >
      <div className="grid grid-cols-2 gap-2">
        <label className="block text-xs">
          <span className="text-brand-mute">Label</span>
          <input
            type="text"
            value={form.label}
            onChange={(e) => update('label', e.target.value)}
            maxLength={40}
            className="mt-1 w-full rounded border border-brand-line bg-black/40 px-2 py-1 text-sm"
            data-testid="address-book-label"
            {...fieldA11y('label')}
          />
        </label>
        <label className="block text-xs">
          <span className="text-brand-mute">ZIP</span>
          <input
            type="text"
            value={form.zip}
            onChange={(e) => update('zip', e.target.value)}
            maxLength={10}
            className="mt-1 w-full rounded border border-brand-line bg-black/40 px-2 py-1 text-sm"
            inputMode="numeric"
            {...fieldA11y('zip')}
          />
        </label>
      </div>
      <label className="block text-xs">
        <span className="text-brand-mute">Address line 1</span>
        <input
          type="text"
          value={form.addressLine1}
          onChange={(e) => update('addressLine1', e.target.value)}
          maxLength={120}
          className="mt-1 w-full rounded border border-brand-line bg-black/40 px-2 py-1 text-sm"
          {...fieldA11y('addressLine1')}
        />
      </label>
      <label className="block text-xs">
        <span className="text-brand-mute">Address line 2 (apt, suite)</span>
        <input
          type="text"
          value={form.addressLine2}
          onChange={(e) => update('addressLine2', e.target.value)}
          maxLength={120}
          className="mt-1 w-full rounded border border-brand-line bg-black/40 px-2 py-1 text-sm"
        />
      </label>
      <div className="grid grid-cols-3 gap-2">
        <label className="col-span-2 block text-xs">
          <span className="text-brand-mute">City</span>
          <input
            type="text"
            value={form.city}
            onChange={(e) => update('city', e.target.value)}
            maxLength={60}
            className="mt-1 w-full rounded border border-brand-line bg-black/40 px-2 py-1 text-sm"
            {...fieldA11y('city')}
          />
        </label>
        <label className="block text-xs">
          <span className="text-brand-mute">State</span>
          <input
            type="text"
            value={form.state}
            onChange={(e) => update('state', e.target.value.toUpperCase())}
            maxLength={3}
            className="mt-1 w-full rounded border border-brand-line bg-black/40 px-2 py-1 text-sm uppercase"
            {...fieldA11y('state')}
          />
        </label>
      </div>
      {!isEdit && (
        <label className="flex items-center gap-2 text-xs">
          <input
            type="checkbox"
            checked={form.setDefault}
            onChange={(e) => update('setDefault', e.target.checked)}
          />
          <span>Make this my default address</span>
        </label>
      )}
      {missing.length > 0 && (
        <p id="address-form-error" className="text-xs font-medium text-rose-300" role="alert">
          Required: {missing.map(([, label]) => label).join(', ')}
        </p>
      )}
      <div className="flex gap-2 pt-1">
        <button
          type="submit"
          disabled={disabled}
          className="btn btn-primary text-sm disabled:opacity-60"
          data-testid="address-book-save"
        >
          {busy ? 'Saving…' : isEdit ? 'Save changes' : 'Add address'}
        </button>
        <button type="button" onClick={onCancel} className="btn btn-secondary text-sm">
          Cancel
        </button>
      </div>
    </form>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
