import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useState } from 'react';

interface Props {
  bookingId: string;
  label?: string;
  className?: string;
}

/**
 * CalendarExportButton — downloadable .ics for the customer's booking. Hits
 * the cookie-gated `/api/customer/bookings/:id/calendar.ics`, packages the
 * response as an object-URL blob, and triggers a download. Works on Safari /
 * iOS because we use an anchor element with `download` attribute rather than
 * `window.location.assign(blob)` (which iOS treats as a navigation).
 */
export function CalendarExportButton(props: Props): JSX.Element {
  useThemeToolsSurface('calendar-export-button');
  const { bookingId, label = 'Add to calendar', className = '' } = props;
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string>('');

  const onClick = useCallback(async () => {
    if (busy) return;
    setBusy(true);
    setError('');
    try {
      const res = await fetch(
        `/api/customer/bookings/${encodeURIComponent(bookingId)}/calendar.ics`,
        {
          credentials: 'include',
        },
      );
      if (res.status === 401) {
        setError('Sign in to download your calendar invite.');
        return;
      }
      if (!res.ok) {
        setError('Could not generate calendar invite.');
        return;
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `brickcitylabor-${bookingId}.ics`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch {
      setError('Network error. Try again.');
    } finally {
      setBusy(false);
    }
  }, [bookingId, busy]);

  return (
    <span className={`inline-flex flex-col gap-1 ${className}`}>
      <button
        type="button"
        onClick={() => void onClick()}
        disabled={busy}
        className="btn btn-primary text-sm disabled:opacity-50"
      >
        {busy ? 'Preparing…' : label}
      </button>
      {error && (
        <span className="text-xs text-red-300" role="alert">
          {error}
        </span>
      )}
    </span>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
