import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useState } from 'react';
import { VideoPlayer } from '../work/VideoPlayer.js';

// Wave 14 — Customer-facing welcome video, landscape 16:9.
//
// Intended to render on the booking-confirmation page (first-time customers
// only). Uses the same `<VideoPlayer />` server-verified pipeline as the
// worker onboarding video so we can later run "what % of new customers
// watched the welcome" reports without instrumenting a second analytics
// path. `videoKind: 'onboarding'` (not 'customer-onboarding') because the
// D1 column is constrained to four kinds — `'onboarding'` covers both crews
// and customers; the watcher row's `user_kind` distinguishes them.

export interface CustomerOnboardingVideoProps {
  readonly onComplete?: () => void;
  readonly autoStart?: boolean;
}

export function CustomerOnboardingVideo({
  onComplete,
  autoStart = false,
}: CustomerOnboardingVideoProps): JSX.Element {
  useThemeToolsSurface('customer-onboarding-video');
  const [done, setDone] = useState<boolean>(false);

  const handleComplete = useCallback((): void => {
    setDone(true);
    onComplete?.();
  }, [onComplete]);

  return (
    <section
      aria-labelledby="customer-onboarding-heading"
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap: 16,
        padding: 20,
        background: 'var(--color-media-panel)',
        border: '1px solid var(--color-media-line)',
        borderRadius: 16,
      }}
    >
      <header style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        <h2
          id="customer-onboarding-heading"
          style={{ margin: 0, fontSize: 22, color: 'var(--color-heading-bright)', fontWeight: 700 }}
        >
          Welcome to Brick Labor
        </h2>
        <p style={{ margin: 0, fontSize: 14, color: 'var(--color-media-mute)' }}>
          A short walkthrough of what to expect when your crew arrives.
        </p>
      </header>

      <VideoPlayer
        videoSrc="/customer/welcome.mp4"
        posterSrc="/onboarding/video-poster.svg"
        videoId="customer-welcome-2026"
        videoKind="onboarding"
        orientation="landscape"
        autoStart={autoStart}
        onComplete={handleComplete}
        captionLabel="Customer welcome video"
      />

      {done ? (
        <p
          role="status"
          aria-live="polite"
          style={{
            margin: 0,
            padding: '10px 14px',
            background: 'var(--color-success-panel)',
            border: '1px solid var(--color-success-bright)',
            borderRadius: 12,
            color: 'var(--color-success-ink)',
            fontSize: 14,
          }}
        >
          Thanks for watching — your crew has the details and you're all set.
        </p>
      ) : null}
    </section>
  );
}

export default CustomerOnboardingVideo;
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
