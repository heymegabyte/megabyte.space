import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { humanizeStatus } from '@theme.tools/scheduling/field-service/booking-status';

/**
 * Customer-facing follow-up conversation panel — renders at `/me/followups`.
 * Shows every outbound BCL follow-up SMS this customer has received, plus
 * their classified replies. Pulls from `/api/auth/client/followups` (session-
 * authed by `bcl_cust_sid`). When no session is present, prompts to log in.
 *
 * No write surface — the conversation evolves via SMS only. This is a
 * read-only history so the customer can scroll back and re-tap a scheduling
 * link or rebook CTA.
 */

const TITLE = 'My follow-ups — Brick Labor';
const DESC = 'Read every check-in BCL has sent and your replies. Rebook a Newark crew in one tap.';

type FollowupKind =
  | 'satisfaction_2h'
  | 'rebook_3mo'
  | 'rebook_6mo'
  | 'rebook_9mo'
  | 'rebook_12mo'
  | 'birthday'
  | 'seasonal';

type ReplyIntent = 'yes' | 'no' | 'maybe' | 'spam' | 'unknown';

interface QueueRow {
  id: string;
  kind: FollowupKind;
  scheduled_at: number;
  status: 'pending' | 'sent' | 'replied' | 'skipped' | 'failed';
  sent_at: string | null;
  reply_text: string | null;
  reply_classified: ReplyIntent | null;
  created_at: string;
  body?: string;
}

interface ResponseRow {
  id: string;
  queue_id: string;
  raw_body: string;
  intent: string | null;
  action_taken: string | null;
  created_at: string;
}

interface Payload {
  authenticated: boolean;
  contact?: string;
  queue: QueueRow[];
  responses: ResponseRow[];
}

const KIND_LABEL: Record<FollowupKind, string> = {
  satisfaction_2h: '2-hour check-in',
  rebook_3mo: '3-month check-in',
  rebook_6mo: '6-month check-in',
  rebook_9mo: '9-month check-in',
  rebook_12mo: 'Anniversary check-in',
  birthday: 'Birthday note',
  seasonal: 'Seasonal reminder',
};

function formatTs(ts: string | null): string {
  if (!ts) return '—';
  const d = new Date(ts);
  if (Number.isNaN(d.getTime())) return ts;
  return d.toLocaleString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  });
}

function intentBadge(intent: ReplyIntent | null): string {
  switch (intent) {
    case 'yes':
      return 'bg-emerald-500/20 text-emerald-200 border-emerald-500/40';
    case 'no':
      return 'bg-rose-500/20 text-rose-200 border-rose-500/40';
    case 'maybe':
      return 'bg-amber-500/20 text-amber-200 border-amber-500/40';
    case 'spam':
      return 'bg-zinc-500/20 text-zinc-300 border-zinc-500/40';
    default:
      return 'bg-brand-card text-brand-mute border-brand-line';
  }
}

export function FollowupChat() {
  useThemeToolsSurface('followup-chat');
  const [payload, setPayload] = useState<Payload | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/auth/client/followups', { credentials: 'same-origin' });
      if (res.status === 401) {
        window.location.href = '/login?next=%2Fme%2Ffollowups';
        return;
      }
      if (!res.ok) {
        setError("Couldn't load your follow-ups. Try again.");
        return;
      }
      const data = (await res.json()) as Payload;
      setPayload(data);
    } catch {
      setError('Network glitch. Try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    document.title = TITLE;
    const meta = document.querySelector('meta[name="description"]');
    if (meta) meta.setAttribute('content', DESC);
    refresh();
  }, [refresh]);

  const responsesByQueueId = useMemo(() => {
    const map = new Map<string, ResponseRow[]>();
    for (const r of payload?.responses ?? []) {
      const list = map.get(r.queue_id) ?? [];
      list.push(r);
      map.set(r.queue_id, list);
    }
    return map;
  }, [payload]);

  if (loading) {
    return (
      <article className="section">
        <div className="container-pad max-w-3xl">
          <p className="text-brand-mute">Loading your follow-ups…</p>
        </div>
      </article>
    );
  }

  if (error) {
    return (
      <article className="section">
        <div className="container-pad max-w-3xl">
          <p className="text-brand-mute">{error}</p>
          <button type="button" onClick={() => void refresh()} className="btn-primary mt-4">
            Retry
          </button>
        </div>
      </article>
    );
  }

  if (!payload?.authenticated) {
    return (
      <article className="section">
        <div className="container-pad max-w-3xl">
          <p className="text-brand-mute">
            Not signed in.{' '}
            <a href="/login?next=%2Fme%2Ffollowups" className="text-brand-accent underline-hover">
              Log in to see your follow-ups →
            </a>
          </p>
        </div>
      </article>
    );
  }

  const { queue, contact } = payload;

  if (queue.length === 0) {
    return (
      <article className="section">
        <div className="container-pad max-w-3xl space-y-6">
          <header>
            <p className="eyebrow mb-2">Follow-ups</p>
            <h1 className="text-4xl sm:text-5xl font-extrabold mb-1">No check-ins yet</h1>
            <p className="text-brand-mute">
              After your next paid job, we'll send a short SMS to confirm the crew did right by you.
            </p>
          </header>
          <a href="/book" className="btn-primary inline-block">
            Book a crew →
          </a>
        </div>
      </article>
    );
  }

  return (
    <article className="section">
      <div className="container-pad max-w-3xl space-y-8">
        <header className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <p className="eyebrow mb-2">Follow-ups</p>
            <h1 className="text-4xl sm:text-5xl font-extrabold mb-1">Your BCL conversation</h1>
            <p className="text-brand-mute">
              Every check-in we've sent{' '}
              {contact ? (
                <>
                  to <strong className="text-brand-ink">{contact}</strong>
                </>
              ) : null}{' '}
              — plus your replies.
            </p>
          </div>
          <a href="/me" className="text-brand-mute hover:text-brand-ink underline-hover text-sm">
            ← Back to account
          </a>
        </header>

        <ol className="space-y-5">
          {queue.map((row) => {
            const replies = responsesByQueueId.get(row.id) ?? [];
            return (
              <li
                key={row.id}
                className="rounded-2xl border border-brand-line bg-brand-card p-5 space-y-3"
              >
                <div className="flex items-center justify-between gap-3 flex-wrap">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs uppercase tracking-wider text-brand-mute">
                      {KIND_LABEL[row.kind] ?? row.kind}
                    </span>
                    <span
                      className={`text-[10px] uppercase tracking-wider rounded-full border px-2 py-0.5 ${intentBadge(
                        row.reply_classified,
                      )}`}
                    >
                      {humanizeStatus(row.status)}
                    </span>
                  </div>
                  <time
                    className="text-xs text-brand-mute"
                    dateTime={row.sent_at ?? row.created_at}
                  >
                    {formatTs(row.sent_at ?? row.created_at)}
                  </time>
                </div>

                {row.body ? (
                  <p className="rounded-xl border border-brand-line bg-brand-bg/40 p-3 text-sm text-brand-ink">
                    {row.body}
                  </p>
                ) : null}

                {row.reply_text ? (
                  <div className="ml-6 space-y-2">
                    <p className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3 text-sm text-brand-ink">
                      <span className="text-xs uppercase tracking-wider text-emerald-200 mr-2">
                        You
                      </span>
                      {row.reply_text}
                    </p>
                    {replies.map((r) => (
                      <p key={r.id} className="text-xs text-brand-mute">
                        Classified:{' '}
                        <strong className="text-brand-ink">{r.intent ?? 'unknown'}</strong>
                        {r.action_taken ? <> · action: {r.action_taken}</> : null}
                      </p>
                    ))}
                  </div>
                ) : null}
              </li>
            );
          })}
        </ol>

        <footer className="rounded-2xl border border-brand-line bg-brand-card p-5 text-sm text-brand-mute">
          Want to rebook? Reply <strong className="text-brand-ink">Y</strong> to the most recent
          SMS, or{' '}
          <a href="/book" className="text-brand-accent underline-hover">
            book online
          </a>
          . Reply <strong className="text-brand-ink">STOP</strong> at any time to opt out.
        </footer>
      </div>
    </article>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
