import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useEffect, useState } from 'react';
import type { JobListItem } from '../../customer-jobs.js';

/**
 * §13c — compact 2-up before/after thumbnail pair embedded inside every job
 * row (both Upcoming and Past lists). Tapping any tile opens a lightweight
 * lightbox overlay scoped to the job's thumbs. When a kind is missing we
 * render a typographic placeholder rather than a gray box so the strip is
 * always exactly 2 cells wide (visual rhythm matches the rest of the row).
 *
 * Source of truth for URLs is `JobListItem.photoThumbs` (signed, 10-min TTL,
 * minted by the worker /api/customer/jobs endpoint). No N+1 fetch per row.
 */
interface JobThumbStripProps {
  readonly item: JobListItem;
  /** Layout — 'row' for past-jobs side strip, 'inline' for upcoming-row 2-up. */
  readonly variant?: 'row' | 'inline';
}

interface ThumbCell {
  readonly kind: 'before' | 'after';
  readonly url: string | null;
}

export function JobThumbStrip({ item, variant = 'inline' }: JobThumbStripProps): JSX.Element {
  useThemeToolsSurface('job-thumb-strip');
  const cells: ReadonlyArray<ThumbCell> = [
    { kind: 'before', url: item.photoThumbs?.before?.url ?? null },
    { kind: 'after', url: item.photoThumbs?.after?.url ?? null },
  ];
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  const hasAny = cells.some((c) => c.url);
  if (!hasAny) {
    // §13c — silent on upcoming jobs (photos arrive AFTER the gig). Past
    // jobs older than Wave 4D still show the legacy placeholder copy.
    if (variant === 'inline') return <></>;
    return (
      <div className="w-[96px] h-[96px] sm:w-[112px] sm:h-[112px] rounded-xl border border-dashed border-brand-line bg-brand-bg/40 flex items-center justify-center text-[10px] text-brand-mute leading-tight text-center px-2">
        Photos coming after the next job
      </div>
    );
  }

  if (variant === 'row') {
    return (
      <>
        <div
          aria-label={`Before and after thumbnails for job ${item.id.slice(0, 8)}`}
          className="w-[96px] h-[96px] sm:w-[112px] sm:h-[112px] rounded-xl overflow-hidden grid grid-cols-2 gap-px bg-brand-line"
        >
          {cells.map((c, i) => (
            <ThumbTile
              key={c.kind}
              cell={c}
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                if (c.url) setOpenIdx(i);
              }}
              compact
            />
          ))}
        </div>
        {openIdx !== null && (
          <ThumbLightbox
            cells={cells}
            index={openIdx}
            onClose={() => setOpenIdx(null)}
            onIndexChange={setOpenIdx}
            jobId={item.id}
          />
        )}
      </>
    );
  }

  return (
    <>
      <div
        aria-label={`Before and after thumbnails for job ${item.id.slice(0, 8)}`}
        className="grid grid-cols-2 gap-1 mt-3 max-w-[220px]"
      >
        {cells.map((c, i) => (
          <ThumbTile
            key={c.kind}
            cell={c}
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              if (c.url) setOpenIdx(i);
            }}
          />
        ))}
      </div>
      {openIdx !== null && (
        <ThumbLightbox
          cells={cells}
          index={openIdx}
          onClose={() => setOpenIdx(null)}
          onIndexChange={setOpenIdx}
          jobId={item.id}
        />
      )}
    </>
  );
}

interface ThumbTileProps {
  readonly cell: ThumbCell;
  readonly onClick: (e: React.MouseEvent) => void;
  readonly compact?: boolean;
}

function ThumbTile({ cell, onClick, compact }: ThumbTileProps): JSX.Element {
  if (!cell.url) {
    return (
      <div
        aria-hidden="true"
        className={`${
          compact ? '' : 'aspect-square'
        } rounded-md bg-brand-bg/40 border border-brand-line/60 flex items-center justify-center text-[9px] uppercase tracking-wider text-brand-mute`}
      >
        no {cell.kind}
      </div>
    );
  }
  return (
    <button
      type="button"
      onClick={onClick}
      data-zoomable="true"
      aria-label={`Open ${cell.kind} photo`}
      className={`${
        compact ? '' : 'aspect-square'
      } relative rounded-md overflow-hidden border border-brand-line bg-brand-card focus:outline-none focus:ring-2 focus:ring-brand-accent group`}
    >
      <img
        src={cell.url}
        alt={`${cell.kind} photo`}
        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
        loading="lazy"
      />
      <span className="absolute top-1 left-1 rounded-full bg-black/60 backdrop-blur-sm px-1.5 py-0.5 text-[8px] font-semibold uppercase tracking-wider text-white">
        {cell.kind}
      </span>
    </button>
  );
}

interface ThumbLightboxProps {
  readonly cells: ReadonlyArray<ThumbCell>;
  readonly index: number;
  readonly onClose: () => void;
  readonly onIndexChange: (i: number) => void;
  readonly jobId: string;
}

function ThumbLightbox({
  cells,
  index,
  onClose,
  onIndexChange,
  jobId,
}: ThumbLightboxProps): JSX.Element | null {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      else if (e.key === 'ArrowRight') {
        const next = (index + 1) % cells.length;
        if (cells[next]?.url) onIndexChange(next);
      } else if (e.key === 'ArrowLeft') {
        const prev = (index - 1 + cells.length) % cells.length;
        if (cells[prev]?.url) onIndexChange(prev);
      }
    };
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [index, cells, onClose, onIndexChange]);

  const cell = cells[index];
  if (!cell?.url) return null;
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={`${cell.kind} photo for job ${jobId.slice(0, 8)}`}
      onClick={onClose}
      className="fixed inset-0 z-[70] bg-black/95 flex items-center justify-center p-4"
    >
      <button
        type="button"
        onClick={onClose}
        aria-label="Close photo"
        className="absolute top-3 right-3 rounded-full bg-white/10 hover:bg-white/20 text-white w-10 h-10 flex items-center justify-center text-2xl"
      >
        ×
      </button>
      <div className="max-w-5xl w-full" onClick={(e) => e.stopPropagation()}>
        <img
          src={cell.url}
          alt={`${cell.kind} photo`}
          className="w-full max-h-[80vh] object-contain rounded-xl"
        />
        <p className="mt-3 text-white text-xs uppercase tracking-wider text-brand-accent text-center">
          {cell.kind} · job {jobId.slice(0, 8)}
        </p>
      </div>
    </div>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
