import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useMemo, useState } from 'react';

/**
 * /me/loyalty — tier + points dashboard for the signed-in customer.
 *
 * Fetches `/api/loyalty/me` (cookie auth on `bcl_cust_sid`). Renders:
 *   • Tier badge with next-tier delta bar
 *   • Points balance + perk catalog filtered to caller's tier
 *   • Redemption history
 *
 * Cookie-auth only — if /me returns 401, redirects to /login same as
 * `MePage.tsx`. No external state libs; all data is fetched + held in this
 * component.
 */

const TITLE = 'Loyalty — Brick Labor';
const DESC =
  'Earn points on every job. Reach silver at $500, gold at $2000. Unlock free hours, priority scheduling, and VIP same-day.';

type LoyaltyTier = 'bronze' | 'silver' | 'gold';

interface Perk {
  id: string;
  tier: LoyaltyTier;
  pointsCost: number;
  label: string;
  description: string;
}

interface Redemption {
  id: string;
  action: string;
  detail: string;
  created_at: string;
}

interface LoyaltyPayload {
  authenticated: boolean;
  phone?: string;
  tier: LoyaltyTier;
  lifetimeCents: number;
  jobsCompleted: number;
  points: number;
  discountPct: number;
  centsToNext: number | null;
  perks: Perk[];
  redemptions: Redemption[];
}

const TIER_LABELS: Record<LoyaltyTier, { color: string; text: string }> = {
  bronze: { color: 'border-amber-700 bg-amber-900/30 text-amber-200', text: 'Bronze' },
  silver: { color: 'border-zinc-400 bg-zinc-700/30 text-zinc-100', text: 'Silver' },
  gold: { color: 'border-yellow-400 bg-yellow-700/30 text-yellow-100', text: 'Gold' },
};

function dollars(cents: number): string {
  return `$${(cents / 100).toFixed(0)}`;
}

export function LoyaltyDashboard() {
  useThemeToolsSurface('loyalty-dashboard');
  const [payload, setPayload] = useState<LoyaltyPayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [redeeming, setRedeeming] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  // Signed in but no loyalty row yet (404 no_account) — NOT the same as
  // unauthenticated. Render a friendly "start earning" empty state.
  const [noAccount, setNoAccount] = useState(false);

  const refresh = useCallback(async () => {
    setLoading(true);
    setError(null);
    setNoAccount(false);
    try {
      const res = await fetch('/api/loyalty/me', { credentials: 'same-origin' });
      if (res.status === 401) {
        window.location.href = '/login?next=%2Fme%2Floyalty';
        return;
      }
      if (res.status === 404) {
        // signed in, no points yet
        setNoAccount(true);
        setPayload(null);
        return;
      }
      if (!res.ok) {
        setError('Could not load your loyalty status. Try again.');
        return;
      }
      const data = (await res.json()) as LoyaltyPayload;
      // Defensive: a payload without a tier is not renderable — treat as "no row".
      if (!data || !data.tier) {
        setNoAccount(true);
        setPayload(null);
        return;
      }
      setPayload(data);
    } catch {
      setError('Could not load your loyalty status. Try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    document.title = TITLE;
    const meta = document.querySelector('meta[name="description"]');
    if (meta) meta.setAttribute('content', DESC);
    refresh();
  }, [refresh]);

  const onRedeem = useCallback(
    async (perk: Perk) => {
      setRedeeming(perk.id);
      setError(null);
      try {
        const clientToken = `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
        const res = await fetch('/api/loyalty/redeem', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ perkId: perk.id, clientToken }),
        });
        const data = (await res.json()) as { ok?: boolean; error?: string };
        if (!data.ok) {
          setError(data.error ?? 'Redemption failed. Try again.');
          return;
        }
        await refresh();
      } catch {
        setError('Network error. Try again.');
      } finally {
        setRedeeming(null);
      }
    },
    [refresh],
  );

  const progress = useMemo(() => {
    if (!payload || payload.centsToNext == null) return null;
    const tierTargets: Record<LoyaltyTier, number> = { bronze: 50000, silver: 200000, gold: 0 };
    const target = tierTargets[payload.tier] || 50000;
    const done = Math.max(0, target - payload.centsToNext);
    return Math.min(100, Math.round((done / target) * 100));
  }, [payload]);

  if (loading) {
    return (
      <article className="section">
        <div className="container-pad max-w-4xl">
          <p className="text-brand-mute">Loading your loyalty status…</p>
        </div>
      </article>
    );
  }

  if (error) {
    return (
      <article className="section">
        <div className="container-pad max-w-4xl">
          <p className="rounded-md border border-rose-900/40 bg-rose-900/20 px-3 py-2 text-sm text-rose-200">
            {error}{' '}
            <button type="button" onClick={() => void refresh()} className="underline font-semibold">
              Retry
            </button>
          </p>
        </div>
      </article>
    );
  }

  if (noAccount) {
    return (
      <article className="section" data-testid="loyalty-empty">
        <div className="container-pad max-w-4xl">
          <header className="space-y-2">
            <h1 className="text-3xl font-bold">Start earning</h1>
            <p className="text-brand-mute">
              Every completed job earns 1 point per dollar. Reach silver at $500 for 5% off, gold
              at $2000 for 10% off — plus free hours and priority scheduling.
            </p>
          </header>
          <a href="/book" className="btn-primary mt-4 inline-flex h-10 items-center px-5">
            Book your first job →
          </a>
        </div>
      </article>
    );
  }

  if (!payload?.authenticated) {
    return (
      <article className="section">
        <div className="container-pad max-w-4xl">
          <p className="text-brand-mute">
            Not signed in.{' '}
            <a href="/login?next=%2Fme%2Floyalty" className="text-brand-accent underline">
              Log in →
            </a>
          </p>
        </div>
      </article>
    );
  }

  const badge = TIER_LABELS[payload.tier];

  return (
    <article className="section">
      <div className="container-pad max-w-4xl space-y-8">
        <header className="space-y-3">
          <h1 className="text-3xl font-bold">Your loyalty</h1>
          <p className="text-brand-mute">
            Every completed job earns 1 point per dollar. Reach silver at $500 spend for 5% off,
            gold at $2000 for 10% off.
          </p>
        </header>

        <section className={`rounded-2xl border p-6 ${badge.color}`}>
          <div className="flex flex-wrap items-center gap-6">
            <div>
              <p className="text-xs uppercase tracking-wider opacity-80">Current tier</p>
              <p className="text-3xl font-bold">{badge.text}</p>
            </div>
            <div className="grid grid-cols-3 gap-6 text-sm">
              <div>
                <p className="opacity-80">Points</p>
                <p className="text-xl font-semibold">{payload.points}</p>
              </div>
              <div>
                <p className="opacity-80">Lifetime spend</p>
                <p className="text-xl font-semibold">{dollars(payload.lifetimeCents)}</p>
              </div>
              <div>
                <p className="opacity-80">Jobs done</p>
                <p className="text-xl font-semibold">{payload.jobsCompleted}</p>
              </div>
            </div>
          </div>
          {progress != null && payload.centsToNext != null && payload.centsToNext > 0 && (
            <div className="mt-4">
              <p className="text-xs opacity-80">
                {dollars(payload.centsToNext)} until {payload.tier === 'bronze' ? 'Silver' : 'Gold'}
              </p>
              <div className="mt-1 h-2 w-full rounded-full bg-black/40">
                <div className="h-2 rounded-full bg-white/70" style={{ width: `${progress}%` }} />
              </div>
            </div>
          )}
          {payload.centsToNext == null && (
            <p className="mt-4 text-sm">Max tier — VIP perks unlocked.</p>
          )}
        </section>

        <section>
          <h2 className="text-xl font-bold">Perks</h2>
          <ul className="mt-3 grid gap-3">
            {payload.perks.length === 0 && (
              <li className="text-brand-mute text-sm">
                No perks yet. Book your first job to start earning.
              </li>
            )}
            {payload.perks.map((perk) => (
              <li
                key={perk.id}
                className="border-brand-line bg-brand-card flex flex-wrap items-center gap-4 rounded-xl border p-4"
              >
                <div className="flex-1 min-w-0">
                  <p className="font-semibold">{perk.label}</p>
                  <p className="text-brand-mute text-sm">{perk.description}</p>
                </div>
                <div className="text-brand-mute text-sm">{perk.pointsCost} pts</div>
                <button
                  type="button"
                  className="bg-brand-accent rounded-lg px-4 py-2 text-sm font-semibold text-black disabled:cursor-not-allowed disabled:opacity-40"
                  disabled={redeeming === perk.id || payload.points < perk.pointsCost}
                  onClick={() => onRedeem(perk)}
                >
                  {redeeming === perk.id ? 'Redeeming…' : 'Redeem'}
                </button>
              </li>
            ))}
          </ul>
          {error && <p className="mt-3 text-sm text-red-300" role="alert">{error}</p>}
        </section>

        <section>
          <h2 className="text-xl font-bold">History</h2>
          {payload.redemptions.length === 0 ? (
            <p className="text-brand-mute mt-2 text-sm">No redemptions yet.</p>
          ) : (
            <ul className="mt-2 space-y-2 text-sm">
              {payload.redemptions.map((r) => (
                <li
                  key={r.id}
                  className="border-brand-line flex items-center justify-between border-b py-2"
                >
                  <span>{r.action}</span>
                  <time className="text-brand-mute">
                    {new Date(r.created_at).toLocaleDateString()}
                  </time>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </article>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
