import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useMemo, useState } from 'react';

/**
 * MyAiRules (customer) — Wave 16 /me/rules card.
 *
 * Customer-facing version of the worker rules card. A signed-in customer can
 * add rules that travel with every booking under their phone (or email
 * contact): "Pet-friendly crew only", "Make sure the crew texts when they
 * finish". The matcher reads these alongside worker self-rules and admin
 * overrides when picking a crew.
 *
 * Mounted by the integrator at /me/rules — this file does NOT touch
 * `MePage.tsx` or `App.tsx`.
 */

type RuleKind = 'preference' | 'soft_rule' | 'hard_rule';

interface Rule {
  id: string;
  scope: 'customer' | 'admin_for_customer';
  subjectId: string;
  authorRole: 'customer' | 'admin';
  text: string;
  kind: RuleKind;
  priority: number;
  createdAt: number;
  lastAppliedAt: number | null;
  appliedCount: number;
}

interface ApiList {
  ok: boolean;
  rules?: Rule[];
  error?: string;
}

interface ApiCreate {
  ok: boolean;
  id?: string;
  error?: string;
}

const KIND_LABELS: Record<RuleKind, { title: string; helper: string }> = {
  preference: { title: 'Nice to have', helper: 'A polite ask — we try to honor it.' },
  soft_rule: { title: 'Strong preference', helper: 'We work hard to match this.' },
  hard_rule: { title: 'Must-have', helper: 'Crews that fail this are skipped.' },
};

export default function MyAiRules() {
  useThemeToolsSurface('my-ai-rules');
  const [rules, setRules] = useState<Rule[]>([]);
  const [text, setText] = useState('');
  const [kind, setKind] = useState<RuleKind>('preference');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setError('');
    try {
      const res = await fetch('/api/customer/rules', {
        headers: { Accept: 'application/json' },
      });
      const data = (await res.json()) as ApiList;
      if (!res.ok || !data.ok) {
        setError(data.error ?? `Couldn't load rules (${res.status}).`);
        return;
      }
      setRules(data.rules ?? []);
    } catch {
      setError('Connection issue. Try refreshing.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const submit = useCallback(
    async (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      const trimmed = text.trim();
      if (trimmed.length < 4) {
        setError('Tell us a bit more — a full sentence works best.');
        return;
      }
      setBusy(true);
      setError('');
      try {
        const res = await fetch('/api/customer/rules', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: trimmed, kind }),
        });
        const data = (await res.json()) as ApiCreate;
        if (!res.ok || !data.ok) {
          setError(data.error ?? `Save failed (${res.status}).`);
          return;
        }
        setText('');
        setKind('preference');
        await load();
      } catch {
        setError('Connection issue. Try again.');
      } finally {
        setBusy(false);
      }
    },
    [text, kind, load],
  );

  const remove = useCallback(
    async (id: string) => {
      setBusy(true);
      setError('');
      try {
        const res = await fetch(`/api/customer/rules/${encodeURIComponent(id)}`, {
          method: 'DELETE',
        });
        if (!res.ok) {
          setError(`Delete failed (${res.status}).`);
          return;
        }
        await load();
      } catch {
        setError('Connection issue. Try again.');
      } finally {
        setBusy(false);
      }
    },
    [load],
  );

  const totalApplied = useMemo(() => rules.reduce((sum, r) => sum + r.appliedCount, 0), [rules]);

  return (
    <section
      aria-labelledby="customer-rules-heading"
      data-bcl-component="customer-rules"
      className="rounded-2xl border border-brand-line bg-brand-card p-5 space-y-4"
    >
      <header className="flex items-start justify-between gap-3">
        <div>
          <h3 id="customer-rules-heading" className="text-lg font-bold text-brand-ink">
            Crew preferences
          </h3>
          <p className="text-sm text-brand-mute">
            What should every Brick Labor crew know before showing up? We bake it into every match.
          </p>
        </div>
        <div className="text-right text-xs text-brand-mute" aria-live="polite">
          <div>
            <span className="font-bold text-brand-ink">{totalApplied}</span> matches
          </div>
          <div>used your prefs</div>
        </div>
      </header>

      <form onSubmit={submit} className="space-y-3" aria-busy={busy}>
        <label htmlFor="cust-rule-text" className="block text-sm font-bold text-brand-ink">
          New preference
        </label>
        <textarea
          id="cust-rule-text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={2}
          maxLength={800}
          placeholder='e.g. "Make sure the crew texts me when they finish each room."'
          className="w-full rounded-xl border border-brand-line bg-brand-bg p-3 text-sm text-brand-ink placeholder:text-brand-mute focus:outline-none focus:ring-2 focus:ring-brand-accent"
        />
        <fieldset className="flex flex-wrap gap-2">
          <legend className="sr-only">How strict?</legend>
          {(Object.keys(KIND_LABELS) as RuleKind[]).map((k) => (
            <label
              key={k}
              className={`cursor-pointer rounded-xl border px-3 py-2 text-xs focus-within:ring-2 focus-within:ring-brand-accent focus-within:ring-offset-2 focus-within:ring-offset-bg-primary ${
                kind === k
                  ? 'border-brand-accent bg-brand-accent/10 text-brand-ink'
                  : 'border-brand-line text-brand-mute hover:text-brand-ink'
              }`}
            >
              <input
                type="radio"
                name="kind"
                value={k}
                checked={kind === k}
                onChange={() => setKind(k)}
                className="sr-only"
              />
              <span className="font-bold">{KIND_LABELS[k].title}</span>
              <span className="block text-[11px] opacity-75">{KIND_LABELS[k].helper}</span>
            </label>
          ))}
        </fieldset>
        <div className="flex items-center justify-between gap-3">
          <p className="text-xs text-brand-mute">
            Honest, specific notes work best. We can't honor preferences that target a worker by
            race, religion, gender, or other protected class.
          </p>
          <button
            type="submit"
            disabled={busy || text.trim().length < 4}
            className="rounded-xl bg-brand-accent px-4 py-2 text-sm font-bold text-brand-bg disabled:opacity-50"
          >
            {busy ? 'Saving…' : 'Save preference'}
          </button>
        </div>
        {error && (
          <p role="alert" className="text-sm text-red-300">
            {error}
          </p>
        )}
      </form>

      <div className="space-y-2">
        <h4 className="text-sm font-bold text-brand-ink">Your preferences ({rules.length})</h4>
        {loading && <p className="text-sm text-brand-mute">Loading…</p>}
        {!loading && rules.length === 0 && (
          <p className="text-sm text-brand-mute">
            No preferences saved yet. Add one above and we'll factor it into every match.
          </p>
        )}
        <ul className="space-y-2">
          {rules.map((r) => (
            <li
              key={r.id}
              className="flex items-start justify-between gap-3 rounded-xl border border-brand-line bg-brand-bg p-3"
            >
              <div className="space-y-1">
                <p className="text-sm text-brand-ink">{r.text}</p>
                <p className="text-[11px] text-brand-mute">
                  <span className="font-bold text-brand-ink">{KIND_LABELS[r.kind].title}</span>
                  {' · '}
                  {r.authorRole === 'admin' ? 'set by Brick Labor' : 'set by you'}
                  {' · used '}
                  {r.appliedCount} time{r.appliedCount === 1 ? '' : 's'}
                </p>
              </div>
              {r.authorRole === 'customer' && (
                <button
                  type="button"
                  onClick={() => void remove(r.id)}
                  disabled={busy}
                  className="rounded-xl border border-brand-line bg-transparent px-2 py-1 text-xs text-brand-mute hover:text-red-300"
                  aria-label={`Delete preference: ${r.text.slice(0, 80)}`}
                >
                  Delete
                </button>
              )}
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
