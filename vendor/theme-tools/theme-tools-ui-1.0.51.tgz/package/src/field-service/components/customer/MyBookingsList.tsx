import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { useMemo, useState } from 'react';
import {
  formatJobDate,
  formatMoney,
  paymentStatusBadgeClass,
  paymentStatusLabel,
} from '../../customer-jobs.js';
import type { JobListItem } from '../../customer-jobs.js';
import { RebookButton } from './RebookButton.js';
import { JobThumbStrip } from './JobThumbStrip.js';

interface MyBookingsListProps {
  items: ReadonlyArray<JobListItem>;
  loading?: boolean;
  onOpenDetail: (bookingId: string) => void;
}

const PAST_STATUSES = new Set(['completed', 'review_requested', 'canceled']);

/**
 * Grid of past jobs — ordered by date desc, each row a card with photo strip
 * (real before/after thumbs from `JobListItem.photoThumbs`), service, crew
 * size, total, status badge, and a tap target opening `MyJobDetail`.
 *
 * §13b — also includes "defunct" rows (past-dated, never-paid). The API
 * derives `paymentStatus: 'defunct'` server-side so the same client filter
 * works without re-implementing the date math here.
 * §13c — thumbnails are real, signed, and clickable (lightbox).
 */
export function MyBookingsList({ items, loading, onOpenDetail }: MyBookingsListProps) {
  useThemeToolsSurface('my-bookings-list');
  const [query, setQuery] = useState('');
  const past = useMemo(() => {
    const filtered = items.filter(
      (i) => PAST_STATUSES.has(i.status) || i.paymentStatus === 'defunct',
    );
    const q = query.trim().toLowerCase();
    if (!q) return filtered;
    return filtered.filter((b) =>
      [b.service, b.address, b.id, b.status, b.city].some((v) =>
        String(v ?? '')
          .toLowerCase()
          .includes(q),
      ),
    );
  }, [items, query]);

  if (loading && past.length === 0) {
    return <p className="text-brand-mute text-sm">Loading past jobs…</p>;
  }

  return (
    <section>
      <div className="flex items-end justify-between gap-3 mb-4 flex-wrap">
        <h2 className="text-2xl font-extrabold">Past jobs</h2>
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search service, address, id…"
          aria-label="Search past jobs"
          className="rounded-md border border-brand-line bg-brand-card px-3 py-2 text-sm text-brand-ink placeholder:text-brand-mute focus:outline-none focus:border-brand-accent"
        />
      </div>

      {past.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-brand-line bg-brand-card p-8 text-center text-brand-mute">
          {query
            ? 'Nothing matches that search. Clear to see everything.'
            : 'No past jobs yet — book your first crew to start a history.'}
        </div>
      ) : (
        <ul className="space-y-3" aria-label="Past jobs">
          {past.map((b) => (
            <PastJobCard key={b.id} item={b} onOpen={() => onOpenDetail(b.id)} />
          ))}
        </ul>
      )}
    </section>
  );
}

function PastJobCard({ item, onOpen }: { item: JobListItem; onOpen: () => void }) {
  const totalPhotos = item.photoCount.before + item.photoCount.after;

  return (
    <li
      data-booking-id={item.id}
      className="rounded-2xl border border-brand-line bg-brand-card p-5 hover:border-brand-accent/60 transition"
    >
      <div className="grid grid-cols-[auto_1fr_auto] sm:grid-cols-[112px_1fr_auto] gap-4 items-start">
        <JobThumbStrip item={item} variant="row" />
        <div className="min-w-0">
          <div className="flex flex-wrap items-start justify-between gap-3 mb-2">
            <div>
              <h3 className="text-lg font-bold capitalize">
                {(item.service || 'crew').replace(/-/g, ' ')}
              </h3>
              <p className="text-sm text-brand-mute">
                {formatJobDate(item.preferredDate)} · {item.crew} crew · {item.hours}h
              </p>
              {item.address && (
                <p className="text-xs text-brand-mute truncate mt-1" title={item.address}>
                  {item.address}
                </p>
              )}
            </div>
            <span
              className={`inline-block rounded-full border px-3 py-1 text-xs font-semibold uppercase tracking-wide ${paymentStatusBadgeClass(
                item.paymentStatus,
              )}`}
            >
              {paymentStatusLabel(item.paymentStatus)}
            </span>
          </div>
          <div className="flex flex-wrap items-center justify-between gap-3 mt-3">
            <div className="text-sm">
              <span className="text-brand-mute">Total</span>{' '}
              <strong className="text-brand-ink">{formatMoney(item.totalCents)}</strong>
              {totalPhotos > 0 && (
                <span className="text-brand-mute ml-3">
                  · {totalPhotos} photo{totalPhotos === 1 ? '' : 's'}
                </span>
              )}
              {item.hasRecap && <span className="text-brand-mute ml-3">· PDF recap</span>}
            </div>
            <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
              <RebookButton
                bookingId={item.id}
                variant="ghost"
                label="Rebook"
                source="past_jobs_card"
                scope={{
                  service: item.service,
                  crew: item.crew,
                  hours: item.hours,
                  address: item.address,
                }}
              />
              <button
                type="button"
                onClick={onOpen}
                aria-label={`Open job ${item.id.slice(0, 8)}`}
                className="rounded-md border border-brand-line px-3 py-1.5 text-xs text-brand-ink hover:border-brand-accent underline-hover"
              >
                Details →
              </button>
            </div>
          </div>
        </div>
        <div className="hidden sm:block" />
      </div>
    </li>
  );
}
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
