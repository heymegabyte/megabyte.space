import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useEffect, useMemo, useState } from 'react';
import {
  formatJobDate,
  formatMoney,
  paymentStatusBadgeClass,
  paymentStatusLabel,
  useJobDetail,
  useJobPhotos,
} from '../../customer-jobs.js';
import type { JobPhoto } from '../../customer-jobs.js';
import { RebookButton } from './RebookButton.js';
import { EscrowStatus } from '../escrow/EscrowStatus.js';
import { RescheduleForm, type ReschedulePrefill } from '../booking/RescheduleForm.js';
import { FavoriteCrewPicker, type CrewMember } from './FavoriteCrewPicker.js';
import { NpsSurvey } from './NpsSurvey.js';
import JobPhotosReview from './JobPhotosReview.js';
import { AddToCalendarMenu } from './AddToCalendarMenu.js';
import CaseStudyCard from '../CaseStudyCard.js';
interface MyJobDetailProps {
  bookingId: string;
  onClose: () => void;
}

/**
 * Modal-style full detail view for a single past job. Contains hero collage
 * (before+after side-by-side), line-item breakdown (labor+rentals+surge+tip),
 * crew avatars w/ "Request again" button, 4+4 photo gallery with lightbox +
 * AI descriptions, payment status + receipt link, recap PDF download,
 * rebook CTA, dispute escalation link.
 *
 * Esc to close. Focus trapped inside while open. Scrollable.
 */
export function MyJobDetail({ bookingId, onClose }: MyJobDetailProps) {
  useThemeToolsSurface('my-job-detail');
  const { data: detail, loading: detailLoading } = useJobDetail(bookingId);
  const { data: photos } = useJobPhotos(bookingId);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (lightboxIndex !== null) setLightboxIndex(null);
        else onClose();
      }
    };
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [onClose, lightboxIndex]);

  const allPhotos = useMemo(() => photos?.items ?? [], [photos]);
  const beforePhotos = allPhotos.filter((p) => p.kind === 'before');
  const afterPhotos = allPhotos.filter((p) => p.kind === 'after');

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Job detail"
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="min-h-full flex items-start justify-center p-4 sm:p-8"
        onClick={(e) => e.stopPropagation()}
      >
        <article className="w-full max-w-4xl rounded-3xl border border-brand-line bg-brand-bg shadow-2xl">
          <header className="sticky top-0 z-10 flex items-center justify-between gap-3 px-6 py-4 border-b border-brand-line bg-brand-bg rounded-t-3xl">
            <div>
              <p className="eyebrow">Job detail</p>
              <h2 className="text-2xl font-extrabold">
                {detail?.booking
                  ? (detail.booking.services[0] || 'Crew').replace(/-/g, ' ')
                  : 'Loading…'}
              </h2>
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close detail"
              className="rounded-full border border-brand-line bg-brand-card w-9 h-9 flex items-center justify-center text-brand-ink hover:border-brand-accent"
            >
              ×
            </button>
          </header>

          {detailLoading && <p className="p-6 text-brand-mute">Loading job…</p>}

          {detail?.booking && (
            <div className="px-6 py-6 space-y-8">
              <HeaderRow booking={detail.booking} />
              <HeroCollage before={beforePhotos[0]} after={afterPhotos[0]} bookingId={bookingId} />
              <CrewFavorites crew={detail.booking.crewMembers} bookingId={bookingId} />
              <PricingBreakdown pricing={detail.booking.pricing} />
              <EscrowStatus bookingId={bookingId} />
              <PhotoGallery photos={allPhotos} onOpenLightbox={(i) => setLightboxIndex(i)} />
              <JobPhotosReview bookingId={bookingId} />
              {/* Case study PDF download — flag-gated (case_study_pdf); renders null when off. */}
              <CaseStudyCard
                bookingId={bookingId}
                jobType={detail.booking.services[0]}
                jobDate={detail.booking.preferredDate}
              />
              {detail.booking.status === 'completed' && <NpsSurvey bookingId={bookingId} />}
              <ActionRow detail={detail.booking} bookingId={bookingId} />
            </div>
          )}
        </article>
      </div>

      {lightboxIndex !== null && allPhotos[lightboxIndex] && (
        <PhotoLightbox
          photos={allPhotos}
          index={lightboxIndex}
          onClose={() => setLightboxIndex(null)}
          onIndexChange={setLightboxIndex}
        />
      )}
    </div>
  );
}

function HeaderRow({
  booking,
}: {
  booking: NonNullable<ReturnType<typeof useJobDetail>['data']>['booking'];
}) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
      <Stat label="Date" value={formatJobDate(booking.preferredDate)} />
      <Stat label="Crew" value={`${booking.crew} people`} />
      <Stat label="Hours" value={String(booking.hours)} />
      <Stat
        label="Status"
        value={paymentStatusLabel(booking.paymentStatus)}
        badgeClass={paymentStatusBadgeClass(booking.paymentStatus)}
      />
    </div>
  );
}

function Stat({ label, value, badgeClass }: { label: string; value: string; badgeClass?: string }) {
  return (
    <div className="rounded-xl border border-brand-line bg-brand-card p-3">
      <p className="text-[10px] uppercase tracking-wider text-brand-mute">{label}</p>
      {badgeClass ? (
        <p
          className={`inline-block rounded-full border px-2 py-0.5 text-xs font-semibold uppercase tracking-wide mt-1 ${badgeClass}`}
        >
          {value}
        </p>
      ) : (
        <p className="text-base font-extrabold text-brand-ink">{value}</p>
      )}
    </div>
  );
}

function HeroCollage({
  before,
  after,
  bookingId,
}: {
  before: JobPhoto | undefined;
  after: JobPhoto | undefined;
  bookingId: string;
}) {
  if (!before && !after) {
    return (
      <div className="rounded-2xl border border-dashed border-brand-line bg-brand-card p-10 text-center text-brand-mute text-sm">
        Photos coming after the next job. Crews snap 4 before + 4 after on every gig.
      </div>
    );
  }
  return (
    <div
      aria-label="Before and after collage"
      className="grid grid-cols-1 sm:grid-cols-2 gap-3 rounded-2xl overflow-hidden border border-brand-line"
    >
      <CollageTile photo={before} fallbackLabel="Before" position="left" bookingId={bookingId} />
      <CollageTile photo={after} fallbackLabel="After" position="right" bookingId={bookingId} />
    </div>
  );
}

function CollageTile({
  photo,
  fallbackLabel,
  position,
  bookingId: _bookingId,
}: {
  photo: JobPhoto | undefined;
  fallbackLabel: string;
  position: 'left' | 'right';
  bookingId: string;
}) {
  return (
    <div className="relative aspect-[4/3] bg-brand-bg">
      {photo ? (
        <img
          src={photo.url}
          alt={photo.aiDescription ?? photo.caption ?? `${fallbackLabel} photo`}
          className="w-full h-full object-cover"
          loading="lazy"
        />
      ) : (
        <div className="w-full h-full flex items-center justify-center text-brand-mute text-xs">
          No {fallbackLabel.toLowerCase()} photo yet
        </div>
      )}
      <span
        className={`absolute top-2 ${
          position === 'left' ? 'left-2' : 'right-2'
        } rounded-full bg-black/60 backdrop-blur-sm px-3 py-1 text-[10px] font-semibold uppercase tracking-wider text-white`}
      >
        {fallbackLabel}
      </span>
    </div>
  );
}

/**
 * "Your crew" roster with working tap-to-favorite hearts. Replaces the old
 * CrewStrip + RequestAgainButton (which posted to a 404 stub
 * /api/claims-board/preferences → "Coming soon"). FavoriteCrewPicker is backed
 * by the real /api/loyalty/favorites endpoint; we just map the booking's crew
 * shape to its CrewMember contract.
 */
function CrewFavorites({
  crew,
  bookingId,
}: {
  crew: NonNullable<ReturnType<typeof useJobDetail>['data']>['booking']['crewMembers'];
  bookingId: string;
}) {
  const members: CrewMember[] = crew.map((m) => ({
    userId: m.workerId,
    displayName: `${m.firstName} ${m.lastInitial}.`,
    photoUrl: m.avatarUrl ?? undefined,
  }));
  return (
    <section>
      <h3 className="text-xl font-extrabold mb-3">Your crew</h3>
      <FavoriteCrewPicker bookingId={bookingId} crew={members} />
    </section>
  );
}

/**
 * In-app reschedule: mints an ownership-scoped token via
 * POST /api/booking-reschedule/:id/token, then reveals the RescheduleForm
 * inline. The server is the source of truth — a non-reschedulable job (409) or
 * a non-owned one (404) degrades to a friendly message, never an error.
 */
function RescheduleButton({ bookingId }: { bookingId: string }) {
  const [pending, setPending] = useState(false);
  const [prefill, setPrefill] = useState<ReschedulePrefill | null>(null);
  const [note, setNote] = useState<string | null>(null);

  const begin = async () => {
    setPending(true);
    setNote(null);
    try {
      const res = await fetch(`/api/booking-reschedule/${encodeURIComponent(bookingId)}/token`, {
        method: 'POST',
        credentials: 'same-origin',
      });
      if (res.status === 409) {
        setNote("This job can't be rescheduled anymore — reach out and we'll help.");
        return;
      }
      if (!res.ok) {
        setNote('Could not start a reschedule just now. Try again.');
        return;
      }
      const data = (await res.json()) as {
        ok: boolean;
        token?: string;
        currentDate?: string;
        currentTime?: string;
      };
      if (!data.ok || !data.token) {
        setNote('Could not start a reschedule just now. Try again.');
        return;
      }
      setPrefill({
        bookingId,
        token: data.token,
        currentDate: data.currentDate,
        currentTime: data.currentTime,
      });
    } catch {
      setNote('Network hiccup. Try again.');
    } finally {
      setPending(false);
    }
  };

  if (prefill) {
    return (
      <div className="mt-3 w-full" data-testid="reschedule-inline">
        <RescheduleForm prefill={prefill} onSuccess={() => setPrefill(null)} />
      </div>
    );
  }

  return (
    <div className="w-full">
      <button
        type="button"
        onClick={begin}
        disabled={pending}
        data-testid="reschedule-start"
        className="rounded-md border border-brand-line bg-brand-card px-4 py-2 text-sm font-semibold text-brand-ink hover:border-brand-accent underline-hover disabled:opacity-60"
      >
        {pending ? 'Opening…' : 'Reschedule'}
      </button>
      {note && (
        <p role="status" className="mt-1 text-xs text-amber-300/90">
          {note}
        </p>
      )}
    </div>
  );
}

function PricingBreakdown({
  pricing,
}: {
  pricing: NonNullable<ReturnType<typeof useJobDetail>['data']>['booking']['pricing'];
}) {
  const rows: Array<{
    label: string;
    value: number;
    sub?: string;
    surgeReasons?: string[];
    rentalLabels?: string[];
    extrasCsv?: string[];
  }> = [{ label: 'Labor', value: pricing.baseLaborCents }];
  if (pricing.rentalsCents > 0) {
    rows.push({
      label: 'Rentals',
      value: pricing.rentalsCents,
      rentalLabels: pricing.rentals.length > 0 ? pricing.rentals.map((r) => r.label) : undefined,
    });
  }
  if (pricing.extrasFlatCents > 0) {
    rows.push({
      label: 'Extras',
      value: pricing.extrasFlatCents,
      extrasCsv: pricing.extrasCsv.length > 0 ? pricing.extrasCsv : undefined,
    });
  }
  if (pricing.afterHoursCents > 0)
    rows.push({ label: 'After-hours / weekend', value: pricing.afterHoursCents });
  if (pricing.rushCents > 0) rows.push({ label: 'Same-day rush', value: pricing.rushCents });
  if (pricing.surgeCents > 0) {
    rows.push({
      label: `Surge × ${pricing.surgeMultiplier.toFixed(2)}`,
      value: pricing.surgeCents,
      surgeReasons: pricing.surgeReasons,
    });
  }
  if (pricing.tipCents > 0) rows.push({ label: 'Tip', value: pricing.tipCents });

  return (
    <section>
      <h3 className="text-xl font-extrabold mb-3">Pricing breakdown</h3>
      <div className="rounded-2xl border border-brand-line bg-brand-card overflow-hidden">
        {rows.map((r, i) => (
          <div
            key={r.label + i}
            className={`flex items-start justify-between gap-3 px-4 py-3 ${
              i > 0 ? 'border-t border-brand-line' : ''
            }`}
          >
            <div className="min-w-0">
              <p className="text-sm text-brand-ink">{r.label}</p>
              {r.sub && <p className="text-xs text-brand-mute mt-0.5">{r.sub}</p>}
              {r.surgeReasons && r.surgeReasons.length > 0 && (
                <ul
                  aria-label="Surge reasons"
                  className="flex flex-wrap gap-1.5 mt-1.5"
                  role="list"
                >
                  {r.surgeReasons.map((reason) => (
                    <li
                      key={reason}
                      className="rounded-full bg-brand-accent/10 border border-brand-accent/25 px-2.5 py-0.5 text-xs font-medium text-brand-accent transition-all duration-[333ms] hover:-translate-y-px hover:bg-brand-accent/20 hover:shadow-sm"
                    >
                      {reason}
                    </li>
                  ))}
                </ul>
              )}
              {r.rentalLabels && r.rentalLabels.length > 0 && (
                <ul aria-label="Rental items" className="flex flex-wrap gap-1.5 mt-1.5" role="list">
                  {r.rentalLabels.map((label) => (
                    <li
                      key={label}
                      className="rounded-full bg-brand-accent/10 border border-brand-accent/25 px-2.5 py-0.5 text-xs font-medium text-brand-accent transition-all duration-[333ms] hover:-translate-y-px hover:bg-brand-accent/20 hover:shadow-sm"
                    >
                      {label}
                    </li>
                  ))}
                </ul>
              )}
              {r.extrasCsv && r.extrasCsv.length > 0 && (
                <ul
                  aria-label="Extra services"
                  className="flex flex-wrap gap-1.5 mt-1.5"
                  role="list"
                >
                  {r.extrasCsv.map((extra) => (
                    <li
                      key={extra}
                      className="rounded-full bg-brand-accent/10 border border-brand-accent/25 px-2.5 py-0.5 text-xs font-medium text-brand-accent transition-all duration-[333ms] hover:-translate-y-px hover:bg-brand-accent/20 hover:shadow-sm"
                    >
                      {extra}
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <p className="text-sm font-extrabold text-brand-ink shrink-0">
              {formatMoney(r.value)}
            </p>
          </div>
        ))}
        <div className="flex items-center justify-between gap-3 px-4 py-3 border-t border-brand-line bg-brand-accent/5">
          <p className="text-base font-extrabold text-brand-ink">Total</p>
          <p className="text-base font-extrabold text-brand-accent">
            {formatMoney(pricing.totalCents)}
          </p>
        </div>
      </div>
    </section>
  );
}

/**
 * Per-photo bookmark toggle (POST/DELETE /api/customer/photos/:id/bookmark —
 * idempotent INSERT OR IGNORE on the server). Optimistic; reverts on failure.
 * The pinned photos surface in the /me Photos panel via <PhotoBookmarksGrid>.
 */
function PhotoBookmarkButton({ photoId }: { photoId: string }) {
  const [saved, setSaved] = useState(false);
  const [busy, setBusy] = useState(false);
  const toggle = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (busy) return;
    const next = !saved;
    setSaved(next);
    setBusy(true);
    try {
      const res = await fetch(`/api/customer/photos/${encodeURIComponent(photoId)}/bookmark`, {
        method: next ? 'POST' : 'DELETE',
        credentials: 'same-origin',
      });
      if (!res.ok) setSaved(!next); // revert on failure
    } catch {
      setSaved(!next);
    } finally {
      setBusy(false);
    }
  };
  return (
    <button
      type="button"
      onClick={toggle}
      disabled={busy}
      aria-pressed={saved}
      aria-label={saved ? 'Remove bookmark' : 'Bookmark this photo'}
      data-testid="photo-bookmark-toggle"
      className="absolute top-1 right-1 z-10 flex h-7 w-7 items-center justify-center rounded-full bg-black/60 backdrop-blur-sm text-sm hover:bg-black/80 disabled:opacity-60"
    >
      <span className={saved ? 'text-amber-300' : 'text-white/80'} aria-hidden="true">
        {saved ? '★' : '☆'}
      </span>
    </button>
  );
}

function PhotoGallery({
  photos,
  onOpenLightbox,
}: {
  photos: ReadonlyArray<JobPhoto>;
  onOpenLightbox: (i: number) => void;
}) {
  if (photos.length === 0) {
    return (
      <section>
        <h3 className="text-xl font-extrabold mb-3">Photo gallery</h3>
        <div className="rounded-2xl border border-dashed border-brand-line bg-brand-card p-8 text-center text-brand-mute text-sm">
          Photos coming after the next job. We snap 4 before + 4 after so you can see exactly what
          we did.
        </div>
      </section>
    );
  }
  return (
    <section>
      <h3 className="text-xl font-extrabold mb-3">
        Photo gallery
        <span className="ml-2 text-sm font-normal text-brand-mute">
          {photos.length} photo{photos.length === 1 ? '' : 's'}
        </span>
      </h3>
      <div
        data-gallery="customer-job-photos"
        className="grid grid-cols-2 sm:grid-cols-4 gap-2"
        aria-label="Job photo gallery"
      >
        {photos.map((p, i) => (
          <div key={p.id} className="relative aspect-square">
            <button
              type="button"
              onClick={() => onOpenLightbox(i)}
              data-zoomable="true"
              aria-label={`Open ${p.kind} photo: ${p.aiDescription ?? p.caption ?? 'no description'}`}
              className="block w-full h-full rounded-xl overflow-hidden border border-brand-line bg-brand-card focus:outline-none focus:ring-2 focus:ring-brand-accent"
            >
              <img
                src={p.url}
                alt={p.aiDescription ?? p.caption ?? `${p.kind} photo`}
                className="w-full h-full object-cover"
                loading="lazy"
              />
              <span className="absolute top-1 left-1 rounded-full bg-black/60 backdrop-blur-sm px-2 py-0.5 text-[9px] font-semibold uppercase tracking-wider text-white">
                {p.kind}
              </span>
            </button>
            <PhotoBookmarkButton photoId={p.id} />
          </div>
        ))}
      </div>
    </section>
  );
}

function PhotoLightbox({
  photos,
  index,
  onClose,
  onIndexChange,
}: {
  photos: ReadonlyArray<JobPhoto>;
  index: number;
  onClose: () => void;
  onIndexChange: (i: number) => void;
}) {
  const p = photos[index];
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') onIndexChange(Math.min(photos.length - 1, index + 1));
      else if (e.key === 'ArrowLeft') onIndexChange(Math.max(0, index - 1));
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [index, photos.length, onIndexChange]);
  if (!p) return null;
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Photo lightbox"
      onClick={onClose}
      className="fixed inset-0 z-[60] bg-black/95 flex items-center justify-center p-4"
    >
      <button
        type="button"
        onClick={onClose}
        aria-label="Close lightbox"
        className="absolute top-3 right-3 rounded-full bg-white/10 hover:bg-white/20 text-white w-10 h-10 flex items-center justify-center text-2xl"
      >
        ×
      </button>
      <div className="max-w-5xl w-full" onClick={(e) => e.stopPropagation()}>
        <img
          src={p.url}
          alt={p.aiDescription ?? p.caption ?? `${p.kind} photo`}
          className="w-full max-h-[80vh] object-contain rounded-xl"
        />
        <div className="mt-4 text-white">
          <p className="text-xs uppercase tracking-wider text-brand-accent">{p.kind}</p>
          {(p.aiDescription || p.caption) && (
            <p className="text-sm mt-1">{p.aiDescription ?? p.caption}</p>
          )}
          <p role="status" aria-live="polite" className="text-xs text-white/60 mt-2">
            {index + 1} of {photos.length}
          </p>
        </div>
      </div>
    </div>
  );
}

function ActionRow({
  detail,
  bookingId,
}: {
  detail: NonNullable<ReturnType<typeof useJobDetail>['data']>['booking'];
  bookingId: string;
}) {
  return (
    <section className="flex flex-wrap gap-2 items-center justify-between pt-2 border-t border-brand-line">
      <div className="flex flex-wrap gap-2">
        <RebookButton
          bookingId={bookingId}
          source="job_detail"
          label="Rebook same scope"
          scope={{
            service: detail.services?.[0],
            crew: detail.crew,
            hours: detail.hours,
            address: detail.address,
          }}
        />
        <RescheduleButton bookingId={bookingId} />
        {/* Self-gating: probes the ICS endpoint; hides when the
            ics_calendar_invites flag is off (404). */}
        <AddToCalendarMenu bookingId={bookingId} />
        {detail.hasRecap && (
          <a
            href={`/api/customer/jobs/${encodeURIComponent(bookingId)}/recap.pdf`}
            className="rounded-md border border-brand-line bg-brand-card px-4 py-2 text-sm font-semibold text-brand-ink hover:border-brand-accent underline-hover"
          >
            Download recap PDF
          </a>
        )}
        {detail.receiptUrl && (
          <a
            href={detail.receiptUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="rounded-md border border-brand-line bg-brand-card px-4 py-2 text-sm font-semibold text-brand-ink hover:border-brand-accent underline-hover"
          >
            View receipt
          </a>
        )}
      </div>
      <a
        href={`mailto:hello@bricklabor.com?subject=Dispute%20job%20${encodeURIComponent(
          bookingId,
        )}`}
        className="text-xs text-brand-mute hover:text-brand-ink underline-hover"
      >
        Dispute or escalate
      </a>
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
