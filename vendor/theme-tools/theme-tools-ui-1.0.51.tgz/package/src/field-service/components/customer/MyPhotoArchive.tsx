import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useEffect, useMemo, useState } from 'react';
import type { JobListItem, JobPhoto } from '../../customer-jobs.js';
import { formatJobDate } from '../../customer-jobs.js';

interface MyPhotoArchiveProps {
  items: ReadonlyArray<JobListItem>;
}

interface ArchivePhoto extends JobPhoto {
  bookingId: string;
  bookingDate: string;
  bookingService: string;
}

/**
 * Aggregate photo grid across ALL past jobs. Filter by service + year.
 * Tap a tile to open a single-photo lightbox. Photos lazy-load — only
 * the visible rows trigger `/api/customer/jobs/:id/photos` calls.
 *
 * Filtering is fully client-side; the underlying jobs list is already
 * paginated/filtered server-side by the parent.
 */
export function MyPhotoArchive({ items }: MyPhotoArchiveProps) {
  useThemeToolsSurface('my-photo-archive');
  const [photosByBooking, setPhotosByBooking] = useState<Record<string, JobPhoto[]>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [serviceFilter, setServiceFilter] = useState<string>('all');
  const [yearFilter, setYearFilter] = useState<string>('all');
  const [lightboxKey, setLightboxKey] = useState<string | null>(null);

  const eligible = useMemo(
    () =>
      items.filter(
        (i) =>
          (i.status === 'completed' || i.status === 'review_requested') &&
          i.photoCount.before + i.photoCount.after > 0,
      ),
    [items],
  );

  useEffect(() => {
    let cancelled = false;
    const toLoad = eligible.filter((i) => !(i.id in photosByBooking) && !(i.id in errors));
    for (const item of toLoad) {
      void fetch(`/api/customer/jobs/${encodeURIComponent(item.id)}/photos`, {
        credentials: 'same-origin',
      })
        .then(async (res) => {
          if (!res.ok) throw new Error(`http_${res.status}`);
          return (await res.json()) as { ok: boolean; items: JobPhoto[] };
        })
        .then((data) => {
          if (cancelled) return;
          setPhotosByBooking((prev) => ({ ...prev, [item.id]: data.items }));
        })
        .catch((err: Error) => {
          if (cancelled) return;
          setErrors((prev) => ({ ...prev, [item.id]: err.message }));
        });
    }
    return () => {
      cancelled = true;
    };
  }, [eligible, photosByBooking, errors]);

  const photos = useMemo<ArchivePhoto[]>(() => {
    const out: ArchivePhoto[] = [];
    for (const item of eligible) {
      const list = photosByBooking[item.id] ?? [];
      for (const p of list) {
        out.push({
          ...p,
          bookingId: item.id,
          bookingDate: item.preferredDate,
          bookingService: item.service,
        });
      }
    }
    return out;
  }, [eligible, photosByBooking]);

  const services = useMemo(() => {
    const s = new Set<string>();
    for (const p of photos) if (p.bookingService) s.add(p.bookingService);
    return [...s].sort();
  }, [photos]);

  const years = useMemo(() => {
    const ys = new Set<string>();
    for (const p of photos) {
      const y = (p.bookingDate || '').slice(0, 4);
      if (y) ys.add(y);
    }
    return [...ys].sort((a, b) => Number(b) - Number(a));
  }, [photos]);

  const filtered = useMemo(() => {
    return photos.filter((p) => {
      if (serviceFilter !== 'all' && p.bookingService !== serviceFilter) return false;
      if (yearFilter !== 'all' && !p.bookingDate.startsWith(yearFilter)) return false;
      return true;
    });
  }, [photos, serviceFilter, yearFilter]);

  const lightboxPhoto = lightboxKey ? filtered.find((p) => p.id === lightboxKey) : null;

  if (eligible.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed border-brand-line bg-brand-card p-10 text-center">
        <h3 className="text-xl font-extrabold mb-2">No photos yet</h3>
        <p className="text-brand-mute text-sm">
          Crews snap 4 before + 4 after on every gig. They'll show up here after your next job.
        </p>
      </div>
    );
  }

  return (
    <section>
      <div className="flex items-end justify-between gap-3 mb-4 flex-wrap">
        <h2 className="text-2xl font-extrabold">Photo archive</h2>
        <div className="flex items-center gap-2 flex-wrap">
          <label className="text-xs text-brand-mute">
            Service{' '}
            <select
              value={serviceFilter}
              onChange={(e) => setServiceFilter(e.target.value)}
              className="rounded-md border border-brand-line bg-brand-card px-2 py-1.5 text-sm text-brand-ink focus:outline-none focus:border-brand-accent"
            >
              <option value="all">All</option>
              {services.map((s) => (
                <option key={s} value={s}>
                  {s.replace(/-/g, ' ')}
                </option>
              ))}
            </select>
          </label>
          <label className="text-xs text-brand-mute">
            Year{' '}
            <select
              value={yearFilter}
              onChange={(e) => setYearFilter(e.target.value)}
              className="rounded-md border border-brand-line bg-brand-card px-2 py-1.5 text-sm text-brand-ink focus:outline-none focus:border-brand-accent"
            >
              <option value="all">All</option>
              {years.map((y) => (
                <option key={y} value={y}>
                  {y}
                </option>
              ))}
            </select>
          </label>
        </div>
      </div>

      {filtered.length === 0 ? (
        <p className="text-brand-mute text-sm">No photos match those filters.</p>
      ) : (
        <div
          data-gallery="customer-photo-archive"
          className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2"
          aria-label="Photo archive"
        >
          {filtered.map((p) => (
            <button
              key={`${p.bookingId}:${p.id}`}
              type="button"
              data-zoomable="true"
              onClick={() => setLightboxKey(p.id)}
              aria-label={`${p.kind} photo from ${formatJobDate(p.bookingDate)}`}
              className="relative aspect-square rounded-xl overflow-hidden border border-brand-line bg-brand-card focus:outline-none focus:ring-2 focus:ring-brand-accent"
            >
              <img
                src={p.url}
                alt={p.aiDescription ?? p.caption ?? `${p.kind} photo`}
                className="w-full h-full object-cover"
                loading="lazy"
              />
              <span className="absolute top-1 left-1 rounded-full bg-black/60 backdrop-blur-sm px-2 py-0.5 text-[9px] font-semibold uppercase tracking-wider text-white">
                {p.kind}
              </span>
              <span className="absolute bottom-1 right-1 rounded-full bg-black/60 backdrop-blur-sm px-2 py-0.5 text-[9px] text-white">
                {p.bookingDate.slice(0, 7)}
              </span>
            </button>
          ))}
        </div>
      )}

      {lightboxPhoto && (
        <div
          role="dialog"
          aria-modal="true"
          onClick={() => setLightboxKey(null)}
          className="fixed inset-0 z-[60] bg-black/95 flex items-center justify-center p-4"
        >
          <div className="max-w-5xl w-full" onClick={(e) => e.stopPropagation()}>
            <img
              src={lightboxPhoto.url}
              alt={
                lightboxPhoto.aiDescription ??
                lightboxPhoto.caption ??
                `${lightboxPhoto.kind} photo`
              }
              className="w-full max-h-[80vh] object-contain rounded-xl"
            />
            <div className="mt-3 text-white text-sm">
              <p className="text-xs uppercase tracking-wider text-brand-accent">
                {lightboxPhoto.kind} · {formatJobDate(lightboxPhoto.bookingDate)}
              </p>
              {(lightboxPhoto.aiDescription || lightboxPhoto.caption) && (
                <p className="mt-1">{lightboxPhoto.aiDescription ?? lightboxPhoto.caption}</p>
              )}
            </div>
            <button
              type="button"
              onClick={() => setLightboxKey(null)}
              aria-label="Close lightbox"
              className="absolute top-3 right-3 rounded-full bg-white/10 hover:bg-white/20 text-white w-10 h-10 flex items-center justify-center text-2xl"
            >
              ×
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
