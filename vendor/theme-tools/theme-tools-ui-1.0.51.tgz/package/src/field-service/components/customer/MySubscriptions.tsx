import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useEffect, useState } from 'react';

/**
 * Customer subscription manager — pause / cancel / view next cycle.
 *
 * Lives inside MePage.tsx. Hits /api/subscriptions/mine?email= to list
 * the signed-in customer's active + past subscriptions, then POSTs
 * /cancel or /pause with ?email= as the soft auth (cookie-session
 * upgrade is a follow-up).
 */

type Subscription = {
  id: string;
  status: 'pending' | 'active' | 'paused' | 'past_due' | 'canceled' | 'completed';
  plan_id: string;
  plan_name: string;
  cadence: string;
  cycle_includes: string;
  start_date: string;
  next_cycle_date: string | null;
  paused_until: string | null;
  autopilot: number;
  monthly_price_cents: number;
  total_cycles_completed: number;
  total_cents_billed: number;
};

const CADENCE_LABEL: Record<string, string> = {
  weekly: '/wk',
  biweekly: '/2 wk',
  monthly: '/mo',
  quarterly: '/qtr',
  yearly: '/yr',
};

function fmtUsd(cents: number): string {
  return `$${(cents / 100).toFixed(0)}`;
}

function statusColor(s: Subscription['status']): string {
  switch (s) {
    case 'active':
      return 'text-emerald-400 border-emerald-500/50 bg-emerald-500/5';
    case 'paused':
      return 'text-amber-400 border-amber-500/50 bg-amber-500/5';
    case 'past_due':
      return 'text-red-400 border-red-500/50 bg-red-500/5';
    case 'canceled':
    case 'completed':
      return 'text-brand-mute border-brand-line bg-bg-elevated';
    default:
      return 'text-brand-accent border-brand-accent/50 bg-brand-accent/5';
  }
}

export function MySubscriptions({ customerEmail }: { customerEmail: string }) {
  useThemeToolsSurface('my-subscriptions');
  const [subs, setSubs] = useState<Subscription[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState<string>('');

  useEffect(() => {
    if (!customerEmail) {
      setLoading(false);
      return;
    }
    void (async () => {
      try {
        const res = await fetch(
          `/api/subscriptions/mine?email=${encodeURIComponent(customerEmail)}`,
        );
        const json = (await res.json()) as { ok: boolean; subscriptions?: Subscription[] };
        if (json.ok && json.subscriptions) setSubs(json.subscriptions);
        else setError('Could not load subscriptions.');
      } catch {
        setError('Network error loading subscriptions.');
      } finally {
        setLoading(false);
      }
    })();
  }, [customerEmail]);

  async function cancel(id: string) {
    if (!confirm('Cancel this subscription? This stops future billing.')) return;
    setBusy(id);
    try {
      const res = await fetch(
        `/api/subscriptions/cancel?email=${encodeURIComponent(customerEmail)}`,
        {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ subscriptionId: id, reason: 'customer-self-cancel' }),
        },
      );
      if (res.ok) {
        setSubs((prev) => prev.map((s) => (s.id === id ? { ...s, status: 'canceled' } : s)));
      } else {
        alert('Cancel failed — contact support.');
      }
    } finally {
      setBusy('');
    }
  }

  async function pause(id: string) {
    const months = prompt('Pause for how many months? (1-6)', '2');
    if (!months) return;
    const m = Math.max(1, Math.min(6, parseInt(months, 10) || 2));
    const resumeOn = new Date();
    resumeOn.setMonth(resumeOn.getMonth() + m);
    setBusy(id);
    try {
      const res = await fetch(
        `/api/subscriptions/pause?email=${encodeURIComponent(customerEmail)}`,
        {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            subscriptionId: id,
            resumeOnIso: resumeOn.toISOString().slice(0, 10),
          }),
        },
      );
      if (res.ok) {
        setSubs((prev) =>
          prev.map((s) =>
            s.id === id
              ? { ...s, status: 'paused', paused_until: resumeOn.toISOString().slice(0, 10) }
              : s,
          ),
        );
      } else {
        alert('Pause failed — contact support.');
      }
    } finally {
      setBusy('');
    }
  }

  if (loading) {
    return (
      <p className="text-sm text-brand-mute" aria-live="polite">
        Loading subscriptions…
      </p>
    );
  }
  if (error) {
    return <p className="text-sm text-red-400">{error}</p>;
  }
  if (subs.length === 0) {
    return (
      <div className="rounded-2xl border border-brand-line bg-bg-elevated/40 p-5 text-center">
        <p className="mb-3 text-sm text-brand-mute">No subscriptions yet.</p>
        <a
          href="/plans"
          className="inline-flex items-center rounded-md bg-brand-accent px-4 py-2 text-sm font-semibold text-black hover:brightness-110"
        >
          Browse maintenance plans →
        </a>
      </div>
    );
  }

  return (
    <section className="space-y-3" aria-labelledby="my-subs-title">
      <h3
        id="my-subs-title"
        className="font-mono text-[11px] uppercase tracking-[0.18em] text-brand-accent"
      >
        Recurring plans
      </h3>
      <ul className="space-y-3">
        {subs.map((s) => (
          <li key={s.id} className="rounded-2xl border border-brand-line bg-bg-elevated p-4">
            <div className="mb-2 flex items-baseline justify-between gap-3">
              <div>
                <p className="text-base font-semibold text-brand-ink">{s.plan_name}</p>
                <p className="text-xs text-brand-mute">{s.cycle_includes}</p>
              </div>
              <span
                className={`rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-widest ${statusColor(s.status)}`}
              >
                {s.status}
              </span>
            </div>
            <dl className="grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
              <Stat
                label="Price"
                value={`${fmtUsd(s.monthly_price_cents)}${CADENCE_LABEL[s.cadence] ?? ''}`}
              />
              <Stat label="Cycles done" value={s.total_cycles_completed.toString()} />
              <Stat label="Next cycle" value={s.next_cycle_date ?? '—'} />
              <Stat label="Billed" value={fmtUsd(s.total_cents_billed)} />
            </dl>
            {s.status === 'paused' && s.paused_until && (
              <p className="mt-2 text-xs text-amber-400">Paused until {s.paused_until}</p>
            )}
            {(s.status === 'active' || s.status === 'pending') && (
              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => pause(s.id)}
                  disabled={busy === s.id}
                  className="rounded-md border border-brand-line bg-bg-primary px-3 py-1.5 text-xs text-brand-ink hover:border-brand-accent disabled:opacity-50"
                >
                  Pause
                </button>
                <button
                  type="button"
                  onClick={() => cancel(s.id)}
                  disabled={busy === s.id}
                  className="rounded-md border border-red-500/50 bg-red-500/5 px-3 py-1.5 text-xs text-red-300 hover:bg-red-500/10 disabled:opacity-50"
                >
                  Cancel
                </button>
              </div>
            )}
          </li>
        ))}
      </ul>
    </section>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-brand-line bg-bg-primary px-2 py-1.5">
      <dt className="font-mono text-[9px] uppercase tracking-widest text-brand-mute">{label}</dt>
      <dd className="text-xs text-brand-ink">{value}</dd>
    </div>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
