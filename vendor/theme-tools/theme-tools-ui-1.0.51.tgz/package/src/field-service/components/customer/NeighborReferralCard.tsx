import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * NeighborReferralCard.tsx — customer-facing /me panel that lets the
 * customer mint + share their `/by/:slug` neighbor-referral link.
 *
 * Two states:
 *   1. Already minted → shows the live URL, copy-button, view-count, and
 *      a share-via-SMS/Email helper.
 *   2. Not yet minted → shows a 2-field form (display name + city) and a
 *      single CTA that POSTs to `/api/neighbor-referrals/mint`.
 *
 * Reads from the extended `/api/customer-referrals/me` payload (the
 * `neighborLanding` field) so we only fetch one endpoint.
 *
 * Flag-gated by `neighbor_referrals`. Falls back to a quiet "you
 * already have a referral code — generate a friendly link when you're
 * ready" empty state when the API returns no data.
 */
import { useEffect, useState } from 'react';
import { useFeatureFlag } from '../../use-feature-flag.js';
import { track } from '../../analytics.js';

interface NeighborLanding {
  slug: string;
  displayName: string | null;
  city: string | null;
  views: number;
  code: string;
}

interface MeReferralResponse {
  ok: boolean;
  totals?: {
    pending: number;
    redeemed: number;
    credited: number;
    totalCreditCents: number;
  };
  neighborLanding: NeighborLanding | null;
}

// Cities the customer can pick from. Mirrors the cities for which we have
// pSEO content; the worker mint endpoint validates against the same set
// via the slug regex.
const CITY_OPTIONS = [
  { slug: 'newark', label: 'Newark' },
  { slug: 'jersey-city', label: 'Jersey City' },
  { slug: 'hoboken', label: 'Hoboken' },
  { slug: 'elizabeth', label: 'Elizabeth' },
  { slug: 'east-orange', label: 'East Orange' },
  { slug: 'paterson', label: 'Paterson' },
  { slug: 'union-city', label: 'Union City' },
  { slug: 'bayonne', label: 'Bayonne' },
  { slug: 'irvington', label: 'Irvington' },
  { slug: 'montclair', label: 'Montclair' },
  { slug: 'bloomfield', label: 'Bloomfield' },
  { slug: 'west-orange', label: 'West Orange' },
] as const;

function fmtCity(slug: string): string {
  const hit = CITY_OPTIONS.find((c) => c.slug === slug);
  if (hit) return hit.label;
  return slug
    .split('-')
    .map((w) => w[0]?.toUpperCase() + w.slice(1))
    .join(' ');
}

export function NeighborReferralCard(): JSX.Element | null {
  useThemeToolsSurface('neighbor-referral-card');
  const flagOn = useFeatureFlag('neighbor_referrals');
  const [data, setData] = useState<NeighborLanding | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Form state for the mint flow.
  const [displayName, setDisplayName] = useState('');
  const [city, setCity] = useState<string>('newark');
  const [submitting, setSubmitting] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!flagOn) {
      setLoading(false);
      return;
    }
    (async () => {
      try {
        const r = await fetch('/api/customer-referrals/me');
        if (!r.ok) {
          setError(r.status === 401 ? 'unauthorized' : `http_${r.status}`);
          setLoading(false);
          return;
        }
        const j = (await r.json()) as MeReferralResponse;
        setData(j.neighborLanding ?? null);
      } catch {
        setError('network');
      } finally {
        setLoading(false);
      }
    })();
  }, [flagOn]);

  if (!flagOn) return null;
  if (loading) {
    return (
      <div className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
        <div className="h-5 w-40 animate-pulse rounded bg-brand-line" />
        <div className="mt-3 h-4 w-3/4 animate-pulse rounded bg-brand-line" />
      </div>
    );
  }

  async function onMint(e: React.FormEvent<HTMLFormElement>): Promise<void> {
    e.preventDefault();
    if (!displayName.trim() || submitting) return;
    setSubmitting(true);
    setError(null);
    try {
      const r = await fetch('/api/neighbor-referrals/mint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ displayName: displayName.trim(), city }),
      });
      const j = (await r.json()) as {
        ok: boolean;
        slug?: string;
        code?: string;
        displayName?: string;
        city?: string;
        url?: string;
        error?: string;
      };
      if (!r.ok || !j.ok || !j.slug || !j.code) {
        setError(j.error ?? `mint_failed_${r.status}`);
        return;
      }
      setData({
        slug: j.slug,
        displayName: j.displayName ?? displayName.trim(),
        city: j.city ?? city,
        code: j.code,
        views: 0,
      });
      track('neighbor_referral_minted_ui', { slug: j.slug, city });
    } catch {
      setError('network');
    } finally {
      setSubmitting(false);
    }
  }

  async function onCopy(url: string): Promise<void> {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      track('neighbor_referral_copy', { slug: data?.slug });
      setTimeout(() => setCopied(false), 2000);
    } catch {
      /* ignore */
    }
  }

  // Minted state.
  if (data) {
    const url = `https://bricklabor.com/by/${data.slug}`;
    const shareText = `Use my Brick Labor code ${data.code} for $25 off your first move in ${fmtCity(data.city ?? 'newark')}: ${url}`;
    const smsUrl = `sms:?body=${encodeURIComponent(shareText)}`;
    const mailtoUrl = `mailto:?subject=${encodeURIComponent('Brick Labor — $25 off')}&body=${encodeURIComponent(shareText)}`;
    return (
      <section
        data-bcl-surface="neighbor-referral-card"
        className="rounded-2xl border border-brand-accent/30 bg-gradient-to-br from-brand-accent/5 to-transparent p-6"
        aria-labelledby="nbr-h2"
      >
        <header className="mb-4 flex items-start justify-between gap-4">
          <div>
            <p className="eyebrow mb-1">Refer a neighbor</p>
            <h2 id="nbr-h2" className="font-display text-xl font-extrabold">
              Your shareable {fmtCity(data.city ?? 'newark')} link
            </h2>
          </div>
          <div className="text-right">
            <div className="font-display text-2xl font-extrabold text-brand-accent">
              {data.views}
            </div>
            <div className="text-[11px] uppercase tracking-wider text-brand-mute">views</div>
          </div>
        </header>
        <div
          className="mb-3 flex items-center gap-2 rounded-lg border border-brand-line bg-bg-primary px-3 py-2 font-mono text-xs sm:text-sm"
          data-testid="neighbor-url"
        >
          <span className="truncate text-brand-ink">{url}</span>
          <button
            type="button"
            onClick={() => void onCopy(url)}
            className="ml-auto rounded-md bg-brand-accent px-3 py-1.5 text-xs font-bold text-bg-primary"
            data-bcl-action="neighbor_copy"
          >
            {copied ? 'Copied ✓' : 'Copy'}
          </button>
        </div>
        <p className="mb-4 text-sm text-brand-mute leading-relaxed">
          When a neighbor books a job through this link, they get{' '}
          <strong className="text-brand-ink">$25 off</strong> automatically and you get a
          <strong className="text-brand-ink"> $25 credit</strong> the moment their job finishes.
          Code <span className="font-mono">{data.code}</span> is locked to this URL.
        </p>
        <div className="flex flex-wrap gap-2">
          <a
            href={smsUrl}
            className="inline-flex min-h-[44px] items-center justify-center rounded-lg border border-brand-line bg-bg-elevated px-4 py-2 text-sm font-bold text-brand-ink"
            data-bcl-action="neighbor_share_sms"
          >
            Share via SMS
          </a>
          <a
            href={mailtoUrl}
            className="inline-flex min-h-[44px] items-center justify-center rounded-lg border border-brand-line bg-bg-elevated px-4 py-2 text-sm font-bold text-brand-ink"
            data-bcl-action="neighbor_share_email"
          >
            Share via email
          </a>
          <button
            type="button"
            onClick={async () => {
              if (typeof navigator !== 'undefined' && 'share' in navigator) {
                try {
                  await navigator.share({
                    title: 'Brick Labor — $25 off',
                    text: shareText,
                    url,
                  });
                  track('neighbor_share_native', { slug: data.slug });
                } catch {
                  /* user dismissed */
                }
              }
            }}
            className="inline-flex min-h-[44px] items-center justify-center rounded-lg bg-brand-accent px-4 py-2 text-sm font-extrabold text-bg-primary"
            data-bcl-action="neighbor_share_native"
          >
            Share…
          </button>
        </div>
      </section>
    );
  }

  // Pre-mint form state.
  return (
    <section
      data-bcl-surface="neighbor-referral-card"
      className="rounded-2xl border border-brand-line bg-bg-elevated p-6"
      aria-labelledby="nbr-h2"
    >
      <p className="eyebrow mb-1">Refer a neighbor</p>
      <h2 id="nbr-h2" className="font-display text-xl font-extrabold">
        Generate your personalized share link
      </h2>
      <p className="mt-2 text-sm text-brand-mute leading-relaxed">
        Get a clean <span className="font-mono">/by/your-name-newark</span> URL you can text + email
        to neighbors. They get $25 off, you get $25 credit when their job finishes.
      </p>
      <form className="mt-5 grid gap-3 sm:grid-cols-[1fr_auto_auto]" onSubmit={onMint}>
        <label className="flex flex-col gap-1">
          <span className="text-xs uppercase tracking-wider text-brand-mute">Display name</span>
          <input
            type="text"
            required
            minLength={1}
            maxLength={40}
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
            placeholder="e.g. Maria S"
            className="rounded-lg border border-brand-line bg-bg-primary px-3 py-2 text-base text-brand-ink"
            data-testid="neighbor-display-name"
          />
        </label>
        <label className="flex flex-col gap-1">
          <span className="text-xs uppercase tracking-wider text-brand-mute">City</span>
          <select
            value={city}
            onChange={(e) => setCity(e.target.value)}
            className="rounded-lg border border-brand-line bg-bg-primary px-3 py-2 text-base text-brand-ink"
            data-testid="neighbor-city"
          >
            {CITY_OPTIONS.map((c) => (
              <option key={c.slug} value={c.slug}>
                {c.label}
              </option>
            ))}
          </select>
        </label>
        <button
          type="submit"
          disabled={submitting || !displayName.trim()}
          className="inline-flex min-h-[44px] items-center justify-center self-end rounded-lg bg-brand-accent px-5 py-2 text-sm font-extrabold text-bg-primary disabled:opacity-60"
          data-bcl-action="neighbor_mint_submit"
        >
          {submitting ? 'Creating…' : 'Generate link →'}
        </button>
      </form>
      {error && (
        <p role="alert" className="mt-3 text-sm text-amber-300">
          {error === 'no_referral_code'
            ? 'Looks like your referral code needs to be set up first — book your next job and we’ll mint one automatically.'
            : error === 'unauthorized'
              ? 'Please sign in to generate a link.'
              : `Couldn’t create your link (${error}). Try again in a moment.`}
        </p>
      )}
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
