import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { POWER_WASH_PROTOCOLS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { useEffect, useMemo, useState } from 'react';

/**
 * NextServiceCard — surfaces the customer's soonest paid/confirmed booking
 * with a live countdown, service name, truncated address, and a Track →
 * deep link. Empty state nudges into /plans.
 *
 * Fetches /api/customer/jobs?filter=upcoming directly (instead of the
 * useCustomerJobs hook) so the component is drop-in mountable from any
 * surface without dragging the SWR cache module along. Mirrors the same
 * sort + filter semantics as UpcomingJobsList.
 */

interface JobListItem {
  id: string;
  service: string;
  preferredDate: string;
  preferredTime: string;
  address: string;
  city: string;
  status: string;
  paymentStatus: 'pending' | 'confirmed' | 'paid' | 'completed' | 'canceled' | 'defunct';
}

interface ListPayload {
  ok: boolean;
  items: JobListItem[];
}

const SOON_STATUSES = new Set(['paid', 'paid_in_full', 'confirmed', 'in_progress', 'en_route']);

function startDate(b: JobListItem): Date {
  const date = (b.preferredDate || '').trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return new Date(NaN);
  const time = (b.preferredTime || '00:00').trim();
  const m = time.match(/^(\d{1,2})(?::(\d{2}))?\s*(am|pm)?$/i);
  let h = m ? Number(m[1] ?? 0) : 0;
  const mm = m && m[2] != null ? Number(m[2]) : 0;
  const period = m?.[3]?.toLowerCase();
  if (period === 'pm' && h < 12) h += 12;
  if (period === 'am' && h === 12) h = 0;
  const d = new Date(`${date}T${String(h).padStart(2, '0')}:${String(mm).padStart(2, '0')}:00`);
  return Number.isNaN(d.getTime()) ? new Date(NaN) : d;
}

function humanCountdown(target: Date): string {
  if (Number.isNaN(target.getTime())) return 'date pending';
  const ms = target.getTime() - Date.now();
  if (ms < 0) return 'happening now';
  const minutes = Math.floor(ms / 60_000);
  if (minutes < 60) return `in ${Math.max(1, minutes)} min`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `in ${hours}h ${minutes % 60}m`;
  const days = Math.floor(hours / 24);
  return `in ${days}d ${hours % 24}h`;
}

function truncate(s: string, max: number): string {
  if (!s) return '';
  return s.length > max ? `${s.slice(0, max - 1)}…` : s;
}

export function NextServiceCard({ customerEmail: _customerEmail }: { customerEmail: string }) {
  useThemeToolsSurface('next-service-card');
  const [items, setItems] = useState<JobListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [tick, setTick] = useState(0);

  // Re-render every 30s so the countdown stays fresh without a re-fetch.
  useEffect(() => {
    const t = setInterval(() => setTick((n) => n + 1), 30_000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const res = await fetch('/api/customer/jobs?filter=upcoming&limit=50', {
          credentials: 'same-origin',
        });
        if (res.status === 401) {
          if (!cancelled) {
            setError('');
            setItems([]);
            setLoading(false);
          }
          return;
        }
        const json = (await res.json()) as ListPayload;
        if (!cancelled) {
          setItems(json.ok ? (json.items ?? []) : []);
          setLoading(false);
        }
      } catch {
        if (!cancelled) {
          setError('Could not load upcoming services.');
          setLoading(false);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const next = useMemo(() => {
    void tick;
    return items
      .filter(
        (b) =>
          SOON_STATUSES.has(b.status) ||
          b.paymentStatus === 'paid' ||
          b.paymentStatus === 'confirmed',
      )
      .filter((b) => !Number.isNaN(startDate(b).getTime()))
      .filter((b) => startDate(b).getTime() + 12 * 3_600_000 > Date.now())
      .sort((a, b) => startDate(a).getTime() - startDate(b).getTime())[0];
  }, [items, tick]);

  if (loading) {
    return (
      <section
        className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
        aria-live="polite"
      >
        <p className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
          Next service
        </p>
        <p className="mt-2 text-sm text-brand-mute">Loading…</p>
      </section>
    );
  }

  if (error) {
    return (
      <section
        className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
        aria-live="polite"
      >
        <p className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
          Next service
        </p>
        <p className="mt-2 text-sm text-red-400">{error}</p>
      </section>
    );
  }

  if (!next) {
    return (
      <section
        className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
        aria-labelledby="next-service-title"
      >
        <p
          id="next-service-title"
          className="font-mono text-[10px] uppercase tracking-widest text-brand-mute"
        >
          Next service
        </p>
        <p className="mt-2 text-sm text-brand-mute">No upcoming services.</p>
        <a
          href="/plans"
          data-bcl-action="next-service-browse-plans"
          className="mt-3 inline-flex items-center rounded-md bg-brand-accent px-3 py-1.5 text-xs font-semibold text-black hover:brightness-110"
        >
          Browse plans →
        </a>
      </section>
    );
  }

  const start = startDate(next);
  const countdown = humanCountdown(start);
  const serviceName = (next.service || 'crew').replace(/-/g, ' ');
  const addr = truncate([next.address, next.city].filter(Boolean).join(', '), 48);

  return (
    <section
      className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
      aria-labelledby="next-service-title"
      aria-live="polite"
    >
      <div className="flex items-baseline justify-between gap-3">
        <p
          id="next-service-title"
          className="font-mono text-[10px] uppercase tracking-widest text-brand-accent"
        >
          Next service
        </p>
        <span className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
          {countdown}
        </span>
      </div>
      <p className="mt-2 text-lg font-semibold capitalize text-brand-ink">{serviceName}</p>
      {addr && <p className="text-xs text-brand-mute">{addr}</p>}
      <a
        href={`/track/${next.id}`}
        data-bcl-action="next-service-track"
        className="mt-3 inline-flex items-center rounded-md border border-brand-line bg-bg-primary px-3 py-1.5 text-xs text-brand-ink hover:border-brand-accent hover:bg-brand-accent/5"
      >
        Track →
      </a>
    </section>
  );
}
export const THEME_TOOLS_POWER_WASH_PROTOCOLS_COUNT = Object.keys(POWER_WASH_PROTOCOLS).length;
