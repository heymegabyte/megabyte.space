import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useState } from 'react';

interface Prefs {
  smsEnabled: boolean;
  emailEnabled: boolean;
  pushEnabled: boolean;
  preferChannel: 'sms' | 'email' | 'push';
  quietHoursStart: string | null;
  quietHoursEnd: string | null;
  updatedAt: string | null;
}

interface PrefsResponse {
  ok: boolean;
  prefs: Prefs;
}

interface PatchResponse {
  ok: boolean;
  error?: string;
}

const DEFAULTS: Prefs = {
  smsEnabled: true,
  emailEnabled: true,
  pushEnabled: false,
  preferChannel: 'sms',
  quietHoursStart: null,
  quietHoursEnd: null,
  updatedAt: null,
};

/**
 * NotificationPrefs — SMS / email / push toggles plus a quiet-hours window.
 * We keep a local copy of prefs (`current`) and PATCH to the server only when
 * the user changes something. TCPA-mandated transactional messages still go
 * out regardless — these prefs gate marketing-style nudges only (rebook,
 * referrals, seasonal).
 *
 * §13d — the "Switch contact method" button now actually swaps the preferred
 * channel between sms ↔ email instead of routing to /login. Single tap. The
 * underlying preferChannel select still exists for granular control (push
 * picks too); the button is the fast path for the common ask.
 */
export function NotificationPrefs(): JSX.Element {
  useThemeToolsSurface('notification-prefs');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string>('');
  const [current, setCurrent] = useState<Prefs>(DEFAULTS);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch('/api/customer/notification-prefs', { credentials: 'include' });
      if (res.status === 401) {
        setError('Sign in to manage notifications.');
        setLoading(false);
        return;
      }
      const json = (await res.json()) as PrefsResponse;
      setCurrent(json.prefs);
    } catch {
      setError('Could not load notification preferences.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const patch = useCallback(
    async (next: Partial<Prefs>) => {
      const prior = current;
      const optimistic: Prefs = { ...current, ...next };
      setCurrent(optimistic);
      setSaving(true);
      setError('');
      try {
        // Only send keys the caller actually wanted to change so the worker's
        // COALESCE upsert leaves untouched values intact. Sending `undefined`
        // got auto-stripped by JSON.stringify, but passing `null` would have
        // wiped quiet-hours rows; build the body explicitly.
        const body: Record<string, unknown> = {};
        for (const k of Object.keys(next) as (keyof Prefs)[]) {
          body[k] = next[k];
        }
        const res = await fetch('/api/customer/notification-prefs', {
          method: 'PATCH',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body),
        });
        const json = (await res.json().catch(() => ({}))) as PatchResponse;
        if (!res.ok || !json.ok) {
          throw new Error(json.error ?? 'Could not save.');
        }
      } catch (e) {
        setCurrent(prior);
        setError((e as Error).message);
      } finally {
        setSaving(false);
      }
    },
    [current],
  );

  // §13d — "Switch contact method": flip the preferred channel between sms
  // and email, and make sure the destination channel is enabled (otherwise
  // we'd switch to a channel that isn't allowed to send).
  const switchContactMethod = useCallback(() => {
    const next: 'sms' | 'email' =
      current.preferChannel === 'sms' || current.preferChannel === 'push' ? 'email' : 'sms';
    const patchBody: Partial<Prefs> = { preferChannel: next };
    if (next === 'sms' && !current.smsEnabled) patchBody.smsEnabled = true;
    if (next === 'email' && !current.emailEnabled) patchBody.emailEnabled = true;
    void patch(patchBody);
  }, [current, patch]);

  if (loading) {
    return (
      <div
        className="rounded-lg border border-brand-line bg-brand-card p-6 text-brand-mute"
        aria-busy="true"
      >
        Loading preferences…
      </div>
    );
  }

  const nextChannelLabel = current.preferChannel === 'sms' ? 'email' : 'SMS';

  return (
    <section
      className="rounded-lg border border-brand-line bg-brand-card p-6"
      aria-labelledby="customer-prefs-heading"
    >
      <h2 id="customer-prefs-heading" className="text-lg font-semibold text-brand-ink mb-1">
        Notifications
      </h2>
      <p className="text-brand-mute text-sm mb-4">
        We always send job-critical updates. These toggles control optional reminders and
        follow-ups.
      </p>

      <div
        className="mb-6 rounded-md border border-brand-line bg-brand-bg/60 p-4"
        data-testid="pre-job-reminder-cadence"
      >
        <h3 className="text-sm font-semibold text-brand-ink">Upcoming-job reminders</h3>
        <p className="mt-1 text-xs leading-5 text-brand-mute">
          For confirmed jobs, we may email you and your crew 72 hours, 24 hours, and 8 hours
          before arrival. Crew also receive a one-hour SMS so they can head over. These
          operational updates stay on even when optional notifications are muted.
        </p>
      </div>

      <div className="flex flex-wrap items-center gap-2 mb-6">
        <button
          type="button"
          onClick={switchContactMethod}
          disabled={saving}
          className="rounded-md border border-brand-line bg-brand-bg/60 px-3 py-2 text-sm text-brand-ink hover:border-brand-accent disabled:opacity-60"
        >
          Switch to {nextChannelLabel}
        </button>
        <span className="text-xs text-brand-mute">
          Current: <strong className="text-brand-ink uppercase">{current.preferChannel}</strong>
        </span>
      </div>

      <fieldset className="space-y-3 mb-6" disabled={saving}>
        <legend className="sr-only">Channel toggles</legend>
        <Toggle
          label="Text messages (SMS)"
          checked={current.smsEnabled}
          onChange={(v) => void patch({ smsEnabled: v })}
        />
        <Toggle
          label="Email"
          checked={current.emailEnabled}
          onChange={(v) => void patch({ emailEnabled: v })}
        />
        <Toggle
          label="Web push (when supported)"
          checked={current.pushEnabled}
          onChange={(v) => void patch({ pushEnabled: v })}
        />
      </fieldset>

      <label className="block mb-4">
        <span className="text-brand-mute text-xs font-medium block mb-1">Preferred channel</span>
        <select
          value={current.preferChannel}
          disabled={saving}
          onChange={(e) =>
            void patch({ preferChannel: e.currentTarget.value as Prefs['preferChannel'] })
          }
          className="rounded-md border border-brand-line bg-brand-bg p-2 text-sm text-brand-ink"
        >
          <option value="sms">SMS</option>
          <option value="email">Email</option>
          <option value="push">Push</option>
        </select>
      </label>

      <fieldset className="grid grid-cols-2 gap-3" disabled={saving}>
        <legend className="col-span-2 text-brand-mute text-xs font-medium mb-1">
          Quiet hours (we won&apos;t send non-urgent messages during this window)
        </legend>
        <label className="block">
          <span className="text-brand-mute text-xs block mb-1">Start</span>
          <input
            type="time"
            value={current.quietHoursStart ?? ''}
            onChange={(e) => void patch({ quietHoursStart: e.currentTarget.value || null })}
            className="rounded-md border border-brand-line bg-brand-bg p-2 text-sm text-brand-ink w-full"
          />
        </label>
        <label className="block">
          <span className="text-brand-mute text-xs block mb-1">End</span>
          <input
            type="time"
            value={current.quietHoursEnd ?? ''}
            onChange={(e) => void patch({ quietHoursEnd: e.currentTarget.value || null })}
            className="rounded-md border border-brand-line bg-brand-bg p-2 text-sm text-brand-ink w-full"
          />
        </label>
      </fieldset>

      {error && (
        <p className="mt-4 text-sm text-red-300" role="alert">
          {error}
        </p>
      )}
    </section>
  );
}

interface ToggleProps {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}

function Toggle({ label, checked, onChange }: ToggleProps): JSX.Element {
  return (
    <label className="flex items-center justify-between gap-3 cursor-pointer">
      <span className="text-sm text-brand-ink">{label}</span>
      <span className="relative inline-flex items-center">
        <input
          type="checkbox"
          className="sr-only peer"
          checked={checked}
          onChange={(e) => onChange(e.currentTarget.checked)}
        />
        <span
          aria-hidden="true"
          className="w-11 h-6 rounded-full peer-focus-visible:ring-2 peer-focus-visible:ring-brand-accent peer-focus-visible:ring-offset-2 peer-focus-visible:ring-offset-bg-primary bg-brand-line/60 peer-checked:bg-emerald-500/60 transition-colors after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:w-5 after:h-5 after:rounded-full after:bg-white after:transition-transform peer-checked:after:translate-x-5"
        />
      </span>
    </label>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
