import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useEffect, useState } from 'react';
import { useRovingRadio } from '../../use-roving-radio.js';

/**
 * NpsSurvey — single-booking NPS capture (0-10 row + comment) that POSTs to
 * /api/nps-survey/submit (created in the same wave by a sibling agent). On
 * detractor scores (≤6) the response may include `aiFollowupDraft` — we
 * surface it as suggested text so the customer can edit and re-send via
 * support without retyping their frustration.
 *
 * Score buttons are color-coded NPS-standard:
 *   0-6  detractors → red
 *   7-8  passives   → amber
 *   9-10 promoters  → emerald
 *
 * aria-live="polite" wraps the dynamic regions so screen-reader users hear
 * follow-up prompts and the thank-you state without losing focus.
 */

interface SubmitPayload {
  ok: boolean;
  aiFollowupDraft?: string;
  error?: string;
  code?: string;
}

interface NpsSurveyProps {
  bookingId: string;
  onSubmitted?: () => void;
}

function categoryFor(score: number): 'detractor' | 'passive' | 'promoter' {
  if (score <= 6) return 'detractor';
  if (score <= 8) return 'passive';
  return 'promoter';
}

function scoreClass(score: number, selected: number | null): string {
  const cat = categoryFor(score);
  const isOn = selected === score;
  if (cat === 'detractor') {
    return isOn
      ? 'border-red-500 bg-red-500/15 text-red-200'
      : 'border-brand-line bg-bg-primary text-brand-mute hover:border-red-500/60 hover:text-red-300';
  }
  if (cat === 'passive') {
    return isOn
      ? 'border-amber-500 bg-amber-500/15 text-amber-200'
      : 'border-brand-line bg-bg-primary text-brand-mute hover:border-amber-500/60 hover:text-amber-300';
  }
  return isOn
    ? 'border-emerald-500 bg-emerald-500/15 text-emerald-200'
    : 'border-brand-line bg-bg-primary text-brand-mute hover:border-emerald-500/60 hover:text-emerald-300';
}

export function NpsSurvey({ bookingId, onSubmitted }: NpsSurveyProps) {
  useThemeToolsSurface('nps-survey');
  const [score, setScore] = useState<number | null>(null);
  // ARIA roving-tabindex over the 0–10 scorer (axe-blind). When nothing is
  // selected yet, index 0 is the single tab stop so the group is reachable.
  const scoreRadio = useRovingRadio(11, (i) => setScore(i));
  const [comment, setComment] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);
  const [followup, setFollowup] = useState<string | null>(null);

  // Auto-prefill the comment with the AI draft when it arrives so the
  // customer can edit-and-send instead of rewriting.
  useEffect(() => {
    if (followup && !comment) setComment(followup);
  }, [followup, comment]);

  async function submit() {
    if (score === null) {
      setError('Pick a number from 0 to 10.');
      return;
    }
    setBusy(true);
    setError('');
    try {
      const res = await fetch('/api/nps-survey/submit', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ bookingId, score, comment: comment.trim() || undefined }),
      });
      if (res.status === 401) {
        setError('Sign in to submit your rating.');
        return;
      }
      const json = (await res.json().catch(() => ({}))) as SubmitPayload;
      if (!res.ok || !json.ok) {
        setError(json.error || 'Submit failed — try again.');
        return;
      }
      if (json.aiFollowupDraft && categoryFor(score) === 'detractor') {
        setFollowup(json.aiFollowupDraft);
      } else {
        setDone(true);
        onSubmitted?.();
      }
    } catch {
      setError('Network error — try again.');
    } finally {
      setBusy(false);
    }
  }

  function sendFollowup() {
    setDone(true);
    onSubmitted?.();
  }

  if (done) {
    return (
      <section
        className="rounded-2xl border border-brand-line bg-bg-elevated p-5"
        aria-live="polite"
      >
        <p className="font-mono text-[10px] uppercase tracking-widest text-brand-accent">
          Thank you
        </p>
        <p className="mt-2 text-sm text-brand-ink">
          Your feedback helps us pay the crews who earn it. We&apos;ll be in touch if anything needs
          following up.
        </p>
      </section>
    );
  }

  return (
    <section
      data-testid="nps-survey"
      className="rounded-2xl border border-brand-line bg-bg-elevated p-5"
      aria-labelledby="nps-survey-title"
    >
      <p
        id="nps-survey-title"
        className="font-mono text-[10px] uppercase tracking-widest text-brand-accent"
      >
        Rate your experience
      </p>
      <p className="mt-1 text-sm text-brand-ink">
        How likely are you to recommend Brick Labor to a neighbor?
      </p>
      <div
        role="radiogroup"
        aria-label="Score from 0 to 10"
        className="mt-3 flex flex-wrap gap-1.5"
      >
        {Array.from({ length: 11 }).map((_, i) => (
          <button
            key={i}
            type="button"
            role="radio"
            aria-checked={score === i}
            data-bcl-action="nps-survey-score"
            onClick={() => setScore(i)}
            {...scoreRadio(i, score === i || (score === null && i === 0))}
            className={`h-10 w-10 rounded-md border text-sm font-semibold transition ${scoreClass(i, score)}`}
          >
            {i}
          </button>
        ))}
      </div>
      <div className="mt-3 flex justify-between font-mono text-[9px] uppercase tracking-widest text-brand-mute">
        <span>Not likely</span>
        <span>Very likely</span>
      </div>
      <label className="mt-4 block">
        <span className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
          Optional comment
        </span>
        <textarea
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          rows={3}
          maxLength={500}
          placeholder="What went well, or what would have made it a 10?"
          className="mt-1 w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink placeholder:text-brand-mute focus:border-brand-accent focus:outline-none"
        />
      </label>
      <div aria-live="polite">
        {followup && (
          <div className="mt-3 rounded-md border border-amber-500/40 bg-amber-500/5 p-3">
            <p className="font-mono text-[10px] uppercase tracking-widest text-amber-300">
              Suggested follow-up
            </p>
            <p className="mt-1 text-xs text-brand-ink">
              We drafted a note to support so you don&apos;t have to retype. Edit above, then send.
            </p>
            <button
              type="button"
              data-bcl-action="nps-survey-send-followup"
              onClick={sendFollowup}
              className="mt-2 inline-flex items-center rounded-md bg-brand-accent px-3 py-1.5 text-xs font-semibold text-black hover:brightness-110"
            >
              Send to support →
            </button>
          </div>
        )}
        {error && (
          <p role="alert" className="mt-3 text-xs text-red-400">
            {error}
          </p>
        )}
      </div>
      {!followup && (
        <button
          type="button"
          data-bcl-action="nps-survey-submit"
          onClick={() => void submit()}
          disabled={busy || score === null}
          className="mt-4 inline-flex items-center rounded-md bg-brand-accent px-4 py-2 text-sm font-semibold text-black hover:brightness-110 disabled:opacity-40"
        >
          {busy ? 'Sending…' : 'Submit'}
        </button>
      )}
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
