import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useState } from 'react';

interface Bookmark {
  id: string;
  photoId: string;
  bookmarkedAt: string;
}

interface BookmarksResponse {
  ok: boolean;
  bookmarks: Bookmark[];
}

interface Props {
  emptyMessage?: string;
  photoUrlBuilder?: (photoId: string) => string;
}

/**
 * PhotoBookmarksGrid — pinned crew-uploaded photos across all jobs. Fetches
 * the customer's bookmark list and renders a responsive grid of thumbnails.
 * The image URL builder is injectable so the integrator can plug in whichever
 * route serves gig photos (default points at a placeholder path; integrator
 * supplies the real public-photo endpoint when mounting).
 */
export function PhotoBookmarksGrid(props: Props): JSX.Element {
  useThemeToolsSurface('photo-bookmarks-grid');
  const {
    emptyMessage = 'No pinned photos yet. Tap the bookmark icon on any job photo to save it here.',
    photoUrlBuilder = (id: string) => `/api/work/upload/gig-photo/${encodeURIComponent(id)}`,
  } = props;
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>('');
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch('/api/customer/bookmarks', { credentials: 'include' });
      if (res.status === 401) {
        setError('Sign in to see your saved photos.');
        setLoading(false);
        return;
      }
      const json = (await res.json()) as BookmarksResponse;
      setBookmarks(json.bookmarks ?? []);
    } catch {
      setError('Could not load saved photos.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const onRemove = useCallback(async (photoId: string) => {
    setBookmarks((prev) => prev.filter((b) => b.photoId !== photoId));
    try {
      await fetch(`/api/customer/photos/${encodeURIComponent(photoId)}/bookmark`, {
        method: 'DELETE',
        credentials: 'include',
      });
    } catch {
      // Background failure — leave optimistic removal in place; the next
      // refresh will reconcile if the delete didn't actually land.
    }
  }, []);

  if (loading) {
    return (
      <div
        className="rounded-lg border border-brand-line bg-brand-card p-6 text-brand-mute"
        aria-busy="true"
      >
        Loading saved photos…
      </div>
    );
  }

  return (
    <section
      className="rounded-lg border border-brand-line bg-brand-card p-6"
      aria-labelledby="photo-bookmarks-heading"
    >
      <h2 id="photo-bookmarks-heading" className="text-lg font-semibold text-brand-ink mb-4">
        Saved photos
      </h2>

      {error && (
        <p className="text-sm text-red-300 mb-3" role="alert">
          {error}
        </p>
      )}

      {bookmarks.length === 0 ? (
        <p className="text-sm text-brand-mute">{emptyMessage}</p>
      ) : (
        <ul
          className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3"
          data-gallery="photo-bookmarks"
        >
          {bookmarks.map((b) => (
            <li key={b.id} className="relative group">
              <img
                src={photoUrlBuilder(b.photoId)}
                alt={`Saved photo ${b.photoId}`}
                loading="lazy"
                data-zoomable="true"
                className="aspect-square w-full object-cover rounded-md border border-brand-line"
              />
              <button
                type="button"
                onClick={() => void onRemove(b.photoId)}
                aria-label="Remove from saved photos"
                className="absolute top-1 right-1 inline-flex min-h-[24px] items-center rounded-full bg-black/70 px-2 py-0.5 text-xs text-white opacity-0 group-hover:opacity-100 focus:opacity-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent transition-opacity"
              >
                Unsave
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
