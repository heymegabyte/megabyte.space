import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useRef, useState } from 'react';
import { useBodyScrollLock, useFocusManagement, useTabTrap } from '../../use-dialog-a11y.js';
import { MODAL_BACKDROP_CLASS, MODAL_PANEL_CLASS, useModalMotion } from '../../use-modal-motion.js';

/**
 * PhotoGallery — aggregated 3-column thumbnail strip of before/after photos
 * from the signed-in customer's most recent jobs. Pulls upcoming + completed
 * jobs via /api/customer/jobs?filter=completed, then fans out to
 * /api/customer/jobs/:id/photos for each. Click a tile to open a modal
 * lightbox (esc / backdrop / × to close).
 *
 * The lightbox is a real ARIA APG modal dialog via the shared dialog a11y kit
 * (`use-dialog-a11y.ts`) — focus moves INTO the panel on open, restores to the
 * thumbnail trigger on close, Tab/Shift+Tab stay trapped inside, and body scroll
 * locks while it covers the viewport (axe-core is blind to every one of those).
 * Dismissal (Esc, backdrop, ×) plays the shared A7 backdrop-fade + panel-slide
 * exit via `use-modal-motion.ts`; ←/→ swap the photo instantly. Extend-don't-
 * duplicate: the same hooks power the chat panel, drawer, and move-photo gallery.
 *
 * Empty + 401 states are graceful — customers who haven't been serviced yet
 * see a nudge instead of an error. No external lightbox dependency; the
 * modal is local state.
 */

interface JobListItem {
  id: string;
  service: string;
  preferredDate: string;
}

interface JobPhoto {
  id: string;
  kind: 'start' | 'end' | 'other';
  url: string;
  caption?: string | null;
  aiDescription?: string | null;
}

interface GalleryItem extends JobPhoto {
  bookingId: string;
  bookingDate: string;
  bookingService: string;
}

export function PhotoGallery({ customerEmail: _customerEmail }: { customerEmail: string }) {
  useThemeToolsSurface('photo-gallery');
  const [items, setItems] = useState<GalleryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [unauth, setUnauth] = useState(false);
  const [openIdx, setOpenIdx] = useState<number | null>(null);
  const panelRef = useRef<HTMLDivElement | null>(null);
  const lastFocusRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const listRes = await fetch('/api/customer/jobs?filter=completed&limit=24', {
          credentials: 'same-origin',
        });
        if (listRes.status === 401) {
          if (!cancelled) {
            setUnauth(true);
            setLoading(false);
          }
          return;
        }
        const listJson = (await listRes.json()) as { ok: boolean; items?: JobListItem[] };
        const jobs = listJson.ok ? (listJson.items ?? []) : [];
        const all: GalleryItem[] = [];
        for (const job of jobs.slice(0, 8)) {
          try {
            const pRes = await fetch(`/api/customer/jobs/${encodeURIComponent(job.id)}/photos`, {
              credentials: 'same-origin',
            });
            if (!pRes.ok) continue;
            const pJson = (await pRes.json()) as { ok: boolean; items?: JobPhoto[] };
            for (const p of pJson.items ?? []) {
              all.push({
                ...p,
                bookingId: job.id,
                bookingDate: job.preferredDate,
                bookingService: job.service,
              });
            }
          } catch {
            /* skip job */
          }
        }
        if (!cancelled) {
          setItems(all);
          setLoading(false);
        }
      } catch {
        if (!cancelled) {
          setError('Could not load photos.');
          setLoading(false);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const isOpen = openIdx !== null;
  const close = useCallback(() => setOpenIdx(null), []);
  // Animated dismissal — plays the shared exit keyframe, then unmounts (close).
  const { closing, requestClose } = useModalMotion(close);

  // Shared dialog a11y kit (axe-blind interaction patterns): focus into the
  // panel on open + restore to the trigger on close, body-scroll lock while the
  // full-screen lightbox is up, and a Tab trap on the overlay.
  useFocusManagement(isOpen, panelRef, lastFocusRef);
  useBodyScrollLock(isOpen, 99999);
  const onTabKeyDown = useTabTrap(panelRef);

  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') requestClose();
      else if (e.key === 'ArrowRight')
        setOpenIdx((i) => (i === null ? null : Math.min(items.length - 1, i + 1)));
      else if (e.key === 'ArrowLeft')
        setOpenIdx((i) => (i === null ? null : Math.max(0, i - 1)));
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isOpen, items.length, requestClose]);

  if (loading) {
    return (
      <section
        className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
        aria-live="polite"
      >
        <p className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
          Job photos
        </p>
        <p className="mt-2 text-sm text-brand-mute">Loading photos…</p>
      </section>
    );
  }
  if (error) {
    return (
      <section className="rounded-2xl border border-brand-line bg-bg-elevated p-4">
        <p className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
          Job photos
        </p>
        <p className="mt-2 text-sm text-red-400">{error}</p>
      </section>
    );
  }
  if (unauth) {
    return (
      <section className="rounded-2xl border border-brand-line bg-bg-elevated p-4">
        <p className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
          Job photos
        </p>
        <p className="mt-2 text-sm text-brand-mute">Sign in to see your job photo history.</p>
      </section>
    );
  }
  if (items.length === 0) {
    return (
      <section className="rounded-2xl border border-brand-line bg-bg-elevated p-4">
        <p className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
          Job photos
        </p>
        <p className="mt-2 text-sm text-brand-mute">
          No job photos yet — they&apos;ll appear here after your next service.
        </p>
        <a
          href="/book"
          data-bcl-action="photo-gallery-book"
          className="mt-3 inline-flex items-center rounded-md bg-brand-accent px-3 py-1.5 text-xs font-semibold text-black hover:brightness-110"
        >
          Book a crew →
        </a>
      </section>
    );
  }

  const open = openIdx !== null ? items[openIdx] : null;

  return (
    <section
      className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
      aria-labelledby="photo-gallery-title"
    >
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <p
          id="photo-gallery-title"
          className="font-mono text-[10px] uppercase tracking-widest text-brand-accent"
        >
          Job photos
        </p>
        <span className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
          {items.length} total
        </span>
      </div>
      <div data-gallery="customer-photo-gallery" className="grid grid-cols-3 gap-2">
        {items.slice(0, 24).map((p, idx) => (
          <button
            key={`${p.bookingId}:${p.id}`}
            type="button"
            data-zoomable="true"
            data-bcl-action="photo-gallery-open"
            onClick={() => setOpenIdx(idx)}
            aria-label={`${p.kind} photo from ${p.bookingDate}`}
            className="relative aspect-square overflow-hidden rounded-lg border border-brand-line bg-bg-primary focus:outline-none focus:ring-2 focus:ring-brand-accent"
          >
            <img
              src={p.url}
              alt={p.aiDescription ?? p.caption ?? `${p.kind} photo`}
              loading="lazy"
              className="h-full w-full object-cover"
            />
            <span className="absolute left-1 top-1 rounded-full bg-black/70 px-2 py-0.5 font-mono text-[9px] uppercase tracking-widest text-white">
              {p.kind}
            </span>
          </button>
        ))}
      </div>

      {open && (
        <div
          ref={panelRef}
          role="dialog"
          aria-modal="true"
          aria-label="Photo viewer"
          data-closing={closing ? 'true' : undefined}
          onKeyDown={onTabKeyDown}
          onClick={requestClose}
          className={`${MODAL_BACKDROP_CLASS} fixed inset-0 z-[60] flex items-center justify-center bg-black/95 p-4`}
        >
          <div
            data-closing={closing ? 'true' : undefined}
            className={`${MODAL_PANEL_CLASS} relative w-full max-w-4xl`}
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={open.url}
              alt={open.aiDescription ?? open.caption ?? `${open.kind} photo`}
              className="max-h-[80vh] w-full rounded-xl object-contain"
            />
            <div className="mt-2 text-sm text-white">
              <p className="font-mono text-[10px] uppercase tracking-widest text-brand-accent">
                {open.kind} · {open.bookingDate}
              </p>
              {(open.aiDescription || open.caption) && (
                <p className="mt-1 text-brand-ink">{open.aiDescription ?? open.caption}</p>
              )}
            </div>
            <button
              type="button"
              data-bcl-action="photo-gallery-close"
              onClick={(e) => {
                e.stopPropagation();
                requestClose();
              }}
              aria-label="Close photo viewer"
              className="absolute right-2 top-2 flex h-9 w-9 min-h-[44px] min-w-[44px] items-center justify-center rounded-full bg-white/10 text-2xl text-white transition-[transform,background-color] duration-[333ms] hover:scale-105 hover:bg-white/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
            >
              ×
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
