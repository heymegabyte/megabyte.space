import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useState } from 'react';

/**
 * Predict-next card — slot into `/me` (or any signed-in surface) to show
 * the Haiku-suggested next service. One-tap accept fires off to /#book
 * with prefill params; dismiss buries the card for 30 days via local
 * storage.
 *
 * Calls `/api/loyalty/predict-next` which wraps `predictNextNeed`. Hides
 * itself silently if the endpoint is absent or returns no suggestion.
 */

interface Prediction {
  ok?: boolean;
  slug?: string;
  headline?: string;
  body?: string;
  source?: 'haiku' | 'fallback';
}

const DISMISS_KEY = 'bcl_predict_dismissed_until';

export function PredictNextCard() {
  useThemeToolsSurface('predict-next-card');
  const [pred, setPred] = useState<Prediction | null>(null);
  const [hidden, setHidden] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(DISMISS_KEY);
      const until = raw ? Number(raw) : 0;
      if (Number.isFinite(until) && until > Date.now()) {
        setHidden(true);
        return;
      }
    } catch {
      /* swallow — storage may be disabled */
    }

    let cancelled = false;
    (async () => {
      try {
        const res = await fetch('/api/loyalty/predict-next', { credentials: 'same-origin' });
        if (!res.ok || cancelled) return;
        const data = (await res.json()) as Prediction;
        if (!cancelled && data.ok && data.slug && data.headline) {
          setPred(data);
        }
      } catch {
        /* swallow */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const dismiss = useCallback(() => {
    try {
      localStorage.setItem(DISMISS_KEY, String(Date.now() + 30 * 24 * 60 * 60 * 1000));
    } catch {
      /* swallow */
    }
    setHidden(true);
  }, []);

  if (hidden || !pred?.slug || !pred.headline) return null;

  const prefillUrl = `/book?service=${encodeURIComponent(pred.slug)}`;

  return (
    <aside
      className="border-brand-accent/40 from-brand-accent/10 rounded-2xl border bg-gradient-to-br to-transparent p-5"
      aria-label="Predicted next service"
    >
      <div className="flex items-start gap-3">
        <div className="text-2xl" aria-hidden="true">
          ✨
        </div>
        <div className="flex-1">
          <p className="text-brand-mute text-xs uppercase tracking-wider">
            Predicted for you{pred.source === 'haiku' ? ' · AI' : ''}
          </p>
          <h3 className="mt-1 text-lg font-bold">{pred.headline}</h3>
          {pred.body && <p className="text-brand-mute mt-1 text-sm">{pred.body}</p>}
          <div className="mt-3 flex flex-wrap gap-2">
            <a
              href={prefillUrl}
              className="bg-brand-accent rounded-full px-4 py-2 text-sm font-semibold text-black"
            >
              Book now →
            </a>
            <button
              type="button"
              onClick={dismiss}
              className="text-brand-mute rounded-full px-4 py-2 text-sm hover:text-white"
            >
              Not now
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
