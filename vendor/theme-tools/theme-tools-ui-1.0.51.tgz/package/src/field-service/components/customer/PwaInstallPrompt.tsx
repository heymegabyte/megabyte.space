import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useRef, useState } from 'react';
import { usePwaInstall } from '../../use-pwa-install.js';

interface PromptState {
  dismissedAt: string | null;
  installedAt: string | null;
  promptCount: number;
}

interface PromptStateResponse {
  ok: boolean;
  /** False for anonymous visitors — the banner needs a signed-in customer. */
  authed?: boolean;
  state: PromptState | null;
}

const VISIT_KEY = 'bcl_pwa_visit_count';
const COOLDOWN_DAYS = 30;
const MIN_VISITS = 2;

/**
 * Compute whether we should show the install prompt given the current state.
 * Pulled out for unit testing. Rules:
 *   - never show if already installed
 *   - never show if shown < MIN_VISITS times worth of total visits
 *   - never show within `COOLDOWN_DAYS` of the last dismissal
 */
export function shouldShowPwaPrompt(opts: {
  visitCount: number;
  state: PromptState;
  nowMs: number;
}): boolean {
  const { visitCount, state, nowMs } = opts;
  if (state.installedAt) return false;
  if (visitCount < MIN_VISITS) return false;
  if (!state.dismissedAt) return true;
  const dismissedMs = new Date(state.dismissedAt).getTime();
  if (Number.isNaN(dismissedMs)) return true;
  return nowMs - dismissedMs > COOLDOWN_DAYS * 86400 * 1000;
}

/**
 * Which install surface to show once a visitor is eligible. Pulled out (and
 * unit-tested) so the `canPrompt` reactivity can't regress: `beforeinstallprompt`
 * fires asynchronously, so a desktop visitor is eligible *before* the browser is
 * installable — we wait for `canPrompt`, fall back to static iOS A2HS, and surface
 * at most once (`alreadyShown`) so the impression records a single time.
 */
export type PwaSurface = 'install' | 'ios' | 'none';
export function pwaSurfaceDecision(opts: {
  eligible: boolean;
  canPrompt: boolean;
  isIos: boolean;
  alreadyShown: boolean;
}): PwaSurface {
  if (!opts.eligible || opts.alreadyShown) return 'none';
  if (opts.canPrompt) return 'install';
  if (opts.isIos) return 'ios';
  return 'none';
}

function bumpVisitCount(): number {
  try {
    const raw = window.localStorage.getItem(VISIT_KEY);
    const next = Math.max(0, Number(raw) || 0) + 1;
    window.localStorage.setItem(VISIT_KEY, String(next));
    return next;
  } catch {
    return 0;
  }
}

/**
 * PwaInstallPrompt — banner that appears on the 2nd+ visit and respects a
 * 30-day dismissal cooldown. Visit count is local (localStorage); cooldown
 * state lives in `pwa_install_prompts` on the server so it survives device
 * resets. The hook gives us the `beforeinstallprompt` event for browsers
 * that support it; iOS shows static A2HS instructions instead.
 */
export function PwaInstallPrompt(): JSX.Element | null {
  useThemeToolsSurface('pwa-install-prompt');
  const { canPrompt, isStandalone, prompt } = usePwaInstall();
  const [visible, setVisible] = useState(false);
  const [busy, setBusy] = useState(false);
  const [iosFallback, setIosFallback] = useState(false);
  const [eligible, setEligible] = useState(false);
  const shownRef = useRef(false);

  // Mount-once: bump the visit counter + read the server cooldown state EXACTLY
  // ONCE per page load. Deliberately NOT keyed on `canPrompt` — it flips
  // false→true when the browser fires `beforeinstallprompt`, and re-running here
  // would double-bump the visit count (firing the "2nd+ visit" banner on the
  // FIRST visit) and double-fetch `/api/customer/pwa-prompt`.
  useEffect(() => {
    if (isStandalone) return;
    const visitCount = bumpVisitCount();
    let mounted = true;
    (async () => {
      try {
        const res = await fetch('/api/customer/pwa-prompt', { credentials: 'include' });
        if (!mounted) return;
        if (res.status === 401) return;
        const json = (await res.json()) as PromptStateResponse;
        // Anonymous visitors get `authed:false` (200, no 401 console error) and
        // no server bookkeeping — never show the banner without it.
        if (json.authed === false || !json.state) return;
        if (mounted) {
          setEligible(shouldShowPwaPrompt({ visitCount, state: json.state, nowMs: Date.now() }));
        }
      } catch {
        // Anonymous visitors or network blip — never show the banner without
        // server bookkeeping, so we don't spam the user across sessions.
      }
    })();
    return () => {
      mounted = false;
    };
  }, [isStandalone]);

  // Surface the banner once eligibility is known. Reacts to `canPrompt` because
  // desktop installability arrives asynchronously after `beforeinstallprompt`;
  // iOS has no such event and uses the static A2HS fallback. Records the
  // impression (`/show`) exactly once via `shownRef`.
  useEffect(() => {
    const surface = pwaSurfaceDecision({
      eligible,
      canPrompt,
      isIos: /iPad|iPhone|iPod/.test(navigator.userAgent),
      alreadyShown: shownRef.current,
    });
    if (surface === 'none') return;
    if (surface === 'ios') setIosFallback(true);
    setVisible(true);
    shownRef.current = true;
    // Bump the server-side prompt count so we don't oscillate across sessions.
    fetch('/api/customer/pwa-prompt/show', { method: 'POST', credentials: 'include' }).catch(
      () => undefined,
    );
  }, [eligible, canPrompt]);

  const onInstall = useCallback(async () => {
    setBusy(true);
    const outcome = await prompt();
    setBusy(false);
    if (outcome === 'accepted') {
      fetch('/api/customer/pwa-prompt/installed', {
        method: 'POST',
        credentials: 'include',
      }).catch(() => undefined);
      setVisible(false);
    }
  }, [prompt]);

  const onDismiss = useCallback(() => {
    setVisible(false);
    fetch('/api/customer/pwa-prompt/dismiss', {
      method: 'POST',
      credentials: 'include',
    }).catch(() => undefined);
  }, []);

  if (!visible) return null;

  return (
    <div
      role="dialog"
      data-testid="pwa-install-prompt"
      aria-labelledby="pwa-install-heading"
      aria-describedby="pwa-install-desc"
      className="fixed inset-x-3 bottom-3 z-40 rounded-lg border border-brand-line bg-brand-card p-4 shadow-2xl sm:left-auto sm:right-4 sm:bottom-4 sm:max-w-sm"
    >
      <div className="flex items-start justify-between gap-3 mb-2">
        <h2 id="pwa-install-heading" className="text-base font-bold text-brand-ink">
          Install Brick Labor
        </h2>
        <button
          type="button"
          onClick={onDismiss}
          aria-label="Dismiss install prompt"
          className="inline-flex min-h-[24px] min-w-[24px] items-center justify-center rounded-md text-lg leading-none text-brand-mute transition-colors hover:text-brand-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
        >
          ×
        </button>
      </div>
      <p id="pwa-install-desc" className="text-sm text-brand-mute mb-3">
        Add the app to your home screen for faster booking and rebooking.
      </p>
      {iosFallback ? (
        <p className="text-xs text-brand-mute">
          On iPhone: tap the Share button, then "Add to Home Screen".
        </p>
      ) : (
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => void onInstall()}
            disabled={busy}
            aria-busy={busy}
            className="btn btn-primary text-sm flex-1 disabled:opacity-50"
          >
            {busy ? 'Installing…' : 'Install'}
          </button>
          <button
            type="button"
            onClick={onDismiss}
            className="btn text-sm flex-1 border border-brand-line bg-brand-bg text-brand-ink hover:bg-brand-line/30"
          >
            Not now
          </button>
        </div>
      )}
    </div>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
