import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { useEffect, useRef, useState } from 'react';
import type { Booking, ServiceId } from '@theme.tools/scheduling/field-service/customer-types';
import { SERVICE_COLORS, SERVICE_IDS, colorForService } from '@theme.tools/scheduling/field-service/customer-types';
import { formatTime12, parseTime } from '@theme.tools/scheduling/field-service/customer-date-utils';

export interface QuickScheduleDraft {
  /** ISO yyyy-mm-dd */
  date: string;
  /** 24-hour HH:MM string */
  startTime: string;
  /** integer hours */
  hours: number;
  /** integer crew size */
  crew: number;
  service: ServiceId;
}

export type QuickScheduleMode = 'create' | 'edit';

interface QuickSchedulePopoverProps {
  mode: QuickScheduleMode;
  /** Existing booking when editing; undefined when creating a new one. */
  booking?: Booking;
  /** Initial draft (drag-create populates this from the drag rectangle). */
  initial: QuickScheduleDraft;
  /** Anchor for popover positioning ({ x, y } in client coords) — when absent renders centered. */
  anchor?: { x: number; y: number } | undefined;
  /** Save handler — caller decides whether to POST /api/booking or PATCH /api/booking/:id. */
  onSave: (draft: QuickScheduleDraft) => Promise<void> | void;
  /** Cancel handler — close without saving. */
  onClose: () => void;
  /** Delete handler — only rendered when mode === 'edit'. */
  onDelete?: () => Promise<void> | void;
  /** Optional async error to surface inline. */
  error?: string | null;
  /** Saving in flight — disables submit. */
  saving?: boolean;
}

/**
 * Inline popover for fast event creation + editing on the Week/Day grids.
 * Renders fixed-position anchored to a click; falls back to centered when no
 * anchor is provided (used for mobile + keyboard "n" shortcut).
 *
 * a11y: role=dialog + aria-modal, focus traps the form, ESC closes via parent.
 */
export function QuickSchedulePopover({
  mode,
  booking,
  initial,
  anchor,
  onSave,
  onClose,
  onDelete,
  error,
  saving,
}: QuickSchedulePopoverProps) {
  useThemeToolsSurface('quick-schedule-popover');
  const [draft, setDraft] = useState<QuickScheduleDraft>(initial);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const firstFieldRef = useRef<HTMLSelectElement | null>(null);

  useEffect(() => {
    firstFieldRef.current?.focus();
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSave(draft);
  };

  const positionStyle: React.CSSProperties | undefined = anchor
    ? {
        position: 'fixed',
        left: Math.min(window.innerWidth - 360, Math.max(12, anchor.x - 180)),
        top: Math.min(window.innerHeight - 480, Math.max(72, anchor.y)),
        zIndex: 60,
      }
    : undefined;

  const containerClass = anchor
    ? 'w-[340px] sm:w-[360px] rounded-2xl border border-brand-line bg-bg-elevated shadow-glow animate-fade-up'
    : 'fixed inset-0 z-[60] grid place-items-center bg-bg-primary/70 backdrop-blur-sm p-4 animate-fade-up';

  const cardClass = anchor
    ? 'p-5'
    : 'w-full max-w-md rounded-2xl border border-brand-line bg-bg-elevated p-6 shadow-glow';

  const palette = colorForService(draft.service);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={mode === 'edit' ? 'Edit booking' : 'Create booking'}
      className={containerClass}
      style={positionStyle}
      onClick={(e) => {
        if (!anchor && e.target === e.currentTarget) onClose();
      }}
    >
      <form onSubmit={submit} className={cardClass}>
        <div className="flex items-start justify-between gap-3 mb-4">
          <div className="min-w-0">
            <p
              className="text-[10px] uppercase tracking-wider font-semibold"
              style={{ color: palette.text }}
            >
              {mode === 'edit' ? 'Edit booking' : 'New booking'}
            </p>
            <h2 className="text-lg font-extrabold text-brand-ink truncate">
              {new Date(`${draft.date}T12:00:00`).toLocaleDateString(undefined, {
                weekday: 'short',
                month: 'short',
                day: 'numeric',
              })}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="rounded-md border border-brand-line bg-bg-primary/60 px-2 py-1 text-xs text-brand-mute hover:text-brand-ink hover:border-brand-accent min-h-[28px] min-w-[28px]"
          >
            ✕
          </button>
        </div>

        <div className="space-y-3">
          <label className="block">
            <span className="block text-xs uppercase tracking-wider text-brand-mute mb-1">
              Service
            </span>
            <select
              ref={firstFieldRef}
              value={draft.service}
              onChange={(e) => setDraft((d) => ({ ...d, service: e.target.value as ServiceId }))}
              className="w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink focus:border-brand-accent focus:outline-none min-h-[40px]"
            >
              {SERVICE_IDS.map((id) => (
                <option key={id} value={id}>
                  {(SERVICE_COLORS[id] ?? { label: id }).label}
                </option>
              ))}
            </select>
          </label>

          <div className="grid grid-cols-2 gap-3">
            <label className="block">
              <span className="block text-xs uppercase tracking-wider text-brand-mute mb-1">
                Date
              </span>
              <input
                type="date"
                value={draft.date}
                onChange={(e) => setDraft((d) => ({ ...d, date: e.target.value }))}
                className="w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink focus:border-brand-accent focus:outline-none min-h-[40px]"
              />
            </label>
            <label className="block">
              <span className="block text-xs uppercase tracking-wider text-brand-mute mb-1">
                Start
              </span>
              <input
                type="time"
                step={900}
                value={draft.startTime}
                onChange={(e) => setDraft((d) => ({ ...d, startTime: e.target.value }))}
                className="w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink focus:border-brand-accent focus:outline-none min-h-[40px]"
              />
            </label>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <label className="block">
              <span className="block text-xs uppercase tracking-wider text-brand-mute mb-1">
                Hours
              </span>
              <input
                type="number"
                min={1}
                max={12}
                value={draft.hours}
                onChange={(e) =>
                  setDraft((d) => ({
                    ...d,
                    hours: Math.max(1, Math.min(12, Number(e.target.value) || 1)),
                  }))
                }
                className="w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink focus:border-brand-accent focus:outline-none min-h-[40px]"
              />
            </label>
            <label className="block">
              <span className="block text-xs uppercase tracking-wider text-brand-mute mb-1">
                Crew
              </span>
              <input
                type="number"
                min={1}
                max={12}
                value={draft.crew}
                onChange={(e) =>
                  setDraft((d) => ({
                    ...d,
                    crew: Math.max(1, Math.min(12, Number(e.target.value) || 1)),
                  }))
                }
                className="w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink focus:border-brand-accent focus:outline-none min-h-[40px]"
              />
            </label>
          </div>

          <div
            className="rounded-lg border p-3 text-xs"
            style={{ background: palette.fill, borderColor: palette.border, color: palette.text }}
          >
            <strong>{palette.label}</strong> · {draft.hours}h × {draft.crew}{' '}
            {draft.crew === 1 ? 'person' : 'people'} · starts{' '}
            {(() => {
              const t = parseTime(draft.startTime);
              return t ? formatTime12(t.hour, t.minute) : draft.startTime;
            })()}
          </div>

          {error && (
            <div
              role="alert"
              className="rounded-md border border-brand-err/50 bg-brand-err/10 px-3 py-2 text-xs text-red-200"
            >
              {error}
            </div>
          )}
        </div>

        <div className="mt-5 flex flex-wrap items-center gap-2">
          <button
            type="submit"
            disabled={saving}
            className="rounded-md bg-brand-accent px-4 py-2 text-sm font-extrabold text-bg-primary hover:bg-brand-accentHover disabled:opacity-60 min-h-[40px]"
          >
            {saving ? 'Saving…' : mode === 'edit' ? 'Save changes' : 'Create booking'}
          </button>
          <button
            type="button"
            onClick={onClose}
            className="rounded-md border border-brand-line px-3 py-2 text-sm text-brand-ink hover:border-brand-accent min-h-[40px]"
          >
            Cancel
          </button>

          {mode === 'edit' && onDelete && (
            <div className="ml-auto">
              {confirmDelete ? (
                <span className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={onDelete}
                    className="rounded-md border border-brand-err/60 bg-brand-err/10 px-3 py-2 text-xs font-semibold text-red-200 hover:bg-brand-err/20 min-h-[36px]"
                  >
                    Confirm cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmDelete(false)}
                    className="rounded-md border border-brand-line px-2 py-2 text-xs text-brand-mute hover:text-brand-ink min-h-[36px]"
                  >
                    Keep it
                  </button>
                </span>
              ) : (
                <button
                  type="button"
                  onClick={() => setConfirmDelete(true)}
                  className="rounded-md border border-brand-err/40 px-3 py-2 text-xs text-red-200 hover:bg-brand-err/10 min-h-[36px]"
                >
                  Cancel booking
                </button>
              )}
            </div>
          )}
        </div>

        {mode === 'edit' && booking && (
          <p className="mt-3 text-[10px] text-brand-mute font-mono break-all">
            id {booking.id.slice(0, 8)} · status {booking.status.replace('_', ' ')}
          </p>
        )}
      </form>
    </div>
  );
}
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
