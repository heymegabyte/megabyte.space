import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useState } from 'react';
import { requestRebook } from '../../customer-jobs.js';
import { rebookFallbackHref } from '@theme.tools/crm/field-service/rebook-prefill';
import type { RebookPrefill } from '@theme.tools/crm/field-service/rebook-prefill';

interface RebookButtonProps {
  bookingId: string;
  source?: string;
  className?: string;
  label?: string;
  variant?: 'primary' | 'ghost';
  /**
   * The prior job's scope, when the caller (past-job card / detail panel) holds
   * it. Drives a lossless, instant `/book` prefill for the no-JS / fetch-failure
   * path so the customer never loses their scope when the async rebook is down.
   */
  scope?: RebookPrefill;
}

/**
 * One-tap rebook standalone button. POSTs `/api/customer/jobs/:id/rebook`
 * (which audits the intent) then navigates to the prefilled /#book URL.
 *
 * Embeddable in `MyJobDetail`, `MyBookingsList`, and transactional emails.
 * The href is a DETERMINISTIC FLOOR (`rebookFallbackHref`): when `scope` is
 * supplied it is a lossless prefilled `/book?service=&crew=&hours=&address=`
 * URL, so a no-JS user — OR one whose rebook fetch fails — still lands on their
 * prior scope, not a bare default form.
 */
export function RebookButton({
  bookingId,
  source = 'me_page',
  className,
  label = 'Rebook same scope',
  variant = 'primary',
  scope,
}: RebookButtonProps) {
  useThemeToolsSurface('rebook-button');
  const [pending, setPending] = useState(false);

  const fallbackHref = rebookFallbackHref(scope, bookingId);

  const onClick = async (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    setPending(true);
    try {
      const r = await requestRebook(bookingId, source);
      if (r.ok && r.rebookUrl) {
        try {
          const w = window as unknown as {
            posthog?: { capture: (n: string, p?: Record<string, unknown>) => void };
          };
          w.posthog?.capture('me_rebook_clicked', { bookingId, source });
        } catch {
          /* noop */
        }
        window.location.href = r.rebookUrl;
        return;
      }
      // Server-audited path failed — degrade to the deterministic prefill floor
      // instead of dead-ending the customer on the money path.
      window.location.href = fallbackHref;
      return;
    } catch {
      window.location.href = fallbackHref;
      return;
    } finally {
      setPending(false);
    }
  };

  const cls =
    className ??
    (variant === 'primary'
      ? 'btn-primary'
      : 'rounded-md border border-brand-line px-3 py-1.5 text-xs text-brand-ink hover:border-brand-accent underline-hover');

  return (
    <>
      <a href={fallbackHref} onClick={onClick} aria-busy={pending} className={cls}>
        {pending ? 'Loading…' : label}
      </a>
    </>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
