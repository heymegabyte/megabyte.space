import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * RecurringPlansPanel.tsx — the customer `/me` "Plans" panel.
 *
 * Fetches GET /api/recurring-subscriptions/mine (session-scoped, flag-gated)
 * and renders one row per recurring subscription with its status + next run,
 * dropping a <VacationHoldCard> into every active plan so the customer can
 * snooze it without contacting support (support-deflection / retention lens).
 *
 * Fully stateful: loading / error / empty / success. The whole surface is
 * dark-safe — when the `recurring_subscriptions` flag is off the API 404s and
 * we render the empty state; the snooze card self-gates on `vacation_hold`.
 */
import { useCallback, useEffect, useState, type JSX } from 'react';
import { VacationHoldCard } from '../VacationHoldCard.js';
import { discountForPlan } from '@theme.tools/scheduling/field-service/recurring';

type Frequency = 'daily' | 'weekly' | 'biweekly' | 'monthly';
type Status = 'active' | 'paused' | 'cancelled';

interface SubscriptionSummary {
  id: string;
  frequency: Frequency;
  status: Status;
  nextRunAt: string;
  lastRunAt: string | null;
  runCount: number;
  createdAt: string;
  cancelledAt: string | null;
  template: unknown;
  canPause: boolean;
  canResume: boolean;
  canSkip: boolean;
  canCancel: boolean;
}

type LoadState =
  | { kind: 'loading' }
  | { kind: 'error'; message: string }
  | { kind: 'ready'; subscriptions: SubscriptionSummary[] };

const FREQUENCY_LABEL: Readonly<Record<Frequency, string>> = {
  daily: 'Daily',
  weekly: 'Weekly',
  biweekly: 'Biweekly',
  monthly: 'Monthly',
};

const STATUS_STYLE: Readonly<Record<Status, string>> = {
  active: 'border-emerald-400/40 bg-emerald-400/10 text-emerald-200',
  paused: 'border-amber-400/40 bg-amber-400/10 text-amber-200',
  cancelled: 'border-brand-line bg-bg-elevated/40 text-brand-mute',
};

/** Pull service strings out of the (untrusted) parsed booking template. */
export function parseServices(template: unknown): string[] {
  if (template && typeof template === 'object' && 'services' in template) {
    const svc = (template as { services?: unknown }).services;
    if (Array.isArray(svc) && svc.length > 0) {
      return svc.filter((s): s is string => typeof s === 'string').slice(0, 3);
    }
  }
  return [];
}

/**
 * The standing discount the customer earns just for being on this cadence,
 * sourced from the canonical RECURRING_PLANS catalog so this badge can never
 * contradict the booking form (daily 12% / weekly 8% / biweekly 5% / monthly 3%).
 * Returns null for a zero-discount cadence so callers render nothing.
 */
export function discountLabel(frequency: Frequency): string | null {
  const pct = discountForPlan(frequency);
  return pct > 0 ? `${pct}% off every visit` : null;
}

function planLabel(sub: SubscriptionSummary): string {
  return FREQUENCY_LABEL[sub.frequency];
}

export function formatDate(iso: string): string {
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return '—';
  return new Date(t).toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export function RecurringPlansPanel(): JSX.Element {
  useThemeToolsSurface('recurring-plans-panel');
  const [state, setState] = useState<LoadState>({ kind: 'loading' });

  const load = useCallback(async () => {
    setState({ kind: 'loading' });
    try {
      const res = await fetch('/api/recurring-subscriptions/mine', {
        credentials: 'same-origin',
      });
      if (res.status === 404) {
        // flag off / feature dark → treat as "no plans" empty state.
        setState({ kind: 'ready', subscriptions: [] });
        return;
      }
      if (!res.ok) {
        setState({ kind: 'error', message: `Could not load your plans (${res.status}).` });
        return;
      }
      const body = (await res.json()) as {
        ok: boolean;
        subscriptions?: SubscriptionSummary[];
      };
      setState({ kind: 'ready', subscriptions: body.subscriptions ?? [] });
    } catch {
      setState({ kind: 'error', message: 'Network error loading your plans.' });
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  if (state.kind === 'loading') {
    return (
      <section className="rounded-2xl border border-brand-line bg-brand-card p-6">
        <p className="eyebrow mb-2">Recurring plans</p>
        <p className="text-brand-mute text-sm" role="status" aria-live="polite">
          Loading your plans…
        </p>
        <div className="mt-4 space-y-3" aria-hidden="true">
          {[0, 1].map((i) => (
            <div
              key={i}
              className="h-20 rounded-xl border border-brand-line bg-bg-elevated/40 animate-pulse"
            />
          ))}
        </div>
      </section>
    );
  }

  if (state.kind === 'error') {
    return (
      <section className="rounded-2xl border border-brand-line bg-brand-card p-6">
        <p className="eyebrow mb-2">Recurring plans</p>
        <div className="rounded-xl border border-red-500/40 bg-red-500/10 p-4 text-sm text-red-200">
          {state.message}{' '}
          <button
            type="button"
            onClick={() => void load()}
            className="underline-hover font-semibold text-red-100"
          >
            Retry
          </button>
        </div>
      </section>
    );
  }

  if (state.subscriptions.length === 0) {
    return (
      <section className="rounded-2xl border border-brand-line bg-brand-card p-6">
        <p className="eyebrow mb-2">Recurring plans</p>
        <h2 className="text-2xl font-extrabold text-brand-ink mb-1">No recurring plans yet</h2>
        <p className="text-brand-mute text-sm mb-4">
          Book a job and choose a repeat cadence to set one up — we&apos;ll handle the rest on
          autopilot.
        </p>
        <a href="/book" className="btn-primary inline-flex text-xs h-9 px-4 items-center">
          Book a job
        </a>
      </section>
    );
  }

  return (
    <section className="space-y-4" data-testid="recurring-plans-panel">
      <header>
        <p className="eyebrow mb-1">Recurring plans</p>
        <h2 className="text-2xl font-extrabold text-brand-ink">Your plans</h2>
        <p className="text-brand-mute text-sm">Pause, resume, or snooze without a phone call.</p>
      </header>

      {state.subscriptions.map((sub) => {
        const services = parseServices(sub.template);
        const savings = sub.status === 'cancelled' ? null : discountLabel(sub.frequency);
        return (
          <article key={sub.id} className="rounded-2xl border border-brand-line bg-brand-card p-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-lg font-bold text-brand-ink">{planLabel(sub)} plan</h3>
              <div className="flex flex-wrap items-center gap-1.5">
                {savings && (
                  <span
                    className="inline-flex items-center gap-1 rounded-full border border-emerald-400/40 bg-emerald-400/10 px-2.5 py-0.5 text-[11px] font-semibold text-emerald-200 transition-all duration-[333ms] hover:-translate-y-0.5 hover:border-emerald-300/60 hover:bg-emerald-400/20"
                    title="Standing discount for keeping this cadence"
                  >
                    <span aria-hidden="true">★</span>
                    {savings}
                  </span>
                )}
                <span
                  className={`rounded-full border px-2.5 py-0.5 font-mono text-[11px] uppercase tracking-wider ${STATUS_STYLE[sub.status]}`}
                >
                  {sub.status}
                </span>
              </div>
            </div>

            {services.length > 0 && (
              <ul aria-label="Services" className="mt-2 flex flex-wrap gap-1.5">
                {services.map((svc, i) => (
                  <li
                    key={svc}
                    className="resume-pill inline-flex animate-[pill-enter_0.35s_ease_both] items-center rounded-full border border-brand-accent/30 bg-brand-accent/10 px-2.5 py-0.5 text-[11px] font-medium text-brand-accent transition-all duration-[333ms] hover:-translate-y-0.5 hover:border-brand-accent/60 hover:bg-brand-accent/20 hover:shadow-sm"
                    style={{ animationDelay: `${i * 50}ms` }}
                  >
                    {svc}
                  </li>
                ))}
              </ul>
            )}

            <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-1 text-sm sm:grid-cols-3">
              <div>
                <dt className="text-brand-mute text-xs uppercase tracking-wide">Next run</dt>
                <dd className="text-brand-ink tabular-nums">
                  {sub.status === 'cancelled' ? '—' : formatDate(sub.nextRunAt)}
                </dd>
              </div>
              <div>
                <dt className="text-brand-mute text-xs uppercase tracking-wide">Completed</dt>
                <dd className="text-brand-ink tabular-nums">{sub.runCount}</dd>
              </div>
              <div>
                <dt className="text-brand-mute text-xs uppercase tracking-wide">Since</dt>
                <dd className="text-brand-ink tabular-nums">{formatDate(sub.createdAt)}</dd>
              </div>
            </dl>

            {sub.status === 'active' && (
              <div className="mt-4">
                <VacationHoldCard recurringSubscriptionId={sub.id} planLabel={planLabel(sub)} />
              </div>
            )}
          </article>
        );
      })}
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
