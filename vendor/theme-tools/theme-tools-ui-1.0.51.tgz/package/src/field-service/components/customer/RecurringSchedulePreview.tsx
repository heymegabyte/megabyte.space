import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { useEffect, useMemo, useState } from 'react';

/**
 * RecurringSchedulePreview — projects the next 6 cycles forward from each
 * active subscription's `next_cycle_date`, using the plan cadence (weekly /
 * biweekly / monthly / quarterly / yearly). Pure client-side projection on
 * top of the existing /api/subscriptions/mine payload; the worker doesn't
 * pre-compute future cycles.
 *
 * Renders a vertical timeline. Empty + paused + canceled subs are filtered
 * out — they don't have a meaningful "next 6" to render.
 */

interface Subscription {
  id: string;
  status: 'pending' | 'active' | 'paused' | 'past_due' | 'canceled' | 'completed';
  plan_name: string;
  cadence: string;
  next_cycle_date: string | null;
}

interface ProjectedCycle {
  isoDate: string;
  label: string;
  planName: string;
  cadence: string;
  subId: string;
  cycleNum: number;
}

const PROJECTION_COUNT = 6;

const CADENCE_LABEL: Record<string, string> = {
  weekly: 'weekly',
  biweekly: 'every 2 weeks',
  monthly: 'monthly',
  quarterly: 'quarterly',
  yearly: 'yearly',
};

function addCadence(iso: string, cadence: string, n: number): string {
  const [y, m, d] = iso.split('-').map(Number);
  if (!y || !m || !d) return iso;
  const dt = new Date(Date.UTC(y, m - 1, d));
  switch (cadence) {
    case 'weekly':
      dt.setUTCDate(dt.getUTCDate() + 7 * n);
      break;
    case 'biweekly':
      dt.setUTCDate(dt.getUTCDate() + 14 * n);
      break;
    case 'monthly':
      dt.setUTCMonth(dt.getUTCMonth() + n);
      break;
    case 'quarterly':
      dt.setUTCMonth(dt.getUTCMonth() + 3 * n);
      break;
    case 'yearly':
      dt.setUTCFullYear(dt.getUTCFullYear() + n);
      break;
    default:
      dt.setUTCMonth(dt.getUTCMonth() + n);
  }
  return dt.toISOString().slice(0, 10);
}

function humanDate(iso: string): string {
  const [y, m, d] = iso.split('-').map(Number);
  if (!y || !m || !d) return iso;
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    timeZone: 'UTC',
  });
}

export function RecurringSchedulePreview({ customerEmail }: { customerEmail: string }) {
  useThemeToolsSurface('recurring-schedule-preview');
  const [subs, setSubs] = useState<Subscription[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!customerEmail) {
      setLoading(false);
      return;
    }
    let cancelled = false;
    void (async () => {
      try {
        const res = await fetch(
          `/api/subscriptions/mine?email=${encodeURIComponent(customerEmail)}`,
        );
        if (res.status === 401) {
          if (!cancelled) {
            setSubs([]);
            setLoading(false);
          }
          return;
        }
        const json = (await res.json()) as { ok: boolean; subscriptions?: Subscription[] };
        if (!cancelled) {
          setSubs(json.ok ? (json.subscriptions ?? []) : []);
          setLoading(false);
        }
      } catch {
        if (!cancelled) {
          setError('Could not load recurring schedule.');
          setLoading(false);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [customerEmail]);

  const projected = useMemo<ProjectedCycle[]>(() => {
    const out: ProjectedCycle[] = [];
    for (const s of subs) {
      if (s.status !== 'active' && s.status !== 'pending') continue;
      if (!s.next_cycle_date) continue;
      for (let i = 0; i < PROJECTION_COUNT; i += 1) {
        const iso = addCadence(s.next_cycle_date, s.cadence, i);
        out.push({
          isoDate: iso,
          label: humanDate(iso),
          planName: s.plan_name,
          cadence: s.cadence,
          subId: s.id,
          cycleNum: i + 1,
        });
      }
    }
    return out.sort((a, b) => a.isoDate.localeCompare(b.isoDate)).slice(0, PROJECTION_COUNT * 2);
  }, [subs]);

  if (loading) {
    return (
      <section
        className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
        aria-live="polite"
      >
        <p className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
          Recurring schedule
        </p>
        <p className="mt-2 text-sm text-brand-mute">Loading…</p>
      </section>
    );
  }
  if (error) {
    return (
      <section className="rounded-2xl border border-brand-line bg-bg-elevated p-4">
        <p className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
          Recurring schedule
        </p>
        <p className="mt-2 text-sm text-red-400">{error}</p>
      </section>
    );
  }
  if (projected.length === 0) {
    return (
      <section className="rounded-2xl border border-brand-line bg-bg-elevated p-4">
        <p className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
          Recurring schedule
        </p>
        <p className="mt-2 text-sm text-brand-mute">
          No active plans yet — set a cadence and we&apos;ll handle the rest.
        </p>
        <a
          href="/plans"
          data-bcl-action="recurring-schedule-browse-plans"
          className="mt-3 inline-flex items-center rounded-md bg-brand-accent px-3 py-1.5 text-xs font-semibold text-black hover:brightness-110"
        >
          Browse plans →
        </a>
      </section>
    );
  }

  return (
    <section
      className="rounded-2xl border border-brand-line bg-bg-elevated p-5"
      aria-labelledby="recurring-schedule-title"
    >
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <p
          id="recurring-schedule-title"
          className="font-mono text-[10px] uppercase tracking-widest text-brand-accent"
        >
          Recurring schedule
        </p>
        <span className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
          Next {projected.length}
        </span>
      </div>
      <ol className="relative space-y-3 border-l border-brand-line pl-4">
        {projected.map((c) => (
          <li key={`${c.subId}-${c.cycleNum}`} className="relative">
            <span
              aria-hidden="true"
              className="absolute -left-[1.18rem] top-1.5 h-2.5 w-2.5 rounded-full border-2 border-bg-elevated bg-brand-accent"
            />
            <div className="flex items-baseline justify-between gap-3">
              <p className="text-sm font-semibold text-brand-ink">{c.label}</p>
              <span className="font-mono text-[9px] uppercase tracking-widest text-brand-mute">
                #{c.cycleNum}
              </span>
            </div>
            <p className="text-xs text-brand-mute">
              {c.planName}{' '}
              <span className="text-brand-mute">· {CADENCE_LABEL[c.cadence] ?? c.cadence}</span>
            </p>
          </li>
        ))}
      </ol>
      <p className="mt-3 text-[11px] text-brand-mute">
        Projected from your subscription cadence — actual visits adjust for weather and crew
        availability.
      </p>
    </section>
  );
}
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
