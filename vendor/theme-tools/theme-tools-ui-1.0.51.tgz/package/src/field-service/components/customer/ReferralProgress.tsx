import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useEffect, useMemo, useState } from 'react';

/**
 * ReferralProgress — shows credited referral $ earned plus a tier ladder
 * (Sprout → Friend → Champion → Mayor). Fetches /api/customer-referrals/me
 * which returns the customer's referral rows + aggregate totals (cookie-gated).
 *
 * Also mints (POST /api/customer-referrals/mint) a personal share code on
 * first render so the copy-to-clipboard CTA is always armed.
 */

interface ReferralRow {
  id: string;
  code: string;
  credit_cents: number;
  status: 'pending' | 'redeemed' | 'credited' | 'expired' | 'void';
}

interface MePayload {
  ok: boolean;
  referrals?: ReferralRow[];
  totals?: {
    pending: number;
    redeemed: number;
    credited: number;
    totalCreditCents: number;
  };
  error?: string;
}

const TIERS = [
  { name: 'Sprout', threshold: 0 },
  { name: 'Friend', threshold: 5000 },
  { name: 'Champion', threshold: 15000 },
  { name: 'Mayor', threshold: 50000 },
] as const;

function fmtUsd(cents: number): string {
  return `$${(cents / 100).toFixed(0)}`;
}

function currentTier(cents: number): {
  name: string;
  next: { name: string; threshold: number } | null;
  pct: number;
} {
  let active: { name: string; threshold: number } = TIERS[0];
  for (const t of TIERS) if (cents >= t.threshold) active = t;
  const next = TIERS.find((t) => t.threshold > cents) ?? null;
  const span = next ? next.threshold - active.threshold : 1;
  const into = cents - active.threshold;
  const pct = next ? Math.max(2, Math.min(100, Math.round((into / span) * 100))) : 100;
  return { name: active.name, next, pct };
}

export function ReferralProgress({ customerEmail: _customerEmail }: { customerEmail: string }) {
  useThemeToolsSurface('referral-progress');
  const [data, setData] = useState<MePayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [unauth, setUnauth] = useState(false);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        // Mint first (idempotent — returns existing pending if present).
        await fetch('/api/customer-referrals/mint', {
          method: 'POST',
          credentials: 'same-origin',
        });
        const res = await fetch('/api/customer-referrals/me', { credentials: 'same-origin' });
        if (res.status === 401) {
          if (!cancelled) {
            setUnauth(true);
            setLoading(false);
          }
          return;
        }
        const json = (await res.json()) as MePayload;
        if (!cancelled) {
          setData(json);
          setLoading(false);
        }
      } catch {
        if (!cancelled) {
          setError('Could not load referral progress.');
          setLoading(false);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const myCode = useMemo<string | null>(() => {
    const pending = data?.referrals?.find((r) => r.status === 'pending');
    return pending?.code ?? data?.referrals?.[0]?.code ?? null;
  }, [data]);

  const shareUrl = myCode ? `https://bricklabor.com/refer?code=${encodeURIComponent(myCode)}` : '';

  async function copyShareLink() {
    if (!shareUrl) return;
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback: select-and-prompt
      window.prompt('Copy this link:', shareUrl);
    }
  }

  if (loading) {
    return (
      <section
        className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
        aria-live="polite"
      >
        <p className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">Referrals</p>
        <p className="mt-2 text-sm text-brand-mute">Loading…</p>
      </section>
    );
  }
  if (error) {
    return (
      <section className="rounded-2xl border border-brand-line bg-bg-elevated p-4">
        <p className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">Referrals</p>
        <p className="mt-2 text-sm text-red-400">{error}</p>
      </section>
    );
  }
  if (unauth || !data?.ok) {
    return (
      <section className="rounded-2xl border border-brand-line bg-bg-elevated p-4">
        <p className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">Referrals</p>
        <p className="mt-2 text-sm text-brand-mute">
          Refer your first neighbor — both get <span className="text-brand-accent">$25</span>.
        </p>
        <a
          href="/refer"
          data-bcl-action="referral-progress-signin"
          className="mt-3 inline-flex items-center rounded-md bg-brand-accent px-3 py-1.5 text-xs font-semibold text-black hover:brightness-110"
        >
          Get my code →
        </a>
      </section>
    );
  }

  const totalCredit = data.totals?.totalCreditCents ?? 0;
  const tier = currentTier(totalCredit);

  return (
    <section
      className="rounded-2xl border border-brand-line bg-bg-elevated p-5"
      aria-labelledby="referral-progress-title"
    >
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <p
          id="referral-progress-title"
          className="font-mono text-[10px] uppercase tracking-widest text-brand-accent"
        >
          Referral progress
        </p>
        <span className="rounded-md border border-brand-accent/50 bg-brand-accent/5 px-2 py-0.5 font-mono text-[10px] uppercase tracking-widest text-brand-accent">
          {tier.name}
        </span>
      </div>
      <p className="text-2xl font-bold text-brand-ink">{fmtUsd(totalCredit)} earned</p>
      <p className="mt-1 text-xs text-brand-mute">
        {tier.next
          ? `${fmtUsd(tier.next.threshold - totalCredit)} to ${tier.next.name}`
          : 'Top tier unlocked — thank you.'}
      </p>
      <div
        className="mt-3 h-2 w-full overflow-hidden rounded-full bg-bg-primary"
        role="progressbar"
        aria-valuenow={tier.pct}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label={`Progress toward ${tier.next?.name ?? tier.name}`}
      >
        <div
          className="h-full rounded-full bg-brand-accent transition-all"
          style={{ width: `${tier.pct}%` }}
        />
      </div>
      <dl className="mt-3 grid grid-cols-3 gap-2 text-xs">
        <Stat label="Sent" value={String(data.totals?.pending ?? 0)} />
        <Stat label="Redeemed" value={String(data.totals?.redeemed ?? 0)} />
        <Stat label="Credited" value={String(data.totals?.credited ?? 0)} />
      </dl>
      {shareUrl && (
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <code className="flex-1 overflow-hidden text-ellipsis whitespace-nowrap rounded-md border border-brand-line bg-bg-primary px-2 py-1.5 font-mono text-[11px] text-brand-ink">
            {shareUrl}
          </code>
          <button
            type="button"
            data-bcl-action="referral-progress-copy"
            onClick={() => void copyShareLink()}
            className="rounded-md bg-brand-accent px-3 py-1.5 text-xs font-semibold text-black hover:brightness-110"
          >
            {copied ? 'Copied!' : 'Copy link'}
          </button>
        </div>
      )}
    </section>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-brand-line bg-bg-primary px-2 py-1.5">
      <dt className="font-mono text-[9px] uppercase tracking-widest text-brand-mute">{label}</dt>
      <dd className="text-sm text-brand-ink">{value}</dd>
    </div>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
