import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useEffect } from 'react';
import { PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';

/**
 * /me/smart-home — onboarding for Alexa skill + Google Action.
 *
 * Pure-static page: no API calls, no auth gating (anyone curious can read
 * the setup). Deep-links to the official Alexa skill page and Google
 * Assistant directory entry; the same `/api/smart-home` endpoints power
 * both.
 */

const TITLE = 'Smart home setup — Brick Labor';
const DESC =
  'Book a Newark crew with Alexa or Google. Step-by-step setup, deeplinks to the official skill + Action.';

const ALEXA_DEEPLINK =
  'https://www.amazon.com/gp/redirect.html?location=https://alexa.amazon.com/spa/index.html#skills/dp/B0BRICKCITYLABOR';
const GOOGLE_DEEPLINK = 'https://assistant.google.com/services/invoke/uid/0000brickcitylabor';

export function SmartHomeSetup() {
  useThemeToolsSurface('smart-home-setup');
  useEffect(() => {
    document.title = TITLE;
    const meta = document.querySelector('meta[name="description"]');
    if (meta) meta.setAttribute('content', DESC);
  }, []);

  return (
    <article className="section">
      <div className="container-pad max-w-3xl space-y-10">
        <header>
          <h1 className="text-3xl font-bold">Smart home setup</h1>
          <p className="text-brand-mute mt-2">
            Book a Newark crew without picking up your phone — say it once, we get the rest.
          </p>
        </header>

        <SetupCard
          platform="Amazon Alexa"
          deeplink={ALEXA_DEEPLINK}
          steps={[
            'Open the Alexa app on your phone.',
            'Tap More → Skills & Games → Search "Brick Labor".',
            'Tap Enable. Link your phone number so we can text confirmations.',
            'Say "Alexa, ask Brick Labor to book a cleanup."',
          ]}
          sample={[
            'Alexa, ask Brick Labor to book a cleanup.',
            'Alexa, ask Brick Labor for the status of my next booking.',
            'Alexa, ask Brick Labor to set up weekly lawn service.',
          ]}
        />

        <SetupCard
          platform="Google Assistant"
          deeplink={GOOGLE_DEEPLINK}
          steps={[
            'Open the Google Assistant or Home app.',
            'Tap your profile → Add → Connect a service. Search "Brick Labor".',
            'Tap Connect and grant the prompt access.',
            'Say "Hey Google, talk to Brick Labor."',
          ]}
          sample={[
            'Hey Google, talk to Brick Labor.',
            'Hey Google, ask Brick Labor to book a cleanup tomorrow.',
            'Hey Google, ask Brick Labor when my crew arrives.',
          ]}
        />

        <p className="text-brand-mute text-sm">
          Trouble pairing? Text us at{' '}
          <a href={PHONE_TEL_HREF} className="text-brand-accent underline underline-offset-2">
            (855) 825-2267
          </a>{' '}
          and we will walk through it on the call.
        </p>
      </div>
    </article>
  );
}

interface CardProps {
  readonly platform: string;
  readonly deeplink: string;
  readonly steps: readonly string[];
  readonly sample: readonly string[];
}

function SetupCard({ platform, deeplink, steps, sample }: CardProps) {
  return (
    <section className="border-brand-line bg-brand-card space-y-4 rounded-2xl border p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-xl font-bold">{platform}</h2>
        <a
          href={deeplink}
          target="_blank"
          rel="noopener noreferrer"
          className="bg-brand-accent rounded-full px-4 py-2 text-sm font-semibold text-black"
        >
          Open the skill →
        </a>
      </div>

      <ol className="text-brand-mute list-decimal space-y-2 pl-5 text-sm">
        {steps.map((step) => (
          <li key={step}>{step}</li>
        ))}
      </ol>

      <div>
        <p className="text-sm font-semibold">Try saying:</p>
        <ul className="text-brand-mute mt-1 space-y-1 text-sm">
          {sample.map((s) => (
            <li key={s} className="rounded bg-black/40 px-3 py-2 font-mono">
              "{s}"
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
