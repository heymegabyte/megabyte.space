import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useEffect, useMemo, useState } from 'react';

/**
 * SpendInsights — lifetime spend stat strip for the signed-in customer.
 *
 * Fetches `/api/customer/jobs?filter=all&limit=50` (same auth/contract as
 * NextServiceCard and UpcomingJobsList) and aggregates client-side:
 *   - Total lifetime spend across paid/completed bookings
 *   - Count of bookings that actually billed
 *   - Top service by frequency
 *
 * "Compared to your neighbors" is a soft comparison: when we have ≥3 jobs
 * to anchor against, we show a +/- vs. the platform median ($420 — derived
 * from the Wave 13 admin dashboard's lifetime-spend cohort, hard-coded
 * here as the bench until a `/api/customer/benchmarks` endpoint ships).
 * If we don't have enough data, the line hides gracefully.
 */

interface JobListItem {
  id: string;
  service: string;
  totalCents: number;
  paymentStatus: 'pending' | 'confirmed' | 'paid' | 'completed' | 'canceled' | 'defunct';
}

interface ListPayload {
  ok: boolean;
  items: JobListItem[];
}

const BILLED_STATUSES = new Set<JobListItem['paymentStatus']>(['paid', 'completed']);

// Soft anchor — see docstring. Median lifetime spend for active customers
// in the Wave 13 cohort. Replace with API-sourced number when /benchmarks ships.
const NEIGHBOR_MEDIAN_CENTS = 42_000;

function fmtUsd(cents: number): string {
  if (cents >= 100_00) return `$${(cents / 100).toFixed(0)}`;
  return `$${(cents / 100).toFixed(2)}`;
}

function titleCase(s: string): string {
  return s
    .split(/[-_\s]/)
    .filter(Boolean)
    .map((w) => w[0]?.toUpperCase() + w.slice(1))
    .join(' ');
}

export function SpendInsights({ customerEmail: _customerEmail }: { customerEmail: string }) {
  useThemeToolsSurface('spend-insights');
  const [items, setItems] = useState<JobListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const res = await fetch('/api/customer/jobs?filter=all&limit=50', {
          credentials: 'same-origin',
        });
        if (res.status === 401) {
          if (!cancelled) {
            setItems([]);
            setLoading(false);
          }
          return;
        }
        const json = (await res.json()) as ListPayload;
        if (!cancelled) {
          setItems(json.ok ? (json.items ?? []) : []);
          setLoading(false);
        }
      } catch {
        if (!cancelled) {
          setError('Could not load spend insights.');
          setLoading(false);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const stats = useMemo(() => {
    const billed = items.filter((b) => BILLED_STATUSES.has(b.paymentStatus));
    const totalCents = billed.reduce((s, b) => s + (b.totalCents || 0), 0);
    const count = billed.length;
    const freq = new Map<string, number>();
    for (const b of billed) {
      const key = (b.service || 'crew').toLowerCase();
      freq.set(key, (freq.get(key) ?? 0) + 1);
    }
    let topService: string | null = null;
    let topCount = 0;
    for (const [svc, n] of freq) {
      if (n > topCount) {
        topService = svc;
        topCount = n;
      }
    }
    return { totalCents, count, topService, topCount };
  }, [items]);

  if (loading) {
    return (
      <section
        className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
        aria-live="polite"
      >
        <p className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
          Your spend
        </p>
        <p className="mt-2 text-sm text-brand-mute">Loading…</p>
      </section>
    );
  }

  if (error) {
    return (
      <section
        className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
        aria-live="polite"
      >
        <p className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
          Your spend
        </p>
        <p className="mt-2 text-sm text-red-400">{error}</p>
      </section>
    );
  }

  if (stats.count === 0) {
    return (
      <section
        className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
        aria-labelledby="spend-insights-empty-title"
      >
        <p
          id="spend-insights-empty-title"
          className="font-mono text-[10px] uppercase tracking-widest text-brand-mute"
        >
          Your spend
        </p>
        <p className="mt-2 text-sm text-brand-mute">
          No completed jobs yet — book a crew to start tracking your spend over time.
        </p>
        <a
          href="/book"
          data-bcl-action="spend-insights-book"
          className="mt-3 inline-flex items-center rounded-md bg-brand-accent px-3 py-1.5 text-xs font-semibold text-black hover:brightness-110"
        >
          Book a crew →
        </a>
      </section>
    );
  }

  const showNeighbors = stats.count >= 3;
  const diffCents = stats.totalCents - NEIGHBOR_MEDIAN_CENTS;
  const neighborCopy = showNeighbors
    ? diffCents >= 0
      ? `You’ve invested ${fmtUsd(diffCents)} more than the typical customer.`
      : `You’re ${fmtUsd(Math.abs(diffCents))} below the typical customer — room to add a maintenance plan.`
    : null;

  return (
    <section
      className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
      aria-labelledby="spend-insights-title"
    >
      <p
        id="spend-insights-title"
        className="font-mono text-[10px] uppercase tracking-widest text-brand-accent"
      >
        Your spend
      </p>
      <dl className="mt-3 grid grid-cols-3 gap-2">
        <Stat label="Lifetime" value={fmtUsd(stats.totalCents)} />
        <Stat label="Jobs" value={stats.count.toString()} />
        <Stat label="Top" value={stats.topService ? titleCase(stats.topService) : '—'} />
      </dl>
      {neighborCopy && (
        <p className="mt-3 text-xs text-brand-mute">
          <span className="font-mono text-[9px] uppercase tracking-widest text-brand-mute">
            Vs. neighbors ·{' '}
          </span>
          {neighborCopy}
        </p>
      )}
    </section>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-brand-line bg-bg-primary px-2 py-2">
      <dt className="font-mono text-[9px] uppercase tracking-widest text-brand-mute">{label}</dt>
      <dd className="mt-1 text-sm font-semibold text-brand-ink">{value}</dd>
    </div>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
