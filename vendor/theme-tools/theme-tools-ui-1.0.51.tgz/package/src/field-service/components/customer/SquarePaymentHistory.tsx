import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { useCallback, useEffect, useState } from 'react';

// Wave 13A — customer-facing payment history. Mounts on `/me/payments`. Shows
// every Square charge for the signed-in customer with status, last-4, and a
// tap-to-receipt link. Unpaid balances surface a "pay now" button that calls
// `/api/customer/square/save-card-intent` to mint a hosted checkout URL.

interface SquarePaymentRow {
  id: string;
  amountCents: number;
  status: string;
  cardBrand: string;
  cardLast4: string;
  receiptUrl: string;
  createdAt: string;
  refundedAt: string | null;
  refundAmountCents: number | null;
  bookingId: string | null;
}

interface SavedCard {
  brand: string;
  last4: string;
  expMonth: number;
  expYear: number;
  cardholderName: string;
}

function formatMoney(cents: number): string {
  return `$${(cents / 100).toFixed(2)}`;
}

function formatDate(iso: string): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function statusBadge(status: string): string {
  const map: Record<string, string> = {
    COMPLETED: 'bg-emerald-500/20 text-emerald-200 border-emerald-500/40',
    APPROVED: 'bg-blue-500/20 text-blue-200 border-blue-500/40',
    PENDING: 'bg-yellow-500/20 text-yellow-200 border-yellow-500/40',
    FAILED: 'bg-rose-500/20 text-rose-200 border-rose-500/40',
    CANCELED: 'bg-zinc-500/20 text-zinc-300 border-zinc-500/40',
  };
  return map[status] ?? 'bg-zinc-700/40 text-zinc-200 border-zinc-500/40';
}

export function SquarePaymentHistory() {
  useThemeToolsSurface('square-payment-history');
  const [payments, setPayments] = useState<SquarePaymentRow[]>([]);
  const [cards, setCards] = useState<SavedCard[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [linked, setLinked] = useState(true);
  const [savingCard, setSavingCard] = useState(false);
  const [cardSavedNotice, setCardSavedNotice] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [paymentsRes, cardsRes] = await Promise.all([
        fetch('/api/customer/square/payments', { credentials: 'same-origin' }),
        fetch('/api/customer/square/cards', { credentials: 'same-origin' }),
      ]);
      if (paymentsRes.status === 401) {
        window.location.href = '/login?as=customer&next=%2Fme%2Fpayments';
        return;
      }
      if (!paymentsRes.ok) throw new Error(`payments HTTP ${paymentsRes.status}`);
      const paymentsData = (await paymentsRes.json()) as {
        payments?: SquarePaymentRow[];
        linked?: boolean;
      };
      setPayments(paymentsData.payments ?? []);
      setLinked(paymentsData.linked !== false);
      if (cardsRes.ok) {
        const cardsData = (await cardsRes.json()) as { cards?: SavedCard[] };
        setCards(cardsData.cards ?? []);
      }
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  // The save-card hosted checkout redirects back to `/me/payments?card_saved=1`.
  // That flag is a client claim, so we ask the worker to RE-CHECK Square and fire
  // the `payment_method_verified` notification only if a real card is on file.
  // Then strip the param (so a refresh doesn't re-confirm) and show the reassuring
  // "you'll only be charged after the job is complete" banner.
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('card_saved') !== '1') return;
    let cancelled = false;
    void (async () => {
      try {
        const res = await fetch('/api/customer/square/confirm-card-saved', {
          method: 'POST',
          credentials: 'same-origin',
        });
        const data = (await res.json()) as { verified?: boolean };
        if (!cancelled && data.verified) setCardSavedNotice(true);
      } catch {
        // Best-effort: the card-on-file list still reflects reality on next load.
      } finally {
        params.delete('card_saved');
        const qs = params.toString();
        window.history.replaceState({}, '', `${window.location.pathname}${qs ? `?${qs}` : ''}`);
        if (!cancelled) void load();
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [load]);

  async function addCard() {
    setSavingCard(true);
    try {
      const res = await fetch('/api/customer/square/save-card-intent', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amountCents: 100 }),
      });
      const data = (await res.json()) as { ok?: boolean; checkoutUrl?: string; error?: string };
      if (data.ok && data.checkoutUrl) {
        window.location.href = data.checkoutUrl;
      } else {
        setError(data.error ?? 'Could not start checkout.');
      }
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setSavingCard(false);
    }
  }

  if (loading) {
    return (
      <div className="rounded-2xl border border-brand-line bg-brand-card/40 p-6 text-sm text-brand-mute">
        Loading your payments…
      </div>
    );
  }

  return (
    <section className="space-y-6">
      <header>
        <h1 className="text-2xl font-semibold text-brand-text">Payments</h1>
        <p className="mt-1 text-sm text-brand-mute">
          Receipts for every Brick Labor charge on your card. Cards on file are stored securely by
          Square — we never see the full number.
        </p>
      </header>

      {cardSavedNotice ? (
        <div
          role="status"
          className="rounded-2xl border border-emerald-500/40 bg-emerald-500/10 p-4 text-sm text-emerald-100"
        >
          Card saved. Your payment method is verified — you&rsquo;ll only be charged after the job
          is complete.
        </div>
      ) : null}

      {!linked ? (
        <div className="rounded-2xl border border-brand-line bg-brand-card/40 p-5 text-sm text-brand-mute">
          We have not linked your Square wallet yet. Book a job or add a card to get started.
        </div>
      ) : null}

      <article className="rounded-2xl border border-brand-line bg-brand-card/40 p-5">
        <header className="mb-3 flex items-center justify-between">
          <h2 className="text-base font-semibold text-brand-text">Cards on file</h2>
          <button
            type="button"
            onClick={() => void addCard()}
            disabled={savingCard}
            className="rounded-lg border border-brand-line bg-brand-card px-3 py-1.5 text-sm text-brand-text hover:bg-brand-line disabled:opacity-60"
          >
            {savingCard ? 'Opening Square…' : 'Add a card'}
          </button>
        </header>
        {cards.length === 0 ? (
          <p className="text-sm text-brand-mute">No saved cards yet.</p>
        ) : (
          <ul className="divide-y divide-brand-line/60">
            {cards.map((c, i) => (
              <li
                key={`${c.brand}-${c.last4}-${i}`}
                className="flex items-center justify-between py-2 text-sm"
              >
                <span className="text-brand-text">
                  {c.brand} ••{c.last4}
                </span>
                <span className="text-xs text-brand-mute">
                  exp {String(c.expMonth).padStart(2, '0')}/{String(c.expYear).slice(-2)}
                </span>
              </li>
            ))}
          </ul>
        )}
      </article>

      <article className="rounded-2xl border border-brand-line bg-brand-card/40 p-5">
        <h2 className="mb-3 text-base font-semibold text-brand-text">Charge history</h2>
        {error ? (
          <p className="mb-3 rounded-lg border border-rose-500/40 bg-rose-500/10 px-3 py-2 text-sm text-rose-200">
            {error}
          </p>
        ) : null}
        {payments.length === 0 ? (
          <p className="rounded-lg border border-dashed border-brand-line px-3 py-6 text-center text-sm text-brand-mute">
            No charges on file yet.
          </p>
        ) : (
          <ul className="divide-y divide-brand-line/60">
            {payments.map((p) => (
              <li key={p.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span
                      className={`rounded-md border px-2 py-0.5 text-xs uppercase tracking-wide ${statusBadge(
                        p.status,
                      )}`}
                    >
                      {p.status}
                    </span>
                    <span className="text-xs text-brand-mute">{formatDate(p.createdAt)}</span>
                  </div>
                  <div className="mt-1 text-sm text-brand-text">
                    <strong className="tabular-nums">{formatMoney(p.amountCents)}</strong>
                    {p.cardBrand ? (
                      <span className="ml-2 text-brand-mute">
                        {p.cardBrand} ••{p.cardLast4}
                      </span>
                    ) : null}
                    {p.refundAmountCents ? (
                      <span className="ml-2 text-rose-300">
                        refunded {formatMoney(p.refundAmountCents)}
                      </span>
                    ) : null}
                  </div>
                  {p.bookingId ? (
                    <a
                      href={`/track/${p.bookingId}`}
                      className="mt-1 inline-block text-xs text-brand-accent hover:underline"
                    >
                      View booking →
                    </a>
                  ) : null}
                </div>
                {p.receiptUrl ? (
                  <a
                    href={p.receiptUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="rounded-lg border border-brand-line bg-brand-bg px-3 py-1.5 text-sm text-brand-accent hover:bg-brand-line"
                  >
                    Receipt
                  </a>
                ) : null}
              </li>
            ))}
          </ul>
        )}
      </article>
    </section>
  );
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
