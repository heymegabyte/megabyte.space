import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { useState } from 'react';

/**
 * TipJar — one-tap tip presets ($5/$10/$20/Custom) for a single booking.
 *
 * POSTs to `/api/work/tips/record/:bookingId` with `{ totalCents, channel,
 * customerMessage }`. The recording endpoint is the canonical pool-tip
 * ingest path (see workers/main/src/routes/work-tips.ts). If the request returns
 * 401 (the route is currently admin-gated, with a customer-tip path
 * planned via the rating modal), the component degrades to a friendly
 * "queued — add it when you rate the crew" message instead of dying.
 *
 * Optimistic UX: each button disables on click, the chosen amount appears
 * as the active pill, and on success the strip switches to a confirmation
 * card with a "Tip another amount" reset.
 */

interface Props {
  bookingId: string;
  crewName?: string;
}

const PRESETS_CENTS = [500, 1000, 2000] as const;

/**
 * The custom-tip Send button shows "Sending…" while a CUSTOM (non-preset) tip is in-flight.
 * Each preset button ($5/$10/$20) shows its OWN "Sending…" (when `busyCents === cents`), so the
 * custom button lights only for non-preset amounts — never gated on an amount threshold (the old
 * `busyCents > 2000` left the default $15 + every small custom tip showing "Send" mid-POST).
 */
export function customTipSending(busyCents: number | null): boolean {
  return busyCents !== null && !(PRESETS_CENTS as readonly number[]).includes(busyCents);
}

type ServerResp = { ok?: boolean; tipId?: string; error?: string; code?: string };

async function postTip(
  bookingId: string,
  totalCents: number,
  crewName: string | undefined,
): Promise<ServerResp> {
  try {
    const res = await fetch(`/api/work/tips/record/${encodeURIComponent(bookingId)}`, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        totalCents,
        channel: 'square',
        customerMessage: crewName ? `Customer tip for ${crewName}` : 'Customer tip',
      }),
    });
    const body = (await res.json().catch(() => ({}))) as ServerResp;
    if (!res.ok) return { ok: false, error: body.error ?? `http_${res.status}` };
    return { ok: true, ...body };
  } catch (err) {
    return { ok: false, error: (err as Error).message || 'network_error' };
  }
}

export function TipJar({ bookingId, crewName }: Props) {
  useThemeToolsSurface('tip-jar');
  const [busyCents, setBusyCents] = useState<number | null>(null);
  const [sentCents, setSentCents] = useState<number | null>(null);
  const [error, setError] = useState('');
  const [showCustom, setShowCustom] = useState(false);
  const [customDollars, setCustomDollars] = useState<string>('15');

  async function submit(totalCents: number) {
    if (totalCents <= 0 || busyCents !== null) return;
    setBusyCents(totalCents);
    setError('');
    const resp = await postTip(bookingId, totalCents, crewName);
    setBusyCents(null);
    if (resp.ok) {
      setSentCents(totalCents);
      setShowCustom(false);
      return;
    }
    if (resp.error === 'unauthorized') {
      // Graceful degrade — tip flow goes through the rating modal post-job.
      setError('Tipping opens after the crew checks out. We’ll text you a link.');
      return;
    }
    setError(resp.error ?? 'Could not send tip. Try again.');
  }

  if (sentCents !== null) {
    return (
      <section
        className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
        aria-labelledby="tipjar-confirm-title"
        aria-live="polite"
      >
        <p
          id="tipjar-confirm-title"
          className="font-mono text-[10px] uppercase tracking-widest text-brand-accent"
        >
          Tip sent
        </p>
        <p className="mt-2 text-sm text-brand-ink">
          Thanks — <strong>${(sentCents / 100).toFixed(2)}</strong> goes 100% to the crew.
        </p>
        <button
          type="button"
          onClick={() => {
            setSentCents(null);
            setError('');
          }}
          data-bcl-action="tipjar-reset"
          className="mt-3 text-xs text-brand-mute underline hover:text-brand-accent"
        >
          Tip another amount
        </button>
      </section>
    );
  }

  return (
    <section
      className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
      aria-labelledby="tipjar-title"
    >
      <div className="flex items-baseline justify-between gap-3">
        <p
          id="tipjar-title"
          className="font-mono text-[10px] uppercase tracking-widest text-brand-accent"
        >
          Tip the crew
        </p>
        <span className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
          100% to crew
        </span>
      </div>
      <p className="mt-1 text-xs text-brand-mute">
        {crewName ? `For ${crewName}.` : 'Every dollar goes to the workers on this job.'}
      </p>
      <div className="mt-3 flex flex-wrap gap-2">
        {PRESETS_CENTS.map((cents) => (
          <button
            key={cents}
            type="button"
            onClick={() => void submit(cents)}
            disabled={busyCents !== null}
            data-bcl-action={`tipjar-preset-${cents}`}
            className="rounded-md border border-brand-line bg-bg-primary px-4 py-2 text-sm font-semibold text-brand-ink hover:border-brand-accent hover:bg-brand-accent/5 disabled:opacity-50"
          >
            {busyCents === cents ? 'Sending…' : `$${cents / 100}`}
          </button>
        ))}
        <button
          type="button"
          onClick={() => setShowCustom((v) => !v)}
          disabled={busyCents !== null}
          data-bcl-action="tipjar-toggle-custom"
          aria-expanded={showCustom}
          className="rounded-md border border-brand-line bg-bg-primary px-4 py-2 text-sm font-semibold text-brand-mute hover:border-brand-accent hover:text-brand-accent disabled:opacity-50"
        >
          Custom
        </button>
      </div>
      {showCustom && (
        <div className="mt-3 flex items-center gap-2">
          <span className="text-sm text-brand-ink">$</span>
          <input
            type="number"
            min={1}
            max={500}
            step={1}
            value={customDollars}
            onChange={(e) => setCustomDollars(e.currentTarget.value)}
            aria-label="Custom tip amount in dollars"
            className="w-24 rounded-md border border-brand-line bg-bg-primary px-2 py-1.5 text-sm text-brand-ink focus:border-brand-accent focus:outline-none"
          />
          <button
            type="button"
            onClick={() => {
              const n = Math.round(Number(customDollars) || 0);
              if (n < 1 || n > 500) {
                setError('Enter a tip between $1 and $500.');
                return;
              }
              void submit(n * 100);
            }}
            disabled={busyCents !== null}
            data-bcl-action="tipjar-custom-submit"
            className="rounded-md bg-brand-accent px-3 py-1.5 text-sm font-semibold text-black hover:brightness-110 disabled:opacity-50"
          >
            {customTipSending(busyCents) ? 'Sending…' : 'Send'}
          </button>
        </div>
      )}
      {error && (
        <p className="mt-3 text-xs text-red-400" role="alert">
          {error}
        </p>
      )}
    </section>
  );
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
