import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useMemo, useState } from 'react';
import type { JobListItem } from '../../customer-jobs.js';
import { formatJobDate, paymentStatusBadgeClass } from '../../customer-jobs.js';

/**
 * §13b — month-grid calendar that sits beneath the 7-day windowed list so
 * the user can scan dates further out. Pure DOM (no react-day-picker — the
 * booking flow uses a native `<input type="date">`, so there's nothing to
 * extract). Selecting a day shows the jobs on that day in a side panel; the
 * default selection is today. Days with jobs get a colored dot per job
 * payment-status.
 *
 * Keyboard: each day is a native `<button>` — Tab to reach it, Enter/Space to
 * select; `aria-pressed` flags the selected cell + `aria-label` carries the full
 * date + job count. Deliberately NOT `role="grid"`: a grid role without
 * arrow-key 2D cell navigation (the ARIA grid pattern) is a malformed, axe-blind
 * broken promise — AT announces "grid" and arrows do nothing. This mirrors the
 * live Angular dashboard calendar policy (dispatch/week/day views strip grid
 * roles for the same reason) and is locked by
 * `tests/unit/calendar-no-malformed-grid.test.ts`.
 */
interface UpcomingCalendarProps {
  readonly items: ReadonlyArray<JobListItem>;
  readonly onOpenJob?: (id: string) => void;
}

const WEEKDAY_LABELS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'] as const;

function ymd(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
    d.getDate(),
  ).padStart(2, '0')}`;
}

function isSameYmd(a: Date, b: Date): boolean {
  return ymd(a) === ymd(b);
}

export function UpcomingCalendar({ items, onOpenJob }: UpcomingCalendarProps): JSX.Element {
  useThemeToolsSurface('upcoming-calendar');
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const [view, setView] = useState<{ y: number; m: number }>({
    y: today.getFullYear(),
    m: today.getMonth(),
  });
  const [selected, setSelected] = useState<string>(ymd(today));

  // Group jobs by yyyy-mm-dd for O(1) lookup per day cell.
  const byDay = useMemo(() => {
    const map = new Map<string, JobListItem[]>();
    for (const it of items) {
      const d = (it.preferredDate || '').trim();
      if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) continue;
      const arr = map.get(d) ?? [];
      arr.push(it);
      map.set(d, arr);
    }
    return map;
  }, [items]);

  // Build a 6-row × 7-col grid that always includes leading + trailing days
  // from the neighboring months so the visual block is rectangular.
  const cells = useMemo(() => {
    const firstOfMonth = new Date(view.y, view.m, 1);
    const lead = firstOfMonth.getDay();
    const start = new Date(firstOfMonth);
    start.setDate(start.getDate() - lead);
    const out: { date: Date; key: string; inMonth: boolean; isToday: boolean }[] = [];
    for (let i = 0; i < 42; i++) {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      out.push({
        date: d,
        key: ymd(d),
        inMonth: d.getMonth() === view.m,
        isToday: isSameYmd(d, today),
      });
    }
    return out;
  }, [view, today]);

  const selectedJobs = byDay.get(selected) ?? [];
  const monthLabel = new Date(view.y, view.m, 1).toLocaleDateString('en-US', {
    month: 'long',
    year: 'numeric',
  });

  const shift = (delta: number) => {
    setView((v) => {
      const m = v.m + delta;
      const y = v.y + Math.floor(m / 12);
      const newM = ((m % 12) + 12) % 12;
      return { y, m: newM };
    });
  };

  return (
    <section
      aria-label="Upcoming jobs calendar"
      className="rounded-2xl border border-brand-line bg-brand-card p-5 mt-6"
    >
      <header className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-extrabold">Browse further out</h3>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => shift(-1)}
            aria-label="Previous month"
            className="rounded-md border border-brand-line bg-brand-bg/40 px-2.5 py-1 text-sm text-brand-ink hover:border-brand-accent"
          >
            ‹
          </button>
          <span className="px-3 text-sm font-semibold tabular-nums min-w-[10ch] text-center">
            {monthLabel}
          </span>
          <button
            type="button"
            onClick={() => shift(1)}
            aria-label="Next month"
            className="rounded-md border border-brand-line bg-brand-bg/40 px-2.5 py-1 text-sm text-brand-ink hover:border-brand-accent"
          >
            ›
          </button>
          <button
            type="button"
            onClick={() => {
              const t = new Date();
              setView({ y: t.getFullYear(), m: t.getMonth() });
              setSelected(ymd(t));
            }}
            className="ml-2 rounded-md border border-brand-line bg-brand-bg/40 px-2.5 py-1 text-xs text-brand-mute hover:text-brand-ink hover:border-brand-accent"
          >
            Today
          </button>
        </div>
      </header>

      <div
        aria-hidden="true"
        className="grid grid-cols-7 gap-1 text-center mb-3"
      >
        {WEEKDAY_LABELS.map((w) => (
          <div
            key={w}
            className="text-[10px] uppercase tracking-wider text-brand-mute font-semibold py-1"
          >
            {w}
          </div>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-1">
        {cells.map((cell) => {
          const jobs = byDay.get(cell.key) ?? [];
          const isSelected = cell.key === selected;
          return (
            <button
              key={cell.key}
              type="button"
              aria-pressed={isSelected}
              aria-label={`${formatJobDate(cell.key)}${jobs.length ? `, ${jobs.length} job${jobs.length === 1 ? '' : 's'}` : ''}`}
              onClick={() => setSelected(cell.key)}
              className={`relative aspect-square rounded-md border text-xs transition focus:outline-none focus:ring-2 focus:ring-brand-accent ${
                isSelected
                  ? 'border-brand-accent bg-brand-accent/15 text-brand-ink font-extrabold'
                  : cell.inMonth
                    ? 'border-brand-line bg-brand-bg/30 text-brand-ink hover:border-brand-accent/60'
                    : 'border-transparent text-brand-mute hover:text-brand-ink'
              } ${cell.isToday && !isSelected ? 'ring-1 ring-brand-accent/40' : ''}`}
            >
              <span className="absolute top-0.5 left-1 tabular-nums">{cell.date.getDate()}</span>
              {jobs.length > 0 && (
                <span className="absolute bottom-1 left-1/2 -translate-x-1/2 flex gap-0.5">
                  {jobs.slice(0, 3).map((j, i) => (
                    <span
                      key={i}
                      aria-hidden="true"
                      className={`w-1.5 h-1.5 rounded-full ${dotClass(j.paymentStatus)}`}
                    />
                  ))}
                </span>
              )}
            </button>
          );
        })}
      </div>

      <div className="mt-5 border-t border-brand-line pt-4">
        <p className="text-sm font-semibold mb-2">
          {selectedJobs.length > 0
            ? `${selectedJobs.length} job${selectedJobs.length === 1 ? '' : 's'} on ${formatJobDate(selected)}`
            : `Nothing scheduled for ${formatJobDate(selected)}.`}
        </p>
        {selectedJobs.length > 0 && (
          <ul className="space-y-2" aria-label="Jobs on selected day">
            {selectedJobs.map((j) => (
              <li
                key={j.id}
                className="flex items-center justify-between gap-3 rounded-md border border-brand-line bg-brand-bg/30 px-3 py-2 text-sm"
              >
                <div className="min-w-0">
                  <p className="font-semibold capitalize truncate">
                    {(j.service || 'crew').replace(/-/g, ' ')} · {j.preferredTime}
                  </p>
                  <p className="text-xs text-brand-mute truncate">{j.address || j.city}</p>
                </div>
                <span
                  className={`shrink-0 inline-block rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${paymentStatusBadgeClass(j.paymentStatus)}`}
                >
                  {j.paymentStatus}
                </span>
                {onOpenJob && (
                  <button
                    type="button"
                    onClick={() => onOpenJob(j.id)}
                    className="shrink-0 rounded-md border border-brand-line px-2 py-1 text-xs hover:border-brand-accent"
                  >
                    Open
                  </button>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}

function dotClass(s: JobListItem['paymentStatus']): string {
  switch (s) {
    case 'paid':
    case 'completed':
      return 'bg-emerald-400';
    case 'confirmed':
      return 'bg-blue-400';
    case 'canceled':
      return 'bg-zinc-400';
    case 'defunct':
      return 'bg-orange-400';
    case 'pending':
    default:
      return 'bg-yellow-400';
  }
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
