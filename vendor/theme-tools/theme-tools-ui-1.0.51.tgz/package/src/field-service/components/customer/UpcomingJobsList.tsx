import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useMemo } from 'react';
import {
  formatJobDate,
  formatMoney,
  paymentStatusBadgeClass,
  paymentStatusLabel,
} from '../../customer-jobs.js';
import type { JobListItem } from '../../customer-jobs.js';
import { PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';
import { JobThumbStrip } from './JobThumbStrip.js';
import { UpcomingCalendar } from './UpcomingCalendar.js';
import { WeatherRescheduleBanner } from '../WeatherRescheduleBanner.js';

interface UpcomingJobsListProps {
  items: ReadonlyArray<JobListItem>;
  loading?: boolean;
}

const UPCOMING_STATUSES = new Set([
  'pending_payment',
  'pending_confirmation',
  'paid',
  'paid_in_full',
  'confirmed',
  'reminded',
  'in_progress',
  'en_route',
]);

const SEVEN_DAY_MS = 7 * 24 * 60 * 60 * 1000;

// Section 13b — a job is "happening now" if start time has passed but
// (start + estimated duration) hasn't. Estimated duration uses booking
// hours field, +30 min slack for setup/cleanup.
function jobWindowState(b: JobListItem, start: Date): 'upcoming' | 'happening' | 'past' {
  if (Number.isNaN(start.getTime())) return 'upcoming';
  const now = Date.now();
  const startMs = start.getTime();
  const durationMs = (Number(b.hours) || 2) * 60 * 60 * 1000 + 30 * 60 * 1000;
  if (now < startMs) return 'upcoming';
  if (now < startMs + durationMs) return 'happening';
  return 'past';
}

// Section 13a — bulletproof time/date formatters. API can ship the time
// as "8", "08:30", "8:30am", "08:30:00", or empty — all need to render
// cleanly, never as "8, NaN, NaN".
function formatTime(t: string | null | undefined): string {
  if (!t) return '—';
  const cleaned = String(t).trim().toLowerCase();
  // Handle "8:30 am" / "8:30pm" / "08:30" / "8" cases
  const ampmMatch = cleaned.match(/^(\d{1,2})(?::(\d{2}))?\s*(am|pm)?$/);
  if (!ampmMatch) return '—';
  const hRaw = Number(ampmMatch[1]);
  const mRaw = ampmMatch[2] != null ? Number(ampmMatch[2]) : 0;
  if (!Number.isFinite(hRaw) || !Number.isFinite(mRaw) || hRaw < 0 || hRaw > 23 || mRaw > 59) {
    return '—';
  }
  let h24 = hRaw;
  if (ampmMatch[3] === 'pm' && h24 < 12) h24 += 12;
  if (ampmMatch[3] === 'am' && h24 === 12) h24 = 0;
  const period = h24 >= 12 ? 'PM' : 'AM';
  const h12 = ((h24 + 11) % 12) + 1;
  return `${h12}:${String(mRaw).padStart(2, '0')} ${period}`;
}

function startDate(b: JobListItem): Date {
  const date = (b.preferredDate || '').trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return new Date(NaN);
  const time = (b.preferredTime || '00:00').trim();
  const timeMatch = time.match(/^(\d{1,2})(?::(\d{2}))?/);
  const h = timeMatch ? String(Number(timeMatch[1] ?? 0)).padStart(2, '0') : '00';
  const m = timeMatch && timeMatch[2] != null ? timeMatch[2] : '00';
  const d = new Date(`${date}T${h}:${m}:00`);
  return Number.isNaN(d.getTime()) ? new Date(NaN) : d;
}

function humanCountdown(target: Date): string {
  if (Number.isNaN(target.getTime())) return 'date pending';
  const ms = target.getTime() - Date.now();
  if (ms < 0) return 'happening now';
  const minutes = Math.floor(ms / 60000);
  if (minutes < 60) return `in ${Math.max(1, minutes)} min`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `in ${hours}h ${minutes % 60}m`;
  const days = Math.floor(hours / 24);
  return `in ${days}d ${hours % 24}h`;
}

/**
 * Renders the customer's scheduled/in-progress jobs with a live-tracking
 * deep link per row. Distinct from `MyBookingsList` which only shows
 * already-finished jobs.
 *
 * §13b — splits the upcoming set into a 7-day windowed list (rendered
 * first) and a month calendar below it for browsing further out. Defunct
 * (past-dated, never-paid) bookings auto-drop from this list — the API now
 * derives `paymentStatus: 'defunct'` for those and they land in Past via
 * MyBookingsList's PAST_STATUSES filter.
 *
 * §13c — every row carries an inline 2-up before/after thumb strip; tap a
 * thumb to open the lightbox.
 */
export function UpcomingJobsList({ items, loading }: UpcomingJobsListProps) {
  useThemeToolsSurface('upcoming-jobs-list');
  const allUpcoming = useMemo(
    () =>
      items
        .filter((i) => UPCOMING_STATUSES.has(i.status))
        .filter((i) => i.paymentStatus !== 'defunct' && i.paymentStatus !== 'canceled')
        .filter((i) => jobWindowState(i, startDate(i)) !== 'past')
        .slice()
        .sort((a, b) => startDate(a).getTime() - startDate(b).getTime()),
    [items],
  );

  const next7Days = useMemo(() => {
    const horizon = Date.now() + SEVEN_DAY_MS;
    return allUpcoming.filter((b) => {
      const t = startDate(b).getTime();
      return Number.isFinite(t) && t <= horizon;
    });
  }, [allUpcoming]);

  if (loading && allUpcoming.length === 0) {
    return <p className="text-brand-mute text-sm">Loading upcoming jobs…</p>;
  }

  if (allUpcoming.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed border-brand-line bg-brand-card p-8 text-center">
        <h3 className="text-lg font-extrabold text-brand-ink mb-1">No upcoming jobs</h3>
        <p className="text-brand-mute text-sm mb-4">
          Crews booked same-day in Newark — flat $50/hr/person.
        </p>
        <a href="/book" className="btn-primary inline-block">
          Book a crew →
        </a>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-end justify-between mb-3 flex-wrap gap-2">
        <h2 className="text-xl font-extrabold">Next 7 days</h2>
        <p className="text-xs text-brand-mute">
          {next7Days.length} of {allUpcoming.length} scheduled
        </p>
      </div>
      {next7Days.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-brand-line bg-brand-card p-6 text-center text-brand-mute text-sm">
          Nothing in the next 7 days — see the calendar below to browse further out.
        </div>
      ) : (
        <ul className="space-y-3" aria-label="Upcoming jobs this week">
          {next7Days.map((b) => {
            const start = startDate(b);
            const windowState = jobWindowState(b, start);
            const statusBadge =
              windowState === 'happening'
                ? {
                    text: 'Happening now',
                    cls: 'border-emerald-500/50 bg-emerald-500/15 text-emerald-200',
                  }
                : null;
            return (
              <li
                key={b.id}
                className={`rounded-2xl border bg-brand-card p-5 transition ${
                  windowState === 'happening'
                    ? 'border-emerald-500/40 hover:border-emerald-400'
                    : 'border-brand-line hover:border-brand-accent/60'
                }`}
              >
                <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
                  <div>
                    <h3 className="text-lg font-bold capitalize">
                      {(b.service || 'crew').replace(/-/g, ' ')}
                    </h3>
                    <p className="text-sm text-brand-mute">
                      {formatJobDate(b.preferredDate)} · {formatTime(b.preferredTime)} ·{' '}
                      <strong className="text-brand-ink">
                        {windowState === 'happening' ? '⚡ happening now' : humanCountdown(start)}
                      </strong>
                    </p>
                  </div>
                  {statusBadge && (
                    <span
                      className={`inline-block rounded-full border px-3 py-1 text-xs font-semibold uppercase tracking-wide ${statusBadge.cls}`}
                    >
                      {statusBadge.text}
                    </span>
                  )}
                  <span
                    className={`inline-block rounded-full border px-3 py-1 text-xs font-semibold uppercase tracking-wide ${paymentStatusBadgeClass(
                      b.paymentStatus,
                    )}`}
                  >
                    {paymentStatusLabel(b.paymentStatus)}
                  </span>
                </div>
                <dl className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm mb-4">
                  <div>
                    <dt className="text-brand-mute">Crew</dt>
                    <dd className="text-brand-ink font-semibold">{b.crew} people</dd>
                  </div>
                  <div>
                    <dt className="text-brand-mute">Hours</dt>
                    <dd className="text-brand-ink font-semibold">{b.hours}</dd>
                  </div>
                  <div>
                    <dt className="text-brand-mute">Total</dt>
                    <dd className="text-brand-ink font-semibold">{formatMoney(b.totalCents)}</dd>
                  </div>
                  <div>
                    <dt className="text-brand-mute">ID</dt>
                    <dd className="text-brand-ink font-mono text-xs break-all">
                      {b.id.slice(0, 8)}
                    </dd>
                  </div>
                </dl>
                <JobThumbStrip item={b} variant="inline" />
                <WeatherRescheduleBanner bookingId={b.id} />
                <div className="flex flex-wrap gap-2 mt-4">
                  {/* Section 13b — drop the underline-hover specifically on the
                      live-tracking pill per the optimization brief. */}
                  <a
                    href={`/track/${b.id}`}
                    className="rounded-md border border-brand-line px-3 py-1.5 text-xs text-brand-ink hover:border-brand-accent hover:bg-brand-accent/5 transition-colors no-underline"
                  >
                    Live tracking →
                  </a>
                  <a
                    href={`/api/booking/ics?id=${b.id}`}
                    className="rounded-md border border-brand-line px-3 py-1.5 text-xs text-brand-ink hover:border-brand-accent hover:bg-brand-accent/5 transition-colors"
                  >
                    Add to calendar (.ics)
                  </a>
                  <a
                    href={PHONE_TEL_HREF}
                    className="rounded-md border border-brand-line px-3 py-1.5 text-xs text-brand-mute hover:border-brand-accent hover:text-brand-accent transition-colors"
                    data-bcl-phone-cta="me-upcoming"
                  >
                    Call about this job
                  </a>
                </div>
              </li>
            );
          })}
        </ul>
      )}

      <UpcomingCalendar items={allUpcoming} />
    </div>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
