import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { useState } from 'react';
import type { Booking } from '@theme.tools/scheduling/field-service/customer-types';
import { bookingStart } from '@theme.tools/scheduling/field-service/customer-date-utils';

interface AiScheduleOptimizerProps {
  bookings: Booking[];
  /** Hit when the user accepts a suggestion — usually opens QuickSchedulePopover with the slot prefilled. */
  onAccept: (suggestion: { weekday: number; hour: number; service: string }) => void;
}

interface Suggestion {
  weekday: number; // 0 Sun .. 6 Sat
  hour: number; // 0..23
  service: string;
  rationale: string;
}

const WEEKDAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'] as const;

/**
 * AI-style schedule optimizer. Pure client-side heuristic by default — sums
 * historical bookings per (weekday × hour × service) tuple and surfaces the
 * top three slots. Calls /api/ai-chat/message when ANTHROPIC is wired to refine
 * the rationale; falls back silently if the endpoint 404s or rate-limits.
 */
export function AiScheduleOptimizer({ bookings, onAccept }: AiScheduleOptimizerProps) {
  useThemeToolsSurface('ai-schedule-optimizer');
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);

  function localSuggest(): Suggestion[] {
    if (bookings.length === 0) {
      return [
        {
          weekday: 6,
          hour: 9,
          service: 'lawn',
          rationale: 'Saturday mornings book fastest — secure your slot.',
        },
      ];
    }
    const buckets = new Map<string, number>();
    for (const b of bookings) {
      const d = bookingStart(b);
      const key = `${d.getDay()}|${d.getHours()}|${(b.service || 'other').split(',')[0]}`;
      buckets.set(key, (buckets.get(key) ?? 0) + 1);
    }
    const ranked = [...buckets.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([key, count]) => {
        const [wd, hr, service] = key.split('|');
        return {
          weekday: Number(wd),
          hour: Number(hr),
          service: service || 'other',
          rationale: `You've booked this slot ${count}× before. Keep the rhythm.`,
        };
      });
    return ranked;
  }

  async function runOptimizer() {
    setLoading(true);
    setOpen(true);
    const base = localSuggest();
    setSuggestions(base);
    try {
      const compact = bookings.slice(0, 12).map((b) => ({
        date: b.preferred_date,
        time: b.preferred_time,
        service: (b.service || '').split(',')[0],
        hours: b.hours,
      }));
      const res = await fetch('/api/ai-chat/message', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          messages: [
            {
              role: 'user',
              content: [
                'You are a scheduling concierge for Brick Labor (Newark, NJ).',
                'Look at this customer history and propose ONE ideal recurring slot.',
                'Format: WEEKDAY HH:MM SERVICE — one-sentence rationale (≤140 chars).',
                `History: ${JSON.stringify(compact)}`,
              ].join('\n'),
            },
          ],
        }),
      });
      if (res.ok) {
        const data = (await res.json()) as { reply?: string };
        if (data.reply) {
          base[0] = { ...base[0]!, rationale: data.reply.slice(0, 180) };
          setSuggestions([...base]);
        }
      }
    } catch {
      /* offline / endpoint unavailable — local suggestion stands */
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="relative">
      <button
        type="button"
        onClick={runOptimizer}
        className="rounded-md border border-brand-accent/40 bg-brand-accent/10 px-3 py-2 text-xs font-extrabold text-brand-accent hover:bg-brand-accent/20 min-h-[36px]"
      >
        ✨ AI optimize
      </button>
      {open && (
        <div className="absolute right-0 mt-2 w-80 z-40 rounded-2xl border border-brand-line bg-bg-elevated p-4 shadow-glow animate-fade-up">
          <div className="flex items-start justify-between gap-2 mb-3">
            <div>
              <p className="text-[10px] uppercase tracking-wider text-brand-accent font-bold">
                Smart suggestions
              </p>
              <h3 className="text-sm font-extrabold text-brand-ink">
                {loading ? 'Analyzing your pattern…' : 'Your best recurring slot'}
              </h3>
            </div>
            <button
              type="button"
              onClick={() => setOpen(false)}
              aria-label="Close suggestions"
              className="rounded-md border border-brand-line px-2 py-1 text-xs text-brand-mute hover:text-brand-ink min-h-[28px]"
            >
              ✕
            </button>
          </div>
          <ul className="space-y-2">
            {suggestions.map((s, i) => (
              <li key={i} className="rounded-lg border border-brand-line bg-bg-primary/60 p-3">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm font-extrabold text-brand-ink capitalize">
                    {WEEKDAY_NAMES[s.weekday]} · {s.hour}:00 · {s.service.replace('-', ' ')}
                  </p>
                  <button
                    type="button"
                    onClick={() => onAccept(s)}
                    className="rounded-md bg-brand-accent px-2 py-1 text-[10px] font-extrabold text-bg-primary hover:bg-brand-accentHover min-h-[28px]"
                  >
                    Use
                  </button>
                </div>
                <p className="text-xs text-brand-mute">{s.rationale}</p>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
