import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import type { Booking } from '@theme.tools/scheduling/field-service/customer-types';
import { colorForService } from '@theme.tools/scheduling/field-service/customer-types';
import { bookingEnd, bookingStart, formatTime12 } from '@theme.tools/scheduling/field-service/customer-date-utils';

interface EventHoverPreviewProps {
  booking: Booking;
  anchor: { x: number; y: number };
}

export function EventHoverPreview({ booking: b, anchor }: EventHoverPreviewProps) {
  useThemeToolsSurface('event-hover-preview');
  const palette = colorForService(b.service);
  const start = bookingStart(b);
  const end = bookingEnd(b);
  const total = `$${(b.total_cents / 100).toFixed(2)}`;

  const left = Math.min(window.innerWidth - 308, Math.max(8, anchor.x + 12));
  const top = Math.min(window.innerHeight - 220, Math.max(8, anchor.y + 12));

  return (
    <div
      role="tooltip"
      className="fixed z-[55] w-72 rounded-xl border border-brand-line bg-bg-elevated p-4 shadow-glow pointer-events-none animate-fade-up"
      style={{ left, top }}
    >
      <div className="flex items-center gap-2 mb-2">
        <span aria-hidden className="h-2 w-2 rounded-full" style={{ background: palette.dot }} />
        <p className="text-xs uppercase tracking-wider font-bold" style={{ color: palette.text }}>
          {palette.label}
        </p>
        <span className="ml-auto rounded-full border border-brand-line bg-bg-primary/60 px-2 py-0.5 text-[10px] font-mono uppercase text-brand-mute">
          {b.status.replace('_', ' ')}
        </span>
      </div>
      <p className="text-sm font-extrabold text-brand-ink mb-1">
        {start.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })}{' '}
        · {formatTime12(start.getHours(), start.getMinutes())} –{' '}
        {formatTime12(end.getHours(), end.getMinutes())}
      </p>
      <dl className="grid grid-cols-2 gap-2 text-xs">
        <div>
          <dt className="text-brand-mute">Crew</dt>
          <dd className="text-brand-ink font-semibold">
            {b.crew_size} {b.crew_size === 1 ? 'person' : 'people'}
          </dd>
        </div>
        <div>
          <dt className="text-brand-mute">Hours</dt>
          <dd className="text-brand-ink font-semibold">{b.hours}</dd>
        </div>
        <div>
          <dt className="text-brand-mute">Total</dt>
          <dd className="text-brand-ink font-semibold">{total}</dd>
        </div>
        <div>
          <dt className="text-brand-mute">ID</dt>
          <dd className="text-brand-ink font-mono text-[10px]">{b.id.slice(0, 8)}</dd>
        </div>
      </dl>
      {b.customer_address && (
        <p className="mt-2 text-xs text-brand-mute truncate">📍 {b.customer_address}</p>
      )}
      <p className="mt-2 text-[10px] text-brand-mute">Click to edit · drag to reschedule</p>
    </div>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
