import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
interface KeyboardShortcutsModalProps {
  onClose: () => void;
}

const SHORTCUTS: ReadonlyArray<readonly [string, string]> = [
  ['d', 'Day view'],
  ['w', 'Week view'],
  ['m', 'Month view'],
  ['a', 'Agenda view'],
  ['t', 'Jump to today'],
  ['j', 'Previous period'],
  ['k', 'Next period'],
  ['n', 'New booking'],
  ['/', 'Focus search'],
  ['?', 'Show shortcuts'],
  ['Esc', 'Close popover'],
  ['Cmd+P', 'Print current view'],
];

export function KeyboardShortcutsModal({ onClose }: KeyboardShortcutsModalProps) {
  useThemeToolsSurface('keyboard-shortcuts-modal');
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Keyboard shortcuts"
      className="fixed inset-0 z-[70] grid place-items-center bg-bg-primary/70 backdrop-blur-sm p-4 animate-fade-up"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-md rounded-2xl border border-brand-line bg-bg-elevated p-6 shadow-glow">
        <div className="flex items-start justify-between gap-3 mb-4">
          <div>
            <p className="text-[10px] uppercase tracking-wider text-brand-accent font-bold">
              Calendar
            </p>
            <h2 className="text-xl font-extrabold text-brand-ink">Keyboard shortcuts</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close shortcuts"
            className="rounded-md border border-brand-line px-2 py-1 text-xs text-brand-mute hover:text-brand-ink hover:border-brand-accent min-h-[32px]"
          >
            Esc
          </button>
        </div>
        <ul className="space-y-1.5">
          {SHORTCUTS.map(([key, desc]) => (
            <li
              key={key}
              className="flex items-center justify-between rounded-md border border-brand-line bg-bg-primary/40 px-3 py-2 text-sm"
            >
              <span className="text-brand-mute">{desc}</span>
              <kbd className="rounded-md border border-brand-line bg-bg-elevated px-2 py-0.5 text-xs font-mono text-brand-ink">
                {key}
              </kbd>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
