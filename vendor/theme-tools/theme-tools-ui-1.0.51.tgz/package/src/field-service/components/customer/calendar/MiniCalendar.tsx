import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useMemo } from 'react';
import type { Booking } from '@theme.tools/scheduling/field-service/customer-types';
import { bookingStart, isSameDay, isSameMonth, isToday, monthGrid, toIsoDate } from '@theme.tools/scheduling/field-service/customer-date-utils';

interface MiniCalendarProps {
  anchor: Date;
  selected: Date;
  bookings: Booking[];
  onPick: (d: Date) => void;
  onMonthShift: (delta: number) => void;
}

/**
 * Compact at-a-glance month grid for the left rail. Dots on dates that have
 * bookings; the current day gets the brand-accent ring, the selected day gets
 * a filled chip.
 */
export function MiniCalendar({
  anchor,
  selected,
  bookings,
  onPick,
  onMonthShift,
}: MiniCalendarProps) {
  useThemeToolsSurface('mini-calendar');
  const days = useMemo(() => monthGrid(anchor), [anchor]);
  const dotMap = useMemo(() => {
    const map = new Map<string, number>();
    for (const b of bookings) {
      const k = toIsoDate(bookingStart(b));
      map.set(k, (map.get(k) ?? 0) + 1);
    }
    return map;
  }, [bookings]);

  return (
    <section aria-label="Mini calendar" className="space-y-2">
      <header className="flex items-center justify-between">
        <button
          type="button"
          onClick={() => onMonthShift(-1)}
          aria-label="Previous month"
          className="rounded-md border border-brand-line bg-bg-elevated px-2 py-1 text-xs text-brand-mute hover:text-brand-ink hover:border-brand-accent min-h-[28px]"
        >
          ‹
        </button>
        <p className="text-sm font-extrabold text-brand-ink">
          {anchor.toLocaleDateString(undefined, { month: 'long', year: 'numeric' })}
        </p>
        <button
          type="button"
          onClick={() => onMonthShift(1)}
          aria-label="Next month"
          className="rounded-md border border-brand-line bg-bg-elevated px-2 py-1 text-xs text-brand-mute hover:text-brand-ink hover:border-brand-accent min-h-[28px]"
        >
          ›
        </button>
      </header>
      <ol className="grid grid-cols-7 gap-1 text-center text-[10px] uppercase tracking-wider text-brand-mute">
        {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((d, i) => (
          <li key={i}>{d}</li>
        ))}
      </ol>
      <ol className="grid grid-cols-7 gap-1">
        {days.map((d) => {
          const inMonth = isSameMonth(d, anchor);
          const today = isToday(d);
          const isSel = isSameDay(d, selected);
          const count = dotMap.get(toIsoDate(d)) ?? 0;
          return (
            <li key={toIsoDate(d)}>
              <button
                type="button"
                onClick={() => onPick(d)}
                aria-label={`${d.toDateString()}${count ? `, ${count} booking${count === 1 ? '' : 's'}` : ''}`}
                aria-pressed={isSel}
                className={[
                  'relative grid h-8 w-full place-items-center rounded-md text-xs transition-colors min-h-[24px]',
                  isSel
                    ? 'bg-brand-accent text-bg-primary font-extrabold'
                    : today
                      ? 'border border-brand-accent text-brand-accent font-extrabold'
                      : inMonth
                        ? 'text-brand-ink hover:bg-brand-line'
                        : 'text-brand-mute hover:text-brand-mute',
                ].join(' ')}
              >
                {d.getDate()}
                {count > 0 && !isSel && (
                  <span
                    aria-hidden
                    className="absolute bottom-0.5 h-1 w-1 rounded-full"
                    style={{ background: 'var(--brand-accent)' }}
                  />
                )}
              </button>
            </li>
          );
        })}
      </ol>
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
