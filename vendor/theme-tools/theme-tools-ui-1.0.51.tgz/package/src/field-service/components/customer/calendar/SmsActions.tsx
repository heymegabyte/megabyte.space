import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useState } from 'react';
import type { Booking } from '@theme.tools/scheduling/field-service/customer-types';

interface SmsActionsProps {
  booking: Booking;
}

const REMINDER_PRESETS: ReadonlyArray<readonly [string, number]> = [
  ['24h before', 24 * 60],
  ['4h before', 4 * 60],
  ['1h before', 60],
  ['30 min before', 30],
];

const CREW_TEMPLATES: ReadonlyArray<string> = [
  'Running 15 min late — see you at the door.',
  'Gate code is 1234. Truck access on the side.',
  'Park in the driveway — neighbors will wave you in.',
  'Bring extra tarps if you have them, big load today.',
];

/**
 * Per-event SMS controls. "Remember on this device" stores a local preference
 * only; it deliberately does not claim that a server-side SMS was scheduled.
 * Transactional pre-job reminders follow the confirmed-job cadence.
 * "Send my crew a heads-up" opens the system SMS composer pre-filled.
 */
export function SmsActions({ booking }: SmsActionsProps) {
  useThemeToolsSurface('sms-actions');
  const [openReminder, setOpenReminder] = useState(false);
  const [openHeadsUp, setOpenHeadsUp] = useState(false);
  const [savedTier, setSavedTier] = useState<number | null>(() => {
    try {
      const raw = localStorage.getItem(`bcl_reminder_${booking.id}`);
      return raw ? Number(raw) : null;
    } catch {
      return null;
    }
  });
  const [customMsg, setCustomMsg] = useState(CREW_TEMPLATES[0] ?? '');

  const saveReminder = (mins: number) => {
    try {
      localStorage.setItem(`bcl_reminder_${booking.id}`, String(mins));
    } catch {
      /* noop */
    }
    setSavedTier(mins);
    setOpenReminder(false);
  };

  const phone = booking.customer_phone?.replace(/[^0-9+]/g, '') || '';
  const smsHref = phone ? `sms:${phone}?&body=${encodeURIComponent(customMsg)}` : '#';

  return (
    <div className="flex flex-wrap gap-2">
      <div className="relative">
        <button
          type="button"
          onClick={() => setOpenReminder((v) => !v)}
          className="rounded-md border border-brand-line bg-bg-elevated px-3 py-1.5 text-xs text-brand-ink hover:border-brand-accent min-h-[32px]"
          aria-expanded={openReminder}
        >
          {savedTier ? '🔔 Device reminder saved' : '🔔 Remember on this device'}
        </button>
        {openReminder && (
          <div className="absolute z-30 mt-1 w-56 rounded-xl border border-brand-line bg-bg-elevated p-3 shadow-glow animate-fade-up">
            <p className="text-[10px] uppercase tracking-wider text-brand-mute mb-2">When?</p>
            <p className="mb-2 text-[10px] leading-4 text-brand-mute">
              Saves your preference in this browser. Confirmed-job messages follow Brick&apos;s
              standard reminder schedule.
            </p>
            <ul className="space-y-1">
              {REMINDER_PRESETS.map(([label, mins]) => (
                <li key={mins}>
                  <button
                    type="button"
                    onClick={() => saveReminder(mins)}
                    className={`w-full rounded-md px-2 py-1.5 text-left text-xs hover:bg-brand-line min-h-[28px] ${
                      savedTier === mins
                        ? 'bg-brand-accent/15 text-brand-accent font-bold'
                        : 'text-brand-ink'
                    }`}
                  >
                    {label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
      <div className="relative">
        <button
          type="button"
          onClick={() => setOpenHeadsUp((v) => !v)}
          className="rounded-md border border-brand-line bg-bg-elevated px-3 py-1.5 text-xs text-brand-ink hover:border-brand-accent min-h-[32px]"
          aria-expanded={openHeadsUp}
        >
          💬 Send crew a heads-up
        </button>
        {openHeadsUp && (
          <div className="absolute z-30 mt-1 w-72 rounded-xl border border-brand-line bg-bg-elevated p-3 shadow-glow animate-fade-up">
            <p className="text-[10px] uppercase tracking-wider text-brand-mute mb-2">
              Pick a template
            </p>
            <ul className="space-y-1 mb-2">
              {CREW_TEMPLATES.map((tpl) => (
                <li key={tpl}>
                  <button
                    type="button"
                    onClick={() => setCustomMsg(tpl)}
                    className={`w-full rounded-md px-2 py-1.5 text-left text-xs hover:bg-brand-line min-h-[28px] ${
                      customMsg === tpl
                        ? 'bg-brand-accent/15 text-brand-accent font-bold'
                        : 'text-brand-ink'
                    }`}
                  >
                    {tpl}
                  </button>
                </li>
              ))}
            </ul>
            <textarea
              value={customMsg}
              onChange={(e) => setCustomMsg(e.target.value)}
              rows={2}
              className="w-full rounded-md border border-brand-line bg-bg-primary px-2 py-1 text-xs text-brand-ink focus:border-brand-accent focus:outline-none"
            />
            <div className="mt-2 flex items-center justify-between">
              <span className="text-[10px] text-brand-mute">
                {phone ? `Opens SMS to ${phone}` : 'Phone number missing'}
              </span>
              <a
                href={smsHref}
                aria-disabled={!phone}
                className={`rounded-md bg-brand-accent px-3 py-1 text-[11px] font-extrabold text-bg-primary min-h-[28px] ${
                  phone ? 'hover:bg-brand-accentHover' : 'pointer-events-none opacity-50'
                }`}
              >
                Open SMS
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
