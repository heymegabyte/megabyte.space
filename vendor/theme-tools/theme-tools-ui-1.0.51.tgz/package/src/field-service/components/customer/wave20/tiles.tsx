import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useEffect, useState } from 'react';

/**
 * Customer-side Wave 20 tiles. Each tile is a thin React surface fronting
 * the `/api/wave20/customer/*` endpoints. Designed to slot into MePage or
 * a dedicated /me/preferences route without ceremony.
 */

async function custFetch<T>(path: string, init: RequestInit = {}): Promise<T | null> {
  try {
    const res = await fetch(`/api/wave20${path}`, {
      ...init,
      credentials: 'include',
      headers: { 'Content-Type': 'application/json', ...(init.headers ?? {}) },
    });
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch {
    return null;
  }
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <article className="rounded-2xl border border-white/10 bg-black/40 p-5 shadow-md shadow-black/30">
      <h3 className="mb-3 text-base font-semibold text-white">{title}</h3>
      <div className="space-y-2 text-sm text-white/80">{children}</div>
    </article>
  );
}

export function NotificationPrefCard() {
  useThemeToolsSurface('tiles');
  const [channel, setChannel] = useState<string>('');
  const [pending, setPending] = useState<string>('sms');
  useEffect(() => {
    (async () => {
      const res = await custFetch<{ channel: string }>('/customer/notification-prefs');
      if (res) setChannel(res.channel);
    })();
  }, []);
  async function save() {
    const res = await custFetch('/customer/notification-prefs', {
      method: 'POST',
      body: JSON.stringify({ channel: pending }),
    });
    if (res) setChannel(pending);
  }
  return (
    <Card title="How should we reach you?">
      <p>
        Current: <span className="font-mono text-white">{channel || '—'}</span>
      </p>
      <select
        value={pending}
        onChange={(e) => setPending(e.target.value)}
        className="rounded-lg border border-white/10 bg-black/40 px-2 py-1 text-xs text-white"
      >
        <option value="sms">SMS</option>
        <option value="email">Email</option>
        <option value="both">Both</option>
        <option value="none">None</option>
      </select>
      <button
        type="button"
        onClick={save}
        className="rounded-lg bg-cyan-500/20 px-3 py-1 text-xs font-medium text-cyan-200 hover:bg-cyan-500/30"
      >
        Save
      </button>
    </Card>
  );
}

export function NpsCard() {
  const [score, setScore] = useState<number>(8);
  const [done, setDone] = useState(false);
  async function submit() {
    const res = await custFetch('/customer/nps', {
      method: 'POST',
      body: JSON.stringify({ score, source: 'web' }),
    });
    if (res) setDone(true);
  }
  if (done) {
    return (
      <Card title="Thanks for the feedback!">
        <p>We hear you — your response is logged.</p>
      </Card>
    );
  }
  return (
    <Card title="How likely are you to refer us?">
      <input
        type="range"
        min={0}
        max={10}
        value={score}
        onChange={(e) => setScore(Number(e.target.value))}
        className="w-full"
      />
      <p className="text-center font-mono text-white">{score}/10</p>
      <button
        type="button"
        onClick={submit}
        className="rounded-lg bg-emerald-500/20 px-3 py-1 text-xs font-medium text-emerald-200 hover:bg-emerald-500/30"
      >
        Submit
      </button>
    </Card>
  );
}

export function BadgesCard() {
  const [badges, setBadges] = useState<string[]>([]);
  useEffect(() => {
    (async () => {
      const res = await custFetch<{ badges: string[] }>('/customer/badges');
      if (res) setBadges(res.badges);
    })();
  }, []);
  return (
    <Card title="Your trust badges">
      {badges.length === 0 ? (
        <p>Book your second job to earn the Repeat badge.</p>
      ) : (
        <ul className="flex flex-wrap gap-2">
          {badges.map((b) => (
            <li
              key={b}
              className="rounded-full bg-cyan-500/20 px-3 py-1 text-xs font-medium uppercase tracking-wide text-cyan-200"
            >
              {b}
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

export function AutofillCard() {
  const [profile, setProfile] = useState<{ full_name: string | null; city: string | null } | null>(
    null,
  );
  useEffect(() => {
    (async () => {
      const res = await custFetch<{
        profile: { full_name: string | null; city: string | null } | null;
      }>('/customer/autofill');
      if (res?.profile) setProfile(res.profile);
    })();
  }, []);
  return (
    <Card title="Saved booking info">
      {profile ? (
        <>
          <p>
            Name: <span className="font-mono text-white">{profile.full_name ?? '—'}</span>
          </p>
          <p>
            City: <span className="font-mono text-white">{profile.city ?? '—'}</span>
          </p>
          <p className="text-white/60">Auto-fills your next booking.</p>
        </>
      ) : (
        <p>Book once and we&apos;ll remember your address + preferences.</p>
      )}
    </Card>
  );
}

export function AffinityCard() {
  const [top, setTop] = useState<{ worker_id: string; jobs_completed: number; score: number }[]>(
    [],
  );
  useEffect(() => {
    (async () => {
      const res = await custFetch<{ top: typeof top }>('/customer/affinity/top');
      if (res) setTop(res.top);
    })();
  }, []);
  return (
    <Card title="Your favorite crew">
      {top.length === 0 ? (
        <p>After your first job we&apos;ll show your top crew here.</p>
      ) : (
        <ul className="space-y-1">
          {top.slice(0, 3).map((t) => (
            <li key={t.worker_id} className="flex justify-between">
              <span className="font-mono text-white">{t.worker_id}</span>
              <span className="text-white/60">
                {t.jobs_completed} jobs · score {t.score.toFixed(1)}
              </span>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
