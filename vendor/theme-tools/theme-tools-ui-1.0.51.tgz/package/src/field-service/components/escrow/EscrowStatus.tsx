import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { useCallback, useEffect, useState } from 'react';
import { useFeatureFlag } from '../../use-feature-flag.js';
import { EscrowBadge, type EscrowState } from './EscrowBadge.js';
import { EscrowDispute } from './EscrowDispute.js';

interface EscrowRecord {
  id: string;
  state: EscrowState;
  capture_error?: string | null;
  refund_error?: string | null;
  customer_signoff?: number;
}

type LoadState =
  | { kind: 'loading' }
  | { kind: 'empty' }
  | { kind: 'error' }
  | { kind: 'ready'; record: EscrowRecord };

export function EscrowStatus({ bookingId }: { readonly bookingId: string }): JSX.Element | null {
  useThemeToolsSurface('escrow-status');
  const enabled = useFeatureFlag('smart_bonded_escrow');
  const [load, setLoad] = useState<LoadState>({ kind: 'loading' });
  const [signing, setSigning] = useState(false);
  const [actionError, setActionError] = useState('');

  const refresh = useCallback(async () => {
    setLoad({ kind: 'loading' });
    try {
      const response = await fetch(`/api/smart-bonded-escrow/${encodeURIComponent(bookingId)}`, {
        credentials: 'include',
      });
      if (response.status === 404) { setLoad({ kind: 'empty' }); return; }
      if (!response.ok) { setLoad({ kind: 'error' }); return; }
      const body = await response.json() as { record?: EscrowRecord };
      if (!body.record?.id || !body.record.state) { setLoad({ kind: 'error' }); return; }
      setLoad({ kind: 'ready', record: body.record });
    } catch {
      setLoad({ kind: 'error' });
    }
  }, [bookingId]);

  useEffect(() => {
    if (enabled) void refresh();
  }, [enabled, refresh]);

  if (!enabled || load.kind === 'empty') return null;
  if (load.kind === 'loading') {
    return <p role="status" className="text-sm text-brand-mute">Checking payment protection…</p>;
  }
  if (load.kind === 'error') {
    return (
      <div role="alert" className="rounded-xl border border-brand-line p-4 text-sm text-brand-mute">
        <p>Payment protection status is temporarily unavailable.</p>
        <button type="button" onClick={() => void refresh()} className="mt-2 min-h-[44px] rounded-lg border border-brand-line px-4 font-semibold text-brand-ink">
          Try again
        </button>
      </div>
    );
  }

  const { record } = load;
  const canSignOff = !record.customer_signoff && ['held', 'partially_verified'].includes(record.state);
  const signOff = async () => {
    setSigning(true);
    setActionError('');
    try {
      const response = await fetch(`/api/smart-bonded-escrow/verify/${encodeURIComponent(bookingId)}`, {
        method: 'POST', credentials: 'include', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ kind: 'customer_signoff' }),
      });
      if (!response.ok) { setActionError('Could not confirm completion. Try again.'); return; }
      await refresh();
    } catch {
      setActionError('Connection issue while confirming completion. Try again.');
    } finally {
      setSigning(false);
    }
  };
  return (
    <section className="space-y-3" aria-label="Payment protection">
      <EscrowBadge state={record.state} />
      {canSignOff && (
        <button type="button" onClick={() => void signOff()} disabled={signing} aria-busy={signing} className="min-h-[44px] rounded-lg bg-brand-accent px-4 font-semibold text-bg-primary disabled:opacity-60">
          {signing ? 'Confirming…' : 'Confirm job completion'}
        </button>
      )}
      {actionError && <p role="alert" className="text-sm text-red-300">{actionError}</p>}
      {(record.capture_error || record.refund_error) && (
        <p role="status" className="text-sm text-amber-300">
          Provider confirmation needs operator attention. Your protected status has not been advanced.
        </p>
      )}
      <EscrowDispute escrowId={record.id} state={record.state} onDisputed={() => void refresh()} />
    </section>
  );
}
