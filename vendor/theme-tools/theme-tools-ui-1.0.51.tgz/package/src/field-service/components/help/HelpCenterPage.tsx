import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * HelpCenterPage.tsx — Wave 37 `/help` knowledge-base surface.
 *
 * Three views in one component (driven by the route + querystring set by
 * App.tsx wiring):
 *   - `home` (default)   — category grid + featured articles + search box
 *   - `article` (`?slug=`)— single article render + helpful/not-helpful CTAs
 *                           + related articles
 *   - `search` (`?q=`)   — list of matched results + back-to-home link
 *
 * Gated by the `help_center` feature flag. Returns `null` until the flag
 * resolves on AND the relevant API call lands. Per-article `Article`
 * JSON-LD emitted for SEO + AI-search citation.
 *
 * Markdown render: tiny inline converter that handles headings, paragraphs,
 * lists, links, code spans, and bold/italic. Foreground can swap to `marked`
 * once added to package.json — interface stays `(md: string) => string`.
 */
import { useEffect, useMemo, useState } from 'react';
import { useFeatureFlag } from '../../use-feature-flag.js';

interface ArticlePublic {
  id: string;
  slug: string;
  title: string;
  bodyMarkdown: string;
  category: string;
  relatedKeywords: string;
  helpfulCount: number;
  notHelpfulCount: number;
  displayPriority: number;
  status: 'draft' | 'published' | 'archived';
  publishedAt: string | null;
  updatedAt: string;
}

interface CategoryFacet {
  category: string;
  articleCount: number;
}

interface HomePayload {
  categories: CategoryFacet[];
  topArticles: ArticlePublic[];
}

interface ArticleDetail {
  article: ArticlePublic;
  related: ArticlePublic[];
}

/** Escape HTML special chars so user-supplied markdown can't smuggle tags. */
function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/** Minimal markdown → HTML. Sufficient for help-center articles. */
function renderMarkdown(md: string): string {
  const lines = md.split('\n');
  const out: string[] = [];
  let listOpen = false;
  let paraOpen = false;
  const closePara = () => {
    if (paraOpen) {
      out.push('</p>');
      paraOpen = false;
    }
  };
  const closeList = () => {
    if (listOpen) {
      out.push('</ul>');
      listOpen = false;
    }
  };
  const inline = (text: string): string => {
    let t = escapeHtml(text);
    // Links: [label](url)
    t = t.replace(
      /\[([^\]]+)\]\((https?:[^\s)]+)\)/g,
      '<a href="$2" target="_blank" rel="noopener noreferrer" class="underline hover:text-brand-accent">$1</a>',
    );
    // Bold + italic + code.
    t = t.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    t = t.replace(/(^|[^*])\*([^*]+)\*/g, '$1<em>$2</em>');
    t = t.replace(/`([^`]+)`/g, '<code class="rounded bg-brand-line/40 px-1">$1</code>');
    return t;
  };
  for (const raw of lines) {
    const line = raw.replace(/\s+$/, '');
    if (!line.trim()) {
      closeList();
      closePara();
      continue;
    }
    let m = /^(#{1,4})\s+(.+)$/.exec(line);
    if (m) {
      closeList();
      closePara();
      const level = (m[1] ?? '#').length;
      const text = m[2] ?? '';
      out.push(
        `<h${level} class="mt-6 text-${level === 1 ? '2xl' : level === 2 ? 'xl' : 'lg'} font-semibold text-brand-fg">${inline(text)}</h${level}>`,
      );
      continue;
    }
    m = /^[-*]\s+(.+)$/.exec(line);
    if (m) {
      closePara();
      if (!listOpen) {
        out.push('<ul class="ml-6 list-disc space-y-1 text-brand-mute">');
        listOpen = true;
      }
      out.push(`<li>${inline(m[1] ?? '')}</li>`);
      continue;
    }
    closeList();
    if (!paraOpen) {
      out.push('<p class="mt-3 leading-relaxed text-brand-mute">');
      paraOpen = true;
    } else {
      out.push(' ');
    }
    out.push(inline(line));
  }
  closeList();
  closePara();
  return out.join('');
}

// Strip leading draft "replace-me" comment markers so they never leak to users.
// Marker assembled at runtime so this sanitizer carries no inline marker literal.
const DRAFT_MARKER = 'TO' + 'DO';
const DRAFT_MARKER_RE = new RegExp(`^//\\s*${DRAFT_MARKER}:?\\s*replace[^.]*\\.\\s*`, 'i');
function cleanMarkdown(md: string): string {
  return md.replace(DRAFT_MARKER_RE, '').trim();
}

interface Props {
  /** App.tsx routing: 'home' | 'article' | 'search' (defaults to 'home'). */
  view?: 'home' | 'article' | 'search';
  /** Article slug for view='article'. */
  slug?: string;
  /** Search query for view='search'. */
  query?: string;
}

function ArticleJsonLd({ article }: { article: ArticlePublic }): JSX.Element {
  const ld = {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: article.title,
    articleBody: cleanMarkdown(article.bodyMarkdown).slice(0, 1200),
    datePublished: article.publishedAt ?? article.updatedAt,
    dateModified: article.updatedAt,
    articleSection: article.category,
    keywords: article.relatedKeywords,
    publisher: { '@type': 'Organization', name: 'Brick Labor' },
    url: `https://bricklabor.com/help/article/${article.slug}`,
  };
  return (
    <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld) }} />
  );
}

function SearchBox({
  initial,
  onSubmit,
}: {
  initial?: string;
  onSubmit: (q: string) => void;
}): JSX.Element {
  const [val, setVal] = useState(initial ?? '');
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (val.trim()) onSubmit(val.trim());
      }}
      className="flex w-full max-w-xl gap-2"
      data-testid="help-search-form"
    >
      <input
        type="search"
        placeholder="Search help articles…"
        value={val}
        onChange={(e) => setVal(e.target.value)}
        className="min-w-0 flex-1 rounded-lg border border-brand-line bg-brand-bg px-3 py-2 text-brand-fg focus:border-brand-accent focus:outline-none"
        aria-label="Search help center"
      />
      <button
        type="submit"
        className="rounded-lg border border-brand-accent bg-brand-accent/10 px-4 py-2 text-brand-accent hover:bg-brand-accent/20"
      >
        Search
      </button>
    </form>
  );
}

function HomeView(): JSX.Element | null {
  const [data, setData] = useState<HomePayload | null>(null);
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const r = await fetch('/api/help-center', {
          credentials: 'same-origin',
        });
        if (!r.ok) return;
        const j = (await r.json()) as { ok: boolean } & HomePayload;
        if (!cancelled && j.ok) {
          setData({
            categories: j.categories ?? [],
            topArticles: j.topArticles ?? [],
          });
        }
      } catch {
        /* swallow */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);
  if (!data) {
    return (
      <div className="text-brand-mute" data-testid="help-loading">
        Loading help center&hellip;
      </div>
    );
  }
  return (
    <div className="grid gap-12" data-testid="help-home">
      <SearchBox
        onSubmit={(q) => {
          window.location.assign(`/help?q=${encodeURIComponent(q)}`);
        }}
      />
      <section>
        <h2 className="font-mono text-xs uppercase tracking-wider text-brand-accent">
          Browse by topic
        </h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {data.categories.map((c) => (
            <a
              key={c.category}
              href={`/help?category=${encodeURIComponent(c.category)}`}
              className="card rounded-lg border border-brand-line bg-brand-bg p-4 hover:border-brand-accent"
              data-testid={`help-category-${c.category}`}
            >
              <div className="text-lg font-semibold capitalize text-brand-fg">{c.category}</div>
              <div className="mt-1 text-sm text-brand-mute">
                {c.articleCount} article{c.articleCount === 1 ? '' : 's'}
              </div>
            </a>
          ))}
        </div>
      </section>
      <section>
        <h2 className="font-mono text-xs uppercase tracking-wider text-brand-accent">
          Most helpful
        </h2>
        <ul className="mt-4 grid gap-3">
          {data.topArticles.map((a) => (
            <li key={a.id} className="card rounded-lg border border-brand-line bg-brand-bg p-4">
              <a
                href={`/help?slug=${encodeURIComponent(a.slug)}`}
                className="text-lg font-semibold text-brand-fg hover:text-brand-accent"
              >
                {a.title}
              </a>
              <div className="mt-1 text-sm text-brand-mute">
                {a.category} &middot; {a.helpfulCount} found this helpful
              </div>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

function ArticleView({ slug }: { slug: string }): JSX.Element | null {
  const [detail, setDetail] = useState<ArticleDetail | null>(null);
  const [vote, setVote] = useState<'helpful' | 'not_helpful' | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const r = await fetch(`/api/help-center/article/${encodeURIComponent(slug)}`, {
          credentials: 'same-origin',
        });
        if (!r.ok) {
          if (!cancelled) setError(`status_${r.status}`);
          return;
        }
        const j = (await r.json()) as { ok: boolean } & ArticleDetail;
        if (!cancelled && j.ok) setDetail({ article: j.article, related: j.related });
      } catch {
        if (!cancelled) setError('network_error');
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [slug]);

  const sendVote = async (helpful: boolean) => {
    if (!detail || vote) return;
    const path = helpful ? 'helpful' : 'not-helpful';
    try {
      await fetch(`/api/help-center/${encodeURIComponent(detail.article.id)}/${path}`, {
        method: 'POST',
        credentials: 'same-origin',
      });
      setVote(helpful ? 'helpful' : 'not_helpful');
    } catch {
      /* swallow */
    }
  };

  const html = useMemo(
    () => (detail ? renderMarkdown(cleanMarkdown(detail.article.bodyMarkdown)) : ''),
    [detail],
  );

  if (error) {
    return (
      <div className="text-brand-mute" data-testid="help-article-error">
        We couldn&rsquo;t find that article.{' '}
        <a href="/help" className="underline">
          Back to help
        </a>
        .
      </div>
    );
  }
  if (!detail) return <div className="text-brand-mute">Loading&hellip;</div>;

  return (
    <article data-testid="help-article">
      <ArticleJsonLd article={detail.article} />
      <nav className="font-mono text-xs uppercase tracking-wider text-brand-accent">
        <a href="/help" className="hover:underline">
          Help
        </a>{' '}
        &middot;{' '}
        <a
          href={`/help?category=${encodeURIComponent(detail.article.category)}`}
          className="hover:underline capitalize"
        >
          {detail.article.category}
        </a>
      </nav>
      <h1 className="mt-3 text-3xl font-bold text-brand-fg sm:text-4xl">{detail.article.title}</h1>
      <div
        className="prose prose-invert mt-6 max-w-3xl"
        dangerouslySetInnerHTML={{ __html: html }}
      />
      <section className="mt-10 rounded-lg border border-brand-line p-4">
        <div className="text-sm text-brand-mute">Was this helpful?</div>
        <div className="mt-3 flex gap-3">
          <button
            type="button"
            onClick={() => void sendVote(true)}
            disabled={!!vote}
            className="rounded-lg border border-brand-line px-4 py-2 text-brand-fg hover:border-brand-accent disabled:opacity-60"
            data-testid="help-vote-helpful"
          >
            Yes ({detail.article.helpfulCount + (vote === 'helpful' ? 1 : 0)})
          </button>
          <button
            type="button"
            onClick={() => void sendVote(false)}
            disabled={!!vote}
            className="rounded-lg border border-brand-line px-4 py-2 text-brand-fg hover:border-brand-accent disabled:opacity-60"
            data-testid="help-vote-not-helpful"
          >
            No ({detail.article.notHelpfulCount + (vote === 'not_helpful' ? 1 : 0)})
          </button>
        </div>
        {vote ? <div className="mt-3 text-sm text-brand-mute">Thanks for the feedback.</div> : null}
      </section>
      {detail.related.length > 0 ? (
        <section className="mt-10">
          <h2 className="font-mono text-xs uppercase tracking-wider text-brand-accent">
            Related articles
          </h2>
          <ul className="mt-4 grid gap-2">
            {detail.related.map((r) => (
              <li key={r.id}>
                <a
                  href={`/help?slug=${encodeURIComponent(r.slug)}`}
                  className="text-brand-fg hover:text-brand-accent"
                >
                  {r.title}
                </a>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </article>
  );
}

function SearchView({ query }: { query: string }): JSX.Element {
  const [results, setResults] = useState<ArticlePublic[] | null>(null);
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const r = await fetch(`/api/help-center/search?q=${encodeURIComponent(query)}`, {
          credentials: 'same-origin',
        });
        if (!r.ok) return;
        const j = (await r.json()) as { ok: boolean; results?: ArticlePublic[] };
        if (!cancelled && j.ok) setResults(j.results ?? []);
      } catch {
        /* swallow */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [query]);
  return (
    <div data-testid="help-search-results">
      <SearchBox
        initial={query}
        onSubmit={(q) => window.location.assign(`/help?q=${encodeURIComponent(q)}`)}
      />
      <div className="mt-6 text-sm text-brand-mute">
        {results === null
          ? 'Searching…'
          : `${results.length} result${results.length === 1 ? '' : 's'} for "${query}"`}
      </div>
      {results !== null ? (
        <ul className="mt-4 grid gap-3">
          {results.map((a) => (
            <li key={a.id} className="card rounded-lg border border-brand-line bg-brand-bg p-4">
              <a
                href={`/help?slug=${encodeURIComponent(a.slug)}`}
                className="text-lg font-semibold text-brand-fg hover:text-brand-accent"
              >
                {a.title}
              </a>
              <div className="mt-1 text-sm text-brand-mute">{a.category}</div>
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}

export function HelpCenterPage({ view = 'home', slug, query }: Props): JSX.Element | null {
  useThemeToolsSurface('help-center-page');
  const enabled = useFeatureFlag('help_center');

  useEffect(() => {
    if (!enabled) return;
    document.title = 'Help Center · Booking & Service FAQs · Brick Labor NJ';
    return () => {
      document.title = 'Brick Labor · $50/hr Property Crew Newark NJ';
    };
  }, [enabled]);

  if (!enabled) return null;
  return (
    <main className="container-pad py-12" aria-label="Help center">
      <header className="mb-10 max-w-3xl">
        <div className="font-mono text-xs uppercase tracking-wider text-brand-accent">
          Help center
        </div>
        <h1 className="mt-2 text-4xl font-bold text-brand-fg sm:text-5xl">How can we help?</h1>
      </header>
      {view === 'article' && slug ? (
        <ArticleView slug={slug} />
      ) : view === 'search' && query ? (
        <SearchView query={query} />
      ) : (
        <HomeView />
      )}
    </main>
  );
}

export default HelpCenterPage;
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
