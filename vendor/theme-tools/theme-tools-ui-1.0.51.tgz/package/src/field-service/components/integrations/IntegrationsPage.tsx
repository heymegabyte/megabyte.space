import { useEffect } from 'react';
import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { WAVE4_PARTNER_SPECS } from '@theme.tools/integrations/field-service-partner-adapters';
import { JsonLd } from '../seo/index.js';
import { PHONE_TEL_HREF, PHONE_WA_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';

const TITLE = 'Integrations — Slack, WhatsApp, Voice, Email · Brick Labor';
const DESC =
  'Book Brick Labor from any channel — WhatsApp, iMessage, voice, email, Slack, Zapier, n8n, iOS Shortcuts, Android Tasker, browser extension, and calendar sync.';

type Status = 'live' | 'beta' | 'planned';

interface ChannelIntegration {
  readonly slug: string;
  readonly name: string;
  readonly category:
    | 'messaging'
    | 'voice'
    | 'email'
    | 'workspace'
    | 'automation'
    | 'native'
    | 'calendar';
  readonly status: Status;
  readonly pitch: string;
  readonly details: string;
  readonly enableHref: string;
  readonly docHref?: string;
}

const INTEGRATIONS: ReadonlyArray<ChannelIntegration> = [
  {
    slug: 'whatsapp',
    name: 'WhatsApp',
    category: 'messaging',
    status: 'live',
    pitch: 'Text us on WhatsApp — same AI booking assistant as SMS.',
    details:
      'Twilio WhatsApp Business inbound + outbound. Message us and the AI extracts service, date, crew size, and ZIP, then replies with a one-tap booking link.',
    enableHref: `${PHONE_WA_HREF}?text=I%20need%20a%20crew`,
    docHref: '/api/channels/whatsapp/inbound',
  },
  {
    slug: 'imessage',
    name: 'iMessage',
    category: 'messaging',
    status: 'beta',
    pitch: 'Apple Business Chat for Messages — tap to chat from Maps/Safari.',
    details:
      'Apple Business Chat via Twilio MSP. Tap the Messages icon on our Apple Business profile to start a conversation; the same booking assistant replies.',
    enableHref: 'https://bcrw.apple.com/urn:biz:ABCD1234',
  },
  {
    slug: 'voice',
    name: 'AI Phone',
    category: 'voice',
    status: 'live',
    pitch: 'Call us — the AI takes the booking and texts you back.',
    details:
      'Twilio Voice with speech-to-text → Claude Haiku → text-to-speech. Customers describe what they need; the AI confirms the booking on the call and texts the link.',
    enableHref: PHONE_TEL_HREF,
  },
  {
    slug: 'email',
    name: 'Email',
    category: 'email',
    status: 'live',
    pitch: 'Email a booking — the AI parses it and replies with a quote.',
    details:
      'Resend inbound forwards email to the AI booking parser. Reply to our quote email and the thread keeps going.',
    enableHref: 'mailto:book@bricklabor.com?subject=Booking%20request',
  },
  {
    slug: 'slack',
    name: 'Slack',
    category: 'workspace',
    status: 'planned',
    pitch: 'Slash command in Slack: `/bcl book Sat 2 haul in 07102`.',
    details:
      'Slack app with the `/bcl` slash command. Install once per workspace; the app verifies request signatures and opens a booking modal.',
    enableHref: 'mailto:hey@bricklabor.com?subject=Slack%20integration',
  },
  {
    slug: 'zapier',
    name: 'Zapier',
    category: 'automation',
    status: 'live',
    pitch: '5,000+ apps — new booking → Slack, Sheets, Notion, CRM.',
    details:
      'Webhook triggers + REST hooks for `new_booking`, `booking_confirmed`, `payout_completed`. Subscribe via Zapier with one click.',
    enableHref: 'https://zapier.com/apps/webhook',
    docHref: '/api/channels/zapier/list/new_booking',
  },
  {
    slug: 'n8n',
    name: 'n8n',
    category: 'automation',
    status: 'live',
    pitch: 'Self-hosted automation — import the template and go.',
    details:
      'Workflow template lives at `/api/channels/n8n/template`. Tag-based subscriptions route events to your n8n instance.',
    enableHref: '/api/channels/n8n/template',
  },
  {
    slug: 'ios-shortcut',
    name: 'iOS Shortcut',
    category: 'native',
    status: 'planned',
    pitch: 'Single-tap booking from the iOS Shortcut gallery.',
    details:
      'One HTTP POST round-trip → parsed booking + URL. Add the Shortcut to your home screen for a one-tap quick book.',
    enableHref: 'mailto:hey@bricklabor.com?subject=iOS%20Shortcut',
  },
  {
    slug: 'android-tasker',
    name: 'Android Tasker',
    category: 'native',
    status: 'live',
    pitch: 'Tasker / Macrodroid macro — one POST, one reply.',
    details:
      'Same shape as the iOS Shortcut endpoint. Import the macro to wire any Android trigger (NFC tag, voice, location) to a booking.',
    enableHref: 'https://taskernet.com/shares/?user=brickcitylabor',
  },
  {
    slug: 'browser-extension',
    name: 'Browser Extension',
    category: 'native',
    status: 'planned',
    pitch: 'Right-click selected text on Zillow / Craigslist → book the move.',
    details:
      'Chrome + Firefox extension calls `/api/channels/extension/quick-book`. CORS allow-listed to the extension origin so no API key is required.',
    enableHref: 'mailto:hey@bricklabor.com?subject=Browser%20Extension',
  },
  {
    slug: 'google-calendar',
    name: 'Google Calendar',
    category: 'calendar',
    status: 'live',
    pitch: 'Push every booking into your Google Calendar automatically.',
    details:
      'Bidirectional iCal sync via the Calendar API. We project upcoming bookings as VEVENT blocks and read back changes via incremental sync tokens.',
    enableHref: '/api/calendar/sync/google',
  },
  {
    slug: 'apple-calendar',
    name: 'Apple Calendar',
    category: 'calendar',
    status: 'beta',
    pitch: 'iCloud Calendar subscription URL — your bookings, everywhere.',
    details:
      'CalDAV / iCalendar feed. Subscribe in Calendar.app → File → New Calendar Subscription with the URL we email you.',
    enableHref: '/api/calendar/sync/apple',
  },
  {
    slug: 'outlook',
    name: 'Outlook',
    category: 'calendar',
    status: 'live',
    pitch: 'Microsoft 365 + Outlook.com — bookings on your Outlook calendar.',
    details: 'Microsoft Graph delta sync. Same VEVENT projection as the Google + Apple paths.',
    enableHref: '/api/calendar/sync/outlook',
  },
  {
    slug: 'calcom',
    name: 'Cal.com',
    category: 'calendar',
    status: 'live',
    pitch: 'Layer Brick Labor on top of your Cal.com availability.',
    details:
      'Sync token-based incremental fetch from Cal.com. Bookings created in Cal.com become Brick Labor jobs and vice versa.',
    enableHref: '/api/calendar/sync/calcom',
  },
  {
    slug: 'teams',
    name: 'Microsoft Teams',
    category: 'workspace',
    status: 'planned',
    pitch: 'Planned — `/bcl` command and Teams Adaptive Card replies.',
    details:
      'Planned 2026 H2. Email hey@bricklabor.com to flag your Teams tenant and we will prioritize.',
    enableHref: 'mailto:hey@bricklabor.com?subject=Teams%20integration',
  },
];

const CATEGORY_LABEL: Record<ChannelIntegration['category'], string> = {
  messaging: 'Messaging',
  voice: 'Voice',
  email: 'Email',
  workspace: 'Workspace',
  automation: 'Automation',
  native: 'Native apps',
  calendar: 'Calendar',
};

/**
 * /integrations — Wave 11 multi-channel catalog. Each integration has an
 * "Enable" deeplink (install URL, mailto, or our API endpoint) and a status
 * badge. Cards group by category so the page scans top-to-bottom.
 */
export function IntegrationsPage(): JSX.Element {
  useEffect(() => {
    document.title = TITLE;
    setMeta('description', DESC);
    setLink('canonical', 'https://bricklabor.com/integrations');
    setMeta('robots', 'index,follow', 'name');
    setMeta('og:title', TITLE, 'property');
    setMeta('og:description', DESC, 'property');
    setMeta('og:url', 'https://bricklabor.com/integrations', 'property');
  }, []);

  const byCategory = INTEGRATIONS.reduce<Record<string, ChannelIntegration[]>>((acc, i) => {
    if (!acc[i.category]) acc[i.category] = [];
    acc[i.category]!.push(i);
    return acc;
  }, {});

  const surfaceProps = useThemeToolsSurface('integrations-page', [
    '@theme.tools/ui',
    '@theme.tools/integrations',
  ]);

  return (
    <article
      className="section"
      data-theme-tools-surface={surfaceProps['data-theme-tools-surface']}
      data-theme-tools-pricing-model={surfaceProps['data-theme-tools-pricing-model']}
      data-wave4-partner-count={Object.keys(WAVE4_PARTNER_SPECS).length}
    >
      <div className="container-pad max-w-5xl">
        <p className="eyebrow mb-3">Integrations</p>
        <h1 className="text-4xl sm:text-5xl font-extrabold">
          Book from <span className="text-brand-accent">any channel</span>.
        </h1>
        <p className="mt-4 text-lg text-brand-mute max-w-2xl">
          WhatsApp, voice, email, Slack — pick the surface your team already lives in. The same AI
          booking assistant handles every channel and writes to one unified inbox.
        </p>

        {Object.entries(byCategory).map(([cat, items]) => (
          <section key={cat} className="mt-10">
            <h2 className="text-2xl font-extrabold mb-4">
              {CATEGORY_LABEL[cat as ChannelIntegration['category']]}
            </h2>
            <ul className="grid sm:grid-cols-2 gap-4">
              {items.map((i) => (
                <li key={i.slug} className="card flex flex-col gap-3">
                  <header className="flex items-start justify-between gap-2">
                    <h3 className="text-lg font-extrabold">{i.name}</h3>
                    <StatusPill status={i.status} />
                  </header>
                  <p className="text-sm text-brand-ink">{i.pitch}</p>
                  <p className="text-sm text-brand-mute leading-relaxed">{i.details}</p>
                  <footer className="mt-auto pt-2 border-t border-brand-line flex items-center justify-between text-[12px]">
                    <a
                      href={i.enableHref}
                      className="text-brand-accent underline-hover font-semibold"
                      target={i.enableHref.startsWith('http') ? '_blank' : undefined}
                      rel={i.enableHref.startsWith('http') ? 'noopener noreferrer' : undefined}
                    >
                      Enable {i.name} →
                    </a>
                    {i.docHref && (
                      <a
                        href={i.docHref}
                        className="text-brand-mute hover:text-brand-ink"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        docs
                      </a>
                    )}
                  </footer>
                </li>
              ))}
            </ul>
          </section>
        ))}

        <section className="mt-12 rounded-xl border border-brand-line p-6 bg-bg-elevated/40">
          <h2 className="text-xl font-extrabold">Build a custom integration</h2>
          <p className="mt-2 text-brand-mute leading-relaxed">
            Our OAuth 2.1 server at{' '}
            <a href="/api/oauth2/authorize" className="text-brand-accent underline-hover">
              /api/oauth2
            </a>{' '}
            issues access + refresh tokens with PKCE. Pair with the white-label dispatch API at{' '}
            <a href="/b2b" className="text-brand-accent underline-hover">
              /b2b
            </a>{' '}
            to drop Brick Labor crews into your own product.
          </p>
        </section>
      </div>

      <JsonLd
        data={{
          '@context': 'https://schema.org',
          '@type': 'WebPage',
          '@id': 'https://bricklabor.com/integrations',
          url: 'https://bricklabor.com/integrations',
          name: TITLE,
          description: DESC,
          isPartOf: { '@id': 'https://bricklabor.com/#website' },
          mainEntity: {
            '@type': 'ItemList',
            numberOfItems: INTEGRATIONS.length,
            itemListElement: INTEGRATIONS.map((i, idx) => ({
              '@type': 'ListItem',
              position: idx + 1,
              name: i.name,
              url: i.enableHref.startsWith('http')
                ? i.enableHref
                : `https://bricklabor.com${i.enableHref}`,
            })),
          },
        }}
      />
    </article>
  );
}

function StatusPill({ status }: { status: Status }): JSX.Element {
  const palette: Record<Status, string> = {
    live: 'border-brand-ok/40 bg-brand-ok/10 text-brand-ok',
    beta: 'border-brand-accent/40 bg-brand-accent/10 text-brand-accent',
    planned: 'border-brand-line bg-bg-elevated text-brand-mute',
  };
  const label: Record<Status, string> = {
    live: 'Live',
    beta: 'Beta',
    planned: 'Planned',
  };
  return (
    <span
      className={`rounded-full border px-2 py-0.5 text-[11px] font-semibold ${palette[status]}`}
    >
      {label[status]}
    </span>
  );
}

function setMeta(name: string, content: string, attr: 'name' | 'property' = 'name') {
  let el = document.querySelector<HTMLMetaElement>(`meta[${attr}="${name}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function setLink(rel: string, href: string) {
  let el = document.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', rel);
    document.head.appendChild(el);
  }
  el.setAttribute('href', href);
}
