import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { WAVE4_PARTNER_SPECS } from '@theme.tools/integrations/field-service-partner-adapters';
import { useEffect, useState } from 'react';

interface InstallState {
  readonly status: 'idle' | 'loading' | 'success' | 'error';
  readonly message: string;
  readonly team?: string;
}

/**
 * Slack OAuth install-callback handler. Mounts at `/integrations/slack` (route
 * wired in a follow-up wave) and consumes the `?code=...` query Slack appends
 * when redirecting back from the consent screen. It forwards the code to
 * `/api/channels/slack/install`, which exchanges it for a bot token and
 * persists the workspace. Renders a status panel and a "Back to integrations"
 * link.
 */
export function SlackInstall(): JSX.Element {
  useThemeToolsSurface('slack-install');
  const [state, setState] = useState<InstallState>({ status: 'idle', message: '' });

  useEffect(() => {
    document.title = 'Slack Integration Install · Brick Labor Integrations';
    return () => {
      document.title = 'Brick Labor · $50/hr Property Crew Newark NJ';
    };
  }, []);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const code = params.get('code');
    const installed = params.get('slack');
    const team = params.get('team') || undefined;

    if (installed === 'installed') {
      setState({
        status: 'success',
        message: 'Slack workspace installed. The `/bcl` command is live in your channels now.',
        team,
      });
      return;
    }

    if (!code) {
      setState({
        status: 'error',
        message: 'Missing OAuth code — start the install from the Integrations page.',
      });
      return;
    }

    setState({ status: 'loading', message: 'Finishing Slack install...' });

    (async () => {
      try {
        const res = await fetch(`/api/channels/slack/install?code=${encodeURIComponent(code)}`, {
          method: 'GET',
          credentials: 'include',
        });
        if (res.redirected) {
          window.location.href = res.url;
          return;
        }
        const data = (await res.json()) as { ok: boolean; error?: string };
        if (!data.ok) {
          throw new Error(data.error || 'install failed');
        }
        setState({
          status: 'success',
          message: 'Slack workspace installed. The `/bcl` command is live in your channels now.',
        });
      } catch (err) {
        setState({ status: 'error', message: (err as Error).message });
      }
    })().catch(() => undefined);
  }, []);

  return (
    <article className="section">
      <div className="container-pad max-w-2xl text-center">
        <p className="eyebrow mb-3">Slack install</p>
        <h1 className="text-3xl sm:text-4xl font-extrabold">
          {state.status === 'success'
            ? 'Slack connected.'
            : state.status === 'error'
              ? 'Install failed.'
              : 'Connecting Slack...'}
        </h1>
        <p className="mt-4 text-brand-mute">{state.message || 'One moment...'}</p>
        {state.team && (
          <p className="mt-2 text-sm text-brand-mute">
            Team ID: <code className="font-mono">{state.team}</code>
          </p>
        )}
        <p className="mt-8 text-sm">
          <a href="/integrations" className="text-brand-accent underline-hover">
            ← Back to integrations
          </a>
        </p>
      </div>
    </article>
  );
}

export default SlackInstall;
export const THEME_TOOLS_PARTNER_SPECS_COUNT = Object.keys(WAVE4_PARTNER_SPECS).length;
