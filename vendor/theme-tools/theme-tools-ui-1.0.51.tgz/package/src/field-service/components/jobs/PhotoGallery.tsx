import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type KeyboardEvent as ReactKeyboardEvent,
  type RefObject,
} from 'react';
import type { JobPhoto, JobPhotosResponse } from '@theme.tools/scheduling/field-service/photo-types';
import { useBodyScrollLock, useFocusManagement, useTabTrap } from '../../use-dialog-a11y.js';
import { MODAL_BACKDROP_CLASS, MODAL_PANEL_CLASS, useModalMotion } from '../../use-modal-motion.js';

interface PhotoGalleryProps {
  readonly bookingId: string;
  readonly initialPhotos?: readonly JobPhoto[];
  /** Override fetch impl for tests. */
  readonly fetchImpl?: typeof fetch;
}

/**
 * Split before/after gallery with damage overlays, a built-in lightbox, and a
 * "download all as zip" button (client-side fetch + JSZip-free implementation
 * using the browser's built-in `showDirectoryPicker` when available; falls
 * back to sequential downloads).
 *
 * Designed to render anywhere — customer review page, admin booking detail,
 * worker dashboard — without external deps.
 *
 * The lightbox is a real ARIA APG modal dialog via the shared dialog a11y kit
 * (`use-dialog-a11y.ts`) — focus moves INTO the panel on open, restores to the
 * thumbnail trigger on close, Tab/Shift+Tab stay trapped inside, and body scroll
 * locks while it covers the viewport (axe-core is blind to all of these).
 * Dismissal (Esc, backdrop, Close) plays the shared A7 backdrop-fade + panel-
 * slide exit via `use-modal-motion.ts`; ←/→ swap the photo instantly. Extend-
 * don't-duplicate: same hooks as the chat panel, drawer, and move-photo gallery.
 */
export default function PhotoGallery({ bookingId, initialPhotos, fetchImpl }: PhotoGalleryProps) {
  useThemeToolsSurface('photo-gallery');
  const f = fetchImpl ?? fetch;
  const [photos, setPhotos] = useState<readonly JobPhoto[]>(initialPhotos ?? []);
  const [loading, setLoading] = useState(!initialPhotos);
  const [active, setActive] = useState<JobPhoto | null>(null);
  const panelRef = useRef<HTMLDivElement | null>(null);
  const lastFocusRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (initialPhotos) return;
    let cancelled = false;
    (async () => {
      try {
        const res = await f(`/api/jobs/${encodeURIComponent(bookingId)}/photos`, {
          credentials: 'include',
        });
        if (!res.ok) return;
        const data = (await res.json()) as JobPhotosResponse;
        if (!cancelled) setPhotos(data.photos);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [bookingId, initialPhotos, f]);

  const start = useMemo(() => photos.filter((p) => p.kind === 'start'), [photos]);
  const end = useMemo(() => photos.filter((p) => p.kind === 'end'), [photos]);

  const isOpen = active != null;
  const close = useCallback(() => setActive(null), []);
  // Animated dismissal — plays the shared exit keyframe, then unmounts (close).
  const { closing, requestClose } = useModalMotion(close);

  // Shared dialog a11y kit (axe-blind interaction patterns): focus into the
  // panel on open + restore to the trigger on close, body-scroll lock while the
  // full-screen lightbox is up, and a Tab trap on the overlay.
  useFocusManagement(isOpen, panelRef, lastFocusRef);
  useBodyScrollLock(isOpen, 99999);
  const onTabKeyDown = useTabTrap(panelRef);

  // Lightbox keyboard nav — Esc animates close; ←/→ swap the photo instantly.
  useEffect(() => {
    if (!active) return;
    const sequence = [...start, ...end];
    const idx = sequence.findIndex((p) => p.id === active.id);
    const onKey = (ev: KeyboardEvent) => {
      if (ev.key === 'Escape') requestClose();
      else if (ev.key === 'ArrowRight' && idx >= 0 && idx < sequence.length - 1) {
        setActive(sequence[idx + 1] ?? null);
      } else if (ev.key === 'ArrowLeft' && idx > 0) setActive(sequence[idx - 1] ?? null);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [active, start, end, requestClose]);

  return (
    <section data-testid="photo-gallery" className="space-y-6">
      <header className="flex items-center justify-between gap-3">
        <h2 className="text-2xl font-display font-bold text-brand-ink">Job photos</h2>
        {photos.length > 0 && (
          <button
            type="button"
            className="btn-ghost text-sm"
            onClick={() => void downloadAll(photos, bookingId)}
            data-testid="download-photos"
          >
            Download all
          </button>
        )}
      </header>

      {loading && <p className="text-brand-mute">Loading photos…</p>}
      {!loading && photos.length === 0 && (
        <p className="text-brand-mute">No photos yet for this booking.</p>
      )}

      <Grid label="Before" photos={start} onOpen={setActive} />
      <Grid label="After" photos={end} onOpen={setActive} />

      {active && (
        <Lightbox
          photo={active}
          onClose={requestClose}
          panelRef={panelRef as React.RefObject<HTMLDivElement>}
          closing={closing}
          onTabKeyDown={onTabKeyDown}
        />
      )}
    </section>
  );
}

function Grid({
  label,
  photos,
  onOpen,
}: {
  readonly label: string;
  readonly photos: readonly JobPhoto[];
  readonly onOpen: (p: JobPhoto) => void;
}) {
  if (photos.length === 0) return null;
  return (
    <div className="space-y-3">
      <h3 className="text-sm font-display font-bold uppercase tracking-wide text-brand-mute">
        {label} ({photos.length})
      </h3>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {photos.map((p, idx) => (
          <button
            type="button"
            key={p.id}
            onClick={() => onOpen(p)}
            className="group relative aspect-square overflow-hidden rounded-xl border border-brand-line bg-bg-primary focus:outline-none focus:ring-2 focus:ring-brand-accent"
            aria-label={`Open ${label.toLowerCase()} photo ${idx + 1}: ${p.ai.description || 'no description'}`}
          >
            <img
              src={p.url}
              alt={p.ai.description || `${label} photo ${idx + 1}`}
              loading="lazy"
              decoding="async"
              className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
            {p.ai.damage && (
              <span className="absolute left-2 top-2 rounded-full bg-brand-err/90 px-2 py-0.5 text-xs font-bold text-white">
                Damage
              </span>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}

function Lightbox({
  photo,
  onClose,
  panelRef,
  closing,
  onTabKeyDown,
}: {
  readonly photo: JobPhoto;
  /** Animated close — routes through the shared `requestClose`. */
  readonly onClose: () => void;
  readonly panelRef: RefObject<HTMLDivElement>;
  readonly closing: boolean;
  readonly onTabKeyDown: (e: ReactKeyboardEvent<HTMLElement>) => void;
}) {
  return (
    <div
      ref={panelRef}
      role="dialog"
      aria-modal="true"
      aria-label={photo.ai.description || 'Job photo'}
      data-closing={closing ? 'true' : undefined}
      onKeyDown={onTabKeyDown}
      className={`${MODAL_BACKDROP_CLASS} fixed inset-0 z-50 flex items-center justify-center bg-bg-primary/95 p-4`}
      onClick={onClose}
    >
      <button
        type="button"
        aria-label="Close"
        onClick={(e) => {
          e.stopPropagation();
          onClose();
        }}
        className="absolute right-4 top-4 min-h-[44px] min-w-[44px] rounded-full bg-bg-elevated px-3 py-1 text-brand-ink transition-[transform,background-color] duration-[333ms] hover:scale-105 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
      >
        Close
      </button>
      <figure
        data-closing={closing ? 'true' : undefined}
        className={`${MODAL_PANEL_CLASS} relative max-h-full max-w-4xl`}
        onClick={(ev) => ev.stopPropagation()}
      >
        <img
          src={photo.url}
          alt={photo.ai.description || 'Job photo'}
          className="max-h-[80vh] w-auto rounded-xl border border-brand-line"
        />
        <figcaption className="mt-3 space-y-1 text-sm text-brand-ink">
          {photo.ai.description && <p>{photo.ai.description}</p>}
          {photo.ai.tags.length > 0 && (
            <p className="flex flex-wrap gap-2">
              {photo.ai.tags.map((t) => (
                <span
                  key={t}
                  className="rounded-full border border-brand-line bg-bg-elevated px-2 py-0.5 text-xs text-brand-mute"
                >
                  {t}
                </span>
              ))}
            </p>
          )}
          {photo.geo && (
            <p className="text-xs text-brand-mute">
              GPS: {photo.geo.lat.toFixed(4)}, {photo.geo.lng.toFixed(4)}
            </p>
          )}
        </figcaption>
      </figure>
    </div>
  );
}

/**
 * Best-effort batch download. Sequential `<a download>` clicks avoid a JSZip
 * dependency; browsers throttle to ~3-4 concurrent saves so this scales fine
 * for the worst-case 8-photo recap. Tests stub this out.
 */
async function downloadAll(photos: readonly JobPhoto[], bookingId: string): Promise<void> {
  for (let i = 0; i < photos.length; i++) {
    const p = photos[i];
    if (!p) continue;
    const a = document.createElement('a');
    a.href = p.url;
    a.download = `${bookingId}-${p.kind}-${String(i + 1).padStart(2, '0')}.${extFromMime(p.mime)}`;
    a.rel = 'noopener';
    document.body.appendChild(a);
    a.click();
    a.remove();
    // Small gap so browsers don't dedup the click as a single user gesture.
    await new Promise((r) => setTimeout(r, 250));
  }
}

function extFromMime(mime: string): string {
  switch (mime) {
    case 'image/jpeg':
      return 'jpg';
    case 'image/png':
      return 'png';
    case 'image/webp':
      return 'webp';
    case 'image/heic':
      return 'heic';
    default:
      return 'bin';
  }
}
