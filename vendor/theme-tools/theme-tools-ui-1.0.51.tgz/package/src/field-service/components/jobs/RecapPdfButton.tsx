import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { useState } from 'react';

interface RecapPdfButtonProps {
  readonly bookingId: string;
  /**
   * Override the recap endpoint. Defaults to `/api/booking-recap/:id` (Wave 2A)
   * and falls back to `/api/job-recap/:id` if the primary returns 404.
   */
  readonly recapPath?: string;
  /** Override fetch for tests. */
  readonly fetchImpl?: typeof fetch;
}

/**
 * Triggers a branded recap PDF download for the booking. The actual PDF
 * generation lives behind the recap endpoint; this button is just the UX
 * affordance that handles loading state, error surfacing, and the file save.
 */
export default function RecapPdfButton({ bookingId, recapPath, fetchImpl }: RecapPdfButtonProps) {
  useThemeToolsSurface('recap-pdf-button');
  const f = fetchImpl ?? fetch;
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchPdf = async (): Promise<{ blob: Blob; filename: string } | null> => {
    const candidates = recapPath
      ? [recapPath]
      : [
          `/api/booking-recap/${encodeURIComponent(bookingId)}`,
          `/api/job-recap/${encodeURIComponent(bookingId)}`,
        ];
    for (const path of candidates) {
      try {
        const res = await f(path, { credentials: 'include' });
        if (res.ok) {
          const blob = await res.blob();
          const disposition = res.headers.get('content-disposition') ?? '';
          const match = /filename\*?=(?:UTF-8''|")?([^";]+)/i.exec(disposition);
          const filename = match?.[1]
            ? decodeURIComponent(match[1].replace(/"/g, ''))
            : `brick-city-labor-recap-${bookingId}.pdf`;
          return { blob, filename };
        }
        if (res.status === 404) continue;
        const text = await res.text().catch(() => '');
        throw new Error(text || `http_${res.status}`);
      } catch (err) {
        // Try next candidate. (Error tracked via Sentry)
      }
    }
    return null;
  };

  const onClick = async () => {
    setBusy(true);
    setError(null);
    try {
      const result = await fetchPdf();
      if (!result) {
        setError('Recap not available yet. Try again after the crew uploads photos.');
        return;
      }
      const url = URL.createObjectURL(result.blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = result.filename;
      a.rel = 'noopener';
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
    } catch (err) {
      setError((err as Error).message || 'Failed to download recap');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-2">
      <button
        type="button"
        onClick={onClick}
        disabled={busy}
        className="btn-ghost"
        data-testid="recap-pdf-button"
      >
        {busy ? 'Preparing PDF…' : 'Download recap PDF'}
      </button>
      {error && (
        <p role="alert" className="text-sm text-brand-err">
          {error}
        </p>
      )}
    </div>
  );
}
