import { useThemeToolsSurface } from '../../../field-service-primitives.js';
export { EeatStrip } from './EeatStrip.js';
export { JsonLd } from './JsonLd.js';
export { useSoleFaqPage, isRedundantFaqPage } from './sole-faqpage.js';
export {
  faqPage,
  homeServicesBusiness,
  personBrian,
  serviceWithOffer,
  type FaqEntry,
  type HomeServicesBusinessOptions,
  type PersonSchemaOptions,
  type ServiceSchemaOptions,
} from '@theme.tools/seo-geo/field-service/schemas';
