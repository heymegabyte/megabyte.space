/**
 * ServiceCategoryCalculator — Interactive category-specific scope & price
 * calculator mounted on all 9 `/services/<slug>` hub pages.
 *
 * Powered by `calculateCategoryScope` (`src/shared/category-calculators.ts`)
 * and localized in `en`, `es`, and `pt`.
 */
import { useState } from 'react';
import { Badge, useThemeToolsSurface } from '../../../field-service-primitives.js';
import {
  CATEGORY_PRESETS,
  calculateCategoryScope,
  type CategoryCalculatorInput,
} from '@theme.tools/scheduling/field-service/category-calculators';
import { buildComprehensiveCategoryDiagnostic } from '@theme.tools/scheduling/field-service/theme-tools-field-service-bridge';
import {
  normalizeToCanonicalSlug,
  type CanonicalServiceSlug,
} from '@theme.tools/seo-geo/field-service/service-slug-aliases';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { priceCalculatorCopy } from '@theme.tools/billing/field-service/price-calculator-copy';

interface ServiceCategoryCalculatorProps {
  readonly slug: string;
}

const SLIDER_BOUNDS: Readonly<
  Record<CanonicalServiceSlug, { readonly min: number; readonly max: number; readonly step: number }>
> = {
  'power-washing': { min: 200, max: 5000, step: 100 },
  'lawn-care': { min: 1000, max: 20000, step: 500 },
  hauling: { min: 1, max: 16, step: 1 },
  'light-repairs': { min: 1, max: 12, step: 1 },
  'moving-labor': { min: 1, max: 6, step: 1 },
  'furniture-removal': { min: 1, max: 15, step: 1 },
  'apartment-cleanout': { min: 1, max: 8, step: 1 },
  'paint-scraping': { min: 50, max: 2000, step: 25 },
  'loading-unloading': { min: 8, max: 26, step: 2 },
};

export function ServiceCategoryCalculator({ slug }: ServiceCategoryCalculatorProps) {
  const canonical = normalizeToCanonicalSlug(slug) ?? 'moving-labor';
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const copy = priceCalculatorCopy(locale);

  const presets = CATEGORY_PRESETS[canonical] ?? CATEGORY_PRESETS['moving-labor'];
  const defaultPreset = presets[1] ?? presets[0]!;
  const bounds = SLIDER_BOUNDS[canonical];

  const [activePresetId, setActivePresetId] = useState<string>(defaultPreset.id);
  const [primaryQty, setPrimaryQty] = useState<number>(
    defaultPreset.primaryQuantity ?? Math.round((bounds.min + bounds.max) / 3),
  );
  const [secondaryQty, setSecondaryQty] = useState<number | undefined>(
    defaultPreset.secondaryQuantity,
  );
  const [condition, setCondition] = useState<'light' | 'standard' | 'heavy' | 'severe'>(
    defaultPreset.condition ?? 'standard',
  );
  const [flightsOfStairs, setFlightsOfStairs] = useState<number>(0);
  const [hasElevator, setHasElevator] = useState<boolean>(false);
  const [homeBuiltBefore1978, setHomeBuiltBefore1978] = useState<boolean>(false);
  const [mattressCount, setMattressCount] = useState<number>(0);

  const applyPreset = (presetId: string) => {
    const idx = presets.findIndex((p) => p.id === presetId);
    const found = presets[idx];
    if (!found) return;
    setActivePresetId(found.id);
    const fallbackQty = Math.min(
      bounds.max,
      Math.max(
        bounds.min,
        Math.round(
          (bounds.min + ((bounds.max - bounds.min) * (idx + 1)) / (presets.length + 1)) /
            bounds.step,
        ) * bounds.step,
      ),
    );
    setPrimaryQty(found.primaryQuantity ?? fallbackQty);
    setSecondaryQty(found.secondaryQuantity);
    setCondition(
      found.condition ?? (idx === 0 ? 'light' : idx === presets.length - 1 ? 'heavy' : 'standard'),
    );
  };

  const calcInput: CategoryCalculatorInput = {
    service: canonical,
    primaryQuantity: primaryQty,
    secondaryQuantity: secondaryQty,
    condition,
    flightsOfStairs,
    hasElevator,
    homeBuiltBefore1978,
    disturbedPaintSqFt: canonical === 'paint-scraping' ? primaryQty : undefined,
    mattressCount,
  };

  const estimate = calculateCategoryScope(calcInput);
  const diagnostic = buildComprehensiveCategoryDiagnostic(canonical, {
    crewSize: estimate.recommendedCrew,
    estimatedHours: estimate.recommendedHours,
  });
  const surfaceProps = useThemeToolsSurface(`service-calculator-${canonical}`, [
    '@theme.tools/ui',
    '@theme.tools/scheduling',
    '@theme.tools/forms',
  ]);
  const localizedBookHref = localizedPath(locale, estimate.bookingHref);

  const showStairsControls =
    canonical === 'moving-labor' ||
    canonical === 'hauling' ||
    canonical === 'furniture-removal' ||
    canonical === 'apartment-cleanout' ||
    canonical === 'loading-unloading';

  const showMattressControl =
    canonical === 'furniture-removal' ||
    canonical === 'hauling' ||
    canonical === 'apartment-cleanout';

  const showPre1978Control = canonical === 'paint-scraping';

  return (
    <section
      className="container-pad my-10"
      aria-label={`${copy.serviceNames[canonical]} ${copy.ariaLabel}`}
      data-testid="service-category-calculator"
      data-theme-tools-surface={surfaceProps['data-theme-tools-surface']}
      data-theme-tools-pricing-model={surfaceProps['data-theme-tools-pricing-model']}
      data-theme-tools-packages={surfaceProps['data-theme-tools-packages']}
    >
      <div className="rounded-2xl border border-brand-line bg-bg-elevated p-6 sm:p-8 shadow-lg">
        <div className="flex flex-wrap items-baseline justify-between gap-3 mb-4">
          <div>
            <p className="eyebrow mb-1">{copy.categoryCalcEyebrow}</p>
            <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-brand-ink">
              {copy.categoryCalcHeading} —{' '}
              <span className="text-brand-accent">{copy.serviceNames[canonical]}</span>
            </h2>
          </div>
          <Badge variant="accent">
            $50{copy.perHourPerPerson} · 1h min
          </Badge>
        </div>
        <p className="text-sm text-brand-mute mb-6 max-w-3xl">
          {copy.categoryCalcSub} <span className="text-brand-accent/90">{diagnostic.engineeringSummary}</span>
        </p>

        {/* Preset pills */}
        <div className="mb-6">
          <p className="font-mono text-xs uppercase tracking-wider text-brand-mute mb-2">
            {copy.presetsLabel}
          </p>
          <div className="flex flex-wrap gap-2" role="group" aria-label={copy.presetsLabel}>
            {presets.map((preset) => {
              const isSelected = activePresetId === preset.id;
              return (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => applyPreset(preset.id)}
                  aria-pressed={isSelected}
                  data-testid={`calc-preset-${preset.id}`}
                  className={`min-h-[40px] rounded-lg border px-3.5 py-2 text-xs font-mono transition-all duration-[333ms] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent ${
                    isSelected
                      ? 'border-brand-accent bg-brand-accent text-bg-primary font-bold shadow-sm'
                      : 'border-brand-line bg-bg-primary text-brand-ink hover:border-brand-accent/60'
                  }`}
                >
                  {preset.label[locale] ?? preset.label.en}
                </button>
              );
            })}
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-12">
          {/* Left column: interactive sliders & modifiers */}
          <div className="lg:col-span-7 space-y-5 rounded-xl border border-brand-line bg-bg-primary p-5">
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <label
                  htmlFor="calc-primary-qty"
                  className="text-xs font-mono uppercase tracking-wider text-brand-mute"
                >
                  {copy.quantityLabelByService[canonical]}
                </label>
                <span className="font-mono text-base font-bold text-brand-accent tabular-nums">
                  {primaryQty.toLocaleString()}
                </span>
              </div>
              <input
                id="calc-primary-qty"
                type="range"
                min={bounds.min}
                max={bounds.max}
                step={bounds.step}
                value={primaryQty}
                onChange={(e) => {
                  setActivePresetId('custom');
                  setPrimaryQty(Number(e.target.value));
                }}
                className="w-full accent-brand-accent cursor-pointer"
              />
              <div className="flex justify-between font-mono text-[11px] text-brand-mute mt-1">
                <span>{bounds.min.toLocaleString()}</span>
                <span>{bounds.max.toLocaleString()}</span>
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <label className="flex flex-col gap-1.5">
                <span className="text-xs font-mono uppercase tracking-wider text-brand-mute">
                  {copy.conditionLabel}
                </span>
                <select
                  value={condition}
                  onChange={(e) => {
                    setActivePresetId('custom');
                    setCondition(
                      e.target.value as 'light' | 'standard' | 'heavy' | 'severe',
                    );
                  }}
                  className="rounded-lg border border-brand-line bg-bg-elevated px-3 py-2.5 text-sm text-brand-ink focus:outline-none focus:ring-2 focus:ring-brand-accent"
                >
                  <option value="light">{copy.conditions.light}</option>
                  <option value="standard">{copy.conditions.standard}</option>
                  <option value="heavy">{copy.conditions.heavy}</option>
                  <option value="severe">{copy.conditions.severe}</option>
                </select>
              </label>

              {showStairsControls && (
                <label className="flex flex-col gap-1.5">
                  <span className="text-xs font-mono uppercase tracking-wider text-brand-mute">
                    {copy.stairsLabel}
                  </span>
                  <select
                    value={flightsOfStairs}
                    onChange={(e) => setFlightsOfStairs(Number(e.target.value))}
                    className="rounded-lg border border-brand-line bg-bg-elevated px-3 py-2.5 text-sm text-brand-ink focus:outline-none focus:ring-2 focus:ring-brand-accent"
                  >
                    {[0, 1, 2, 3, 4, 5].map((f) => (
                      <option key={f} value={f}>
                        {f === 0 ? 'Ground floor / 0 flights' : `${f} flight${f > 1 ? 's' : ''}`}
                      </option>
                    ))}
                  </select>
                </label>
              )}

              {showMattressControl && (
                <label className="flex flex-col gap-1.5">
                  <span className="text-xs font-mono uppercase tracking-wider text-brand-mute">
                    {copy.mattressLabel}
                  </span>
                  <select
                    value={mattressCount}
                    onChange={(e) => setMattressCount(Number(e.target.value))}
                    className="rounded-lg border border-brand-line bg-bg-elevated px-3 py-2.5 text-sm text-brand-ink focus:outline-none focus:ring-2 focus:ring-brand-accent"
                  >
                    {[0, 1, 2, 3, 4, 5, 6].map((m) => (
                      <option key={m} value={m}>
                        {m} {m === 1 ? 'mattress / box spring' : 'mattresses'}
                      </option>
                    ))}
                  </select>
                </label>
              )}
            </div>

            {showStairsControls && (
              <label className="inline-flex items-center gap-2.5 text-sm text-brand-ink cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={hasElevator}
                  onChange={(e) => setHasElevator(e.target.checked)}
                  className="h-4 w-4 rounded border-brand-line accent-brand-accent"
                />
                <span>{copy.elevatorLabel}</span>
              </label>
            )}

            {showPre1978Control && (
              <label className="inline-flex items-center gap-2.5 text-sm text-brand-ink cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={homeBuiltBefore1978}
                  onChange={(e) => setHomeBuiltBefore1978(e.target.checked)}
                  className="h-4 w-4 rounded border-brand-line accent-brand-accent"
                />
                <span>{copy.pre1978Label}</span>
              </label>
            )}

            {/* Compliance & technical badges */}
            <div className="pt-2 border-t border-brand-line/60">
              <div className="flex flex-wrap gap-1.5">
                {estimate.complianceBadges.map((badge) => (
                  <span
                    key={badge}
                    className="inline-flex items-center rounded-md border border-brand-accent/30 bg-brand-accent/10 px-2.5 py-1 font-mono text-[11px] text-brand-accent"
                  >
                    ✓ {badge}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Right column: live deterministic output & prefilled CTA */}
          <div
            className="lg:col-span-5 flex flex-col justify-between rounded-xl border border-brand-accent/40 bg-bg-primary p-5"
            aria-live="polite"
          >
            <div>
              <div className="flex items-baseline justify-between gap-2">
                <span className="font-mono text-xs uppercase tracking-wider text-brand-mute">
                  {copy.estimatedRangeLabel}
                </span>
                <span className="font-mono text-xs text-brand-accent font-semibold">
                  {estimate.unitSummary}
                </span>
              </div>

              <div
                className="mt-2 font-display text-4xl sm:text-5xl font-extrabold text-brand-ink tabular-nums"
                data-testid="service-calc-price-range"
              >
                ${estimate.estimatedMinDollars}
                <span className="text-brand-mute text-2xl font-normal">
                  {' '}
                  – ${estimate.estimatedMaxDollars}
                </span>
              </div>

              <p className="mt-1 text-xs font-mono text-brand-mute">
                {copy.recommendedScopeLabel}:{' '}
                <strong className="text-brand-ink">
                  {estimate.recommendedCrew}{' '}
                  {estimate.recommendedCrew > 1 ? copy.personPlural : copy.personSingular} ×{' '}
                  {estimate.recommendedHours}{' '}
                  {estimate.recommendedHours > 1 ? copy.hourPlural : copy.hourSingular}
                </strong>{' '}
                (${estimate.baseLaborDollars} base
                {estimate.materialsFeeDollars > 0
                  ? ` + $${estimate.materialsFeeDollars} bags`
                  : ''}
                )
              </p>

              <p className="mt-1 text-[11px] font-mono text-emerald-400">
                ${estimate.depositDollars} (20%) — {copy.depositSplitLabel}
              </p>

              {estimate.warnings.length > 0 && (
                <div className="mt-4 space-y-2">
                  {estimate.warnings.map((warn) => (
                    <div
                      key={warn}
                      role="status"
                      className="rounded-lg border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-xs text-amber-200 leading-relaxed"
                    >
                      ⚠️ {warn}
                    </div>
                  ))}
                </div>
              )}

              <div className="mt-4 pt-3 border-t border-brand-line">
                <p className="font-mono text-[11px] uppercase tracking-wider text-brand-mute mb-1.5">
                  {copy.prepChecklistHeading}
                </p>
                <ul className="space-y-1 text-xs text-brand-mute">
                  {estimate.checklist.map((item) => (
                    <li key={item} className="flex items-start gap-1.5">
                      <span className="text-brand-accent">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <a
              href={localizedBookHref}
              data-testid="service-calc-book-cta"
              className="mt-5 inline-flex min-h-[46px] w-full items-center justify-center rounded-lg bg-brand-accent px-5 py-3 text-center text-sm font-bold text-bg-primary transition-all duration-[333ms] hover:bg-brand-accent-bright focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
            >
              {copy.bookCta}
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
