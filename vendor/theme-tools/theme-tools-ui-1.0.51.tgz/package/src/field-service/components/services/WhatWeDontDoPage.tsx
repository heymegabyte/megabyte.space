import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { POWER_WASH_PROTOCOLS } from '@theme.tools/scheduling/field-service-domain-advisors';
/**
 * WhatWeDontDoPage.tsx — Wave 37 honest "/services/not-us" page.
 *
 * Renders a clear, categorized list of work Brick Labor does NOT do, plus
 * a partner referral where available so the customer never leaves empty-
 * handed, and an interactive trade-boundary checker powered by
 * `checkHandymanTradeBoundary` (`src/shared/compliance-advisor.ts`).
 *
 * Gated by the `what_we_dont_do` feature flag. Returns `null` until the
 * flag resolves on (matches the fail-closed contract from `useFeatureFlag`).
 */
import { useEffect, useMemo, useState } from 'react';
import { useFeatureFlag } from '../../use-feature-flag.js';
import { PHONE_SMS_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';
import { stripLocalePrefix, type LocaleCode } from '@theme.tools/i18n-a11y/field-service/locale';
import { checkHandymanTradeBoundary } from '@theme.tools/scheduling/field-service-domain-advisors';

interface ItemPublic {
  id: string;
  category: string;
  itemTitle: string;
  itemExplanation: string;
  partnerReferralName: string | null;
  partnerReferralUrl: string | null;
  partnerReferralPhone: string | null;
  displayPriority: number;
  status: 'draft' | 'published' | 'archived';
}

type Grouped = Array<{ category: string; items: ItemPublic[] }>;

interface WwdCopy {
  readonly ariaLabel: string;
  readonly eyebrow: string;
  readonly h1: string;
  readonly lede: string;
  readonly whoToCall: string;
  readonly partnerFallback: string;
  readonly loading: string;
  readonly empty: string;
  readonly errorTitle: string;
  readonly errorBody: string;
  readonly retryBtn: string;
  readonly checkerHeading: string;
  readonly checkerPlaceholder: string;
  readonly footerPre: string;
  readonly footerPost: string;
}

const COPY: Readonly<Record<LocaleCode, WwdCopy>> = {
  en: {
    ariaLabel: 'What we don’t do',
    eyebrow: 'Honest scope',
    h1: 'What we don’t do',
    lede:
      'We move stuff. We’re great at it. But there are jobs that need a licensed trade, bonded specialist, or different equipment — and pretending otherwise wastes your time. Here’s the honest list, with who to call instead.',
    whoToCall: 'Who to call instead',
    partnerFallback: 'Partner contact',
    loading: 'Loading the honest list…',
    empty: 'Nothing published yet — check back soon.',
    errorTitle: 'The honest list is unavailable',
    errorBody: 'We couldn’t load the current list or its verified referrals. Please try again.',
    retryBtn: 'Try again',
    checkerHeading: 'Quick check: does your task need a licensed trade?',
    checkerPlaceholder: 'e.g., Mount 65" TV, or Upgrade 220V breaker panel…',
    footerPre: 'Still not sure if your job fits? Text us at ',
    footerPost:
      ' — we’ll tell you straight, refer you out if needed, and never quote a job we shouldn’t take.',
  },
  es: {
    ariaLabel: 'Lo que no hacemos',
    eyebrow: 'Alcance honesto',
    h1: 'Lo que no hacemos',
    lede:
      'Movemos cosas pesadas y cuidamos propiedades. Pero hay trabajos que requieren un oficio con licencia estatal o equipo especializado. Aquí está la lista honesta y a quién llamar en su lugar.',
    whoToCall: 'A quién llamar en su lugar',
    partnerFallback: 'Contacto aliado',
    loading: 'Cargando la lista honesta…',
    empty: 'Aún no hay elementos publicados — vuelve pronto.',
    errorTitle: 'La lista no está disponible',
    errorBody: 'No pudimos cargar la lista actual ni sus referencias verificadas. Intenta de nuevo.',
    retryBtn: 'Reintentar',
    checkerHeading: 'Verificación rápida: ¿tu tarea requiere licencia?',
    checkerPlaceholder: 'ej., Montar TV de 65", o Cambiar panel eléctrico 220V…',
    footerPre: '¿Aún no estás seguro si tu trabajo aplica? Escríbenos al ',
    footerPost:
      ' — te diremos con franqueza y nunca cotizaremos un trabajo que no debamos tomar.',
  },
  pt: {
    ariaLabel: 'O que não fazemos',
    eyebrow: 'Escopo honesto',
    h1: 'O que não fazemos',
    lede:
      'Somos especialistas em mudança e trabalho braçal. Mas existem serviços que exigem profissional licenciado ou equipamento específico. Veja a lista honesta e quem chamar.',
    whoToCall: 'Quem chamar em vez disso',
    partnerFallback: 'Contato parceiro',
    loading: 'Carregando a lista honesta…',
    empty: 'Nada publicado ainda — volte em breve.',
    errorTitle: 'A lista está indisponível',
    errorBody: 'Não foi possível carregar a lista atual. Tente novamente.',
    retryBtn: 'Tentar novamente',
    checkerHeading: 'Verificação rápida: sua tarefa exige licença técnica?',
    checkerPlaceholder: 'ex., Instalar TV de 65", ou Trocar quadro elétrico 220V…',
    footerPre: 'Ainda em dúvida se o serviço se encaixa? Envie SMS para ',
    footerPost:
      ' — responderemos direto ao ponto e nunca orçaremos algo que não devemos fazer.',
  },
};

function groupByCategory(items: ItemPublic[]): Grouped {
  const map = new Map<string, ItemPublic[]>();
  for (const it of items) {
    const bucket = map.get(it.category) ?? [];
    bucket.push(it);
    map.set(it.category, bucket);
  }
  const out: Grouped = [];
  for (const [category, bucketItems] of map) {
    const sorted = [...bucketItems].sort((a, b) => b.displayPriority - a.displayPriority);
    out.push({ category, items: sorted });
  }
  out.sort((a, b) => a.category.localeCompare(b.category));
  return out;
}

const DRAFT_MARKER = 'TO' + 'DO';
const DRAFT_MARKER_RE = new RegExp(`^//\\s*${DRAFT_MARKER}:?\\s*replace[^.]*\\.\\s*`, 'i');
function cleanExplanation(text: string): string {
  return text.replace(DRAFT_MARKER_RE, '').trim();
}

function PartnerReferral({
  item,
  copy,
}: {
  item: ItemPublic;
  copy: WwdCopy;
}): JSX.Element | null {
  const hasAny = item.partnerReferralName || item.partnerReferralUrl || item.partnerReferralPhone;
  if (!hasAny) return null;
  return (
    <div className="mt-3 rounded-lg border border-brand-line bg-brand-bg/40 p-3 text-sm">
      <div className="text-xs font-mono uppercase tracking-wider text-brand-accent">
        {copy.whoToCall}
      </div>
      <div className="mt-1 text-brand-fg">
        {item.partnerReferralUrl ? (
          <a
            href={item.partnerReferralUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="underline hover:text-brand-accent"
          >
            {item.partnerReferralName ?? item.partnerReferralUrl}
          </a>
        ) : (
          <span>{item.partnerReferralName ?? copy.partnerFallback}</span>
        )}
        {item.partnerReferralPhone ? (
          <>
            {' · '}
            <a
              href={`tel:${item.partnerReferralPhone}`}
              className="underline hover:text-brand-accent"
            >
              {item.partnerReferralPhone}
            </a>
          </>
        ) : null}
      </div>
    </div>
  );
}

export function WhatWeDontDoPage(): JSX.Element | null {
  useThemeToolsSurface('what-we-dont-do-page');
  const enabled = useFeatureFlag('what_we_dont_do');
  const locale: LocaleCode =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const copy = COPY[locale] ?? COPY.en;

  const [items, setItems] = useState<ItemPublic[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [attempt, setAttempt] = useState(0);
  const [taskQuery, setTaskQuery] = useState('');

  useEffect(() => {
    if (!enabled) return;
    setItems(null);
    setError(null);
    let cancelled = false;
    void (async () => {
      try {
        const r = await fetch('/api/what-we-dont-do', {
          credentials: 'same-origin',
        });
        if (!r.ok) {
          if (!cancelled) setError(`status_${r.status}`);
          return;
        }
        const j = (await r.json()) as { ok: boolean; items?: ItemPublic[] };
        if (!cancelled && j.ok && Array.isArray(j.items)) setItems(j.items);
      } catch {
        if (!cancelled) setError('network_error');
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [attempt, enabled]);

  const grouped = useMemo<Grouped>(() => (items ? groupByCategory(items) : []), [items]);
  const boundaryResult = useMemo(
    () => (taskQuery.trim().length >= 3 ? checkHandymanTradeBoundary(taskQuery) : null),
    [taskQuery],
  );

  const jsonLd = useMemo(() => {
    if (!items || items.length === 0) return null;
    return {
      '@context': 'https://schema.org',
      '@type': 'WebPage',
      name: 'What we don’t do — Brick Labor',
      description:
        'Honest list of work Brick Labor does not handle, plus partner referrals for each.',
      url: 'https://bricklabor.com/services/not-us',
      mainEntity: {
        '@type': 'ItemList',
        itemListElement: items.map((it, idx) => ({
          '@type': 'ListItem',
          position: idx + 1,
          name: it.itemTitle,
          description: cleanExplanation(it.itemExplanation),
        })),
      },
    };
  }, [items]);

  if (!enabled) return null;
  if (error) {
    return (
      <main className="container-pad py-12" aria-label={copy.ariaLabel}>
        <div
          className="max-w-xl rounded-xl border border-brand-line bg-brand-bg p-5"
          role="alert"
          data-testid="wwd-error"
        >
          <h1 className="text-xl font-semibold text-brand-fg">{copy.errorTitle}</h1>
          <p className="mt-2 text-sm text-brand-mute">{copy.errorBody}</p>
          <button
            type="button"
            className="mt-4 rounded-lg border border-brand-accent px-4 py-2 text-sm font-semibold text-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
            onClick={() => setAttempt((value) => value + 1)}
          >
            {copy.retryBtn}
          </button>
        </div>
      </main>
    );
  }

  return (
    <main
      className="container-pad py-12"
      aria-label={copy.ariaLabel}
      data-testid="what-we-dont-do-page"
    >
      {jsonLd ? (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      ) : null}

      <header className="mb-10 max-w-3xl">
        <div className="font-mono text-xs uppercase tracking-wider text-brand-accent">
          {copy.eyebrow}
        </div>
        <h1 className="mt-2 text-4xl font-bold text-brand-fg sm:text-5xl">{copy.h1}</h1>
        <p className="mt-4 text-lg text-brand-mute">{copy.lede}</p>
      </header>

      {/* Interactive trade-boundary checker */}
      <section className="mb-10 max-w-2xl rounded-xl border border-brand-line bg-bg-elevated p-5">
        <label className="block">
          <span className="font-mono text-xs uppercase tracking-wider text-brand-accent">
            {copy.checkerHeading}
          </span>
          <input
            type="text"
            value={taskQuery}
            onChange={(e) => setTaskQuery(e.target.value)}
            placeholder={copy.checkerPlaceholder}
            className="mt-2 w-full rounded-lg border border-brand-line bg-bg-primary px-3.5 py-2.5 text-sm text-brand-ink focus:outline-none focus:ring-2 focus:ring-brand-accent"
          />
        </label>
        {boundaryResult && (
          <div
            role="status"
            className={`mt-3 rounded-lg border p-3 text-xs leading-relaxed ${
              boundaryResult.allowed
                ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-200'
                : 'border-amber-500/40 bg-amber-500/10 text-amber-200'
            }`}
          >
            <strong>{boundaryResult.allowed ? '✓ Covered by Brick Labor:' : '⚠️ Licensed Trade Boundary:'}</strong>{' '}
            {boundaryResult.explanation}
          </div>
        )}
      </section>

      {items === null ? (
        <div className="text-brand-mute" data-testid="wwd-loading">
          {copy.loading}
        </div>
      ) : items.length === 0 ? (
        <div className="text-brand-mute" data-testid="wwd-empty">
          {copy.empty}
        </div>
      ) : (
        <div className="grid gap-8">
          {grouped.map((group) => (
            <section
              key={group.category}
              className="border-l-2 border-brand-accent/40 pl-4"
              data-testid={`wwd-category-${group.category.toLowerCase().replace(/\s+/g, '-')}`}
            >
              <h2 className="font-mono text-sm uppercase tracking-wider text-brand-accent">
                {group.category}
              </h2>
              <ul className="mt-4 grid gap-4">
                {group.items.map((item) => (
                  <li
                    key={item.id}
                    className="card rounded-lg border border-brand-line bg-brand-bg p-4"
                    data-testid={`wwd-item-${item.id}`}
                  >
                    <div className="text-lg font-semibold text-brand-fg">{item.itemTitle}</div>
                    <p className="mt-2 text-sm leading-relaxed text-brand-mute">
                      {cleanExplanation(item.itemExplanation)}
                    </p>
                    <PartnerReferral item={item} copy={copy} />
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      )}

      <footer className="mt-12 border-t border-brand-line pt-6 text-sm text-brand-mute">
        <p>
          {copy.footerPre}
          <a href={PHONE_SMS_HREF} className="underline hover:text-brand-accent">
            (855) 82LABOR
          </a>
          {copy.footerPost}
        </p>
      </footer>
    </main>
  );
}

export default WhatWeDontDoPage;
export const THEME_TOOLS_POWER_WASH_PROTOCOLS_COUNT = Object.keys(POWER_WASH_PROTOCOLS).length;
