import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { useEffect, useRef, useState, type JSX, type ReactNode } from 'react';
import { useRovingMenu, type RovingMenuItemProps } from '../../use-roving-menu.js';
import { menuTriggerOpensOn } from '@theme.tools/i18n-a11y/field-service/menu-keynav';

/**
 * Top-right user avatar that opens a dropdown menu. Shared across every
 * dashboard shell (/me, /work/dashboard, /admin/*).
 *
 * Avatar = initials on brand-orange unless a real image url is supplied.
 * Menu = role-aware sections (My account / Sign in as crew / Sign out / etc).
 * Closes on Esc, outside click, or selecting any item. Focus traps inside
 * while open. Mobile-friendly tap target (44×44 min).
 */

export interface UserAvatarMenuItem {
  readonly label: string;
  readonly href?: string;
  readonly onClick?: () => void;
  readonly icon?: string;
  readonly danger?: boolean;
  readonly external?: boolean;
}

export interface UserAvatarMenuGroup {
  readonly label?: string;
  readonly items: ReadonlyArray<UserAvatarMenuItem>;
}

export interface UserAvatarMenuProps {
  readonly displayName: string;
  readonly subtitle?: string;
  readonly avatarUrl?: string | null;
  readonly groups: ReadonlyArray<UserAvatarMenuGroup>;
  readonly className?: string;
}

function initialsFromName(name: string): string {
  const cleaned = name.trim();
  if (!cleaned) return '?';
  const parts = cleaned.split(/\s+/).slice(0, 2);
  return parts.map((p) => p[0]?.toUpperCase() ?? '').join('') || '?';
}

export function UserAvatarMenu({
  displayName,
  subtitle,
  avatarUrl,
  groups,
  className = '',
}: UserAvatarMenuProps): JSX.Element {
  useThemeToolsSurface('user-avatar-menu');
  const [open, setOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);

  // ARIA menu roving-tabindex: one tab stop, arrow/Home/End move focus, focus
  // lands on the first item when the menu opens. axe can't see this gap.
  const totalItems = groups.reduce((n, g) => n + g.items.length, 0);
  const menuItem = useRovingMenu(totalItems, open);
  const groupOffsets: number[] = [];
  {
    let acc = 0;
    for (const g of groups) {
      groupOffsets.push(acc);
      acc += g.items.length;
    }
  }

  useEffect(() => {
    if (!open) return;
    function onDown(e: MouseEvent) {
      if (menuRef.current?.contains(e.target as Node)) return;
      if (buttonRef.current?.contains(e.target as Node)) return;
      setOpen(false);
    }
    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') {
        setOpen(false);
        buttonRef.current?.focus();
      }
    }
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const initials = initialsFromName(displayName);

  return (
    <div className={`relative ${className}`}>
      <button
        ref={buttonRef}
        type="button"
        onClick={() => setOpen((v) => !v)}
        onKeyDown={(e) => {
          // APG menu-button: ArrowDown/ArrowUp open the menu (useRovingMenu then
          // moves focus to the first item on open). Enter/Space open natively.
          if (menuTriggerOpensOn(e.key)) {
            e.preventDefault();
            setOpen(true);
          }
        }}
        aria-expanded={open}
        aria-haspopup="menu"
        aria-label={`Open account menu for ${displayName}`}
        className="flex items-center gap-2 rounded-full border border-brand-line bg-bg-elevated/70 hover:bg-bg-elevated hover:border-brand-accent transition-colors p-1 pr-3 min-h-[40px]"
      >
        <span
          className="grid place-items-center h-8 w-8 rounded-full bg-brand-accent text-bg-primary font-display font-extrabold text-sm shrink-0 overflow-hidden"
          aria-hidden
        >
          {avatarUrl ? (
            <img src={avatarUrl} alt="" className="h-full w-full object-cover" />
          ) : (
            initials
          )}
        </span>
        <span className="hidden sm:flex flex-col items-start leading-tight min-w-0 max-w-[140px]">
          <span className="text-xs font-bold text-brand-ink truncate w-full">{displayName}</span>
          {subtitle && (
            <span className="font-mono text-[10px] uppercase tracking-wider text-brand-mute truncate w-full">
              {subtitle}
            </span>
          )}
        </span>
        <svg
          viewBox="0 0 20 20"
          aria-hidden
          className={`h-3.5 w-3.5 text-brand-mute transition-transform ${open ? 'rotate-180' : ''}`}
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <polyline points="6 8 10 12 14 8" />
        </svg>
      </button>

      {open && (
        <div
          ref={menuRef}
          role="menu"
          aria-label={`${displayName} account menu`}
          className="absolute right-0 top-full mt-2 z-50 w-64 rounded-xl border border-brand-line bg-bg-elevated shadow-2xl overflow-hidden animate-fade-in"
        >
          <div className="px-4 py-3 border-b border-brand-line bg-bg-primary/40">
            <p className="text-sm font-bold text-brand-ink truncate">{displayName}</p>
            {subtitle && (
              <p className="font-mono text-[11px] uppercase tracking-wider text-brand-mute mt-0.5 truncate">
                {subtitle}
              </p>
            )}
          </div>
          {groups.map((group, gi) => (
            <div key={gi} className={gi > 0 ? 'border-t border-brand-line' : ''}>
              {group.label && (
                <p className="px-4 pt-2 pb-1 font-mono text-[10px] uppercase tracking-wider text-brand-mute">
                  {group.label}
                </p>
              )}
              <ul className="py-1">
                {group.items.map((item, i) => (
                  <li key={i}>
                    <MenuRow
                      item={item}
                      rovingProps={menuItem(groupOffsets[gi]! + i)}
                      onClose={() => setOpen(false)}
                    />
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function MenuRow({
  item,
  rovingProps,
  onClose,
}: {
  item: UserAvatarMenuItem;
  rovingProps: RovingMenuItemProps;
  onClose: () => void;
}): JSX.Element {
  const cls = `flex items-center gap-3 px-4 py-2 text-sm transition-all duration-[333ms] w-full text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-brand-accent ${
    item.danger
      ? 'text-red-300 hover:bg-red-500/10 focus-visible:bg-red-500/10 hover:text-red-200 focus-visible:text-red-200'
      : 'text-brand-ink hover:bg-brand-accent/10 focus-visible:bg-brand-accent/10 hover:text-brand-accent focus-visible:text-brand-accent'
  }`;
  const inner: ReactNode = (
    <>
      {item.icon && (
        <span className="w-4 text-center font-mono text-brand-mute" aria-hidden>
          {item.icon}
        </span>
      )}
      <span className="flex-1 truncate">{item.label}</span>
      {item.external && (
        <span className="text-brand-mute" aria-hidden>
          ↗
        </span>
      )}
    </>
  );
  if (item.href) {
    return (
      <a
        href={item.href}
        onClick={onClose}
        className={cls}
        role="menuitem"
        target={item.external ? '_blank' : undefined}
        rel={item.external ? 'noopener noreferrer' : undefined}
        {...rovingProps}
      >
        {inner}
      </a>
    );
  }
  return (
    <button
      type="button"
      onClick={() => {
        onClose();
        item.onClick?.();
      }}
      className={cls}
      role="menuitem"
      {...rovingProps}
    >
      {inner}
    </button>
  );
}
