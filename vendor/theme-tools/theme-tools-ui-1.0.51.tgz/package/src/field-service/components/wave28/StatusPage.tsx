import { useThemeToolsSurface } from '../../../field-service-primitives.js';
/**
 * StatusPage — public /status surface.
 *
 * Polls /api/wave28-status every 30s; renders component pills + last 25
 * incidents. When the flag is off the API returns "all systems normal"
 * (NOT 404) so this page degrades cleanly into a steady-state confidence
 * surface.
 */
import { useEffect, useState } from 'react';

type ComponentStatus = 'operational' | 'degraded' | 'down';

interface Component {
  name: string;
  status: ComponentStatus;
  severity?: string;
}

interface Incident {
  id: string;
  component: string;
  severity: string;
  title: string;
  description: string | null;
  started_at: string;
  resolved_at: string | null;
}

interface StatusPayload {
  ok: true;
  status: 'all_systems_normal' | 'degraded';
  components: Component[];
  incidents: Incident[];
  generatedAt: string;
}

const STATUS_COLOR: Record<ComponentStatus, string> = {
  operational: 'bg-emerald-600/20 text-emerald-300',
  degraded: 'bg-amber-600/20 text-amber-300',
  down: 'bg-rose-600/20 text-rose-300',
};

export default function StatusPage(): JSX.Element {
  useThemeToolsSurface('status-page');
  const [data, setData] = useState<StatusPayload | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    async function load(): Promise<void> {
      try {
        const r = await fetch('/api/wave28-status', { cache: 'no-store' });
        const j = (await r.json()) as StatusPayload;
        if (alive) setData(j);
      } catch (err) {
        if (alive) setError((err as Error).message);
      }
    }
    void load();
    const t = setInterval(load, 30_000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, []);

  return (
    <main className="mx-auto max-w-3xl px-4 py-12" aria-labelledby="status-h1">
      <h1 id="status-h1" className="text-2xl font-semibold text-neutral-100">
        System status
      </h1>
      <p className="mt-2 text-sm text-neutral-400">
        Live status of dispatch, payments, messaging, and infrastructure.{' '}
        <a href="/api/wave28-status/rss" className="text-cyan-400 hover:underline">
          RSS
        </a>
      </p>

      {error && <p className="mt-6 text-sm text-rose-400">Unable to load status: {error}</p>}

      {data && (
        <>
          <section className="mt-6 rounded-lg border border-neutral-800 bg-neutral-900/50 p-4">
            <p
              className={`text-sm font-medium ${
                data.status === 'all_systems_normal' ? 'text-emerald-300' : 'text-amber-300'
              }`}
            >
              {data.status === 'all_systems_normal'
                ? 'All systems normal'
                : 'Some systems degraded'}
            </p>
            <ul className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {data.components.map((c) => (
                <li
                  key={c.name}
                  className={`flex items-center justify-between rounded-md px-3 py-2 text-xs ${STATUS_COLOR[c.status]}`}
                >
                  <span className="truncate">{c.name}</span>
                  <span className="ml-2 text-[10px] uppercase tracking-wider">{c.status}</span>
                </li>
              ))}
            </ul>
          </section>

          <section className="mt-8" aria-label="Recent incidents">
            <h2 className="text-lg font-semibold text-neutral-100">Recent incidents</h2>
            {data.incidents.length === 0 && (
              <p className="mt-2 text-sm text-neutral-400">No incidents reported.</p>
            )}
            <ul className="mt-4 flex flex-col gap-3">
              {data.incidents.map((i) => (
                <li
                  key={i.id}
                  id={`i-${i.id}`}
                  className="rounded-md border border-neutral-800 bg-neutral-900/50 p-3"
                >
                  <p className="text-sm font-medium text-neutral-100">{i.title}</p>
                  <p className="mt-1 text-xs text-neutral-400">
                    {i.component} · {i.severity} · started {i.started_at}
                    {i.resolved_at && ` · resolved ${i.resolved_at}`}
                  </p>
                  {i.description && (
                    <p className="mt-2 text-sm text-neutral-300">{i.description}</p>
                  )}
                </li>
              ))}
            </ul>
          </section>
        </>
      )}
    </main>
  );
}
