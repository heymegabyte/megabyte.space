import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { useEffect, useState } from 'react';
import { useFeatureFlag } from '../../use-feature-flag.js';

/**
 * AddonShopModal — self-serve add-on purchases for a confirmed booking.
 * Fetches catalog from /api/addon-shop/catalog, lets customer add
 * packing tape, blankets, dollies, boxes, wrap to a booking. Submits via
 * POST /api/addon-shop/purchase; payment reconciled at job-close.
 *
 * Flag: addon_shop_self_serve
 */
interface CatalogItem {
  sku: string;
  name: string;
  unit_cents: number;
  description: string;
  max_quantity: number;
}

interface Props {
  bookingId: string;
  onClose?: () => void;
}

export default function AddonShopModal(props: Props): JSX.Element | null {
  useThemeToolsSurface('addon-shop-modal');
  const enabled = useFeatureFlag('addon_shop_self_serve');
  const [catalog, setCatalog] = useState<CatalogItem[]>([]);
  const [qty, setQty] = useState<Record<string, number>>({});
  const [busy, setBusy] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => {
    if (!enabled) return;
    const ac = new AbortController();
    fetch('/api/addon-shop/catalog', { signal: ac.signal, credentials: 'same-origin' })
      .then((r) => (r.ok ? r.json() : null))
      .then((j) => {
        if (j && (j as { ok: boolean }).ok) setCatalog((j as { catalog: CatalogItem[] }).catalog);
      })
      .catch(() => {});
    return () => ac.abort();
  }, [enabled]);

  if (!enabled) return null;

  async function purchase(sku: string): Promise<void> {
    const quantity = qty[sku] ?? 1;
    setBusy(sku);
    setMsg(null);
    try {
      const r = await fetch('/api/addon-shop/purchase', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ booking_id: props.bookingId, sku, quantity }),
      });
      const j = (await r.json()) as { ok: boolean; error?: string };
      setMsg(j.ok ? `Added ${quantity}× ${sku}` : `Failed: ${j.error ?? 'unknown'}`);
    } catch {
      setMsg('Network error.');
    } finally {
      setBusy(null);
    }
  }

  return (
    <section
      data-bcl-component="wave29-addon-shop"
      aria-labelledby="addon-shop-heading"
      className="rounded-2xl border border-brand-line bg-brand-card/60 p-5 my-4"
      data-animate="fade-up"
    >
      <header className="flex items-baseline justify-between mb-3">
        <h3 id="addon-shop-heading" className="text-base font-semibold text-brand-ink">
          Need supplies?
        </h3>
        <div className="flex items-center gap-3">
          {msg && <span className="text-xs text-brand-accent">{msg}</span>}
          {props.onClose && (
            <button
              type="button"
              onClick={props.onClose}
              className="text-sm text-brand-mute underline min-h-[44px]"
              aria-label="Close"
            >
              Close
            </button>
          )}
        </div>
      </header>
      <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3" data-stagger="80">
        {catalog.map((item) => (
          <li
            key={item.sku}
            data-animate="fade-up"
            className="rounded-xl border border-brand-line bg-brand-card p-3 transition-all duration-[333ms] hover:border-brand-accent/60 hover:-translate-y-0.5"
          >
            <div className="flex items-baseline justify-between">
              <h4 className="text-sm font-semibold text-brand-ink">{item.name}</h4>
              <span className="text-sm tabular-nums text-brand-ink">
                ${(item.unit_cents / 100).toFixed(2)}
              </span>
            </div>
            <p className="text-xs text-brand-mute mt-1">{item.description}</p>
            <div className="flex items-center gap-2 mt-2">
              <input
                type="number"
                min={1}
                max={item.max_quantity}
                value={qty[item.sku] ?? 1}
                onChange={(e) =>
                  setQty((q) => ({ ...q, [item.sku]: Math.max(1, Number(e.target.value)) }))
                }
                className="w-20 rounded-lg border border-brand-line bg-bg-elevated/60 text-brand-ink px-2 py-1.5 min-h-[40px]"
                aria-label={`Quantity for ${item.name}`}
              />
              <button
                type="button"
                disabled={busy === item.sku}
                onClick={() => purchase(item.sku)}
                className="rounded-lg bg-brand-accent text-brand-bg font-semibold px-3 py-1.5 min-h-[40px] disabled:opacity-50 hover:brightness-110 transition-all duration-[333ms]"
              >
                Add
              </button>
            </div>
          </li>
        ))}
      </ul>
      <p className="mt-3 text-xs text-brand-mute">
        Charges added at job close; payment via your booking's existing card.
      </p>
    </section>
  );
}
