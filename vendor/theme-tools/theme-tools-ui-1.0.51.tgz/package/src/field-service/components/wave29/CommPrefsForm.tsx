import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { useEffect, useState } from 'react';
import { useFeatureFlag } from '../../use-feature-flag.js';

/**
 * CommPrefsForm — granular communication preferences.
 * Eight toggles across {email, sms, push, voice} × {marketing,
 * transactional}. Transactional defaults on; marketing off. Surfaces
 * inside /me → Notifications; flag `granular_comm_prefs`. Backend lives
 * at `/api/comm-prefs` (GET fetch + PUT save).
 */
interface Prefs {
  email_marketing: boolean;
  email_transactional: boolean;
  sms_marketing: boolean;
  sms_transactional: boolean;
  push_marketing: boolean;
  push_transactional: boolean;
  voice_marketing: boolean;
  voice_transactional: boolean;
}

const CHANNELS: ReadonlyArray<{ key: 'email' | 'sms' | 'push' | 'voice'; label: string }> = [
  { key: 'email', label: 'Email' },
  { key: 'sms', label: 'SMS' },
  { key: 'push', label: 'Push' },
  { key: 'voice', label: 'Voice calls' },
];

export default function CommPrefsForm(): JSX.Element | null {
  useThemeToolsSurface('comm-prefs-form');
  const enabled = useFeatureFlag('granular_comm_prefs');
  const [prefs, setPrefs] = useState<Prefs | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => {
    if (!enabled) return;
    const ac = new AbortController();
    setLoading(true);
    fetch('/api/comm-prefs', { signal: ac.signal, credentials: 'same-origin' })
      .then((r) => (r.ok ? r.json() : null))
      .then((j) => {
        if (j && (j as { ok: boolean }).ok) setPrefs((j as { prefs: Prefs }).prefs);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
    return () => ac.abort();
  }, [enabled]);

  if (!enabled) return null;

  function toggle(key: keyof Prefs): void {
    setPrefs((p) => (p ? { ...p, [key]: !p[key] } : p));
  }

  async function save(): Promise<void> {
    if (!prefs) return;
    setBusy(true);
    setMsg(null);
    try {
      const r = await fetch('/api/comm-prefs', {
        method: 'PUT',
        credentials: 'same-origin',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(prefs),
      });
      const j = (await r.json()) as { ok: boolean; error?: string };
      setMsg(j.ok ? 'Saved.' : `Failed: ${j.error ?? 'unknown'}`);
    } catch {
      setMsg('Network error.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <section
      data-bcl-component="granular-comm-prefs"
      className="rounded-2xl border border-brand-line bg-bg-elevated/70 p-5"
    >
      <header className="mb-3 flex items-baseline justify-between gap-3">
        <h3 className="font-display text-base font-extrabold text-brand-ink">
          Communication preferences
        </h3>
        {msg && (
          <span className="text-xs font-medium text-brand-accent" role="status" aria-live="polite">
            {msg}
          </span>
        )}
      </header>
      <p className="mb-4 text-[12px] leading-relaxed text-brand-mute">
        Transactional messages (delivery updates, payment receipts) stay on to keep your bookings on
        track. Turn marketing off any time.
      </p>

      {loading && !prefs ? (
        <p className="py-6 text-center text-sm text-brand-mute" aria-live="polite">
          Loading your preferences…
        </p>
      ) : !prefs ? (
        <p className="py-6 text-center text-sm text-brand-mute">
          Preferences are unavailable right now. Try again shortly.
        </p>
      ) : (
        <>
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[11px] font-mono uppercase tracking-wider text-brand-mute">
                <th className="py-1">Channel</th>
                <th className="py-1 text-center">Marketing</th>
                <th className="py-1 text-center">Transactional</th>
              </tr>
            </thead>
            <tbody>
              {CHANNELS.map((ch) => {
                const mKey = `${ch.key}_marketing` as keyof Prefs;
                const tKey = `${ch.key}_transactional` as keyof Prefs;
                return (
                  <tr key={ch.key} className="border-t border-brand-line">
                    <td className="py-2 font-medium text-brand-ink">{ch.label}</td>
                    <td className="py-2 text-center">
                      <input
                        type="checkbox"
                        checked={prefs[mKey]}
                        onChange={() => toggle(mKey)}
                        aria-label={`${ch.label} marketing`}
                        className="h-5 w-5 cursor-pointer accent-brand-accent transition-all duration-[333ms] focus-visible:outline-2 focus-visible:outline-brand-accent"
                      />
                    </td>
                    <td className="py-2 text-center">
                      <input
                        type="checkbox"
                        checked={prefs[tKey]}
                        onChange={() => toggle(tKey)}
                        aria-label={`${ch.label} transactional`}
                        className="h-5 w-5 cursor-pointer accent-brand-accent transition-all duration-[333ms] focus-visible:outline-2 focus-visible:outline-brand-accent"
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          <div className="mt-4 flex justify-end">
            <button
              type="button"
              disabled={busy}
              onClick={save}
              className="min-h-[44px] rounded-lg bg-brand-accent px-4 py-2 font-semibold text-bg-primary transition-all duration-[333ms] hover:brightness-110 focus-visible:outline-2 focus-visible:outline-brand-accent disabled:opacity-50"
            >
              {busy ? 'Saving…' : 'Save preferences'}
            </button>
          </div>
        </>
      )}
    </section>
  );
}
