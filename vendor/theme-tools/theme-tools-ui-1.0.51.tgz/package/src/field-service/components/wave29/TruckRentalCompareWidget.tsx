import { useEffect, useState } from 'react';

/**
 * TruckRentalCompareWidget — Wave 29 #114. Self-move customers compare
 * U-Haul / Penske / Budget rates inline at quote time. Renders three
 * provider cards with the cheapest size auto-selected. On click we POST
 * /click for affiliate attribution then open the partner URL in a new tab.
 *
 * Flag-gated server-side via `wave29_truck_rental_compare`; client probes
 * the compare endpoint and renders nothing on 404.
 */
interface TruckQuote {
  provider: 'uhaul' | 'penske' | 'budget';
  providerLabel: string;
  truckSize: string;
  description: string;
  dailyCents: number;
  perMileCents: number;
  estimatedTotalCents: number;
  bookingUrl: string;
}

interface Props {
  pickupZip: string;
  dropoffZip: string;
  bookingId?: string;
}

export default function TruckRentalCompareWidget({
  pickupZip,
  dropoffZip,
  bookingId,
}: Props): JSX.Element | null {
  const [quotes, setQuotes] = useState<TruckQuote[]>([]);
  const [miles, setMiles] = useState<number>(0);
  const [hidden, setHidden] = useState(false);

  useEffect(() => {
    if (!pickupZip || !dropoffZip) return;
    const ac = new AbortController();
    fetch(`/api/truck-rental/compare?pickupZip=${pickupZip}&dropoffZip=${dropoffZip}`, {
      signal: ac.signal,
    })
      .then((r) => (r.status === 404 ? null : r.json()))
      .then((j: { ok?: boolean; quotes?: TruckQuote[]; estimatedMiles?: number } | null) => {
        if (!j?.ok) {
          setHidden(true);
          return;
        }
        setQuotes(j.quotes ?? []);
        setMiles(j.estimatedMiles ?? 0);
      })
      .catch(() => setHidden(true));
    return () => ac.abort();
  }, [pickupZip, dropoffZip]);

  if (hidden || quotes.length === 0) return null;

  // Show one row per provider — cheapest size each.
  const byProvider = new Map<string, TruckQuote>();
  for (const q of quotes) {
    const cur = byProvider.get(q.provider);
    if (!cur || q.estimatedTotalCents < cur.estimatedTotalCents) byProvider.set(q.provider, q);
  }
  const featured = Array.from(byProvider.values()).sort(
    (a, b) => a.estimatedTotalCents - b.estimatedTotalCents,
  );

  const track = async (q: TruckQuote): Promise<void> => {
    try {
      await fetch('/api/truck-rental/click', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          provider: q.provider,
          truckSize: q.truckSize,
          pickupZip,
          bookingId,
        }),
      });
    } catch {
      /* affiliate click is fire-and-forget */
    }
    window.open(q.bookingUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <section
      data-bcl-component="wave29-truck-compare"
      className="rounded-2xl border border-stone-200 bg-white p-5 my-4"
    >
      <header className="mb-3">
        <h3 className="text-base font-semibold text-stone-900">
          Doing it yourself? Compare truck rentals
        </h3>
        <p className="text-xs text-stone-500">
          Estimated {miles} miles · final pricing set at the rental site.
        </p>
      </header>

      <div className="grid gap-3 sm:grid-cols-3">
        {featured.map((q) => (
          <button
            key={q.provider}
            type="button"
            onClick={() => track(q)}
            className="text-left rounded-xl border border-stone-200 hover:border-amber-400 hover:shadow-sm transition p-3"
          >
            <div className="text-xs uppercase tracking-wider text-stone-500">{q.providerLabel}</div>
            <div className="text-lg font-semibold text-stone-900 mt-0.5">{q.truckSize}</div>
            <div className="text-xs text-stone-600 leading-tight">{q.description}</div>
            <div className="mt-2 text-xl font-semibold tabular-nums text-stone-900">
              ${(q.estimatedTotalCents / 100).toFixed(0)}
            </div>
            <div className="text-[11px] text-stone-500">
              ${(q.dailyCents / 100).toFixed(0)}/day · ${(q.perMileCents / 100).toFixed(2)}/mi
            </div>
          </button>
        ))}
      </div>
      <p className="mt-3 text-[11px] text-stone-400">
        We may earn a small commission if you book through these links — costs you nothing extra.
      </p>
    </section>
  );
}
