import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useState } from 'react';

/**
 * Wave 3A — worker-side blocklist editor.
 *
 * Workers mark past customers as "don't dispatch me to this customer again".
 * The customer is shown as an anonymized label (`cust_a4f3`) derived from
 * SHA-256(`bcl-cust|${contact}`).slice(0,4). Same hashing as Wave 2B
 * claims-board so labels reconcile across surfaces.
 */

interface PastCustomer {
  contact_hash: string;
  label: string;
  last_job_at: string | null;
  jobs_count: number;
  service_zip: string | null;
}

interface BlockEntry {
  id: string;
  worker_id: string;
  customer_contact_hash: string;
  label: string;
  reason: string | null;
  created_at: string;
}

export function BlocklistEditor() {
  useThemeToolsSurface('blocklist-editor');
  const [blocks, setBlocks] = useState<BlockEntry[]>([]);
  const [past, setPast] = useState<PastCustomer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [reasonDraft, setReasonDraft] = useState<Record<string, string>>({});

  const refresh = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/work/blocklist', { headers: { Accept: 'application/json' } });
      if (!res.ok) {
        setError(`Couldn't load blocklist (${res.status})`);
        return;
      }
      const body = (await res.json()) as { blocks: BlockEntry[]; past: PastCustomer[] };
      setBlocks(body.blocks ?? []);
      setPast(body.past ?? []);
    } catch (err) {
      setError(`Network: ${(err as Error).message}`);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const blocked = new Set(blocks.map((b) => b.customer_contact_hash));

  async function block(contactHash: string) {
    try {
      await fetch('/api/work/blocklist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contactHash,
          reason: reasonDraft[contactHash] || undefined,
        }),
      });
      void refresh();
    } catch (err) {
      setError(`Network: ${(err as Error).message}`);
    }
  }

  async function unblock(id: string) {
    try {
      await fetch(`/api/work/blocklist/${encodeURIComponent(id)}`, { method: 'DELETE' });
      void refresh();
    } catch (err) {
      setError(`Network: ${(err as Error).message}`);
    }
  }

  return (
    <section className="space-y-5" data-testid="blocklist-editor">
      <header>
        <p className="eyebrow mb-1">Customer blocklist</p>
        <h2 className="text-xl font-extrabold text-brand-ink">Don't send me to these customers</h2>
        <p className="text-sm text-brand-mute mt-1">
          The dispatcher honors this list. Customers are shown as anonymized labels — we never
          surface their identity outside the booking.
        </p>
      </header>

      {error && (
        <p role="alert" className="text-sm text-red-300">
          {error}
        </p>
      )}

      <div>
        <h3 className="text-sm uppercase tracking-wider text-brand-mute font-extrabold mb-2">
          Blocked ({blocks.length})
        </h3>
        {loading && <p className="text-sm text-brand-mute">Loading…</p>}
        {!loading && blocks.length === 0 && (
          <p className="text-sm text-brand-mute">No blocks yet.</p>
        )}
        <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {blocks.map((b) => (
            <li
              key={b.id}
              className="rounded-2xl border border-brand-line bg-brand-card p-4 flex flex-wrap items-baseline justify-between gap-2"
            >
              <div>
                <p className="font-extrabold text-brand-ink">{b.label}</p>
                <p className="text-xs text-brand-mute">{b.reason || 'No reason given'}</p>
              </div>
              <button
                type="button"
                onClick={() => void unblock(b.id)}
                className="text-xs text-brand-mute underline-hover"
              >
                Unblock
              </button>
            </li>
          ))}
        </ul>
      </div>

      <div>
        <h3 className="text-sm uppercase tracking-wider text-brand-mute font-extrabold mb-2">
          Recent customers
        </h3>
        {past.length === 0 && (
          <p className="text-sm text-brand-mute">
            No completed gigs yet — customers show up here after your first job.
          </p>
        )}
        <ul className="space-y-2">
          {past.map((p) => {
            const isBlocked = blocked.has(p.contact_hash);
            return (
              <li
                key={p.contact_hash}
                className="rounded-2xl border border-brand-line bg-brand-card p-4 flex flex-wrap items-center justify-between gap-3"
              >
                <div>
                  <p className="font-extrabold text-brand-ink">{p.label}</p>
                  <p className="text-xs text-brand-mute">
                    {p.jobs_count} job{p.jobs_count === 1 ? '' : 's'}
                    {p.service_zip ? ` · ${p.service_zip}` : ''}
                  </p>
                </div>
                {!isBlocked ? (
                  <div className="flex flex-wrap items-center gap-2">
                    <input
                      type="text"
                      placeholder="Why? (optional)"
                      value={reasonDraft[p.contact_hash] ?? ''}
                      onChange={(e) =>
                        setReasonDraft((prev) => ({
                          ...prev,
                          [p.contact_hash]: e.target.value,
                        }))
                      }
                      maxLength={500}
                      className="rounded-lg border border-brand-line bg-brand-bg px-3 py-1.5 text-xs text-brand-ink"
                    />
                    <button
                      type="button"
                      onClick={() => void block(p.contact_hash)}
                      className="rounded-lg border border-red-500/40 bg-red-500/10 px-3 py-1.5 text-xs font-bold text-red-300 hover:bg-red-500/20 transition-colors"
                    >
                      Block
                    </button>
                  </div>
                ) : (
                  <p className="text-xs font-bold text-amber-300">Blocked</p>
                )}
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
