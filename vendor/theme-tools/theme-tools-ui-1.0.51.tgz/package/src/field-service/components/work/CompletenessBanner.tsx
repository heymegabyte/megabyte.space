import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useState } from 'react';

// ─────────────────────────────────────────────────────────────────────────────
// Wave 18 — large warning card mounted at the TOP of WorkerDashboard.
//
// Four visual states:
//   • not_started → red gradient, score 0
//   • partial     → amber gradient, some progress
//   • verifying   → blue gradient, waiting on background check / Stripe / KYC
//   • ready       → renders nothing (component returns null)
//
// "Dismissible but recurring": the dismiss button hides the banner for the
// current session (sessionStorage) but it returns on next reload. We never
// hide it across sessions — incomplete profile is a working-eligibility
// blocker, not a tooltip.
// ─────────────────────────────────────────────────────────────────────────────

interface CompletenessApiResponse {
  ok: boolean;
  workerId?: string;
  score?: number;
  readyToWork?: boolean;
  readyToReceivePayouts?: boolean;
  missingFields?: string[];
  aiReasoning?: string | null;
  checklist?: { id: string; label: string }[];
  state?: BannerState;
}

type BannerState = 'not_started' | 'partial' | 'verifying' | 'ready';

const ACTION_HREF: Record<string, string> = {
  phone_verification: '/login?as=crew&next=%2Fwork%2Fdashboard%23settings',
  home_address: '/work/dashboard#settings',
  id_verification: '/work/dashboard#settings',
  background_check: '/work/dashboard#settings',
  drivers_license_front: '/work/dashboard#settings',
  drivers_license_back: '/work/dashboard#settings',
  auto_insurance: '/work/dashboard#settings',
  stripe_connect_account: '/work/payouts',
  stripe_payouts_enabled: '/work/payouts',
  email_address: '/work/dashboard#settings',
};

const STATE_STYLES: Record<
  BannerState,
  { ring: string; tint: string; eyebrow: string; emoji: string }
> = {
  not_started: {
    ring: 'border-red-500/60 bg-gradient-to-br from-red-950/70 to-red-900/40',
    tint: 'text-red-200',
    eyebrow: 'Account at risk',
    emoji: '!',
  },
  partial: {
    ring: 'border-amber-500/60 bg-gradient-to-br from-amber-900/60 to-amber-950/40',
    tint: 'text-amber-100',
    eyebrow: 'Almost there',
    emoji: '⋯',
  },
  verifying: {
    ring: 'border-sky-500/50 bg-gradient-to-br from-sky-950/70 to-blue-950/40',
    tint: 'text-sky-100',
    eyebrow: 'Verifying',
    emoji: '✓',
  },
  ready: {
    ring: 'border-emerald-500/60 bg-emerald-950/40',
    tint: 'text-emerald-100',
    eyebrow: 'Ready',
    emoji: '✓',
  },
};

const DISMISS_KEY = 'bcl_completeness_dismissed';

export function CompletenessBanner() {
  useThemeToolsSurface('completeness-banner');
  const [data, setData] = useState<CompletenessApiResponse | null>(null);
  const [dismissed, setDismissed] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    try {
      const res = await fetch('/api/work/completeness', {
        headers: { Accept: 'application/json' },
      });
      if (!res.ok) {
        // 401 just means we're not signed in yet — don't show an error.
        if (res.status !== 401) setError(`Couldn't load completeness (${res.status}).`);
        return;
      }
      setData((await res.json()) as CompletenessApiResponse);
    } catch {
      setError('Network issue.');
    }
  }, []);

  useEffect(() => {
    void load();
    if (typeof window !== 'undefined') {
      setDismissed(window.sessionStorage.getItem(DISMISS_KEY) === '1');
    }
  }, [load]);

  if (error || !data || data.state === 'ready') return null;
  if (dismissed) return null;

  const state: BannerState = data.state ?? 'partial';
  const styles = STATE_STYLES[state];
  const score = Math.max(0, Math.min(100, Number(data.score ?? 0)));
  const checklist = data.checklist ?? [];

  return (
    <section
      role="alert"
      aria-live="polite"
      className={`mb-6 rounded-2xl border-2 p-5 ${styles.ring}`}
    >
      <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
        <div>
          <p className={`eyebrow ${styles.tint} mb-1`}>{styles.eyebrow}</p>
          <h2 className="text-xl sm:text-2xl font-extrabold text-brand-ink">
            Finish your profile to start getting paid
          </h2>
          <p className="text-sm text-brand-mute mt-1">
            You're {score}% of the way to dispatch-ready. We can't legally send you to a job (or
            wire your pay) until these are squared away.
          </p>
        </div>
        <button
          type="button"
          aria-label="Hide for this session"
          className="text-xs text-brand-mute underline-hover"
          onClick={() => {
            try {
              window.sessionStorage.setItem(DISMISS_KEY, '1');
            } catch {
              /* sessionStorage blocked — fine */
            }
            setDismissed(true);
          }}
        >
          Hide for now
        </button>
      </div>

      <div className="mb-4">
        <div
          className="h-2 w-full overflow-hidden rounded-full bg-brand-line"
          role="progressbar"
          aria-valuenow={score}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-label="Profile completeness"
        >
          <div
            className="h-full bg-gradient-to-r from-brand-accent to-amber-400 transition-all"
            style={{ width: `${score}%` }}
          />
        </div>
      </div>

      {checklist.length > 0 && (
        <ul className="space-y-2 mb-4">
          {checklist.map((item) => (
            <li key={item.id} className="flex items-start gap-3 text-sm">
              <span
                aria-hidden="true"
                className="flex-shrink-0 inline-flex h-5 w-5 items-center justify-center rounded-full border border-current text-[10px] font-extrabold"
              >
                {styles.emoji}
              </span>
              <span className="flex-1 text-brand-ink">{item.label}</span>
              <a
                href={ACTION_HREF[item.id] ?? '/work/dashboard#settings'}
                className="text-xs font-bold text-brand-accent underline-hover whitespace-nowrap"
              >
                Fix →
              </a>
            </li>
          ))}
        </ul>
      )}

      {data.aiReasoning && (
        <p className="text-xs italic text-brand-mute mt-3 border-t border-brand-line pt-3">
          {data.aiReasoning}
        </p>
      )}

      <div className="flex flex-wrap gap-2 pt-2">
        <a href="/work/dashboard#settings" className="btn-primary">
          Complete profile →
        </a>
        <a href="/work/payouts" className="btn-secondary">
          Set up payouts
        </a>
      </div>
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
