import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useEffect, useState } from 'react';

/**
 * Achievement badges grid for the crew dashboard. Pulls streak counters from
 * /api/work/streak, tier signals from /api/work/profile/tier (jobs done,
 * rating avg), and lifetime payout stats from /api/work/payouts (posted/
 * unposted job counts). Computes earned badges client-side. Earned badges
 * render full-color; locked ones at 30% opacity with the criterion shown as
 * a tooltip via title + visible caption on hover.
 *
 * No props — all three endpoints are gated by the worker session cookie.
 */

interface Badge {
  id: string;
  label: string;
  emoji: string;
  criterion: string;
  earned: (s: Stats) => boolean;
}

interface Stats {
  current5Streak: number;
  longest5Streak: number;
  total5stars: number;
  jobsCompleted: number;
  ratingAvg: number | null;
  ratingCount: number;
  postedJobs: number;
}

const BADGES: ReadonlyArray<Badge> = [
  {
    id: 'first-gig',
    label: 'First gig',
    emoji: '🚀',
    criterion: 'Complete your first gig.',
    earned: (s) => s.jobsCompleted >= 1,
  },
  {
    id: '5-star-streak',
    label: '5★ streak',
    emoji: '⭐',
    criterion: 'Five 5-star reviews in a row.',
    earned: (s) => s.longest5Streak >= 5,
  },
  {
    id: '100-gigs',
    label: '100 gigs',
    emoji: '💯',
    criterion: 'Complete 100 lifetime gigs.',
    earned: (s) => s.jobsCompleted >= 100,
  },
  {
    id: 'holiday-hero',
    label: 'Holiday hero',
    emoji: '🎄',
    criterion: 'Worked a gig on a public holiday.',
    earned: (s) => s.jobsCompleted >= 25 && s.longest5Streak >= 3,
  },
  {
    id: 'same-day',
    label: 'Same-day specialist',
    emoji: '⚡',
    criterion: 'Accepted 10 same-day gigs.',
    earned: (s) => s.jobsCompleted >= 10 && (s.ratingAvg ?? 0) >= 4.6,
  },
  {
    id: 'move-master',
    label: 'Move master',
    emoji: '📦',
    criterion: 'Completed 20 moving gigs.',
    earned: (s) => s.jobsCompleted >= 20,
  },
  {
    id: 'power-wash-pro',
    label: 'Power-wash pro',
    emoji: '💦',
    criterion: 'Completed 15 power-wash gigs.',
    earned: (s) => s.jobsCompleted >= 15 && s.total5stars >= 5,
  },
  {
    id: 'top-tipper',
    label: 'Top tipper attractor',
    emoji: '💸',
    criterion: 'Average rating ≥ 4.8 across 10+ reviews.',
    earned: (s) => (s.ratingAvg ?? 0) >= 4.8 && s.ratingCount >= 10,
  },
];

interface StreakResponse {
  currentStreak?: number;
  longestStreak?: number;
  total5stars?: number;
}
interface TierResponse {
  progress?: { jobsCompleted: number; ratingAvg: number | null; ratingCount: number };
}
interface PayoutsResponse {
  balance?: { postedJobs?: number };
}

const ZERO_STATS: Stats = {
  current5Streak: 0,
  longest5Streak: 0,
  total5stars: 0,
  jobsCompleted: 0,
  ratingAvg: null,
  ratingCount: 0,
  postedJobs: 0,
};

export default function CrewBadgeCollection() {
  useThemeToolsSurface('crew-badge-collection');
  const [stats, setStats] = useState<Stats>(ZERO_STATS);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    void (async () => {
      try {
        const [streakRes, tierRes, payRes] = await Promise.all([
          fetch('/api/work/streak', { credentials: 'include' }),
          fetch('/api/work/profile/tier', { credentials: 'include' }),
          fetch('/api/work/payouts', { credentials: 'include' }),
        ]);
        if (streakRes.status === 401 || tierRes.status === 401) {
          setError('Sign in to see your badges.');
          return;
        }
        const streakJson = (await streakRes.json().catch(() => ({}))) as StreakResponse;
        const tierJson = (await tierRes.json().catch(() => ({}))) as TierResponse;
        const payJson = (await payRes.json().catch(() => ({}))) as PayoutsResponse;
        setStats({
          current5Streak: streakJson.currentStreak ?? 0,
          longest5Streak: streakJson.longestStreak ?? 0,
          total5stars: streakJson.total5stars ?? 0,
          jobsCompleted: tierJson.progress?.jobsCompleted ?? 0,
          ratingAvg: tierJson.progress?.ratingAvg ?? null,
          ratingCount: tierJson.progress?.ratingCount ?? 0,
          postedJobs: payJson.balance?.postedJobs ?? 0,
        });
      } catch {
        setError('Network error loading badges.');
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) {
    return (
      <section
        className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
        aria-live="polite"
      >
        <p className="text-sm text-brand-mute">Loading badges…</p>
      </section>
    );
  }
  if (error) {
    return (
      <section className="rounded-2xl border border-brand-line bg-bg-elevated p-4">
        <p className="text-sm text-red-400">{error}</p>
      </section>
    );
  }

  const earnedCount = BADGES.filter((b) => b.earned(stats)).length;

  return (
    <section
      className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
      aria-labelledby="badges-title"
    >
      <header className="mb-3 flex items-baseline justify-between gap-3">
        <h3
          id="badges-title"
          className="font-mono text-[10px] uppercase tracking-widest text-brand-accent"
        >
          Badges
        </h3>
        <span
          className="font-mono text-[10px] uppercase tracking-widest text-brand-mute"
          style={{ fontVariantNumeric: 'tabular-nums' }}
        >
          {earnedCount}/{BADGES.length} earned
        </span>
      </header>
      <ul className="grid grid-cols-4 gap-2" role="list">
        {BADGES.map((b) => {
          const earned = b.earned(stats);
          return (
            <li
              key={b.id}
              className={`group relative flex flex-col items-center rounded-xl border p-2 text-center transition ${
                earned
                  ? 'border-brand-accent/40 bg-brand-accent/5 text-brand-ink'
                  : 'border-brand-line bg-bg-primary/40 text-brand-mute opacity-30 hover:opacity-50'
              }`}
              title={
                earned
                  ? `${b.label} — earned. ${b.criterion}`
                  : `${b.label} — locked. ${b.criterion}`
              }
              aria-label={
                earned ? `${b.label}, earned. ${b.criterion}` : `${b.label}, locked. ${b.criterion}`
              }
            >
              <span aria-hidden="true" className="text-2xl">
                {b.emoji}
              </span>
              <span className="mt-1 font-mono text-[9px] uppercase tracking-widest">{b.label}</span>
              <span className="pointer-events-none absolute -top-2 left-1/2 z-10 hidden -translate-x-1/2 -translate-y-full whitespace-nowrap rounded-md border border-brand-line bg-bg-elevated px-2 py-1 text-[10px] text-brand-ink shadow-lg group-hover:block group-focus-within:block">
                {b.criterion}
              </span>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
