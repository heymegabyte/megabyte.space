import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useEffect, useRef, useState } from 'react';
import { useFeatureFlag } from '../../use-feature-flag.js';
import { JobMap } from '../jobs/JobMap.js';
import { JobDetails } from '../jobs/JobDetails.js';
import { haversineMeters, etaFromDistance } from '../../geo-client.js';

// Crew-side live Job view. Mounts in the worker dashboard for an ACCEPTED gig:
// the crew sees the job pinned on a live map relative to their own GPS, with a
// Navigate button + scope + pay. Self-contained + flag-gated, so it's a safe
// additive mount that renders null when the flag is off or the gig isn't
// geocoded yet.

interface Transparency {
  gigId: string;
  claimStatus: string;
  pay: { centsPerHour: number; estimatedTotalCents: number; hoursEstimated: number };
  location: { streetAddress: string | null; zip: string | null; lat: number | null; lng: number | null };
  scopeSummary: string | null;
  customerNotes: string | null;
  startAt: string;
}

interface Props {
  readonly gigId: string;
  /** Services for the schedule chip row (optional — dashboard may pass them). */
  readonly services?: readonly string[];
}

export function CrewJobMapCard({ gigId, services = [] }: Props) {
  useThemeToolsSurface('crew-job-map-card');
  const enabled = useFeatureFlag('live_job_map');
  const [data, setData] = useState<Transparency | null>(null);
  const [me, setMe] = useState<{ lat: number; lng: number; heading: number | null } | null>(null);
  const watchRef = useRef<number | null>(null);

  // Pull the gig detail (includes dest coords after accept when the flag is on).
  useEffect(() => {
    if (!enabled || !gigId) return;
    let aborted = false;
    fetch(`/api/work/gigs/${encodeURIComponent(gigId)}`, { credentials: 'include' })
      .then((r) => (r.ok ? r.json() : null))
      .then((j: { transparency?: Transparency } | null) => {
        if (!aborted && j?.transparency) setData(j.transparency);
      })
      .catch(() => {
        /* fail soft — card simply doesn't render */
      });
    return () => {
      aborted = true;
    };
  }, [enabled, gigId]);

  // Track the crew's own position for the "you" marker + ETA to the job.
  useEffect(() => {
    if (!enabled || !data?.location.lat || typeof navigator === 'undefined' || !navigator.geolocation)
      return;
    watchRef.current = navigator.geolocation.watchPosition(
      (pos) =>
        setMe({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          heading: Number.isFinite(pos.coords.heading) ? pos.coords.heading : null,
        }),
      () => {
        /* permission denied — map still shows the dest pin */
      },
      { enableHighAccuracy: true, maximumAge: 15_000, timeout: 20_000 },
    );
    return () => {
      if (watchRef.current != null) navigator.geolocation.clearWatch(watchRef.current);
      watchRef.current = null;
    };
  }, [enabled, data?.location.lat, data?.location.lng]);

  if (!enabled || !data) return null;
  const { lat, lng } = data.location;
  if (lat == null || lng == null) return null;

  const dest = { lat, lng };
  let etaSeconds: number | null = null;
  let distanceMeters: number | null = null;
  if (me) {
    distanceMeters = haversineMeters(me, dest);
    etaSeconds = etaFromDistance(distanceMeters).etaSeconds;
  }

  const total = data.pay.estimatedTotalCents;

  return (
    <div className="mb-4 flex flex-col gap-4" data-testid="crew-job-map-card">
      <JobMap
        destination={dest}
        crewPosition={me}
        etaSeconds={etaSeconds}
        distanceMeters={distanceMeters}
        moverLabel="You"
      />
      <JobDetails
        variant="crew"
        schedule={{ date: data.startAt, time: '', hours: data.pay.hoursEstimated }}
        services={services}
        address={data.location.streetAddress}
        destination={dest}
        breakdown={[{ label: 'Your payout', cents: total }]}
      />
    </div>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
