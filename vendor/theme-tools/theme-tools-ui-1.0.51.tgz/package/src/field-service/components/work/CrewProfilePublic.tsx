import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useEffect, useState } from 'react';

/**
 * Wave 3A — public crew profile page, rendered at `/crew/:slug`.
 *
 * Pulls from /api/crew/:slug. Renders a marketing-friendly card with
 * first name + last initial, public bio, badges, rating, recent review
 * excerpts (no customer names). Worker opts in via Settings tab toggle.
 *
 * The component handles its own data fetch + 404 — integrator just routes
 * `/crew/:slug` to `<CrewProfilePublic slug={...} />`.
 */

interface Badge {
  slug: string;
  label: string;
  earned: boolean;
}

interface ReviewExcerpt {
  stars: number;
  body: string | null;
  createdAt: string;
}

interface PublicProfile {
  slug: string;
  displayName: string;
  bio: string | null;
  tier: string;
  city: string | null;
  state: string | null;
  rating: { avg: number | null; count: number };
  jobsCompleted: number;
  canDrive: boolean;
  badges: Badge[];
  reviewExcerpts: ReviewExcerpt[];
}

/**
 * Rolling reputation the `mutual-ratings-crew-profile` feature computes — a fresher
 * 90-day average + review count and a 365-day completed-jobs count, distinct from the
 * all-time `rating` on the base profile. Fetched best-effort from the flag-gated bridge;
 * absent for real visitors (the flag is dark) so the panel simply doesn't render.
 */
interface RecentReputation {
  displayName: string;
  averageRating: number | null;
  reviewCount: number;
  recentJobsCount: number;
}

function stars(n: number): string {
  return '★'.repeat(Math.max(0, Math.min(5, n))) + '☆'.repeat(Math.max(0, 5 - n));
}

export function CrewProfilePublic({ slug }: { slug: string }) {
  useThemeToolsSurface('crew-profile-public');
  const [profile, setProfile] = useState<PublicProfile | null>(null);
  const [status, setStatus] = useState<'loading' | 'ready' | 'not-found' | 'error'>('loading');
  const [recent, setRecent] = useState<RecentReputation | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(`/api/crew/${encodeURIComponent(slug)}`, {
          headers: { Accept: 'application/json' },
        });
        if (cancelled) return;
        if (res.status === 404) {
          setStatus('not-found');
          return;
        }
        if (!res.ok) {
          setStatus('error');
          return;
        }
        const body = (await res.json()) as PublicProfile;
        setProfile(body);
        setStatus('ready');
      } catch {
        if (!cancelled) setStatus('error');
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [slug]);

  // Best-effort: fetch the rolling-90-day reputation from the flag-gated bridge.
  // When the `mutual_ratings_crew_profile` flag is dark (the prod default) OR the
  // crew hasn't opted in, this 404s and the panel stays hidden — zero regression on
  // the existing all-time rating card. Failures are swallowed (never a console error).
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(
          `/api/mutual-ratings-crew-profile/by-slug/${encodeURIComponent(slug)}/profile-summary`,
          { headers: { Accept: 'application/json' } },
        );
        if (cancelled || !res.ok) return;
        const body = (await res.json()) as {
          ok?: boolean;
          summary?: {
            displayName: string;
            averageRating: number | null;
            reviewCount: number;
            recentJobsCount: number;
          };
        };
        if (body.ok && body.summary) {
          setRecent({
            displayName: body.summary.displayName,
            averageRating: body.summary.averageRating,
            reviewCount: body.summary.reviewCount,
            recentJobsCount: body.summary.recentJobsCount,
          });
        }
      } catch {
        /* best-effort — the base profile already rendered; silently skip. */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [slug]);

  if (status === 'loading') {
    return (
      <article className="section">
        <div className="container-pad max-w-2xl text-center text-brand-mute">
          Loading crew profile…
        </div>
      </article>
    );
  }

  if (status === 'not-found' || !profile) {
    return (
      <article className="section">
        <div className="container-pad max-w-2xl text-center">
          <h1 className="text-3xl font-extrabold text-brand-ink mb-2">Profile not found</h1>
          <p className="text-brand-mute">
            This crew member hasn't opted in to a public profile yet, or the link is stale.
          </p>
          <p className="mt-4">
            <a href="/work" className="underline-hover text-brand-accent">
              Want to join the crew? →
            </a>
          </p>
        </div>
      </article>
    );
  }

  if (status === 'error') {
    return (
      <article className="section">
        <div className="container-pad max-w-2xl text-center text-red-300">
          Couldn't load profile. Try again in a moment.
        </div>
      </article>
    );
  }

  const earnedBadges = profile.badges.filter((b) => b.earned);

  return (
    <article className="section" data-testid="crew-profile-public">
      <div className="container-pad max-w-3xl space-y-6">
        <header className="space-y-2">
          <p className="eyebrow">Brick Labor crew</p>
          <h1 className="text-4xl sm:text-5xl font-extrabold text-brand-ink">
            {profile.displayName}
          </h1>
          <p className="text-brand-mute">
            {profile.city && profile.state ? `${profile.city}, ${profile.state}` : 'New Jersey'}
            {' · '}
            {profile.tier.replaceAll('_', ' ')} tier
            {profile.canDrive ? ' · driver' : ''}
          </p>
        </header>

        {profile.bio && <p className="text-lg text-brand-ink leading-relaxed">{profile.bio}</p>}

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="rounded-2xl border border-brand-line bg-brand-card p-4">
            <p className="text-xs uppercase tracking-wider text-brand-mute mb-1">Rating</p>
            <p className="text-2xl font-extrabold text-brand-ink">
              {profile.rating.avg !== null ? profile.rating.avg.toFixed(1) : '—'}
              <span className="text-brand-mute text-sm font-normal">
                {' '}
                / 5 · {profile.rating.count} review{profile.rating.count === 1 ? '' : 's'}
              </span>
            </p>
          </div>
          <div className="rounded-2xl border border-brand-line bg-brand-card p-4">
            <p className="text-xs uppercase tracking-wider text-brand-mute mb-1">Jobs done</p>
            <p className="text-2xl font-extrabold text-brand-ink">{profile.jobsCompleted}</p>
          </div>
          <div className="rounded-2xl border border-brand-line bg-brand-card p-4">
            <p className="text-xs uppercase tracking-wider text-brand-mute mb-1">Badges</p>
            <p className="text-2xl font-extrabold text-brand-ink">{earnedBadges.length}</p>
          </div>
        </div>

        {recent && (recent.reviewCount > 0 || recent.recentJobsCount > 0) && (
          <section
            data-testid="crew-recent-reputation"
            className="rounded-2xl border-l-2 border-brand-accent bg-gradient-to-br from-brand-accent/8 to-transparent border border-brand-line p-5"
          >
            <p className="font-mono uppercase tracking-wider text-xs text-brand-accent mb-3">
              Recent reputation · last 90 days
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <p className="text-xs uppercase tracking-wider text-brand-mute mb-1">
                  Recent rating
                </p>
                <p className="text-2xl font-extrabold text-brand-ink">
                  {recent.averageRating !== null ? recent.averageRating.toFixed(1) : '—'}
                  <span className="text-brand-mute text-sm font-normal">
                    {' '}
                    / 5 · {recent.reviewCount} review{recent.reviewCount === 1 ? '' : 's'}
                  </span>
                </p>
              </div>
              <div>
                <p className="text-xs uppercase tracking-wider text-brand-mute mb-1">
                  Jobs (12 mo)
                </p>
                <p className="text-2xl font-extrabold text-brand-ink">{recent.recentJobsCount}</p>
              </div>
              <div className="sm:text-right sm:self-end">
                <p className="text-xs text-brand-mute">
                  A live look at how {recent.displayName} has performed on their most recent jobs.
                </p>
              </div>
            </div>
          </section>
        )}

        {earnedBadges.length > 0 && (
          <section>
            <h2 className="text-xl font-extrabold text-brand-ink mb-2">Badges</h2>
            <ul className="flex flex-wrap gap-2">
              {earnedBadges.map((b) => (
                <li
                  key={b.slug}
                  className="rounded-full border border-brand-accent/40 bg-brand-accent/10 px-3 py-1 text-xs font-bold text-brand-accent"
                >
                  {b.label}
                </li>
              ))}
            </ul>
          </section>
        )}

        {profile.reviewExcerpts.length > 0 && (
          <section>
            <h2 className="text-xl font-extrabold text-brand-ink mb-3">Recent reviews</h2>
            <ul className="space-y-3">
              {profile.reviewExcerpts.map((r, idx) => (
                <li key={idx} className="rounded-2xl border border-brand-line bg-brand-card p-4">
                  <p className="text-amber-300 font-extrabold mb-1" aria-label={`${r.stars} stars`}>
                    {stars(r.stars)}
                  </p>
                  {r.body && <p className="text-sm text-brand-ink italic">"{r.body}"</p>}
                </li>
              ))}
            </ul>
          </section>
        )}

        <footer className="pt-4 border-t border-brand-line text-sm text-brand-mute">
          Want to book {profile.displayName} for your next gig?{' '}
          <a href="/book" className="underline-hover text-brand-accent">
            Start a booking →
          </a>
        </footer>
      </div>
    </article>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
