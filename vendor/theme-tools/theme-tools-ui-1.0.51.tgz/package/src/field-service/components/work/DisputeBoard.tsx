import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useMemo, useState } from 'react';

/**
 * Wave 3A — dispute board. Worker sees a 48h SLA countdown for each open
 * dispute and can file a new one against a completed claim.
 *
 * The rating freezes (UI-side flag) while a dispute is open or under
 * investigation — the score isn't shown as final until the dispute resolves.
 */

export type DisputeReason = 'no_show' | 'rude' | 'unsafe' | 'property_damage' | 'quality' | 'other';
export type DisputeStatus =
  | 'open'
  | 'investigating'
  | 'resolved_for_worker'
  | 'resolved_for_customer'
  | 'dismissed'
  | 'withdrawn';

export interface Dispute {
  id: string;
  gig_claim_id: string;
  worker_id: string;
  reason: DisputeReason;
  notes: string | null;
  status: DisputeStatus;
  sla_due_at: string;
  resolution_notes: string | null;
  resolved_at: string | null;
  created_at: string;
  gig_id: string;
  start_at: string;
  service_zip: string | null;
}

const REASONS: Array<{ value: DisputeReason; label: string }> = [
  { value: 'no_show', label: 'Customer flagged no-show wrongly' },
  { value: 'rude', label: 'Customer was rude / abusive' },
  { value: 'unsafe', label: 'Job site was unsafe' },
  { value: 'property_damage', label: 'False property-damage claim' },
  { value: 'quality', label: 'Quality complaint I dispute' },
  { value: 'other', label: 'Other' },
];

function hoursRemaining(slaDueAt: string): number {
  const ms = new Date(slaDueAt).getTime() - Date.now();
  return Math.max(0, Math.ceil(ms / 3600_000));
}

function slaLabel(d: Dispute): string {
  if (d.status === 'resolved_for_worker') return 'Resolved in your favor';
  if (d.status === 'resolved_for_customer') return 'Resolved for customer';
  if (d.status === 'dismissed') return 'Dismissed';
  if (d.status === 'withdrawn') return 'Withdrawn';
  const hrs = hoursRemaining(d.sla_due_at);
  if (hrs <= 0) return 'SLA elapsed — ops will respond';
  const due = new Date(d.sla_due_at).toLocaleString('en-US', {
    weekday: 'short',
    hour: 'numeric',
    minute: '2-digit',
    timeZone: 'America/New_York',
  });
  return `Decision by ${due} — ${hrs}h remaining`;
}

export function DisputeBoard({ initialClaimId }: { initialClaimId?: string } = {}) {
  useThemeToolsSurface('dispute-board');
  const [disputes, setDisputes] = useState<Dispute[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showFiler, setShowFiler] = useState(!!initialClaimId);

  const refresh = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/work/disputes', { headers: { Accept: 'application/json' } });
      if (!res.ok) {
        setError(`Couldn't load disputes (${res.status})`);
        return;
      }
      const body = (await res.json()) as { disputes: Dispute[] };
      setDisputes(body.disputes ?? []);
    } catch (err) {
      setError(`Network: ${(err as Error).message}`);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const open = useMemo(
    () => disputes.filter((d) => d.status === 'open' || d.status === 'investigating'),
    [disputes],
  );
  const closed = useMemo(
    () => disputes.filter((d) => d.status !== 'open' && d.status !== 'investigating'),
    [disputes],
  );

  return (
    <section className="space-y-6">
      <header className="flex flex-wrap items-baseline justify-between gap-3">
        <div>
          <p className="eyebrow mb-1">Disputes</p>
          <h2 className="text-2xl font-extrabold text-brand-ink">Open + closed</h2>
          <p className="text-sm text-brand-mute mt-1">
            48-hour SLA. Your rating freezes while a dispute is open.
          </p>
        </div>
        <button type="button" className="btn-primary" onClick={() => setShowFiler(true)}>
          File a dispute
        </button>
      </header>

      {error && (
        <p role="alert" className="text-sm text-red-300">
          {error}
        </p>
      )}

      {showFiler && (
        <DisputeFiler
          initialClaimId={initialClaimId}
          onFiled={() => {
            setShowFiler(false);
            void refresh();
          }}
          onCancel={() => setShowFiler(false)}
        />
      )}

      <div>
        <h3 className="text-sm uppercase tracking-wider text-brand-mute font-extrabold mb-2">
          Open ({open.length})
        </h3>
        {loading && <p className="text-sm text-brand-mute">Loading…</p>}
        {!loading && open.length === 0 && (
          <p className="text-sm text-brand-mute">No open disputes. You're good.</p>
        )}
        <ul className="space-y-3">
          {open.map((d) => (
            <li key={d.id}>
              <DisputeCard dispute={d} onChanged={refresh} />
            </li>
          ))}
        </ul>
      </div>

      {closed.length > 0 && (
        <div>
          <h3 className="text-sm uppercase tracking-wider text-brand-mute font-extrabold mb-2">
            Closed ({closed.length})
          </h3>
          <ul className="space-y-3">
            {closed.map((d) => (
              <li key={d.id}>
                <DisputeCard dispute={d} onChanged={refresh} />
              </li>
            ))}
          </ul>
        </div>
      )}
    </section>
  );
}

function DisputeCard({ dispute, onChanged }: { dispute: Dispute; onChanged: () => void }) {
  const [busy, setBusy] = useState(false);
  const [showWithdraw, setShowWithdraw] = useState(false);
  const [withdrawReason, setWithdrawReason] = useState('');

  const isOpen = dispute.status === 'open' || dispute.status === 'investigating';

  async function withdraw() {
    setBusy(true);
    try {
      await fetch(`/api/work/disputes/${encodeURIComponent(dispute.id)}/withdraw`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason: withdrawReason || undefined }),
      });
      onChanged();
    } finally {
      setBusy(false);
    }
  }

  return (
    <article
      className={`rounded-2xl border p-4 ${
        isOpen ? 'border-amber-500/40 bg-amber-500/5' : 'border-brand-line bg-brand-card'
      }`}
      data-testid="dispute-card"
    >
      <header className="flex flex-wrap items-baseline justify-between gap-2 mb-2">
        <div>
          <p className="text-xs uppercase tracking-wider text-brand-mute">
            {dispute.reason.replaceAll('_', ' ')}
          </p>
          <p className="font-extrabold text-brand-ink">
            Gig {dispute.gig_id.slice(0, 8)} · {dispute.service_zip ?? '—'}
          </p>
        </div>
        <p
          className={`text-xs font-bold ${isOpen ? 'text-amber-300' : 'text-brand-mute'}`}
          data-testid="sla-label"
        >
          {slaLabel(dispute)}
        </p>
      </header>
      {dispute.notes && <p className="text-sm text-brand-ink italic mb-2">"{dispute.notes}"</p>}
      {dispute.resolution_notes && (
        <p className="text-sm text-emerald-300 mb-2">Ops verdict: {dispute.resolution_notes}</p>
      )}
      {isOpen && (
        <div className="mt-3 flex flex-wrap gap-2 items-center">
          {!showWithdraw && (
            <button
              type="button"
              onClick={() => setShowWithdraw(true)}
              className="text-xs text-brand-mute underline-hover"
            >
              Withdraw
            </button>
          )}
          {showWithdraw && (
            <div className="flex flex-wrap items-center gap-2">
              <input
                type="text"
                placeholder="Why withdraw? (optional)"
                value={withdrawReason}
                onChange={(e) => setWithdrawReason(e.target.value)}
                className="rounded-lg border border-brand-line bg-brand-bg px-3 py-1.5 text-xs text-brand-ink"
                maxLength={500}
              />
              <button
                type="button"
                disabled={busy}
                onClick={() => void withdraw()}
                className="rounded-lg border border-brand-line bg-brand-bg px-3 py-1.5 text-xs font-bold text-brand-ink hover:bg-brand-line transition-colors disabled:opacity-50"
              >
                Confirm withdraw
              </button>
              <button
                type="button"
                onClick={() => setShowWithdraw(false)}
                className="text-xs text-brand-mute underline-hover"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      )}
    </article>
  );
}

function DisputeFiler({
  initialClaimId,
  onFiled,
  onCancel,
}: {
  initialClaimId?: string;
  onFiled: () => void;
  onCancel: () => void;
}) {
  const [claimId, setClaimId] = useState(initialClaimId ?? '');
  const [reason, setReason] = useState<DisputeReason>('rude');
  const [notes, setNotes] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  async function file() {
    if (!claimId.trim()) {
      setErr('Pick a claim ID first.');
      return;
    }
    setBusy(true);
    setErr('');
    try {
      const res = await fetch('/api/work/disputes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ claimId: claimId.trim(), reason, notes: notes || undefined }),
      });
      if (!res.ok) {
        const body = (await res.json().catch(() => ({}))) as { code?: string };
        if (body.code === 'already_filed') setErr('You already filed a dispute on this claim.');
        else if (body.code === 'rate_limited') setErr('Too many disputes — try again in an hour.');
        else setErr(`File failed: ${body.code ?? res.status}`);
        return;
      }
      onFiled();
    } catch (e) {
      setErr(`Network: ${(e as Error).message}`);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="rounded-2xl border border-brand-line bg-brand-card p-5 space-y-3">
      <h3 className="text-lg font-extrabold text-brand-ink">File a dispute</h3>
      <p className="text-sm text-brand-mute">
        48-hour SLA. Ops responds in writing before the clock expires.
      </p>
      <label className="flex flex-col gap-1 text-xs text-brand-mute">
        Claim ID
        <input
          type="text"
          value={claimId}
          onChange={(e) => setClaimId(e.target.value)}
          placeholder="e.g. a1b2c3…"
          className="rounded-lg border border-brand-line bg-brand-bg px-3 py-2 text-sm text-brand-ink"
        />
      </label>
      <label className="flex flex-col gap-1 text-xs text-brand-mute">
        Reason
        <select
          value={reason}
          onChange={(e) => setReason(e.target.value as DisputeReason)}
          className="rounded-lg border border-brand-line bg-brand-bg px-3 py-2 text-sm text-brand-ink"
        >
          {REASONS.map((r) => (
            <option key={r.value} value={r.value}>
              {r.label}
            </option>
          ))}
        </select>
      </label>
      <label className="flex flex-col gap-1 text-xs text-brand-mute">
        Notes (optional, up to 2000 chars)
        <textarea
          rows={4}
          maxLength={2000}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          className="rounded-lg border border-brand-line bg-brand-bg px-3 py-2 text-sm text-brand-ink"
          placeholder="What happened?"
        />
      </label>
      {err && (
        <p role="alert" className="text-sm text-red-300">
          {err}
        </p>
      )}
      <div className="flex gap-2">
        <button type="button" onClick={() => void file()} disabled={busy} className="btn-primary">
          {busy ? '…' : 'File dispute'}
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="rounded-xl border border-brand-line bg-transparent px-4 py-2 text-sm font-bold text-brand-mute hover:text-brand-ink transition-colors"
        >
          Cancel
        </button>
      </div>
    </div>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
