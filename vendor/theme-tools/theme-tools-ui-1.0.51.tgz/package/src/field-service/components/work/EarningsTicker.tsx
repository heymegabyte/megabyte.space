import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useEffect, useRef, useState } from 'react';

/**
 * Earnings ticker — live $ ticker for the crew dashboard. Aggregates today's
 * completed gigs from /api/work/gigs into a big rolling dollar amount with
 * three sub-stats (gigs done, tips earned, hours worked).
 *
 * No daily endpoint exists, so we filter the `completed` array client-side to
 * gigs whose check_out_at is today. RAF-driven count-up animation from 0 on
 * mount. Respects prefers-reduced-motion.
 */

interface CompletedGig {
  id: string;
  start_at: string;
  service_address: string | null;
  earnings_cents: number | null;
  tip_cents: number | null;
  check_in_at: string | null;
  check_out_at: string | null;
}

interface GigsResponse {
  invites: unknown[];
  completed: CompletedGig[];
  error?: string;
}

function isToday(iso: string | null): boolean {
  if (!iso) return false;
  const d = new Date(iso);
  const now = new Date();
  return (
    d.getFullYear() === now.getFullYear() &&
    d.getMonth() === now.getMonth() &&
    d.getDate() === now.getDate()
  );
}

function fmtUsd(cents: number): string {
  return `$${(cents / 100).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function hoursBetween(inIso: string | null, outIso: string | null): number {
  if (!inIso || !outIso) return 0;
  const diffMs = new Date(outIso).getTime() - new Date(inIso).getTime();
  return Math.max(0, diffMs / 3_600_000);
}

function useCountUp(target: number, durationMs = 900): number {
  const [val, setVal] = useState(0);
  const startRef = useRef<number | null>(null);
  const fromRef = useRef(0);

  useEffect(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce) {
      setVal(target);
      return;
    }
    fromRef.current = val;
    startRef.current = null;
    let raf = 0;
    const step = (ts: number) => {
      if (startRef.current === null) startRef.current = ts;
      const t = Math.min(1, (ts - startRef.current) / durationMs);
      const eased = 1 - Math.pow(1 - t, 3);
      setVal(fromRef.current + (target - fromRef.current) * eased);
      if (t < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [target, durationMs]);

  return val;
}

export default function EarningsTicker() {
  useThemeToolsSurface('earnings-ticker');
  const [centsToday, setCentsToday] = useState(0);
  const [tipsToday, setTipsToday] = useState(0);
  const [gigsToday, setGigsToday] = useState(0);
  const [hoursToday, setHoursToday] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    void (async () => {
      try {
        const res = await fetch('/api/work/gigs', { credentials: 'include' });
        if (res.status === 401) {
          setError('Sign in to see today’s earnings.');
          return;
        }
        const json = (await res.json()) as GigsResponse;
        if (json.error) {
          setError(json.error);
          return;
        }
        const todays = (json.completed ?? []).filter((g) => isToday(g.check_out_at));
        let earn = 0;
        let tips = 0;
        let hrs = 0;
        for (const g of todays) {
          earn += g.earnings_cents ?? 0;
          tips += g.tip_cents ?? 0;
          hrs += hoursBetween(g.check_in_at, g.check_out_at);
        }
        setCentsToday(earn);
        setTipsToday(tips);
        setGigsToday(todays.length);
        setHoursToday(hrs);
      } catch {
        setError('Network error loading earnings.');
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const dollarsAnimated = useCountUp(centsToday / 100);

  if (loading) {
    return (
      <section
        className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
        aria-live="polite"
      >
        <p className="text-sm text-brand-mute">Loading earnings…</p>
      </section>
    );
  }
  if (error) {
    return (
      <section className="rounded-2xl border border-brand-line bg-bg-elevated p-4">
        <p className="text-sm text-red-400">{error}</p>
      </section>
    );
  }

  return (
    <section
      className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
      aria-labelledby="earnings-ticker-title"
    >
      <header className="mb-3">
        <h3
          id="earnings-ticker-title"
          className="font-mono text-[10px] uppercase tracking-widest text-brand-accent"
        >
          Earnings ticker
        </h3>
      </header>
      <div className="mb-4">
        <p
          className="text-4xl font-bold text-brand-ink leading-none"
          style={{ fontVariantNumeric: 'tabular-nums' }}
          aria-label={`Earned ${fmtUsd(centsToday)} today`}
        >
          {fmtUsd(Math.round(dollarsAnimated * 100))}
        </p>
        <p className="mt-1 font-mono text-[10px] uppercase tracking-widest text-brand-mute">
          today
        </p>
      </div>
      <dl className="grid grid-cols-3 gap-2 text-xs">
        <Stat label="Gigs done" value={gigsToday.toString()} />
        <Stat label="Tips" value={fmtUsd(tipsToday)} />
        <Stat label="Hours" value={hoursToday.toFixed(1)} />
      </dl>
    </section>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-brand-line bg-bg-primary px-2 py-1.5">
      <dt className="font-mono text-[9px] uppercase tracking-widest text-brand-mute">{label}</dt>
      <dd
        className="text-xs font-semibold text-brand-ink"
        style={{ fontVariantNumeric: 'tabular-nums' }}
      >
        {value}
      </dd>
    </div>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
