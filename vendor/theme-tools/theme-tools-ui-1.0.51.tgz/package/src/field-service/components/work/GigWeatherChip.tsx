import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useEffect, useState } from 'react';

// Wave 21B — compact NWS forecast chip for a specific gig.
//
// Renders a single-line summary (e.g. "Sat 2pm · 72° · Partly cloudy") for
// the period closest to the gig's start time. Falls back gracefully if NWS
// is unreachable (the chip just hides itself).

interface ForecastPeriod {
  number: number;
  name: string;
  startTime: string;
  endTime: string;
  temperature: number;
  temperatureUnit: string;
  windSpeed: string;
  windDirection: string;
  shortForecast: string;
  probabilityOfPrecipitation?: { value: number | null };
}

interface WeatherPayload {
  gigId: string;
  startAt: string;
  zip: string | null;
  periods: ForecastPeriod[];
  cachedAt: number;
}

interface GigWeatherChipProps {
  gigId: string;
  startAt: string;
}

function pickPeriod(periods: ForecastPeriod[], startAt: string): ForecastPeriod | null {
  const first = periods[0];
  if (!first) return null;
  const target = new Date(startAt).getTime();
  let best: ForecastPeriod = first;
  let bestDelta = Math.abs(new Date(first.startTime).getTime() - target);
  for (const p of periods) {
    const d = Math.abs(new Date(p.startTime).getTime() - target);
    if (d < bestDelta) {
      best = p;
      bestDelta = d;
    }
  }
  return best;
}

export function GigWeatherChip({ gigId, startAt }: GigWeatherChipProps): JSX.Element | null {
  useThemeToolsSurface('gig-weather-chip');
  const [data, setData] = useState<WeatherPayload | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const res = await fetch(`/api/work/weather?gigId=${encodeURIComponent(gigId)}`, {
          credentials: 'include',
          headers: { Accept: 'application/json' },
        });
        if (!res.ok) {
          if (!cancelled) setFailed(true);
          return;
        }
        const j = (await res.json()) as WeatherPayload;
        if (!cancelled) setData(j);
      } catch {
        if (!cancelled) setFailed(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [gigId]);

  if (failed || !data) return null;
  const period = pickPeriod(data.periods, startAt);
  if (!period) return null;

  const precip = period.probabilityOfPrecipitation?.value;
  const wetWarning = typeof precip === 'number' && precip >= 50;

  return (
    <span
      role="img"
      aria-label={`Forecast: ${period.shortForecast}, ${period.temperature}${period.temperatureUnit}, wind ${period.windSpeed}${typeof precip === 'number' ? `, ${precip}% precip` : ''}`}
      className={`inline-flex items-center gap-2 rounded-full border px-2.5 py-1 text-[11px] font-medium ${
        wetWarning
          ? 'border-amber-500/60 bg-amber-900/30 text-amber-100'
          : 'border-brand-line bg-brand-bg text-brand-ink'
      }`}
    >
      <span aria-hidden="true">{wetWarning ? '☔' : '☀'}</span>
      <span>
        {period.temperature}°{period.temperatureUnit}
        {' · '}
        {period.shortForecast}
        {typeof precip === 'number' && precip > 0 && ` · ${precip}% rain`}
      </span>
    </span>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
