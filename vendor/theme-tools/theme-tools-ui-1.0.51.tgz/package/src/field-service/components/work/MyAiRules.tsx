import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useMemo, useState } from 'react';

/**
 * MyAiRules (worker) — Wave 16 settings-tab card.
 *
 * Lets a logged-in worker write natural-language dispatch rules ("Don't send
 * me to any jobs at Penn Station"), pick a kind (preference|soft_rule|
 * hard_rule), and delete their own rules. AI-validates the rule text on save
 * (rejects gibberish + self-contradictions). Shows "applied to X dispatches
 * this month" counter so workers see the rules engine acting on their behalf.
 *
 * Mounted by the integrator inside `WorkerDashboard`'s Settings tab — this
 * file does NOT touch `WorkerDashboard.tsx`.
 */

type RuleKind = 'preference' | 'soft_rule' | 'hard_rule';
type RuleScope = 'worker' | 'admin_for_worker';

interface Rule {
  id: string;
  scope: RuleScope;
  subjectId: string;
  authorRole: 'worker' | 'admin';
  text: string;
  kind: RuleKind;
  priority: number;
  createdAt: number;
  lastAppliedAt: number | null;
  appliedCount: number;
}

interface ApiList {
  ok: boolean;
  rules?: Rule[];
  error?: string;
}

interface ApiCreate {
  ok: boolean;
  id?: string;
  error?: string;
  code?: string;
}

const KIND_LABELS: Record<RuleKind, { title: string; helper: string }> = {
  preference: { title: 'Preference', helper: 'Nudge — AI weighs it lightly.' },
  soft_rule: { title: 'Strong preference', helper: 'AI penalizes mismatches.' },
  hard_rule: { title: 'Non-negotiable', helper: 'Blocks dispatch entirely.' },
};

export default function MyAiRules() {
  useThemeToolsSurface('my-ai-rules');
  const [rules, setRules] = useState<Rule[]>([]);
  const [text, setText] = useState('');
  const [kind, setKind] = useState<RuleKind>('preference');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setError('');
    try {
      const res = await fetch('/api/work/rules', { headers: { Accept: 'application/json' } });
      const data = (await res.json()) as ApiList;
      if (!res.ok || !data.ok) {
        setError(data.error ?? `Couldn't load rules (${res.status}).`);
        return;
      }
      setRules(data.rules ?? []);
    } catch {
      setError('Connection issue. Try refreshing.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const submit = useCallback(
    async (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      const trimmed = text.trim();
      if (trimmed.length < 4) {
        setError('Rule is too short — give it a sentence at least.');
        return;
      }
      setBusy(true);
      setError('');
      try {
        const res = await fetch('/api/work/rules', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: trimmed, kind }),
        });
        const data = (await res.json()) as ApiCreate;
        if (!res.ok || !data.ok) {
          setError(data.error ?? `Save failed (${res.status}).`);
          return;
        }
        setText('');
        setKind('preference');
        await load();
      } catch {
        setError('Connection issue. Try again.');
      } finally {
        setBusy(false);
      }
    },
    [text, kind, load],
  );

  const remove = useCallback(
    async (id: string) => {
      setBusy(true);
      setError('');
      try {
        const res = await fetch(`/api/work/rules/${encodeURIComponent(id)}`, {
          method: 'DELETE',
        });
        if (!res.ok) {
          setError(`Delete failed (${res.status}).`);
          return;
        }
        await load();
      } catch {
        setError('Connection issue. Try again.');
      } finally {
        setBusy(false);
      }
    },
    [load],
  );

  const monthlyApplied = useMemo(() => {
    const cutoff = Math.floor(Date.now() / 1000) - 30 * 86400;
    return rules.reduce(
      (sum, r) => sum + (r.lastAppliedAt && r.lastAppliedAt >= cutoff ? r.appliedCount : 0),
      0,
    );
  }, [rules]);

  return (
    <section
      aria-labelledby="my-ai-rules-heading"
      className="rounded-2xl border border-brand-line bg-brand-card p-5 space-y-4"
    >
      <header className="flex items-start justify-between gap-3">
        <div>
          <h3 id="my-ai-rules-heading" className="text-lg font-bold text-brand-ink">
            My dispatch rules
          </h3>
          <p className="text-sm text-brand-mute">
            Tell the matcher what jobs to send you — or skip. Plain English works.
          </p>
        </div>
        <div className="text-right text-xs text-brand-mute" aria-live="polite">
          <div>
            <span className="font-bold text-brand-ink">{monthlyApplied}</span> dispatches this month
          </div>
          <div>used your rules</div>
        </div>
      </header>

      <form onSubmit={submit} className="space-y-3" aria-busy={busy}>
        <label htmlFor="rule-text" className="block text-sm font-bold text-brand-ink">
          New rule
        </label>
        <textarea
          id="rule-text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={2}
          maxLength={800}
          placeholder='e.g. "Only send me jobs on Thursdays and Mondays."'
          className="w-full rounded-xl border border-brand-line bg-brand-bg p-3 text-sm text-brand-ink placeholder:text-brand-mute focus:outline-none focus:ring-2 focus:ring-brand-accent"
        />
        <fieldset className="flex flex-wrap gap-2">
          <legend className="sr-only">Rule strength</legend>
          {(Object.keys(KIND_LABELS) as RuleKind[]).map((k) => (
            <label
              key={k}
              className={`cursor-pointer rounded-xl border px-3 py-2 text-xs focus-within:ring-2 focus-within:ring-brand-accent focus-within:ring-offset-2 focus-within:ring-offset-bg-primary ${
                kind === k
                  ? 'border-brand-accent bg-brand-accent/10 text-brand-ink'
                  : 'border-brand-line text-brand-mute hover:text-brand-ink'
              }`}
            >
              <input
                type="radio"
                name="kind"
                value={k}
                checked={kind === k}
                onChange={() => setKind(k)}
                className="sr-only"
              />
              <span className="font-bold">{KIND_LABELS[k].title}</span>
              <span className="block text-[11px] opacity-75">{KIND_LABELS[k].helper}</span>
            </label>
          ))}
        </fieldset>
        <div className="flex items-center justify-between gap-3">
          <p className="text-xs text-brand-mute">
            AI checks each rule for clarity before saving. Discriminatory targeting will be
            rejected.
          </p>
          <button
            type="submit"
            disabled={busy || text.trim().length < 4}
            className="rounded-xl bg-brand-accent px-4 py-2 text-sm font-bold text-brand-bg disabled:opacity-50"
          >
            {busy ? 'Saving…' : 'Add rule'}
          </button>
        </div>
        {error && (
          <p role="alert" className="text-sm text-red-300">
            {error}
          </p>
        )}
      </form>

      <div className="space-y-2">
        <h4 className="text-sm font-bold text-brand-ink">Active rules ({rules.length})</h4>
        {loading && <p className="text-sm text-brand-mute">Loading…</p>}
        {!loading && rules.length === 0 && (
          <p className="text-sm text-brand-mute">
            No rules yet. Add one above and the matcher will respect it on every dispatch.
          </p>
        )}
        <ul className="space-y-2">
          {rules.map((r) => (
            <li
              key={r.id}
              className="flex items-start justify-between gap-3 rounded-xl border border-brand-line bg-brand-bg p-3"
            >
              <div className="space-y-1">
                <p className="text-sm text-brand-ink">{r.text}</p>
                <p className="text-[11px] text-brand-mute">
                  <span className="font-bold text-brand-ink">{KIND_LABELS[r.kind].title}</span>
                  {' · '}
                  {r.authorRole === 'admin' ? 'set by admin' : 'set by you'}
                  {' · applied '}
                  {r.appliedCount} time{r.appliedCount === 1 ? '' : 's'}
                </p>
              </div>
              {r.authorRole === 'worker' && (
                <button
                  type="button"
                  onClick={() => void remove(r.id)}
                  disabled={busy}
                  className="rounded-xl border border-brand-line bg-transparent px-2 py-1 text-xs text-brand-mute hover:text-red-300"
                  aria-label={`Delete rule: ${r.text.slice(0, 80)}`}
                >
                  Delete
                </button>
              )}
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
