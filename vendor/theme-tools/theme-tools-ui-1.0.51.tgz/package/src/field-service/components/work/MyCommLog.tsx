import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useState } from 'react';

// Wave 19 — worker self-view of every push notification + SMS we sent them.
// Renders as a button on the Worker Dashboard Settings tab that opens a
// slide-over drawer with a timeline.
//
// Backed by `GET /api/work/comm-log` which filters rows to
// `recipient_user_kind = 'worker' AND recipient_user_id = session.workerId`.

interface CommLogItem {
  id: string;
  kind: 'email' | 'sms' | 'push' | 'voice';
  direction: 'outbound' | 'inbound';
  subject: string | null;
  body_preview: string | null;
  has_full_body: boolean;
  status: string;
  error: string | null;
  sent_at: number | null;
  delivered_at: number | null;
  opened_at: number | null;
  clicked_at: number | null;
  related_entity_kind: string | null;
  related_entity_id: string | null;
}

interface WorkCommLogProps {
  /** Override fetch impl for tests. */
  readonly fetchImpl?: typeof fetch;
}

const KIND_LABEL: Record<CommLogItem['kind'], string> = {
  email: 'Email',
  sms: 'Text',
  push: 'Push',
  voice: 'Call',
};

const STATUS_BADGE: Record<string, { label: string; cls: string }> = {
  queued: { label: 'Queued', cls: 'border-brand-line text-brand-mute' },
  sent: { label: 'Sent', cls: 'border-brand-accent/40 text-brand-accent' },
  delivered: { label: 'Delivered', cls: 'border-brand-ok/40 text-brand-ok' },
  opened: { label: 'Opened', cls: 'border-brand-ok/40 text-brand-ok' },
  clicked: { label: 'Clicked', cls: 'border-brand-ok/40 text-brand-ok' },
  replied: { label: 'Replied', cls: 'border-brand-ok/40 text-brand-ok' },
  bounced: { label: 'Bounced', cls: 'border-brand-err/40 text-brand-err' },
  failed: { label: 'Failed', cls: 'border-brand-err/40 text-brand-err' },
};

function formatTimestamp(unix: number | null): string {
  if (!unix) return '';
  const d = new Date(unix * 1000);
  return d.toLocaleString();
}

/**
 * Worker dashboard widget — same UX as the customer MyCommLog but pulls from
 * `/api/work/comm-log`. Mounted on the Settings tab of `WorkerDashboard`.
 */
export function WorkCommLog({ fetchImpl }: WorkCommLogProps = {}) {
  useThemeToolsSurface('my-comm-log');
  const f = fetchImpl ?? fetch;
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<readonly CommLogItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [expandedBody, setExpandedBody] = useState<string | null>(null);
  const [expandedLoading, setExpandedLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await f('/api/work/comm-log?limit=100', { credentials: 'include' });
      if (!res.ok) {
        setError(
          res.status === 401 ? 'Sign in to see your message history.' : `http_${res.status}`,
        );
        return;
      }
      const data = (await res.json()) as { items: CommLogItem[] };
      setItems(data.items ?? []);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }, [f]);

  useEffect(() => {
    if (open) void load();
  }, [open, load]);

  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [open]);

  const handleExpand = async (item: CommLogItem) => {
    if (expandedId === item.id) {
      setExpandedId(null);
      setExpandedBody(null);
      return;
    }
    setExpandedId(item.id);
    setExpandedBody(null);
    if (!item.has_full_body) return;
    setExpandedLoading(true);
    try {
      const res = await f(`/api/work/comm-log/${item.id}/body`, { credentials: 'include' });
      if (res.ok) {
        const data = (await res.json()) as { body: string | null };
        setExpandedBody(data.body ?? null);
      }
    } finally {
      setExpandedLoading(false);
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="rounded-md border border-brand-line bg-brand-card px-4 py-2 text-sm text-brand-ink hover:border-brand-accent transition focus:outline-none focus:ring-2 focus:ring-brand-accent"
        data-testid="work-comm-log-open"
      >
        View messages we&rsquo;ve sent you
      </button>

      {open && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Your message history"
          className="fixed inset-0 z-50 flex justify-end"
        >
          <button
            type="button"
            aria-label="Close drawer"
            onClick={() => setOpen(false)}
            className="absolute inset-0 bg-brand-bg/60 backdrop-blur-sm"
          />
          <div className="relative h-full w-full max-w-lg overflow-y-auto bg-brand-bg border-l border-brand-line p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-xl font-extrabold">Messages we sent you</h2>
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="rounded-md border border-brand-line px-3 py-1 text-sm hover:border-brand-accent"
              >
                Close
              </button>
            </div>

            {loading && <p className="text-brand-mute text-sm">Loading…</p>}
            {error && (
              <p role="alert" className="text-brand-err text-sm">
                {error}
              </p>
            )}
            {!loading && !error && items.length === 0 && (
              <p className="text-brand-mute text-sm">
                Nothing yet — we haven&rsquo;t sent you any push notifications or texts.
              </p>
            )}

            <ul className="space-y-3" aria-label="Message timeline">
              {items.map((item) => {
                const badge = STATUS_BADGE[item.status] ?? {
                  label: item.status,
                  cls: 'border-brand-line text-brand-mute',
                };
                return (
                  <li
                    key={item.id}
                    className="rounded-xl border border-brand-line bg-brand-card p-4"
                  >
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="min-w-0">
                        <p className="text-xs uppercase tracking-wide text-brand-mute">
                          {KIND_LABEL[item.kind]} · {formatTimestamp(item.sent_at)}
                        </p>
                        {item.subject && (
                          <p className="font-semibold text-brand-ink truncate" title={item.subject}>
                            {item.subject}
                          </p>
                        )}
                      </div>
                      <span
                        className={`inline-block rounded-full border px-2 py-0.5 text-xs font-semibold ${badge.cls}`}
                      >
                        {badge.label}
                      </span>
                    </div>
                    {item.body_preview && (
                      <p className="text-sm text-brand-mute whitespace-pre-wrap">
                        {item.body_preview}
                      </p>
                    )}
                    {item.has_full_body && (
                      <button
                        type="button"
                        onClick={() => void handleExpand(item)}
                        className="mt-2 text-xs text-brand-accent underline-hover"
                      >
                        {expandedId === item.id ? 'Hide full message' : 'View full message'}
                      </button>
                    )}
                    {expandedId === item.id && (
                      <div className="mt-3 rounded-md border border-brand-line bg-brand-bg/60 p-3 text-sm">
                        {expandedLoading ? (
                          <p className="text-brand-mute">Loading full message…</p>
                        ) : expandedBody ? (
                          item.kind === 'email' ? (
                            <iframe
                              title={`Email body ${item.id}`}
                              sandbox=""
                              srcDoc={expandedBody}
                              className="w-full h-72 rounded border border-brand-line bg-white"
                            />
                          ) : (
                            <pre className="whitespace-pre-wrap text-brand-ink">{expandedBody}</pre>
                          )
                        ) : (
                          <p className="text-brand-mute">Full message unavailable.</p>
                        )}
                      </div>
                    )}
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      )}
    </>
  );
}

export default WorkCommLog;
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
