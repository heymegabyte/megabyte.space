import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useEffect, useState } from 'react';

/**
 * Next Gig Offer — pending invite surface with a 2-minute countdown ring.
 *
 * Reads /api/work/gigs and picks the first claim with status='invited'.
 * Counts down from 120s based on the server's invited_at timestamp (so a
 * remount mid-offer resumes from the correct point rather than restarting).
 * Accept calls POST /api/work/gigs/:id/accept (first-Y-wins per backend).
 *
 * Returns null when there's no pending offer — designed to be mounted always
 * but to disappear when irrelevant.
 */

const OFFER_TTL_SEC = 120;

interface GigInvite {
  id: string;
  booking_id: string;
  status: string;
  claim_id: string;
  claim_status: string;
  invited_at: string;
  start_at: string;
  service_address: string | null;
  service_zip: string | null;
  hours_estimated: number;
  worker_pay_cents_per_person: number;
  customer_notes: string | null;
}

interface GigsResponse {
  invites: GigInvite[];
  completed: unknown[];
  error?: string;
}

function fmtTime(iso: string): string {
  return new Date(iso).toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  });
}

function fmtUsd(cents: number): string {
  return `$${(cents / 100).toFixed(0)}`;
}

export default function NextGigOfferTimer() {
  useThemeToolsSurface('next-gig-offer-timer');
  const [offer, setOffer] = useState<GigInvite | null>(null);
  const [secondsLeft, setSecondsLeft] = useState(OFFER_TTL_SEC);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    void (async () => {
      try {
        const res = await fetch('/api/work/gigs', { credentials: 'include' });
        if (!res.ok) {
          setLoading(false);
          return;
        }
        const json = (await res.json()) as GigsResponse;
        if (json.error) {
          setLoading(false);
          return;
        }
        const pending = (json.invites ?? []).find((g) => g.claim_status === 'invited') ?? null;
        if (pending) {
          const ageSec = Math.max(
            0,
            Math.floor((Date.now() - new Date(pending.invited_at).getTime()) / 1000),
          );
          const remaining = Math.max(0, OFFER_TTL_SEC - ageSec);
          if (remaining > 0) {
            setOffer(pending);
            setSecondsLeft(remaining);
          }
        }
      } catch {
        // silent — no offer is the common case
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  useEffect(() => {
    if (!offer) return;
    const id = window.setInterval(() => {
      setSecondsLeft((s) => {
        if (s <= 1) {
          window.clearInterval(id);
          setOffer(null);
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, [offer]);

  async function accept() {
    if (!offer) return;
    setBusy(true);
    setError('');
    try {
      const res = await fetch(`/api/work/gigs/${encodeURIComponent(offer.id)}/accept`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'content-type': 'application/json' },
      });
      const json = (await res.json()) as { ok?: boolean; error?: string; code?: string };
      if (!res.ok || !json.ok) {
        setError(
          json.code === 'crew_full' ? 'Crew filled before you.' : (json.error ?? 'Accept failed.'),
        );
        return;
      }
      setOffer(null);
    } catch {
      setError('Network error — try again.');
    } finally {
      setBusy(false);
    }
  }

  if (loading || !offer) return null;

  const pct = secondsLeft / OFFER_TTL_SEC;
  const radius = 22;
  const circumference = 2 * Math.PI * radius;
  const dashOffset = circumference * (1 - pct);
  const addr = offer.service_address ?? offer.service_zip ?? '—';
  const estPay = fmtUsd(offer.worker_pay_cents_per_person * offer.hours_estimated);

  return (
    <section
      className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
      aria-labelledby="next-gig-offer-title"
      role="region"
    >
      <header className="mb-3 flex items-center justify-between gap-3">
        <h3
          id="next-gig-offer-title"
          className="font-mono text-[10px] uppercase tracking-widest text-brand-accent"
        >
          New gig offer
        </h3>
        <div className="relative" aria-label={`${secondsLeft} seconds remaining`}>
          <svg width="52" height="52" viewBox="0 0 52 52" aria-hidden="true">
            <circle
              cx="26"
              cy="26"
              r={radius}
              stroke="currentColor"
              strokeWidth="3"
              fill="none"
              className="text-brand-line"
            />
            <circle
              cx="26"
              cy="26"
              r={radius}
              stroke="currentColor"
              strokeWidth="3"
              fill="none"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={dashOffset}
              transform="rotate(-90 26 26)"
              className="text-brand-accent transition-[stroke-dashoffset] duration-1000 ease-linear"
            />
          </svg>
          <span
            className="absolute inset-0 flex items-center justify-center text-xs font-bold text-brand-ink"
            style={{ fontVariantNumeric: 'tabular-nums' }}
          >
            {secondsLeft}s
          </span>
        </div>
      </header>
      <div className="space-y-1">
        <p className="text-sm font-semibold text-brand-ink">{addr}</p>
        <p className="font-mono text-[11px] text-brand-mute">
          {fmtTime(offer.start_at)} · {offer.hours_estimated}h · est. {estPay}
        </p>
        {offer.customer_notes && <p className="text-xs text-brand-mute">{offer.customer_notes}</p>}
      </div>
      {error && <p className="mt-2 text-xs text-red-400">{error}</p>}
      <div className="mt-3 flex gap-2">
        <button
          type="button"
          onClick={accept}
          disabled={busy}
          data-bcl-action="next-gig-offer.accept"
          className="flex-1 rounded-md bg-brand-accent px-3 py-2 text-sm font-semibold text-black hover:brightness-110 disabled:opacity-50"
        >
          {busy ? 'Accepting…' : 'Accept'}
        </button>
        <button
          type="button"
          onClick={() => setOffer(null)}
          disabled={busy}
          data-bcl-action="next-gig-offer.dismiss"
          className="rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-mute hover:text-brand-ink disabled:opacity-50"
        >
          Dismiss
        </button>
      </div>
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
