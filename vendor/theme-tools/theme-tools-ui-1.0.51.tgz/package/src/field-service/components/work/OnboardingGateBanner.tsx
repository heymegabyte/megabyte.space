import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useEffect, useState } from 'react';

// Wave 21B — gate banner that BLOCKS the gig-claim flow until the worker has
// completed the verified onboarding video.
//
// The component fetches `/api/work/completeness` (already an existing surface)
// and watches for the `onboarding_video_watched` checklist key. When the key
// is missing we render a hard-stop banner with a link straight to the video.
// When the key is present (or completeness 404s for any reason) we render
// nothing.

interface CompletenessResponse {
  ok?: boolean;
  checklist?: { id: string; label: string; ok?: boolean }[];
  missingFields?: string[];
}

export function OnboardingGateBanner(): JSX.Element | null {
  useThemeToolsSurface('onboarding-gate-banner');
  const [needsOnboarding, setNeedsOnboarding] = useState(false);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const res = await fetch('/api/work/completeness', {
          credentials: 'include',
          headers: { Accept: 'application/json' },
        });
        if (!res.ok) return;
        const j = (await res.json()) as CompletenessResponse;
        const missing = new Set(j.missingFields ?? []);
        if (cancelled) return;
        setNeedsOnboarding(
          missing.has('onboarding_video_watched') ||
            missing.has('onboarding_video') ||
            (j.checklist ?? []).some(
              (item) =>
                (item.id === 'onboarding_video_watched' || item.id === 'onboarding_video') &&
                item.ok !== true,
            ),
        );
      } catch {
        /* leave gated-off */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (!needsOnboarding) return null;

  return (
    <section
      role="alert"
      aria-live="polite"
      className="mb-6 rounded-2xl border-2 border-red-500/70 bg-gradient-to-br from-red-950/70 to-red-900/40 p-5"
    >
      <p className="eyebrow text-red-200 mb-1">Onboarding required</p>
      <h2 className="text-xl sm:text-2xl font-extrabold text-brand-ink">
        Watch the 8-second onboarding video to unlock dispatch
      </h2>
      <p className="text-sm text-red-100 mt-2 leading-relaxed">
        We can't legally send you on a job until you've finished the onboarding video. It's quick —
        no quiz — and once it's complete you can start accepting invites the same day.
      </p>
      <div className="flex flex-wrap gap-2 mt-4">
        <a href="/work/dashboard#today" className="btn-primary">
          Watch onboarding →
        </a>
        <a href="mailto:hey@bricklabor.com" className="btn-secondary">
          Trouble? Email ops
        </a>
      </div>
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
