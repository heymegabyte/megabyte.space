import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useState } from 'react';
import { VideoPlayer } from './VideoPlayer.js';

// Wave 14 — Worker onboarding video, landscape 16:9.
//
// Rendered inside the worker dashboard's "first-time onboarding" pane. The
// underlying `<VideoPlayer />` posts heartbeats to /api/video/watch/* and
// only fires `onComplete` after the server returns `verified: true`. Until
// then the dispatcher will NOT route gigs to this worker — `hasVerifiedWatch`
// is the gate.
//
// Sample MP4 ships in `public/onboarding/video.mp4` (an 8s placeholder
// produced by `npm run gen:sample-videos`). The poster is the matching
// landscape SVG at `public/onboarding/video-poster.svg`. When the real video
// is filmed, swap the MP4 file at the same path — no code change needed.

export interface OnboardingVideoProps {
  readonly onComplete?: () => void;
  readonly autoStart?: boolean;
}

export function OnboardingVideo({
  onComplete,
  autoStart = false,
}: OnboardingVideoProps): JSX.Element {
  useThemeToolsSurface('onboarding-video');
  const [done, setDone] = useState<boolean>(false);

  const handleComplete = useCallback((): void => {
    setDone(true);
    onComplete?.();
  }, [onComplete]);

  return (
    <section
      aria-labelledby="onboarding-video-heading"
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap: 16,
        padding: 20,
        background: 'var(--color-media-panel)',
        border: '1px solid var(--color-media-line)',
        borderRadius: 16,
      }}
    >
      <header style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        <h2
          id="onboarding-video-heading"
          style={{ margin: 0, fontSize: 22, color: 'var(--color-heading-bright)', fontWeight: 700 }}
        >
          Crew onboarding
        </h2>
        <p style={{ margin: 0, fontSize: 14, color: 'var(--color-media-mute)' }}>
          Watch the full 8-second walkthrough. You must finish it before your first gig is
          dispatched.
        </p>
      </header>

      <VideoPlayer
        videoSrc="/onboarding/video.mp4"
        posterSrc="/onboarding/video-poster.svg"
        videoId="onboarding-2026"
        videoKind="onboarding"
        orientation="landscape"
        autoStart={autoStart}
        onComplete={handleComplete}
        captionLabel="Brick Labor onboarding video"
      />

      {done ? (
        <div
          role="status"
          aria-live="polite"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 12,
            padding: '12px 14px',
            background: 'var(--color-success-panel)',
            border: '1px solid var(--color-success-bright)',
            borderRadius: 12,
            color: 'var(--color-success-ink)',
            fontSize: 14,
          }}
        >
          <span
            aria-hidden="true"
            style={{
              width: 24,
              height: 24,
              borderRadius: 999,
              background: 'var(--color-success-bright)',
              color: 'var(--bg-primary)',
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: 800,
            }}
          >
            ✓
          </span>
          <span>
            Onboarding complete — you can now accept your first gig. Dispatch is unlocked.
          </span>
        </div>
      ) : null}
    </section>
  );
}

export default OnboardingVideo;
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
