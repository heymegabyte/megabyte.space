import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useState } from 'react';

/**
 * Wave 3A — floating red panic button. Gated on `gig_claims.status ===
 * 'checked_in'` (worker is physically on-site). One-tap variants:
 *  - "Panic" → severity high → SMS to owner + ops + incidents row
 *  - "Harassment" → severity medium → harassment-flow with no-retaliation
 *    customer pause
 *
 * On tap: confirm modal → POST /api/work/panic. Geolocation requested but
 * not required.
 */

export interface PanicButtonProps {
  gigId: string;
  claimId: string;
  /** Show the button only when the worker is checked in. */
  visible: boolean;
}

export function PanicButton({ gigId, claimId, visible }: PanicButtonProps) {
  useThemeToolsSurface('panic-button');
  const [open, setOpen] = useState(false);
  const [kind, setKind] = useState<'panic' | 'harassment'>('panic');
  const [notes, setNotes] = useState('');
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<'idle' | 'sent' | 'error'>('idle');
  const [err, setErr] = useState('');

  const send = useCallback(async () => {
    setBusy(true);
    setErr('');
    const payload: Record<string, unknown> = { claimId, kind, notes: notes || undefined };
    const geo = await new Promise<{ lat?: number; lng?: number }>((resolve) => {
      if (typeof navigator === 'undefined' || !('geolocation' in navigator)) {
        resolve({});
        return;
      }
      navigator.geolocation.getCurrentPosition(
        (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        () => resolve({}),
        { enableHighAccuracy: true, timeout: 5000, maximumAge: 30000 },
      );
    });
    if (typeof geo.lat === 'number' && typeof geo.lng === 'number') {
      payload.lat = geo.lat;
      payload.lng = geo.lng;
    }
    try {
      const res = await fetch('/api/work/panic', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        setErr(`Couldn't send (${res.status})`);
        setStatus('error');
        return;
      }
      setStatus('sent');
    } catch (e) {
      setErr(`Network: ${(e as Error).message}`);
      setStatus('error');
    } finally {
      setBusy(false);
    }
  }, [claimId, kind, notes]);

  if (!visible) return null;

  return (
    <>
      <button
        type="button"
        aria-label="Panic — alert ops and owner immediately"
        onClick={() => {
          setStatus('idle');
          setErr('');
          setOpen(true);
        }}
        className="fixed bottom-6 right-6 z-50 inline-flex items-center justify-center rounded-full bg-red-600 hover:bg-red-700 active:bg-red-800 text-white font-extrabold w-16 h-16 shadow-[0_6px_0_0_#7f1d1d] transition-transform active:translate-y-[3px] active:shadow-[0_3px_0_0_#7f1d1d]"
        data-testid="panic-button"
        data-gig-id={gigId}
      >
        <span aria-hidden>SOS</span>
      </button>

      {open && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="panic-modal-title"
          className="fixed inset-0 z-[60] flex items-center justify-center bg-black/70 p-4"
          onClick={(e) => {
            if (e.target === e.currentTarget && !busy) setOpen(false);
          }}
        >
          <div className="w-full max-w-md rounded-2xl border border-red-500/40 bg-brand-card p-5 space-y-3">
            <h2 id="panic-modal-title" className="text-xl font-extrabold text-brand-ink">
              {status === 'sent' ? 'Help is on the way' : 'Alert ops + owner'}
            </h2>
            {status !== 'sent' && (
              <>
                <p className="text-sm text-brand-mute">
                  SMS goes to the owner and ops the second you confirm. Use this if you feel unsafe,
                  if a customer is hostile, or if the job site is dangerous.
                </p>
                <fieldset className="space-y-2">
                  <legend className="text-xs uppercase tracking-wider text-brand-mute">
                    What's happening?
                  </legend>
                  <label className="flex items-center gap-2 text-sm text-brand-ink">
                    <input
                      type="radio"
                      name="panic-kind"
                      checked={kind === 'panic'}
                      onChange={() => setKind('panic')}
                    />
                    Emergency / I feel unsafe (high severity)
                  </label>
                  <label className="flex items-center gap-2 text-sm text-brand-ink">
                    <input
                      type="radio"
                      name="panic-kind"
                      checked={kind === 'harassment'}
                      onChange={() => setKind('harassment')}
                    />
                    Harassment (file with no retaliation)
                  </label>
                </fieldset>
                <label className="flex flex-col gap-1 text-xs text-brand-mute">
                  Quick notes (optional)
                  <textarea
                    rows={3}
                    maxLength={2000}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="rounded-lg border border-brand-line bg-brand-bg px-3 py-2 text-sm text-brand-ink"
                  />
                </label>
                {err && (
                  <p role="alert" className="text-sm text-red-300">
                    {err}
                  </p>
                )}
                <div className="flex gap-2">
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => void send()}
                    className="flex-1 rounded-xl bg-red-600 hover:bg-red-700 px-4 py-3 text-sm font-extrabold text-white disabled:opacity-50"
                  >
                    {busy
                      ? 'Sending…'
                      : kind === 'panic'
                        ? 'Send PANIC alert'
                        : 'Send harassment report'}
                  </button>
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => setOpen(false)}
                    className="rounded-xl border border-brand-line bg-transparent px-4 py-3 text-sm font-bold text-brand-mute hover:text-brand-ink transition-colors"
                  >
                    Cancel
                  </button>
                </div>
                <p className="text-[11px] text-brand-mute">
                  If this is a life-threatening emergency, dial 911 first. This button does not
                  replace 911.
                </p>
              </>
            )}
            {status === 'sent' && (
              <>
                <p className="text-sm text-emerald-300">
                  Alert sent. Ops will reach out by SMS within minutes.
                </p>
                <button type="button" onClick={() => setOpen(false)} className="btn-primary w-full">
                  Close
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
