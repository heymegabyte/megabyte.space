import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useEffect, useState } from 'react';

// Wave 21B — current + longest 5-star streak plus total 5-star count.
//
// Reads `/api/work/streak`. Falls back to a synthetic zero-state if the
// endpoint 401s or fails — workers without any reviews yet see the card with
// a "Get your first 5-star review" prompt.

interface StreakApiResponse {
  workerId: string;
  currentStreak: number;
  longestStreak: number;
  last5starAt: string | null;
  total5stars: number;
}

export function StreakCard(): JSX.Element {
  useThemeToolsSurface('streak-card');
  const [data, setData] = useState<StreakApiResponse | null>(null);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const res = await fetch('/api/work/streak', {
          credentials: 'include',
          headers: { Accept: 'application/json' },
        });
        if (!res.ok) return;
        const j = (await res.json()) as StreakApiResponse;
        if (!cancelled) setData(j);
      } catch {
        /* leave null */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const current = data?.currentStreak ?? 0;
  const longest = data?.longestStreak ?? 0;
  const total = data?.total5stars ?? 0;

  return (
    <section
      aria-label="Five-star review streak"
      className="rounded-2xl border border-brand-line bg-gradient-to-br from-yellow-900/20 via-amber-950/30 to-brand-card p-5"
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <div>
          <p className="eyebrow text-yellow-300 mb-1">Five-star streak</p>
          <h3 className="text-lg font-extrabold text-brand-ink">
            {current === 0 ? 'Land your first 5-star review' : `${current} in a row`}
          </h3>
        </div>
        <span aria-hidden="true" className="text-3xl leading-none" title="streak">
          {current >= 5 ? '★★★★★' : '★'}
        </span>
      </div>
      <dl className="grid grid-cols-3 gap-3 text-center">
        <div>
          <dt className="text-[11px] uppercase tracking-wide text-brand-mute">Current</dt>
          <dd className="text-2xl font-extrabold text-yellow-200">{current}</dd>
        </div>
        <div>
          <dt className="text-[11px] uppercase tracking-wide text-brand-mute">Longest</dt>
          <dd className="text-2xl font-extrabold text-brand-ink">{longest}</dd>
        </div>
        <div>
          <dt className="text-[11px] uppercase tracking-wide text-brand-mute">All-time 5★</dt>
          <dd className="text-2xl font-extrabold text-brand-ink">{total}</dd>
        </div>
      </dl>
      {data?.last5starAt && (
        <p className="text-xs text-brand-mute mt-3 text-center">
          Last 5★: {new Date(data.last5starAt).toLocaleDateString()}
        </p>
      )}
      {current === 0 && (
        <p className="text-xs text-brand-mute mt-3 text-center">
          Tip: a clean before/after photo + a quick text to the customer asking for a review doubles
          your chance of 5 stars.
        </p>
      )}
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
