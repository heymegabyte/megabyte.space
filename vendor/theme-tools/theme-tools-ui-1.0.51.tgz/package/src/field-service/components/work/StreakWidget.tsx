import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useEffect, useState } from 'react';

/**
 * Streak widget — gamified retention panel for the crew dashboard. Pairs the
 * sequential 5-star streak counter (GET /api/work/streak) with the tier
 * ladder (GET /api/work/profile/tier) so the worker sees current streak,
 * longest streak, current tier with a progress bar to the next tier, and
 * the next-tier coach line.
 *
 * No props — both endpoints are gated by the worker session cookie.
 *
 * Empty state: "Complete your first gig to start a streak →" (when both
 * streak and tier jobsCompleted are zero).
 */

interface StreakResponse {
  workerId?: string;
  currentStreak?: number;
  longestStreak?: number;
  last5starAt?: string | null;
  total5stars?: number;
  error?: string;
}

interface TierResponse {
  ok?: boolean;
  current?: { slug: string; name: string; hourlyRateCents: number; leadEligible: boolean } | null;
  next?: {
    slug: string;
    name: string;
    hourlyRateCents: number;
    minRating: number | null;
    minJobs: number;
  } | null;
  progress?: {
    jobsCompleted: number;
    ratingAvg: number | null;
    ratingCount: number;
  };
  advice?: string;
  error?: string;
}

function fmtUsd(cents: number): string {
  return `$${(cents / 100).toFixed(0)}`;
}

function progressPct(done: number, target: number): number {
  if (target <= 0) return 100;
  return Math.max(0, Math.min(100, Math.round((done / target) * 100)));
}

export default function StreakWidget() {
  useThemeToolsSurface('streak-widget');
  const [streak, setStreak] = useState<StreakResponse | null>(null);
  const [tier, setTier] = useState<TierResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    void (async () => {
      try {
        const [streakRes, tierRes] = await Promise.all([
          fetch('/api/work/streak', { credentials: 'include' }),
          fetch('/api/work/profile/tier', { credentials: 'include' }),
        ]);
        if (streakRes.status === 401 || tierRes.status === 401) {
          setError('Sign in to see your streak.');
          return;
        }
        const streakJson = (await streakRes.json()) as StreakResponse;
        const tierJson = (await tierRes.json()) as TierResponse;
        if (streakJson.error && tierJson.error) {
          setError(streakJson.error);
          return;
        }
        setStreak(streakJson);
        setTier(tierJson);
      } catch {
        setError('Network error loading streak.');
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) {
    return (
      <section
        className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
        aria-live="polite"
      >
        <p className="text-sm text-brand-mute">Loading streak…</p>
      </section>
    );
  }
  if (error) {
    return (
      <section className="rounded-2xl border border-brand-line bg-bg-elevated p-4">
        <p className="text-sm text-red-400">{error}</p>
      </section>
    );
  }

  const current = streak?.currentStreak ?? 0;
  const longest = streak?.longestStreak ?? 0;
  const total = streak?.total5stars ?? 0;
  const jobs = tier?.progress?.jobsCompleted ?? 0;
  const tierName = tier?.current?.name ?? 'Apprentice';
  const nextName = tier?.next?.name ?? null;
  const minJobs = tier?.next?.minJobs ?? 0;
  const pct = nextName ? progressPct(jobs, minJobs) : 100;

  if (current === 0 && jobs === 0 && total === 0) {
    return (
      <section
        className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
        aria-labelledby="streak-title"
      >
        <header className="mb-3">
          <h3
            id="streak-title"
            className="font-mono text-[10px] uppercase tracking-widest text-brand-accent"
          >
            5-star streak
          </h3>
        </header>
        <p className="text-sm text-brand-mute">
          Complete your first gig to start a streak{' '}
          <a href="/work/dashboard#today" className="text-brand-accent hover:underline">
            →
          </a>
        </p>
      </section>
    );
  }

  return (
    <section
      className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
      aria-labelledby="streak-title"
    >
      <header className="mb-3 flex items-baseline justify-between gap-3">
        <h3
          id="streak-title"
          className="font-mono text-[10px] uppercase tracking-widest text-brand-accent"
        >
          5-star streak
        </h3>
        <span className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
          {total} total
        </span>
      </header>
      <div className="mb-4 flex items-baseline gap-4">
        <div>
          <p
            className="text-4xl font-bold leading-none text-brand-ink"
            style={{ fontVariantNumeric: 'tabular-nums' }}
            aria-label={`Current streak: ${current} five-star reviews in a row`}
          >
            {current}
          </p>
          <p className="mt-1 font-mono text-[10px] uppercase tracking-widest text-brand-mute">
            in a row
          </p>
        </div>
        <div className="rounded-md border border-brand-line bg-bg-primary px-3 py-2">
          <p
            className="text-lg font-semibold text-brand-ink"
            style={{ fontVariantNumeric: 'tabular-nums' }}
          >
            {longest}
          </p>
          <p className="font-mono text-[9px] uppercase tracking-widest text-brand-mute">longest</p>
        </div>
      </div>
      <div className="rounded-xl border border-brand-line bg-bg-primary/40 p-3">
        <div className="mb-2 flex items-baseline justify-between gap-3">
          <p className="text-sm font-semibold text-brand-accent">{tierName}</p>
          {tier?.current?.hourlyRateCents != null && (
            <p
              className="font-mono text-[10px] uppercase tracking-widest text-brand-mute"
              style={{ fontVariantNumeric: 'tabular-nums' }}
            >
              {fmtUsd(tier.current.hourlyRateCents)}/hr
            </p>
          )}
        </div>
        {nextName ? (
          <>
            <div
              className="h-2 overflow-hidden rounded-full border border-brand-line bg-bg-primary"
              role="progressbar"
              aria-label={`${pct}% to ${nextName}`}
              aria-valuenow={pct}
              aria-valuemin={0}
              aria-valuemax={100}
            >
              <div
                className="h-full bg-brand-accent transition-[width] duration-500"
                style={{ width: `${pct}%` }}
              />
            </div>
            <p className="mt-2 text-xs text-brand-mute">
              {jobs}/{minJobs} jobs to <span className="text-brand-ink">{nextName}</span>
            </p>
            {tier?.advice && <p className="mt-1 text-xs text-brand-mute">{tier.advice}</p>}
          </>
        ) : (
          <p className="text-xs text-brand-mute">Top tier reached. Keep stacking 5-stars.</p>
        )}
      </div>
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
