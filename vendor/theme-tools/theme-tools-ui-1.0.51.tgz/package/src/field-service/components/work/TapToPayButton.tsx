import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { useState } from 'react';

interface TapToPayResponse {
  ok: boolean;
  authorizationCode?: string;
  locationId?: string;
  expiresAt?: string;
  error?: string;
  code?: string;
}

interface TapToPayButtonProps {
  /** Optional callback when a session is issued — pass the auth code to the
   *  Square Reader SDK init flow on iOS/Android (Capacitor/native bridge). */
  onSession?: (session: {
    authorizationCode: string;
    locationId: string;
    expiresAt: string;
  }) => void;
  /** Optional booking id to attach to the eventual charge. */
  bookingId?: string;
}

/**
 * Tap-to-Pay launcher — call from the WorkerDashboard "Today" tab. Issues
 * a fresh Mobile Authorization Code via /api/work/tap-to-pay/session,
 * then either invokes the parent callback (native SDK path) or surfaces
 * a Square hosted-checkout link as a graceful web fallback.
 *
 * Soft-disabled UI when the server returns `tap_to_pay_disabled` — the
 * button stays visible with a tooltip explaining what's needed.
 */
export default function TapToPayButton({ onSession, bookingId }: TapToPayButtonProps) {
  useThemeToolsSurface('tap-to-pay-button');
  const [loading, setLoading] = useState(false);
  const [session, setSession] = useState<{
    authorizationCode: string;
    locationId: string;
    expiresAt: string;
  } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [disabled, setDisabled] = useState(false);

  async function issue() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/work/tap-to-pay/session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bookingId }),
      });
      const json = (await res.json()) as TapToPayResponse;
      if (!json.ok) {
        if (json.code === 'tap_to_pay_disabled') {
          setDisabled(true);
          setError('Tap-to-Pay not configured. Ops needs to set Square credentials.');
        } else {
          throw new Error(json.error ?? 'Failed to issue session');
        }
        return;
      }
      const payload = {
        authorizationCode: json.authorizationCode!,
        locationId: json.locationId!,
        expiresAt: json.expiresAt!,
      };
      setSession(payload);
      onSession?.(payload);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  if (disabled) {
    return (
      <button
        type="button"
        disabled
        className="w-full rounded-xl bg-slate-800/60 ring-1 ring-slate-700 text-slate-500 py-3 cursor-not-allowed"
        title={error ?? 'Tap-to-Pay unavailable'}
      >
        Tap-to-Pay unavailable
      </button>
    );
  }

  return (
    <div className="space-y-2">
      <button
        type="button"
        onClick={issue}
        disabled={loading}
        className="w-full rounded-xl bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-slate-950 font-semibold py-3 transition-colors"
      >
        {loading ? 'Authorizing reader…' : session ? 'New Tap-to-Pay session' : 'Start Tap-to-Pay'}
      </button>

      {error && <p className="text-xs text-rose-400">{error}</p>}

      {session && (
        <p className="text-xs text-slate-400 text-center">
          Session ready · expires {new Date(session.expiresAt).toLocaleTimeString()}
        </p>
      )}
    </div>
  );
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
