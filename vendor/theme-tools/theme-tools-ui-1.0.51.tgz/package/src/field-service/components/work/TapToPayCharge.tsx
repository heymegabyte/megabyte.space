import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { useState } from 'react';

interface ChargeResponse {
  ok: boolean;
  receiptToken?: string;
  paymentId?: string;
  status?: string;
  amountCents?: number;
  feeCents?: number;
  receiptUrl?: string | null;
  cardBrand?: string | null;
  cardLast4?: string | null;
  error?: string;
  code?: string;
}

interface TapToPayChargeProps {
  /** Booking id this charge is associated with (optional). */
  bookingId?: string;
  /** Square customer id, if known. */
  squareCustomerId?: string;
  /** Optional initial amount in dollars (the worker can override). */
  initialAmountDollars?: number;
  /** Fired after a successful charge so the parent can refresh. */
  onCharged?: (
    result: NonNullable<Pick<ChargeResponse, 'paymentId' | 'amountCents' | 'receiptUrl'>>,
  ) => void;
}

/**
 * Tap-to-Pay charge flow — used at job end. The worker enters the amount
 * (+ optional tip), the device captures a single-use Square payment token
 * via the Reader SDK, this component POSTs to /api/work/tap-to-pay/charge
 * which calls Square Payments and persists the charge.
 *
 * On native iOS/Android (Capacitor) the auth session feeds into the Reader
 * SDK to surface the NFC sheet. On web we expose the same flow as a graceful
 * fallback so ops can still test the chain end-to-end via Square's sandbox
 * `cnon:card-nonce-ok` test token.
 */
export default function TapToPayCharge({
  bookingId,
  squareCustomerId,
  initialAmountDollars,
  onCharged,
}: TapToPayChargeProps) {
  useThemeToolsSurface('tap-to-pay-charge');
  const [amountDollars, setAmountDollars] = useState(
    initialAmountDollars ? initialAmountDollars.toFixed(2) : '',
  );
  const [tipDollars, setTipDollars] = useState('');
  const [sourceId, setSourceId] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<ChargeResponse | null>(null);

  async function captureToken() {
    setError(null);
    setBusy(true);
    try {
      // First, mint the Mobile Authorization Code (kept for native bridge).
      const sesRes = await fetch('/api/work/tap-to-pay/session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bookingId }),
      });
      const sesJson = (await sesRes.json()) as {
        ok: boolean;
        authorizationCode?: string;
        error?: string;
        code?: string;
      };
      if (!sesJson.ok) {
        throw new Error(
          sesJson.code === 'tap_to_pay_disabled'
            ? 'Tap-to-Pay not configured.'
            : (sesJson.error ?? 'auth_failed'),
        );
      }
      // On native, hand `sesJson.authorizationCode` to the Reader SDK, await
      // the NFC tap, and the SDK returns a one-time `cnon:...` source id.
      // On web fallback, the worker pastes a Square sandbox source id below.
      // (We don't simulate the NFC flow here — the parent native bridge does.)
      const nativeBridge = (
        window as unknown as {
          squareTapToPay?: { capture: (authCode: string) => Promise<string> };
        }
      ).squareTapToPay;
      if (nativeBridge?.capture) {
        const captured = await nativeBridge.capture(sesJson.authorizationCode!);
        setSourceId(captured);
      } else {
        setError('Tap your phone to the card now, then paste the source id.');
      }
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function runCharge() {
    setError(null);
    setSuccess(null);
    const amountCents = Math.round(parseFloat(amountDollars) * 100);
    if (!isFinite(amountCents) || amountCents <= 0) {
      setError('Enter a valid amount.');
      return;
    }
    const tipCents = tipDollars ? Math.max(0, Math.round(parseFloat(tipDollars) * 100)) : 0;
    if (!sourceId) {
      setError('Capture the card tap first.');
      return;
    }
    setBusy(true);
    try {
      const res = await fetch('/api/work/tap-to-pay/charge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sourceId,
          amountCents,
          tipCents,
          bookingId,
          customerId: squareCustomerId,
        }),
      });
      const json = (await res.json()) as ChargeResponse;
      if (!json.ok) throw new Error(json.error ?? 'charge_failed');
      setSuccess(json);
      onCharged?.({
        paymentId: json.paymentId,
        amountCents: json.amountCents,
        receiptUrl: json.receiptUrl ?? null,
      });
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="rounded-2xl bg-slate-900/60 ring-1 ring-white/10 p-5 space-y-3">
      <header>
        <h3 className="text-base font-semibold text-white">Tap-to-Pay charge</h3>
        <p className="text-xs text-slate-400 mt-0.5">
          Charge the customer's card right at the door. Funds land in Square instantly.
        </p>
      </header>

      <div className="grid grid-cols-2 gap-3">
        <label className="block">
          <span className="text-xs text-slate-400 uppercase">Amount ($)</span>
          <input
            type="number"
            step="0.01"
            min="0"
            value={amountDollars}
            onChange={(e) => setAmountDollars(e.target.value)}
            className="block w-full bg-slate-950 border border-white/10 rounded-md px-3 py-2 text-sm text-white mt-1"
            placeholder="0.00"
          />
        </label>
        <label className="block">
          <span className="text-xs text-slate-400 uppercase">Tip ($)</span>
          <input
            type="number"
            step="0.01"
            min="0"
            value={tipDollars}
            onChange={(e) => setTipDollars(e.target.value)}
            className="block w-full bg-slate-950 border border-white/10 rounded-md px-3 py-2 text-sm text-white mt-1"
            placeholder="optional"
          />
        </label>
      </div>

      <div className="flex gap-2">
        <button
          type="button"
          onClick={captureToken}
          disabled={busy}
          className="flex-1 rounded-md bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-slate-950 font-semibold py-2 text-sm"
        >
          {busy ? 'Working…' : '1. Capture tap'}
        </button>
        <button
          type="button"
          onClick={runCharge}
          disabled={busy || !sourceId}
          className="flex-1 rounded-md bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 font-semibold py-2 text-sm"
        >
          2. Charge card
        </button>
      </div>

      {/* Web fallback for ops + testing — never visible on iOS/Android native */}
      {!sourceId && (
        <label className="block">
          <span className="text-xs text-slate-400 uppercase">
            Source id (web fallback / sandbox)
          </span>
          <input
            type="text"
            value={sourceId}
            onChange={(e) => setSourceId(e.target.value)}
            className="block w-full bg-slate-950 border border-white/10 rounded-md px-3 py-2 text-xs font-mono text-white mt-1"
            placeholder="cnon:card-nonce-ok"
          />
        </label>
      )}

      {error && <p className="text-xs text-rose-400">{error}</p>}
      {success && success.ok && (
        <div className="rounded-md bg-emerald-500/10 ring-1 ring-emerald-500/30 p-3 text-sm text-emerald-200">
          <p className="font-semibold">
            Charged ${((success.amountCents ?? 0) / 100).toFixed(2)} {success.cardBrand} ·{' '}
            {success.cardLast4 ? `…${success.cardLast4}` : ''}
          </p>
          {success.receiptUrl && (
            <a
              href={success.receiptUrl}
              target="_blank"
              rel="noreferrer"
              className="text-cyan-300 hover:underline text-xs"
            >
              Square receipt →
            </a>
          )}
          {typeof success.feeCents === 'number' && (
            <p className="text-xs text-emerald-300/80 mt-1">
              Fee: ${((success.feeCents ?? 0) / 100).toFixed(2)} (Square Tap-to-Pay rate)
            </p>
          )}
        </div>
      )}
    </section>
  );
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
