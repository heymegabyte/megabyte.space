import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useMemo, useState } from 'react';

/**
 * Wave 3A — in-app tax surface.
 *
 *  - Year-end CSV download via GET /api/work/payouts/tax/csv?year=YYYY
 *  - Estimated quarterly set-aside (25-35%)
 *  - IRS 2025 standard mileage rate $0.70/mi
 *  - Stripe Express form link
 *  - Everlance + MileIQ deeplinks for mileage tracking
 *
 * Per IRS Notice 2025-05 (Internal Revenue Service, 2025), the 2025 standard
 * mileage rate for business use is $0.70 per mile — the rate workers should
 * use when reconciling 1099-NEC income with the Schedule C deductions.
 */

const CURRENT_YEAR = new Date().getUTCFullYear();
const YEARS = [CURRENT_YEAR, CURRENT_YEAR - 1, CURRENT_YEAR - 2];

const IRS_MILEAGE_2025_USD = 0.7;
const IRS_MILEAGE_2025_CITE = 'IRS Notice 2025-05';

export interface TaxSurfaceProps {
  taxYearTotalCents?: number;
  hasStripeAccount?: boolean;
}

function dollars(cents: number): string {
  return `$${(cents / 100).toFixed(2)}`;
}

export function TaxSurface({ taxYearTotalCents = 0, hasStripeAccount = false }: TaxSurfaceProps) {
  useThemeToolsSurface('tax-surface');
  const [year, setYear] = useState<number>(CURRENT_YEAR);
  const [downloading, setDownloading] = useState(false);

  const setAside = useMemo(() => {
    return {
      low: Math.round(taxYearTotalCents * 0.25),
      high: Math.round(taxYearTotalCents * 0.35),
    };
  }, [taxYearTotalCents]);

  async function downloadCsv() {
    setDownloading(true);
    try {
      const url = `/api/work/payouts/tax/csv?year=${encodeURIComponent(String(year))}`;
      const a = document.createElement('a');
      a.href = url;
      a.rel = 'noopener';
      a.click();
    } finally {
      setDownloading(false);
    }
  }

  return (
    <section className="space-y-5" data-testid="tax-surface">
      <header>
        <p className="eyebrow mb-1">Taxes</p>
        <h2 className="text-2xl font-extrabold text-brand-ink">Year-end tax surface</h2>
        <p className="text-sm text-brand-mute mt-1">
          Set aside 25–35% of every payout for federal + state + self-employment tax. Square files
          your 1099-NEC; we give you the working copy.
        </p>
      </header>

      <div className="rounded-2xl border border-brand-line bg-brand-card p-5 space-y-3">
        <h3 className="text-lg font-extrabold text-brand-ink">Set-aside estimate</h3>
        <p className="text-sm text-brand-mute">
          Based on YTD earnings of{' '}
          <span className="font-extrabold text-brand-ink">{dollars(taxYearTotalCents)}</span>:
        </p>
        <dl className="grid grid-cols-2 gap-3">
          <div className="rounded-xl border border-brand-line bg-brand-bg/40 p-3">
            <dt className="text-xs uppercase tracking-wider text-brand-mute">25% (conservative)</dt>
            <dd className="text-2xl font-extrabold text-brand-ink">{dollars(setAside.low)}</dd>
          </div>
          <div className="rounded-xl border border-brand-accent/40 bg-brand-accent/5 p-3">
            <dt className="text-xs uppercase tracking-wider text-brand-mute">35% (safe)</dt>
            <dd className="text-2xl font-extrabold text-brand-accent">{dollars(setAside.high)}</dd>
          </div>
        </dl>
        <p className="text-[11px] text-brand-mute">
          Estimates only; consult a CPA before filing. Self-employment tax is 15.3% on top of income
          tax.
        </p>
      </div>

      <div className="rounded-2xl border border-brand-line bg-brand-card p-5 space-y-3">
        <h3 className="text-lg font-extrabold text-brand-ink">Mileage deduction</h3>
        <p className="text-sm text-brand-mute">
          IRS 2025 standard mileage rate:{' '}
          <span className="font-extrabold text-brand-ink">
            ${IRS_MILEAGE_2025_USD.toFixed(2)}/mi
          </span>{' '}
          ({IRS_MILEAGE_2025_CITE}). Track every mile from your address to the job site and back.
        </p>
        <div className="flex flex-wrap gap-2">
          <a
            href="https://www.everlance.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="rounded-xl border border-brand-line bg-brand-bg/60 px-3 py-2 text-xs font-bold text-brand-ink hover:bg-brand-line transition-colors"
          >
            Everlance ↗
          </a>
          <a
            href="https://mileiq.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="rounded-xl border border-brand-line bg-brand-bg/60 px-3 py-2 text-xs font-bold text-brand-ink hover:bg-brand-line transition-colors"
          >
            MileIQ ↗
          </a>
          <a
            href="https://stride.health/"
            target="_blank"
            rel="noopener noreferrer"
            className="rounded-xl border border-brand-line bg-brand-bg/60 px-3 py-2 text-xs font-bold text-brand-ink hover:bg-brand-line transition-colors"
          >
            Stride (free) ↗
          </a>
        </div>
      </div>

      <div className="rounded-2xl border border-brand-line bg-brand-card p-5 space-y-3">
        <h3 className="text-lg font-extrabold text-brand-ink">CSV export</h3>
        <p className="text-sm text-brand-mute">
          One row per completed gig — hours, miles, pay, tips. Open in Numbers, Excel, or Google
          Sheets when you file Schedule C.
        </p>
        <div className="flex flex-wrap items-end gap-3">
          <label className="flex flex-col gap-1 text-xs text-brand-mute">
            Tax year
            <select
              value={year}
              onChange={(e) => setYear(Number(e.target.value))}
              className="rounded-lg border border-brand-line bg-brand-bg px-3 py-2 text-sm text-brand-ink"
            >
              {YEARS.map((y) => (
                <option key={y} value={y}>
                  {y}
                </option>
              ))}
            </select>
          </label>
          <button
            type="button"
            onClick={() => void downloadCsv()}
            disabled={downloading}
            className="btn-primary"
          >
            {downloading ? 'Preparing…' : `Download ${year} CSV`}
          </button>
        </div>
      </div>

      <div className="rounded-2xl border border-brand-line bg-brand-card p-5 space-y-2">
        <h3 className="text-lg font-extrabold text-brand-ink">Stripe Express W-9 / 1099</h3>
        <p className="text-sm text-brand-mute">
          {hasStripeAccount
            ? 'Your Stripe Express account holds the official 1099-NEC. Log in to download.'
            : 'Open a Stripe Express account to receive the official IRS 1099-NEC.'}
        </p>
        <a
          href="https://connect.stripe.com/express_login"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 rounded-xl border border-brand-accent/40 bg-brand-accent/10 px-4 py-2 text-sm font-bold text-brand-accent hover:bg-brand-accent/20 transition-colors"
        >
          Open Stripe Express ↗
        </a>
      </div>

      <p className="text-[11px] text-brand-mute">
        Reference: {IRS_MILEAGE_2025_CITE} establishes the 2025 standard business mileage rate at
        $0.70/mi (Internal Revenue Service, 2025).
      </p>
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
