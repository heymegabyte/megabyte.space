import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useState } from 'react';
import { VideoPlayer } from './VideoPlayer.js';

// Wave 14 — Technique Library. TikTok-grade 9:16 portrait clips embedded in
// a responsive grid. Each tile is its own verified `<VideoPlayer />`.
//
// The catalog is intentionally inline (not a JSON file) — these are short,
// stable, and read by humans more than by build steps. When new techniques
// are filmed: add a new entry + drop the MP4 in `public/technique/`.

interface TechniqueClip {
  readonly videoId: string;
  readonly title: string;
  readonly slug: string;
  readonly summary: string;
}

const TECHNIQUE_CLIPS: readonly TechniqueClip[] = [
  {
    videoId: 'lifting-form',
    slug: 'lifting-form',
    title: 'Safe lifting form',
    summary: 'Knees bent, back straight, weight against your chest.',
  },
  {
    videoId: 'dolly-handling',
    slug: 'dolly-handling',
    title: 'Dolly handling',
    summary: 'Strap first, two-hand grip, stairs go slow.',
  },
  {
    videoId: 'de-escalation',
    slug: 'de-escalation',
    title: 'Customer de-escalation',
    summary: 'Voice low, hands visible, repeat the ask back.',
  },
  {
    videoId: 'power-wash-stance',
    slug: 'power-wash-stance',
    title: 'Power-wash stance',
    summary: 'Wide base, both hands on the wand, sweep top-down.',
  },
  {
    videoId: 'lawn-edge-pattern',
    slug: 'lawn-edge-pattern',
    title: 'Lawn edge pattern',
    summary: 'Straight line along the curb, overlap each pass by an inch.',
  },
  {
    videoId: 'haul-securement',
    slug: 'haul-securement',
    title: 'Haul securement',
    summary: 'Ratchet straps in an X, tarp tucked, double-check before driving.',
  },
];

export interface TechniqueLibraryProps {
  readonly onClipComplete?: (videoId: string) => void;
}

export function TechniqueLibrary({ onClipComplete }: TechniqueLibraryProps): JSX.Element {
  useThemeToolsSurface('technique-library');
  const [watched, setWatched] = useState<ReadonlySet<string>>(() => new Set());

  const handleComplete = useCallback(
    (videoId: string): void => {
      setWatched((prev) => {
        const next = new Set(prev);
        next.add(videoId);
        return next;
      });
      onClipComplete?.(videoId);
    },
    [onClipComplete],
  );

  return (
    <section
      aria-labelledby="technique-library-heading"
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap: 16,
      }}
    >
      <header style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        <h2
          id="technique-library-heading"
          style={{ margin: 0, fontSize: 22, color: 'var(--color-heading-bright)', fontWeight: 700 }}
        >
          Technique library
        </h2>
        <p style={{ margin: 0, fontSize: 14, color: 'var(--color-media-mute)' }}>
          Short, vertical, watch-on-the-job clips. The badge appears after you finish each one.
        </p>
      </header>

      <ul
        style={{
          listStyle: 'none',
          margin: 0,
          padding: 0,
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
          gap: 18,
        }}
      >
        {TECHNIQUE_CLIPS.map((clip) => {
          const isWatched = watched.has(clip.videoId);
          return (
            <li
              key={clip.videoId}
              style={{
                background: 'var(--color-media-panel)',
                border: '1px solid var(--color-media-line)',
                borderRadius: 16,
                padding: 14,
                display: 'flex',
                flexDirection: 'column',
                gap: 10,
              }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'baseline',
                  justifyContent: 'space-between',
                  gap: 8,
                }}
              >
                <h3 style={{ margin: 0, fontSize: 16, color: 'var(--color-heading-bright)' }}>
                  {clip.title}
                </h3>
                {isWatched ? (
                  <span
                    style={{
                      fontSize: 11,
                      padding: '2px 8px',
                      borderRadius: 999,
                      background: 'var(--color-success-panel)',
                      color: 'var(--color-success-bright)',
                      border: '1px solid var(--color-success-bright)',
                      letterSpacing: '.04em',
                      textTransform: 'uppercase',
                      fontWeight: 700,
                    }}
                  >
                    Watched
                  </span>
                ) : null}
              </div>

              <VideoPlayer
                videoSrc={`/technique/${clip.slug}.mp4`}
                posterSrc="/onboarding/video-poster.svg"
                videoId={`technique-${clip.videoId}`}
                videoKind="technique"
                orientation="portrait"
                onComplete={() => handleComplete(clip.videoId)}
                captionLabel={`Technique: ${clip.title}`}
              />

              <p style={{ margin: 0, fontSize: 13, color: '#A6B0BE' }}>{clip.summary}</p>
            </li>
          );
        })}
      </ul>
    </section>
  );
}

export default TechniqueLibrary;
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
