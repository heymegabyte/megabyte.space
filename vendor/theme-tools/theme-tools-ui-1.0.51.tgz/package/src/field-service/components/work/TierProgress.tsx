import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useMemo, useState } from 'react';

/**
 * Wave 4B — worker tier progress card.
 *
 * Renders a four-tier ladder (apprentice → pro → lead → master), the worker's
 * current badge + hourly rate, an AI-written coach paragraph (with a rules
 * fallback baked into the API), and a progress bar to the next tier.
 *
 * When the worker has an active gig, the card also surfaces the surge-mirror
 * effective hourly rate so they see exactly why their pay-rate moved:
 *   "Your rate this gig: $35 × 1.485 surge = $51.97/hr"
 *
 * Data: GET /api/work/profile/tier — see workers/main/src/routes/worker-tier.ts.
 * The card is self-contained: parent need only mount it.
 */

type TierSlug = 'apprentice' | 'pro' | 'lead' | 'master';

interface TierLadderRow {
  slug: TierSlug;
  name: string;
  hourlyRateCents: number;
  minRating: number | null;
  minJobs: number;
  requiresCanDrive: boolean;
  leadEligible: boolean;
  displayOrder: number;
}

interface TierResponse {
  ok: true;
  current: {
    slug: TierSlug;
    name: string;
    hourlyRateCents: number;
    leadEligible: boolean;
  } | null;
  next: {
    slug: TierSlug;
    name: string;
    hourlyRateCents: number;
    minRating: number | null;
    minJobs: number;
    requiresCanDrive: boolean;
    leadEligible: boolean;
  } | null;
  progress: {
    jobsCompleted: number;
    ratingAvg: number | null;
    ratingCount: number;
    requestAgainCount: number;
    noShowCount: number;
    disputeCount: number;
    canDrive: boolean;
    canRepair: boolean;
    skills: string[];
  };
  reasoning: string;
  advice: string;
  recomputedAt: number | null;
  currentGigRate: {
    gigId: string;
    baseHourlyCents: number;
    multiplier: number;
    effectiveHourlyCents: number;
    reasons: ReadonlyArray<{ kind: string; label: string }>;
  } | null;
  ladder: TierLadderRow[];
}

const TIER_TONE: Record<TierSlug, { bg: string; ring: string; text: string }> = {
  apprentice: { bg: 'bg-slate-700/40', ring: 'ring-slate-500/60', text: 'text-slate-100' },
  pro: { bg: 'bg-sky-700/40', ring: 'ring-sky-400/60', text: 'text-sky-50' },
  lead: { bg: 'bg-amber-600/40', ring: 'ring-amber-300/70', text: 'text-amber-50' },
  master: { bg: 'bg-fuchsia-700/40', ring: 'ring-fuchsia-300/70', text: 'text-fuchsia-50' },
};

function fmtDollars(cents: number): string {
  return `$${(cents / 100).toFixed(cents % 100 === 0 ? 0 : 2)}`;
}

function fmtRate(cents: number): string {
  return `${fmtDollars(cents)}/hr`;
}

function fmtTimeAgo(ts: number | null): string {
  if (!ts) return 'never';
  const diff = Math.max(0, Date.now() - ts);
  const minutes = Math.floor(diff / 60_000);
  if (minutes < 60) return `${minutes || 1}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

export function TierProgress({ className = '' }: { className?: string }) {
  useThemeToolsSurface('tier-progress');
  const [data, setData] = useState<TierResponse | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const refresh = useCallback(async () => {
    setBusy(true);
    setError('');
    try {
      const res = await fetch('/api/work/profile/tier', {
        headers: { Accept: 'application/json' },
      });
      if (!res.ok) {
        setError(`Couldn't load your tier (${res.status}).`);
        return;
      }
      const json = (await res.json()) as TierResponse;
      if (!json.ok) {
        setError('Tier data unavailable.');
        return;
      }
      setData(json);
    } catch {
      setError('Connection issue. Try refreshing.');
    } finally {
      setBusy(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const progressPct = useMemo(() => {
    if (!data?.next) return 100;
    const jobsRatio = Math.min(1, data.progress.jobsCompleted / Math.max(1, data.next.minJobs));
    const ratingRatio =
      data.next.minRating !== null
        ? Math.min(1, (data.progress.ratingAvg ?? 0) / data.next.minRating)
        : 1;
    return Math.round(((jobsRatio + ratingRatio) / 2) * 100);
  }, [data]);

  if (error) {
    return (
      <section
        aria-labelledby="tier-progress-heading"
        className={`rounded-2xl border border-brand-line bg-brand-card p-6 ${className}`}
      >
        <h3
          id="tier-progress-heading"
          className="text-sm font-bold uppercase tracking-wide text-brand-mute"
        >
          Your tier
        </h3>
        <p role="alert" className="mt-2 text-sm text-red-300">
          {error}
        </p>
        <button
          type="button"
          onClick={() => void refresh()}
          className="mt-3 rounded-xl border border-brand-line bg-transparent px-3 py-1.5 text-sm font-bold text-brand-mute hover:text-brand-ink transition-colors"
        >
          Retry
        </button>
      </section>
    );
  }

  if (!data) {
    return (
      <section
        aria-labelledby="tier-progress-heading"
        className={`rounded-2xl border border-brand-line bg-brand-card p-6 ${className}`}
        aria-live="polite"
      >
        <h3
          id="tier-progress-heading"
          className="text-sm font-bold uppercase tracking-wide text-brand-mute"
        >
          Your tier
        </h3>
        <p className="mt-2 text-sm text-brand-mute">{busy ? 'Loading your tier…' : 'Loading…'}</p>
      </section>
    );
  }

  const current = data.current;
  const tone = current ? TIER_TONE[current.slug] : TIER_TONE.apprentice;

  return (
    <section
      aria-labelledby="tier-progress-heading"
      className={`rounded-2xl border border-brand-line bg-brand-card p-6 space-y-5 ${className}`}
    >
      <header className="flex items-start justify-between gap-4">
        <div>
          <h3
            id="tier-progress-heading"
            className="text-sm font-bold uppercase tracking-wide text-brand-mute"
          >
            Your tier
          </h3>
          <div className="mt-1 flex items-center gap-3">
            <span
              className={`inline-flex items-center rounded-full px-3 py-1 text-sm font-bold ring-1 ${tone.bg} ${tone.ring} ${tone.text}`}
            >
              {current?.name ?? 'Apprentice'}
            </span>
            <span className="text-base font-extrabold text-brand-ink">
              {current ? fmtRate(current.hourlyRateCents) : '—'}
            </span>
            {current?.leadEligible ? (
              <span className="rounded-md bg-amber-500/20 px-2 py-0.5 text-xs font-bold text-amber-200">
                Lead-eligible
              </span>
            ) : null}
          </div>
        </div>
        <button
          type="button"
          onClick={() => void refresh()}
          disabled={busy}
          className="rounded-xl border border-brand-line bg-transparent px-3 py-1.5 text-xs font-bold text-brand-mute hover:text-brand-ink transition-colors disabled:opacity-50"
        >
          {busy ? 'Refreshing…' : 'Refresh'}
        </button>
      </header>

      {data.currentGigRate ? (
        <p className="rounded-xl border border-amber-400/40 bg-amber-500/10 px-4 py-3 text-sm text-amber-100">
          <strong>Your rate this gig:</strong> {fmtDollars(data.currentGigRate.baseHourlyCents)} ×{' '}
          {data.currentGigRate.multiplier.toFixed(3)} surge ={' '}
          <strong>{fmtRate(data.currentGigRate.effectiveHourlyCents)}</strong>
          {data.currentGigRate.reasons.length > 0 ? (
            <span className="ml-1 flex flex-wrap items-center gap-1 mt-1">
              {data.currentGigRate.reasons.map((r, i) => (
                <span
                  key={r.label}
                  style={{ animationDelay: `${i * 60}ms` }}
                  className="inline-block rounded-full border border-amber-400/50 bg-amber-500/20 px-2 py-0.5 text-[11px] font-medium text-amber-200 transition-all duration-[333ms] hover:-translate-y-0.5 hover:bg-amber-500/35 hover:shadow-sm"
                >
                  {r.label}
                </span>
              ))}
            </span>
          ) : null}
        </p>
      ) : null}

      <p className="text-sm text-brand-ink leading-relaxed">{data.reasoning}</p>

      {data.next ? (
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-brand-mute">
            <span>
              Next: <strong className="text-brand-ink">{data.next.name}</strong> ·{' '}
              {fmtRate(data.next.hourlyRateCents)}
            </span>
            <span>{progressPct}%</span>
          </div>
          <div
            role="progressbar"
            aria-valuemin={0}
            aria-valuemax={100}
            aria-valuenow={progressPct}
            aria-label={`Progress to ${data.next.name} tier`}
            className="h-2 w-full overflow-hidden rounded-full bg-brand-line/40"
          >
            <div
              className="h-full bg-gradient-to-r from-sky-400 via-amber-400 to-fuchsia-400 transition-all"
              style={{ width: `${progressPct}%` }}
            />
          </div>
          {data.advice ? (
            <p className="text-xs text-brand-mute">
              <strong className="text-brand-ink">What to do next:</strong> {data.advice}
            </p>
          ) : null}
        </div>
      ) : (
        <p className="text-xs text-brand-mute">Top tier — keep setting the standard.</p>
      )}

      <ul className="grid grid-cols-2 gap-2 text-xs text-brand-mute sm:grid-cols-4">
        <li className="rounded-lg border border-brand-line px-3 py-2">
          <span className="block text-brand-ink font-bold">{data.progress.jobsCompleted}</span>
          jobs done
        </li>
        <li className="rounded-lg border border-brand-line px-3 py-2">
          <span className="block text-brand-ink font-bold">
            {data.progress.ratingAvg !== null ? data.progress.ratingAvg.toFixed(2) : '—'}
          </span>
          rating ({data.progress.ratingCount})
        </li>
        <li className="rounded-lg border border-brand-line px-3 py-2">
          <span className="block text-brand-ink font-bold">{data.progress.requestAgainCount}</span>
          request-again
        </li>
        <li className="rounded-lg border border-brand-line px-3 py-2">
          <span className="block text-brand-ink font-bold">{data.progress.skills.length}</span>
          skills listed
        </li>
      </ul>

      <details className="text-xs text-brand-mute">
        <summary className="cursor-pointer font-bold uppercase tracking-wide hover:text-brand-ink">
          Tier ladder
        </summary>
        <ul className="mt-3 space-y-1">
          {data.ladder.map((row) => (
            <li
              key={row.slug}
              className={`flex items-center justify-between rounded-md px-2 py-1 ${
                current?.slug === row.slug ? 'bg-brand-line/40 text-brand-ink' : ''
              }`}
            >
              <span className="font-bold">{row.name}</span>
              <span>
                {fmtRate(row.hourlyRateCents)}
                {row.minRating !== null ? ` · ${row.minRating.toFixed(1)}★` : ''}
                {row.minJobs > 0 ? ` · ${row.minJobs}+ jobs` : ''}
                {row.requiresCanDrive ? ' · drive' : ''}
                {row.leadEligible ? ' · lead' : ''}
              </span>
            </li>
          ))}
        </ul>
      </details>

      <p className="text-[11px] text-brand-mute">
        Last scored: {fmtTimeAgo(data.recomputedAt)}. Re-scored nightly by the AI coach.
      </p>
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
