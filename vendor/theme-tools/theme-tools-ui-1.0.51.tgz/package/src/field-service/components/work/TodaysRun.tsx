import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useEffect, useState } from 'react';
import { GigWeatherChip } from './GigWeatherChip.js';
import TapToPayButton from './TapToPayButton.js';

/**
 * Today's Run — crew dashboard panel showing the worker's gigs scheduled for
 * today, ordered by start time. Each row has time, address (truncated),
 * customer name, status pill, weather chip, deeplink to Google Maps, and a
 * "Tap to charge" jump to the global TapToPayCharge surface at /work#tap-to-pay.
 *
 * Reads the worker session cookie (no props). Filters /api/work/gigs invites
 * client-side to today's date in the worker's local timezone — the backend
 * returns all upcoming invites, but the panel scopes to today.
 */

interface GigInvite {
  id: string;
  booking_id: string;
  status: string;
  claim_id: string;
  claim_status: string;
  invited_at: string;
  start_at: string;
  service_address: string | null;
  service_zip: string | null;
  hours_estimated: number;
  worker_pay_cents_per_person: number;
  customer_notes: string | null;
}

interface GigsResponse {
  invites: GigInvite[];
  completed: unknown[];
  error?: string;
}

function isToday(iso: string): boolean {
  const d = new Date(iso);
  const now = new Date();
  return (
    d.getFullYear() === now.getFullYear() &&
    d.getMonth() === now.getMonth() &&
    d.getDate() === now.getDate()
  );
}

function fmtTime(iso: string): string {
  return new Date(iso).toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  });
}

function truncate(s: string, n: number): string {
  return s.length > n ? s.slice(0, n - 1) + '…' : s;
}

function statusColor(s: string): string {
  switch (s) {
    case 'accepted':
    case 'confirmed':
      return 'text-emerald-400 border-emerald-500/50 bg-emerald-500/5';
    case 'checked_in':
      return 'text-brand-accent border-brand-accent/50 bg-brand-accent/5';
    case 'invited':
      return 'text-amber-400 border-amber-500/50 bg-amber-500/5';
    default:
      return 'text-brand-mute border-brand-line bg-bg-elevated';
  }
}

export default function TodaysRun() {
  useThemeToolsSurface('todays-run');
  const [gigs, setGigs] = useState<GigInvite[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    void (async () => {
      try {
        const res = await fetch('/api/work/gigs', { credentials: 'include' });
        if (res.status === 401) {
          setError('Sign in to see your run.');
          return;
        }
        const json = (await res.json()) as GigsResponse;
        if (json.error) {
          setError(json.error);
          return;
        }
        const todays = (json.invites ?? [])
          .filter((g) => isToday(g.start_at))
          .sort((a, b) => a.start_at.localeCompare(b.start_at));
        setGigs(todays);
      } catch {
        setError('Network error loading today’s run.');
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) {
    return (
      <section
        className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
        aria-live="polite"
      >
        <p className="text-sm text-brand-mute">Loading today’s run…</p>
      </section>
    );
  }
  if (error) {
    return (
      <section className="rounded-2xl border border-brand-line bg-bg-elevated p-4">
        <p className="text-sm text-red-400">{error}</p>
      </section>
    );
  }

  return (
    <section
      className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
      aria-labelledby="todays-run-title"
    >
      <header className="mb-3 flex items-baseline justify-between gap-3">
        <h3
          id="todays-run-title"
          className="font-mono text-[10px] uppercase tracking-widest text-brand-accent"
        >
          Today’s run
        </h3>
        <span className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
          {gigs.length} gig{gigs.length === 1 ? '' : 's'}
        </span>
      </header>
      {gigs.length === 0 ? (
        <p className="text-sm text-brand-mute">No gigs scheduled today. Check back later.</p>
      ) : (
        <ol className="space-y-3">
          {gigs.map((g, idx) => {
            const addr = g.service_address ?? g.service_zip ?? '—';
            const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(addr)}`;
            return (
              <li key={g.id} className="rounded-xl border border-brand-line bg-bg-primary/40 p-3">
                <div className="flex items-baseline justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-mono text-[11px] text-brand-mute">
                      #{idx + 1} · {fmtTime(g.start_at)} · {g.hours_estimated}h est.
                    </p>
                    <p className="text-sm font-semibold text-brand-ink">{truncate(addr, 48)}</p>
                    <div className="mt-1">
                      <GigWeatherChip gigId={g.id} startAt={g.start_at} />
                    </div>
                    {g.customer_notes && (
                      <p className="mt-1 text-xs text-brand-mute">
                        {truncate(g.customer_notes, 80)}
                      </p>
                    )}
                  </div>
                  <span
                    className={`shrink-0 rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-widest ${statusColor(g.claim_status)}`}
                  >
                    {g.claim_status}
                  </span>
                </div>
                <div className="mt-2 flex flex-wrap gap-2">
                  <a
                    href={mapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    data-bcl-action="todays-run.open-maps"
                    className="rounded-md border border-brand-line bg-bg-primary px-3 py-1.5 text-xs text-brand-ink hover:border-brand-accent"
                  >
                    Open in Maps →
                  </a>
                  <a
                    href={`/work#tap-to-pay?bookingId=${encodeURIComponent(g.booking_id)}`}
                    data-bcl-action="todays-run.tap-to-charge"
                    className="rounded-md bg-brand-accent px-3 py-1.5 text-xs font-semibold text-black hover:brightness-110"
                  >
                    Tap to charge
                  </a>
                </div>
              </li>
            );
          })}
        </ol>
      )}
      {gigs.length > 0 && (
        <div className="mt-4 border-t border-brand-line pt-3">
          <p className="mb-2 font-mono text-[10px] uppercase tracking-widest text-brand-mute">
            Card reader
          </p>
          <TapToPayButton />
        </div>
      )}
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
