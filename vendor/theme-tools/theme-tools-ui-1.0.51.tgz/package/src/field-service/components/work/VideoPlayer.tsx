import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useMemo, useRef, useState, type CSSProperties } from 'react';

// Wave 14 — force-watch HTML5 video player.
//
// Server-authoritative: every 2s during playback the component POSTs the
// current time + session token to `/api/video/watch/heartbeat`. The worker
// validates monotonic progress, rejects forward jumps > 5s, and (on
// `/complete`) only returns `verified: true` when the watcher cleared the
// 95%-completion + max-jump + heartbeat-count gates.
//
// Client-side enforcement is layered for UX:
//   - HTML5 `controlsList` removes download / picture-in-picture / playback
//     rate controls.
//   - A custom progress bar replaces the native seek bar (read-only).
//   - `seeking` event is intercepted — any forward jump > 2s snaps back to
//     the last verified time and shows a toast.
//   - Page Visibility API pauses on tab blur.
//   - IntersectionObserver pauses when scrolled off-screen.
//   - Common keyboard shortcuts are swallowed (j/l/f/arrows) except Space.

export interface VideoPlayerProps {
  readonly videoSrc: string;
  readonly posterSrc?: string;
  readonly videoId: string;
  readonly videoKind: 'onboarding' | 'technique' | 'safety' | 'compliance';
  readonly orientation: 'landscape' | 'portrait';
  readonly autoStart?: boolean;
  readonly onComplete?: () => void;
  readonly captionLabel?: string;
}

type Phase = 'idle' | 'loading' | 'playing' | 'paused' | 'complete' | 'error';

const HEARTBEAT_INTERVAL_MS = 2_000;
const MAX_CLIENT_FORWARD_JUMP_S = 2;

function formatTime(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return '0:00';
  const total = Math.floor(seconds);
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m}:${s.toString().padStart(2, '0')}`;
}

interface ToastState {
  readonly id: number;
  readonly message: string;
}

export function VideoPlayer(props: VideoPlayerProps): JSX.Element {
  useThemeToolsSurface('video-player');
  const {
    videoSrc,
    posterSrc,
    videoId,
    videoKind,
    orientation,
    autoStart = false,
    onComplete,
    captionLabel,
  } = props;

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const sessionTokenRef = useRef<string | null>(null);
  const lastVerifiedTimeRef = useRef<number>(0);
  const heartbeatTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const completedRef = useRef<boolean>(false);

  const [phase, setPhase] = useState<Phase>('idle');
  const [duration, setDuration] = useState<number>(0);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [completionPct, setCompletionPct] = useState<number>(0);
  const [error, setError] = useState<string>('');
  const [toast, setToast] = useState<ToastState | null>(null);
  const [prefersReducedMotion, setPrefersReducedMotion] = useState<boolean>(false);

  // prefers-reduced-motion: skip the slide-in animation but keep functional
  // behavior identical.
  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return;
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    setPrefersReducedMotion(mq.matches);
    const handler = (e: MediaQueryListEvent): void => setPrefersReducedMotion(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  const showToast = useCallback((message: string): void => {
    setToast({ id: Date.now(), message });
  }, []);

  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => setToast(null), 3_500);
    return () => window.clearTimeout(id);
  }, [toast]);

  const stopHeartbeat = useCallback((): void => {
    if (heartbeatTimerRef.current) {
      clearInterval(heartbeatTimerRef.current);
      heartbeatTimerRef.current = null;
    }
  }, []);

  const heartbeat = useCallback(async (): Promise<void> => {
    const video = videoRef.current;
    const token = sessionTokenRef.current;
    if (!video || !token) return;
    if (video.paused || video.ended) return;

    try {
      const res = await fetch('/api/video/watch/heartbeat', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionToken: token,
          currentTime: video.currentTime,
          playbackRate: video.playbackRate,
        }),
      });
      const data = (await res.json()) as {
        ok: boolean;
        suspect: boolean;
        completionPct: number;
        resetTo?: number;
        reason?: string;
      };
      if (!data) return;
      setCompletionPct(Math.max(0, Math.min(1, data.completionPct ?? 0)));
      if (data.suspect && typeof data.resetTo === 'number') {
        // Server rejected: snap back + warn.
        video.currentTime = data.resetTo;
        lastVerifiedTimeRef.current = data.resetTo;
        showToast('Please watch the full video — skipping ahead is not allowed.');
      } else if (data.ok) {
        lastVerifiedTimeRef.current = video.currentTime;
      }
    } catch {
      // Network blip — heartbeats are eventually-consistent; keep playing.
    }
  }, [showToast]);

  const startHeartbeat = useCallback((): void => {
    stopHeartbeat();
    heartbeatTimerRef.current = setInterval(() => {
      void heartbeat();
    }, HEARTBEAT_INTERVAL_MS);
  }, [heartbeat, stopHeartbeat]);

  const onStart = useCallback(async (): Promise<void> => {
    const video = videoRef.current;
    if (!video) return;
    setPhase('loading');
    setError('');

    // Wait for metadata so we have a real `duration`.
    const totalSeconds = await new Promise<number>((resolve) => {
      if (video.readyState >= 1 && Number.isFinite(video.duration) && video.duration > 0) {
        resolve(video.duration);
        return;
      }
      const handler = (): void => {
        video.removeEventListener('loadedmetadata', handler);
        resolve(Number.isFinite(video.duration) ? video.duration : 0);
      };
      video.addEventListener('loadedmetadata', handler);
      // Force a load if the browser hasn't started one yet.
      try {
        video.load();
      } catch {
        /* noop */
      }
    });

    if (totalSeconds < 1) {
      setError('Video could not load. Please refresh.');
      setPhase('error');
      return;
    }
    setDuration(totalSeconds);

    try {
      const res = await fetch('/api/video/watch/start', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ videoId, videoKind, totalSeconds }),
      });
      const data = (await res.json()) as {
        ok?: boolean;
        sessionToken?: string;
        error?: string;
      };
      if (!res.ok || !data.ok || !data.sessionToken) {
        setError(
          data.error === 'unauthorized'
            ? 'Sign in to watch this video.'
            : 'Could not start verified playback.',
        );
        setPhase('error');
        return;
      }
      sessionTokenRef.current = data.sessionToken;
    } catch {
      setError('Network error — please try again.');
      setPhase('error');
      return;
    }

    try {
      await video.play();
      setPhase('playing');
      startHeartbeat();
    } catch {
      // Autoplay denied — leave the user with a paused, clickable video.
      setPhase('paused');
    }
  }, [videoId, videoKind, startHeartbeat]);

  // Auto-start when explicitly requested.
  useEffect(() => {
    if (!autoStart) return;
    if (phase !== 'idle') return;
    void onStart();
  }, [autoStart, phase, onStart]);

  // Seeking guard — server is still the authority, but blocking on the client
  // gives the user immediate feedback.
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const onSeeking = (): void => {
      if (!sessionTokenRef.current) return;
      const target = video.currentTime;
      const delta = target - lastVerifiedTimeRef.current;
      if (delta > MAX_CLIENT_FORWARD_JUMP_S) {
        video.currentTime = lastVerifiedTimeRef.current;
        showToast('Please watch the full video — skipping ahead is not allowed.');
      }
    };

    const onTimeUpdate = (): void => {
      setCurrentTime(video.currentTime);
    };

    const onPlay = (): void => {
      setPhase('playing');
      startHeartbeat();
    };
    const onPause = (): void => {
      if (!video.ended) setPhase('paused');
      stopHeartbeat();
    };
    const onEnded = async (): Promise<void> => {
      stopHeartbeat();
      const token = sessionTokenRef.current;
      if (!token || completedRef.current) return;
      try {
        const res = await fetch('/api/video/watch/complete', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ sessionToken: token }),
        });
        const data = (await res.json()) as { verified: boolean; reason?: string };
        if (data?.verified) {
          completedRef.current = true;
          setPhase('complete');
          setCompletionPct(1);
          onComplete?.();
        } else {
          setPhase('paused');
          showToast(
            data?.reason === 'below_completion_threshold'
              ? 'You need to watch at least 95% to finish.'
              : 'We could not verify this watch — please play it again.',
          );
        }
      } catch {
        showToast('Could not save your progress — please try again.');
      }
    };

    video.addEventListener('seeking', onSeeking);
    video.addEventListener('timeupdate', onTimeUpdate);
    video.addEventListener('play', onPlay);
    video.addEventListener('pause', onPause);
    video.addEventListener('ended', onEnded);

    return () => {
      video.removeEventListener('seeking', onSeeking);
      video.removeEventListener('timeupdate', onTimeUpdate);
      video.removeEventListener('play', onPlay);
      video.removeEventListener('pause', onPause);
      video.removeEventListener('ended', onEnded);
    };
  }, [onComplete, showToast, startHeartbeat, stopHeartbeat]);

  // Keyboard guard — block j/l/f and arrows on the video, allow Space.
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    const onKey = (e: KeyboardEvent): void => {
      const target = e.target as Element | null;
      if (!target || !container.contains(target)) return;
      if (e.key === ' ' || e.code === 'Space') return; // pause/play OK
      if (
        e.key === 'ArrowLeft' ||
        e.key === 'ArrowRight' ||
        e.key === 'ArrowUp' ||
        e.key === 'ArrowDown' ||
        e.key === 'j' ||
        e.key === 'J' ||
        e.key === 'l' ||
        e.key === 'L' ||
        e.key === 'f' ||
        e.key === 'F' ||
        e.key === 'Home' ||
        e.key === 'End'
      ) {
        e.preventDefault();
        e.stopPropagation();
      }
    };
    container.addEventListener('keydown', onKey, true);
    return () => container.removeEventListener('keydown', onKey, true);
  }, []);

  // Page Visibility — pause when tab is hidden.
  useEffect(() => {
    const onVis = (): void => {
      const video = videoRef.current;
      if (!video) return;
      if (document.hidden && !video.paused) {
        video.pause();
      }
    };
    document.addEventListener('visibilitychange', onVis);
    return () => document.removeEventListener('visibilitychange', onVis);
  }, []);

  // IntersectionObserver — pause when scrolled off-screen.
  useEffect(() => {
    const container = containerRef.current;
    if (!container || typeof IntersectionObserver === 'undefined') return;
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          const video = videoRef.current;
          if (!video) continue;
          if (!entry.isIntersecting && !video.paused) {
            video.pause();
          }
        }
      },
      { threshold: 0.5 },
    );
    observer.observe(container);
    return () => observer.disconnect();
  }, []);

  // Cleanup on unmount.
  useEffect(() => {
    return () => stopHeartbeat();
  }, [stopHeartbeat]);

  const aspectStyles: CSSProperties = useMemo(() => {
    if (orientation === 'portrait') {
      return {
        aspectRatio: '9 / 16',
        maxWidth: '380px',
        width: '100%',
        margin: '0 auto',
      };
    }
    return {
      aspectRatio: '16 / 9',
      maxWidth: '960px',
      width: '100%',
      margin: '0 auto',
    };
  }, [orientation]);

  const progressLabel = useMemo(() => {
    const watched = formatTime(currentTime);
    const total = formatTime(duration);
    const pct = Math.round(completionPct * 100);
    if (phase === 'complete')
      return `${total} of ${total} watched · 100% complete · ready to continue`;
    return `${watched} of ${total} watched · ${pct}% complete · keep watching to continue`;
  }, [completionPct, currentTime, duration, phase]);

  return (
    <div
      ref={containerRef}
      className="bcl-video-player"
      data-orientation={orientation}
      data-phase={phase}
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap: '12px',
        opacity: prefersReducedMotion ? 1 : undefined,
        transition: prefersReducedMotion ? 'none' : 'opacity .35s ease',
      }}
      aria-label={captionLabel ?? `Training video: ${videoId}`}
    >
      <div
        style={{
          position: 'relative',
          background: 'var(--bg-primary)',
          borderRadius: 14,
          overflow: 'hidden',
          ...aspectStyles,
        }}
      >
        <video
          ref={videoRef}
          src={videoSrc}
          poster={posterSrc}
          preload="metadata"
          playsInline
          controls
          controlsList="nodownload noremoteplayback noplaybackrate"
          disablePictureInPicture
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            display: 'block',
          }}
        >
          <track kind="captions" />
        </video>

        {phase === 'idle' ? (
          <button
            type="button"
            onClick={() => void onStart()}
            style={{
              position: 'absolute',
              inset: 0,
              border: 0,
              background: 'rgba(10,14,20,.55)',
              color: 'var(--color-heading-bright)',
              fontSize: 18,
              fontWeight: 600,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 10,
            }}
            aria-label="Start verified watch"
          >
            <span aria-hidden="true" style={{ fontSize: 28 }}>
              ▶
            </span>
            Start watching
          </button>
        ) : null}

        {phase === 'loading' ? (
          <div
            style={{
              position: 'absolute',
              inset: 0,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'var(--color-heading-bright)',
              background: 'rgba(10,14,20,.45)',
              fontSize: 14,
            }}
          >
            Starting verified playback…
          </div>
        ) : null}

        {toast ? (
          <div
            role="status"
            aria-live="polite"
            style={{
              position: 'absolute',
              left: 12,
              right: 12,
              bottom: 12,
              background: 'var(--color-accent-deep)',
              color: 'var(--color-accent-ink)',
              border: '1px solid var(--brand-accent)',
              borderRadius: 10,
              padding: '8px 12px',
              fontSize: 13,
              boxShadow: '0 4px 14px rgba(0,0,0,.3)',
            }}
          >
            {toast.message}
          </div>
        ) : null}
      </div>

      <div
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={Math.round(completionPct * 100)}
        aria-label="Watch progress"
        style={{
          position: 'relative',
          height: 6,
          background: 'var(--color-media-line)',
          borderRadius: 999,
          overflow: 'hidden',
        }}
      >
        <div
          style={{
            position: 'absolute',
            inset: 0,
            width: `${Math.round(completionPct * 100)}%`,
            background: phase === 'complete' ? 'var(--color-success-bright)' : 'var(--brand-accent)',
            transition: prefersReducedMotion ? 'none' : 'width .25s ease',
          }}
        />
      </div>

      <p
        style={{
          margin: 0,
          fontSize: 13,
          color: phase === 'complete' ? 'var(--color-success-bright)' : 'var(--color-media-mute)',
          fontVariantNumeric: 'tabular-nums',
        }}
      >
        {progressLabel}
      </p>

      {error ? (
        <p style={{ margin: 0, fontSize: 13, color: '#FF6B6B' }} role="alert">
          {error}
        </p>
      ) : null}
    </div>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
