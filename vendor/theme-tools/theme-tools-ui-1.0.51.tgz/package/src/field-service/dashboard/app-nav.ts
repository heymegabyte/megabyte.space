import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * DASHBOARD_NAV — the role-shaped sidebar for the Spartan AppShell, filtered by
 * the active view-as role (RoleService) via visibleNavItems(). Items with no
 * `roles` show for everyone; the rest gate on customer / crew / super_admin.
 * Routes mirror app.routes.ts. Keep in sync when a top-level route is added.
 */
import type { ShellNavItem } from './shared/ui-spartan';

export const DASHBOARD_NAV: ShellNavItem[] = [
  // Customer
  { label: 'Bookings', route: '/bookings', roles: ['customer'], section: 'Customer' },
  { label: 'Quotes', route: '/quotes', roles: ['customer'], section: 'Customer' },
  // Photos folded into each booking's detail (before/after + video) — no standalone tab.
  { label: 'Calendar', route: '/calendar', roles: ['customer'], section: 'Customer' },
  { label: 'Refer', route: '/refer', roles: ['customer'], section: 'Customer' },
  {
    label: 'Move protection',
    route: '/insurance',
    roles: ['customer'],
    flag: 'inventory_insurance',
    section: 'Customer',
  },
  // Crew
  { label: 'Jobs', route: '/jobs', roles: ['crew'], section: 'Crew' },
  { label: 'Crew console', route: '/crew', roles: ['crew'], section: 'Crew' },
  { label: 'Earnings', route: '/crew/earnings', roles: ['crew'], section: 'Crew' },
  // Super-admin
  { label: 'Admin', route: '/admin', roles: ['super_admin'], section: 'Operations' },
  {
    label: 'Mid-job feedback',
    route: '/ops/nps-queue',
    roles: ['super_admin'],
    flag: 'mid_job_nps',
    section: 'Operations',
  },
  {
    label: 'Photo estimates',
    route: '/admin/photo-quotes',
    roles: ['super_admin'],
    flag: 'photo_sms_intake',
    section: 'Operations',
  },
  {
    label: 'Bonded escrow',
    route: '/admin/escrow',
    roles: ['super_admin'],
    flag: 'smart_bonded_escrow',
    section: 'Operations',
  },
  {
    label: 'Weather offers',
    route: '/admin/weather-offers',
    roles: ['super_admin'],
    flag: 'weather_reschedule_agent',
    section: 'Operations',
  },
  // Dispatch calendar command center — appears once `dashboard_calendar` is
  // promoted; stays hidden in the nav while the flag is dark (route still guarded).
  {
    label: 'Dispatch',
    route: '/calendar/month',
    roles: ['super_admin'],
    flag: 'dashboard_calendar',
    section: 'Operations',
  },
  // Showcase of every wave/brilliant-ideas feature with live status + flag links
  // (the discovery surface for experimental features like /auctions + /insurance,
  // which stay out of the primary nav until their flag is promoted).
  {
    label: 'Features',
    route: '/wave-features',
    roles: ['super_admin'],
    section: 'Operations',
    badge: 'New',
  },
  { label: 'Sites', route: '/sites', roles: ['super_admin'], section: 'Operations' },
  { label: 'Logs', route: '/logs', roles: ['super_admin'], section: 'Developer' },
  { label: 'SQL', route: '/sql', roles: ['super_admin'], section: 'Developer' },
  { label: 'Snapshots', route: '/snapshots', roles: ['super_admin'], section: 'Developer' },
  // GP-08 — unified Past history. Shows for customer AND crew (super_admin sees
  // it too); appears in the nav once past_bookings_unified is promoted, stays
  // hidden while dark (route still guarded). One list, role-badged per row.
  {
    label: 'Past',
    route: '/past',
    roles: ['customer', 'crew'],
    flag: 'past_bookings_unified',
    section: 'Account',
  },
  // Shared (all roles) — GP-09 wallet appears in the nav once wallet_balance_menu
  // is promoted; the always-visible entry is the top-of-sidebar WalletButton.
  { label: 'Wallet', route: '/wallet', flag: 'wallet_balance_menu', section: 'Account' },
  {
    label: 'Integrations',
    route: '/integrations',
    roles: ['super_admin'],
    section: 'Operations',
  },
  { label: 'Billing', route: '/billing', section: 'Account' },
  { label: 'Team', route: '/team', roles: ['super_admin'], section: 'Operations' },
  { label: 'Settings', route: '/settings', section: 'Account' },
];
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'app-nav',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
