import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * Root providers — provideRouter (with view transitions + scroll restoration)
 * and provideHttpClient (with fetch + the three typed functional interceptors).
 *
 * View Transitions API enables the cinematic cross-route morph that pairs
 * with the marketing site's existing transitions.
 *
 * Wave 27-C: lazy-init Sentry + PostHog telemetry post-bootstrap so the SDK
 * chunks never block first paint. ErrorHandler routes all uncaught errors
 * through Sentry; HTTP interceptor adds breadcrumbs for every API call.
 */
import {
  ApplicationConfig,
  ErrorHandler,
  inject,
  provideAppInitializer,
  provideZonelessChangeDetection,
} from '@angular/core';
import {
  provideRouter,
  Router,
  withComponentInputBinding,
  withInMemoryScrolling,
  withViewTransitions,
} from '@angular/router';
import { provideHttpClient, withFetch, withInterceptors } from '@angular/common/http';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { appRoutes } from './app.routes';
import {
  authInterceptor,
  tenantInterceptor,
  roleInterceptor,
  telemetryInterceptor,
} from './core/http.interceptor';
import {
  TelemetryService,
  TelemetryErrorHandler,
  bindRouterTelemetry,
} from './core/telemetry.service';
import { AuthService } from './core/auth.service';

const viewTransitionFeatures = globalThis.matchMedia?.('(prefers-reduced-motion: reduce)').matches
  ? []
  : [withViewTransitions({ skipInitialTransition: true })];

export const appConfig: ApplicationConfig = {
  providers: [
    provideZonelessChangeDetection(),
    provideRouter(
      appRoutes,
      // Do not create View Transitions for reduced-motion users. Skipping an
      // already-created transition still makes Angular log rejected browser
      // promises, while omitting the feature provides the requested instant
      // navigation and avoids Chrome's "Page already revealed" race.
      ...viewTransitionFeatures,
      withComponentInputBinding(),
      withInMemoryScrolling({ scrollPositionRestoration: 'top', anchorScrolling: 'enabled' }),
    ),
    provideHttpClient(
      withFetch(),
      withInterceptors([authInterceptor, tenantInterceptor, roleInterceptor, telemetryInterceptor]),
    ),
    provideAnimationsAsync(),
    { provide: ErrorHandler, useClass: TelemetryErrorHandler },
    // AWAITED — hydrate whoami before the router's initial canMatch runs. The
    // role guards (requireSuperAdmin / requireRole) read RoleService.isSuperAdmin
    // synchronously; without pre-hydration a hard deep-load / refresh / new-tab on
    // a super_admin route (/logs, /sql, /team, /integrations, /snapshots, /crew)
    // saw the empty default and bounced to home. Blocking here resolves the role
    // before any route activates. See core/role.guard.spec.ts.
    provideAppInitializer(() => inject(AuthService).hydrate()),
    provideAppInitializer(() => {
      const telemetry = inject(TelemetryService);
      const router = inject(Router);
      // Fire-and-forget — telemetry boot must never block route activation.
      void telemetry.boot().then(() => bindRouterTelemetry(router, telemetry));
    }),
  ],
};
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'app-config',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
