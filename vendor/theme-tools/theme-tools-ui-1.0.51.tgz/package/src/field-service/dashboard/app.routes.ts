import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * Top-level lazy routes for the unified dashboard.
 *
 * Every feature owns its own `<feature>.routes.ts` so we can defer
 * loading and split bundles. Role gating happens via canMatch +
 * requireRole / requireSuperAdmin from core/role.guard.ts.
 */
import { Route } from '@angular/router';
import { requireRole, requireSuperAdmin } from './core/role.guard';
import { featureFlagGuard } from './core/feature-flag-guard';

export const appRoutes: Route[] = [
  // Login is UNIFIED on the React `/login` page (Google + GitHub + magic-email,
  // one screen for customers/crew/operators). The Angular login surface is
  // retired: this route redirects to the canonical React page (preserving
  // ?next=/?as=). The retired Angular login component has been removed so the
  // canonical React page is the single sign-in surface for every persona.
  {
    path: 'login',
    loadComponent: () =>
      import('./features/auth/login-redirect.component').then((m) => m.LoginRedirectComponent),
  },
  {
    path: '',
    pathMatch: 'full',
    loadComponent: () => import('./features/home/home.component').then((m) => m.HomeComponent),
  },
  // Wave 31 — unified showcase. Super-admin sees every wave feature
  // shipped to the worker with live status + UI links + probe button.
  {
    path: 'wave-features',
    loadComponent: () =>
      import('./features/wave-features-hub/wave-features-hub.component').then(
        (m) => m.WaveFeaturesHubComponent,
      ),
    canMatch: [requireSuperAdmin],
  },
  // Wave 31 — Mid-job NPS dispatcher queue.
  {
    path: 'ops/nps-queue',
    loadComponent: () =>
      import('./features/nps-queue/nps-queue.component').then((m) => m.NpsQueueComponent),
    canMatch: [requireSuperAdmin],
    canActivate: [featureFlagGuard('mid_job_nps')],
  },
  // Wave 31 — Reverse-auction marketplace. Visible to all personas; the
  // component itself switches surface per role.
  {
    path: 'auctions',
    canActivate: [featureFlagGuard('reverse_auction')],
    loadComponent: () =>
      import('./features/reverse-auction/auctions-list.component').then(
        (m) => m.AuctionsListComponent,
      ),
  },
  // Wave 31 — Inventory insurance customer flow.
  {
    path: 'insurance',
    canMatch: [requireRole('customer')],
    canActivate: [featureFlagGuard('inventory_insurance')],
    loadComponent: () =>
      import('./features/insurance/insurance.component').then((m) => m.InsuranceComponent),
  },
  // Customer surfaces ported from React /me — calendar, photos, refer.
  {
    path: 'calendar',
    loadComponent: () =>
      import('./features/calendar/calendar.component').then((m) => m.CalendarComponent),
  },
  // Dispatch calendar command center (flag: dashboard_calendar). Month + week +
  // day + schedule views are all built over real /api/admin/bookings.
  {
    path: 'calendar/month',
    canMatch: [requireSuperAdmin],
    canActivate: [featureFlagGuard('dashboard_calendar')],
    loadComponent: () =>
      import('./features/calendar/dispatch-calendar.component').then(
        (m) => m.DispatchCalendarComponent,
      ),
  },
  {
    path: 'calendar/week',
    canMatch: [requireSuperAdmin],
    canActivate: [featureFlagGuard('dashboard_calendar')],
    loadComponent: () =>
      import('./features/calendar/week-view.component').then((m) => m.WeekViewComponent),
  },
  {
    path: 'calendar/day',
    canMatch: [requireSuperAdmin],
    canActivate: [featureFlagGuard('dashboard_calendar')],
    loadComponent: () =>
      import('./features/calendar/day-view.component').then((m) => m.DayViewComponent),
  },
  {
    path: 'calendar/schedule',
    canMatch: [requireSuperAdmin],
    canActivate: [featureFlagGuard('dashboard_calendar')],
    loadComponent: () =>
      import('./features/calendar/schedule-view.component').then((m) => m.ScheduleViewComponent),
  },
  {
    path: 'calendar/settings',
    canMatch: [requireSuperAdmin],
    canActivate: [featureFlagGuard('dashboard_calendar')],
    loadComponent: () =>
      import('./features/calendar/calendar-settings.component').then(
        (m) => m.CalendarSettingsComponent,
      ),
  },
  // Photos are now shown per-booking on the booking detail (before/after + video).
  // Redirect the retired standalone archive so old links/bookmarks don't 404.
  { path: 'photos', redirectTo: 'bookings', pathMatch: 'full' },
  {
    // Persona router: crew → crew-refers-crew bonus ($100 / 5 gigs), else →
    // neighbor referral ($25 off). /work/refer 308-redirects here for crew.
    path: 'refer',
    loadComponent: () =>
      import('./features/refer/refer-switch.component').then((m) => m.ReferSwitchComponent),
  },
  // Notification center — standalone full-history inbox (filter / mark-read /
  // mark-unread / archive / deep-link). Open to every persona; the feed
  // endpoint self-scopes per session and is guest-safe.
  {
    path: 'notifications',
    loadChildren: () =>
      import('./features/notifications/notification-center.routes').then(
        (m) => m.NOTIFICATIONS_ROUTES,
      ),
  },
  {
    path: 'bookings',
    loadChildren: () =>
      import('./features/bookings/bookings.routes').then((m) => m.BOOKINGS_ROUTES),
    canMatch: [requireRole('customer')],
  },
  {
    path: 'quotes',
    loadChildren: () => import('./features/quotes/quotes.routes').then((m) => m.QUOTES_ROUTES),
    canMatch: [requireRole('customer')],
  },
  {
    path: 'jobs',
    loadChildren: () => import('./features/jobs/jobs.routes').then((m) => m.JOBS_ROUTES),
    canMatch: [requireRole('crew')],
  },
  // GP-08 — unified Past history (flag: past_bookings_unified). ONE reverse-chron
  // list interweaving the caller's past customer-bookings + gigs they worked as
  // crew, each row badged "as Customer" / "as Crew". Open to customer OR crew
  // (super_admin via View-As); the route + service self-scope. Dark by default:
  // featureFlagGuard redirects /dashboard/past to '/' until the flag is promoted.
  {
    path: 'past',
    loadChildren: () =>
      import('./features/past-bookings/past-bookings.routes').then((m) => m.PAST_BOOKINGS_ROUTES),
  },
  // Crew console index — bare /crew renders the control center for crew AND
  // super_admin. `pathMatch:'full'` so /crew/earnings + /crew/wellness still
  // fall through to their flag-gated groups below. Without this explicit index
  // the wave27 group's `path:'crew'` matched bare /crew but exposed no index
  // child → a blank outlet (caught 2026-06-10 by the live visual audit). The
  // CrewComponent self-gates: crew persona → console, others → switch-persona
  // empty state. Pairs with the deep-load fix in core/role.guard.spec.ts.
  {
    path: 'crew',
    pathMatch: 'full',
    loadComponent: () => import('./features/crew/crew.component').then((m) => m.CrewComponent),
    canMatch: [requireRole('crew')],
  },
  // Wave 27 crew earnings + payout + hours-coach + tier-ladder. Each child
  // route is flag-gated via featureFlagGuard().
  {
    path: 'crew',
    loadChildren: () => import('./features/crew/earnings.routes').then((m) => m.CREW_WAVE27_ROUTES),
    canMatch: [requireRole('crew')],
  },
  // Wave 28 — /crew/wellness (#56-60). Single screen; component reads each
  // owning flag and renders sub-cards conditionally.
  {
    path: 'crew',
    loadChildren: () =>
      import('./features/crew/wellness.routes').then((m) => m.CREW_WELLNESS_ROUTES),
    canMatch: [requireRole('crew')],
  },
  {
    path: 'sites',
    loadChildren: () => import('./features/sites/sites.routes').then((m) => m.SITES_ROUTES),
  },
  {
    path: 'logs',
    loadChildren: () => import('./features/logs/logs.routes').then((m) => m.LOGS_ROUTES),
    canMatch: [requireSuperAdmin],
  },
  {
    path: 'snapshots',
    loadChildren: () =>
      import('./features/snapshots/snapshots.routes').then((m) => m.SNAPSHOTS_ROUTES),
    canMatch: [requireSuperAdmin],
  },
  {
    path: 'sql',
    loadChildren: () => import('./features/sql/sql.routes').then((m) => m.SQL_ROUTES),
    canMatch: [requireSuperAdmin],
  },
  {
    path: 'integrations',
    loadChildren: () =>
      import('./features/integrations/integrations.routes').then((m) => m.INTEGRATIONS_ROUTES),
    canMatch: [requireSuperAdmin],
  },
  {
    path: 'billing',
    loadChildren: () => import('./features/billing/billing.routes').then((m) => m.BILLING_ROUTES),
  },
  {
    path: 'team',
    loadChildren: () => import('./features/team/team.routes').then((m) => m.TEAM_ROUTES),
    canMatch: [requireSuperAdmin],
  },
  {
    path: 'settings',
    loadChildren: () =>
      import('./features/settings/settings.routes').then((m) => m.SETTINGS_ROUTES),
  },
  // GP-09 wallet — balance + cash-out (crew) / add-money (customer). Open to
  // every persona; the page switches surface by role. Route guarded by
  // featureFlagGuard('wallet_balance_menu') — dark by default.
  {
    path: 'wallet',
    loadChildren: () => import('./features/wallet/wallet.routes').then((m) => m.WALLET_ROUTES),
  },
  {
    path: 'admin',
    loadChildren: () => import('./features/admin/admin.routes').then((m) => m.ADMIN_ROUTES),
    canMatch: [requireSuperAdmin],
  },
  { path: '**', redirectTo: '' },
];
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'app-routes',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
