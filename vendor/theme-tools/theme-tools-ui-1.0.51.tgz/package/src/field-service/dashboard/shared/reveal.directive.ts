import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * BclRevealDirective (`[bclReveal]`) — subtle first-paint enter motion: fade + an
 * 8px rise via the Web Animations API. Mirrors the cinematic-ui-patterns `appReveal`
 * contract for the dashboard (which had no motion primitive).
 *
 * - `prefers-reduced-motion: reduce` → no animation; the element stays at its final
 *   visible state (never hides content from reduced-motion users).
 * - SSR/test-safe: only animates when `Element.animate` exists; otherwise no-op.
 * - Optional stagger: a module-scoped counter delays successive reveals by `revealStep`
 *   ms (document order), so a grid of cards cascades. Override per-host with `revealDelay`.
 *
 * Pure helper `revealDelayMs` is unit-tested in reveal.directive.spec.ts.
 */
import { Directive, ElementRef, inject, input, OnInit } from '@angular/core';

let revealOrder = 0;

/** Pure: total enter delay = base order-stagger (capped) + explicit per-host delay. */
export function revealDelayMs(order: number, step: number, explicit: number): number {
  const staggered = Math.min(Math.max(0, order), 12) * Math.max(0, step);
  return staggered + Math.max(0, explicit);
}

@Directive({
  selector: '[bclReveal]',
  standalone: true,
})
export class BclRevealDirective implements OnInit {
  private readonly el = inject(ElementRef<HTMLElement>);

  /** Extra delay (ms) on top of the automatic document-order stagger. */
  readonly revealDelay = input<number>(0);
  /** Per-card stagger step (ms) applied by document order. */
  readonly revealStep = input<number>(70);

  ngOnInit(): void {
    const node = this.el.nativeElement;
    const reduce =
      typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce || typeof node.animate !== 'function') {
      return; // final visible state; no motion
    }
    const delay = revealDelayMs(revealOrder++, this.revealStep(), this.revealDelay());
    node.animate(
      [
        { opacity: 0, transform: 'translateY(8px)' },
        { opacity: 1, transform: 'translateY(0)' },
      ],
      { duration: 480, delay, easing: 'cubic-bezier(0.16, 1, 0.3, 1)', fill: 'both' },
    );
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'reveal-directive',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
