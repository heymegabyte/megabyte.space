import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * hlm-badge — status/label pill (vendored helm). cva variants themed by HLM
 * vars. Used for claim status, role badges, flag stages, etc.
 * Usage: <span hlmBadge variant="default|secondary|destructive|outline">…</span>
 */
import { Directive, computed, input } from '@angular/core';
import { cva, type VariantProps } from 'class-variance-authority';
import { HLM_BADGE_CVA_BASE, HLM_BADGE_CVA_VARIANTS } from '@theme-tools/ui/spartan-helm-variants';
import { cn } from '../utils/cn';

export const badgeVariants = cva(HLM_BADGE_CVA_BASE, {
  variants: HLM_BADGE_CVA_VARIANTS,
  defaultVariants: { variant: 'default' },
});

export type BadgeVariant = VariantProps<typeof badgeVariants>['variant'];

@Directive({
  selector: '[hlmBadge]',
  standalone: true,
  host: { '[class]': '_computedClass()' },
})
export class HlmBadge {
  readonly variant = input<BadgeVariant>('default');
  readonly userClass = input<string>('', { alias: 'class' });
  protected readonly _computedClass = computed(() =>
    cn(badgeVariants({ variant: this.variant() }), this.userClass()),
  );
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'hlm-badge',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
