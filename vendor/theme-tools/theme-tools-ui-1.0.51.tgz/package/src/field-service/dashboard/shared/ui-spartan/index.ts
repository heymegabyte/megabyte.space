import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * ui-spartan — the Spartan-UI design-system layer for the dashboard.
 * Vendored helm primitives (copy-in-source) composed on @spartan-ng/brain +
 * cva + the HLM theme bridge in styles.css. Grows one primitive per Wave-1
 * pass; feature waves import from here only (never hand-rolled UI).
 */
export { cn, hlm } from './utils/cn';
export { HlmButton, buttonVariants, type ButtonVariant, type ButtonSize } from './button/hlm-button';
export {
  HlmCard,
  HlmCardHeader,
  HlmCardTitle,
  HlmCardDescription,
  HlmCardContent,
  HlmCardFooter,
  HlmCardImports,
} from './card/hlm-card';
export { HlmBadge, badgeVariants, type BadgeVariant } from './badge/hlm-badge';
export { HlmInput } from './input/hlm-input';
export { HlmSwitch } from './switch/hlm-switch.component';
export { HlmLabel } from './label/hlm-label';
export { HlmSkeleton } from './skeleton/hlm-skeleton';
export { StateBlockComponent, type SurfaceState } from './state/state-block.component';
export {
  HlmTable,
  HlmTHead,
  HlmTBody,
  HlmTr,
  HlmTh,
  HlmTd,
  HlmTableImports,
} from './table/hlm-table';
export { SmartTableComponent, nextSorting } from './table/smart-table.component';
export { HlmFormField } from './form-field/hlm-form-field.component';
export { HlmSeparator } from './misc/hlm-separator';
export { HlmSpinner } from './misc/hlm-spinner.component';
export { ToastService, type Toast, type ToastVariant } from './toast/toast.service';
export { HlmToastHost } from './toast/toast-host.component';
export { HlmDialog } from './dialog/hlm-dialog.component';
export { ConfirmDialog } from './dialog/confirm-dialog.component';
export {
  CommandPaletteComponent,
  filterCommands,
  type PaletteCommand,
} from './command/command-palette.component';
export {
  AppShellComponent,
  visibleNavItems,
  type ShellNavItem,
} from './shell/app-shell.component';
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'index',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
