import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * hlm-table — styled table primitives (vendored helm). Visual layer for the
 * SmartTable; themed by HLM border/muted vars. Plain directives so they work
 * on native <table>/<thead>/<tr>/<th>/<td> with zero markup ceremony.
 */
import { Directive, computed, input } from '@angular/core';
import { cn } from '../utils/cn';

@Directive({ selector: '[hlmTable]', standalone: true, host: { '[class]': '_c()' } })
export class HlmTable {
  readonly userClass = input<string>('', { alias: 'class' });
  protected readonly _c = computed(() => cn('w-full caption-bottom text-sm', this.userClass()));
}

@Directive({ selector: '[hlmTHead]', standalone: true, host: { '[class]': '_c()' } })
export class HlmTHead {
  readonly userClass = input<string>('', { alias: 'class' });
  protected readonly _c = computed(() => cn('[&_tr]:border-b', this.userClass()));
}

@Directive({ selector: '[hlmTBody]', standalone: true, host: { '[class]': '_c()' } })
export class HlmTBody {
  readonly userClass = input<string>('', { alias: 'class' });
  protected readonly _c = computed(() => cn('[&_tr:last-child]:border-0', this.userClass()));
}

@Directive({ selector: '[hlmTr]', standalone: true, host: { '[class]': '_c()' } })
export class HlmTr {
  readonly userClass = input<string>('', { alias: 'class' });
  protected readonly _c = computed(() =>
    cn(
      'border-b border-border transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted',
      this.userClass(),
    ),
  );
}

@Directive({ selector: '[hlmTh]', standalone: true, host: { '[class]': '_c()' } })
export class HlmTh {
  readonly userClass = input<string>('', { alias: 'class' });
  protected readonly _c = computed(() =>
    cn(
      'h-11 px-3 text-left align-middle text-xs font-semibold uppercase tracking-wide text-muted-foreground [&:has([role=checkbox])]:pr-0',
      this.userClass(),
    ),
  );
}

@Directive({ selector: '[hlmTd]', standalone: true, host: { '[class]': '_c()' } })
export class HlmTd {
  readonly userClass = input<string>('', { alias: 'class' });
  protected readonly _c = computed(() =>
    cn('px-3 py-3 align-middle text-foreground tabular-nums [&:has([role=checkbox])]:pr-0', this.userClass()),
  );
}

export const HlmTableImports = [HlmTable, HlmTHead, HlmTBody, HlmTr, HlmTh, HlmTd] as const;
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'hlm-table',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
