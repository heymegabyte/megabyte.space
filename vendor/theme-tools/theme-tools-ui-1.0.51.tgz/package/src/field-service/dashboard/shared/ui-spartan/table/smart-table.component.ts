import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * SmartTableComponent — generic, signal-driven data table on TanStack's
 * headless engine (per package-preference-registry: TanStack Table for grids).
 * Client-side sorting (getSortedRowModel) + optional global filter
 * (getFilteredRowModel). Rows are optionally activatable (click / Enter / Space
 * → rowActivate) for master-detail surfaces. Cells + headers render through
 * FlexRender so columns supply plain text or a render fn. Styled by HlmTable.
 *
 * Usage:
 *   <app-smart-table [data]="rows()" [columns]="cols"
 *      [filterable]="true" filterPlaceholder="Filter…" (rowActivate)="open($event)" />
 * where `cols` are TanStack ColumnDef<T>[] (accessorKey + header + optional cell).
 */
import { ChangeDetectionStrategy, Component, input, output, signal } from '@angular/core';
import {
  type ColumnDef,
  type SortDirection,
  type SortingState,
  FlexRenderDirective,
  createAngularTable,
  getCoreRowModel,
  getFilteredRowModel,
  getSortedRowModel,
} from '@tanstack/angular-table';
import { HlmTableImports } from './hlm-table';
import { HlmInput } from '../input/hlm-input';
import { HlmSkeleton } from '../skeleton/hlm-skeleton';

/** Pure sort-state cycle for a column: none → asc → desc → none. Unit-tested. */
export function nextSorting(current: SortingState, columnId: string): SortingState {
  const existing = current.find((s) => s.id === columnId);
  if (!existing) return [{ id: columnId, desc: false }];
  if (!existing.desc) return [{ id: columnId, desc: true }];
  return []; // was desc → clear
}

@Component({
  selector: 'app-smart-table',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [...HlmTableImports, FlexRenderDirective, HlmInput, HlmSkeleton],
  template: `
    @if (loading()) {
      <div class="flex flex-col gap-2" data-testid="smart-table-loading" aria-busy="true">
        @for (r of [0, 1, 2, 3, 4]; track r) {
          <div hlmSkeleton class="h-11 w-full"></div>
        }
      </div>
    } @else {
      @if (filterable()) {
        <div class="mb-3">
          <input
            hlmInput
            type="search"
            [value]="globalFilter()"
            (input)="globalFilter.set(asValue($event))"
            [placeholder]="filterPlaceholder()"
            data-testid="smart-table-filter"
            aria-label="Filter rows"
            class="max-w-xs"
          />
        </div>
      }
      <div class="overflow-x-auto rounded-xl border border-border">
        <table hlmTable data-testid="smart-table">
          <thead hlmTHead>
            @for (hg of table.getHeaderGroups(); track hg.id) {
              <tr hlmTr>
                @for (header of hg.headers; track header.id) {
                  <th hlmTh [attr.aria-sort]="header.column.getCanSort() ? ariaSort(header.column.getIsSorted()) : null">
                    @if (header.column.getCanSort()) {
                      <!-- APG sortable-column pattern: a real <button> makes the sort keyboard-operable
                           (Tab to focus, Enter/Space to sort — native button semantics), while the <th>
                           keeps its columnheader role + aria-sort. Headers were click-only before (WCAG 2.1.1). -->
                      <button
                        type="button"
                        data-testid="smart-table-sort"
                        class="group inline-flex w-full cursor-pointer select-none items-center gap-1 rounded-sm text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1"
                        (click)="onSort(header.column.id, true)"
                      >
                        <ng-container *flexRender="header.column.columnDef.header; props: header.getContext(); let h">
                          {{ h }}
                        </ng-container>
                        @if (header.column.getIsSorted() === 'asc') {<span aria-hidden="true">▲</span>}
                        @if (header.column.getIsSorted() === 'desc') {<span aria-hidden="true">▼</span>}
                      </button>
                    } @else {
                      <span class="inline-flex items-center gap-1">
                        <ng-container *flexRender="header.column.columnDef.header; props: header.getContext(); let h">
                          {{ h }}
                        </ng-container>
                      </span>
                    }
                  </th>
                }
              </tr>
            }
          </thead>
          <tbody hlmTBody>
            @for (row of table.getRowModel().rows; track row.id) {
              <tr
                hlmTr
                [class.cursor-pointer]="activatable()"
                [attr.role]="activatable() ? 'button' : null"
                [attr.tabindex]="activatable() ? 0 : null"
                (click)="activate(row.original)"
                (keydown.enter)="activate(row.original)"
                (keydown.space)="onSpace($event, row.original)"
              >
                @for (cell of row.getVisibleCells(); track cell.id) {
                  <td hlmTd>
                    <ng-container *flexRender="cell.column.columnDef.cell; props: cell.getContext(); let c">
                      {{ c }}
                    </ng-container>
                  </td>
                }
              </tr>
            }
            @if (table.getRowModel().rows.length === 0) {
              <tr hlmTr>
                <td hlmTd [attr.colspan]="columns().length" class="py-8 text-center text-sm text-muted-foreground">
                  {{ globalFilter() ? 'No rows match your filter.' : emptyText() }}
                </td>
              </tr>
            }
          </tbody>
        </table>
      </div>
    }
  `,
})
export class SmartTableComponent<T> {
  readonly data = input<T[]>([]);
  readonly columns = input<ColumnDef<T>[]>([]);
  readonly loading = input<boolean>(false);
  readonly filterable = input<boolean>(false);
  readonly filterPlaceholder = input<string>('Filter…');
  readonly emptyText = input<string>('No rows.');
  /** When a consumer subscribes to rowActivate, rows become clickable. */
  readonly rowActivate = output<T>();

  protected readonly sorting = signal<SortingState>([]);
  protected readonly globalFilter = signal<string>('');
  /** Rows are interactive (clickable → rowActivate) unless disabled by the parent. */
  readonly activatable = input<boolean>(true, { alias: 'rowsActivatable' });

  protected readonly table = createAngularTable(() => ({
    data: this.data(),
    columns: this.columns(),
    state: { sorting: this.sorting(), globalFilter: this.globalFilter() },
    onSortingChange: (updater) =>
      this.sorting.set(typeof updater === 'function' ? updater(this.sorting()) : updater),
    onGlobalFilterChange: (updater) =>
      this.globalFilter.set(typeof updater === 'function' ? updater(this.globalFilter()) : updater),
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
  }));

  protected asValue(ev: Event): string {
    return (ev.target as HTMLInputElement).value;
  }

  protected onSort(columnId: string, canSort: boolean): void {
    if (!canSort) return;
    this.sorting.set(nextSorting(this.sorting(), columnId));
  }

  protected activate(row: T): void {
    if (this.activatable()) this.rowActivate.emit(row);
  }

  protected onSpace(ev: Event, row: T): void {
    ev.preventDefault(); // stop page scroll on Space-activate
    this.activate(row);
  }

  protected ariaSort(dir: false | SortDirection): 'ascending' | 'descending' | 'none' {
    return dir === 'asc' ? 'ascending' : dir === 'desc' ? 'descending' : 'none';
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'smart-table-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
