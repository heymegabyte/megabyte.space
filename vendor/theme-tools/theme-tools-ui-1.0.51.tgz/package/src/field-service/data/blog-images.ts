const data: Record<string, { slug: string; images: Array<{ src: string; alt: string; photographer: string; photographerUrl: string; source: string; query: string; width: number; height: number; webp?: string; avif?: string }> } | undefined> = {
  "newark-power-washing-free-sample-work": {
    "slug": "newark-power-washing-free-sample-work",
    "images": [
      {
        "src": "/guides/power-washing/surface-cleaner.jpg",
        "alt": "Brick Labor technician executing a free 4-square-foot power washing test patch on a Newark masonry facade and concrete driveway",
        "photographer": "Brick Labor Newark Field Crew",
        "photographerUrl": "https://bricklabor.com/book",
        "source": "Brick Labor Field Archive",
        "query": "power washing Newark New Jersey free sample test patch",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/guides/power-washing/machine-gas.jpg",
        "alt": "Commercial 4,000 PSI / 4.0 GPM belt-drive pressure washer and EPA Safer Choice surfactant calibration in Newark NJ",
        "photographer": "Brick Labor Newark Field Crew",
        "photographerUrl": "https://bricklabor.com/book",
        "source": "Brick Labor Field Archive",
        "query": "power washing Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/cities/newark/3.jpg",
        "alt": "Branch Brook Park Cherry Blossom Esplanade and Forest Hill residential corridor in Newark, New Jersey",
        "photographer": "Jim.henderson",
        "photographerUrl": "https://commons.wikimedia.org/wiki/File:2nd_River_BBP_sakura_photog_jeh.jpg",
        "source": "Wikimedia Commons",
        "query": "Newark New Jersey Branch Brook Park",
        "width": 1400,
        "height": 900
      }
    ]
  },
  "fifty-dollar-hour-per-person-philosophy": {
    "slug": "fifty-dollar-hour-per-person-philosophy",
    "images": [
      {
        "src": "/blog-images/fifty-dollar-hour-per-person-philosophy/1.jpg",
        "alt": "From above of blue jeans with retail price and size label placed on white table",
        "photographer": "Atlantic Ambience",
        "photographerUrl": "https://www.pexels.com/@freestockpro",
        "source": "pexels",
        "query": "pricing Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/fifty-dollar-hour-per-person-philosophy/2.jpg",
        "alt": "Breathtaking view of the New York City skyline captured from across the river.",
        "photographer": "Andres Figueroa",
        "photographerUrl": "https://www.pexels.com/@andres-figueroa-3326883",
        "source": "pexels",
        "query": "pricing Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/fifty-dollar-hour-per-person-philosophy/3.jpg",
        "alt": "Dramatic black and white photo of Jersey City's distinctive skyline on a clear day.",
        "photographer": "LaMont L. Johnson",
        "photographerUrl": "https://www.pexels.com/@lamont-l-johnson-710717269",
        "source": "pexels",
        "query": "pricing Newark New Jersey",
        "width": 1400,
        "height": 900
      }
    ]
  },
  "casual-labor-vs-licensed-contractor": {
    "slug": "casual-labor-vs-licensed-contractor",
    "images": [
      {
        "src": "/blog-images/casual-labor-vs-licensed-contractor/1.jpg",
        "alt": "brown concrete building near trees during daytime",
        "photographer": "Robert Thiemann",
        "photographerUrl": "https://unsplash.com/@rthiemann",
        "source": "unsplash",
        "query": "how-to Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/casual-labor-vs-licensed-contractor/2.jpg",
        "alt": "body of water near trees and buildings during daytime",
        "photographer": "Robert Thiemann",
        "photographerUrl": "https://unsplash.com/@rthiemann",
        "source": "unsplash",
        "query": "how-to Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/casual-labor-vs-licensed-contractor/3.jpg",
        "alt": "train station with people walking",
        "photographer": "Saul Mercado",
        "photographerUrl": "https://unsplash.com/@mercadomuses",
        "source": "unsplash",
        "query": "how-to Newark New Jersey",
        "width": 1400,
        "height": 900
      }
    ]
  },
  "evenings-and-weekends-newark-property-crew": {
    "slug": "evenings-and-weekends-newark-property-crew",
    "images": [
      {
        "src": "/blog-images/evenings-and-weekends-newark-property-crew/1.jpg",
        "alt": "brown concrete building near trees during daytime",
        "photographer": "Robert Thiemann",
        "photographerUrl": "https://unsplash.com/@rthiemann",
        "source": "unsplash",
        "query": "how-to Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/evenings-and-weekends-newark-property-crew/2.jpg",
        "alt": "body of water near trees and buildings during daytime",
        "photographer": "Robert Thiemann",
        "photographerUrl": "https://unsplash.com/@rthiemann",
        "source": "unsplash",
        "query": "how-to Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/evenings-and-weekends-newark-property-crew/3.jpg",
        "alt": "train station with people walking",
        "photographer": "Saul Mercado",
        "photographerUrl": "https://unsplash.com/@mercadomuses",
        "source": "unsplash",
        "query": "how-to Newark New Jersey",
        "width": 1400,
        "height": 900
      }
    ]
  },
  "lawn-mowing-pricing-newark": {
    "slug": "lawn-mowing-pricing-newark",
    "images": [
      {
        "src": "/blog-images/lawn-mowing-pricing-newark/1.jpg",
        "alt": "Exterior of contemporary residential house with glass doors and panoramic windows near green lawn with paved paths on sunny day in summer",
        "photographer": "Max Vakhtbovych",
        "photographerUrl": "https://www.pexels.com/@artbovich",
        "source": "pexels",
        "query": "lawn care Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/lawn-mowing-pricing-newark/2.jpg",
        "alt": "Close-up of a grass trimmer cutting lawn with grass clippings flying.",
        "photographer": "Pascal Küffer",
        "photographerUrl": "https://www.pexels.com/@pascal-kuffer-190126462",
        "source": "pexels",
        "query": "lawn care Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/lawn-mowing-pricing-newark/3.jpg",
        "alt": "Close-up of a grass cutter trimming green grass with flying clippings outdoors.",
        "photographer": "Pascal Küffer",
        "photographerUrl": "https://www.pexels.com/@pascal-kuffer-190126462",
        "source": "pexels",
        "query": "lawn care Newark New Jersey",
        "width": 1400,
        "height": 900
      }
    ]
  },
  "gutter-cleaning-newark": {
    "slug": "gutter-cleaning-newark",
    "images": [
      {
        "src": "/blog-images/gutter-cleaning-newark/1.jpg",
        "alt": "Technician repairing an air conditioner unit in New Delhi workshop.",
        "photographer": "Multitech Institute",
        "photographerUrl": "https://www.pexels.com/@multitech-institute-2155038539",
        "source": "pexels",
        "query": "repairs Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/gutter-cleaning-newark/2.jpg",
        "alt": "Stunning aerial shot of the USS New Jersey battleship docked in Philadelphia, Pennsylvania.",
        "photographer": "K",
        "photographerUrl": "https://www.pexels.com/@kelly",
        "source": "pexels",
        "query": "repairs Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/gutter-cleaning-newark/3.jpg",
        "alt": "Close-up of disassembled smartphone parts on a blue repair mat with tools.",
        "photographer": "Fotografia Lui Vlad",
        "photographerUrl": "https://www.pexels.com/@fotografia-lui-vlad-1445510816",
        "source": "pexels",
        "query": "repairs Newark New Jersey",
        "width": 1400,
        "height": 900
      }
    ]
  },
  "appliance-haul-away-newark": {
    "slug": "appliance-haul-away-newark",
    "images": [
      {
        "src": "/blog-images/appliance-haul-away-newark/1.jpg",
        "alt": "body of water near trees and buildings during daytime",
        "photographer": "Robert Thiemann",
        "photographerUrl": "https://unsplash.com/@rthiemann",
        "source": "unsplash",
        "query": "hauling Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/appliance-haul-away-newark/2.jpg",
        "alt": "City street with buildings and lamp post.",
        "photographer": "Michael Moloney",
        "photographerUrl": "https://unsplash.com/@mjmolo",
        "source": "unsplash",
        "query": "hauling Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/appliance-haul-away-newark/3.jpg",
        "alt": "A white construction truck loaded with building materials and equipment parked by a building.",
        "photographer": "Mathias Reding",
        "photographerUrl": "https://www.pexels.com/@matreding",
        "source": "pexels",
        "query": "hauling Newark New Jersey",
        "width": 1400,
        "height": 900
      }
    ]
  },
  "snow-shoveling-newark-on-call": {
    "slug": "snow-shoveling-newark-on-call",
    "images": [
      {
        "src": "/blog-images/snow-shoveling-newark-on-call/1.jpg",
        "alt": "body of water near trees and buildings during daytime",
        "photographer": "Robert Thiemann",
        "photographerUrl": "https://unsplash.com/@rthiemann",
        "source": "unsplash",
        "query": "seasonal Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/snow-shoveling-newark-on-call/2.jpg",
        "alt": "white labeled card on wooden surface",
        "photographer": "Mockaroon",
        "photographerUrl": "https://unsplash.com/@mockaroon",
        "source": "unsplash",
        "query": "seasonal Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/snow-shoveling-newark-on-call/3.jpg",
        "alt": "brown concrete building near trees during daytime",
        "photographer": "Robert Thiemann",
        "photographerUrl": "https://unsplash.com/@rthiemann",
        "source": "unsplash",
        "query": "seasonal Newark New Jersey",
        "width": 1400,
        "height": 900
      }
    ]
  },
  "spring-property-prep-newark": {
    "slug": "spring-property-prep-newark",
    "images": [
      {
        "src": "/blog-images/spring-property-prep-newark/1.jpg",
        "alt": "body of water near trees and buildings during daytime",
        "photographer": "Robert Thiemann",
        "photographerUrl": "https://unsplash.com/@rthiemann",
        "source": "unsplash",
        "query": "seasonal Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/spring-property-prep-newark/2.jpg",
        "alt": "white labeled card on wooden surface",
        "photographer": "Mockaroon",
        "photographerUrl": "https://unsplash.com/@mockaroon",
        "source": "unsplash",
        "query": "seasonal Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/spring-property-prep-newark/3.jpg",
        "alt": "brown concrete building near trees during daytime",
        "photographer": "Robert Thiemann",
        "photographerUrl": "https://unsplash.com/@rthiemann",
        "source": "unsplash",
        "query": "seasonal Newark New Jersey",
        "width": 1400,
        "height": 900
      }
    ]
  },
  "fence-repair-newark-light-carpentry": {
    "slug": "fence-repair-newark-light-carpentry",
    "images": [
      {
        "src": "/blog-images/fence-repair-newark-light-carpentry/1.jpg",
        "alt": "Technician repairing an air conditioner unit in New Delhi workshop.",
        "photographer": "Multitech Institute",
        "photographerUrl": "https://www.pexels.com/@multitech-institute-2155038539",
        "source": "pexels",
        "query": "repairs Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/fence-repair-newark-light-carpentry/2.jpg",
        "alt": "Stunning aerial shot of the USS New Jersey battleship docked in Philadelphia, Pennsylvania.",
        "photographer": "K",
        "photographerUrl": "https://www.pexels.com/@kelly",
        "source": "pexels",
        "query": "repairs Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/fence-repair-newark-light-carpentry/3.jpg",
        "alt": "Close-up of disassembled smartphone parts on a blue repair mat with tools.",
        "photographer": "Fotografia Lui Vlad",
        "photographerUrl": "https://www.pexels.com/@fotografia-lui-vlad-1445510816",
        "source": "pexels",
        "query": "repairs Newark New Jersey",
        "width": 1400,
        "height": 900
      }
    ]
  },
  "driveway-power-washing-equipment": {
    "slug": "driveway-power-washing-equipment",
    "images": [
      {
        "src": "/blog-images/driveway-power-washing-equipment/1.jpg",
        "alt": "Smiling woman in yellow shirt uses power spray to wash black car outside.",
        "photographer": "Andrea Piacquadio",
        "photographerUrl": "https://www.pexels.com/@olly",
        "source": "pexels",
        "query": "power washing Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/driveway-power-washing-equipment/2.jpg",
        "alt": "Man in orange jumpsuit and mask cleaning an outdoor urban wall. Bright daylight setting.",
        "photographer": "cottonbro studio",
        "photographerUrl": "https://www.pexels.com/@cottonbro",
        "source": "pexels",
        "query": "power washing Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/driveway-power-washing-equipment/3.jpg",
        "alt": "A person using a pressure washer to clean a car in an indoor garage setting.",
        "photographer": "Tima Miroshnichenko",
        "photographerUrl": "https://www.pexels.com/@tima-miroshnichenko",
        "source": "pexels",
        "query": "power washing Newark New Jersey",
        "width": 1400,
        "height": 900
      }
    ]
  },
  "tony-partnership-st-johns-soup-kitchen": {
    "slug": "tony-partnership-st-johns-soup-kitchen",
    "images": [
      {
        "src": "/blog-images/tony-partnership-st-johns-soup-kitchen/1.jpg",
        "alt": "brown concrete building near trees during daytime",
        "photographer": "Robert Thiemann",
        "photographerUrl": "https://unsplash.com/@rthiemann",
        "source": "unsplash",
        "query": "community Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/tony-partnership-st-johns-soup-kitchen/2.jpg",
        "alt": "aerial view of city buildings during daytime",
        "photographer": "Emmanuel Ogbonnaya",
        "photographerUrl": "https://unsplash.com/@mannythegrapher",
        "source": "unsplash",
        "query": "community Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/tony-partnership-st-johns-soup-kitchen/3.jpg",
        "alt": "Breathtaking view of the New York City skyline captured from across the river.",
        "photographer": "Andres Figueroa",
        "photographerUrl": "https://www.pexels.com/@andres-figueroa-3326883",
        "source": "pexels",
        "query": "community Newark New Jersey",
        "width": 1400,
        "height": 900
      }
    ]
  },
  "pulling-weeds-from-the-roots": {
    "slug": "pulling-weeds-from-the-roots",
    "images": [
      {
        "src": "/blog-images/pulling-weeds-from-the-roots/1.jpg",
        "alt": "Exterior of contemporary residential house with glass doors and panoramic windows near green lawn with paved paths on sunny day in summer",
        "photographer": "Max Vakhtbovych",
        "photographerUrl": "https://www.pexels.com/@artbovich",
        "source": "pexels",
        "query": "lawn care Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/pulling-weeds-from-the-roots/2.jpg",
        "alt": "Close-up of a grass trimmer cutting lawn with grass clippings flying.",
        "photographer": "Pascal Küffer",
        "photographerUrl": "https://www.pexels.com/@pascal-kuffer-190126462",
        "source": "pexels",
        "query": "lawn care Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/pulling-weeds-from-the-roots/3.jpg",
        "alt": "Close-up of a grass cutter trimming green grass with flying clippings outdoors.",
        "photographer": "Pascal Küffer",
        "photographerUrl": "https://www.pexels.com/@pascal-kuffer-190126462",
        "source": "pexels",
        "query": "lawn care Newark New Jersey",
        "width": 1400,
        "height": 900
      }
    ]
  },
  "sofa-haul-away-as-low-as-200": {
    "slug": "sofa-haul-away-as-low-as-200",
    "images": [
      {
        "src": "/blog-images/sofa-haul-away-as-low-as-200/1.jpg",
        "alt": "body of water near trees and buildings during daytime",
        "photographer": "Robert Thiemann",
        "photographerUrl": "https://unsplash.com/@rthiemann",
        "source": "unsplash",
        "query": "hauling Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/sofa-haul-away-as-low-as-200/2.jpg",
        "alt": "City street with buildings and lamp post.",
        "photographer": "Michael Moloney",
        "photographerUrl": "https://unsplash.com/@mjmolo",
        "source": "unsplash",
        "query": "hauling Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/sofa-haul-away-as-low-as-200/3.jpg",
        "alt": "A white construction truck loaded with building materials and equipment parked by a building.",
        "photographer": "Mathias Reding",
        "photographerUrl": "https://www.pexels.com/@matreding",
        "source": "pexels",
        "query": "hauling Newark New Jersey",
        "width": 1400,
        "height": 900
      }
    ]
  },
  "newark-property-owner-hiring-guide": {
    "slug": "newark-property-owner-hiring-guide",
    "images": [
      {
        "src": "/blog-images/newark-property-owner-hiring-guide/1.jpg",
        "alt": "Stunning aerial shot of the USS New Jersey battleship docked in Philadelphia, Pennsylvania.",
        "photographer": "K",
        "photographerUrl": "https://www.pexels.com/@kelly",
        "source": "pexels",
        "query": "guides Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/newark-property-owner-hiring-guide/2.jpg",
        "alt": "Breathtaking view of the New York City skyline captured from across the river.",
        "photographer": "Andres Figueroa",
        "photographerUrl": "https://www.pexels.com/@andres-figueroa-3326883",
        "source": "pexels",
        "query": "guides Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/newark-property-owner-hiring-guide/3.jpg",
        "alt": "Dramatic aerial view of the Jersey City skyline showcasing prominent skyscrapers along the Hudson River.",
        "photographer": "Matthis Volquardsen",
        "photographerUrl": "https://www.pexels.com/@einfoto",
        "source": "pexels",
        "query": "guides Newark New Jersey",
        "width": 1400,
        "height": 900
      }
    ]
  },
  "newark-power-washing-mistakes": {
    "slug": "newark-power-washing-mistakes",
    "images": [
      {
        "src": "/blog-images/newark-power-washing-mistakes/1.jpg",
        "alt": "Smiling woman in yellow shirt uses power spray to wash black car outside.",
        "photographer": "Andrea Piacquadio",
        "photographerUrl": "https://www.pexels.com/@olly",
        "source": "pexels",
        "query": "power washing Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/newark-power-washing-mistakes/2.jpg",
        "alt": "Man in orange jumpsuit and mask cleaning an outdoor urban wall. Bright daylight setting.",
        "photographer": "cottonbro studio",
        "photographerUrl": "https://www.pexels.com/@cottonbro",
        "source": "pexels",
        "query": "power washing Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/newark-power-washing-mistakes/3.jpg",
        "alt": "A person using a pressure washer to clean a car in an indoor garage setting.",
        "photographer": "Tima Miroshnichenko",
        "photographerUrl": "https://www.pexels.com/@tima-miroshnichenko",
        "source": "pexels",
        "query": "power washing Newark New Jersey",
        "width": 1400,
        "height": 900
      }
    ]
  },
  "newark-hauling-disposal-guide": {
    "slug": "newark-hauling-disposal-guide",
    "images": [
      {
        "src": "/blog-images/newark-hauling-disposal-guide/1.jpg",
        "alt": "body of water near trees and buildings during daytime",
        "photographer": "Robert Thiemann",
        "photographerUrl": "https://unsplash.com/@rthiemann",
        "source": "unsplash",
        "query": "hauling Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/newark-hauling-disposal-guide/2.jpg",
        "alt": "City street with buildings and lamp post.",
        "photographer": "Michael Moloney",
        "photographerUrl": "https://unsplash.com/@mjmolo",
        "source": "unsplash",
        "query": "hauling Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/newark-hauling-disposal-guide/3.jpg",
        "alt": "A white construction truck loaded with building materials and equipment parked by a building.",
        "photographer": "Mathias Reding",
        "photographerUrl": "https://www.pexels.com/@matreding",
        "source": "pexels",
        "query": "hauling Newark New Jersey",
        "width": 1400,
        "height": 900
      }
    ]
  },
  "newark-yard-care-calendar": {
    "slug": "newark-yard-care-calendar",
    "images": [
      {
        "src": "/blog-images/newark-yard-care-calendar/1.jpg",
        "alt": "Exterior of contemporary residential house with glass doors and panoramic windows near green lawn with paved paths on sunny day in summer",
        "photographer": "Max Vakhtbovych",
        "photographerUrl": "https://www.pexels.com/@artbovich",
        "source": "pexels",
        "query": "lawn care Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/newark-yard-care-calendar/2.jpg",
        "alt": "Close-up of a grass trimmer cutting lawn with grass clippings flying.",
        "photographer": "Pascal Küffer",
        "photographerUrl": "https://www.pexels.com/@pascal-kuffer-190126462",
        "source": "pexels",
        "query": "lawn care Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/newark-yard-care-calendar/3.jpg",
        "alt": "Close-up of a grass cutter trimming green grass with flying clippings outdoors.",
        "photographer": "Pascal Küffer",
        "photographerUrl": "https://www.pexels.com/@pascal-kuffer-190126462",
        "source": "pexels",
        "query": "lawn care Newark New Jersey",
        "width": 1400,
        "height": 900
      }
    ]
  },
  "how-to-hire-property-crew-without-getting-burned": {
    "slug": "how-to-hire-property-crew-without-getting-burned",
    "images": [
      {
        "src": "/blog-images/how-to-hire-property-crew-without-getting-burned/1.jpg",
        "alt": "Stunning aerial shot of the USS New Jersey battleship docked in Philadelphia, Pennsylvania.",
        "photographer": "K",
        "photographerUrl": "https://www.pexels.com/@kelly",
        "source": "pexels",
        "query": "guides Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/how-to-hire-property-crew-without-getting-burned/2.jpg",
        "alt": "Breathtaking view of the New York City skyline captured from across the river.",
        "photographer": "Andres Figueroa",
        "photographerUrl": "https://www.pexels.com/@andres-figueroa-3326883",
        "source": "pexels",
        "query": "guides Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/how-to-hire-property-crew-without-getting-burned/3.jpg",
        "alt": "Dramatic aerial view of the Jersey City skyline showcasing prominent skyscrapers along the Hudson River.",
        "photographer": "Matthis Volquardsen",
        "photographerUrl": "https://www.pexels.com/@einfoto",
        "source": "pexels",
        "query": "guides Newark New Jersey",
        "width": 1400,
        "height": 900
      }
    ]
  },
  "twenty-four-seven-emergency-property-help-newark": {
    "slug": "twenty-four-seven-emergency-property-help-newark",
    "images": [
      {
        "src": "/blog-images/twenty-four-seven-emergency-property-help-newark/1.jpg",
        "alt": "brown concrete building near trees during daytime",
        "photographer": "Robert Thiemann",
        "photographerUrl": "https://unsplash.com/@rthiemann",
        "source": "unsplash",
        "query": "how-to Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/twenty-four-seven-emergency-property-help-newark/2.jpg",
        "alt": "body of water near trees and buildings during daytime",
        "photographer": "Robert Thiemann",
        "photographerUrl": "https://unsplash.com/@rthiemann",
        "source": "unsplash",
        "query": "how-to Newark New Jersey",
        "width": 1400,
        "height": 900
      },
      {
        "src": "/blog-images/twenty-four-seven-emergency-property-help-newark/3.jpg",
        "alt": "train station with people walking",
        "photographer": "Saul Mercado",
        "photographerUrl": "https://unsplash.com/@mercadomuses",
        "source": "unsplash",
        "query": "how-to Newark New Jersey",
        "width": 1400,
        "height": 900
      }
    ]
  }
};
export default data;
