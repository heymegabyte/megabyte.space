const raw = [
  {
    "slug": "newark",
    "name": "Newark",
    "state": "NJ",
    "county": "Essex",
    "population": 311549,
    "lat": 40.7357,
    "lng": -74.1724,
    "zip": "07102",
    "primary": true
  },
  {
    "slug": "jersey-city",
    "name": "Jersey City",
    "state": "NJ",
    "county": "Hudson",
    "population": 292449,
    "lat": 40.7178,
    "lng": -74.0431,
    "zip": "07302"
  },
  {
    "slug": "paterson",
    "name": "Paterson",
    "state": "NJ",
    "county": "Passaic",
    "population": 159732,
    "lat": 40.9168,
    "lng": -74.1718,
    "zip": "07501"
  },
  {
    "slug": "elizabeth",
    "name": "Elizabeth",
    "state": "NJ",
    "county": "Union",
    "population": 137298,
    "lat": 40.664,
    "lng": -74.2107,
    "zip": "07201"
  },
  {
    "slug": "edison",
    "name": "Edison",
    "state": "NJ",
    "county": "Middlesex",
    "population": 107588,
    "lat": 40.5187,
    "lng": -74.4121,
    "zip": "08817"
  },
  {
    "slug": "clifton",
    "name": "Clifton",
    "state": "NJ",
    "county": "Passaic",
    "population": 90296,
    "lat": 40.8584,
    "lng": -74.1638,
    "zip": "07011"
  },
  {
    "slug": "union-city",
    "name": "Union City",
    "state": "NJ",
    "county": "Hudson",
    "population": 68247,
    "lat": 40.7795,
    "lng": -74.0238,
    "zip": "07087"
  },
  {
    "slug": "bayonne",
    "name": "Bayonne",
    "state": "NJ",
    "county": "Hudson",
    "population": 71686,
    "lat": 40.6687,
    "lng": -74.1143,
    "zip": "07002"
  },
  {
    "slug": "east-orange",
    "name": "East Orange",
    "state": "NJ",
    "county": "Essex",
    "population": 69612,
    "lat": 40.7673,
    "lng": -74.2049,
    "zip": "07017"
  },
  {
    "slug": "passaic",
    "name": "Passaic",
    "state": "NJ",
    "county": "Passaic",
    "population": 70537,
    "lat": 40.8568,
    "lng": -74.1285,
    "zip": "07055"
  },
  {
    "slug": "north-bergen",
    "name": "North Bergen",
    "state": "NJ",
    "county": "Hudson",
    "population": 63361,
    "lat": 40.8043,
    "lng": -74.0121,
    "zip": "07047"
  },
  {
    "slug": "irvington",
    "name": "Irvington",
    "state": "NJ",
    "county": "Essex",
    "population": 61176,
    "lat": 40.7323,
    "lng": -74.2349,
    "zip": "07111"
  },
  {
    "slug": "hoboken",
    "name": "Hoboken",
    "state": "NJ",
    "county": "Hudson",
    "population": 60419,
    "lat": 40.7439,
    "lng": -74.0324,
    "zip": "07030"
  },
  {
    "slug": "wayne",
    "name": "Wayne",
    "state": "NJ",
    "county": "Passaic",
    "population": 54838,
    "lat": 40.9293,
    "lng": -74.2767,
    "zip": "07470"
  },
  {
    "slug": "plainfield",
    "name": "Plainfield",
    "state": "NJ",
    "county": "Union",
    "population": 54586,
    "lat": 40.6337,
    "lng": -74.4076,
    "zip": "07060"
  },
  {
    "slug": "bloomfield",
    "name": "Bloomfield",
    "state": "NJ",
    "county": "Essex",
    "population": 53105,
    "lat": 40.8067,
    "lng": -74.1854,
    "zip": "07003"
  },
  {
    "slug": "west-new-york",
    "name": "West New York",
    "state": "NJ",
    "county": "Hudson",
    "population": 52910,
    "lat": 40.7879,
    "lng": -74.0143,
    "zip": "07093"
  },
  {
    "slug": "west-orange",
    "name": "West Orange",
    "state": "NJ",
    "county": "Essex",
    "population": 48843,
    "lat": 40.7987,
    "lng": -74.2391,
    "zip": "07052"
  },
  {
    "slug": "hackensack",
    "name": "Hackensack",
    "state": "NJ",
    "county": "Bergen",
    "population": 46030,
    "lat": 40.8859,
    "lng": -74.0435,
    "zip": "07601"
  },
  {
    "slug": "linden",
    "name": "Linden",
    "state": "NJ",
    "county": "Union",
    "population": 43007,
    "lat": 40.622,
    "lng": -74.2446,
    "zip": "07036"
  },
  {
    "slug": "kearny",
    "name": "Kearny",
    "state": "NJ",
    "county": "Hudson",
    "population": 41999,
    "lat": 40.7684,
    "lng": -74.1454,
    "zip": "07032"
  },
  {
    "slug": "teaneck",
    "name": "Teaneck",
    "state": "NJ",
    "county": "Bergen",
    "population": 41246,
    "lat": 40.8976,
    "lng": -74.016,
    "zip": "07666"
  },
  {
    "slug": "montclair",
    "name": "Montclair",
    "state": "NJ",
    "county": "Essex",
    "population": 41011,
    "lat": 40.8259,
    "lng": -74.2091,
    "zip": "07042"
  },
  {
    "slug": "fort-lee",
    "name": "Fort Lee",
    "state": "NJ",
    "county": "Bergen",
    "population": 40191,
    "lat": 40.8509,
    "lng": -73.9701,
    "zip": "07024"
  },
  {
    "slug": "belleville",
    "name": "Belleville",
    "state": "NJ",
    "county": "Essex",
    "population": 38222,
    "lat": 40.7937,
    "lng": -74.15,
    "zip": "07109"
  },
  {
    "slug": "orange",
    "name": "Orange",
    "state": "NJ",
    "county": "Essex",
    "population": 34447,
    "lat": 40.7704,
    "lng": -74.2326,
    "zip": "07050"
  },
  {
    "slug": "garfield",
    "name": "Garfield",
    "state": "NJ",
    "county": "Bergen",
    "population": 32060,
    "lat": 40.8815,
    "lng": -74.1126,
    "zip": "07026"
  },
  {
    "slug": "livingston",
    "name": "Livingston",
    "state": "NJ",
    "county": "Essex",
    "population": 31330,
    "lat": 40.7959,
    "lng": -74.3149,
    "zip": "07039"
  },
  {
    "slug": "westfield",
    "name": "Westfield",
    "state": "NJ",
    "county": "Union",
    "population": 31196,
    "lat": 40.659,
    "lng": -74.3477,
    "zip": "07090"
  },
  {
    "slug": "nutley",
    "name": "Nutley",
    "state": "NJ",
    "county": "Essex",
    "population": 30143,
    "lat": 40.8222,
    "lng": -74.1599,
    "zip": "07110"
  },
  {
    "slug": "rahway",
    "name": "Rahway",
    "state": "NJ",
    "county": "Union",
    "population": 30063,
    "lat": 40.6082,
    "lng": -74.2776,
    "zip": "07065"
  },
  {
    "slug": "englewood",
    "name": "Englewood",
    "state": "NJ",
    "county": "Bergen",
    "population": 29308,
    "lat": 40.8929,
    "lng": -73.9726,
    "zip": "07631"
  },
  {
    "slug": "paramus",
    "name": "Paramus",
    "state": "NJ",
    "county": "Bergen",
    "population": 26698,
    "lat": 40.9445,
    "lng": -74.0754,
    "zip": "07652"
  },
  {
    "slug": "maplewood",
    "name": "Maplewood",
    "state": "NJ",
    "county": "Essex",
    "population": 25684,
    "lat": 40.7312,
    "lng": -74.273,
    "zip": "07040"
  },
  {
    "slug": "cranford",
    "name": "Cranford",
    "state": "NJ",
    "county": "Union",
    "population": 24008,
    "lat": 40.6584,
    "lng": -74.2998,
    "zip": "07016"
  },
  {
    "slug": "roselle",
    "name": "Roselle",
    "state": "NJ",
    "county": "Union",
    "population": 22902,
    "lat": 40.652,
    "lng": -74.2587,
    "zip": "07203"
  },
  {
    "slug": "summit",
    "name": "Summit",
    "state": "NJ",
    "county": "Union",
    "population": 22719,
    "lat": 40.7155,
    "lng": -74.364,
    "zip": "07901"
  },
  {
    "slug": "millburn",
    "name": "Millburn",
    "state": "NJ",
    "county": "Essex",
    "population": 21710,
    "lat": 40.7295,
    "lng": -74.3032,
    "zip": "07041"
  },
  {
    "slug": "south-orange",
    "name": "South Orange",
    "state": "NJ",
    "county": "Essex",
    "population": 18484,
    "lat": 40.7491,
    "lng": -74.2615,
    "zip": "07079"
  },
  {
    "slug": "springfield",
    "name": "Springfield",
    "state": "NJ",
    "county": "Union",
    "population": 17659,
    "lat": 40.7012,
    "lng": -74.3252,
    "zip": "07081"
  },
  {
    "slug": "verona",
    "name": "Verona",
    "state": "NJ",
    "county": "Essex",
    "population": 14572,
    "lat": 40.8298,
    "lng": -74.2402,
    "zip": "07044"
  },
  {
    "slug": "roselle-park",
    "name": "Roselle Park",
    "state": "NJ",
    "county": "Union",
    "population": 13811,
    "lat": 40.6645,
    "lng": -74.2641,
    "zip": "07204"
  },
  {
    "slug": "cedar-grove",
    "name": "Cedar Grove",
    "state": "NJ",
    "county": "Essex",
    "population": 12981,
    "lat": 40.8537,
    "lng": -74.2287,
    "zip": "07009"
  },
  {
    "slug": "caldwell",
    "name": "Caldwell",
    "state": "NJ",
    "county": "Essex",
    "population": 9159,
    "lat": 40.839,
    "lng": -74.2768,
    "zip": "07006"
  },
  {
    "slug": "glen-ridge",
    "name": "Glen Ridge",
    "state": "NJ",
    "county": "Essex",
    "population": 7852,
    "lat": 40.8054,
    "lng": -74.2038,
    "zip": "07028"
  },
  {
    "slug": "manhattan",
    "name": "Manhattan",
    "state": "NY",
    "county": "New York",
    "population": 1694251,
    "lat": 40.7831,
    "lng": -73.9712,
    "zip": "10001"
  },
  {
    "slug": "brooklyn",
    "name": "Brooklyn",
    "state": "NY",
    "county": "Kings",
    "population": 2736074,
    "lat": 40.6782,
    "lng": -73.9442,
    "zip": "11201"
  },
  {
    "slug": "queens",
    "name": "Queens",
    "state": "NY",
    "county": "Queens",
    "population": 2405464,
    "lat": 40.7282,
    "lng": -73.7949,
    "zip": "11101"
  },
  {
    "slug": "the-bronx",
    "name": "The Bronx",
    "state": "NY",
    "county": "Bronx",
    "population": 1472654,
    "lat": 40.8448,
    "lng": -73.8648,
    "zip": "10451"
  },
  {
    "slug": "staten-island",
    "name": "Staten Island",
    "state": "NY",
    "county": "Richmond",
    "population": 495747,
    "lat": 40.5795,
    "lng": -74.1502,
    "zip": "10301"
  },
  {
    "slug": "washington-dc",
    "name": "Washington",
    "state": "DC",
    "county": "District of Columbia",
    "population": 689545,
    "lat": 38.9072,
    "lng": -77.0369,
    "zip": "20001",
    "completedGigs": 0
  }
] as const;

export interface City {
  slug: string;
  name: string;
  state: 'NJ' | 'NY' | 'DC';
  county: string;
  population: number;
  lat: number;
  lng: number;
  zip?: string;
  primary?: boolean;
  /**
   * Wave 1A: thin-content gate. City pages with fewer than 10 completed gigs
   * (or <300 visible words) emit `<meta name="robots" content="noindex">` to
   * avoid Google thin-content penalties and pollution of LLM citations. Stub
   * defaults to 0 — every city stays noindex until real history lands here.
   */
  completedGigs?: number;
}

export const CITIES: City[] = raw as unknown as City[];

const NEWARK = CITIES[0] ?? {
  slug: 'newark',
  name: 'Newark',
  state: 'NJ',
  county: 'Essex',
  population: 311549,
  lat: 40.7357,
  lng: -74.1724,
  primary: true,
};

const EARTH_KM = 6371;
function haversine(a: City, b: City): number {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * EARTH_KM * Math.asin(Math.sqrt(x));
}

export function distanceFromNewarkMiles(city: City): number {
  return haversine(NEWARK, city) * 0.621371;
}

/**
 * True for a service area we TRAVEL to for scheduled projects (e.g. Washington
 * DC) rather than dispatch a same-day local crew — anything outside the NJ/NY
 * metro. Drives truthful "we travel here" framing and suppresses the Newark-
 * proximity copy (nearby-cities list, "minutes from Newark") that only holds
 * for the local footprint.
 */
export function isDestinationCity(city: City): boolean {
  return city.state !== 'NJ' && city.state !== 'NY';
}

export function nearestCities(target: City, count = 4): City[] {
  return CITIES.filter((c) => c.slug !== target.slug)
    .map((c) => ({ city: c, d: haversine(target, c) }))
    .sort((a, b) => a.d - b.d)
    .slice(0, count)
    .map((x) => x.city);
}

export function getCityBySlug(slug: string): City | undefined {
  return CITIES.find((c) => c.slug === slug);
}
