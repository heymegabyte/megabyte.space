const raw = {
  "newark": {
    "slug": "newark",
    "alt": "Breathtaking view of the New York City skyline captured from across the river.",
    "photographer": "Andres Figueroa",
    "photographerUrl": "https://www.pexels.com/@andres-figueroa-3326883",
    "source": "pexels",
    "query": "Newark New Jersey downtown",
    "bytes": 102493
  },
  "jersey-city": {
    "slug": "jersey-city",
    "alt": "A large body of water with a city in the background",
    "photographer": "Zhen Yao",
    "photographerUrl": "https://unsplash.com/@zhenyao_photo",
    "source": "unsplash",
    "query": "Jersey City New Jersey skyline",
    "bytes": 193538
  },
  "paterson": {
    "slug": "paterson",
    "alt": "a large waterfall with water cascading down it's sides",
    "photographer": "Brice Cooper",
    "photographerUrl": "https://unsplash.com/@brice_cooper18",
    "source": "unsplash",
    "query": "Paterson New Jersey waterfall",
    "bytes": 348023
  },
  "elizabeth": {
    "slug": "elizabeth",
    "alt": "a white fire hydrant sitting on the side of a road",
    "photographer": "Suraj Tomer",
    "photographerUrl": "https://unsplash.com/@meditative",
    "source": "unsplash",
    "query": "Elizabeth New Jersey street",
    "bytes": 424108
  },
  "edison": {
    "slug": "edison",
    "alt": "a white two story house sitting on the side of a road",
    "photographer": "Sean Boyd",
    "photographerUrl": "https://unsplash.com/@seanfboyd",
    "source": "unsplash",
    "query": "Edison New Jersey suburb",
    "bytes": 427672
  },
  "clifton": {
    "slug": "clifton",
    "alt": "A sign that is on the side of a building",
    "photographer": "Frolicsome Fairy",
    "photographerUrl": "https://unsplash.com/@frolicsomefairy",
    "source": "unsplash",
    "query": "Clifton New Jersey street",
    "bytes": 185459
  },
  "union-city": {
    "slug": "union-city",
    "alt": "Aerial view of Edgewater, NJ overlooking the waterfront and Manhattan skyline.",
    "photographer": "Malcolm Garret",
    "photographerUrl": "https://www.pexels.com/@malcolm-garret-3023588",
    "source": "pexels",
    "query": "Hudson County New Jersey rowhouse",
    "bytes": 147250
  },
  "bayonne": {
    "slug": "bayonne",
    "alt": "A vibrant intersection in Jersey City with towering skyscrapers and a historic building.",
    "photographer": "Arjun Gheewala",
    "photographerUrl": "https://www.pexels.com/@arjun-gheewala-454811670",
    "source": "pexels",
    "query": "Bayonne New Jersey street",
    "bytes": 144424
  },
  "east-orange": {
    "slug": "east-orange",
    "alt": "Aerial view of urban residential apartments featuring an American flag, depicting city life.",
    "photographer": "Illya Goloborodko",
    "photographerUrl": "https://www.pexels.com/@illya-goloborodko-78974058",
    "source": "pexels",
    "query": "East Orange New Jersey neighborhood",
    "bytes": 143485
  },
  "passaic": {
    "slug": "passaic",
    "alt": "City street with buildings and lamp post.",
    "photographer": "Michael Moloney",
    "photographerUrl": "https://unsplash.com/@mjmolo",
    "source": "unsplash",
    "query": "Passaic New Jersey street",
    "bytes": 242439
  },
  "north-bergen": {
    "slug": "north-bergen",
    "alt": "Breathtaking view of the New York City skyline captured from across the river.",
    "photographer": "Andres Figueroa",
    "photographerUrl": "https://www.pexels.com/@andres-figueroa-3326883",
    "source": "pexels",
    "query": "North Bergen New Jersey skyline",
    "bytes": 102493
  },
  "irvington": {
    "slug": "irvington",
    "alt": "Aerial view of urban residential apartments featuring an American flag, depicting city life.",
    "photographer": "Illya Goloborodko",
    "photographerUrl": "https://www.pexels.com/@illya-goloborodko-78974058",
    "source": "pexels",
    "query": "New Jersey suburban street",
    "bytes": 143485
  },
  "hoboken": {
    "slug": "hoboken",
    "alt": "Bank of America, New York",
    "photographer": "Shane Lynes",
    "photographerUrl": "https://unsplash.com/@slynes",
    "source": "unsplash",
    "query": "Hoboken New Jersey waterfront",
    "bytes": 284081
  },
  "wayne": {
    "slug": "wayne",
    "alt": "aerial photography of houses near trees",
    "photographer": "Matt Donders",
    "photographerUrl": "https://unsplash.com/@mattdonders",
    "source": "unsplash",
    "query": "New Jersey suburban home",
    "bytes": 234619
  },
  "plainfield": {
    "slug": "plainfield",
    "alt": "Aerial view of urban residential apartments featuring an American flag, depicting city life.",
    "photographer": "Illya Goloborodko",
    "photographerUrl": "https://www.pexels.com/@illya-goloborodko-78974058",
    "source": "pexels",
    "query": "New Jersey suburban street",
    "bytes": 143485
  },
  "bloomfield": {
    "slug": "bloomfield",
    "alt": "A large brick building with two garage doors",
    "photographer": "Julien Maculan",
    "photographerUrl": "https://unsplash.com/@maculan",
    "source": "unsplash",
    "query": "Bloomfield New Jersey street",
    "bytes": 290314
  },
  "west-new-york": {
    "slug": "west-new-york",
    "alt": "A picturesque European street lined with red brick buildings, cars, and bicycles under a cloudy sky.",
    "photographer": "Melike  B",
    "photographerUrl": "https://www.pexels.com/@mlkbnl",
    "source": "pexels",
    "query": "New Jersey rowhouse street",
    "bytes": 159017
  },
  "west-orange": {
    "slug": "west-orange",
    "alt": "Aerial view of Edgewater, NJ overlooking the waterfront and Manhattan skyline.",
    "photographer": "Malcolm Garret",
    "photographerUrl": "https://www.pexels.com/@malcolm-garret-3023588",
    "source": "pexels",
    "query": "West Orange New Jersey home",
    "bytes": 147250
  },
  "hackensack": {
    "slug": "hackensack",
    "alt": "Aerial view of urban residential apartments featuring an American flag, depicting city life.",
    "photographer": "Illya Goloborodko",
    "photographerUrl": "https://www.pexels.com/@illya-goloborodko-78974058",
    "source": "pexels",
    "query": "Hackensack New Jersey street",
    "bytes": 143485
  },
  "linden": {
    "slug": "linden",
    "alt": "aerial photography of houses near trees",
    "photographer": "Matt Donders",
    "photographerUrl": "https://unsplash.com/@mattdonders",
    "source": "unsplash",
    "query": "New Jersey suburban home",
    "bytes": 234619
  },
  "kearny": {
    "slug": "kearny",
    "alt": "a white fire hydrant sitting on the side of a road",
    "photographer": "Suraj Tomer",
    "photographerUrl": "https://unsplash.com/@meditative",
    "source": "unsplash",
    "query": "Kearny New Jersey street",
    "bytes": 424108
  },
  "teaneck": {
    "slug": "teaneck",
    "alt": "A serene view of a lake with house reflections and overcast skies.",
    "photographer": "JINISH RAJAGOPAL",
    "photographerUrl": "https://www.pexels.com/@jinish-rajagopal-2148784550",
    "source": "pexels",
    "query": "Teaneck New Jersey home",
    "bytes": 107044
  },
  "montclair": {
    "slug": "montclair",
    "alt": "Historic colonial house surrounded by greenery in a peaceful setting.",
    "photographer": "Malcolm Garret",
    "photographerUrl": "https://www.pexels.com/@malcolm-garret-3023588",
    "source": "pexels",
    "query": "Montclair New Jersey home",
    "bytes": 166744
  },
  "fort-lee": {
    "slug": "fort-lee",
    "alt": "Underside view of a large steel bridge structure",
    "photographer": "Matt Dragon",
    "photographerUrl": "https://unsplash.com/@matt_dragon",
    "source": "unsplash",
    "query": "Fort Lee New Jersey skyline",
    "bytes": 224551
  },
  "belleville": {
    "slug": "belleville",
    "alt": "Aerial view of urban residential apartments featuring an American flag, depicting city life.",
    "photographer": "Illya Goloborodko",
    "photographerUrl": "https://www.pexels.com/@illya-goloborodko-78974058",
    "source": "pexels",
    "query": "Belleville New Jersey street",
    "bytes": 143485
  },
  "orange": {
    "slug": "orange",
    "alt": "brown wooden framed glass window",
    "photographer": "Khürt Williams",
    "photographerUrl": "https://unsplash.com/@khurtwilliams",
    "source": "unsplash",
    "query": "Orange New Jersey street",
    "bytes": 319013
  },
  "garfield": {
    "slug": "garfield",
    "alt": "a house with a driveway and trees in front of it",
    "photographer": "Suraj Tomer",
    "photographerUrl": "https://unsplash.com/@meditative",
    "source": "unsplash",
    "query": "New Jersey suburb home",
    "bytes": 394647
  },
  "livingston": {
    "slug": "livingston",
    "alt": "A serene view of a lake with house reflections and overcast skies.",
    "photographer": "JINISH RAJAGOPAL",
    "photographerUrl": "https://www.pexels.com/@jinish-rajagopal-2148784550",
    "source": "pexels",
    "query": "Livingston New Jersey home",
    "bytes": 107044
  },
  "westfield": {
    "slug": "westfield",
    "alt": "a house with a driveway and trees in front of it",
    "photographer": "Suraj Tomer",
    "photographerUrl": "https://unsplash.com/@meditative",
    "source": "unsplash",
    "query": "Westfield New Jersey home",
    "bytes": 394647
  },
  "nutley": {
    "slug": "nutley",
    "alt": "A serene view of a lake with house reflections and overcast skies.",
    "photographer": "JINISH RAJAGOPAL",
    "photographerUrl": "https://www.pexels.com/@jinish-rajagopal-2148784550",
    "source": "pexels",
    "query": "Nutley New Jersey home",
    "bytes": 107044
  },
  "rahway": {
    "slug": "rahway",
    "alt": "Aerial view of urban residential apartments featuring an American flag, depicting city life.",
    "photographer": "Illya Goloborodko",
    "photographerUrl": "https://www.pexels.com/@illya-goloborodko-78974058",
    "source": "pexels",
    "query": "New Jersey suburb",
    "bytes": 143485
  },
  "englewood": {
    "slug": "englewood",
    "alt": "A serene view of a lake with house reflections and overcast skies.",
    "photographer": "JINISH RAJAGOPAL",
    "photographerUrl": "https://www.pexels.com/@jinish-rajagopal-2148784550",
    "source": "pexels",
    "query": "Englewood New Jersey home",
    "bytes": 107044
  },
  "paramus": {
    "slug": "paramus",
    "alt": "Aerial view of urban residential apartments featuring an American flag, depicting city life.",
    "photographer": "Illya Goloborodko",
    "photographerUrl": "https://www.pexels.com/@illya-goloborodko-78974058",
    "source": "pexels",
    "query": "Paramus New Jersey street",
    "bytes": 143485
  },
  "maplewood": {
    "slug": "maplewood",
    "alt": "A serene view of a lake with house reflections and overcast skies.",
    "photographer": "JINISH RAJAGOPAL",
    "photographerUrl": "https://www.pexels.com/@jinish-rajagopal-2148784550",
    "source": "pexels",
    "query": "Maplewood New Jersey home",
    "bytes": 107044
  },
  "cranford": {
    "slug": "cranford",
    "alt": "A serene view of a lake with house reflections and overcast skies.",
    "photographer": "JINISH RAJAGOPAL",
    "photographerUrl": "https://www.pexels.com/@jinish-rajagopal-2148784550",
    "source": "pexels",
    "query": "Cranford New Jersey home",
    "bytes": 107044
  },
  "roselle": {
    "slug": "roselle",
    "alt": "Aerial view of urban residential apartments featuring an American flag, depicting city life.",
    "photographer": "Illya Goloborodko",
    "photographerUrl": "https://www.pexels.com/@illya-goloborodko-78974058",
    "source": "pexels",
    "query": "New Jersey suburban street",
    "bytes": 143485
  },
  "summit": {
    "slug": "summit",
    "alt": "Calm lake surrounded by trees and houses reflecting a cloudy sky, capturing tranquil nature.",
    "photographer": "JINISH RAJAGOPAL",
    "photographerUrl": "https://www.pexels.com/@jinish-rajagopal-2148784550",
    "source": "pexels",
    "query": "Summit New Jersey home",
    "bytes": 91486
  },
  "millburn": {
    "slug": "millburn",
    "alt": "a white two story house sitting on the side of a road",
    "photographer": "Sean Boyd",
    "photographerUrl": "https://unsplash.com/@seanfboyd",
    "source": "unsplash",
    "query": "Millburn New Jersey home",
    "bytes": 427672
  },
  "south-orange": {
    "slug": "south-orange",
    "alt": "a house with a driveway and trees in front of it",
    "photographer": "Suraj Tomer",
    "photographerUrl": "https://unsplash.com/@meditative",
    "source": "unsplash",
    "query": "South Orange New Jersey home",
    "bytes": 394647
  },
  "springfield": {
    "slug": "springfield",
    "alt": "aerial photography of houses near trees",
    "photographer": "Matt Donders",
    "photographerUrl": "https://unsplash.com/@mattdonders",
    "source": "unsplash",
    "query": "New Jersey suburban home",
    "bytes": 234619
  },
  "verona": {
    "slug": "verona",
    "alt": "A serene view of a lake with house reflections and overcast skies.",
    "photographer": "JINISH RAJAGOPAL",
    "photographerUrl": "https://www.pexels.com/@jinish-rajagopal-2148784550",
    "source": "pexels",
    "query": "Verona New Jersey home",
    "bytes": 107044
  },
  "roselle-park": {
    "slug": "roselle-park",
    "alt": "Aerial view of urban residential apartments featuring an American flag, depicting city life.",
    "photographer": "Illya Goloborodko",
    "photographerUrl": "https://www.pexels.com/@illya-goloborodko-78974058",
    "source": "pexels",
    "query": "New Jersey suburb",
    "bytes": 143485
  },
  "cedar-grove": {
    "slug": "cedar-grove",
    "alt": "Aerial view of urban residential apartments featuring an American flag, depicting city life.",
    "photographer": "Illya Goloborodko",
    "photographerUrl": "https://www.pexels.com/@illya-goloborodko-78974058",
    "source": "pexels",
    "query": "New Jersey suburban street",
    "bytes": 143485
  },
  "caldwell": {
    "slug": "caldwell",
    "alt": "a white fire hydrant sitting on the side of a road",
    "photographer": "Suraj Tomer",
    "photographerUrl": "https://unsplash.com/@meditative",
    "source": "unsplash",
    "query": "Caldwell New Jersey street",
    "bytes": 424108
  },
  "glen-ridge": {
    "slug": "glen-ridge",
    "alt": "a house with a driveway and trees in front of it",
    "photographer": "Suraj Tomer",
    "photographerUrl": "https://unsplash.com/@meditative",
    "source": "unsplash",
    "query": "Glen Ridge New Jersey home",
    "bytes": 394647
  },
  "manhattan": {
    "slug": "manhattan",
    "alt": "Two doors on a brick building with windows.",
    "photographer": "Bradley Andrews",
    "photographerUrl": "https://unsplash.com/@bradleyandroos",
    "source": "unsplash",
    "query": "Manhattan New York City brownstone",
    "bytes": 382367
  },
  "brooklyn": {
    "slug": "brooklyn",
    "alt": "a building with many windows and a tree in front of it",
    "photographer": "Tyler Donaghy",
    "photographerUrl": "https://unsplash.com/@tylerdonaghy",
    "source": "unsplash",
    "query": "Brooklyn New York brownstone",
    "bytes": 276136
  },
  "queens": {
    "slug": "queens",
    "alt": "a city street lined with parked cars and tall buildings",
    "photographer": "Sebastian Enrique",
    "photographerUrl": "https://unsplash.com/@sebenrique12",
    "source": "unsplash",
    "query": "Queens New York street",
    "bytes": 364740
  },
  "the-bronx": {
    "slug": "the-bronx",
    "alt": "grayscale photo of power tool",
    "photographer": "Mike Von",
    "photographerUrl": "https://unsplash.com/@thevoncomplex",
    "source": "unsplash",
    "query": "Bronx New York apartment building",
    "bytes": 232623
  },
  "staten-island": {
    "slug": "staten-island",
    "alt": "Large stone house on the water's edge",
    "photographer": "Sebastian Enrique",
    "photographerUrl": "https://unsplash.com/@sebenrique12",
    "source": "unsplash",
    "query": "Staten Island New York home",
    "bytes": 350520
  }
} as unknown;

export interface CityImage {
  slug: string;
  alt: string;
  photographer: string;
  photographerUrl: string;
  source: 'unsplash' | 'pexels';
  query: string;
  bytes: number;
  gallery?: CityGalleryImage[];
}

export interface CityGalleryImage {
  src: string;
  alt: string;
  photographer: string;
  photographerUrl: string;
  source: 'unsplash' | 'pexels';
  query: string;
  width?: number;
  height?: number;
}

const MAP: Record<string, CityImage> = raw as Record<string, CityImage>;

export function getCityImage(slug: string): CityImage | undefined {
  return MAP[slug];
}

export function cityImageSrc(slug: string): string {
  return `/cities/${slug}.jpg`;
}

export function getCityGallery(slug: string): CityGalleryImage[] {
  return MAP[slug]?.gallery ?? [];
}
