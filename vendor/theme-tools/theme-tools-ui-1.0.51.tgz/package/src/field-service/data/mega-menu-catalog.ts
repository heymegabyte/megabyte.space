import { BLOG_POSTS } from './blog-posts.js';
import blogImagesManifest from './blog-images.js';

export interface MegaMenuCatalogItem {
  readonly id: string;
  readonly category: 'services' | 'blog' | 'cities' | 'company';
  readonly title: string;
  readonly href: string;
  readonly badge: string;
  readonly description: string;
  readonly featuredImage: string;
  readonly metaLabel: string;
}

export interface MegaMenuCategorySpec {
  readonly id: 'services' | 'blog' | 'cities' | 'company';
  readonly label: string;
  readonly eyebrow: string;
}

export const MEGA_MENU_CATEGORIES: readonly MegaMenuCategorySpec[] = [
  {
    id: 'services',
    label: 'Services & 3D Guides',
    eyebrow: 'FLAT $50/HR PROPERTY CREW',
  },
  {
    id: 'blog',
    label: 'Blog & Audio Guides',
    eyebrow: 'FIELD ARCHIVE & PODCASTS',
  },
  {
    id: 'cities',
    label: 'Newark & NJ/NYC Hubs',
    eyebrow: '51 SEED CITIES · 1,450 TOWNS',
  },
  {
    id: 'company',
    label: 'Dashboards & Company',
    eyebrow: 'PORTALS, PRICING & RESEARCH',
  },
] as const;

const BLOG_IMAGES = blogImagesManifest as Record<
  string,
  { slug: string; images: Array<{ src: string; alt: string }> } | undefined
>;

function buildFeaturedBlogItems(): readonly MegaMenuCatalogItem[] {
  const prioritySlugs = [
    'newark-power-washing-free-sample-work',
    'newark-power-washing-mistakes',
    'driveway-power-washing-equipment',
    'lawn-mowing-pricing-newark',
    'newark-hauling-disposal-guide',
    'gutter-cleaning-newark',
    'fence-repair-newark-light-carpentry',
  ];

  const picked = prioritySlugs
    .map((slug) => BLOG_POSTS.find((p) => p.slug === slug))
    .filter((p): p is NonNullable<typeof p> => Boolean(p));

  const fallbackImages: Record<string, string> = {
    'newark-power-washing-free-sample-work': '/guides/power-washing/hero.jpg',
    'newark-power-washing-mistakes': '/guides/power-washing/surface-cleaner.jpg',
    'driveway-power-washing-equipment': '/guides/power-washing/machine-gas.jpg',
    'lawn-mowing-pricing-newark': '/cities/newark/3.jpg',
    'newark-hauling-disposal-guide': '/cities/newark/local-2.jpg',
    'gutter-cleaning-newark': '/cities/newark/local-4.jpg',
    'fence-repair-newark-light-carpentry': '/cities/newark/local-1.jpg',
  };

  const items: MegaMenuCatalogItem[] = picked.slice(0, 6).map((post) => {
    const rawManifestImg = BLOG_IMAGES[post.slug]?.images?.[0]?.src;
    const manifestImg = rawManifestImg
      ? rawManifestImg.replace(/^\/blog-images\//, '/guides/blog-images/')
      : undefined;
    const featuredImage =
      manifestImg ?? fallbackImages[post.slug] ?? '/guides/power-washing/hero.jpg';
    return {
      id: `blog-${post.slug}`,
      category: 'blog',
      title: post.title,
      href: `/blog/${post.slug}`,
      badge: `${post.category.toUpperCase()} · PODCAST`,
      description: post.excerpt,
      featuredImage,
      metaLabel: `${post.readMinutes} read · Spoken Audio Guide`,
    };
  });

  items.push({
    id: 'blog-index-all',
    category: 'blog',
    title: 'Explore All Blog Articles & Spoken Podcasts →',
    href: '/blog',
    badge: 'FULL FIELD ARCHIVE',
    description:
      'Browse every Newark & NJ property care guide, $50/hr cost breakdown, and WebGL spoken audio briefing.',
    featuredImage: '/guides/power-washing/dry-sweep.jpg',
    metaLabel: '2,000+ Word Guides · Citations Included',
  });

  return items;
}

export const UNIVERSAL_MEGA_MENU_ITEMS: readonly MegaMenuCatalogItem[] = [
  // 1. Core Services & 3D Solutions Matrix
  {
    id: 'svc-flagship-sample',
    category: 'services',
    title: 'Newark Power Washing — Free 2ft × 2ft Sample Spot First',
    href: '/c/newark/power-washing/newark-power-washing-free-sample-work',
    badge: '★ FLAGSHIP GUIDE · FREE SAMPLE',
    description:
      'We wash a free 2ft × 2ft sample patch on your Newark brick, brownstone, bluestone, or concrete driveway before finishing at $50/hr.',
    featuredImage: '/guides/power-washing/hero.jpg',
    metaLabel: '$50/hr per worker · $0 travel & gear fee',
  },
  {
    id: 'svc-power-washing',
    category: 'services',
    title: 'Power Washing & Gentle Masonry Soft-Wash',
    href: '/services/power-washing',
    badge: 'POWER WASHING · $50/HR',
    description:
      '4.0 GPM commercial rotary surface cleaner for driveways & sidewalks plus gentle low-pressure soft-washing for brick and siding.',
    featuredImage: '/guides/power-washing/surface-cleaner.jpg',
    metaLabel: '1-hr minimum · 15-min increments',
  },
  {
    id: 'svc-lawn-care',
    category: 'services',
    title: 'Lawn Care, Mowing, Mulch & Seasonal Yard Cleanups',
    href: '/services/lawn-care',
    badge: 'LAWN & YARD · $50/HR',
    description:
      'Mowing, string-trimming, hedge shaping, spring/fall leaf cleanups, and mulch installation across Newark and Essex County.',
    featuredImage: '/cities/newark/3.jpg',
    metaLabel: 'Standing weekly (-8%) & biweekly (-5%) plans',
  },
  {
    id: 'svc-hauling',
    category: 'services',
    title: 'Hauling, Junk Removal, Moving Labor & Cleanouts',
    href: '/services/hauling',
    badge: 'MOVING & HAULING · $50/HR',
    description:
      'Walk-up apartment moves, U-Haul & PODS loading/unloading, basement/estate cleanouts, and heavy furniture carry.',
    featuredImage: '/cities/newark/local-2.jpg',
    metaLabel: 'Dollies, moving pads & straps included ($0)',
  },
  {
    id: 'svc-light-repairs',
    category: 'services',
    title: 'Light Repairs, Gutter Cleaning, Fence & TV Mounting',
    href: '/services/light-repairs',
    badge: 'LIGHT REPAIRS · $50/HR',
    description:
      'Gutter cleanouts, fence gate & picket repairs, TV/shelf wall mounting, weatherstripping, and punch-list handyman work.',
    featuredImage: '/cities/newark/local-4.jpg',
    metaLabel: 'Licensed NJ Home Improvement Contractor',
  },
  {
    id: 'svc-walkup-brigade',
    category: 'services',
    title: '3-Movers-4-Hours Walk-Up & Brownstone Brigade',
    href: '/for/3-movers-4-hours-walkup-brigade',
    badge: 'CREW × HOUR BLOCK · $600',
    description:
      'Our high-output 3-worker, 4-hour crew block engineered for 3rd/4th-floor walk-ups, brownstone stoops, and 26ft truck loads.',
    featuredImage: '/cities/newark/local-1.jpg',
    metaLabel: '3 Crew × 4 Hours @ $50/hr ($600 total)',
  },
  {
    id: 'svc-matrix-hub',
    category: 'services',
    title: 'All 30 Solutions Matrix & Specialty Guides →',
    href: '/for',
    badge: '7-AXIS SOLUTIONS MATRIX',
    description:
      'Compose any 3D landing guide by NJ/NYC town, work type, building archetype, container, or crew × hour block.',
    featuredImage: '/guides/power-washing/machine-gas.jpg',
    metaLabel: '1,450 Towns × 9 Work Types × 30 Modifiers',
  },

  // 2. Blog Articles & Audio Field Guides
  ...buildFeaturedBlogItems(),

  // 3. Newark & NJ/NYC City Hubs & Sub-Pages
  {
    id: 'city-newark',
    category: 'cities',
    title: 'Newark, NJ Home Base (Ironbound, Forest Hill, Central Ward)',
    href: '/c/newark',
    badge: 'HOME BASE · $0 TRAVEL FEE',
    description:
      'Dispatched directly from our Newark home base across all 5 wards — Ironbound, Forest Hill, University Heights, Roseville & Vailsburg.',
    featuredImage: '/cities/newark/hero.jpg',
    metaLabel: '0 mi from Newark · Same-day & next-day slots',
  },
  {
    id: 'city-jersey-city',
    category: 'cities',
    title: 'Jersey City, NJ (Downtown, Paulus Hook, The Heights)',
    href: '/c/jersey-city',
    badge: 'HUDSON COUNTY · $50/HR',
    description:
      'High-rise COI moving labor, brownstone stoop washing, and backyard patio cleanups across Jersey City.',
    featuredImage: '/cities/jersey-city/hero.jpg',
    metaLabel: '7 mi from Newark · $0 travel fee',
  },
  {
    id: 'city-hoboken',
    category: 'cities',
    title: 'Hoboken, NJ Walk-Ups, Brownstones & Courtyard Patios',
    href: '/c/hoboken',
    badge: 'HUDSON COUNTY · $50/HR',
    description:
      'Mile-Square walk-up moving brigades, bluestone stoop soft-washing, and temporary parking-permit coordination.',
    featuredImage: '/cities/hoboken/hero.jpg',
    metaLabel: '8 mi from Newark · $0 travel fee',
  },
  {
    id: 'city-montclair',
    category: 'cities',
    title: 'Montclair, NJ Victorian Porches, Driveways & Lawn Care',
    href: '/c/montclair',
    badge: 'ESSEX COUNTY · $50/HR',
    description:
      'Gentle historic brick & bluestone washing, large-lot leaf cleanups, and estate moving labor in Montclair.',
    featuredImage: '/cities/montclair/hero.jpg',
    metaLabel: '6 mi from Newark · $0 travel fee',
  },
  {
    id: 'subpage-buildings',
    category: 'cities',
    title: '25 Named NJ High-Rise Building COI & Freight Guides',
    href: '/buildings',
    badge: 'BUILDING COI REGISTRY',
    description:
      'Pre-mapped freight elevator dimensions, loading dock windows, and $1M–$5M Certificate of Insurance templates.',
    featuredImage: '/cities/newark/local-1.jpg',
    metaLabel: 'Newark, Jersey City, Hoboken & Fort Lee towers',
  },
  {
    id: 'subpage-vs',
    category: 'cities',
    title: 'Brick Labor ($50/hr) vs. National Gig Apps (/vs)',
    href: '/vs',
    badge: 'SIDE-BY-SIDE COMPARISON',
    description:
      'Compare our flat $50/hr W-2/vetted Newark crew against Lugg, Dolly, TaskRabbit, Bellhop, and franchise wash rigs.',
    featuredImage: '/guides/power-washing/machine-electric.jpg',
    metaLabel: 'Zero platform fees · Zero surprise surcharges',
  },

  // 4. Dashboards, Tools & Company Pages
  {
    id: 'co-dashboard',
    category: 'company',
    title: 'Unified Customer, Crew & Admin Operations Dashboard',
    href: '/dashboard',
    badge: 'LIVE OPERATIONS COCKPIT',
    description:
      'Manage bookings, live crew dispatch calendar, quotes, recurring schedules, billing, and property sites in one place.',
    featuredImage: '/cities/newark/hero.jpg',
    metaLabel: 'Role-aware portal · Instant demo sign-in available',
  },
  {
    id: 'co-book',
    category: 'company',
    title: 'Live 60-Second Online Booking & Crew Calendar',
    href: '/book',
    badge: 'BOOK ONLINE · $50/HR',
    description:
      'Pick your crew size (1–4 workers), hours, one-time or recurring cadence (up to 12% off), and lock in your window.',
    featuredImage: '/guides/power-washing/hero.jpg',
    metaLabel: '1-hr minimum · 15-min increments after hr 1',
  },
  {
    id: 'co-pricing',
    category: 'company',
    title: 'Transparent $50/hr Pricing, Bundles & Calculator',
    href: '/#pricing',
    badge: 'HONEST HOURLY METER',
    description:
      'See exactly what 1 to 4 crew members accomplish in 1 to 4 hours, plus prepay bundles and standing recurring discounts.',
    featuredImage: '/guides/power-washing/surface-cleaner.jpg',
    metaLabel: 'Daily -12% · Weekly -8% · Biweekly -5% · Monthly -3%',
  },
  {
    id: 'co-sources',
    category: 'company',
    title: 'Verified Research Library & Municipal Citations',
    href: '/sources',
    badge: 'PRIMARY SOURCES & DATA',
    description:
      'Explore our full bibliography of U.S. Census ACS, BLS, National Park Service masonry briefs, EPA Safer Choice, and NJ DCA standards.',
    featuredImage: '/cities/newark/local-4.jpg',
    metaLabel: 'Fact-checked quarterly by Newark Operations',
  },
  {
    id: 'co-apply',
    category: 'company',
    title: 'Join the Crew ($25–$32/hr + 100% of Customer Tips)',
    href: '/apply',
    badge: 'HIRING IN NEWARK NJ',
    description:
      'Apply to join Brick Labor’s Newark property crew — transparent W-2/vetted pay, instant payouts, and performance bonuses.',
    featuredImage: '/cities/newark/local-2.jpg',
    metaLabel: 'Newark dispatch base · Flexible shifts',
  },
  {
    id: 'co-contact',
    category: 'company',
    title: 'Contact Us, Live AI Concierge & Direct Dispatch Line',
    href: '/contact',
    badge: '(855) 82LABOR · 24/7',
    description:
      'Chat with our live AI estimator, text photos of your project, or call (855) 82LABOR for immediate Newark dispatch help.',
    featuredImage: '/cities/newark/3.jpg',
    metaLabel: 'hey@bricklabor.com · (855) 825-2267',
  },
] as const;
