/**
 * Wikimedia Commons / archival attribution for neighborhood hero photos.
 *
 * If a neighborhood has no entry here, the page inherits its parent city's
 * hero from `src/data/city-images.ts`. We never ship AI-generated imagery
 * on these geographic surfaces — real photo or city fallback only.
 */

export interface NeighborhoodCredit {
  /** /c/<city>/<slug> */
  citySlug: string;
  nbSlug: string;
  /** Public path under /neighborhoods/<city>/<slug>/hero.jpg */
  src: string;
  alt: string;
  /** "Author · Source · License · Year" */
  credit: string;
  sourceUrl: string;
}

export const NEIGHBORHOOD_CREDITS: NeighborhoodCredit[] = [
  // No primary-sourced photos shipped in this batch — all 45 new
  // neighborhoods inherit their parent city's hero image. Future passes
  // should populate Wikimedia Commons sourced hero shots here.
];

export function getNeighborhoodCredit(
  citySlug: string,
  nbSlug: string,
): NeighborhoodCredit | undefined {
  return NEIGHBORHOOD_CREDITS.find((c) => c.citySlug === citySlug && c.nbSlug === nbSlug);
}
