export interface NewarkNeighborhood {
  slug: string;
  name: string;
  tagline?: string;
  zipCodes?: string[];
  [key: string]: unknown;
}
export const NEWARK_NEIGHBORHOODS: NewarkNeighborhood[] = [
  {
    "slug": "ironbound",
    "name": "Ironbound",
    "title": "Ironbound Newark Crew · Power Wash + Cleanouts · $50/hr",
    "description": "Ironbound rowhouse stoops, narrow side yards, basement cleanouts. Local Newark crew, $50/hr per person, flat. Ferry St to Penn Station coverage.",
    "h1": "Ironbound Newark — stoops, side yards, and basement cleanouts.",
    "lede": "Ferry Street rowhouses, brick fronts gray from decades of curbside diesel, and basements stacked deep with the last tenant's leftovers. Ironbound jobs are dense work — narrow staircases, stoop washing under power lines, alternate-side parking, and Portuguese-bakery foot traffic on weekends. We know the block layout and the parking schedule.",
    "streets": [
      "Ferry Street",
      "Wilson Avenue",
      "Lafayette Street",
      "Pacific Street",
      "Walnut Street",
      "Adams Street"
    ],
    "landmarks": [
      "Penn Station",
      "Independence Park",
      "Riverbank Park",
      "Ironbound Stadium",
      "Peter Francisco Park"
    ],
    "homeStock": "Two- and three-family brick rowhouses on 25-foot lots, parlor floors set 8–10 stairs above the sidewalk, full basements at street level.",
    "jobs": [
      "Stoop power-washing",
      "Brick-front rinse",
      "Basement cleanouts",
      "Side-alley clearing",
      "Roof-deck rinse"
    ],
    "jobsParagraph": "Most Ironbound calls are two-person basement cleanouts where the staircase turns hard at the landing and we have to dolly furniture up to the sidewalk. Stoop power-washing is the second most common — Ferry Street stoops collect a year of grime fast. We stage the truck on the corner if your block is full and walk the gear in.",
    "access": "Most blocks are alternate-side Tuesday/Thursday or Wednesday/Friday — we know the schedule. Permit zones run east of Lafayette. Walnut Street and Adams Street usually have a meter we can park at while we work.",
    "faq": [
      {
        "q": "Can you work around the Ferry Street weekend traffic?",
        "a": "Yes. Saturday and Sunday before noon are quietest — we book those slots first for Ferry Street stoop work and any job that needs the truck on the curb. Weekday mornings before 10 also work fine."
      },
      {
        "q": "My basement door is around the side. Can your crew get a couch out?",
        "a": "If the side gate clears 30 inches we can usually get a couch out the side door without taking the front door off its hinges. Send us a photo at booking and we'll bring the right number of crew."
      },
      {
        "q": "Do you do roof-deck cleaning on Ferry Street rowhouses?",
        "a": "Yes — soft-wash on the deck boards and a 25-degree tip on the parapet wall. We bring 50 ft of high-pressure hose so we can run from the basement spigot up four flights without damaging anything."
      },
      {
        "q": "How fast can you start in the Ironbound?",
        "a": "Same-day or next-day for jobs under 2 hours. Bigger cleanouts usually book within 2–4 days. We dispatch from Newark proper so there's no travel surcharge anywhere east of McCarter Highway."
      }
    ],
    "center": {
      "lat": 40.7282,
      "lng": -74.1499
    },
    "ogTagline": "Ironbound stoops + cleanouts — $50/hr"
  },
  {
    "slug": "forest-hill",
    "name": "Forest Hill",
    "title": "Forest Hill Newark Crew · $50/hr · Same-Week Booking",
    "description": "Forest Hill backyard cleanups, deck rinses, gutter cleanouts on the leafy blocks east of Branch Brook. Local Newark crew, $50/hr per person, flat.",
    "h1": "Forest Hill Newark — yards, decks, and gutters east of Branch Brook.",
    "lede": "Heller Parkway and the blocks running off it are the closest thing Newark has to a quiet leafy neighborhood. Mature oaks, brick colonials, real driveways, and a yearly leaf load that fills gutters faster than anywhere else in the city. Most Forest Hill jobs are seasonal: spring rinse, summer fence work, fall gutter and leaf, December prep.",
    "streets": [
      "Heller Parkway",
      "Mount Prospect Avenue",
      "Ballantine Parkway",
      "Park Avenue",
      "Highland Avenue"
    ],
    "landmarks": [
      "Branch Brook Park",
      "Ballantine Mansion",
      "Forest Hill Field Club",
      "Cathedral Basilica"
    ],
    "homeStock": "Brick and stone colonials on 50-foot lots, full driveways, mature plantings, fenced back yards 80–100 feet deep.",
    "jobs": [
      "Backyard leaf cleanups",
      "Gutter and downspout flush",
      "Deck power-washing",
      "Driveway rinse",
      "Hedge and shrub trimming"
    ],
    "jobsParagraph": "Forest Hill jobs are bigger than Ironbound but simpler — full driveway access, no permit issues, and most yards run a single crew. Fall is our busiest Forest Hill season: oak and London-plane leaves fill 30 contractor bags a yard. Spring brings the deck rinse and the first lawn-edge clean.",
    "access": "Driveway access on every block. No permit zones. We stage on the driveway pad and load directly. Heller Parkway median makes for easy turnaround if a yard waste truck needs to drop bags.",
    "faq": [
      {
        "q": "Will you haul the leaf bags or do I leave them at the curb?",
        "a": "Either way. Newark sanitation picks up bagged leaves on the regular schedule — we can stack them at the curb. If you want them hauled same day, add hauling at booking and we take everything to the transfer station for an extra $30 dump fee."
      },
      {
        "q": "How long does a typical Forest Hill backyard cleanup take?",
        "a": "A standard 80×30 yard takes 2 hours with one crew, 1 hour with two. Bigger lots (100+ ft) or yards with 5+ trees go 3–4 hours. We charge by the hour, so you only pay for actual time on site."
      },
      {
        "q": "Do you pressure wash brick fronts on Heller Parkway?",
        "a": "Yes. Most Heller Parkway brick is hard-fired and takes a 25-degree tip at 3,000 PSI without spalling. We pre-rinse the foundation plantings and post-rinse to dilute the soft-wash mildewcide."
      },
      {
        "q": "Can you trim the front-yard hedge along Heller?",
        "a": "Up to 8 feet, yes — we bring an extension hedge trimmer and a 6-foot ladder. Anything taller (privet hedges that have run wild for years) needs a tree-care company because of the chainsaw work and the haul."
      }
    ],
    "center": {
      "lat": 40.7711,
      "lng": -74.1748
    },
    "ogTagline": "Forest Hill yards + decks — $50/hr"
  },
  {
    "slug": "north-newark",
    "name": "North Newark",
    "title": "North Newark Crew · Yards, Hauling, Repairs · $50/hr",
    "description": "North Newark backyard cleanups, garage hauls, fence and gutter work west of Branch Brook. Local crew, $50/hr per person, flat. Same-week booking.",
    "h1": "North Newark — yards, hauling, and small repairs west of the park.",
    "lede": "The blocks running west off Mount Prospect Avenue are mostly two- and three-family wood-frames with side driveways and 60-foot back yards. North Newark jobs split between yard-and-hauling work in the warm months and basement-and-garage cleanouts in the cold ones. Branch Brook Park keeps the leaf load high every fall.",
    "streets": [
      "Mount Prospect Avenue",
      "Park Avenue",
      "Verona Avenue",
      "Lake Street",
      "7th Avenue",
      "Summer Avenue"
    ],
    "landmarks": [
      "Branch Brook Park",
      "Branch Brook Park Lake",
      "St. Lucy's Church",
      "Lake Street Park"
    ],
    "homeStock": "Two- and three-family wood-frames on 30-foot lots, brick colonials in the upper blocks, full side driveways and detached garages.",
    "jobs": [
      "Backyard cleanouts",
      "Garage hauling",
      "Gutter cleaning",
      "Fence repair",
      "Driveway rinse"
    ],
    "jobsParagraph": "Most North Newark calls are spring or fall yard cleanouts plus garage hauls. Mount Prospect Avenue blocks have detached garages that haven't been cleaned out since the last owner — we usually load 30–50 contractor bags plus 4–6 large items per garage. Fence repairs along the back property line are common after winter storms.",
    "access": "Side driveways on most blocks. Permit parking only on the south end near Verona Avenue. Mount Prospect and Summer Avenue have meter parking we use during business hours.",
    "faq": [
      {
        "q": "My garage hasn't been opened in 5 years. Can you handle the whole thing?",
        "a": "Yes — that's a 4–6 hour job for two crew, usually. We sort what stays, what goes, and what gets donated. Junk hauling adds the dump fee on top of labor. We've done dozens of these on Mount Prospect alone."
      },
      {
        "q": "Will the cherry-blossom traffic in April mess up my booking?",
        "a": "We avoid Sunday afternoons during peak bloom (usually mid-April) but most weekday mornings work fine. The Lake Street and 7th Avenue side of the park is less affected than Park Avenue itself."
      },
      {
        "q": "Can you fix a leaning back-yard fence section?",
        "a": "Yes — we re-plumb posts, replace cracked rails, and swap a panel if you have a spare. We don't pour new concrete footings (that needs a licensed contractor); for a quick re-set we use Sika Fast-Set in the existing hole."
      },
      {
        "q": "How early can you arrive?",
        "a": "We can be on site as early as 7 AM in North Newark — we dispatch from Newark proper. For loud work (power washing, hedge trimming) we usually wait until 8 AM out of respect for neighbors."
      }
    ],
    "center": {
      "lat": 40.7647,
      "lng": -74.1851
    },
    "ogTagline": "North Newark yards + hauls — $50/hr"
  },
  {
    "slug": "vailsburg",
    "name": "Vailsburg",
    "title": "Vailsburg Newark Crew · $50/hr · Property Help, Same Week",
    "description": "Vailsburg lawn care, gutters, hauling, and basement cleanouts off South Orange Ave. Newark crew, $50/hr per person, flat. Local fast booking.",
    "h1": "Vailsburg — lawns, gutters, and basements off South Orange Ave.",
    "lede": "The blocks running south off South Orange Avenue between Sanford and Mount Vernon are Vailsburg — two-family wood-frames, brick capes, full driveways, real grass yards. The work here is suburban-pattern: regular lawn care, fall gutter cleans, and basement cleanouts when a tenant moves out.",
    "streets": [
      "South Orange Avenue",
      "Sanford Avenue",
      "Mount Vernon Place",
      "Ivy Street",
      "Stuyvesant Avenue"
    ],
    "landmarks": [
      "Vailsburg Park",
      "Ivy Hill Park",
      "Seton Hall Prep area",
      "St. Antoninus Church"
    ],
    "homeStock": "Two-family wood-frames on 35-foot lots, brick capes and bungalows, full driveways and small detached garages.",
    "jobs": [
      "Lawn cuts and edging",
      "Gutter cleaning",
      "Basement cleanouts",
      "Driveway and walkway washing",
      "Fence and shed repair"
    ],
    "jobsParagraph": "Vailsburg jobs lean toward repeat lawn care plus seasonal extras. We'll do the spring cleanup, the every-2-week summer cut, the fall gutter, and the December basement clean — same family, same crew, same flat rate. Most yards run 2,000–4,000 sq ft and finish in 60–90 minutes.",
    "access": "Full driveway access on virtually every block. No permit issues. South Orange Avenue is busy but we stage on the side streets.",
    "faq": [
      {
        "q": "Do you do biweekly lawn care in Vailsburg?",
        "a": "Yes. We schedule a recurring slot — usually Tuesday or Thursday morning — and bill at the same $50/hr per person. Most yards take one crew 60 minutes including blow-down. No contract, you can cancel any time."
      },
      {
        "q": "How much does a basement cleanout run on Stuyvesant Avenue?",
        "a": "Most two-family basements run 3–4 hours for two crew — call it $300–400 in labor plus the dump fee (usually $40–80 depending on volume). If there's appliance disposal we add the certified-disposal fee for fridges/freezers."
      },
      {
        "q": "Will you haul the dead branches from the storm last week?",
        "a": "Yes. We cut anything under 6 inches in diameter with a battery saw, bundle it, and haul it to the transfer station. Anything bigger we recommend a tree-care company because of the rope work and the chipper."
      },
      {
        "q": "Can you do gutter work on a two-story Vailsburg cape?",
        "a": "Yes — most two-story Vailsburg homes top out at 22 feet at the eave, which is in range for our 28-foot extension ladder. We hand-clean the gutters, flush them with a hose, and check the downspout flow."
      }
    ],
    "center": {
      "lat": 40.7449,
      "lng": -74.2293
    },
    "ogTagline": "Vailsburg lawn + gutter — $50/hr"
  },
  {
    "slug": "weequahic",
    "name": "Weequahic",
    "title": "Weequahic Newark Crew · Yards, Hauling + Cleanouts · $50/hr",
    "description": "Weequahic backyard cleanups, gutter cleaning, hauling around Weequahic Park. Local Newark crew, $50/hr per person, flat. Same-week booking.",
    "h1": "Weequahic — yards, gutters, and hauling around the park.",
    "lede": "The blocks ringing Weequahic Park — Elizabeth Avenue, Lyons, Chancellor, Hawthorne — are mostly brick three-flats and pre-war wood-frames with mature trees. The work here is yard-heavy: heavy fall leaf loads from the park-side oaks, gutter cleans every season, and basement and garage cleanouts year-round.",
    "streets": [
      "Elizabeth Avenue",
      "Lyons Avenue",
      "Chancellor Avenue",
      "Hawthorne Avenue",
      "Bergen Street"
    ],
    "landmarks": [
      "Weequahic Park",
      "Weequahic Park Golf Course",
      "Bethany Cemetery",
      "Beth Israel Hospital"
    ],
    "homeStock": "Brick three-flats on 30-foot lots, pre-war wood-frames near Bergen Street, mature street trees on every block.",
    "jobs": [
      "Backyard leaf cleanups",
      "Gutter cleaning",
      "Basement and garage hauls",
      "Driveway rinse",
      "Hedge trimming"
    ],
    "jobsParagraph": "Weequahic's park-side trees mean fall here is a multi-truckload leaf job — most blocks need 30–60 bags a yard. Lyons and Chancellor have the heaviest leaf load. Three-flat basements off Bergen Street are usually deep cleanouts because the basement runs full-footprint and never gets touched between tenants.",
    "access": "Most blocks have driveway access. Elizabeth Avenue is permit-only — we stage on the side streets. Lyons and Chancellor have meter parking near the park entrance.",
    "faq": [
      {
        "q": "How many bags does a typical Weequahic Park-side yard fill in fall?",
        "a": "Most yards on Lyons or Chancellor fill 30–50 contractor bags per pickup in November. Yards with a single oak go higher — 60+ bags. We size the crew so it finishes in one visit."
      },
      {
        "q": "Is there meter parking near Weequahic Park for your truck?",
        "a": "Yes — Elizabeth Avenue has meter pull-ins along the park edge that fit our cargo van. We pay the meter while we work; if it's a longer job we ask the homeowner to leave their driveway open."
      },
      {
        "q": "Will you do a full three-flat basement cleanout?",
        "a": "Yes — that's 4–6 hours for two crew on a typical Weequahic three-flat. We sort by floor (top tenant's stuff vs. bottom tenant's stuff), bag the rest, and load the truck."
      },
      {
        "q": "Can you trim the privet hedge along the property line?",
        "a": "Up to 8 feet with battery hedge trimmer and pole hedger. Anything older or taller (10+ feet of overgrown privet) is a chainsaw + tarp job — we can quote that as a separate visit."
      }
    ],
    "center": {
      "lat": 40.7066,
      "lng": -74.2018
    },
    "ogTagline": "Weequahic yards + hauling — $50/hr"
  }
];
export function getNeighborhood(slug: string): NewarkNeighborhood | undefined {
  return NEWARK_NEIGHBORHOODS.find((n) => n.slug === slug);
}
