/**
 * Power-Washing Standard Operating Procedure.
 *
 * Structured data for the /guides/power-washing operational manual — used by
 * both the customer-facing transparency page and the field SOP surface.
 *
 * Editing rules:
 * - Raw Unicode only in string literals: use "→", "·", "×", "–", "…" not
 *   HTML entities. The registry test enforces this.
 * - Keep step arrays flat; do NOT nest sub-sequences. If a sub-flow is
 *   needed, add another entry to SEQUENCES with its own id.
 * - Every SEQUENCES entry MUST reference a valid Surface id and Contaminant
 *   id; the test suite fails otherwise.
 * - Every entry MUST have a non-empty `expected` string so the customer-
 *   facing card always shows a realistic outcome.
 */

/* ─────────────────────────────────────────────────────────────────────────
 * MACHINES — equipment classes carried by every Brick Labor crew
 * ─────────────────────────────────────────────────────────────────────── */

export type MachineId = 'gas-4000' | 'electric-1900';

export interface Machine {
  readonly id: MachineId;
  readonly displayName: string;
  readonly shortName: string;
  readonly power: string;
  readonly type: 'gas' | 'electric';
  readonly summary: string;
  readonly bestFor: readonly string[];
  readonly avoidWhen: readonly string[];
  readonly examples: readonly string[];
}

export const MACHINES: readonly Machine[] = [
  {
    id: 'gas-4000',
    displayName: 'Simpson Pro Series gas pressure washer',
    shortName: 'Gas washer',
    power: '~4,000 PSI machine capacity · ~3.5 GPM',
    type: 'gas',
    summary:
      'The high-flow production machine. Its real advantage is GPM and its ability to run the 24-inch surface cleaner — not the 4,000 PSI headline number. We choose it when the JOB SIZE justifies the setup.',
    bestFor: [
      'Long concrete driveways',
      'Commercial sidewalks and storefronts',
      'Parking lots and dumpster pads',
      'Any surface-cleaner work on durable flatwork',
      'Long hose runs',
      'Large rinsing volumes',
      'Extension-wand work on siding and elevated surfaces',
      'Heavy contamination on durable surfaces AFTER correct pretreatment',
    ],
    avoidWhen: [
      'Small patios and porches',
      'Delicate paint, wood, or coatings',
      'Manufacturer-restricted furniture and fixtures',
      'Small residential detail sections',
      'Anywhere the setup overhead outweighs the productivity gain',
    ],
    examples: [
      '80-ft residential concrete driveway',
      '24-inch surface-clean pass on a 2,000 sqft sidewalk',
      'Vinyl siding house wash with the extension wand',
      'Restaurant dumpster pad after solids removal',
    ],
  },
  {
    id: 'electric-1900',
    displayName: '1,900 PSI electric pressure washer',
    shortName: 'Electric washer',
    power: '~1,900 PSI · lower GPM · compact',
    type: 'electric',
    summary:
      'The professional choice for small, delicate, and detail work. Lower flow, faster setup, quieter, and less chance of surface damage. Choosing it is a signal that we care about the surface — not a sign we brought less equipment.',
    bestFor: [
      'Small patios and porches',
      'Delicate residential siding sections',
      'Light dirt and light rinsing',
      'Compatible outdoor furniture',
      'Detail work after the gas washer finishes production',
      'Small painted surfaces after a test area',
      'Controlled final rinse on delicate materials',
    ],
    avoidWhen: [
      'Any job requiring the 24-inch surface cleaner',
      'Long concrete flatwork where production speed matters',
      'Heavy grease, deep organic staining, or long hose runs',
    ],
    examples: [
      'Small front porch clean-off',
      'Light siding rinse after algae treatment',
      'Detail edging after gas-washer surface-clean pass',
      'Small compatible patio furniture set',
    ],
  },
];

/* ─────────────────────────────────────────────────────────────────────────
 * ADDITIONAL EQUIPMENT — carried on the truck for every real job
 * ─────────────────────────────────────────────────────────────────────── */

export interface EquipmentGroup {
  readonly heading: string;
  readonly items: readonly string[];
}

export const EQUIPMENT: readonly EquipmentGroup[] = [
  {
    heading: 'Cleaning heads and tips',
    items: [
      'Garvee 24-inch surface cleaner',
      'Integrated / compatible water broom',
      'Standard pressure-washer wand',
      '24-foot pressure-washing extension wand',
      'Wide-fan tips (25° / 40°)',
      'Soap / low-pressure application tip',
      'Downstream chemical injector',
    ],
  },
  {
    heading: 'Hose and supply',
    items: [
      'Garden hose',
      'High-pressure hose',
      'Quick-connect fittings',
      'Replacement O-rings',
      'Flow / pressure measurement equipment for troubleshooting water supply',
    ],
  },
  {
    heading: 'Chemistry application',
    items: [
      'Bleach-compatible chemical sprayer',
      'Degreaser sprayer',
      'Enzyme / odor-treatment sprayer',
    ],
  },
  {
    heading: 'Manual and safety',
    items: [
      'Brushes and brooms',
      'Push broom, dustpan, shovel for heavy debris',
      'Cones, tape, or signage for pedestrian control',
      'Eye protection, ear protection, gloves',
    ],
  },
];

/* ─────────────────────────────────────────────────────────────────────────
 * MASTER WORKFLOW — the 29-step universal job flow, in order
 * ─────────────────────────────────────────────────────────────────────── */

export interface WorkflowStep {
  readonly n: number;
  readonly title: string;
  readonly detail: string;
}

export const MASTER_WORKFLOW: readonly WorkflowStep[] = [
  {
    n: 1,
    title: 'Inspect',
    detail: 'Walk the site. Note surfaces, hazards, delicate coatings, drainage.',
  },
  { n: 2, title: 'Photograph', detail: 'Timestamped before-photos for every zone we will touch.' },
  {
    n: 3,
    title: 'Identify surface',
    detail: 'Concrete, asphalt, paver, brick, siding, wood — each has its own rules.',
  },
  {
    n: 4,
    title: 'Identify contamination',
    detail: 'Loose dirt, organic growth, oil, food grease, urine, gum, rust, efflorescence, paint.',
  },
  {
    n: 5,
    title: 'Choose machine',
    detail: 'Gas washer for production; electric for delicate or small work.',
  },
  {
    n: 6,
    title: 'Choose cleaning tool',
    detail: 'Surface cleaner, wand, water broom, extension wand — match the tool to the surface.',
  },
  {
    n: 7,
    title: 'Establish runoff plan',
    detail: 'Where does the water go? Protect storm drains and vegetation. Direct sediment.',
  },
  {
    n: 8,
    title: 'Remove loose debris',
    detail:
      'Manual pickup of trash, food debris, gravel, mulch, cigarette butts before any water hits the surface.',
  },
  {
    n: 9,
    title: 'Dry sweep or blow',
    detail: 'Broom or leaf blower to remove remaining loose material.',
  },
  {
    n: 10,
    title: 'Protect surrounding property',
    detail: 'Wet plants, cover electrical, close windows, move fragile items when possible.',
  },
  {
    n: 11,
    title: 'Establish water supply',
    detail: 'Confirm continuous adequate flow — not just static pressure.',
  },
  {
    n: 12,
    title: 'Purge air',
    detail: 'Water fully ON, trigger open, engine or motor OFF. No pump-dry starts.',
  },
  {
    n: 13,
    title: 'Test equipment',
    detail: 'Stable stream, correct nozzle, no leaks, chemical draw as expected.',
  },
  {
    n: 14,
    title: 'Test inconspicuous area',
    detail: 'Verify the chosen chemistry / pressure combination on a hidden section first.',
  },
  {
    n: 15,
    title: 'Pretreat only where useful',
    detail: 'Do not spray chemical over the whole property when spot treatment will do.',
  },
  { n: 16, title: 'Allow dwell', detail: 'Chemistry needs time. Never dry-rush a chemical.' },
  {
    n: 17,
    title: 'Agitate where useful',
    detail: 'Brush or broom the areas that need it, before mechanical cleaning.',
  },
  {
    n: 18,
    title: 'Perform primary mechanical cleaning',
    detail: 'Surface cleaner, wand, or water broom — the main production pass.',
  },
  {
    n: 19,
    title: 'Detail edges and corners',
    detail: 'Hand-clean boundaries the surface cleaner cannot safely reach.',
  },
  {
    n: 20,
    title: 'Disable chemical feed',
    detail: 'Chemical draw OFF before rinse, water-broom, or plain-water passes.',
  },
  { n: 21, title: 'Rinse', detail: 'Move loosened dirt off the surface with plain water.' },
  {
    n: 22,
    title: 'Water-broom broad areas where appropriate',
    detail: 'Push dirty water off flatwork to a controlled runoff point.',
  },
  {
    n: 23,
    title: 'Allow partial dry-down',
    detail: 'Some staining and stripes only appear as the surface dries.',
  },
  {
    n: 24,
    title: 'Inspect for stripes, missed contamination, residue',
    detail: 'A dry-inspection is required before we call the job done.',
  },
  { n: 25, title: 'Spot-correct', detail: 'Return to any zone that dry-inspection flagged.' },
  {
    n: 26,
    title: 'Final rinse if necessary',
    detail: 'Only if spot-correction added chemistry or debris back to the surface.',
  },
  { n: 27, title: 'Final photos', detail: 'Timestamped after-photos for every zone we touched.' },
  {
    n: 28,
    title: 'Flush equipment',
    detail: 'Clear the injector, wind hoses, drain the machine per manufacturer instructions.',
  },
  {
    n: 29,
    title: 'Restore property',
    detail:
      'Reopen access, move signage, brief the customer, leave the site cleaner than we found it.',
  },
];

/* ─────────────────────────────────────────────────────────────────────────
 * DRY SWEEPING — solids are removed dry whenever reasonable
 * ─────────────────────────────────────────────────────────────────────── */

export const DRY_SWEEP_TOOLS: readonly string[] = [
  'Broom',
  'Push broom',
  'Leaf blower where appropriate',
  'Shovel and dustpan for heavy debris',
  'Manual pickup for irregular items',
];

export const DRY_SWEEP_TARGETS: readonly string[] = [
  'Leaves',
  'Trash and paper',
  'Gravel',
  'Mulch',
  'Cigarette butts',
  'Food debris',
  'Loose dirt and sand',
  'Broken material and irregular solids',
];

export const DRY_SWEEP_REASONS: readonly string[] = [
  'Reduces mud creation on the surface we are trying to clean',
  'Prevents clogged drains and storm-water contamination',
  'Improves chemical contact with the actual stain',
  'Improves surface-cleaner performance and prevents streaking',
  'Minimizes debris being blasted into landscaping',
  'Minimizes volume and toxicity of runoff',
];

/* ─────────────────────────────────────────────────────────────────────────
 * SURFACES + CONTAMINANTS
 * ─────────────────────────────────────────────────────────────────────── */

export type SurfaceId =
  | 'concrete'
  | 'asphalt'
  | 'painted-asphalt'
  | 'paver'
  | 'brick-walk'
  | 'brick-wall'
  | 'vinyl-siding'
  | 'painted-siding'
  | 'wood-deck'
  | 'wood-fence'
  | 'commercial-sidewalk'
  | 'parking-lot'
  | 'dumpster-pad'
  | 'storefront';

export interface Surface {
  readonly id: SurfaceId;
  readonly name: string;
  readonly notes: string;
}

export const SURFACES: readonly Surface[] = [
  {
    id: 'concrete',
    name: 'Concrete',
    notes: 'Durable flatwork. Handles the surface cleaner well when chemistry is right.',
  },
  {
    id: 'asphalt',
    name: 'Asphalt',
    notes: 'Softer than concrete. Aggressive washing can lift binder before it lifts the stain.',
  },
  {
    id: 'painted-asphalt',
    name: 'Painted / sealcoated asphalt',
    notes: 'Stripes, sealcoat, and paint come off first. Default to gentle.',
  },
  {
    id: 'paver',
    name: 'Pavers',
    notes: 'Joint sand is the vulnerability. Aggressive rinsing empties joints.',
  },
  {
    id: 'brick-walk',
    name: 'Brick walkway',
    notes: 'Horizontal brick with mortar. Test the mortar before committing.',
  },
  {
    id: 'brick-wall',
    name: 'Brick wall',
    notes: 'Never force water into mortar joints. Wide fan, controlled distance.',
  },
  {
    id: 'vinyl-siding',
    name: 'Vinyl siding',
    notes: 'Never spray upward behind laps. Low-pressure chemistry does the work.',
  },
  {
    id: 'painted-siding',
    name: 'Painted siding',
    notes: 'Inspect for chalking and loose paint first. Document before touching it.',
  },
  {
    id: 'wood-deck',
    name: 'Wood deck',
    notes: 'The surface cleaner is not a default. Fibers fur under too much pressure.',
  },
  {
    id: 'wood-fence',
    name: 'Wood fence',
    notes: 'Wide fan, conservative distance. Stop at any visible furring.',
  },
  {
    id: 'commercial-sidewalk',
    name: 'Commercial sidewalk',
    notes: 'Pedestrian control comes first. High-visibility runoff management.',
  },
  {
    id: 'parking-lot',
    name: 'Parking lot',
    notes: 'Concrete lots and asphalt lots are cleaned differently. Never the same method.',
  },
  {
    id: 'dumpster-pad',
    name: 'Dumpster pad',
    notes: 'Solids first. Contain runoff. Sanitation-compatible treatment when justified.',
  },
  {
    id: 'storefront',
    name: 'Storefront concrete + glass edge',
    notes: 'Glass and building edges protected before we start the concrete.',
  },
];

export type ContaminantId =
  | 'loose-dirt'
  | 'mud'
  | 'algae'
  | 'oil'
  | 'food-grease'
  | 'urine'
  | 'gum'
  | 'rust'
  | 'efflorescence'
  | 'paint'
  | 'automotive';

export interface Contaminant {
  readonly id: ContaminantId;
  readonly name: string;
  readonly firstChoice: string;
  readonly typicalOrder: string;
  readonly note?: string;
}

export const CONTAMINANTS: readonly Contaminant[] = [
  {
    id: 'loose-dirt',
    name: 'Loose dirt and light soil',
    firstChoice: 'Water and mechanical only',
    typicalOrder: 'Sweep → clean → rinse',
  },
  {
    id: 'mud',
    name: 'Mud and semi-dry soil',
    firstChoice: 'Physical removal, then water',
    typicalOrder: 'Scrape / sweep heavy material → low-pressure pre-rinse → surface clean → rinse',
    note: 'Avoid immediately turning large volumes of dry soil into slurry.',
  },
  {
    id: 'algae',
    name: 'Algae, mildew, organic growth',
    firstChoice: 'Compatible organic treatment',
    typicalOrder: 'Sweep → protect plants → chemical → dwell → mechanical clean → thorough rinse',
    note: 'Chemistry lets us clean at lower pressure. That is the point.',
  },
  {
    id: 'oil',
    name: 'Oil (concrete or asphalt)',
    firstChoice: 'Surface-compatible degreaser',
    typicalOrder: 'Sweep → degrease → dwell → agitate → clean → rinse → repeat if justified',
    note: 'Oil penetrates. Complete removal is not guaranteed and we say so up front.',
  },
  {
    id: 'food-grease',
    name: 'Food grease and dumpster residue',
    firstChoice: 'Degreaser with manual agitation',
    typicalOrder:
      'Remove solids → sweep → contain runoff → degrease → dwell → agitate → controlled rinse → repeat spot',
    note: 'Never combine incompatible chemistries — separate rinses required.',
  },
  {
    id: 'urine',
    name: 'Urine and organic odor',
    firstChoice: 'Enzyme treatment',
    typicalOrder:
      'Remove debris → light rinse only if needed → enzyme → dwell → agitate per label → rinse',
    note: 'Enzyme and SH are never mixed. If both are needed, enzyme first with a complete rinse before the next chemistry.',
  },
  {
    id: 'gum',
    name: 'Chewing gum',
    firstChoice: 'Softening and controlled mechanical removal',
    typicalOrder:
      'Sweep → identify → soften / treat → controlled mechanical removal → rinse residue → normal clean',
    note: 'We do not gouge concrete with a concentrated nozzle to remove gum.',
  },
  {
    id: 'rust',
    name: 'Rust',
    firstChoice: 'Specialty product, only when trained and authorized',
    typicalOrder:
      'General clean → identify remaining stain → stop → approved specialty spot treatment',
    note: 'Ordinary pressure will damage the substrate before it removes the rust.',
  },
  {
    id: 'efflorescence',
    name: 'Efflorescence',
    firstChoice: 'Masonry-specific process',
    typicalOrder:
      'General clean → identify → evaluate masonry compatibility → specialty process if authorized',
    note: 'Pressure alone will not remove efflorescence and can damage the substrate.',
  },
  {
    id: 'paint',
    name: 'Paint and coatings',
    firstChoice: 'Do not attempt without a scoped removal plan',
    typicalOrder: 'General clean → identify → evaluate removal method separately',
    note: 'Paint removal is a separate service, not part of a wash.',
  },
  {
    id: 'automotive',
    name: 'Automotive fluids (parking lot)',
    firstChoice: 'Asphalt- or concrete-compatible degreaser',
    typicalOrder:
      'Spot pretreat → dwell → clean using surface-specific method → water broom → contain sediment',
  },
];

/* ─────────────────────────────────────────────────────────────────────────
 * SEQUENCES — the surface × contaminant playbook
 * ─────────────────────────────────────────────────────────────────────── */

export interface CleaningSequence {
  readonly id: string;
  readonly surfaceId: SurfaceId;
  readonly contaminantId: ContaminantId;
  readonly title: string;
  readonly machine: MachineId;
  readonly steps: readonly string[];
  readonly warning?: string;
  readonly expected: string;
}

export const SEQUENCES: readonly CleaningSequence[] = [
  {
    id: 'concrete-loose-dirt',
    surfaceId: 'concrete',
    contaminantId: 'loose-dirt',
    title: 'Lightly dirty concrete sidewalk',
    machine: 'gas-4000',
    steps: [
      'Sweep or blow the slab clean',
      'Choose the gas washer if the area is large enough to justify setup, otherwise the electric',
      'Surface clean with overlapping passes',
      'Fan-tip detail the edges',
      'Rinse',
      'Water broom',
      'Allow partial dry-down',
      'Inspect for stripes and missed spots',
    ],
    expected:
      'Uniform color across the slab. Edges match the field. No visible stripes after dry-down.',
  },
  {
    id: 'concrete-algae',
    surfaceId: 'concrete',
    contaminantId: 'algae',
    title: 'Organic growth and algae on concrete',
    machine: 'gas-4000',
    steps: [
      'Sweep loose debris',
      'Wet nearby plants and protect landscaping',
      'Apply compatible organic treatment across the affected area',
      'Dwell without letting the surface dry out',
      'Surface clean at conservative effective pressure',
      'Fan-tip detail the edges',
      'Full rinse of the slab',
      'Rinse the surrounding vegetation',
      'Water broom',
      'Dry inspection',
    ],
    warning:
      'Do NOT let the treatment dry mid-dwell — re-mist if necessary. Do NOT rinse plants after the fact only; wet them before AND after.',
    expected: 'Uniform color, no green tinge, no chemical residue on adjacent plants.',
  },
  {
    id: 'concrete-oil',
    surfaceId: 'concrete',
    contaminantId: 'oil',
    title: 'Oil spot on concrete',
    machine: 'gas-4000',
    steps: [
      'Sweep the slab',
      'Apply degreaser ONLY to the affected area',
      'Dwell per product',
      'Agitate the stain manually',
      'Rinse loosened residue away',
      'Repeat spot treatment if justified',
      'Surface clean the general slab',
      'Detail the edges',
      'Final rinse',
    ],
    warning:
      'Oil penetrates concrete. Complete removal is not guaranteed. Tell the customer up front.',
    expected:
      'Significant reduction in the stain footprint. A shadow may remain — that is the substrate, not dirt.',
  },
  {
    id: 'concrete-food-grease',
    surfaceId: 'dumpster-pad',
    contaminantId: 'food-grease',
    title: 'Food grease / dumpster pad',
    machine: 'gas-4000',
    steps: [
      'Remove all solids by hand',
      'Sweep',
      'Contain and manage the runoff path',
      'Apply degreaser to affected areas',
      'Dwell per product',
      'Aggressive manual agitation where appropriate',
      'Controlled rinse',
      'Repeat spot treatment as needed',
      'Surface clean the slab if the concrete is stable enough',
      'Complete rinse',
      'Sanitation-compatible treatment if separately justified',
      'Water broom or controlled collection',
      'Final inspection',
    ],
    warning:
      'Never combine incompatible chemistries. If sanitation treatment is separately justified, complete a full rinse before it goes down.',
    expected:
      'Significant grease reduction. Odor reduction if a compatible sanitation step was performed. Deep-set grease shadows may remain.',
  },
  {
    id: 'concrete-mud',
    surfaceId: 'concrete',
    contaminantId: 'mud',
    title: 'Mud-covered concrete',
    machine: 'gas-4000',
    steps: [
      'Remove heavy dry or semi-dry material manually',
      'Sweep',
      'Low-pressure pre-rinse to move remaining loose material off the slab',
      'Surface clean',
      'Detail the edges',
      'Final rinse',
      'Water broom',
    ],
    warning:
      'Avoid immediately turning large amounts of loose soil into slurry. Get the volume off the slab dry first.',
    expected: 'Clean slab, controlled sediment at the runoff endpoint.',
  },
  {
    id: 'asphalt-loose-dirt',
    surfaceId: 'asphalt',
    contaminantId: 'loose-dirt',
    title: 'Light dirt on asphalt',
    machine: 'electric-1900',
    steps: [
      'Sweep and blow thoroughly',
      'Choose the electric washer or a conservative gas-washer fan rinse depending on area',
      'Wide fan or water broom pass',
      'Controlled rinse',
      'Inspect',
    ],
    warning: 'Avoid unnecessary surface-cleaner aggression on asphalt.',
    expected: 'Uniform dark asphalt tone. No lightened stripes from over-aggression.',
  },
  {
    id: 'asphalt-oil',
    surfaceId: 'asphalt',
    contaminantId: 'oil',
    title: 'Oil on asphalt',
    machine: 'electric-1900',
    steps: [
      'Sweep',
      'Targeted asphalt-compatible degreaser to the affected area',
      'Dwell',
      'Gentle agitation',
      'Controlled low-pressure rinse',
      'Repeat carefully if justified',
      'Final water-broom rinse',
    ],
    warning:
      'Aggressive washing can remove asphalt binder and aggregate BEFORE it removes a deeply absorbed oil stain. Stop early.',
    expected: 'Reduced stain visibility. Shadow may remain — the alternative is asphalt damage.',
  },
  {
    id: 'painted-asphalt-loose-dirt',
    surfaceId: 'painted-asphalt',
    contaminantId: 'loose-dirt',
    title: 'Painted or sealcoated asphalt',
    machine: 'electric-1900',
    steps: [
      'Sweep',
      'Water first, no chemistry by default',
      'Test in a hidden area',
      'Compatible mild detergent only if necessary',
      'Gentle agitation',
      'Low-pressure rinse',
      'Water broom',
    ],
    warning: 'SH is NOT default here. Protect stripes, coatings, paint, sealcoat.',
    expected: 'Uniform color. Stripes and coatings intact.',
  },
  {
    id: 'paver-loose-dirt',
    surfaceId: 'paver',
    contaminantId: 'loose-dirt',
    title: 'General paver cleaning',
    machine: 'gas-4000',
    steps: [
      'Sweep thoroughly',
      'Inspect joint material — polymeric or joint sand?',
      'Apply compatible pretreatment if required',
      'Dwell',
      'Conservative fan rinse or carefully tested surface cleaner',
      'Detail edges',
      'Rinse',
      'Inspect joints for material loss',
      'Inform the customer if re-sanding is required',
    ],
    warning:
      'Do NOT blast polymeric or joint sand away unnecessarily. Joint loss is the risk on every paver job.',
    expected:
      'Cleaner pavers with joints intact. Customer informed about any joint refresh needed.',
  },
  {
    id: 'paver-algae',
    surfaceId: 'paver',
    contaminantId: 'algae',
    title: 'Organic growth between pavers',
    machine: 'electric-1900',
    steps: [
      'Sweep',
      'Apply organic treatment',
      'Dwell',
      'Gentle mechanical cleaning',
      'Controlled rinse',
      'Inspect joints',
    ],
    expected: 'Growth removed. Joints intact.',
  },
  {
    id: 'brick-walk-loose-dirt',
    surfaceId: 'brick-walk',
    contaminantId: 'loose-dirt',
    title: 'Brick walkway',
    machine: 'gas-4000',
    steps: [
      'Sweep',
      'Inspect mortar — any loss, cracking, or crumbling?',
      'Test chemistry in a hidden area',
      'Pretreat only if necessary',
      'Dwell',
      'Wide-fan controlled cleaning',
      'Rinse',
      'Inspect mortar again after',
    ],
    warning:
      'Surface cleaner only if the horizontal masonry is stable and testing confirms it is safe.',
    expected: 'Uniform brick tone. No mortar loss.',
  },
  {
    id: 'brick-wall-algae',
    surfaceId: 'brick-wall',
    contaminantId: 'algae',
    title: 'Brick wall with organic staining',
    machine: 'electric-1900',
    steps: [
      'Inspect mortar',
      'Protect openings — windows, vents, outlets',
      'Test small area',
      'Apply compatible cleaner if needed',
      'Dwell',
      'Controlled wide-fan rinse',
      'Work in orderly sections',
      'Final rinse',
    ],
    warning:
      'Do NOT force water deeply into mortar joints. That is how mortar loss and interior water damage happen.',
    expected: 'Growth reduced. Mortar and openings undamaged.',
  },
  {
    id: 'vinyl-siding-algae',
    surfaceId: 'vinyl-siding',
    contaminantId: 'algae',
    title: 'Vinyl siding with algae or grime',
    machine: 'gas-4000',
    steps: [
      'Inspect siding condition',
      'Close and protect openings',
      'Wet and protect plants at grade',
      'Apply compatible siding treatment using low-pressure application',
      'Dwell',
      'Gentle rinse',
      'Work methodically top-to-bottom',
      'Final inspection',
    ],
    warning:
      'Do NOT spray upward behind siding laps. Water inside the wall is a bigger problem than a dirty exterior.',
    expected: 'Uniform siding color. No water intrusion.',
  },
  {
    id: 'vinyl-siding-loose-dirt',
    surfaceId: 'vinyl-siding',
    contaminantId: 'loose-dirt',
    title: 'Lightly dirty siding with no organic staining',
    machine: 'electric-1900',
    steps: ['Inspect', 'Test', 'Low-pressure wide-fan rinse', 'Detail', 'Inspect'],
    expected: 'Uniform siding. No chemistry residue.',
  },
  {
    id: 'painted-siding-loose-dirt',
    surfaceId: 'painted-siding',
    contaminantId: 'loose-dirt',
    title: 'Painted siding',
    machine: 'electric-1900',
    steps: [
      'Inspect for chalking or loose paint',
      'Document existing condition',
      'Test in a hidden area',
      'Mild cleaner only if necessary',
      'Gentle rinse',
      'Inspect',
    ],
    warning: 'Stop immediately if paint begins releasing unexpectedly.',
    expected: 'Cleaner siding with the paint layer intact.',
  },
  {
    id: 'wood-deck-loose-dirt',
    surfaceId: 'wood-deck',
    contaminantId: 'loose-dirt',
    title: 'Wood deck',
    machine: 'electric-1900',
    steps: [
      'Remove furniture and planters',
      'Sweep',
      'Inspect for rot and loose boards',
      'Test',
      'Apply appropriate wood-compatible cleaner if necessary',
      'Dwell',
      'Gentle rinse following the grain where practical',
      'Inspect fibers for furring',
      'Final rinse',
    ],
    warning:
      'Do NOT use the 24-inch surface cleaner by default. Fibers fur under too much pressure and we cannot undo it.',
    expected: 'Cleaner boards with no visible furring.',
  },
  {
    id: 'wood-fence-loose-dirt',
    surfaceId: 'wood-fence',
    contaminantId: 'loose-dirt',
    title: 'Wood fence',
    machine: 'electric-1900',
    steps: [
      'Inspect',
      'Remove debris',
      'Test',
      'Compatible cleaner if needed',
      'Dwell',
      'Broad fan at conservative distance',
      'Work consistently panel by panel',
      'Rinse',
    ],
    warning: 'Stop if the wood starts visibly furring.',
    expected: 'Cleaner fence with grain intact.',
  },
  {
    id: 'commercial-sidewalk-mixed',
    surfaceId: 'commercial-sidewalk',
    contaminantId: 'loose-dirt',
    title: 'Commercial sidewalk',
    machine: 'gas-4000',
    steps: [
      'Set pedestrian controls — cones, tape, signage',
      'Photograph',
      'Remove trash',
      'Sweep or blow',
      'Identify gum, oil, and organic spots',
      'Pretreat individual contaminants',
      'Dwell',
      'Surface-clean the main field',
      'Hand-detail edges',
      'Spot-reclean anything the surface cleaner missed',
      'Rinse the storefront and building edge carefully',
      'Water broom runoff in a controlled direction',
      'Dry inspect',
      'Reopen the area',
    ],
    warning: 'Pedestrians come first. Runoff must never head toward a storm drain uncontrolled.',
    expected:
      'Uniform sidewalk with visible before/after contrast. No damage to storefront, glass, or signage.',
  },
  {
    id: 'parking-lot-automotive',
    surfaceId: 'parking-lot',
    contaminantId: 'automotive',
    title: 'Parking lot with automotive contamination',
    machine: 'gas-4000',
    steps: [
      'Traffic and pedestrian plan',
      'Remove trash',
      'Blow and sweep',
      'Identify oil, grease, food, organic areas',
      'Spot pretreat',
      'Dwell',
      'Clean using the surface-specific method (concrete lot vs asphalt lot)',
      'Water broom',
      'Control sediment and runoff',
      'Inspect',
      'Reopen',
    ],
    warning: 'Do not treat an asphalt parking lot as giant concrete. The methods differ.',
    expected:
      'Cleaner lot with contamination reduced. Oil shadows may remain on asphalt — the alternative is asphalt damage.',
  },
  {
    id: 'urine-organic',
    surfaceId: 'commercial-sidewalk',
    contaminantId: 'urine',
    title: 'Urine or organic-odor area',
    machine: 'electric-1900',
    steps: [
      'Remove solids and debris',
      'Light initial rinse only if necessary',
      'Apply enzyme treatment per label',
      'Dwell',
      'Agitate if the label or process supports it',
      'Rinse',
      'Evaluate remaining staining separately',
    ],
    warning:
      'Enzyme treatment is never directly mixed with SH. If additional chemistry is used afterward, complete rinse between them.',
    expected: 'Odor reduction. Visible stain may require separate cleaning.',
  },
  {
    id: 'gum-removal',
    surfaceId: 'commercial-sidewalk',
    contaminantId: 'gum',
    title: 'Gum on commercial sidewalk',
    machine: 'gas-4000',
    steps: [
      'Remove loose debris',
      'Identify gum locations',
      'Soften or treat with a compatible method',
      'Controlled mechanical removal',
      'Rinse residue',
      'Continue normal surface-cleaning sequence',
    ],
    warning: 'Do NOT gouge concrete with a concentrated zero-degree nozzle to remove gum.',
    expected: 'Gum removed. Substrate intact.',
  },
];

/* ─────────────────────────────────────────────────────────────────────────
 * STOP-WORK CONDITIONS — reasons to pause and reassess
 * ─────────────────────────────────────────────────────────────────────── */

export const STOP_WORK_CONDITIONS: readonly string[] = [
  'Unknown surface material',
  'Visible surface degradation from cleaning',
  'Aggregate loss from concrete',
  'Paint peeling that was not documented pre-job',
  'Mortar loss from masonry',
  'Wood furring under the fan',
  'Unstable or shifting pavers',
  'Unexpected chemical reaction on the surface',
  'Strong chemical drift affecting people, pets, or neighbors',
  'Unsafe pedestrian or vehicle traffic',
  'Electrical hazard — GFCI trips, standing water near power',
  'Inadequate water supply or pump starvation',
  'Leaking high-pressure hose',
  'Damaged coupler or fitting',
  'Uncontrolled runoff heading for a storm drain',
  'Extension wand becoming unstable at height',
  'Employee cannot confidently determine the next safe step',
];

/* ─────────────────────────────────────────────────────────────────────────
 * CHECKLISTS — customer-prep and employee field
 * ─────────────────────────────────────────────────────────────────────── */

export const CUSTOMER_PREP: readonly string[] = [
  'Move vehicles when requested',
  'Secure pets indoors',
  'Close windows and doors',
  'Move fragile objects off the work area',
  'Point out any known window, door, or roof leaks',
  'Point out delicate coatings or freshly painted surfaces',
  'Provide the agreed water access point',
  'Mention any drainage issues on the property',
  'Identify any area that must stay open during service',
];

export const CUSTOMER_EXPECTATIONS_PROMISE: readonly string[] = [
  'The best safely achievable cleaning result on your surfaces',
  'Clear before-and-after photos of every zone we touch',
  'Chemistry used only where it helps',
  'The lowest effective pressure for the job',
  'Timestamped documentation of any pre-existing damage',
];

export const CUSTOMER_EXPECTATIONS_LIMITS: readonly string[] = [
  'Complete removal of deeply absorbed oil',
  'Restoration of asphalt color',
  'Repair of damaged concrete',
  'Removal of oxidation through washing',
  'Perfect rust removal',
  'Perfect efflorescence removal',
  'Restoration of loose or peeling paint',
  'Restoration of damaged mortar',
  'Restoration of rotten wood',
];

export const FIELD_CHECKLIST: readonly string[] = [
  'Inspect',
  'Photograph',
  'Identify surface',
  'Identify contamination',
  'Choose electric vs gas',
  'Plan runoff',
  'Pick up debris',
  'Sweep or blow',
  'Protect surroundings',
  'Connect water',
  'Purge air',
  'Test machine',
  'Test surface',
  'Pretreat if needed',
  'Dwell',
  'Agitate if needed',
  'Primary clean',
  'Edge and detail',
  'Turn chemical OFF',
  'Rinse',
  'Water broom if appropriate',
  'Dry-down inspect',
  'Spot correct',
  'Final rinse',
  'Final photos',
  'Flush and pack equipment',
  'Report exceptions',
];

/* ─────────────────────────────────────────────────────────────────────────
 * TROUBLESHOOTING — common field problems and the likely cause
 * ─────────────────────────────────────────────────────────────────────── */

export interface TroubleshootEntry {
  readonly id: string;
  readonly issue: string;
  readonly likely: string;
  readonly action: string;
}

export const TROUBLESHOOTING: readonly TroubleshootEntry[] = [
  {
    id: 'weak-pressure',
    issue: 'Weak pressure at the wand',
    likely: 'Inlet water starvation, clogged nozzle, or worn tip',
    action:
      'Check inlet flow at the hose, purge air, verify tip size, swap to a fresh tip if needed.',
  },
  {
    id: 'pressure-pulsing',
    issue: 'Pressure pulsing or surging',
    likely: 'Air in the supply line or inadequate inlet',
    action: 'Water fully ON with engine OFF, purge trigger until stable, then restart the machine.',
  },
  {
    id: 'chem-not-drawing',
    issue: 'Chemical is not drawing through the injector',
    likely: 'Wrong tip on the wand, worn injector, or blocked filter',
    action:
      'Confirm soap/low-pressure tip is installed, inspect the injector filter, verify the chemistry pickup is submerged.',
  },
  {
    id: 'leaking-quick-connect',
    issue: 'Leaking quick-connect coupler',
    likely: 'Worn O-ring or damaged coupler',
    action:
      'Swap the O-ring first; if leak persists, replace the coupler. Do not tape over a leak.',
  },
  {
    id: 'surface-cleaner-striping',
    issue: 'Surface cleaner leaving stripes',
    likely: 'Uneven walking speed, worn tips, or hovering',
    action: 'Walk at a consistent pace, overlap passes, verify both tips are matched and unworn.',
  },
  {
    id: 'surface-cleaner-not-spinning',
    issue: 'Surface cleaner not spinning',
    likely: 'Debris in the swivel or clogged tips',
    action: 'Stop, lift, clear debris, confirm both tips are clear, restart.',
  },
  {
    id: 'reaction-force',
    issue: 'Excessive reaction force at the wand',
    likely: 'Nozzle too small for the machine or wand configuration',
    action: 'Step up to a wider fan or larger orifice; two-hand the wand and increase distance.',
  },
  {
    id: 'gfci-trip',
    issue: 'Electric washer trips the GFCI or breaker',
    likely: 'Wet connection, wrong outlet, or overloaded circuit',
    action:
      'Dry all connections, verify the outlet meets manufacturer requirements, isolate the circuit.',
  },
  {
    id: 'inadequate-supply',
    issue: 'Inadequate customer water supply',
    likely: 'Line not fully open, hose restriction, or dropped GPM under continuous demand',
    action:
      'Open the spigot fully, remove any hose restriction, measure continuous GPM under the same flow rate we will use.',
  },
];

/* ─────────────────────────────────────────────────────────────────────────
 * FAQ — real customer questions, answered honestly. Backs the FAQPage
 * JSON-LD on the guide (never fabricate Q&A just to add the schema).
 * ─────────────────────────────────────────────────────────────────────── */

export interface FaqItem {
  readonly q: string;
  readonly a: string;
}

export const FAQ_ITEMS: readonly FaqItem[] = [
  {
    q: 'Will power washing damage my concrete, siding, or wood?',
    a: 'Not the way we do it. Cleaning force comes from chemistry and dwell time, not raw pressure — we use the least aggressive method that produces the result, test a hidden area first, and stop at the first sign of surface stress.',
  },
  {
    q: 'Do you use harsh chemicals near my plants?',
    a: 'Only where they help — many jobs need no chemical at all. When we do treat, we wet the surrounding landscaping before and after and rinse it thoroughly so nothing is left to sit on your plants.',
  },
  {
    q: 'Can you remove oil stains completely?',
    a: 'Usually we reduce them dramatically, but deeply absorbed oil penetrates the substrate. A faint shadow can remain — that is the concrete itself, not dirt. We tell you what is realistic before we start rather than overpromising.',
  },
  {
    q: 'How is power washing priced?',
    a: 'The same way as all our labor: hourly per crew member with a one-hour minimum, so you pay for the time the job actually takes. See the power-washing service page for current rates and to book.',
  },
  {
    q: 'How long will the job take?',
    a: 'It depends on the area, surface, and how heavy the contamination is. A small porch is often under an hour; a long driveway, commercial sidewalk, or parking lot takes longer. We give you a time estimate before we begin.',
  },
  {
    q: 'Do I need to be home?',
    a: 'No — as long as we can reach the work area and a water supply. We document every zone with timestamped before-and-after photos so you can see exactly what was done.',
  },
  {
    q: 'Do you pressure wash roofs?',
    a: 'We do not high-pressure wash roofs — high pressure destroys shingles and forces water where it should not go. Roofs need low-pressure soft-washing; we will tell you honestly if that is the right call for yours.',
  },
  {
    q: 'What surfaces do you clean?',
    a: 'Concrete, pavers, brick walks and walls, vinyl and painted siding, wood decks and fences, commercial sidewalks, parking lots, dumpster pads, and storefronts. Each surface has its own method — see the sequence playbook above.',
  },
  {
    q: 'What should I do before you arrive?',
    a: 'Move vehicles, secure pets indoors, close windows and doors, and point out any known leaks or delicate coatings. The full customer-preparation checklist is in the section above.',
  },
  {
    q: 'What happens if it rains?',
    a: 'Light rain is usually fine and can even help a rinse. Heavy rain or unsafe wind pauses the work — we reschedule at no penalty rather than risk a poor result or an unsafe crew.',
  },
];

/* ─────────────────────────────────────────────────────────────────────────
 * ANCHORS — table-of-contents order and headings
 * ─────────────────────────────────────────────────────────────────────── */

export interface TocEntry {
  readonly id: string;
  readonly label: string;
}

export const TOC: readonly TocEntry[] = [
  { id: 'philosophy', label: '1. Core operating philosophy' },
  { id: 'right-size', label: '2. Right-size the machine to the job' },
  { id: 'machines', label: '3. The two machines' },
  { id: 'workflow', label: '4. Master workflow' },
  { id: 'dry-sweep', label: '5. Dry sweeping rules' },
  { id: 'chemistry-order', label: '6. Chemistry timing' },
  { id: 'sequences', label: '7. Sequence playbook' },
  { id: 'chemical-matrix', label: '8. Chemical decision matrix' },
  { id: 'technique', label: '9. Tool technique' },
  { id: 'water-supply', label: '10. Water supply and startup' },
  { id: 'troubleshooting', label: '11. Troubleshooting' },
  { id: 'stop-work', label: '12. Stop-work conditions' },
  { id: 'customer-prep', label: '13. Customer preparation' },
  { id: 'expectations', label: '14. What we promise (and do not)' },
  { id: 'faq', label: '15. Frequently asked questions' },
  { id: 'field-checklist', label: '16. Employee quick field checklist' },
];
