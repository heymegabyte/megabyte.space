// APA 7th-edition citations for quantitative claims on the public site.
// Anything claiming a %, $, or N must reference an entry here.

export interface ResearchSource {
  id: string;
  apa: string;
  url: string;
}

export const SOURCES: Record<string, ResearchSource> = {
  bls_occ_landscaping: {
    id: 'bls_occ_landscaping',
    apa: 'U.S. Bureau of Labor Statistics. (2024, May). Occupational Employment and Wage Statistics: Landscaping and Groundskeeping Workers (SOC 37-3011). U.S. Department of Labor.',
    url: 'https://www.bls.gov/oes/current/oes373011.htm',
  },
  bls_occ_movers: {
    id: 'bls_occ_movers',
    apa: 'U.S. Bureau of Labor Statistics. (2024, May). Occupational Employment and Wage Statistics: Laborers and Freight, Stock, and Material Movers, Hand (SOC 53-7062). U.S. Department of Labor.',
    url: 'https://www.bls.gov/oes/current/oes537062.htm',
  },
  bls_cpi_services: {
    id: 'bls_cpi_services',
    apa: 'U.S. Bureau of Labor Statistics. (2025, March). Consumer Price Index: Services less energy services, U.S. city average, not seasonally adjusted. U.S. Department of Labor.',
    url: 'https://www.bls.gov/cpi/',
  },
  nj_min_wage_2025: {
    id: 'nj_min_wage_2025',
    apa: 'New Jersey Department of Labor and Workforce Development. (2025, January 1). State minimum wage rate increase to $15.49/hour. State of New Jersey.',
    url: 'https://www.nj.gov/labor/wageandhour/support/faqs/minwagefaqs.shtml',
  },
  taskrabbit_pricing_2024: {
    id: 'taskrabbit_pricing_2024',
    apa: 'TaskRabbit Help Center. (2024). How Tasker rates and service fees work. TaskRabbit, Inc.',
    url: 'https://support.taskrabbit.com/hc/en-us/articles/204411550',
  },
  homeadvisor_pressure_wash: {
    id: 'homeadvisor_pressure_wash',
    apa: 'HomeAdvisor. (2024). Pressure washing cost guide: National average price ranges. HomeAdvisor (Angi).',
    url: 'https://www.homeadvisor.com/cost/cleaning-services/hire-a-pressure-washing-service/',
  },
  acs_essex_2023: {
    id: 'acs_essex_2023',
    apa: 'U.S. Census Bureau. (2024). American Community Survey 5-year estimates, Essex County, New Jersey (Table DP04 Selected Housing Characteristics). U.S. Department of Commerce.',
    url: 'https://data.census.gov/profile/Essex_County,_New_Jersey?g=050XX00US34013',
  },
  noaa_nj_climate: {
    id: 'noaa_nj_climate',
    apa: 'National Oceanic and Atmospheric Administration. (2024). New Jersey state climate summary (NOAA Technical Report NESDIS 150-NJ, 2nd ed.). U.S. Department of Commerce.',
    url: 'https://statesummaries.ncics.org/chapter/nj/',
  },
};

export interface PricingFact {
  label: string;
  value: string;
  detail: string;
  citationId: keyof typeof SOURCES;
}

// Used by Pricing.tsx "Why $50/hr is fair" panel. Every value cites a source.
export const PRICING_BENCHMARKS: PricingFact[] = [
  {
    label: 'BLS movers median wage (NJ)',
    value: '$19.04/hr',
    detail: 'Median hourly wage for material movers and laborers in New Jersey, May 2024.',
    citationId: 'bls_occ_movers',
  },
  {
    label: 'BLS landscaping median wage (NJ)',
    value: '$19.43/hr',
    detail: 'Median hourly wage for landscaping & groundskeeping workers in New Jersey, May 2024.',
    citationId: 'bls_occ_landscaping',
  },
  {
    label: 'NJ minimum wage 2025',
    value: '$15.49/hr',
    detail: 'Statewide minimum wage effective January 1, 2025.',
    citationId: 'nj_min_wage_2025',
  },
  {
    label: 'TaskRabbit median labor rate (NYC metro)',
    value: '$55–$110/hr',
    detail: 'Plus 15% service fee on every task; no flat-rate option.',
    citationId: 'taskrabbit_pricing_2024',
  },
  {
    label: 'HomeAdvisor pressure-wash range',
    value: '$192–$417',
    detail: 'National average per-project cost; we beat the low end on labor.',
    citationId: 'homeadvisor_pressure_wash',
  },
];

export interface ServiceAreaFact {
  label: string;
  value: string;
  detail: string;
  citationId: keyof typeof SOURCES;
}

export const SERVICE_AREA_FACTS: ServiceAreaFact[] = [
  {
    label: 'Essex County owner-occupied homes',
    value: '~120,000',
    detail: 'Owner-occupied housing units in Essex County, NJ — our home county.',
    citationId: 'acs_essex_2023',
  },
  {
    label: 'NJ frost-free season',
    value: '~180 days',
    detail: 'Average frost-free season for north-central NJ — drives our seasonal calendar.',
    citationId: 'noaa_nj_climate',
  },
];

export function sourceById(id: keyof typeof SOURCES): ResearchSource {
  const src = SOURCES[id];
  if (!src) throw new Error(`research: unknown source id "${String(id)}"`);
  return src;
}
