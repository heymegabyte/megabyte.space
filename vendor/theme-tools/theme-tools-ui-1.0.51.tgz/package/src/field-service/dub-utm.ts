// UTM templating + Dub short-link minting. The marketing surface needs
// trackable links for flyer QR codes, partner referrals, ad creatives, and
// email campaigns — every one of those clicks should resolve to a Dub
// short URL (`https://bcl.ink/<slug>`) so we can read the click-through
// in the Dub dashboard AND fire the matching `dub_id` cookie when the
// visitor lands.
//
// The actual minting goes through the existing worker route at `/api/dub`
// (owner-authenticated). This module is the browser-side helper that
// formats the source URL with the right UTM params, calls the API, and
// returns the canonical short URL.

export interface UtmParams {
  source: string; // e.g. 'flyer', 'twitter', 'newsletter'
  medium: string; // e.g. 'qr', 'social', 'email'
  campaign: string; // e.g. 'fall-2025-newark'
  content?: string; // e.g. 'top-cta'
  term?: string; // paid-search keyword
}

/**
 * Pure helper: append (or override) UTM params on a target URL. Safe to
 * call on any absolute URL; preserves existing query params unless the
 * UTM key conflicts (in which case the new UTM value wins).
 */
export function applyUtm(targetUrl: string, utm: UtmParams): string {
  const url = new URL(targetUrl);
  url.searchParams.set('utm_source', utm.source);
  url.searchParams.set('utm_medium', utm.medium);
  url.searchParams.set('utm_campaign', utm.campaign);
  if (utm.content) url.searchParams.set('utm_content', utm.content);
  if (utm.term) url.searchParams.set('utm_term', utm.term);
  return url.toString();
}

export interface BuildDubLinkOptions extends UtmParams {
  /** Optional explicit short-key slug — Dub auto-mints when omitted. */
  key?: string;
  /** Bearer token for the owner-only `/api/dub/link` endpoint. */
  bearer: string;
  /** Optional Dub domain override (default `bcl.ink`). */
  domain?: string;
}

interface DubLink {
  shortLink: string;
  url: string;
  key: string;
  domain: string;
}

interface DubResponse {
  ok: boolean;
  link?: DubLink;
  error?: string;
}

/**
 * Mint a Dub short link for a target URL with UTM params baked in.
 * Owner-only — the worker route requires the `OWNER_INVOICE_KEY` bearer.
 * Returns the short URL (e.g. `https://bcl.ink/fall25`) on success.
 *
 * Errors throw so the caller (admin tool) can surface the failure in UI.
 * Browser code that doesn't have the bearer should not call this — use
 * the pre-minted short URLs from the Dub dashboard instead.
 */
export async function buildDubLink(
  targetUrl: string,
  options: BuildDubLinkOptions,
): Promise<string> {
  const fullUrl = applyUtm(targetUrl, options);
  const res = await fetch('/api/dub/link', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${options.bearer}`,
    },
    body: JSON.stringify({
      url: fullUrl,
      key: options.key,
      title: options.campaign,
      description: `${options.source}/${options.medium}`,
    }),
  });

  if (!res.ok) {
    throw new Error(`dub_link_failed_${res.status}`);
  }
  const data = (await res.json()) as DubResponse;
  if (!data.ok || !data.link) {
    throw new Error(data.error || 'dub_link_failed');
  }
  return data.link.shortLink;
}

/**
 * Convenience builder for canonical campaign URLs. Used by content team
 * to mint share links via the admin tool with a single function call.
 *
 * @example
 *   const url = await campaignLink('booking', { source: 'qr', medium: 'flyer', campaign: 'fall25' }, bearer);
 */
export async function campaignLink(
  page: 'booking' | 'work' | 'quote' | 'contact' | string,
  utm: UtmParams,
  bearer: string,
): Promise<string> {
  const base = `https://bricklabor.com/${page.replace(/^\/+/, '')}`;
  return buildDubLink(base, { ...utm, bearer });
}
