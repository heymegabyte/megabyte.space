// Pure geo helpers for the client (mirror of the worker's geocode.ts math, kept
// separate so the web bundle never imports worker code). Used by the crew Job
// map to estimate ETA from the crew's own GPS to the job.

export interface LatLng {
  readonly lat: number;
  readonly lng: number;
}

const EARTH_M = 6_371_000;

/** Great-circle distance in meters. */
export function haversineMeters(a: LatLng, b: LatLng): number {
  if (a.lat === b.lat && a.lng === b.lng) return 0;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const h = Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
  return Math.round(2 * EARTH_M * Math.asin(Math.min(1, Math.sqrt(h))));
}

/** Coarse ETA from straight-line distance (1.35 detour factor, ~28 mph, ≥1 min). */
export function etaFromDistance(distanceMeters: number, speedMps = 12.5): {
  etaSeconds: number;
  distanceMeters: number;
} {
  const drive = distanceMeters * 1.35;
  return { etaSeconds: Math.max(60, Math.round(drive / speedMps)), distanceMeters };
}
