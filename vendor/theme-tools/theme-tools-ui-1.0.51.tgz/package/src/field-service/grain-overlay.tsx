import type { ReactNode } from 'react';

interface GrainOverlayProps {
  /** Children rendered above the grain layer. */
  children: ReactNode;
  /** Optional extra Tailwind classes for the wrapper. */
  className?: string;
  /**
   * Apply the hero-only tone filter (slight desaturate + brightness drop) to
   * keep the hero photographic backdrop from looking AI-bright.
   */
  toneHero?: boolean;
}

/**
 * Grain overlay wrapper.
 *
 * Renders children atop a 256×256 SVG noise layer via `.grain-overlay`. The
 * actual noise is declared inline in `styles/index.css` as a base64-free SVG
 * data URI so no extra HTTP request is needed. `mix-blend-mode: overlay`
 * blends the grain into the underlying surface instead of fading it.
 *
 * Set `toneHero` to also apply the `saturate(0.92) brightness(0.98)` filter
 * called for in the Wave 1B brief — only meaningful on the hero section.
 */
export function GrainOverlay({ children, className, toneHero = false }: GrainOverlayProps) {
  const cls = ['grain-overlay', toneHero ? 'grain-hero-toning' : '', className]
    .filter(Boolean)
    .join(' ');
  return <div className={cls}>{children}</div>;
}
