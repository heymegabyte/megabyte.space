import { useCallback, useRef, useState } from 'react';

/**
 * Generic optimistic-state hook. Flips local state immediately to `next`,
 * fires the async mutator, and rolls back to the previous value if the
 * mutator rejects. Returns the current value, a setter that wraps the
 * mutator, and an `isPending` flag while the mutation is in flight.
 *
 * Pattern: pair with `view-transition-name` on the rendered surface so the
 * rollback cross-fades instead of pop-replaces. Errors bubble — the caller
 * decides whether to surface them via toast / inline error / Sentry.
 *
 * @example
 *   const [name, setName, saving] = useOptimistic(profile.name, async (n) => {
 *     await fetch('/api/me', { method: 'PUT', body: JSON.stringify({ name: n }) });
 *   });
 */
export function useOptimistic<T>(
  initial: T,
  mutate: (next: T) => Promise<void>,
): [T, (next: T) => Promise<void>, boolean] {
  const [value, setValue] = useState<T>(initial);
  const [isPending, setIsPending] = useState(false);
  // Track the last server-confirmed value so rollback always reverts to
  // truth, even across multiple in-flight mutations.
  const lastConfirmedRef = useRef<T>(initial);

  const set = useCallback(
    async (next: T): Promise<void> => {
      const previous = lastConfirmedRef.current;
      setValue(next);
      setIsPending(true);
      try {
        await mutate(next);
        lastConfirmedRef.current = next;
      } catch (err) {
        setValue(previous);
        throw err;
      } finally {
        setIsPending(false);
      }
    },
    [mutate],
  );

  return [value, set, isPending];
}
