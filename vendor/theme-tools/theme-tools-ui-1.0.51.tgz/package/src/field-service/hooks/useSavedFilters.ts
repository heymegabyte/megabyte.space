import { useCallback, useEffect, useState } from 'react';

/**
 * Read the current URL search params and pick keys that match the defaults
 * shape, coercing each to the same primitive type as the default value.
 * Unknown keys are ignored; missing keys fall back to the default.
 */
function readFromUrl<T extends Record<string, unknown>>(defaults: T): Partial<T> {
  if (typeof window === 'undefined') return {};
  const params = new URLSearchParams(window.location.search);
  const out: Record<string, unknown> = {};
  for (const key of Object.keys(defaults)) {
    const raw = params.get(key);
    if (raw === null) continue;
    const sample = defaults[key];
    if (typeof sample === 'number') out[key] = Number(raw);
    else if (typeof sample === 'boolean') out[key] = raw === 'true' || raw === '1';
    else out[key] = raw;
  }
  return out as Partial<T>;
}

/**
 * Read previously-persisted filter state from localStorage. Quietly returns
 * `{}` if the storage read fails (private-mode Safari, disabled storage).
 */
function readFromStorage<T extends Record<string, unknown>>(key: string): Partial<T> {
  if (typeof window === 'undefined') return {};
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as unknown;
    return (parsed && typeof parsed === 'object' ? parsed : {}) as Partial<T>;
  } catch {
    return {};
  }
}

/**
 * Persist filter state to both URL search params (so the view is shareable +
 * bookmarkable) and localStorage (so the user's last view sticks across
 * sessions). On mount, hydration order is URL → localStorage → defaults so a
 * shared link always wins.
 *
 * Returns `[filters, update, reset]`. `update` accepts a partial patch and
 * shallow-merges. `reset` clears both stores and reverts to defaults.
 *
 * @example
 *   const [filters, update, reset] = useSavedFilters('bcl_admin_filters', {
 *     status: 'all',
 *     city: '',
 *     showCancelled: false,
 *   });
 */
export function useSavedFilters<T extends Record<string, unknown>>(
  key: string,
  defaults: T,
): [T, (next: Partial<T>) => void, () => void] {
  const [filters, setFilters] = useState<T>(() => ({
    ...defaults,
    ...readFromStorage<T>(key),
    ...readFromUrl<T>(defaults),
  }));

  // Sync to URL + localStorage whenever filters change.
  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      window.localStorage.setItem(key, JSON.stringify(filters));
    } catch {
      // Storage unavailable — fail silently; URL still reflects state.
    }
    const params = new URLSearchParams(window.location.search);
    for (const [k, v] of Object.entries(filters)) {
      const def = defaults[k];
      if (v === def || v === '' || v === undefined || v === null) {
        params.delete(k);
      } else {
        params.set(k, String(v));
      }
    }
    const qs = params.toString();
    const next = `${window.location.pathname}${qs ? `?${qs}` : ''}${window.location.hash}`;
    window.history.replaceState(window.history.state, '', next);
  }, [filters, key, defaults]);

  const update = useCallback((next: Partial<T>): void => {
    setFilters((prev) => ({ ...prev, ...next }));
  }, []);

  const reset = useCallback((): void => {
    if (typeof window !== 'undefined') {
      try {
        window.localStorage.removeItem(key);
      } catch {
        /* noop */
      }
    }
    setFilters(defaults);
  }, [key, defaults]);

  return [filters, update, reset];
}
