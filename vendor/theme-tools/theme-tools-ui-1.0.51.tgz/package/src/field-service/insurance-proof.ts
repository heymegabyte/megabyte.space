// Fetches the live insurance / DOT proof shown in the hero <TrustBadges /> tile.
// Backed by GET /api/stats/insurance, which reads optional `INSURANCE_*` worker
// secrets and is KV-cached for 1h. Until a real policy + certificate are
// provisioned, EVERY coverage field is null — the tile renders the honest
// "damage-protected, coverage pending" surface (gated by `hasActiveCoverage`),
// never a fabricated dollar figure. Every rendered value is tagged
// `data-eeat="usdot"` / `mc` / `coi` so the SEO agent and AI-search crawlers
// can pull real proof from the DOM the moment it exists. Type + active-coverage
// gate are the shared SSOT in src/shared/insurance-status.ts.

import { type InsuranceProof, PENDING_PROOF } from "./insurance-status.js";

export { hasActiveCoverage, type InsuranceProof } from "./insurance-status.js";

/**
 * Honest fallback proof — no carrier, no coverage. NEVER seed placeholder
 * dollar amounts here: a "$1M liability" line on a policy that does not exist
 * is a false-advertising claim. `hasActiveCoverage(FALLBACK) === false`, so the
 * hero shows the truthful pending surface until a real policy is wired in.
 */
export const FALLBACK: InsuranceProof = { ...PENDING_PROOF, asOf: new Date().toISOString().slice(0, 10) };

let cachedPromise: Promise<InsuranceProof> | null = null;

/**
 * Fetch the live insurance proof. Memoized for the page lifetime to keep the
 * hero render path off the network on subsequent re-renders. Always resolves
 * (network errors fall back to placeholder values) so the trust tile renders
 * with safe defaults even on a cold worker or offline reload.
 */
export function fetchInsuranceProof(): Promise<InsuranceProof> {
  if (cachedPromise) return cachedPromise;
  cachedPromise = (async () => {
    try {
      const res = await fetch('/api/stats/insurance', {
        headers: { Accept: 'application/json' },
        credentials: 'same-origin',
      });
      if (!res.ok) return FALLBACK;
      const json = (await res.json()) as { ok?: boolean; insurance?: InsuranceProof };
      if (!json.ok || !json.insurance) return FALLBACK;
      return { ...FALLBACK, ...json.insurance };
    } catch {
      return FALLBACK;
    }
  })();
  return cachedPromise;
}

/**
 * Sub-line for the hero tile. Uses real USDOT/MC operating authority when
 * present; otherwise prints "Newark NJ · owner-run crew" — Brick Labor is
 * casual labor, NOT a licensed contractor, and crew are not insured by BCL
 * (Terms §11), so the fallback must never imply a license OR insurance is held
 * (NJ Consumer Fraud exposure + contradicts the site's own disclosures).
 */
export function formatLicenseLine(proof: InsuranceProof): string {
  if (proof.usdot && proof.mcNumber) return `USDOT ${proof.usdot} · MC ${proof.mcNumber}`;
  if (proof.usdot) return `USDOT ${proof.usdot}`;
  if (proof.mcNumber) return `MC ${proof.mcNumber}`;
  return 'Newark NJ · owner-run crew';
}

/**
 * Coverage summary suitable for the tile sub-line. Formats dollar coverage with
 * compact `$1M / $100k` style; falls back to "Coverage pending" on null.
 */
export function formatCoverageLine(proof: InsuranceProof): string {
  const liability = formatDollars(proof.liabilityCoverageDollars);
  const cargo = formatDollars(proof.cargoCoverageDollars);
  if (!liability && !cargo) return 'Coverage pending';
  if (liability && cargo) return `${liability} liability · ${cargo} cargo`;
  return liability || cargo || 'Coverage pending';
}

function formatDollars(amount: number | null): string | null {
  if (amount === null || !Number.isFinite(amount) || amount <= 0) return null;
  if (amount >= 1_000_000) return `$${Math.round(amount / 1_000_000)}M`;
  if (amount >= 1_000) return `$${Math.round(amount / 1_000)}k`;
  return `$${amount}`;
}
