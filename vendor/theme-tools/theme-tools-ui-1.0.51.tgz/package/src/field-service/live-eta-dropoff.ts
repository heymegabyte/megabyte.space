/**
 * live-eta-dropoff.ts — resolve the dropoff (customer destination) coords the
 * /track `<LiveEtaTracker>` needs to compute distance + ETA from the crew's live
 * GPS frames.
 *
 * The coords live on the track payload's `liveMap.dest` (resolved + persisted
 * server-side in track.ts, gated by the `live_job_map` flag). Returns null when
 * they're absent/invalid so the tracker falls back to its "waiting for GPS" state
 * instead of crashing.
 *
 * fire-146: TrackBooking mounted `<LiveEtaTracker>` WITHOUT passing these, so the
 * component's distance/ETA calc always bailed (`dropoffLat == null`) and the live
 * ETA was permanently dark ("waiting for GPS" even with frames streaming). This
 * helper + the one-line prop wire-up light it up.
 */
export interface LiveEtaDropoff {
  readonly lat: number;
  readonly lng: number;
}

export function liveEtaDropoff(
  booking:
    | { readonly liveMap?: { readonly dest?: { readonly lat: number; readonly lng: number } | null } | null }
    | null
    | undefined,
): LiveEtaDropoff | null {
  const d = booking?.liveMap?.dest;
  if (d && Number.isFinite(d.lat) && Number.isFinite(d.lng)) return { lat: d.lat, lng: d.lng };
  return null;
}
