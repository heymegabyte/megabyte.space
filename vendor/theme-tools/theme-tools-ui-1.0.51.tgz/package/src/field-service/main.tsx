import { StrictMode } from 'react';
import { createRoot, hydrateRoot } from 'react-dom/client';
import { App } from './App.js';
import { ErrorBoundary } from './components/ErrorBoundary.js';
import { attach } from './animate.js';
import { initSentry } from '@theme.tools/telemetry/field-service/sentry-browser';
import { trackReferralIfPresent } from './referral.js';
import { captureDubIdIfPresent } from './dub.js';
import { installTrustedTypesPolicies } from './csp-nonce.js';
import { initWebVitals } from '@theme.tools/telemetry/field-service/web-vitals';
import { isHeroRoute } from '@theme.tools/seo-geo/field-service/hero-route';
import { capturePrerenderedRoot } from './prerendered-root.js';
import { shouldReloadForControllerChange } from './service-worker-refresh.js';

// Install Trusted Types policies BEFORE React touches the DOM so that any
// `innerHTML` sink — including third-party scripts — has a default policy
// to flow through under `require-trusted-types-for 'script'`.
installTrustedTypesPolicies();

// Route-aware LCP preloads (Wave 27-C). Hero only renders on `/` and city
// pages — preloading the AVIF poster on /me, /work, /admin, /dashboard-ng
// triggers the browser warning "preloaded but not used within window load
// event". Inject the preload synchronously before React mounts so it still
// wins the LCP race when it IS the LCP. Geist font preload likewise scoped
// to routes that actually paint Hero copy.
(() => {
  // Only the homepage (incl. /es + /pt) renders <Hero> + the hero-poster
  // backdrop. City pages (/c/:slug) render their own content and never use it,
  // so preloading there is wasted (pass +85). isHeroRoute is shared + unit-tested.
  if (!isHeroRoute(window.location.pathname)) return;
  const head = document.head;
  const mk = (attrs: Record<string, string>) => {
    const link = document.createElement('link');
    for (const [k, v] of Object.entries(attrs)) link.setAttribute(k, v);
    head.appendChild(link);
  };
  // Match the exact responsive AVIF selected by Hero's picture element. Media-
  // scoped preloads prevent mobile from downloading the desktop poster too.
  //
  // NOTE: the big `/` LCP lever is NOT this image (118K, preloaded, fast) — the
  // homepage ships a CLIENT-RENDERED empty `#root`, so mobile LCP (~5.9s lab, slow-4G)
  // waits on JS download + hydration. Prerendering the hero is the real fix — queued
  // as BACKLOG § HOMEPAGE-SSG-PRERENDER (fire-28 CWV finding).
  mk({
    rel: 'preload',
    as: 'image',
    href: '/brand/hero-poster-mobile.avif',
    type: 'image/avif',
    fetchpriority: 'high',
    media: '(max-width: 767px)',
  });
  mk({
    rel: 'preload',
    as: 'image',
    href: '/brand/hero-poster.avif',
    type: 'image/avif',
    fetchpriority: 'high',
    media: '(min-width: 768px)',
  });
})();

const rootEl = document.getElementById('root');
if (!rootEl) throw new Error('Missing #root');

// Snapshot the server-prerendered markup BEFORE createRoot() clears #root, so
// pure-SSG routes with no React twin (/vs/:slug comparison pages) can re-render
// their exact prerendered content instead of being stomped by NotFound404.
capturePrerenderedRoot(rootEl.innerHTML);

const app = (
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>
);

const hasHomepagePrerender = Boolean(
  document.querySelector('meta[name="bcl-react-prerender"][content="homepage-v1"]'),
);
const shouldHydrateHomepage = window.location.pathname === '/' && hasHomepagePrerender;

if (shouldHydrateHomepage) {
  hydrateRoot(rootEl, app, {
    onRecoverableError(error, errorInfo) {
      rootEl.dataset.hydrationError = 'true';
      window.dispatchEvent(
        new CustomEvent('bcl:hydration-error', {
          detail: { error, componentStack: errorInfo.componentStack },
        }),
      );
      if (typeof window.reportError === 'function') window.reportError(error);
    },
  });
} else {
  createRoot(rootEl).render(app);
}

// `attach()` writes inline reveal-animation styles. Hydration is concurrent, so
// mutating prerendered nodes immediately after hydrateRoot can race React's DOM
// comparison and produce false "extra attributes" warnings. Two frames keep the
// first paint fast while ensuring React has claimed the server tree first.
if (shouldHydrateHomepage) {
  requestAnimationFrame(() => requestAnimationFrame(attach));
} else {
  attach();
}
initSentry();
initWebVitals();
trackReferralIfPresent();
captureDubIdIfPresent();

if ('serviceWorker' in navigator) {
  const hadServiceWorkerControllerAtBoot = Boolean(navigator.serviceWorker.controller);
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register('/sw.js')
      .then((reg) => {
        // Surface a low-friction reload prompt when a new worker is waiting.
        // The SW already calls skipWaiting() on install, so the prompt is a
        // courtesy — most users won't see it unless they keep the tab open.
        const notifyUpdate = () => {
          if (!reg.waiting) return;
          if (typeof window === 'undefined') return;
          window.dispatchEvent(new CustomEvent('bcl:sw-update', { detail: reg }));
        };
        if (reg.waiting) notifyUpdate();
        reg.addEventListener('updatefound', () => {
          const installing = reg.installing;
          if (!installing) return;
          installing.addEventListener('statechange', () => {
            if (installing.state === 'installed' && navigator.serviceWorker.controller)
              notifyUpdate();
          });
        });
      })
      .catch(() => {
        /* noop */
      });

    let refreshing = false;
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (
        !shouldReloadForControllerChange({
          hadControllerAtBoot: hadServiceWorkerControllerAtBoot,
          refreshing,
        })
      )
        return;
      refreshing = true;
      window.location.reload();
    });
  });
}

export const FIELD_SERVICE_MAIN_BOOTSTRAPPED = true;
