/**
 * nav-icons — a tiny, dependency-free SVG icon registry for the dashboard
 * sidebar (the dashboard has no icon library; adding lucide/ng-icons would bloat
 * the bundle for ~18 glyphs). Each entry is a raw `<path>`/shape STRING drawn
 * inside a shared 24×24 `viewBox` with `stroke="currentColor"` + 1.75 stroke —
 * so an icon inherits the nav item's text colour and animates with it.
 *
 * Keys are matched to nav routes by `iconForRoute()` (longest-prefix wins) so a
 * new nav item gets a sensible glyph automatically, with a clean fallback.
 * strictTemplates-safe: `iconForRoute` ALWAYS returns a string (never undefined).
 */

/** Inner SVG markup per icon key (stroked, 24×24 viewBox, round caps/joins). */
export const NAV_ICON_PATHS: Readonly<Record<string, string>> = {
  // calendar / bookings
  bookings:
    '<rect x="3" y="4" width="18" height="17" rx="2.5"/><path d="M3 9h18M8 2.5v3M16 2.5v3"/><circle cx="8.5" cy="14" r="1.1" fill="currentColor" stroke="none"/><circle cx="12" cy="14" r="1.1" fill="currentColor" stroke="none"/><circle cx="15.5" cy="14" r="1.1" fill="currentColor" stroke="none"/>',
  // price tag / quotes
  quotes:
    '<path d="M20.6 13.4 13 21a2 2 0 0 1-2.8 0l-6.5-6.5a2 2 0 0 1-.6-1.4V5a2 2 0 0 1 2-2h5.6a2 2 0 0 1 1.4.6l6.5 6.5a2 2 0 0 1 0 2.8Z"/><circle cx="8" cy="8" r="1.3" fill="currentColor" stroke="none"/>',
  calendar:
    '<rect x="3" y="4" width="18" height="17" rx="2.5"/><path d="M3 9h18M8 2.5v3M16 2.5v3M8 13h3v3H8z"/>',
  // gift / refer
  refer:
    '<rect x="3" y="8" width="18" height="4" rx="1"/><path d="M5 12v8a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-8M12 8v13M12 8S9.5 3.5 7.5 5s.5 3 4.5 3Zm0 0s2.5-4.5 4.5-3 -.5 3-4.5 3Z"/>',
  // hard hat / jobs (crew)
  jobs:
    '<path d="M3.5 18a8.5 8.5 0 0 1 17 0"/><path d="M2.5 18h19M10 9.2V6a2 2 0 0 1 4 0v3.2M6.5 10.5c0-2 1-3 1.6-3.4M17.5 10.5c0-2-1-3-1.6-3.4"/>',
  // users / crew console
  crew:
    '<circle cx="9" cy="8" r="3.2"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 5.2a3.2 3.2 0 0 1 0 5.6M17 14.2a6.5 6.5 0 0 1 4.5 5.8"/>',
  // wallet / earnings + wallet
  earnings:
    '<path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H18a2 2 0 0 1 2 2v.5"/><rect x="3" y="7.5" width="18" height="12" rx="2.5"/><path d="M16 13.5h2.5"/><circle cx="16.5" cy="13.5" r="0.4" fill="currentColor" stroke="none"/>',
  // shield / admin
  admin:
    '<path d="M12 2.5 20 6v5.5c0 5-3.4 8.4-8 9.9C7.4 19.9 4 16.5 4 11.5V6l8-3.5Z"/><path d="m9 12 2 2 4-4.5"/>',
  // sparkles / features
  features:
    '<path d="M12 3.5 13.7 9 19 10.5 13.7 12 12 17.5 10.3 12 5 10.5 10.3 9 12 3.5Z"/><path d="M18.5 4v3M20 5.5h-3M5.5 17v2.5M6.75 18.25h-2.5"/>',
  // globe / sites
  sites:
    '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.4 3.8 5.6 3.8 9S14.5 18.6 12 21c-2.5-2.4-3.8-5.6-3.8-9S9.5 5.4 12 3Z"/>',
  // terminal-lines / logs
  logs: '<rect x="3" y="4" width="18" height="16" rx="2.5"/><path d="M7 9l3 3-3 3M13 15h4"/>',
  // database / sql
  sql: '<ellipse cx="12" cy="5.5" rx="8" ry="3"/><path d="M4 5.5v13c0 1.7 3.6 3 8 3s8-1.3 8-3v-13M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
  // layers / snapshots
  snapshots: '<path d="M12 2.5 21.5 8 12 13.5 2.5 8 12 2.5Z"/><path d="m2.5 12 9.5 5.5 9.5-5.5M2.5 16 12 21.5 21.5 16"/>',
  // clock / past history
  past: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2.2"/>',
  // wallet (top-of-sidebar link mirror) — reuse earnings glyph
  wallet:
    '<path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H18a2 2 0 0 1 2 2v.5"/><rect x="3" y="7.5" width="18" height="12" rx="2.5"/><path d="M16 13.5h2.5"/><circle cx="16.5" cy="13.5" r="0.4" fill="currentColor" stroke="none"/>',
  // plug / integrations
  integrations:
    '<path d="M9 2.5v5M15 2.5v5M7 7.5h10v3a5 5 0 0 1-10 0v-3ZM12 15.5v6"/>',
  // receipt / billing
  billing:
    '<path d="M5 2.5h14v19l-2.3-1.5-2.35 1.5L12 21.5l-2.35 1.5L7.3 21.5 5 21.5V2.5Z"/><path d="M9 8h6M9 12h6"/>',
  // people / team
  team: '<circle cx="8.5" cy="9" r="2.8"/><circle cx="16.5" cy="9.5" r="2.3"/><path d="M3.5 19a5 5 0 0 1 10 0M14 19a5 5 0 0 1 6.5-4.8"/>',
  // gear / settings
  settings:
    '<circle cx="12" cy="12" r="3.2"/><path d="M12 2.5v2.6M12 18.9v2.6M21.5 12h-2.6M5.1 12H2.5M18.7 5.3l-1.8 1.8M7.1 16.9l-1.8 1.8M18.7 18.7l-1.8-1.8M7.1 7.1 5.3 5.3"/>',
  // dispatch / calendar month — map/route glyph
  dispatch:
    '<path d="M9 20.5 3 18V4l6 2.5 6-2.5 6 2.5v14l-6-2.5-6 2.5ZM9 6.5v14M15 4v14"/>',
  // generic fallback — dot-grid
  default:
    '<circle cx="6" cy="6" r="1.4" fill="currentColor" stroke="none"/><circle cx="12" cy="6" r="1.4" fill="currentColor" stroke="none"/><circle cx="18" cy="6" r="1.4" fill="currentColor" stroke="none"/><circle cx="6" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="18" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="6" cy="18" r="1.4" fill="currentColor" stroke="none"/><circle cx="12" cy="18" r="1.4" fill="currentColor" stroke="none"/><circle cx="18" cy="18" r="1.4" fill="currentColor" stroke="none"/>',
};

/**
 * Longest-prefix route → icon key. `/crew/earnings` prefers `earnings` over
 * `crew`; `/calendar/month` prefers `dispatch`. Order longest/most-specific
 * first. Every entry's value MUST be a key of NAV_ICON_PATHS.
 */
const ROUTE_ICON_RULES: ReadonlyArray<readonly [prefix: string, key: string]> = [
  ['/crew/earnings', 'earnings'],
  ['/calendar/month', 'dispatch'],
  ['/wave-features', 'features'],
  ['/bookings', 'bookings'],
  ['/quotes', 'quotes'],
  ['/calendar', 'calendar'],
  ['/refer', 'refer'],
  ['/jobs', 'jobs'],
  ['/crew', 'crew'],
  ['/admin', 'admin'],
  ['/sites', 'sites'],
  ['/logs', 'logs'],
  ['/sql', 'sql'],
  ['/snapshots', 'snapshots'],
  ['/past', 'past'],
  ['/wallet', 'wallet'],
  ['/integrations', 'integrations'],
  ['/billing', 'billing'],
  ['/team', 'team'],
  ['/settings', 'settings'],
];

/**
 * Resolve a nav route to its inner-SVG icon string. An explicit `iconKey`
 * (from the nav config) wins; otherwise longest-prefix match; otherwise the
 * dot-grid fallback. Always returns a non-empty string (strictTemplates-safe).
 */
export function iconForRoute(route: string, iconKey?: string): string {
  if (iconKey && NAV_ICON_PATHS[iconKey]) return NAV_ICON_PATHS[iconKey];
  for (const [prefix, key] of ROUTE_ICON_RULES) {
    if (route === prefix || route.startsWith(prefix + '/') || route.startsWith(prefix)) {
      const path = NAV_ICON_PATHS[key];
      if (path) return path;
    }
  }
  return NAV_ICON_PATHS['default'] ?? '';
}
