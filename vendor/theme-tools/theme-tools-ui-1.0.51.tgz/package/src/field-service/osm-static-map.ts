/**
 * osm-static-map.ts — token-free OpenStreetMap static-map URL builder.
 *
 * Single source of truth for every static crew-tracking map across the app —
 * the customer `/track` live map (`track-map.ts` → `LiveCrewTrackMap`), the
 * full-screen live-crew page (`LiveCrewMapPage`), and the predictive-ETA
 * thumbnail (`predictive-eta/lib/routing.ts`) + its eta-sms MMS preview. It
 * REPLACES the Mapbox Static Images API: OSS OSM tiles via the public
 * `staticmap.openstreetmap.de` renderer, NO API key.
 *
 * Pure + deterministic — same points always produce the same URL — so the
 * rendered `<img>` can never drift from its unit tests, and the worker + web
 * share one encoding. Center + zoom are computed from the marker bounds so the
 * map always frames every pin. Returns `null` when there is no valid marker so
 * callers render an "unavailable" state instead of a broken image.
 */

/** Which kind of pin a point is — drives its marker icon. */
export type OsmMarkerRole = 'dest' | 'crew';

export interface OsmMapPoint {
  readonly lat: number;
  readonly lng: number;
  readonly role: OsmMarkerRole;
}

export interface OsmStaticMapInput {
  /** Markers to render. Destinations first so crew pins draw on top. */
  readonly points: readonly OsmMapPoint[];
  /** Rendered pixel width (clamped to the renderer limits). */
  readonly width?: number;
  /** Rendered pixel height (clamped to the renderer limits). */
  readonly height?: number;
}

/** Public, token-free OSM static-map renderer (staticMapLite). */
const OSM_STATIC_BASE = 'https://staticmap.openstreetmap.de/staticmap.php';
const MAX_DIM = 1024; // staticmap.openstreetmap.de hard cap per side
const MIN_DIM = 1;
const DEFAULT_W = 640;
const DEFAULT_H = 420;
const MIN_ZOOM = 3;
const MAX_ZOOM = 17;

/** staticMapLite marker icons (token-free). Crew = blue (moving), dest = red. */
const MARKER_ICON: Record<OsmMarkerRole, string> = {
  crew: 'ol-marker-blue',
  dest: 'ol-marker',
};

function inLatRange(n: number): boolean {
  return Number.isFinite(n) && n >= -90 && n <= 90;
}
function inLngRange(n: number): boolean {
  return Number.isFinite(n) && n >= -180 && n <= 180;
}
function validPoint(p: OsmMapPoint): boolean {
  return inLatRange(p.lat) && inLngRange(p.lng);
}
function clampDim(n: number | undefined, fallback: number): number {
  if (n == null || !Number.isFinite(n)) return fallback;
  return Math.min(MAX_DIM, Math.max(MIN_DIM, Math.round(n)));
}
/** ≤6 decimals keeps the URL compact + stable across negligible GPS jitter. */
function coord(n: number): string {
  return String(Math.round(n * 1e6) / 1e6);
}

/**
 * Pick a zoom level that frames the given lat/lng spans. A single point (zero
 * span) zooms in close; a city-wide span zooms out. Clamped to the renderer's
 * usable range.
 *
 * @param latSpan - max−min latitude across all markers (degrees).
 * @param lngSpan - max−min longitude across all markers (degrees).
 * @returns an integer OSM zoom level in [{@link MIN_ZOOM}, {@link MAX_ZOOM}].
 * @example zoomForSpan(0, 0) // → 16 (single pin, close zoom)
 */
export function zoomForSpan(latSpan: number, lngSpan: number): number {
  const span = Math.max(latSpan, lngSpan, 1e-4);
  // 360° of longitude ≈ zoom 0; each zoom level halves the visible span.
  const z = Math.floor(Math.log2(360 / span)) - 1;
  return Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, z));
}

/**
 * Build a token-free OSM static-map URL for the given markers, or `null` when
 * no marker is valid.
 *
 * @param input - markers + optional pixel dimensions.
 * @returns the static-map URL, or `null` when there is nothing to render.
 * @example
 * buildOsmStaticMapUrl({ points: [
 *   { lat: 40.73, lng: -74.17, role: 'dest' },
 *   { lat: 40.75, lng: -74.2, role: 'crew' },
 * ] })
 * // → 'https://staticmap.openstreetmap.de/staticmap.php?center=40.74,-74.185
 * //    &zoom=12&size=640x420&maptype=mapnik
 * //    &markers=40.73,-74.17,ol-marker&markers=40.75,-74.2,ol-marker-blue'
 */
export function buildOsmStaticMapUrl(input: OsmStaticMapInput): string | null {
  const valid = (input.points ?? []).filter(validPoint);
  if (valid.length === 0) return null;

  const lats = valid.map((p) => p.lat);
  const lngs = valid.map((p) => p.lng);
  const minLat = Math.min(...lats);
  const maxLat = Math.max(...lats);
  const minLng = Math.min(...lngs);
  const maxLng = Math.max(...lngs);
  const centerLat = (minLat + maxLat) / 2;
  const centerLng = (minLng + maxLng) / 2;
  const zoom = zoomForSpan(maxLat - minLat, maxLng - minLng);

  const w = clampDim(input.width, DEFAULT_W);
  const h = clampDim(input.height, DEFAULT_H);

  const params = [
    `center=${coord(centerLat)},${coord(centerLng)}`,
    `zoom=${zoom}`,
    `size=${w}x${h}`,
    `maptype=mapnik`,
    ...valid.map((p) => `markers=${coord(p.lat)},${coord(p.lng)},${MARKER_ICON[p.role]}`),
  ];
  return `${OSM_STATIC_BASE}?${params.join('&')}`;
}
