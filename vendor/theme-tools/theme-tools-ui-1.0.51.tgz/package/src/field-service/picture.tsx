import type { JSX } from 'react';

/**
 * Renders a `<picture>` element that serves AVIF → WebP → original JPEG/PNG
 * in that order. Pairs with `scripts/build-image-variants.mjs` which writes
 * `.avif` + `.webp` siblings of every input the components reference.
 *
 * Usage: `<ResponsivePicture src="/services/power-washing.jpg" alt="…" />`
 */
interface ResponsivePictureProps {
  readonly src: string;
  readonly alt: string;
  readonly className?: string;
  readonly width?: number;
  readonly height?: number;
  readonly loading?: 'eager' | 'lazy';
  readonly decoding?: 'sync' | 'async' | 'auto';
  readonly fetchPriority?: 'high' | 'low' | 'auto';
  readonly sizes?: string;
}

function swapExt(src: string, ext: '.avif' | '.webp'): string {
  return src.replace(/\.(jpe?g|png)$/i, ext);
}

export function ResponsivePicture(props: ResponsivePictureProps): JSX.Element {
  const { src, alt, className, width, height, loading, decoding, fetchPriority, sizes } = props;
  const avif = swapExt(src, '.avif');
  const webp = swapExt(src, '.webp');
  return (
    <picture>
      <source srcSet={avif} type="image/avif" sizes={sizes} />
      <source srcSet={webp} type="image/webp" sizes={sizes} />
      <img
        src={src}
        alt={alt}
        className={className}
        width={width}
        height={height}
        loading={loading}
        decoding={decoding}
        fetchPriority={fetchPriority}
        sizes={sizes}
      />
    </picture>
  );
}
