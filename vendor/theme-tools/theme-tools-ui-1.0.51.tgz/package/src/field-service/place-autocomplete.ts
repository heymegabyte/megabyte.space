// Lightweight, framework-agnostic helpers for talking to /api/places.
// Wave 2A: used by Hero quick-quote + Booking quote flow.
//
// The richer React component (`AddressAutocomplete` in places-autocomplete.tsx)
// loads the Google Maps JS SDK directly. This module is the no-SDK fallback:
// it just proxies our own /api/places endpoints, which means no third-party
// script tag and no CSP escape hatch. Use this when you want a tiny combobox
// without pulling in the full SDK on first paint (e.g. hero LCP path).

export interface PlaceSuggestion {
  readonly placeId: string;
  readonly primary: string;
  readonly secondary: string;
}

export interface ResolvedPlace {
  readonly placeId: string;
  readonly formatted: string;
  readonly street: string;
  readonly city: string;
  readonly state: string;
  readonly zip: string;
  readonly lat?: number;
  readonly lng?: number;
}

interface AutocompleteResponse {
  ok: boolean;
  suggestions?: PlaceSuggestion[];
  disabled?: boolean;
}

interface DetailsResponse {
  ok: boolean;
  disabled?: boolean;
  place?: {
    id: string;
    formatted: string;
    street: string;
    city: string;
    state: string;
    zip: string;
    lat?: number;
    lng?: number;
    name?: string;
    phone?: string;
    website?: string;
    isBusiness?: boolean;
  };
}

/**
 * Generate (and cache on the global) a single browsing-session token so that
 * Google bills our autocomplete + details lookups as one session.
 */
const SESSION_KEY = '__bcl_place_session';
type WithSession = Window & { [SESSION_KEY]?: string };
export function getPlacesSession(): string {
  if (typeof window === 'undefined') return '';
  const w = window as WithSession;
  let token = w[SESSION_KEY];
  if (!token) {
    token =
      typeof crypto !== 'undefined' && 'randomUUID' in crypto
        ? crypto.randomUUID()
        : `s-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
    w[SESSION_KEY] = token;
  }
  return token;
}

/**
 * Reset the session after a successful pick — next typing session starts
 * a new billable bucket.
 */
export function resetPlacesSession(): void {
  if (typeof window === 'undefined') return;
  (window as WithSession)[SESSION_KEY] = undefined;
}

/**
 * Fetch up to 5 autocomplete suggestions for the given query.
 * Returns an empty array when the API is disabled or rate-limited.
 */
export async function fetchAutocomplete(
  query: string,
  options: { signal?: AbortSignal; mode?: 'address' | 'business' } = {},
): Promise<PlaceSuggestion[]> {
  const q = query.trim();
  if (q.length < 3) return [];
  const url = new URL('/api/places/autocomplete', window.location.origin);
  url.searchParams.set('q', q);
  url.searchParams.set('session', getPlacesSession());
  if (options.mode) url.searchParams.set('mode', options.mode);
  try {
    const res = await fetch(url.toString(), { signal: options.signal });
    if (!res.ok) return [];
    const data = (await res.json()) as AutocompleteResponse;
    if (!data.ok || !data.suggestions) return [];
    return data.suggestions;
  } catch {
    return [];
  }
}

/**
 * Resolve a placeId into a normalized street/city/state/zip block.
 * Returns null on failure so callers can fall back to manual entry.
 */
export async function fetchPlaceDetails(placeId: string): Promise<ResolvedPlace | null> {
  if (!placeId) return null;
  const url = new URL('/api/places/details', window.location.origin);
  url.searchParams.set('place_id', placeId);
  url.searchParams.set('session', getPlacesSession());
  try {
    const res = await fetch(url.toString());
    if (!res.ok) return null;
    const data = (await res.json()) as DetailsResponse;
    if (!data.ok || !data.place) return null;
    return {
      placeId: data.place.id,
      formatted: data.place.formatted,
      street: data.place.street,
      city: data.place.city,
      state: data.place.state,
      zip: data.place.zip,
      lat: data.place.lat,
      lng: data.place.lng,
    };
  } catch {
    return null;
  } finally {
    // Either way the session is consumed once details land.
    resetPlacesSession();
  }
}

/**
 * Simple debouncer that returns a wrapped fn + cancel handle. Used by the
 * Hero quick-quote autocomplete to avoid spamming /api/places on every keystroke.
 */
export function debounce<Args extends readonly unknown[]>(
  fn: (...args: Args) => void,
  ms: number,
): { run: (...args: Args) => void; cancel: () => void } {
  let timer: ReturnType<typeof setTimeout> | undefined;
  return {
    run(...args: Args) {
      if (timer !== undefined) clearTimeout(timer);
      timer = setTimeout(() => fn(...args), ms);
    },
    cancel() {
      if (timer !== undefined) clearTimeout(timer);
      timer = undefined;
    },
  };
}
