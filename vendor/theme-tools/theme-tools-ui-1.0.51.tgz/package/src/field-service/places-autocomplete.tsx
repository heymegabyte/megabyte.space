export interface GeocoderAddressComponentLike {
  long_name: string;
  short_name: string;
  types: string[];
}
export interface PlaceResultLike {
  address_components?: GeocoderAddressComponentLike[];
  formatted_address?: string;
  geometry?: {
    location?: {
      lat: () => number;
      lng: () => number;
    };
  };
}
export interface AutocompleteInstanceLike {
  addListener: (eventName: string, handler: () => void) => { remove?: () => void };
  getPlace: () => PlaceResultLike;
}
export interface GooglePlacesNamespace {
  maps: {
    event?: { clearInstanceListeners?: (instance: unknown) => void };
    importLibrary: (lib: string) => Promise<unknown>;
    places?: {
      Autocomplete: new (input: HTMLInputElement, opts: Record<string, unknown>) => AutocompleteInstanceLike;
    };
  };
}
import { useEffect, useRef, useState } from 'react';

// Singleton loader for the Google Maps JS SDK (places library).
// Re-uses any existing global google.maps namespace; concurrent callers share
// the same in-flight promise so we only inject the <script> tag once.

interface MapsConfig {
  ok: boolean;
  apiKey: string;
  mapId?: string;
}

let cachedConfig: Promise<MapsConfig> | null = null;
let sdkPromise: Promise<GooglePlacesNamespace> | null = null;

function getConfig(): Promise<MapsConfig> {
  if (cachedConfig) return cachedConfig;
  cachedConfig = fetch('/api/maps/config')
    .then((r) => r.json() as Promise<MapsConfig>)
    .catch(() => ({ ok: false, apiKey: '' }));
  return cachedConfig;
}

function loadPlacesSdk(apiKey: string): Promise<GooglePlacesNamespace> {
  if (
    typeof window !== 'undefined' &&
    (window as unknown as { google: GooglePlacesNamespace }).google?.maps?.places
  ) {
    return Promise.resolve((window as unknown as { google: GooglePlacesNamespace }).google);
  }
  if (sdkPromise) {
    return sdkPromise.then(async (g) => {
      if (!g.maps.places) await g.maps.importLibrary('places');
      return g;
    });
  }
  sdkPromise = new Promise((resolve, reject) => {
    const cbName = `__bcl_gmaps_places_cb_${Date.now()}`;
    (window as unknown as Record<string, unknown>)[cbName] = async () => {
      delete (window as unknown as Record<string, unknown>)[cbName];
      const g = (window as unknown as { google: GooglePlacesNamespace }).google;
      try {
        if (!g.maps.places) await g.maps.importLibrary('places');
      } catch {
        /* ignore — module may already be loaded */
      }
      resolve(g);
    };
    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(apiKey)}&v=weekly&loading=async&libraries=places&callback=${cbName}`;
    script.async = true;
    script.defer = true;
    script.onerror = () => reject(new Error('gmaps-places-load-failed'));
    document.head.appendChild(script);
  });
  return sdkPromise;
}

export interface ResolvedAddress {
  address1: string;
  city: string;
  state: string;
  zip: string;
  lat?: number;
  lng?: number;
  formatted?: string;
}

function pickComponent(
  components: GeocoderAddressComponentLike[],
  type: string,
  short = false,
): string {
  const hit = components.find((c) => c.types.includes(type));
  if (!hit) return '';
  return short ? hit.short_name : hit.long_name;
}

function placeToAddress(place: PlaceResultLike): ResolvedAddress {
  const comps = place.address_components ?? [];
  const streetNumber = pickComponent(comps, 'street_number');
  const route = pickComponent(comps, 'route');
  const address1 = [streetNumber, route].filter(Boolean).join(' ').trim();
  const city =
    pickComponent(comps, 'locality') ||
    pickComponent(comps, 'sublocality') ||
    pickComponent(comps, 'sublocality_level_1') ||
    pickComponent(comps, 'postal_town') ||
    pickComponent(comps, 'administrative_area_level_2');
  const state = pickComponent(comps, 'administrative_area_level_1', true);
  const zip = pickComponent(comps, 'postal_code');
  const loc = place.geometry?.location;
  return {
    address1,
    city,
    state,
    zip,
    lat: loc ? loc.lat() : undefined,
    lng: loc ? loc.lng() : undefined,
    formatted: place.formatted_address ?? '',
  };
}

export interface AddressAutocompleteProps {
  label: string;
  value: string;
  onChange: (next: string) => void;
  onSelect: (resolved: ResolvedAddress) => void;
  placeholder?: string;
  className?: string;
  inputClassName?: string;
  countryRestrictions?: string[];
  autoFocus?: boolean;
}

export function AddressAutocomplete({
  label,
  value,
  onChange,
  onSelect,
  placeholder = 'Start typing your street address…',
  className,
  inputClassName,
  countryRestrictions = ['us'],
  autoFocus,
}: AddressAutocompleteProps) {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const acRef = useRef<AutocompleteInstanceLike | null>(null);
  const [status, setStatus] = useState<'idle' | 'loading' | 'ready' | 'error'>('idle');

  useEffect(() => {
    let cancelled = false;
    setStatus('loading');
    getConfig()
      .then(async (cfg) => {
        if (cancelled) return;
        if (!cfg.ok || !cfg.apiKey) {
          setStatus('error');
          return;
        }
        const g = await loadPlacesSdk(cfg.apiKey);
        if (cancelled || !inputRef.current) return;
        const ac = new (g.maps.places!.Autocomplete)(inputRef.current, {
          types: ['address'],
          componentRestrictions: { country: countryRestrictions },
          fields: ['address_components', 'formatted_address', 'geometry.location'],
        });
        acRef.current = ac;
        ac.addListener('place_changed', () => {
          const place = ac.getPlace();
          if (!place || !place.address_components) return;
          const resolved = placeToAddress(place);
          onSelect(resolved);
        });
        setStatus('ready');
      })
      .catch(() => {
        if (!cancelled) setStatus('error');
      });
    return () => {
      cancelled = true;
      const gWin = (window as unknown as { google?: GooglePlacesNamespace }).google;
      if (acRef.current && gWin?.maps?.event?.clearInstanceListeners) {
        gWin.maps.event.clearInstanceListeners(acRef.current);
      }
      acRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <label className={`block ${className ?? ''}`}>
      <span className="block text-sm text-brand-mute mb-1">{label}</span>
      <div className="relative">
        <input
          ref={inputRef}
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          autoComplete="street-address"
          autoFocus={autoFocus}
          className={`w-full rounded-md border border-brand-line bg-brand-bg/40 px-3 py-2 text-brand-ink placeholder:text-brand-mute focus:outline-none focus:border-brand-accent ${inputClassName ?? ''}`}
        />
        {status === 'loading' && (
          <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[10px] uppercase tracking-wider text-brand-mute font-mono">
            loading…
          </span>
        )}
        {status === 'error' && (
          <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[10px] uppercase tracking-wider text-amber-300 font-mono">
            manual
          </span>
        )}
      </div>
      {status === 'ready' && (
        <span className="block text-[11px] text-brand-mute mt-1">
          Picking a suggestion auto-fills city, state, and ZIP.
        </span>
      )}
    </label>
  );
}
