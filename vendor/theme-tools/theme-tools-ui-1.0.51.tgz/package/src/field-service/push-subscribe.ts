/**
 * push-subscribe.ts — Wave 23
 *
 * One-shot helper that walks a user from "no push" to "subscribed + server
 * knows their endpoint" in a single async call. Used by PushPermissionPrompt
 * after the user accepts the rationale screen.
 *
 * Flow:
 *   1. Confirm the browser supports Service Worker + PushManager + Notification.
 *   2. Request Notification permission (no-op if already granted/denied).
 *   3. Await the registered service worker.
 *   4. Fetch the public VAPID key from /api/push/vapid-key (graceful 503/404
 *      fallback to the build-time constant below, which mirrors the deployed
 *      VAPID_PUBLIC_KEY worker secret).
 *   5. Subscribe via pushManager.subscribe with userVisibleOnly:true.
 *   6. POST the serialized subscription to /api/push/subscribe in the worker's
 *      { endpoint, keys: { p256dh, auth } } shape (push-register.ts contract).
 *
 * Returns true only when every step succeeded. Never throws — every failure
 * path resolves to false so the caller can render a graceful retry UI.
 */

// Build-time VAPID public key — mirrors the deployed VAPID_PUBLIC_KEY worker
// secret (read from the live GET /api/push/vapid-key on 2026-06-28). Used only
// when that endpoint is unreachable; the live route normally serves this same
// key from env. Base64url-encoded 65-byte uncompressed P-256 key. Must match
// the server's signing key or the push service rejects the subscription.
const VAPID_PUB_FALLBACK =
  'BIYzfi8P3X7iTsSCexpOGcMGc01ID_ToawZ9hbzdAbH58gZ7XhvZO5FSUp73ZKEWNK3mCMrdpexX16OM64fSjhQ';

/**
 * Convert a base64url-encoded VAPID public key into the Uint8Array the
 * PushManager expects for `applicationServerKey`. Pads + maps URL-safe chars.
 */
function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const raw = atob(base64);
  const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i += 1) out[i] = raw.charCodeAt(i);
  return out;
}

async function fetchVapidPublicKey(): Promise<string> {
  try {
    const res = await fetch('/api/push/vapid-key', { credentials: 'include' });
    if (!res.ok) return VAPID_PUB_FALLBACK;
    const data = (await res.json()) as { publicKey?: string; vapid?: string };
    return data.publicKey || data.vapid || VAPID_PUB_FALLBACK;
  } catch {
    return VAPID_PUB_FALLBACK;
  }
}

export type PushRole = 'customer' | 'crew';

export async function subscribeUserToPush(role: PushRole): Promise<boolean> {
  if (typeof window === 'undefined') return false;
  if (!('serviceWorker' in navigator)) return false;
  if (!('PushManager' in window)) return false;
  if (typeof Notification === 'undefined') return false;

  let permission: NotificationPermission = Notification.permission;
  if (permission === 'default') {
    try {
      permission = await Notification.requestPermission();
    } catch {
      return false;
    }
  }
  if (permission !== 'granted') return false;

  let registration: ServiceWorkerRegistration;
  try {
    registration = await navigator.serviceWorker.ready;
  } catch {
    return false;
  }

  const publicKey = await fetchVapidPublicKey();

  let subscription: PushSubscription | null = null;
  try {
    // Reuse any pre-existing subscription to avoid re-prompting the push
    // service unnecessarily; only mint a new one when none exists.
    subscription = await registration.pushManager.getSubscription();
    if (!subscription) {
      // Cast to BufferSource — TS DOM lib types Uint8Array as
      // ArrayBufferView<ArrayBufferLike> which is structurally identical
      // to BufferSource but the type system refuses the literal.
      const appServerKey = urlBase64ToUint8Array(publicKey) as unknown as BufferSource;
      subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: appServerKey,
      });
    }
  } catch {
    return false;
  }

  if (!subscription) return false;

  // Map the browser subscription envelope to the worker's /subscribe contract
  // (push-register.ts SUBSCRIBE_SCHEMA): { endpoint, keys: { p256dh, auth } }.
  // `role` is carried for future crew routing; zod strips unknown keys today.
  const json = subscription.toJSON();
  const endpoint = json.endpoint;
  const p256dh = json.keys?.p256dh;
  const auth = json.keys?.auth;
  if (!endpoint || !p256dh || !auth) return false;

  try {
    const res = await fetch('/api/push/subscribe', {
      method: 'POST',
      credentials: 'include',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ endpoint, keys: { p256dh, auth }, role }),
    });
    if (!res.ok) return false;
  } catch {
    return false;
  }

  return true;
}

/**
 * Quick capability probe — useful for gating the prompt UI so we don't show
 * the rationale screen on browsers (Safari iOS without PWA install) where
 * push is unavailable.
 */
export function isPushSupported(): boolean {
  if (typeof window === 'undefined') return false;
  return (
    'serviceWorker' in navigator && 'PushManager' in window && typeof Notification !== 'undefined'
  );
}
