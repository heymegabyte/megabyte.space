/**
 * Roving-tabindex keyboard navigation for custom ARIA radio groups.
 *
 * The ARIA Authoring Practices radio-group pattern requires the group to be a
 * SINGLE tab stop: only the checked option has `tabIndex=0`, the rest carry
 * `tabIndex=-1`, and the arrow keys move selection between options (wrapping at
 * the ends). A naive `role="radio"` row where every button is independently
 * Tab-focusable and only `onClick` changes the value FAILS this pattern — a
 * keyboard-only user must Tab through every option and can't arrow between them.
 * axe-core does not detect this (it is an interaction-pattern gap, not a static
 * attribute one), so it must be unit-pinned instead.
 *
 * This module is pure + framework-free so the worker, the React widgets, and the
 * unit suite can all share one implementation — no React import, no DOM.
 */

/** Keys that drive selection in a horizontal OR vertical radio group. */
const NEXT_KEYS = new Set(['ArrowRight', 'ArrowDown']);
const PREV_KEYS = new Set(['ArrowLeft', 'ArrowUp']);

/**
 * Compute the index a radio group should move selection to for a key press.
 *
 * @param currentIndex - The index of the currently-selected option.
 * @param count - Total number of options in the group (must be ≥ 1).
 * @param key - The `KeyboardEvent.key` value.
 * @returns The next selected index, or `null` when the key is not a navigation
 *   key (caller should not preventDefault / move focus in that case).
 * @example
 * nextRadioIndex(0, 4, 'ArrowRight') // → 1
 * nextRadioIndex(3, 4, 'ArrowRight') // → 0  (wraps to start)
 * nextRadioIndex(0, 4, 'ArrowLeft')  // → 3  (wraps to end)
 * nextRadioIndex(2, 4, 'Home')       // → 0
 * nextRadioIndex(2, 4, 'End')        // → 3
 * nextRadioIndex(1, 4, 'Tab')        // → null
 */
export function nextRadioIndex(
  currentIndex: number,
  count: number,
  key: string,
): number | null {
  if (count <= 0) return null;
  const i = Math.min(Math.max(currentIndex, 0), count - 1);
  if (NEXT_KEYS.has(key)) return (i + 1) % count;
  if (PREV_KEYS.has(key)) return (i - 1 + count) % count;
  if (key === 'Home') return 0;
  if (key === 'End') return count - 1;
  return null;
}

/**
 * Roving `tabIndex` for one option in an ARIA radio group: the selected option
 * is the single tab stop (`0`); every other option is `-1`.
 *
 * @param isSelected - Whether this option is the currently-checked radio.
 * @returns `0` for the selected option, `-1` otherwise.
 * @example
 * rovingTabIndex(true)  // → 0
 * rovingTabIndex(false) // → -1
 */
export function rovingTabIndex(isSelected: boolean): 0 | -1;
export function rovingTabIndex(optionIndex: number, activeIndex: number): 0 | -1;
export function rovingTabIndex(a: boolean | number, b?: number): 0 | -1 {
  if (typeof a === 'boolean') return a ? 0 : -1;
  return a === b ? 0 : -1;
}

export function focusRadioAtIndex(group: HTMLElement | null, index: number): void {
  if (!group) return;
  const options = group.querySelectorAll<HTMLElement>('[role="radio"]');
  options.item(index)?.focus();
}
