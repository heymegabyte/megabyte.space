// Reads utm_* / ref query params on first page load, pings POST /api/referral
// once per session, and stashes the touch in sessionStorage so the booking
// form can include the source on submit. No PII — just attribution params.

const SESSION_KEY = 'bcl-referral';

interface Touch {
  source: string;
  medium: string;
  campaign: string;
  ref: string;
  landing: string;
  ts: string;
}

export function trackReferralIfPresent(): void {
  if (typeof window === 'undefined') return;
  const params = new URLSearchParams(window.location.search);
  const source = params.get('utm_source') || params.get('ref') || '';
  if (!source) {
    // Still record document.referrer as soft attribution if we have one.
    const ref = document.referrer;
    if (ref && !ref.includes(window.location.host)) {
      sessionStorage.setItem(
        SESSION_KEY,
        JSON.stringify({
          source: 'referrer',
          medium: 'organic',
          campaign: '',
          ref,
          landing: window.location.pathname,
          ts: new Date().toISOString(),
        } satisfies Touch),
      );
    }
    return;
  }

  if (sessionStorage.getItem(SESSION_KEY)) return;

  const touch: Touch = {
    source: source.slice(0, 60),
    medium: (params.get('utm_medium') || '').slice(0, 60),
    campaign: (params.get('utm_campaign') || '').slice(0, 120),
    ref: (params.get('ref') || '').slice(0, 160),
    landing: window.location.pathname,
    ts: new Date().toISOString(),
  };
  sessionStorage.setItem(SESSION_KEY, JSON.stringify(touch));

  fetch('/api/referral', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(touch),
    keepalive: true,
  }).catch(() => {
    /* best-effort */
  });
}

export function getReferralTouch(): Touch | null {
  if (typeof window === 'undefined') return null;
  const raw = sessionStorage.getItem(SESSION_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as Touch;
  } catch {
    return null;
  }
}
