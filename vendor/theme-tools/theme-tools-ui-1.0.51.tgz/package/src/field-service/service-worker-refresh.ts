export interface ControllerRefreshState {
  readonly hadControllerAtBoot: boolean;
  readonly refreshing: boolean;
}

/**
 * A newly installed worker claims an uncontrolled first-visit page too. That
 * controllerchange must not reload the visitor mid-interaction; only replacing
 * a controller that existed when the app booted represents an update refresh.
 */
export function shouldReloadForControllerChange({
  hadControllerAtBoot,
  refreshing,
}: ControllerRefreshState): boolean {
  return hadControllerAtBoot && !refreshing;
}
