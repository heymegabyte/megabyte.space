/**
 * SmsConsentDisclosure — the canonical FCC/CTIA point-of-consent SMS notice.
 *
 * TCPA + CTIA Messaging Principles require the FULL disclosure to live AT the
 * point a phone number is collected for texting — not buried on a /tcpa page.
 * Every required element must be present beside the opt-in control:
 *   1. Sender identity ........ "Brick Labor"
 *   2. Message purpose ........ booking + crew dispatch updates
 *   3. Frequency .............. "up to ~6 messages per booking"
 *   4. Carrier cost notice .... "Msg & data rates may apply"
 *   5. Opt-out + help ......... "Reply STOP to cancel, HELP for help"
 *   6. Not-a-condition ........ "Consent is not a condition of service"
 *   7. Policy links ........... /tcpa + /privacy
 *
 * Missing any element = $500–$1,500-per-text TCPA exposure. `scripts/
 * validate-tcpa-consent.mjs` gates the build on all seven tokens being present
 * here AND on every SMS-opt-in surface importing this component.
 *
 * One canonical disclosure, imported everywhere — never re-typed per form
 * (per repo-folder-hygiene single-source-of-truth).
 */
export function SmsConsentDisclosure({ className = '' }: { className?: string }) {
  return (
    <p
      data-testid="sms-consent-disclosure"
      data-bcl-tcpa-consent
      className={`text-[11px] leading-snug text-brand-mute ${className}`}
    >
      By sharing your number you agree <strong className="text-brand-ink">Brick Labor</strong> may
      text you booking confirmations and crew dispatch updates (up to ~6 messages per booking). Msg
      &amp; data rates may apply. Reply <strong className="text-brand-ink">STOP</strong> to cancel,{' '}
      <strong className="text-brand-ink">HELP</strong> for help. Consent is not a condition of
      service. See our{' '}
      <a href="/tcpa" className="text-brand-accent underline hover:no-underline">
        SMS&nbsp;Policy
      </a>{' '}
      &amp;{' '}
      <a href="/privacy" className="text-brand-accent underline hover:no-underline">
        Privacy&nbsp;Policy
      </a>
      .
    </p>
  );
}
