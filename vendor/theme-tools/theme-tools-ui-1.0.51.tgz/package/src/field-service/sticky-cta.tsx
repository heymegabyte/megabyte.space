import { useEffect, useState, type ReactElement } from 'react';
import { track } from './analytics.js';

// Sticky mobile CTA — slides up from the bottom (no overlay) once the
// hero/in-flow primary CTA has scrolled out of view. 56-64px tall so it
// never eats more than a single tap-target's worth of real estate.
//
// Triggered via an IntersectionObserver on a sentinel id (default `book-cta`).
// Falls back to a scroll listener if IO isn't available.

export interface StickyCtaProps {
  /** Sentinel element id we watch — when it leaves viewport, CTA shows. */
  readonly sentinelId?: string;
  /** Anchor href to scroll to on tap. Default `#book`. */
  readonly href?: string;
  /** Primary label — first-person to match brand voice. */
  readonly label?: string;
  /** Trust microcopy under the label. */
  readonly subLabel?: string;
  /** Optional secondary action — usually the SMS quote alt CTA. */
  readonly secondary?: {
    readonly label: string;
    readonly onClick: () => void;
  };
  /** Hide entirely when the user has dismissed once this session. */
  readonly dismissible?: boolean;
}

const DISMISSED_KEY = 'bcl-sticky-cta-dismissed-v1';

/**
 * Slides in from the bottom of the viewport on mobile when the primary
 * hero/quote CTA scrolls off-screen. Hidden on lg+ where the desktop CTA
 * stays sticky in the hero column. Honors prefers-reduced-motion.
 */
export function StickyCta({
  sentinelId = 'book-cta-sentinel',
  href = '/book',
  label = 'Get My Quote',
  subLabel = 'Insured · photo-documented · 60-sec quote',
  secondary,
  dismissible = true,
}: StickyCtaProps): ReactElement | null {
  const [visible, setVisible] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (dismissible) {
      try {
        if (sessionStorage.getItem(DISMISSED_KEY) === '1') {
          setDismissed(true);
          return;
        }
      } catch {
        /* noop */
      }
    }
    const target = document.getElementById(sentinelId);
    if (!target) {
      // Fallback: show after 600px scroll, hide before.
      const onScroll = () => setVisible(window.scrollY > 600);
      onScroll();
      window.addEventListener('scroll', onScroll, { passive: true });
      return () => window.removeEventListener('scroll', onScroll);
    }
    const io = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.target === target) setVisible(!entry.isIntersecting);
        }
      },
      { threshold: 0, rootMargin: '0px 0px -10% 0px' },
    );
    io.observe(target);
    return () => io.disconnect();
  }, [sentinelId, dismissible]);

  if (dismissed) return null;

  return (
    <div
      data-bcl-sticky-cta
      data-visible={visible ? '1' : '0'}
      aria-hidden={!visible}
      className={[
        'lg:hidden fixed inset-x-0 bottom-0 z-40 px-3 pb-3',
        'pointer-events-none transition-transform duration-[333ms] ease-[cubic-bezier(0.22,1,0.36,1)] motion-reduce:transition-none',
        visible ? 'translate-y-0' : 'translate-y-full',
      ].join(' ')}
      style={{ paddingBottom: 'max(0.75rem, env(safe-area-inset-bottom))' }}
    >
      <div
        className={[
          'pointer-events-auto mx-auto flex max-w-md items-center gap-2',
          'rounded-2xl border border-brand-accent/40 bg-bg-elevated/95 backdrop-blur-md',
          'px-3 py-2 shadow-2xl shadow-black/40',
        ].join(' ')}
        style={{ minHeight: 56, maxHeight: 64 }}
      >
        <a
          href={href}
          onClick={() => track('sticky_cta_tap', { href, label })}
          className="flex-1 flex flex-col justify-center rounded-xl bg-brand-accent px-3 py-2 text-bg-primary"
        >
          <span className="font-display text-sm font-extrabold leading-tight">{label}</span>
          <span className="text-[10px] uppercase tracking-wider opacity-80 leading-tight">
            {subLabel}
          </span>
        </a>
        {secondary && (
          <button
            type="button"
            onClick={() => {
              track('sticky_cta_secondary_tap', { label: secondary.label });
              secondary.onClick();
            }}
            className="shrink-0 rounded-xl border border-brand-line px-2 py-2 text-[10px] font-mono uppercase tracking-wider text-brand-mute hover:border-brand-accent hover:text-brand-accent"
          >
            {secondary.label}
          </button>
        )}
        {dismissible && (
          <button
            type="button"
            aria-label="Dismiss"
            onClick={() => {
              try {
                sessionStorage.setItem(DISMISSED_KEY, '1');
              } catch {
                /* noop */
              }
              setDismissed(true);
              track('sticky_cta_dismiss');
            }}
            className="shrink-0 rounded-md p-1 text-brand-mute hover:text-brand-ink"
          >
            <span aria-hidden>✕</span>
          </button>
        )}
      </div>
    </div>
  );
}

/**
 * Invisible sentinel — drop one wherever the in-flow primary CTA lives.
 * IntersectionObserver toggles `<StickyCta>` based on this leaving viewport.
 */
export function StickyCtaSentinel({
  id = 'book-cta-sentinel',
}: {
  readonly id?: string;
}): ReactElement {
  return <span id={id} aria-hidden className="block h-0 w-0" />;
}
