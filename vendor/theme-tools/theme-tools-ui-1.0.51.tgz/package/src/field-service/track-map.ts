/**
 * track-map.ts — pure builder for the customer `/track` live crew-tracking map.
 *
 * The worker's `GET /api/track/:id` snapshot already serves a `liveMap` payload
 * (destination coords + the lead crew's live GPS position, via `CrewLocationDO`)
 * whenever the `live_job_map` flag is on. This helper turns that payload into a
 * token-free OSM static-map URL (via the shared `osm-static-map` builder) — a
 * map with the destination pin + the moving crew pin(s), auto-framed to all
 * markers — so the post-pay customer sees the Uber/Lyft "your crew is on the
 * way" map, not just a text ETA pill.
 *
 * Kept a pure function (single source of truth for the rendered `<img>` AND its
 * unit tests) so the customer map can never drift from the encoding the snapshot
 * feeds it. The static-image approach keeps the heavy GL bundle off this
 * money-path page (TTFR-safe).
 */

import { buildOsmStaticMapUrl, type OsmMapPoint } from "./osm-static-map.js";

export interface TrackMapPoint {
  readonly lat: number;
  readonly lng: number;
}

export interface TrackMapCrew extends TrackMapPoint {
  readonly heading?: number | null;
}

export interface TrackMapInput {
  /** Customer job destination, or null until it's geocoded. */
  readonly dest: TrackMapPoint | null;
  /** Live crew GPS positions (lead crew only, per the snapshot). */
  readonly crew: readonly TrackMapCrew[];
  /** Rendered pixel width (clamped to OSM renderer limits). */
  readonly width?: number;
  /** Rendered pixel height (clamped to OSM renderer limits). */
  readonly height?: number;
}

const DEFAULT_W = 640;
const DEFAULT_H = 420;

/**
 * Build the token-free OSM static-map URL for the customer live map.
 *
 * @returns the URL, or `null` when there is no valid marker — the caller renders
 * an "unavailable" state rather than a broken image.
 * @example
 * buildTrackStaticMapUrl({ dest: { lat: 40.73, lng: -74.17 },
 *   crew: [{ lat: 40.75, lng: -74.2 }] })
 * // → 'https://staticmap.openstreetmap.de/staticmap.php?center=…&markers=…'
 */
export function buildTrackStaticMapUrl(input: TrackMapInput): string | null {
  const points: OsmMapPoint[] = [];
  // Destination first so the crew pin (appended last) renders on top of it.
  if (input.dest) {
    points.push({ lat: input.dest.lat, lng: input.dest.lng, role: 'dest' });
  }
  for (const c of input.crew ?? []) {
    points.push({ lat: c.lat, lng: c.lng, role: 'crew' });
  }
  return buildOsmStaticMapUrl({
    points,
    width: input.width ?? DEFAULT_W,
    height: input.height ?? DEFAULT_H,
  });
}
