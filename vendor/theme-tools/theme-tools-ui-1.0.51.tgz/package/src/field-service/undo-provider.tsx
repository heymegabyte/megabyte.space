import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import type { ReactNode } from 'react';

/**
 * Global undo provider. Any destructive op registers an undo + label;
 * a fixed bottom-right toast shows the most recent with a countdown bar
 * and an Undo button. Global Cmd+Z fires the most recent undo when the
 * user is NOT focused in an input/textarea/contentEditable.
 *
 * Session-scoped — nothing persists.
 */

interface UndoEntry {
  id: string;
  label: string;
  undoFn: () => void | Promise<void>;
  expiresAt: number;
  used: boolean;
}

interface UndoContextValue {
  registerUndo: (
    label: string,
    undoFn: () => void | Promise<void>,
    opts?: { durationMs?: number },
  ) => void;
}

const UndoContext = createContext<UndoContextValue | null>(null);

export function useUndo(): UndoContextValue {
  const ctx = useContext(UndoContext);
  if (!ctx) {
    // Safe no-op when provider is missing — components shouldn't crash.
    return { registerUndo: () => undefined };
  }
  return ctx;
}

const MAX_STACK = 5;
const DEFAULT_DURATION = 8000;

export function UndoProvider({ children }: { children: ReactNode }) {
  const [stack, setStack] = useState<UndoEntry[]>([]);
  const stackRef = useRef<UndoEntry[]>([]);
  stackRef.current = stack;

  const registerUndo = useCallback<UndoContextValue['registerUndo']>((label, undoFn, opts) => {
    const entry: UndoEntry = {
      id: `u_${crypto.randomUUID()}`,
      label,
      undoFn,
      expiresAt: Date.now() + (opts?.durationMs ?? DEFAULT_DURATION),
      used: false,
    };
    setStack((prev) => [entry, ...prev.filter((e) => !e.used)].slice(0, MAX_STACK));
  }, []);

  // Tick the top entry's countdown every 100ms; drop expired entries.
  const [, setTick] = useState(0);
  useEffect(() => {
    const t = window.setInterval(() => {
      setStack((prev) => prev.filter((e) => !e.used && e.expiresAt > Date.now()));
      setTick((n) => n + 1);
    }, 100);
    return () => window.clearInterval(t);
  }, []);

  // Cmd+Z (or Ctrl+Z) when not in an input.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!(e.metaKey || e.ctrlKey) || e.key.toLowerCase() !== 'z') return;
      const target = e.target as HTMLElement | null;
      const tag = target?.tagName ?? '';
      if (tag === 'INPUT' || tag === 'TEXTAREA' || target?.isContentEditable) return;
      const top = stackRef.current[0];
      if (!top) return;
      e.preventDefault();
      void invoke(top);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  async function invoke(entry: UndoEntry) {
    setStack((prev) => prev.map((e) => (e.id === entry.id ? { ...e, used: true } : e)));
    try {
      await entry.undoFn();
    } catch (err) {
      // Error tracked via Sentry
    }
  }

  const value = useMemo<UndoContextValue>(() => ({ registerUndo }), [registerUndo]);

  const top = stack[0];
  const remaining = top ? Math.max(0, top.expiresAt - Date.now()) : 0;
  const total = DEFAULT_DURATION;
  const pct = top ? (remaining / total) * 100 : 0;

  return (
    <UndoContext.Provider value={value}>
      {children}
      {top && !top.used && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-6 right-6 z-[200] w-80 overflow-hidden rounded-xl border border-brand-line bg-bg-elevated p-4 shadow-2xl"
          style={{ viewTransitionName: 'bcl-undo-toast' }}
          data-enter
        >
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0 flex-1">
              <p className="font-mono text-[10px] uppercase tracking-widest text-brand-accent">
                Undo available
              </p>
              <p className="mt-1 text-sm text-brand-ink">{top.label}</p>
            </div>
            <button
              type="button"
              onClick={() => void invoke(top)}
              className="rounded-md bg-brand-accent px-3 py-1.5 text-xs font-semibold text-black hover:brightness-110"
              data-bcl-action="undo_clicked"
            >
              Undo
            </button>
          </div>
          <div className="mt-3 h-0.5 w-full overflow-hidden rounded-full bg-brand-line">
            <div
              className="h-full bg-brand-accent transition-[width]"
              style={{ width: `${pct}%`, transitionDuration: '100ms' }}
            />
          </div>
          <p className="mt-1 text-[10px] text-brand-mute">
            <kbd className="rounded bg-bg-primary px-1">Cmd Z</kbd> for last undo
          </p>
        </div>
      )}
    </UndoContext.Provider>
  );
}
