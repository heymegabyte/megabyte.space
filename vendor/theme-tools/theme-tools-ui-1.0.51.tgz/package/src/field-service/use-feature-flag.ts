/**
 * use-feature-flag.ts — React hook for Wave 27 feature flag gates.
 *
 * Fetches `/api/feature-flags` once per page load, caches the response in
 * memory (per-tab), and exposes a synchronous `useFeatureFlag(key)` hook
 * that re-renders the component when the response arrives.
 *
 * Default-off — the hook returns `false` until the response lands, so any
 * gated component disappears until proven enabled. Same posture as the
 * `[[feature-flags]]` SUPREME rule's recommended server-side behavior.
 *
 * Bonus: `useFeatureFlags()` returns the full record for UIs that gate
 * many sub-toggles in one component without N hook calls.
 */

import { useEffect, useState } from 'react';

type FlagMap = Record<string, boolean>;

let cache: FlagMap | null = null;
let inflight: Promise<FlagMap> | null = null;
const listeners = new Set<(m: FlagMap) => void>();

async function fetchFlags(): Promise<FlagMap> {
  if (cache) return cache;
  if (inflight) return inflight;
  inflight = (async () => {
    try {
      const r = await fetch('/api/feature-flags', { credentials: 'same-origin' });
      if (!r.ok) throw new Error(`status ${r.status}`);
      const j = (await r.json()) as { flags?: FlagMap };
      const next = j.flags ?? {};
      cache = next;
      for (const cb of listeners) cb(next);
      return next;
    } catch {
      cache = {};
      return {};
    } finally {
      inflight = null;
    }
  })();
  return inflight;
}

/** Single-flag hook. Returns `false` until the fetch lands. */
export function useFeatureFlag(key: string): boolean {
  const [enabled, setEnabled] = useState<boolean>(Boolean(cache?.[key]));
  useEffect(() => {
    let cancelled = false;
    const apply = (m: FlagMap) => {
      if (!cancelled) setEnabled(Boolean(m[key]));
    };
    if (cache) apply(cache);
    else fetchFlags().then(apply);
    listeners.add(apply);
    return () => {
      cancelled = true;
      listeners.delete(apply);
    };
  }, [key]);
  return enabled;
}

/** Whole-record hook for components that gate several toggles. */
export function useFeatureFlags(): FlagMap {
  const [flags, setFlags] = useState<FlagMap>(cache ?? {});
  useEffect(() => {
    let cancelled = false;
    const apply = (m: FlagMap) => {
      if (!cancelled) setFlags(m);
    };
    if (cache) apply(cache);
    else fetchFlags().then(apply);
    listeners.add(apply);
    return () => {
      cancelled = true;
      listeners.delete(apply);
    };
  }, []);
  return flags;
}

/** Call after admin mutation (or whenever you want to refresh). */
export function resetFeatureFlagsCache(): void {
  cache = null;
  inflight = null;
  fetchFlags();
}
