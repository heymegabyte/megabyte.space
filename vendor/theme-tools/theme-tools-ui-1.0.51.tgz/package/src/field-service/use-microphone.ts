import { useCallback, useEffect, useRef, useState } from 'react';

/**
 * First-class microphone support for the /contact chat.
 *
 * Owns the full audio graph (getUserMedia → AudioContext → AnalyserNode) that
 * drives the background visualizer, PLUS best-effort speech-to-text via the Web
 * Speech API. The visualizer works on every browser that grants mic access; the
 * transcription layer is additive — where SpeechRecognition is missing (Firefox
 * today) the orb still pulses to the user's voice, we just can't type it for them.
 *
 * @remarks Impure — calls `navigator.mediaDevices.getUserMedia` + Web Audio RNG.
 */

/** Minimal Web Speech API typings (absent from lib.dom in TS 5.7). */
interface SpeechRecognitionAlternativeLike {
  readonly transcript: string;
}
interface SpeechRecognitionResultLike {
  readonly isFinal: boolean;
  readonly length: number;
  readonly [index: number]: SpeechRecognitionAlternativeLike | undefined;
}
interface SpeechRecognitionResultListLike {
  readonly length: number;
  readonly [index: number]: SpeechRecognitionResultLike | undefined;
}
interface SpeechRecognitionEventLike extends Event {
  readonly resultIndex: number;
  readonly results: SpeechRecognitionResultListLike;
}
interface SpeechRecognitionLike extends EventTarget {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  start(): void;
  stop(): void;
  abort(): void;
  onresult: ((e: SpeechRecognitionEventLike) => void) | null;
  onerror: ((e: Event) => void) | null;
  onend: (() => void) | null;
}
type SpeechRecognitionCtor = new () => SpeechRecognitionLike;

/** Resolve the (prefixed) SpeechRecognition constructor, or null when unsupported. */
function getSpeechCtor(): SpeechRecognitionCtor | null {
  if (typeof window === 'undefined') return null;
  const w = window as unknown as {
    SpeechRecognition?: SpeechRecognitionCtor;
    webkitSpeechRecognition?: SpeechRecognitionCtor;
  };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

/** Resolve the (prefixed) AudioContext constructor, or null when unsupported. */
function getAudioCtor(): typeof AudioContext | null {
  if (typeof window === 'undefined') return null;
  const w = window as unknown as {
    AudioContext?: typeof AudioContext;
    webkitAudioContext?: typeof AudioContext;
  };
  return w.AudioContext ?? w.webkitAudioContext ?? null;
}

export interface Microphone {
  /** getUserMedia + AudioContext are both available. */
  readonly supported: boolean;
  /** Speech-to-text (Web Speech API) is available. */
  readonly speechSupported: boolean;
  /** Currently capturing audio. */
  readonly active: boolean;
  /** Live (not-yet-finalized) transcript, for on-screen feedback. */
  readonly interim: string;
  /** Last error message, if any. */
  readonly error: string;
  /** Frequency-analysis node for the visualizer (null until active). */
  readonly analyser: AnalyserNode | null;
  readonly start: () => Promise<void>;
  readonly stop: () => void;
  readonly toggle: () => void;
}

/**
 * Wire a microphone to a transcript sink.
 *
 * @param onTranscript - Called with each finalized speech fragment (trimmed).
 * @returns Live microphone state + start/stop/toggle controls.
 * @example
 * const mic = useMicrophone((text) => setNotes((n) => `${n} ${text}`.trim()));
 * <button onClick={mic.toggle}>{mic.active ? 'Stop' : 'Talk'}</button>
 * <MicVisualizer analyser={mic.analyser} active={mic.active} />
 */
export function useMicrophone(onTranscript: (text: string) => void): Microphone {
  const [active, setActive] = useState(false);
  const [analyser, setAnalyser] = useState<AnalyserNode | null>(null);
  const [interim, setInterim] = useState('');
  const [error, setError] = useState('');

  const streamRef = useRef<MediaStream | null>(null);
  const ctxRef = useRef<AudioContext | null>(null);
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);
  const onTranscriptRef = useRef(onTranscript);
  onTranscriptRef.current = onTranscript;

  const supported =
    typeof navigator !== 'undefined' &&
    Boolean(navigator.mediaDevices?.getUserMedia) &&
    getAudioCtor() !== null;
  const speechSupported = getSpeechCtor() !== null;

  const stop = useCallback(() => {
    setActive(false);
    setInterim('');
    try {
      recognitionRef.current?.stop();
    } catch {
      /* recognition already ended */
    }
    recognitionRef.current = null;
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    if (ctxRef.current && ctxRef.current.state !== 'closed') {
      void ctxRef.current.close();
    }
    ctxRef.current = null;
    setAnalyser(null);
  }, []);

  const start = useCallback(async () => {
    const AudioCtor = getAudioCtor();
    if (!supported || !AudioCtor) {
      setError('Microphone is not supported in this browser.');
      return;
    }
    setError('');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const ctx = new AudioCtor();
      ctxRef.current = ctx;
      const source = ctx.createMediaStreamSource(stream);
      const node = ctx.createAnalyser();
      node.fftSize = 256;
      node.smoothingTimeConstant = 0.8;
      source.connect(node);
      setAnalyser(node);
      setActive(true);

      // Speech-to-text is best-effort; the visualizer runs regardless.
      const Ctor = getSpeechCtor();
      if (Ctor) {
        const rec = new Ctor();
        rec.lang = 'en-US';
        rec.continuous = true;
        rec.interimResults = true;
        rec.onresult = (e) => {
          let finalText = '';
          let interimText = '';
          for (let i = e.resultIndex; i < e.results.length; i++) {
            const r = e.results[i];
            if (!r) continue;
            const alt = r[0]?.transcript ?? '';
            if (r.isFinal) finalText += alt;
            else interimText += alt;
          }
          if (finalText) onTranscriptRef.current(finalText.trim());
          setInterim(interimText);
        };
        rec.onerror = () => {
          /* keep the visualizer alive on a transient recognition error */
        };
        rec.onend = () => {
          setInterim('');
        };
        recognitionRef.current = rec;
        try {
          rec.start();
        } catch {
          /* start() throws if already running — ignore */
        }
      }
    } catch {
      setError('Microphone access was blocked. Enable it in your browser to talk.');
      stop();
    }
  }, [supported, stop]);

  const toggle = useCallback(() => {
    if (active) stop();
    else void start();
  }, [active, start, stop]);

  useEffect(() => () => stop(), [stop]);

  return { supported, speechSupported, active, interim, error, analyser, start, stop, toggle };
}
