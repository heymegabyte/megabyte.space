/**
 * Shared modal entrance/exit motion — the ONE source of truth for the A7
 * "Modals/drawers — backdrop fade + panel slide/scale, focus-trap preserved,
 * Esc animates close" choreography (BACKLOG ★ ANIMATION SYSTEM).
 *
 * The motion itself lives in CSS (`bcl-modal-backdrop` / `bcl-modal-panel`
 * classes + the `bcl-modal-backdrop-in|out` / `bcl-modal-panel-in|out`
 * keyframes in `styles/index.css`, all `prefers-reduced-motion`-gated). This
 * module owns the React glue that drives them: a `closing` state for the exit
 * animation, a referentially-stable `requestClose` that plays the exit then
 * calls `onClose` after the animation ends, and an instant-close fast path when
 * the OS asks for reduced motion (so no dangling timeout fires).
 *
 * Every dialog reuses this instead of re-implementing the close timing inline —
 * `SurgeExplainerModal` and `ExitIntentRescue` share these constants + helper so
 * the duration can never drift from the CSS keyframe.
 */
import { useCallback, useRef, useState } from 'react';

/** CSS class running the shared backdrop fade (`bcl-modal-backdrop-in` / `-out`). */
export const MODAL_BACKDROP_CLASS = 'bcl-modal-backdrop';

/** CSS class running the shared panel slide+scale settle (`bcl-modal-panel-in` / `-out`). */
export const MODAL_PANEL_CLASS = 'bcl-modal-panel';

/**
 * Exit-animation duration in ms. MUST stay equal to the `bcl-modal-panel-out`
 * duration in `src/web/styles/index.css` (180ms) — the modal-motion unit test
 * fails the build if they drift apart.
 */
export const MODAL_EXIT_MS = 180;

/**
 * True when the user has asked the OS to minimize motion. SSR-safe — returns
 * `false` when `window` / `matchMedia` are unavailable (server render).
 *
 * @returns whether `prefers-reduced-motion: reduce` is active
 * @example
 * if (prefersReducedMotion()) onClose(); // skip the exit animation
 */
export function prefersReducedMotion(): boolean {
  return (
    typeof window !== 'undefined' &&
    typeof window.matchMedia === 'function' &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches
  );
}

/** Return shape of {@link useModalMotion}. */
export interface ModalMotion {
  /** True while the exit animation is playing — drive `data-closing` with it. */
  readonly closing: boolean;
  /**
   * Play the panel/backdrop exit animation, then invoke `onClose` after
   * {@link MODAL_EXIT_MS}. Under reduced motion it closes immediately (no
   * timeout, no `closing` flip) so nothing dangles.
   */
  readonly requestClose: () => void;
  /** Reset `closing` to `false`. Call when a persistent (kept-mounted) dialog re-opens. */
  readonly resetClosing: () => void;
}

/**
 * Drive a modal's animated dismissal. The dialog applies `data-closing` from
 * the returned `closing` flag (CSS swaps the entrance keyframe for the exit
 * keyframe), and routes every dismiss path — backdrop click, Esc, the close
 * button, the "no thanks" decline — through `requestClose`.
 *
 * @param onClose - called once the exit animation finishes (or immediately under reduced motion)
 * @returns the `closing` flag, a stable `requestClose`, and a `resetClosing`
 * @example
 * const { closing, requestClose } = useModalMotion(onClose);
 * return (
 *   <div className={`${MODAL_BACKDROP_CLASS} ...`} data-closing={closing || undefined} onClick={requestClose}>
 *     <div className={`${MODAL_PANEL_CLASS} ...`} data-closing={closing || undefined}>…</div>
 *   </div>
 * );
 */
export function useModalMotion(onClose: () => void): ModalMotion {
  const [closing, setClosing] = useState(false);
  // Keep onClose in a ref so requestClose stays referentially stable even when
  // the parent passes a fresh arrow each render (avoids re-firing open effects).
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  const requestClose = useCallback(() => {
    if (prefersReducedMotion()) {
      onCloseRef.current();
      return;
    }
    setClosing(true);
    window.setTimeout(() => onCloseRef.current(), MODAL_EXIT_MS);
  }, []);

  const resetClosing = useCallback(() => setClosing(false), []);

  return { closing, requestClose, resetClosing };
}
