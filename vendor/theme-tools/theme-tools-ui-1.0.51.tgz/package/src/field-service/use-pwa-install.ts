import { useCallback, useEffect, useState } from 'react';

// React hook that wraps the (non-standard) BeforeInstallPromptEvent so a
// custom A2HS button can replace the browser's default mini-infobar. Chrome,
// Edge, and Samsung Internet fire `beforeinstallprompt`; Safari/iOS does not
// — for those, we fall back to a static install-instructions tile.
//
// The hook does NOT auto-show the prompt. It only:
//   1. Captures the event when it fires (`event.preventDefault()` so the
//      browser doesn't auto-prompt).
//   2. Exposes `canPrompt` so the UI can light up the install button.
//   3. Exposes `prompt()` so the UI can trigger the install when ready.
//   4. Listens for `appinstalled` and clears state when the user installs.
//
// Server-side cooldown bookkeeping lives in PwaInstallPrompt.tsx via the
// `/api/customer/pwa-prompt/*` endpoints — that's separate from the
// in-memory state this hook tracks.

interface BeforeInstallPromptEvent extends Event {
  readonly platforms: ReadonlyArray<string>;
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

interface UsePwaInstallReturn {
  canPrompt: boolean;
  installed: boolean;
  isStandalone: boolean;
  prompt: () => Promise<'accepted' | 'dismissed' | 'unavailable'>;
}

function detectStandalone(): boolean {
  if (typeof window === 'undefined') return false;
  if (window.matchMedia?.('(display-mode: standalone)').matches) return true;
  // iOS legacy: navigator.standalone on the global Navigator instance.
  const nav = window.navigator as Navigator & { standalone?: boolean };
  return nav.standalone === true;
}

export function usePwaInstall(): UsePwaInstallReturn {
  const [deferred, setDeferred] = useState<BeforeInstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(false);
  const [isStandalone, setIsStandalone] = useState<boolean>(false);

  useEffect(() => {
    setIsStandalone(detectStandalone());
  }, []);

  useEffect(() => {
    function onBeforeInstallPrompt(e: Event): void {
      e.preventDefault();
      setDeferred(e as BeforeInstallPromptEvent);
    }
    function onAppInstalled(): void {
      setInstalled(true);
      setDeferred(null);
    }
    window.addEventListener('beforeinstallprompt', onBeforeInstallPrompt);
    window.addEventListener('appinstalled', onAppInstalled);
    return () => {
      window.removeEventListener('beforeinstallprompt', onBeforeInstallPrompt);
      window.removeEventListener('appinstalled', onAppInstalled);
    };
  }, []);

  const prompt = useCallback(async (): Promise<'accepted' | 'dismissed' | 'unavailable'> => {
    if (!deferred) return 'unavailable';
    await deferred.prompt();
    const choice = await deferred.userChoice;
    setDeferred(null);
    return choice.outcome;
  }, [deferred]);

  return {
    canPrompt: deferred !== null && !installed && !isStandalone,
    installed,
    isStandalone,
    prompt,
  };
}
