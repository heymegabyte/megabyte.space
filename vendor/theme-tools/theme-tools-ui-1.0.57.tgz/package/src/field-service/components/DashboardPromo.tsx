import { Badge, Card, ThemeToolsPageSurface, useThemeToolsSurface } from '../../field-service-primitives.js';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { dashboardPromoCopy } from '@theme.tools/i18n-a11y/field-service/dashboard-promo-copy';

/**
 * Homepage promotion for the Google-Calendar-style customer dashboard at `/me`.
 * Sits between AiFairMarket and Services — gives every visitor a clear "you can
 * manage all of this in one screen" moment before they reach pricing-shock.
 *
 * Mockup is rendered in raw HTML/Tailwind (no screenshot dependency) so the
 * section stays sharp on every breakpoint and never serves a stale PNG.
 *
 * All visitor-facing strings — incl. the calendar-mockup micro-copy (day
 * names, job blocks, stat tiles, caption) — come from `dashboardPromoCopy(locale)`
 * so the `/es` + `/pt` mirrors render in-language post-hydration (was
 * English-forever). The layout fields (day/startRow/rows/tone) are
 * locale-invariant and stay here; the localized label/sub/value zip on by index.
 */
export function DashboardPromo() {
  useThemeToolsSurface('dashboard-promo');
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  // Keep a mirror-locale visitor in /es · /pt: localize internal `/` hrefs;
  // leave mailto:/tel:/external + static-asset paths bare.
  const lp = (p: string) => (p.startsWith('/') ? localizedPath(locale, p) : p);
  const c = dashboardPromoCopy(locale);

  // Locale-invariant calendar layout; text zips in from `c.blocks` by index.
  const layout: Array<{
    day: number;
    startRow: number;
    rows: number;
    tone: 'confirmed' | 'enroute' | 'pending';
  }> = [
    { day: 0, startRow: 2, rows: 3, tone: 'confirmed' },
    { day: 1, startRow: 4, rows: 2, tone: 'confirmed' },
    { day: 2, startRow: 1, rows: 2, tone: 'enroute' },
    { day: 3, startRow: 3, rows: 3, tone: 'confirmed' },
    { day: 5, startRow: 2, rows: 4, tone: 'pending' },
  ];
  const blocks = layout.map((b, i) => ({
    ...b,
    label: c.blocks[i]?.label ?? '',
    sub: c.blocks[i]?.sub ?? '',
  }));
  const toneStyles: Record<(typeof layout)[number]['tone'], string> = {
    confirmed: 'border-brand-accent/60 bg-brand-accent/20 text-brand-ink',
    enroute: 'border-brand-ok/70 bg-brand-ok/15 text-brand-ink',
    pending: 'border-brand-warn/60 bg-brand-warn/15 text-brand-ink',
  };
  const statTones: ReadonlyArray<'ok' | 'accent' | 'ink'> = ['ok', 'accent', 'ink'];

  return (
    <ThemeToolsPageSurface
      as="section"
      surface="dashboard-promo"
      id="dashboard"
      className="section relative overflow-hidden border-y border-black/85 bg-bg-elevated/40"
    >
      <div
        className="pointer-events-none absolute -top-40 left-1/2 h-[420px] w-[420px] -translate-x-1/2 rounded-full bg-brand-accent/10 blur-3xl"
        aria-hidden
      />
      <div className="container-pad relative">
        <div className="grid gap-12 lg:grid-cols-[1.05fr,1fr] lg:items-center">
          <div data-animate="fade-up">
            <p className="eyebrow mb-3">{c.eyebrow}</p>
            <h2 className="font-display text-4xl sm:text-5xl font-extrabold leading-[1.05]">
              {c.titlePre} <span className="text-gradient">{c.titleAccent}</span>
            </h2>
            <p className="mt-5 max-w-xl text-lg text-brand-mute">{c.lead}</p>
            <ul className="mt-7 flex flex-wrap gap-2 text-xs font-mono">
              {c.pills.map((pill) => (
                <li key={pill}>
                  <Badge
                    variant="outline"
                    className="rounded-full border border-brand-accent/40 bg-brand-accent/10 px-3 py-1.5 text-brand-accent"
                  >
                    {pill}
                  </Badge>
                </li>
              ))}
            </ul>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <a
                href={lp('/me')}
                className="btn-primary text-base"
                data-bcl-cta="dashboard-promo-primary"
              >
                {c.ctaPrimary}
              </a>
              <a
                href={lp('/login?as=customer&next=%2Fme')}
                className="btn-ghost text-base"
                data-bcl-cta="dashboard-promo-signin"
              >
                {c.ctaSignin}
              </a>
            </div>
            <p className="mt-4 text-xs text-brand-mute">{c.noPassword}</p>
          </div>

          <div
            className="relative"
            data-animate="slide-left"
            data-delay="120"
            aria-label="Preview: Brick Labor customer dashboard"
          >
            <Card className="rounded-2xl border border-black/85 bg-[#0c1017] p-5 shadow-glow">
              <div className="mb-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="h-2.5 w-2.5 rounded-full bg-brand-err/80" aria-hidden />
                  <span className="h-2.5 w-2.5 rounded-full bg-brand-warn/80" aria-hidden />
                  <span className="h-2.5 w-2.5 rounded-full bg-brand-ok/80" aria-hidden />
                  <span className="ml-3 font-mono text-[11px] uppercase tracking-wider text-brand-mute">
                    bricklabor.com/me
                  </span>
                </div>
                <span className="font-mono text-[11px] text-brand-accent">{c.weekLabel}</span>
              </div>
              <div
                role="presentation"
                className="grid grid-cols-[36px_repeat(7,_1fr)] gap-px overflow-hidden rounded-lg border border-brand-line bg-brand-line text-[11px]"
              >
                <div className="bg-bg-elevated px-2 py-2 text-brand-mute" />
                {c.days.map((d) => (
                  <div
                    key={d}
                    className="bg-bg-elevated px-1 py-2 text-center font-mono text-brand-mute"
                  >
                    {d}
                  </div>
                ))}
                {Array.from({ length: 7 }).map((_, rowIdx) => (
                  <RowBlock key={rowIdx} hour={8 + rowIdx} />
                ))}
              </div>
              <div className="pointer-events-none absolute inset-x-12 top-[88px] grid grid-cols-7 gap-1.5">
                {blocks.map((b, i) => (
                  <div
                    key={i}
                    className={`pointer-events-auto rounded-md border px-2 py-1.5 backdrop-blur-sm transition-transform hover:-translate-y-0.5 ${toneStyles[b.tone]}`}
                    style={{
                      gridColumnStart: b.day + 1,
                      gridRowStart: 1,
                      marginTop: `${(b.startRow - 1) * 28}px`,
                      minHeight: `${b.rows * 28 - 4}px`,
                    }}
                  >
                    <p className="font-display text-[11px] font-bold leading-tight">{b.label}</p>
                    <p className="font-mono text-[10px] text-brand-mute">{b.sub}</p>
                  </div>
                ))}
              </div>
              <div className="mt-4 grid grid-cols-3 gap-3 text-[11px]">
                {c.stats.map((s, i) => (
                  <Stat
                    key={s.label}
                    label={s.label}
                    value={s.value}
                    tone={statTones[i] ?? 'ink'}
                  />
                ))}
              </div>
            </Card>
            <p className="mt-3 text-center text-[11px] text-brand-mute">
              {c.livePreviewPre}
              <a href={lp('/me')} className="text-brand-accent underline-hover">
                /me
              </a>
              {c.livePreviewPost}
            </p>
          </div>
        </div>
      </div>
    </ThemeToolsPageSurface>
  );
}

function RowBlock({ hour }: { hour: number }) {
  return (
    <>
      <div className="bg-bg-primary px-2 py-1.5 text-right font-mono text-brand-mute">{hour}</div>
      {Array.from({ length: 7 }).map((_, i) => (
        <div key={i} className="h-[28px] bg-bg-primary" />
      ))}
    </>
  );
}

function Stat({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone: 'ok' | 'accent' | 'ink';
}) {
  const toneClass =
    tone === 'ok' ? 'text-brand-ok' : tone === 'accent' ? 'text-brand-accent' : 'text-brand-ink';
  return (
    <div className="rounded-md border border-brand-line bg-bg-elevated/60 px-2.5 py-2">
      <p className="font-mono text-[10px] uppercase tracking-wider text-brand-mute">{label}</p>
      <p className={`mt-0.5 font-display text-sm font-bold ${toneClass}`}>{value}</p>
    </div>
  );
}
