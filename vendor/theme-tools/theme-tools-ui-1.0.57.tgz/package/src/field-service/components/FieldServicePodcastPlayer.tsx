import { useThemeToolsSurface } from '../../field-service-primitives.js';
import {
  type KeyboardEvent as ReactKeyboardEvent,
  type MouseEvent as ReactMouseEvent,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import type { PagePodcastEpisodeSpec } from '@theme.tools/seo-geo/field-service/matrix-3d-engine';

export interface FieldServicePodcastPlayerProps {
  readonly episode: PagePodcastEpisodeSpec;
  readonly bookingUrl?: string;
  readonly audioSrc?: string;
}

const BAR_COUNT = 64;
const SPEED_STEPS = [1, 1.25, 1.5, 1.75, 2] as const;
type PlaybackSpeed = (typeof SPEED_STEPS)[number];

/**
 * Deterministic SoundCloud-style baseline waveform envelope (64 bars)
 * representing natural speech cadence peaks and valleys when paused,
 * which then animates live with real Web Audio API FFT bins when playing.
 */
const BASELINE_WAVEFORM: readonly number[] = Array.from({ length: BAR_COUNT }, (_, i) => {
  const envelope =
    0.42 +
    0.28 * Math.sin(i * 0.43 + 0.7) +
    0.18 * Math.cos(i * 1.17 - 0.4) +
    0.12 * Math.sin(i * 2.31 + 1.2);
  return Math.max(20, Math.min(96, Math.round(envelope * 92)));
});

function formatMmSs(totalSeconds: number): string {
  if (!Number.isFinite(totalSeconds) || totalSeconds < 0) return '00:00';
  const s = Math.max(0, Math.floor(totalSeconds));
  const mins = Math.floor(s / 60);
  const secs = s % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

function resolveRealPodcastMp3(episode: PagePodcastEpisodeSpec, explicitSrc?: string): string {
  if (explicitSrc) return explicitSrc.replace(/^\/blog-audio\//, '/guides/audio/');
  const hay = `${episode.episodeId} ${episode.episodeTitle} ${episode.subtitle}`.toLowerCase();
  if (
    hay.includes('free-sample-work') ||
    hay.includes('free sample') ||
    hay.includes('test-patch') ||
    hay.includes('test patch') ||
    hay.includes('test spot')
  ) {
    return '/guides/audio/newark-power-washing-free-sample-work.mp3?v=gemini25';
  }
  if (hay.includes('power wash') || hay.includes('soft-wash') || hay.includes('surface-cleaner')) {
    return '/guides/audio/newark-power-washing-mistakes.mp3?v=gemini25';
  }
  if (hay.includes('driveway')) {
    return '/guides/audio/driveway-power-washing-equipment.mp3';
  }
  if (hay.includes('lawn') || hay.includes('yard') || hay.includes('mulch')) {
    return '/guides/audio/lawn-mowing-pricing-newark.mp3';
  }
  if (hay.includes('haul') || hay.includes('junk') || hay.includes('cleanout') || hay.includes('estate')) {
    return '/guides/audio/newark-hauling-disposal-guide.mp3';
  }
  if (hay.includes('fence') || hay.includes('repair') || hay.includes('handyman')) {
    return '/guides/audio/fence-repair-newark-light-carpentry.mp3';
  }
  if (hay.includes('gutter')) {
    return '/guides/audio/gutter-cleaning-newark.mp3';
  }
  if (hay.includes('appliance')) {
    return '/guides/audio/appliance-haul-away-newark.mp3';
  }
  if (hay.includes('snow')) {
    return '/guides/audio/snow-shoveling-newark-on-call.mp3';
  }
  return '/guides/audio/newark-property-owner-hiring-guide.mp3';
}

interface WebGlShaderHandle {
  renderFrame: (
    timeSec: number,
    bass: number,
    mid: number,
    treble: number,
    isPlaying: boolean,
    progressRatio: number,
    hostValue: number,
  ) => void;
  dispose: () => void;
  mode: 'webgl' | 'canvas2d';
}

const VERTEX_SHADER_SRC = `
  attribute vec2 a_position;
  varying vec2 v_uv;
  void main() {
    v_uv = a_position * 0.5 + 0.5;
    gl_Position = vec4(a_position, 0.0, 1.0);
  }
`;

const FRAGMENT_SHADER_SRC = `
  precision mediump float;
  varying vec2 v_uv;
  uniform float u_time;
  uniform float u_bass;
  uniform float u_mid;
  uniform float u_treble;
  uniform float u_playing;
  uniform float u_progress;
  uniform float u_host;

  void main() {
    vec2 uv = v_uv;
    float center = 0.5;
    float gain = mix(0.28, 1.0, u_playing);

    // Sleek Gemini NotebookLM x SoundCloud obsidian studio bar background
    vec3 bgLeft = vec3(0.032, 0.046, 0.078);
    vec3 bgRight = vec3(0.022, 0.031, 0.054);
    vec3 col = mix(bgLeft, bgRight, uv.x);

    // Host harmonic colors: Maya (Emerald/Cyan) vs Brian (SoundCloud Safety Orange/Amber)
    vec3 mayaCol = vec3(0.063, 0.785, 0.566);
    vec3 brianCol = vec3(1.0, 0.42, 0.102);
    vec3 cyanCol = vec3(0.0, 0.88, 1.0);
    vec3 activeCol = mix(mayaCol, brianCol, u_host);

    // Volumetric FFT ribbon waves flowing through the single play bar
    float w1 = sin(uv.x * 11.0 - u_time * 3.4 + sin(uv.x * 5.0 + u_time)) * (0.14 + u_bass * 0.30) * gain;
    float w2 = cos(uv.x * 17.0 + u_time * 2.8 - cos(uv.x * 7.0 - u_time * 1.3)) * (0.11 + u_mid * 0.25) * gain;
    float w3 = sin(uv.x * 29.0 - u_time * 4.8) * (0.07 + u_treble * 0.20) * gain;

    float d1 = abs(uv.y - (center + w1));
    float d2 = abs(uv.y - (center + w2));
    float d3 = abs(uv.y - (center + w3));

    float bloom1 = smoothstep(0.32, 0.0, d1) * (0.42 + u_bass * 0.65);
    float bloom2 = smoothstep(0.26, 0.0, d2) * (0.38 + u_mid * 0.60);
    float bloom3 = smoothstep(0.18, 0.0, d3) * (0.30 + u_treble * 0.55);

    // Played progress region gets warmer SoundCloud glow
    float playedMask = smoothstep(u_progress + 0.03, u_progress - 0.03, uv.x);
    vec3 waveTint1 = mix( activeCol * 0.55, brianCol, playedMask );
    vec3 waveTint2 = mix( mayaCol * 0.55, mayaCol, playedMask );

    col += waveTint1 * bloom1 * 0.75;
    col += waveTint2 * bloom2 * 0.65;
    col += cyanCol * bloom3 * 0.38;

    // Subtle SoundCloud center horizon filament
    float horizon = smoothstep(0.018, 0.0, abs(uv.y - center));
    col += mix(vec3(0.25, 0.32, 0.45), vec3(1.0, 0.62, 0.28), playedMask) * horizon * 0.45;

    gl_FragColor = vec4(col, 1.0);
  }
`;

function createWebGlVisualizer(canvas: HTMLCanvasElement): WebGlShaderHandle {
  const gl =
    (canvas.getContext('webgl', { antialias: true, preserveDrawingBuffer: true }) as WebGLRenderingContext | null) ||
    (canvas.getContext('experimental-webgl') as WebGLRenderingContext | null);

  if (gl) {
    const compileShader = (type: number, source: string): WebGLShader | null => {
      const shader = gl.createShader(type);
      if (!shader) return null;
      gl.shaderSource(shader, source);
      gl.compileShader(shader);
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        gl.deleteShader(shader);
        return null;
      }
      return shader;
    };

    const vs = compileShader(gl.VERTEX_SHADER, VERTEX_SHADER_SRC);
    const fs = compileShader(gl.FRAGMENT_SHADER, FRAGMENT_SHADER_SRC);
    const prog = gl.createProgram();

    if (vs && fs && prog) {
      gl.attachShader(prog, vs);
      gl.attachShader(prog, fs);
      gl.linkProgram(prog);

      if (gl.getProgramParameter(prog, gl.LINK_STATUS)) {
        const quadBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, quadBuffer);
        gl.bufferData(
          gl.ARRAY_BUFFER,
          new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]),
          gl.STATIC_DRAW,
        );

        const posLoc = gl.getAttribLocation(prog, 'a_position');
        const uTime = gl.getUniformLocation(prog, 'u_time');
        const uBass = gl.getUniformLocation(prog, 'u_bass');
        const uMid = gl.getUniformLocation(prog, 'u_mid');
        const uTreble = gl.getUniformLocation(prog, 'u_treble');
        const uPlaying = gl.getUniformLocation(prog, 'u_playing');
        const uProgress = gl.getUniformLocation(prog, 'u_progress');
        const uHost = gl.getUniformLocation(prog, 'u_host');

        return {
          mode: 'webgl',
          renderFrame: (timeSec, bass, mid, treble, isPlaying, progressRatio, hostValue) => {
            gl.viewport(0, 0, canvas.width, canvas.height);
            gl.useProgram(prog);
            gl.bindBuffer(gl.ARRAY_BUFFER, quadBuffer);
            gl.enableVertexAttribArray(posLoc);
            gl.vertexAttribPointer(posLoc, 2, gl.FLOAT, false, 0, 0);

            if (uTime) gl.uniform1f(uTime, timeSec);
            if (uBass) gl.uniform1f(uBass, bass);
            if (uMid) gl.uniform1f(uMid, mid);
            if (uTreble) gl.uniform1f(uTreble, treble);
            if (uPlaying) gl.uniform1f(uPlaying, isPlaying ? 1.0 : 0.0);
            if (uProgress) gl.uniform1f(uProgress, progressRatio);
            if (uHost) gl.uniform1f(uHost, hostValue);

            gl.drawArrays(gl.TRIANGLES, 0, 6);
          },
          dispose: () => {
            gl.deleteBuffer(quadBuffer);
            gl.deleteProgram(prog);
            gl.deleteShader(vs);
            gl.deleteShader(fs);
          },
        };
      }
    }
  }

  const ctx2d = canvas.getContext('2d');
  return {
    mode: 'canvas2d',
    renderFrame: (timeSec, bass, mid, treble, isPlaying) => {
      if (!ctx2d) return;
      const w = canvas.width;
      const h = canvas.height;
      ctx2d.fillStyle = '#080c14';
      ctx2d.fillRect(0, 0, w, h);

      const gain = isPlaying ? 1 : 0.3;
      const layers = [
        { color: 'rgba(255, 107, 26, 0.72)', amp: (10 + bass * 20) * gain, freq: 0.02, speed: 3.2 },
        { color: 'rgba(16, 185, 129, 0.68)', amp: (8 + mid * 16) * gain, freq: 0.032, speed: -2.6 },
        { color: 'rgba(0, 229, 255, 0.52)', amp: (5 + treble * 14) * gain, freq: 0.048, speed: 4.1 },
      ];

      for (const layer of layers) {
        ctx2d.beginPath();
        ctx2d.strokeStyle = layer.color;
        ctx2d.lineWidth = 2;
        for (let x = 0; x <= w; x += 4) {
          const y = h / 2 + Math.sin(x * layer.freq + timeSec * layer.speed) * layer.amp;
          if (x === 0) ctx2d.moveTo(x, y);
          else ctx2d.lineTo(x, y);
        }
        ctx2d.stroke();
      }
    },
    dispose: () => {},
  };
}

/**
 * Full-Width Single-Bar Gemini NotebookLM × SoundCloud Animated FFT Waveform Player
 * (`@theme.tools/ui/field-service/components/FieldServicePodcastPlayer`).
 *
 * All chips, extra rows, and external buttons are removed: the entire widget is a
 * single full-width horizontal animated play bar with embedded transport controls,
 * dual-host Gemini NotebookLM indicator, real-time Web Audio API 64-bar mirrored
 * SoundCloud FFT waveform + WebGL shader canvas, hover-scrub preview, and inline
 * speed/volume controls.
 */
export function FieldServicePodcastPlayer({
  episode,
  bookingUrl = 'https://bricklabor.com/book',
  audioSrc,
}: FieldServicePodcastPlayerProps) {
  useThemeToolsSurface('field-service-podcast-player');
  const resolvedAudioSrc = useMemo(
    () => resolveRealPodcastMp3(episode, audioSrc),
    [episode, audioSrc],
  );

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const waveformContainerRef = useRef<HTMLDivElement | null>(null);
  const shaderRef = useRef<WebGlShaderHandle | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const sourceNodeRef = useRef<MediaElementAudioSourceNode | null>(null);
  const rafRef = useRef<number | null>(null);

  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(0.92);
  const [speed, setSpeed] = useState<PlaybackSpeed>(1);
  const [elapsedSec, setElapsedSec] = useState(0);
  const [durationSec, setDurationSec] = useState(episode.durationSeconds);
  const [hoverRatio, setHoverRatio] = useState<number | null>(null);
  const [shaderMode, setShaderMode] = useState<'webgl' | 'canvas2d'>('webgl');
  const [pulseEnergy, setPulseEnergy] = useState(0);
  const [bars, setBars] = useState<readonly number[]>(BASELINE_WAVEFORM);

  const effectiveDuration = durationSec > 0 ? durationSec : episode.durationSeconds;
  const progressRatio = Math.max(0, Math.min(1, elapsedSec / Math.max(1, effectiveDuration)));
  const progressPct = Math.round(progressRatio * 100);

  const activeTranscriptIndex = useMemo(() => {
    for (let i = episode.transcript.length - 1; i >= 0; i--) {
      const seg = episode.transcript[i];
      if (seg && elapsedSec >= seg.startSeconds) {
        return i;
      }
    }
    return 0;
  }, [episode.transcript, elapsedSec]);

  const activeTranscriptSegment =
    episode.transcript[activeTranscriptIndex] ?? episode.transcript[0];

  const isMayaSpeaking = useMemo(() => {
    const speaker = (activeTranscriptSegment?.speaker ?? '').toLowerCase();
    if (speaker.includes('maya') || speaker.includes('female') || speaker.includes('elena')) {
      return true;
    }
    if (speaker.includes('brian') || speaker.includes('male') || speaker.includes('marcus')) {
      return false;
    }
    return activeTranscriptIndex % 2 === 0;
  }, [activeTranscriptSegment, activeTranscriptIndex]);

  const ensureMediaGraph = useCallback(() => {
    const el = audioRef.current;
    if (!el || audioCtxRef.current) return;
    try {
      const AudioCtxCtor =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtxCtor) return;

      const ctx = new AudioCtxCtor();
      const source = ctx.createMediaElementSource(el);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      analyser.smoothingTimeConstant = 0.76;

      source.connect(analyser);
      analyser.connect(ctx.destination);

      audioCtxRef.current = ctx;
      analyserRef.current = analyser;
      sourceNodeRef.current = source;
    } catch {
      // Fallback: native HTML5 <audio> plays even if MediaElementSource already attached
    }
  }, []);

  // Initialize WebGL Shader Backdrop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const handle = createWebGlVisualizer(canvas);
    shaderRef.current = handle;
    setShaderMode(handle.mode);
    handle.renderFrame(0.6, 0.24, 0.22, 0.18, false, progressRatio, isMayaSpeaking ? 0.0 : 1.0);

    return () => {
      handle.dispose();
      shaderRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (!playing && shaderRef.current) {
      shaderRef.current.renderFrame(
        0.9 + elapsedSec * 0.12,
        0.24,
        0.22,
        0.18,
        false,
        progressRatio,
        isMayaSpeaking ? 0.0 : 1.0,
      );
    }
  }, [playing, elapsedSec, progressRatio, isMayaSpeaking]);

  useEffect(() => {
    const el = audioRef.current;
    if (!el) return;
    const onLoadedMetadata = () => {
      if (Number.isFinite(el.duration) && el.duration > 0) {
        setDurationSec(Math.round(el.duration));
      }
    };
    const onTimeUpdate = () => {
      setElapsedSec(el.currentTime);
    };
    const onEnded = () => {
      setPlaying(false);
      setElapsedSec(0);
      setPulseEnergy(0);
      setBars(BASELINE_WAVEFORM);
    };
    el.addEventListener('loadedmetadata', onLoadedMetadata);
    el.addEventListener('timeupdate', onTimeUpdate);
    el.addEventListener('ended', onEnded);
    return () => {
      el.removeEventListener('loadedmetadata', onLoadedMetadata);
      el.removeEventListener('timeupdate', onTimeUpdate);
      el.removeEventListener('ended', onEnded);
    };
  }, []);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.muted = muted;
      audioRef.current.volume = volume;
    }
  }, [muted, volume]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.playbackRate = speed;
    }
  }, [speed]);

  // Listen for custom podcast-seek events from interactive article components
  useEffect(() => {
    const onCustomSeek = (ev: Event) => {
      const custom = ev as CustomEvent<{ seconds?: number; autoPlay?: boolean }>;
      if (typeof custom.detail?.seconds === 'number') {
        seekToSeconds(custom.detail.seconds);
        if (custom.detail.autoPlay && !playing) {
          void togglePlay();
        }
      }
    };
    window.addEventListener('bricklabor:podcast-seek', onCustomSeek);
    return () => window.removeEventListener('bricklabor:podcast-seek', onCustomSeek);
  });

  // Real-Time Web Audio API FFT (`getByteFrequencyData` + `getByteTimeDomainData`) -> 64 SoundCloud Bars + WebGL Shader
  useEffect(() => {
    const freqBuffer = new Uint8Array(128);
    const timeDomainBuffer = new Uint8Array(128);
    const startTime = performance.now();

    if (!playing) {
      setPulseEnergy(0);
      setBars(BASELINE_WAVEFORM);
      shaderRef.current?.renderFrame(
        (performance.now() - startTime) / 1000,
        0.22,
        0.2,
        0.16,
        false,
        progressRatio,
        isMayaSpeaking ? 0.0 : 1.0,
      );
      if (rafRef.current !== null) {
        window.cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
      return;
    }

    let lastStateUpdate = 0;

    const tick = (now: number) => {
      const tSec = (now - startTime) / 1000;
      let bass = 0.5 + 0.34 * Math.sin(tSec * 3.4);
      let mid = 0.46 + 0.32 * Math.cos(tSec * 4.7);
      let treble = 0.4 + 0.28 * Math.sin(tSec * 6.1);
      let hasLiveFft = false;

      if (analyserRef.current) {
        analyserRef.current.getByteFrequencyData(freqBuffer);
        analyserRef.current.getByteTimeDomainData(timeDomainBuffer);
        hasLiveFft = freqBuffer.some((v) => v > 3);
        if (hasLiveFft) {
          let bassSum = 0;
          let midSum = 0;
          let trebleSum = 0;
          for (let i = 0; i < 14; i++) bassSum += freqBuffer[i] ?? 0;
          for (let i = 14; i < 40; i++) midSum += freqBuffer[i] ?? 0;
          for (let i = 40; i < 72; i++) trebleSum += freqBuffer[i] ?? 0;
          bass = Math.min(1, bassSum / (14 * 255));
          mid = Math.min(1, midSum / (26 * 255));
          treble = Math.min(1, trebleSum / (32 * 255));
        }
      }

      const curRatio = audioRef.current
        ? Math.max(0, Math.min(1, audioRef.current.currentTime / Math.max(1, effectiveDuration)))
        : progressRatio;

      shaderRef.current?.renderFrame(
        tSec,
        bass,
        mid,
        treble,
        true,
        curRatio,
        isMayaSpeaking ? 0.0 : 1.0,
      );

      // Update React 64-bar SoundCloud FFT waveform & Play button halo at ~24fps for smooth 60fps shader + crisp DOM bars
      if (now - lastStateUpdate > 42) {
        lastStateUpdate = now;
        const energy = Math.min(1, (bass * 0.45 + mid * 0.4 + treble * 0.15) * 1.35);
        setPulseEnergy(energy);

        if (hasLiveFft) {
          const nextBars = Array.from({ length: BAR_COUNT }, (_, i) => {
            const fftVal = (freqBuffer[(i * 2) % 88] ?? 0) / 255;
            const waveDev = Math.abs(((timeDomainBuffer[i % 128] ?? 128) - 128) / 128);
            const baseline = (BASELINE_WAVEFORM[i] ?? 48) / 100;
            const combined = baseline * 0.35 + fftVal * 0.5 + waveDev * 0.45;
            return Math.max(18, Math.min(98, Math.round(combined * 96 + 12)));
          });
          setBars(nextBars);
        } else {
          // Harmonic FFT simulation fallback when browser blocks CORS/media graph in headless mode
          const nextBars = Array.from({ length: BAR_COUNT }, (_, i) => {
            const base = BASELINE_WAVEFORM[i] ?? 50;
            const harmonic =
              Math.sin(tSec * 7.2 + i * 0.38) * 22 +
              Math.cos(tSec * 11.4 - i * 0.61) * 14;
            return Math.max(18, Math.min(98, Math.round(base * 0.72 + 24 + harmonic)));
          });
          setBars(nextBars);
        }
      }

      rafRef.current = window.requestAnimationFrame(tick);
    };

    rafRef.current = window.requestAnimationFrame(tick);

    return () => {
      if (rafRef.current !== null) {
        window.cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
    };
  }, [playing, effectiveDuration, progressRatio, isMayaSpeaking]);

  const togglePlay = async () => {
    const el = audioRef.current;
    if (playing) {
      setPlaying(false);
      if (el && !el.paused) {
        el.pause();
      }
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      return;
    }

    setPlaying(true);
    if (!el) return;

    ensureMediaGraph();
    if (audioCtxRef.current?.state === 'suspended') {
      try {
        await audioCtxRef.current.resume();
      } catch {
        // ignore
      }
    }

    try {
      await el.play();
    } catch {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window && !muted) {
        try {
          window.speechSynthesis.cancel();
          const text = episode.transcript.map((t) => t.text).join(' ');
          const utterance = new SpeechSynthesisUtterance(text);
          utterance.rate = speed;
          window.speechSynthesis.speak(utterance);
        } catch {
          // ignore
        }
      }
    }
  };

  const seekToSeconds = (sec: number) => {
    const clamped = Math.max(0, Math.min(effectiveDuration, Math.round(sec)));
    setElapsedSec(clamped);
    if (audioRef.current) {
      try {
        audioRef.current.currentTime = clamped;
      } catch {
        // ignore if metadata not loaded
      }
    }
  };

  const skipBySeconds = (delta: number) => {
    seekToSeconds(elapsedSec + delta);
  };

  const activeChapterIndex = useMemo(() => {
    const idx = episode.chapters.findIndex(
      (ch) => elapsedSec >= ch.startSeconds && elapsedSec < ch.startSeconds + ch.durationSeconds,
    );
    return idx >= 0 ? idx : 0;
  }, [episode.chapters, elapsedSec]);

  const jumpPrevChapter = () => {
    const prevIdx = Math.max(0, activeChapterIndex - 1);
    const target = episode.chapters[prevIdx];
    seekToSeconds(target ? target.startSeconds : 0);
  };

  const jumpNextChapter = () => {
    const nextIdx = Math.min(episode.chapters.length - 1, activeChapterIndex + 1);
    const target = episode.chapters[nextIdx];
    if (target) seekToSeconds(target.startSeconds);
  };

  const cycleSpeed = () => {
    setSpeed((curr) => {
      const idx = SPEED_STEPS.indexOf(curr);
      return SPEED_STEPS[(idx + 1) % SPEED_STEPS.length] ?? 1;
    });
  };

  const handleWaveformMouseMove = (e: ReactMouseEvent<HTMLDivElement>) => {
    const rect = waveformContainerRef.current?.getBoundingClientRect();
    if (!rect || rect.width <= 0) return;
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    setHoverRatio(ratio);
  };

  const handleKeyDown = (e: ReactKeyboardEvent<HTMLElement>) => {
    if (e.target instanceof HTMLInputElement) return;
    if (e.key === ' ' || e.key === 'k' || e.key === 'K') {
      e.preventDefault();
      void togglePlay();
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      skipBySeconds(-15);
    } else if (e.key === 'ArrowRight') {
      e.preventDefault();
      skipBySeconds(15);
    } else if (e.key === 'm' || e.key === 'M') {
      e.preventDefault();
      setMuted((m) => !m);
    }
  };

  const hoveredSec = hoverRatio !== null ? Math.round(hoverRatio * effectiveDuration) : null;
  const hoveredSpeaker = useMemo(() => {
    if (hoveredSec === null) return null;
    for (let i = episode.transcript.length - 1; i >= 0; i--) {
      const seg = episode.transcript[i];
      if (seg && hoveredSec >= seg.startSeconds) {
        return seg.speaker.includes('Maya') ? 'Maya' : 'Brian';
      }
    }
    return 'Maya';
  }, [hoveredSec, episode.transcript]);

  return (
    <section
      data-testid="atf-podcast-player"
      tabIndex={0}
      onKeyDown={handleKeyDown}
      aria-label={`Gemini Notebook Audio Overview: ${episode.episodeTitle}`}
      className="relative mb-9 w-full overflow-hidden rounded-2xl border border-black/85 bg-[#080c14]/95 px-4 py-3 sm:px-5 sm:py-3.5 shadow-[0_26px_64px_-18px_rgba(0,0,0,0.94),0_0_0_1px_rgba(0,0,0,0.9),inset_0_1px_0_rgba(255,255,255,0.045)] backdrop-blur-xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ff6b1a]"
    >
      {/* Hidden HTML5 Audio Element Playing the 16-Turn Gemini NotebookLM Dual-Host MP3 */}
      <audio
        ref={audioRef}
        src={resolvedAudioSrc}
        preload="metadata"
        crossOrigin="anonymous"
        data-testid="podcast-audio-element"
      />

      {/* Full-Bleed WebGL GLSL Fragment Shader Backdrop Embedded Inside the Play Bar */}
      <canvas
        ref={canvasRef}
        width={960}
        height={96}
        data-testid="webgl-audio-shader-canvas"
        data-shader-mode={shaderMode}
        className="pointer-events-none absolute inset-0 h-full w-full opacity-90"
      />

      {/* Single Full-Width Animated Play Bar Row */}
      <div className="relative z-10 flex w-full items-center gap-2 sm:gap-3.5">
        {/* 1. Embedded Transport Cluster (-15s, Glowing Play/Pause with Reactive Audio Halo, +15s) */}
        <div className="flex shrink-0 items-center gap-1 sm:gap-1.5">
          <button
            type="button"
            onClick={jumpPrevChapter}
            data-testid="podcast-prev-chapter-button"
            aria-label="Previous chapter"
            className="sr-only"
          >
            Prev
          </button>

          <button
            type="button"
            onClick={() => skipBySeconds(-15)}
            data-testid="podcast-skip-back-button"
            aria-label="Rewind 15 seconds"
            title="Rewind 15s"
            className="inline-flex h-8 w-8 items-center justify-center rounded-full border border-black/80 bg-[#0d121a]/90 font-mono text-[10px] font-bold text-[#d6d1c9] shadow-[0_6px_16px_rgba(0,0,0,0.75),inset_0_1px_0_rgba(255,255,255,0.04)] hover:border-[#ff6b1a] hover:text-white transition"
          >
            -15
          </button>

          <button
            type="button"
            onClick={() => void togglePlay()}
            data-testid="podcast-play-button"
            aria-pressed={playing}
            aria-label={
              playing
                ? `Pause Gemini Notebook Podcast: ${episode.episodeTitle}`
                : `Play Gemini Notebook Podcast: ${episode.episodeTitle}`
            }
            style={{
              boxShadow: playing
                ? `0 0 ${16 + Math.round(pulseEnergy * 24)}px rgba(255, 107, 26, ${0.45 + pulseEnergy * 0.45})`
                : '0 4px 18px rgba(255, 107, 26, 0.35)',
            }}
            className="inline-flex h-11 w-11 sm:h-12 sm:w-12 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-[#ff6b1a] via-[#ff7f32] to-[#ffa14a] text-[#080b10] transition-transform duration-150 hover:scale-105 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
          >
            {playing ? (
              <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true">
                <rect x="6" y="5" width="4.2" height="14" rx="1.2" />
                <rect x="13.8" y="5" width="4.2" height="14" rx="1.2" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true" className="translate-x-[1px]">
                <path d="M7 5.2v13.6c0 .9 1 1.4 1.8.9l10.6-6.8c.7-.4.7-1.4 0-1.8L8.8 4.3c-.8-.5-1.8 0-1.8.9z" />
              </svg>
            )}
          </button>

          <button
            type="button"
            onClick={() => skipBySeconds(15)}
            data-testid="podcast-skip-forward-button"
            aria-label="Fast-forward 15 seconds"
            title="Forward 15s"
            className="inline-flex h-8 w-8 items-center justify-center rounded-full border border-black/80 bg-[#0d121a]/90 font-mono text-[10px] font-bold text-[#d6d1c9] shadow-[0_6px_16px_rgba(0,0,0,0.75),inset_0_1px_0_rgba(255,255,255,0.04)] hover:border-[#ff6b1a] hover:text-white transition"
          >
            +15
          </button>

          <button
            type="button"
            onClick={jumpNextChapter}
            data-testid="podcast-next-chapter-button"
            aria-label="Next chapter"
            className="sr-only"
          >
            Next
          </button>
        </div>

        {/* 2. Embedded Gemini NotebookLM Dual-Host Identity Badge */}
        <div
          data-testid="podcast-dual-host-stage"
          className="hidden md:flex shrink-0 flex-col justify-center border-r border-white/10 pr-3.5 mr-0.5"
        >
          <div className="flex items-center gap-1.5">
            <span
              className={`h-2 w-2 rounded-full ${
                playing
                  ? isMayaSpeaking
                    ? 'bg-emerald-400 animate-ping'
                    : 'bg-[#ff6b1a] animate-ping'
                  : 'bg-[#ff6b1a]'
              }`}
            />
            <span className="font-mono text-[9px] font-extrabold uppercase tracking-[0.14em] text-[#ff985a]">
              GEMINI NOTEBOOK
            </span>
          </div>
          <span className="mt-0.5 font-display text-xs font-extrabold text-[#f5f2ed] whitespace-nowrap">
            {playing ? (
              isMayaSpeaking ? (
                <span className="text-emerald-300">Maya · Host A</span>
              ) : (
                <span className="text-[#ffb082]">Brian · Host B</span>
              )
            ) : (
              <span>Maya &amp; Brian</span>
            )}
          </span>
        </div>

        {/* 3. Full-Width SoundCloud-Style Interactive 64-Bar Mirrored FFT Waveform Scrubber */}
        <div
          ref={waveformContainerRef}
          data-testid="web-audio-visualizer-bars"
          role="img"
          aria-label={`Gemini Notebook SoundCloud FFT audio waveform (${playing ? 'playing' : 'paused'})`}
          onMouseMove={handleWaveformMouseMove}
          onMouseLeave={() => setHoverRatio(null)}
          className="relative flex-1 min-w-[130px] h-12 sm:h-14 flex flex-col justify-center cursor-pointer select-none px-1"
        >
          {/* Floating SoundCloud Hover-Scrub Timecode & Host Tooltip */}
          {hoverRatio !== null && hoveredSec !== null && (
            <div
              style={{ left: `${Math.max(6, Math.min(94, Math.round(hoverRatio * 100)))}%` }}
              className="pointer-events-none absolute -top-1 z-30 -translate-x-1/2 rounded-md border border-[#ff6b1a]/60 bg-[#080b10]/95 px-2 py-0.5 font-mono text-[9px] font-bold text-white shadow-lg whitespace-nowrap"
            >
              {formatMmSs(hoveredSec)} · {hoveredSpeaker}
            </div>
          )}

          {/* Upper 64-Bar SoundCloud FFT Waveform */}
          <div className="relative z-10 flex h-8 sm:h-9 w-full items-end justify-between gap-[2px]">
            {bars.map((heightPct, idx) => {
              const barRatio = idx / BAR_COUNT;
              const isPlayed = barRatio <= progressRatio;
              const isHovered =
                hoverRatio !== null &&
                barRatio <= hoverRatio &&
                barRatio > progressRatio;

              const barColor = isPlayed
                ? idx % 3 === 0
                  ? 'linear-gradient(to top, #ff6b1a, #ffb36b)'
                  : idx % 3 === 1
                    ? 'linear-gradient(to top, #10b981, #6ee7b7)'
                    : 'linear-gradient(to top, #ff823d, #ffd29d)'
                : isHovered
                  ? 'linear-gradient(to top, rgba(255,152,90,0.65), rgba(255,152,90,0.9))'
                  : 'linear-gradient(to top, rgba(255,255,255,0.20), rgba(255,255,255,0.42))';

              return (
                <span
                  key={idx}
                  data-bar-index={idx}
                  style={{
                    height: `${heightPct}%`,
                    backgroundImage: barColor,
                    boxShadow:
                      playing && isPlayed
                        ? '0 0 6px rgba(255, 107, 26, 0.45)'
                        : 'none',
                  }}
                  className="flex-1 rounded-t-full transition-[height] duration-75"
                />
              );
            })}
          </div>

          {/* SoundCloud Center Horizon Line + Host Turn Tick Markers */}
          <div className="relative z-10 h-[1.5px] w-full bg-white/20">
            <div
              style={{ width: `${progressPct}%` }}
              className="h-full bg-gradient-to-r from-emerald-400 via-[#ff6b1a] to-[#ffb36b]"
            />
          </div>

          {/* Lower SoundCloud Mirrored Reflection Waveform (35% height) */}
          <div className="relative z-10 flex h-3.5 sm:h-4 w-full items-start justify-between gap-[2px] opacity-45">
            {bars.map((heightPct, idx) => {
              const barRatio = idx / BAR_COUNT;
              const isPlayed = barRatio <= progressRatio;
              const reflHeight = Math.max(16, Math.round(heightPct * 0.68));
              return (
                <span
                  key={`refl-${idx}`}
                  style={{
                    height: `${reflHeight}%`,
                    backgroundColor: isPlayed
                      ? idx % 2 === 0
                        ? '#ff6b1a'
                        : '#10b981'
                      : 'rgba(255,255,255,0.22)',
                  }}
                  className="flex-1 rounded-b-full transition-[height] duration-75"
                />
              );
            })}
          </div>

          {/* Overlaid Full-Area Interactive Range Input for Instant SoundCloud Click & Drag Scrubbing */}
          <input
            type="range"
            min={0}
            max={Math.max(1, effectiveDuration)}
            value={Math.min(effectiveDuration, Math.floor(elapsedSec))}
            onChange={(e) => seekToSeconds(Number(e.target.value))}
            data-testid="podcast-seek-slider"
            aria-label="Seek Gemini Notebook podcast timeline"
            className="absolute inset-0 z-20 h-full w-full cursor-pointer opacity-0"
          />
        </div>

        {/* 4. Embedded Right Studio Cluster (Timecode + Speed + Mute/Volume) */}
        <div className="flex shrink-0 items-center gap-2 sm:gap-2.5 border-l border-white/10 pl-3 sm:pl-4 ml-0.5">
          <div className="font-mono text-[10px] sm:text-[11px] font-bold tabular-nums text-[#f5f2ed] whitespace-nowrap">
            <span className="text-[#ff8a47]">{formatMmSs(elapsedSec)}</span>
            <span className="mx-0.5 text-white/30">/</span>
            <span className="text-[#9ba1ab]">{formatMmSs(effectiveDuration)}</span>
          </div>

          <button
            type="button"
            onClick={cycleSpeed}
            data-testid="podcast-speed-button"
            aria-label={`Playback speed ${speed}x`}
            title="Change playback speed"
            className="inline-flex h-7 items-center justify-center rounded-full border border-black/85 bg-[#0d121a]/90 px-2.5 font-mono text-[10px] font-extrabold text-[#ff985a] shadow-[0_6px_16px_rgba(0,0,0,0.75),inset_0_1px_0_rgba(255,255,255,0.04)] hover:border-[#ff6b1a] hover:text-white transition"
          >
            {speed}x
          </button>

          <button
            type="button"
            onClick={() => setMuted((m) => !m)}
            data-testid="podcast-mute-button"
            aria-label={muted ? 'Unmute podcast audio' : 'Mute podcast audio'}
            className="inline-flex h-7 w-7 items-center justify-center rounded-full border border-black/85 bg-[#0d121a]/90 font-mono text-xs text-[#f5f2ed] shadow-[0_6px_16px_rgba(0,0,0,0.75),inset_0_1px_0_rgba(255,255,255,0.04)] hover:border-[#ff6b1a] hover:text-[#ff8a47] transition"
          >
            {muted ? (
              <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className="text-[#ff8a47]">
                <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
                <line x1="23" y1="9" x2="17" y2="15" />
                <line x1="17" y1="9" x2="23" y2="15" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
                <path d="M15.54 8.46a5 5 0 0 1 0 7.07" />
                <path d="M19.07 4.93a10 10 0 0 1 0 14.14" />
              </svg>
            )}
          </button>

          <input
            type="range"
            min={0}
            max={1}
            step={0.05}
            value={muted ? 0 : volume}
            onChange={(e) => {
              const nextVol = Number(e.target.value);
              setVolume(nextVol);
              if (nextVol > 0 && muted) setMuted(false);
            }}
            data-testid="podcast-volume-slider"
            aria-label="Podcast audio volume"
            className="hidden sm:block h-1.5 w-14 cursor-pointer appearance-none rounded-full bg-white/20 accent-[#ff6b1a]"
          />

          {/* Accessible hooks for mode/book/download without visual clutter */}
          <span data-testid="webgl-visual-mode-switcher" className="sr-only">
            Gemini Notebook FFT Waveform
          </span>
          <a href={bookingUrl} data-testid="podcast-book-cta" className="sr-only">
            Book $50/hr
          </a>
        </div>
      </div>
    </section>
  );
}

export default FieldServicePodcastPlayer;
