import { Badge, Button, Card, Input, useThemeToolsSurface } from '../../field-service-primitives.js';
import { useState } from 'react';
import { Logo } from './Logo.js';
import { GoogleReviewBadge } from './GoogleReviewBadge.js';
import { LocaleSwitcher } from './LocaleSwitcher.js';
import { useFeatureFlag } from '../use-feature-flag.js';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { footerCopy } from '@theme.tools/i18n-a11y/field-service/footer-copy';
import type { FooterCopy } from '@theme.tools/i18n-a11y/field-service/footer-copy';
import { PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';

interface FooterProps {
  /**
   * Minimal mode: render ONLY the newsletter signup + the copyright/legal-links row.
   * Skips the 5-column site nav grid (logo blurb, services, cities, customers, crew).
   * Used on legal pages (/privacy, /terms) where we want the page to end at the
   * newsletter and not surface the full site index again.
   */
  minimal?: boolean;
}

export function Footer({ minimal = false }: FooterProps = {}) {
  useThemeToolsSurface('footer');
  // Locale read off the URL (SSR-safe `en` default), mirroring Header/Hero/
  // Services/Pricing so the bottom chrome renders in-language on the `/es` +
  // `/pt` mirrors instead of an English site index under localized body sections.
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const t = footerCopy(locale);
  // Keep a mirror-locale visitor in /es · /pt on every footer click — the TEXT
  // is already localized; localize the internal hrefs too so the bottom chrome
  // doesn't dump them onto the English route. Static assets (/sitemap.xml,
  // the flyer .pdf), mailto:/tel:, and external links stay bare.
  const lp = (path: string) => localizedPath(locale, path);
  // Edge-native site search (`/search`, Orama in the Worker). Flag-gated so the
  // footer never surfaces a dead-end link while the feature is dark — the link
  // appears only once `edge_search` is promoted, in lockstep with the API.
  const searchEnabled = useFeatureFlag('edge_search');
  return (
    <footer className="border-t border-black/85 bg-bg-primary shadow-[0_-16px_44px_rgba(0,0,0,0.75)]">
      <div className="container-pad py-14">
        <NewsletterSignup t={t} />
        {!minimal && <FooterCtaBand t={t} lp={lp} />}
        {minimal && (
          <div className="mb-8 flex justify-center py-2">
            <GoogleReviewBadge />
          </div>
        )}
        {!minimal && (
          <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-5" data-stagger="80">
            <div data-animate="fade-up" className="lg:col-span-1">
              <div className="flex items-center">
                <Logo className="h-8 w-auto" />
                <span className="sr-only">
                  Brick <span className="text-brand-accent">Labor</span>
                </span>
              </div>
              <div className="mt-3.5 mb-1 py-1 flex items-center justify-center sm:justify-start">
                <GoogleReviewBadge />
              </div>
              <p className="mt-4 text-sm text-brand-mute leading-relaxed">{t.blurb}</p>
              <Badge
                variant="outline"
                className="mt-3 inline-flex items-center gap-1.5 rounded-full border border-brand-accent/40 bg-brand-accent/10 px-2.5 py-1 font-mono text-[10px] uppercase tracking-[0.16em] text-brand-accent"
              >
                <span aria-hidden>✦</span>
                <a href={lp('/#fair-market')} className="underline-hover text-brand-accent">
                  {t.aiEstimate}
                </a>
              </Badge>
              <p className="mt-3 text-xs text-brand-mute">
                {t.workWithPre}
                <a href={lp('/work')} className="text-brand-accent underline-hover font-bold">
                  {t.workWithLink}
                </a>
                {t.workWithPost}
              </p>
              <div className="mt-4 flex flex-wrap gap-3 text-xs">
                <a
                  href="https://www.instagram.com/brickcitylabor"
                  target="_blank"
                  rel="noopener"
                  className="underline-hover text-brand-mute"
                >
                  Instagram
                </a>
                <a
                  href="https://www.facebook.com/brickcitylabor"
                  target="_blank"
                  rel="noopener"
                  className="underline-hover text-brand-mute"
                >
                  Facebook
                </a>
                <a
                  href="https://www.google.com/search?q=Brick+Labor+Newark+NJ+reviews"
                  target="_blank"
                  rel="noopener"
                  className="underline-hover text-brand-mute"
                >
                  {t.googleReviews}
                </a>
                <a href="/sitemap.xml" className="underline-hover text-brand-mute">
                  {t.sitemap}
                </a>
              </div>
            </div>

            <div data-animate="fade-up">
              <h3 className="font-display text-sm font-bold uppercase tracking-wider text-brand-ink">
                {t.colServices}
              </h3>
              <ul className="mt-4 space-y-2 text-sm">
                <li>
                  <a
                    href={lp('/services/power-washing')}
                    className="underline-hover text-brand-mute"
                  >
                    {t.svcPowerWashing}
                  </a>
                </li>
                <li>
                  <a href={lp('/services/lawn-care')} className="underline-hover text-brand-mute">
                    {t.svcLawn}
                  </a>
                </li>
                <li>
                  <a href={lp('/services/hauling')} className="underline-hover text-brand-mute">
                    {t.svcHauling}
                  </a>
                </li>
                <li>
                  <a
                    href={lp('/services/light-repairs')}
                    className="underline-hover text-brand-mute"
                  >
                    {t.svcLightRepairs}
                  </a>
                </li>
                <li>
                  <a
                    href={lp('/blog/appliance-haul-away-newark')}
                    className="underline-hover text-brand-mute"
                  >
                    {t.svcAppliance}
                  </a>
                </li>
                <li>
                  <a
                    href={lp('/blog/spring-property-prep-newark')}
                    className="underline-hover text-brand-mute"
                  >
                    {t.svcSpringPrep}
                  </a>
                </li>
                <li>
                  <a href={lp('/services')} className="underline-hover text-brand-mute">
                    {t.svcAllServices}
                  </a>
                </li>
                <li>
                  <a href={lp('/#pricing')} className="underline-hover text-brand-mute">
                    {t.svcAllPricing}
                  </a>
                </li>
                <li>
                  <a
                    href={lp('/book?from=footer-services')}
                    className="underline-hover text-brand-accent font-semibold"
                    data-bcl-magic-link="footer-services"
                  >
                    {t.svcBook}
                  </a>
                </li>
              </ul>
            </div>

            <div data-animate="fade-up">
              <h3 className="font-display text-sm font-bold uppercase tracking-wider text-brand-ink">
                {t.colCities}
              </h3>
              <ul className="mt-4 space-y-2 text-sm">
                <li>
                  <a href={lp('/c/newark')} className="underline-hover text-brand-mute">
                    Newark
                  </a>
                </li>
                <li>
                  <a href={lp('/c/jersey-city')} className="underline-hover text-brand-mute">
                    Jersey City
                  </a>
                </li>
                <li>
                  <a href={lp('/c/paterson')} className="underline-hover text-brand-mute">
                    Paterson
                  </a>
                </li>
                <li>
                  <a href={lp('/c/elizabeth')} className="underline-hover text-brand-mute">
                    Elizabeth
                  </a>
                </li>
                <li>
                  <a href={lp('/c/east-orange')} className="underline-hover text-brand-mute">
                    East Orange
                  </a>
                </li>
                <li>
                  <a href={lp('/c/irvington')} className="underline-hover text-brand-mute">
                    Irvington
                  </a>
                </li>
                <li>
                  <a href={lp('/c/bloomfield')} className="underline-hover text-brand-mute">
                    Bloomfield
                  </a>
                </li>
                <li>
                  <a href={lp('/c/hoboken')} className="underline-hover text-brand-mute">
                    Hoboken
                  </a>
                </li>
                <li>
                  <a href={lp('/#coverage')} className="underline-hover text-brand-mute">
                    {t.allCoverage}
                  </a>
                </li>
              </ul>
            </div>

            <div data-animate="fade-up">
              <h3 className="font-display text-sm font-bold uppercase tracking-wider text-brand-ink">
                {t.colCustomers}
              </h3>
              <ul className="mt-4 space-y-2 text-sm">
                <li>
                  <a
                    href={lp('/me')}
                    className="underline-hover text-brand-accent font-semibold"
                    data-bcl-cta="footer-dashboard"
                  >
                    {t.myDashboard}
                  </a>
                </li>
                <li>
                  {/* Wave 33 — data-bcl-magic-link signals the client-side enhancer
                      (when magic_links flag is on for the visitor) to
                      swap href with a pre-filled signed URL on hover/focus.
                      Falls back to the unsigned /book URL otherwise. */}
                  <a
                    href={lp('/book?from=footer-customers')}
                    className="underline-hover text-brand-mute"
                    data-bcl-magic-link="footer-customers"
                  >
                    {t.custBook}
                  </a>
                </li>
                <li>
                  <a
                    href={lp('/contact')}
                    className="underline-hover text-brand-mute"
                    data-bcl-cta="footer-contact"
                  >
                    {t.contactUs}
                  </a>
                </li>
                <li>
                  <a href={lp('/me?panel=calendar')} className="underline-hover text-brand-mute">
                    {t.schedulingDashboard}
                  </a>
                </li>
                <li>
                  <a href={lp('/#fair-market')} className="underline-hover text-brand-mute">
                    {t.aiEstimate}
                  </a>
                </li>
                <li>
                  <a href={lp('/#testimonials')} className="underline-hover text-brand-mute">
                    {t.customerStories}
                  </a>
                </li>
                <li>
                  <a href={lp('/#faq')} className="underline-hover text-brand-mute">
                    {t.faq}
                  </a>
                </li>
                <li>
                  <a href={lp('/blog')} className="underline-hover text-brand-mute">
                    {t.propertyBlog}
                  </a>
                </li>
                {searchEnabled && (
                  <li>
                    <a
                      href={lp('/search')}
                      className="underline-hover text-brand-mute"
                      data-bcl-cta="footer-search"
                    >
                      {t.siteSearch}
                    </a>
                  </li>
                )}
                <li>
                  <a href={lp('/#about')} className="underline-hover text-brand-mute">
                    {t.meetOwner}
                  </a>
                </li>
                <li>
                  <a href={lp('/sources')} className="underline-hover text-brand-mute">
                    {t.howWeCite}
                  </a>
                </li>
                <li>
                  <a href={lp('/privacy')} className="underline-hover text-brand-mute">
                    {t.privacy}
                  </a>
                </li>
                <li>
                  <a href={lp('/terms')} className="underline-hover text-brand-mute">
                    {t.terms}
                  </a>
                </li>
                <li>
                  {/* Reopens the NJDPA cookie-consent panel (CookieConsent.tsx
                      listens for this event) so a visitor can change their
                      analytics opt-in at any time — a consent-withdrawal path. */}
                  <button
                    type="button"
                    onClick={() =>
                      window.dispatchEvent(new CustomEvent('bcl:open-cookie-preferences'))
                    }
                    className="underline-hover inline-flex min-h-6 items-center text-left text-brand-mute"
                  >
                    {t.cookiePrefs}
                  </button>
                </li>
              </ul>
            </div>

            <div data-animate="fade-up">
              <h3 className="font-display text-sm font-bold uppercase tracking-wider text-brand-ink">
                {t.colCrew}
              </h3>
              <ul className="mt-4 space-y-2 text-sm">
                <li>
                  <a href={lp('/work')} className="underline-hover text-brand-mute">
                    {t.applyToWork}
                  </a>
                </li>
                <li>
                  <a href={lp('/careers')} className="underline-hover text-brand-mute">
                    {t.careers}
                  </a>
                </li>
                <li>
                  <a
                    href={lp('/login?intent=signin&kind=crew')}
                    className="underline-hover text-brand-mute"
                  >
                    {t.crewSignIn}
                  </a>
                </li>
                <li>
                  <a href={lp('/work/dashboard')} className="underline-hover text-brand-mute">
                    {t.crewDashboard}
                  </a>
                </li>
                <li>
                  <a href="mailto:hey@bricklabor.com" className="underline-hover text-brand-mute">
                    hey@bricklabor.com
                  </a>
                </li>
                <li>
                  <a href={PHONE_TEL_HREF} className="underline-hover text-brand-mute">
                    (855) 82LABOR
                  </a>
                </li>
                <li>
                  <a
                    href="https://www.google.com/maps/dir/?api=1&destination=Newark%2C%20NJ"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="underline-hover text-brand-mute"
                  >
                    Newark, NJ 07102
                  </a>
                </li>
                <li>
                  <a
                    href="/brick-city-labor-flyer.pdf"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="underline-hover text-brand-mute"
                    data-bcl-cta-location="footer-flyer"
                    aria-label={t.flyerAria}
                  >
                    {t.printableFlyer}
                  </a>
                </li>
                <li>
                  <a
                    href="https://www.linkedin.com/company/megabyte-labs"
                    target="_blank"
                    rel="noopener"
                    className="underline-hover text-brand-mute"
                  >
                    LinkedIn
                  </a>
                </li>
              </ul>
            </div>
          </div>
        )}

        <div className="mt-12 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-t border-brand-line pt-6 text-xs text-brand-mute">
          <p>
            © {new Date().getFullYear()} Brick Labor · Newark, NJ. {t.copyrightTail}
          </p>
          <LocaleSwitcher inline />
          <p>
            {t.siteByPre}
            <a
              href="https://megabyte.space"
              target="_blank"
              rel="noopener noreferrer"
              className="underline-hover text-brand-mute"
            >
              megabyte.space
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
}

/**
 * End-of-page conversion band — the last, most prominent thing above the site
 * index. A busy owner who scrolled to the bottom without booking gets one
 * obvious orange primary CTA ("Book a crew") plus a low-commitment "Contact us"
 * escape hatch, so the two highest-intent destinations are always reachable from
 * the footer regardless of which page they landed on. Rendered only in full
 * (non-minimal) mode; legal pages end at the newsletter.
 */
function FooterCtaBand({ t, lp }: { t: FooterCopy; lp: (path: string) => string }) {
  return (
    <div
      className="mb-12 overflow-hidden rounded-xl border border-brand-accent/30 bg-gradient-to-br from-brand-accent/10 via-bg-elevated/40 to-bg-elevated/40 p-6 sm:p-8"
      data-animate="fade-up"
    >
      <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="eyebrow mb-2">{t.ctaEyebrow}</p>
          <h3 className="font-display text-2xl font-bold text-brand-ink sm:text-3xl">
            {t.ctaHeadlineMain}
            <span className="text-brand-accent">{t.ctaHeadlineAccent}</span>
          </h3>
          <p className="mt-2 max-w-md text-sm text-brand-mute">{t.ctaBody}</p>
        </div>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <a
            href={lp('/book?from=footer-cta')}
            className="btn-primary inline-flex min-h-[48px] items-center justify-center whitespace-nowrap px-6 text-sm"
            data-bcl-magic-link="footer-cta"
            aria-label={t.ctaBookAria}
          >
            {t.ctaBook}
          </a>
          <a
            href={lp('/contact')}
            className="inline-flex min-h-[48px] items-center justify-center whitespace-nowrap rounded-lg border border-brand-line px-6 text-sm font-semibold text-brand-ink transition-all duration-[333ms] hover:border-brand-accent hover:text-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent focus-visible:ring-offset-2 focus-visible:ring-offset-bg-primary"
            data-bcl-cta="footer-cta-contact"
            aria-label={t.ctaContactAria}
          >
            {t.ctaContact}
          </a>
        </div>
      </div>
    </div>
  );
}

function NewsletterSignup({ t }: { t: FooterCopy }) {
  const [email, setEmail] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<{ ok: boolean; message: string } | null>(null);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!email.trim()) return;
    setSubmitting(true);
    setResult(null);
    try {
      const res = await fetch('/api/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim(), source: 'footer' }),
      });
      const data = (await res.json()) as { ok: boolean; message: string };
      if (res.ok && data.ok) {
        setResult({ ok: true, message: data.message });
        setEmail('');
      } else {
        setResult({ ok: false, message: data.message || t.nlGenericErr });
      }
    } catch (err) {
      // Error tracked via Sentry
      setResult({ ok: false, message: t.nlNetworkErr });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Card
      className="mb-12 rounded-2xl border border-black/85 bg-[#0c1017] p-6 sm:p-8 shadow-[0_26px_64px_-22px_rgba(0,0,0,0.92),0_0_0_1px_rgba(0,0,0,0.9),inset_0_1px_0_rgba(255,255,255,0.035)]"
      data-animate="fade-up"
    >
      <div className="grid gap-6 lg:grid-cols-[1.2fr,1fr] lg:items-center">
        <div>
          <p className="eyebrow mb-2">{t.nlEyebrow}</p>
          <h3 className="font-display text-2xl font-bold text-brand-ink sm:text-3xl">
            {t.nlHeadlineMain}
            <span className="text-brand-accent">{t.nlHeadlineAccent}</span>
          </h3>
          <p className="mt-2 text-sm text-brand-mute">{t.nlBody}</p>
        </div>
        <form
          onSubmit={onSubmit}
          className="flex flex-col gap-3 sm:flex-row"
          aria-label={t.nlFormAria}
        >
          <label htmlFor="nl-email" className="sr-only">
            {t.nlEmailLabel}
          </label>
          <Input
            id="nl-email"
            name="email"
            type="email"
            required
            autoComplete="email"
            inputMode="email"
            placeholder="you@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="input flex-1"
          />
          <Button
            type="submit"
            disabled={submitting}
            unstyled
            className="btn-primary whitespace-nowrap"
          >
            {submitting ? t.nlSubmitting : t.nlSubmit}
          </Button>
        </form>
      </div>
      {result && (
        <div
          role="status"
          className={`mt-4 rounded-lg border p-3 text-sm ${
            result.ok
              ? 'border-brand-ok/40 bg-brand-ok/10 text-brand-ok'
              : 'border-brand-err/40 bg-brand-err/10 text-brand-err'
          }`}
        >
          {result.message}
        </div>
      )}
    </Card>
  );
}
