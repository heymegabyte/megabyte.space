import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useRef, useState } from 'react';

/**
 * AuditLogSearch — global text search across `audit_logs`.
 *
 * Hits `/api/admin/audit-search?q=…&entityType=…`. The backend join is a
 * follow-up — until then the endpoint 404s and this panel renders the
 * "pending" copy. Once shipped, the same fetch + render loop populates.
 *
 * Debounces typing 350ms. Entity-type filter is a hardcoded enum matching
 * the categories the worker currently writes to `audit_logs.entity_type`.
 */

type EntityType = '' | 'booking' | 'worker' | 'gig' | 'payout' | 'admin' | 'coupon';

interface AuditRow {
  id: string;
  entity_type: string;
  entity_id: string;
  action: string;
  detail: string | null;
  created_at: string;
  actor: string | null;
}

interface SearchResponse {
  ok: boolean;
  rows?: AuditRow[];
  error?: string;
}

const ENTITY_OPTIONS: ReadonlyArray<{ value: EntityType; label: string }> = [
  { value: '', label: 'All entities' },
  { value: 'booking', label: 'Booking' },
  { value: 'worker', label: 'Worker' },
  { value: 'gig', label: 'Gig' },
  { value: 'payout', label: 'Payout' },
  { value: 'admin', label: 'Admin' },
  { value: 'coupon', label: 'Coupon' },
];

export function AuditLogSearch({ bearer }: { bearer: string }) {
  useThemeToolsSurface('audit-log-search');
  const [q, setQ] = useState('');
  const [entityType, setEntityType] = useState<EntityType>('');
  const [rows, setRows] = useState<AuditRow[]>([]);
  const [status, setStatus] = useState('');
  const [loading, setLoading] = useState(false);
  const [endpointMissing, setEndpointMissing] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const headers = useCallback(
    (): HeadersInit => ({
      'content-type': 'application/json',
      authorization: `Bearer ${bearer}`,
    }),
    [bearer],
  );

  const runSearch = useCallback(
    async (query: string, et: EntityType) => {
      if (!bearer) return;
      if (query.trim().length < 2) {
        setRows([]);
        setStatus('');
        return;
      }
      setLoading(true);
      setStatus('');
      try {
        const params = new URLSearchParams({ q: query.trim() });
        if (et) params.set('entityType', et);
        const res = await fetch(`/api/admin/audit-search?${params.toString()}`, {
          headers: headers(),
        });
        if (res.status === 404) {
          setEndpointMissing(true);
          setRows([]);
          return;
        }
        const json = (await res.json()) as SearchResponse;
        if (!res.ok || !json.ok) {
          setStatus(json.error ?? `HTTP ${res.status}`);
          setRows([]);
        } else {
          setEndpointMissing(false);
          setRows(json.rows ?? []);
          if ((json.rows ?? []).length === 0) {
            setStatus('No matches.');
          }
        }
      } catch (err) {
        setStatus((err as Error).message);
      } finally {
        setLoading(false);
      }
    },
    [bearer, headers],
  );

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      void runSearch(q, entityType);
    }, 350);
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [q, entityType, runSearch]);

  if (!bearer) {
    return (
      <section className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
        <h2 className="text-xl font-bold text-brand-ink">Audit log search</h2>
        <p className="mt-2 text-sm text-brand-mute">
          Add the owner key above to search the audit trail.
        </p>
      </section>
    );
  }

  return (
    <section className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
      <h2 className="text-xl font-bold text-brand-ink">Audit log search</h2>
      <p className="mt-1 text-sm text-brand-mute">
        Global text search across every action — booking lifecycle, worker moves, payouts, admin
        overrides, coupon redemptions.
      </p>

      <div className="mt-4 flex flex-col gap-2 sm:flex-row">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="search action, detail, entity id, actor…"
          className="flex-1 rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink focus:outline focus:outline-2 focus:outline-brand-accent"
        />
        <label className="block">
          <span className="sr-only">Entity type filter</span>
          <select
            value={entityType}
            onChange={(e) => setEntityType(e.target.value as EntityType)}
            className="w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink sm:w-auto"
          >
            {ENTITY_OPTIONS.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
        </label>
      </div>

      {endpointMissing && (
        <div className="mt-4 rounded-md border border-dashed border-brand-line p-4 text-sm text-brand-mute">
          Search endpoint pending; results appear here when wired.
          <span className="ml-1 font-mono text-[10px] text-brand-mute">
            (GET /api/admin/audit-search)
          </span>
        </div>
      )}

      {loading && <p className="mt-3 text-xs text-brand-mute">Searching…</p>}

      {!endpointMissing && rows.length > 0 && (
        <ul className="mt-4 space-y-2">
          {rows.map((r) => (
            <li
              key={r.id}
              className="rounded-md border border-brand-line bg-bg-primary p-3 text-sm"
            >
              <div className="flex flex-wrap items-center gap-2">
                <span className="rounded-md border border-brand-line bg-bg-elevated px-2 py-0.5 font-mono text-[10px] uppercase tracking-widest text-brand-mute">
                  {r.entity_type}
                </span>
                <span className="font-mono text-xs text-brand-accent">{r.action}</span>
                <span className="font-mono text-[10px] text-brand-mute">
                  {r.entity_id.slice(0, 16)}…
                </span>
                <span className="ml-auto font-mono text-[10px] text-brand-mute">
                  {new Date(r.created_at).toLocaleString()}
                </span>
              </div>
              {r.actor && (
                <p className="mt-1 font-mono text-[10px] text-brand-mute">actor: {r.actor}</p>
              )}
              {r.detail && (
                <pre className="mt-1 whitespace-pre-wrap font-mono text-xs text-brand-ink">
                  {r.detail}
                </pre>
              )}
            </li>
          ))}
        </ul>
      )}

      {!endpointMissing && !loading && status && (
        <p className="mt-3 text-xs text-brand-mute">{status}</p>
      )}
    </section>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
