import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { useEffect, useState } from 'react';

interface ActiveGig {
  id: string;
  booking_id: string;
  status: string;
  start_at: string;
  service_address: string | null;
  crew_needed: number;
  crew_filled: number;
  customer_pay_cents: number;
  crew_csv: string | null;
  photo_count: number;
}

interface ApiResponse {
  ok: true;
  gigs: ActiveGig[];
}

/**
 * Live-ops table of in-progress gigs. Pulls every 15s.
 */
export function GigsTable({ headers }: { headers: HeadersInit }) {
  useThemeToolsSurface('gigs-table');
  const [gigs, setGigs] = useState<ActiveGig[]>([]);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    let cancelled = false;
    async function load(): Promise<void> {
      try {
        const res = await fetch('/api/admin/gigs/active', { headers });
        if (!res.ok) {
          setError(`Fetch failed: ${res.status}`);
          return;
        }
        const json = (await res.json()) as ApiResponse;
        if (!cancelled) setGigs(json.gigs);
      } catch (err) {
        if (!cancelled) setError((err as Error).message);
      }
    }
    void load();
    const id = window.setInterval(() => void load(), 15_000);
    return () => {
      cancelled = true;
      window.clearInterval(id);
    };
  }, [headers]);

  if (error) return <p className="text-sm text-red-300">{error}</p>;
  if (gigs.length === 0) {
    return <p className="text-brand-mute text-sm">No active gigs right now.</p>;
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left text-sm" data-testid="gigs-table">
        <thead className="text-brand-mute text-xs uppercase">
          <tr>
            <th className="py-2 pr-2">Gig</th>
            <th className="px-2 py-2">Status</th>
            <th className="px-2 py-2">Start</th>
            <th className="px-2 py-2">Crew</th>
            <th className="px-2 py-2">Photos</th>
            <th className="px-2 py-2">Pay</th>
            <th className="px-2 py-2">Address</th>
          </tr>
        </thead>
        <tbody>
          {gigs.map((g) => (
            <tr key={g.id} className="border-t border-white/5">
              <td className="py-2 pr-2 font-mono text-xs">{g.id.slice(0, 8)}</td>
              <td className="px-2 py-2">
                <span className="rounded bg-white/10 px-1.5 py-0.5 text-xs uppercase">
                  {g.status}
                </span>
              </td>
              <td className="px-2 py-2 text-xs">{formatTime(g.start_at)}</td>
              <td className="px-2 py-2">
                {g.crew_filled}/{g.crew_needed}{' '}
                {g.crew_csv && <span className="text-brand-mute text-xs">· {g.crew_csv}</span>}
              </td>
              <td className="px-2 py-2 tabular-nums">{g.photo_count}</td>
              <td className="px-2 py-2 tabular-nums">${(g.customer_pay_cents / 100).toFixed(0)}</td>
              <td className="px-2 py-2 text-xs">{g.service_address ?? '—'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function formatTime(iso: string): string {
  try {
    const d = new Date(iso);
    return d.toLocaleString();
  } catch {
    return iso;
  }
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
