/**
 * bolt.diy D1 Console — mounted in the projectsites.dev editor bottom panel.
 * SQL query editor (textarea), results table, schema browser, saved queries
 * (localStorage), CSV export.
 *
 * Requires: D1 proxy at /api/admin/d1 (now served by bricklabor.com worker).
 *
 * States: idle → querying → results → error
 */
import { useState, useEffect } from 'react';

interface Column { name: string; type: string; }
interface QueryResult { columns: Column[]; rows: Record<string, unknown>[]; duration_ms: number; }

interface TableInfo { name: string; row_count: number; /* column count from schema */ }

interface SavedQuery { name: string; sql: string; savedAt: string; }

interface D1ConsoleProps {
  database: string;
  apiBase: string;
  dark?: boolean;
}

const SAVED_KEY = 'bcl_d1_saved_queries';

function loadSaved(): SavedQuery[] {
  try {
    const raw = localStorage.getItem(SAVED_KEY);
    return raw ? (JSON.parse(raw) as SavedQuery[]) : [];
  } catch { return []; }
}

function saveToStorage(queries: SavedQuery[]) {
  try { localStorage.setItem(SAVED_KEY, JSON.stringify(queries.slice(0, 50))); } catch {}
}

function csvEscape(v: unknown): string {
  if (v === null || v === undefined) return '';
  const s = String(v);
  if (s.includes(',') || s.includes('"') || s.includes('\n')) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

function toCsv(columns: Column[], rows: Record<string, unknown>[]): string {
  const header = columns.map(c => csvEscape(c.name)).join(',');
  const body = rows.map(row => columns.map(c => csvEscape(row[c.name])).join(','));
  return [header, ...body].join('\n');
}

function downloadCsv(columns: Column[], rows: Record<string, unknown>[]) {
  const csv = toCsv(columns, rows);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `d1-export-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

export function D1Console({ database, apiBase, dark = true }: D1ConsoleProps) {
  const [sql, setSql] = useState("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;");
  const [results, setResults] = useState<QueryResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [running, setRunning] = useState(false);
  const [tables, setTables] = useState<TableInfo[]>([]);
  const [history, setHistory] = useState<string[]>([]);
  const [, setShowSchema] = useState(false);
  const [activeTab, setActiveTab] = useState<'query' | 'schema'>('query');
  const [savedQueries, setSavedQueries] = useState<SavedQuery[]>(() => loadSaved());
  const [saveName, setSaveName] = useState('');

  useEffect(() => { saveToStorage(savedQueries); }, [savedQueries]);

  const queryUrl = `${apiBase}/d1/query`;
  const schemaUrl = `${apiBase}/d1/schema`;

  const runQuery = async () => {
    setRunning(true);
    setError(null);
    setResults(null);
    try {
      const res = await fetch(queryUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sql, params: [] }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}: ${(await res.text()).slice(0, 200)}`);
      const data = await res.json() as QueryResult;
      setResults(data);
      setHistory(prev => [sql, ...prev].slice(0, 50));
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setRunning(false);
    }
  };

  const loadSchema = async () => {
    try {
      const res = await fetch(schemaUrl);
      if (res.ok) {
        const data = await res.json() as { ok: boolean; tables: Record<string, Array<{ name: string; type: string; pk: boolean }>>; count: number };
        setTables(Object.entries(data.tables || {}).map(([name, cols]) => ({
          name,
          row_count: cols.length, // column count; row count needs per-table SELECT COUNT(*)
        })));
      }
      setShowSchema(true);
      setActiveTab('schema');
    } catch {}
  };

  const saveQuery = () => {
    const name = saveName.trim() || `Query ${savedQueries.length + 1}`;
    setSavedQueries(prev => [{ name, sql, savedAt: new Date().toISOString() }, ...prev.filter(q => q.name !== name)].slice(0, 50));
    setSaveName('');
  };

  const deleteSaved = (name: string) => {
    setSavedQueries(prev => prev.filter(q => q.name !== name));
  };

  const bg = dark ? '#060610' : '#fff';
  const fg = dark ? '#F5F5F5' : '#111';
  const accent = '#00E5FF';
  const mute = dark ? '#A0A0B0' : '#666';
  const card = dark ? '#0A0E14' : '#f5f5f5';
  const line = dark ? '#1E1E2E' : '#e0e0e0';
  const danger = '#ef4444';
  const success = '#22c55e';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', fontFamily: 'JetBrains Mono, monospace', fontSize: 13, background: bg, color: fg }}>
      <div style={{ display: 'flex', borderBottom: `1px solid ${line}`, padding: '0 10px' }}>
        <TabButton label="Query" active={activeTab === 'query'} onClick={() => setActiveTab('query')} accent={accent} dark={dark} />
        <TabButton label="Schema" active={activeTab === 'schema'} onClick={loadSchema} accent={accent} dark={dark} />
        <TabButton label={`Saved (${savedQueries.length})`} active={false} onClick={() => {}} accent={accent} dark={dark} />
        <span style={{ marginLeft: 'auto', color: mute, fontSize: 11, paddingTop: 10 }}>{database}</span>
      </div>

      {activeTab === 'query' && (
        <>
          <div style={{ padding: 10, borderBottom: `1px solid ${line}` }}>
            <textarea
              value={sql}
              onChange={e => setSql(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) runQuery(); }}
              rows={4}
              style={{ width: '100%', background: card, color: fg, border: `1px solid ${line}`, borderRadius: 4, padding: 8, fontFamily: 'JetBrains Mono, monospace', fontSize: 13, resize: 'vertical' }}
              placeholder="SELECT * FROM ..."
            />
            <div style={{ display: 'flex', gap: 8, marginTop: 8, flexWrap: 'wrap', alignItems: 'center' }}>
              <button onClick={runQuery} disabled={running} style={{ ...btnStyle(accent, dark), opacity: running ? 0.6 : 1 }}>
                {running ? 'Running...' : 'Run (⌘Enter)'}
              </button>
              {/* Save query */}
              <input
                value={saveName}
                onChange={e => setSaveName(e.target.value)}
                placeholder="Query name..."
                style={{ background: card, color: fg, border: `1px solid ${line}`, borderRadius: 4, padding: '4px 8px', fontSize: 12, fontFamily: 'JetBrains Mono, monospace', width: 140 }}
                onKeyDown={e => { if (e.key === 'Enter') saveQuery(); }}
              />
              <button onClick={saveQuery} style={btnStyle(mute, dark)}>Save</button>
              {history.length > 0 && (
                <select
                  onChange={e => { if (e.target.value) setSql(e.target.value); }}
                  style={{ background: card, color: fg, border: `1px solid ${line}`, borderRadius: 4, padding: '4px 8px', fontSize: 12, fontFamily: 'JetBrains Mono, monospace', maxWidth: 400 }}
                  defaultValue=""
                >
                  <option value="">History ({history.length})</option>
                  {history.slice(0, 20).map((h, i) => (
                    <option key={i} value={h}>{h.slice(0, 100)}</option>
                  ))}
                </select>
              )}
            </div>

            {/* Saved queries list */}
            {savedQueries.length > 0 && (
              <div style={{ marginTop: 8 }}>
                {savedQueries.map(q => (
                  <div key={q.name} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 0', borderBottom: `1px solid ${line}20` }}>
                    <button
                      onClick={() => { setSql(q.sql); }}
                      style={{ background: 'transparent', border: 'none', color: accent, cursor: 'pointer', fontSize: 12, fontFamily: 'JetBrains Mono, monospace', textAlign: 'left', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}
                      title={q.sql}
                    >
                      {q.name} <span style={{ color: mute, fontSize: 10 }}>— {q.sql.slice(0, 60)}{q.sql.length > 60 ? '…' : ''}</span>
                    </button>
                    <button
                      onClick={() => deleteSaved(q.name)}
                      style={{ background: 'transparent', border: 'none', color: danger, cursor: 'pointer', fontSize: 16, padding: '0 4px', lineHeight: 1 }}
                      title="Delete saved query"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div style={{ flex: 1, overflow: 'auto', padding: 10 }}>
            {error && <div style={{ color: danger, padding: 10, background: `${danger}10`, borderRadius: 4, marginBottom: 10 }}>{error}</div>}
            {results && (
              <>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                  <span style={{ color: success, fontSize: 12 }}>
                    {results.rows.length} row{results.rows.length !== 1 ? 's' : ''} · {results.duration_ms}ms
                  </span>
                  {results.rows.length > 0 && (
                    <button
                      onClick={() => downloadCsv(results.columns, results.rows)}
                      style={btnStyle(success, dark)}
                    >
                      ↓ CSV
                    </button>
                  )}
                </div>
                {results.rows.length > 0 && (
                  <div style={{ overflow: 'auto', maxHeight: 'calc(100vh - 320px)' }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                      <thead>
                        <tr>
                          {results.columns.map(c => (
                            <th key={c.name} style={{ padding: '6px 10px', textAlign: 'left', borderBottom: `2px solid ${line}`, color: accent, position: 'sticky', top: 0, background: bg }}>{c.name}<div style={{ fontSize: 10, fontWeight: 400, color: mute }}>{c.type}</div></th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {results.rows.map((row, i) => (
                          <tr key={i} style={{ background: i % 2 === 0 ? 'transparent' : `${accent}05` }}>
                            {results.columns.map(c => (
                              <td key={c.name} style={{ padding: '4px 10px', borderBottom: `1px solid ${line}`, maxWidth: 300, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                {row[c.name] === null ? <span style={{ color: mute, fontStyle: 'italic' }}>NULL</span> : String(row[c.name])}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </>
            )}
            {!results && !error && <div style={{ color: mute, padding: 20 }}>Write a query and press ⌘Enter to run</div>}
          </div>
        </>
      )}

      {activeTab === 'schema' && (
        <div style={{ flex: 1, overflow: 'auto', padding: 10 }}>
          {tables.length > 0 && (
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
              <thead>
                <tr>
                  <th style={{ padding: '6px 10px', textAlign: 'left', borderBottom: `2px solid ${line}`, color: accent }}>Table</th>
                  <th style={{ padding: '6px 10px', textAlign: 'right', borderBottom: `2px solid ${line}`, color: accent }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {tables.map(t => (
                  <tr key={t.name}>
                    <td style={{ padding: '4px 10px', borderBottom: `1px solid ${line}`, cursor: 'pointer' }} onClick={() => { setSql(`SELECT * FROM ${t.name} LIMIT 20;`); setActiveTab('query'); }}>
                      {t.name}
                    </td>
                    <td style={{ padding: '4px 10px', borderBottom: `1px solid ${line}`, textAlign: 'right' }}>
                      <button onClick={() => { setSql(`SELECT * FROM ${t.name} LIMIT 20;`); setActiveTab('query'); }} style={{ ...btnStyle(accent, dark), fontSize: 10, padding: '2px 8px' }}>SELECT *</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          {tables.length === 0 && <div style={{ color: mute }}>Click "Schema" tab to load tables</div>}
        </div>
      )}
    </div>
  );
}

function TabButton({ label, active, onClick, accent, dark }: { label: string; active: boolean; onClick: () => void; accent: string; dark: boolean }) {
  return (
    <button onClick={onClick} style={{
      padding: '8px 16px', background: 'transparent', border: 'none', cursor: 'pointer',
      color: active ? accent : dark ? '#A0A0B0' : '#666',
      borderBottom: active ? `2px solid ${accent}` : '2px solid transparent',
      fontFamily: 'JetBrains Mono, monospace', fontSize: 13, fontWeight: active ? 700 : 400,
    }}>
      {label}
    </button>
  );
}

function btnStyle(color: string, _dark: boolean): React.CSSProperties {
  return {
    padding: '5px 14px', borderRadius: 4, border: `1px solid ${color}`,
    background: 'transparent', color, cursor: 'pointer', fontSize: 12,
    fontFamily: 'JetBrains Mono, monospace',
  };
}
