import { Badge, Card, ThemeToolsPageSurface, useThemeToolsSurface } from '../../field-service-primitives.js';
import type { JSX } from 'react';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { aiFairMarketCopy } from '@theme.tools/i18n-a11y/field-service/ai-fair-market-copy';

// Homepage marketing surface for the AI Fair-Market estimator. Sits between
// the hero and the Services grid as a "core feature" pitch — the AI tells
// the customer what the job should cost BEFORE the booking form. Visually
// the rail-card variant + brand-accent number anchors the eye; the proof
// row below explains the three things the model actually compares.
//
// Companion to the in-form widget (Booking.tsx, aiQuote block) — copy stays
// aligned so customers see the same promise here and inside the booking
// flow. Strings come from `aiFairMarketCopy(locale)` so the `/es` + `/pt`
// mirrors render in-language post-hydration (was English-forever — the first
// English wall below the localized hero). SSR-safe `en` default.

export function AiFairMarket(): JSX.Element {
  useThemeToolsSurface('ai-fair-market');
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  // Keep a mirror-locale visitor in /es · /pt: localize internal `/` hrefs;
  // leave mailto:/tel:/external + static-asset paths bare.
  const lp = (p: string) => (p.startsWith('/') ? localizedPath(locale, p) : p);
  const c = aiFairMarketCopy(locale);

  return (
    <ThemeToolsPageSurface
      as="section"
      surface="ai-fair-market"
      id="fair-market"
      aria-labelledby="fair-market-title"
      className="section-tight border-t border-black/80"
    >
      <div className="container-pad">
        <div className="grid gap-8 lg:grid-cols-[1.05fr_1fr] lg:items-center">
          <div className="rail-card" data-animate="fade-up">
            <p className="eyebrow mb-3">{c.eyebrow}</p>
            <h2
              id="fair-market-title"
              className="font-display text-3xl sm:text-4xl lg:text-5xl font-extrabold leading-tight tracking-tight text-brand-ink"
            >
              {c.titlePre} <span className="text-gradient">{c.titleAccent}</span>
            </h2>
            <p className="mt-4 text-base sm:text-lg leading-relaxed text-brand-mute max-w-prose">
              {c.leadPre}
              <a href={lp('/sources')} className="underline-hover text-brand-ink">
                {c.localRates}
              </a>
              {c.leadMid}
              <a
                href={lp('/blog/fifty-dollar-hour-per-person-philosophy')}
                className="underline-hover text-brand-ink"
              >
                {c.blsData}
              </a>
              {c.leadPost}
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <a
                href={lp('/book')}
                className="btn-primary text-sm"
                data-bcl-cta-location="fair-market-hero"
              >
                {c.ctaTry}
              </a>
              <a href={lp('/quote')} className="btn-ghost text-sm">
                {c.ctaRead}
              </a>
            </div>
            <p className="mt-5 font-mono text-[11px] uppercase tracking-[0.16em] text-brand-mute">
              {c.freeNote}
            </p>
          </div>

          <Card
            className="card flex flex-col gap-4 p-6 sm:p-8 lg:self-stretch"
            aria-label="Sample AI estimate preview"
            data-animate="slide-left"
            data-delay="120"
          >
            <div className="flex items-baseline justify-between gap-3">
              <p className="eyebrow">{c.sampleOutput}</p>
              <Badge
                variant="outline"
                className="rounded-full border border-black/80 bg-bg-primary px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-[0.16em] text-brand-mute"
              >
                88% {c.confidence}
              </Badge>
            </div>
            <p className="text-sm text-brand-mute">
              <span className="font-mono text-brand-ink">{c.jobLabel}</span> {c.jobDesc}
            </p>
            <div className="flex items-baseline gap-3 flex-wrap border-t border-black/85 pt-4">
              <span className="font-display text-5xl font-extrabold leading-none text-brand-accent">
                $525
              </span>
              <span className="font-mono text-sm text-brand-mute">{c.priceMeta}</span>
            </div>
            <p className="text-sm leading-relaxed text-brand-ink">
              {c.comparePre}
              <strong className="text-brand-ink">{c.compareStrong}</strong>
              {c.comparePost}
            </p>
            <ul className="mt-2 grid gap-2.5 sm:grid-cols-1 border-t border-black/85 pt-4">
              {c.proof.map((p) => (
                <li key={p.label} className="flex items-start gap-3">
                  <span
                    aria-hidden
                    className="mt-1 inline-block h-1.5 w-1.5 flex-shrink-0 rounded-full bg-brand-accent"
                  />
                  <span className="text-xs leading-relaxed text-brand-mute">
                    <strong className="font-mono uppercase tracking-[0.14em] text-brand-ink">
                      {p.label}.
                    </strong>{' '}
                    {p.body}
                  </span>
                </li>
              ))}
            </ul>
          </Card>
        </div>
      </div>
    </ThemeToolsPageSurface>
  );
}
