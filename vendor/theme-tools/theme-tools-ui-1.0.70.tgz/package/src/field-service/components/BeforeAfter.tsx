import { ThemeToolsPageSurface, useThemeToolsSurface } from '../../field-service-primitives.js';
import { Badge } from '../../Badge.js';
import { stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { beforeAfterCopy } from '@theme.tools/i18n-a11y/field-service/before-after-copy';

/**
 * Locale-invariant geometry for each before/after job card — the visual tone +
 * clutter-dot count + city (a proper noun). The localized title / hours /
 * before-label / after-label come from `beforeAfterCopy(locale)` and zip on by
 * index, so `/es` + `/pt` read the cards in-language while the artwork is
 * identical across locales.
 */
interface JobGeometry {
  city: string;
  categorySlug: string;
  curbFt: number;
  before: { tone: string; clutter: number };
  after: { tone: string; clutter: number };
}

const JOB_GEOMETRY: JobGeometry[] = [
  {
    city: 'Newark, NJ',
    categorySlug: 'apartment-cleanout',
    curbFt: 42,
    before: { tone: '#3a2f24', clutter: 9 },
    after: { tone: '#9aa6b2', clutter: 1 },
  },
  {
    city: 'Jersey City, NJ',
    categorySlug: 'lawn-care',
    curbFt: 22,
    before: { tone: '#2c3a1c', clutter: 8 },
    after: { tone: '#4f7a2a', clutter: 1 },
  },
  {
    city: 'Manhattan, NY',
    categorySlug: 'moving-labor',
    curbFt: 30,
    before: { tone: '#3a2a2a', clutter: 10 },
    after: { tone: '#1c252e', clutter: 0 },
  },
  {
    city: 'Hoboken, NJ',
    categorySlug: 'hauling',
    curbFt: 30,
    before: { tone: '#2d2418', clutter: 7 },
    after: { tone: '#1f2a36', clutter: 0 },
  },
];

interface PanelProps {
  tone: string;
  clutter: number;
  label: string;
  state: 'before' | 'after';
  stateLabel: string;
}

function Panel({ tone, clutter, label, state, stateLabel }: PanelProps) {
  const dots = Array.from({ length: clutter }).map((_, i) => {
    const cx = 12 + ((i * 37) % 76);
    const cy = 14 + ((i * 53) % 72);
    const r = 2 + ((i * 7) % 6);
    return <circle key={i} cx={cx} cy={cy} r={r} fill="rgba(0,0,0,0.45)" />;
  });

  return (
    <div
      className="relative h-32 sm:h-36 overflow-hidden rounded-lg"
      style={{ backgroundColor: tone }}
    >
      <svg
        viewBox="0 0 100 100"
        preserveAspectRatio="none"
        className="absolute inset-0 h-full w-full"
        aria-hidden
      >
        <defs>
          <linearGradient id={`g-${state}-${tone.slice(1)}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="rgba(255,255,255,0.18)" />
            <stop offset="1" stopColor="rgba(0,0,0,0.35)" />
          </linearGradient>
        </defs>
        <rect width="100" height="100" fill={`url(#g-${state}-${tone.slice(1)})`} />
        {dots}
      </svg>
      <div className="absolute left-2 top-2 rounded bg-bg-primary/85 px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-brand-ink">
        {stateLabel}
      </div>
      <div className="absolute bottom-2 right-2 rounded bg-bg-primary/85 px-2 py-0.5 text-[11px] text-brand-mute">
        {label}
      </div>
    </div>
  );
}

export function BeforeAfter() {
  useThemeToolsSurface('before-after');
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const c = beforeAfterCopy(locale);

  return (
    <ThemeToolsPageSurface as="section" surface="before-after" id="work" className="section">
      <div className="container-pad">
        <div className="mb-10 max-w-3xl" data-animate="fade-up">
          <p className="eyebrow mb-3">{c.eyebrow}</p>
          <h2 className="text-4xl sm:text-5xl font-extrabold">
            {c.titlePre}
            <span className="text-gradient">{c.titleAccent}</span>
          </h2>
          <p className="mt-4 text-lg text-brand-mute">{c.lead}</p>
        </div>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4" data-stagger="80">
          {JOB_GEOMETRY.map((geo, i) => {
            const job = c.jobs[i] ?? beforeAfterCopy('en').jobs[i];
            if (!job) return null;
            return (
              <article
                key={job.title}
                className="card-hover reveal-on-view"
                data-animate="fade-up"
                data-card="job"
              >
                <div className="grid grid-cols-2 gap-2">
                  <Panel
                    state="before"
                    stateLabel={c.stateBefore}
                    tone={geo.before.tone}
                    clutter={geo.before.clutter}
                    label={job.beforeLabel}
                  />
                  <Panel
                    state="after"
                    stateLabel={c.stateAfter}
                    tone={geo.after.tone}
                    clutter={geo.after.clutter}
                    label={job.afterLabel}
                  />
                </div>
                <div className="mt-4">
                  <h3 className="font-display text-base font-bold">{job.title}</h3>
                  <p className="text-sm text-brand-mute">{geo.city}</p>
                  <p className="mt-1 font-mono text-[11px] text-brand-accent">{job.hours}</p>
                  <div className="mt-2 flex items-center justify-between gap-2 text-[11px] text-brand-mute">
                    <Badge variant="outline" className="rounded border-black/85 px-1.5 py-0.5 font-mono text-[11px] text-brand-mute">
                      {geo.curbFt} ft curb zone
                    </Badge>
                    <a
                      href={`/services/${geo.categorySlug}#category-calculator`}
                      className="font-mono text-brand-accent underline-hover"
                    >
                      Estimate scope →
                    </a>
                  </div>
                </div>
              </article>
            );
          })}
        </div>

        <p className="mt-8 text-xs text-brand-mute" data-animate="fade-in">
          {c.footnote}
        </p>
      </div>
    </ThemeToolsPageSurface>
  );
}
