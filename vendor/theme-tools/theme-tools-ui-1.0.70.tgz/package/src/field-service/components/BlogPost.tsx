import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect, useMemo, useState } from 'react';
import { BLOG_POSTS } from '../data/blog-posts.js';
import { listedPosts } from '@theme.tools/seo-geo/field-service/blog-visibility';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import blogImagesManifest from '../data/blog-images.js';
import blogAudioManifest from '../data/blog-audio.js';
import { SERVICES, serviceHeroImage } from '../data/services.js';
import { CITIES } from '../data/cities.js';
import { FieldServicePodcastPlayer } from './FieldServicePodcastPlayer.js';
import { AuthorityDossierTail } from './IdeogramInfographicDeck.js';
import { ArticleMultimediaSuite } from './ArticleMultimediaSuite.js';
import { buildLongFormPageAuthorityDossier } from '@theme.tools/seo-geo/field-service/matrix-3d-engine';
import { JsonLd, personBrian } from './seo/index.js';
import { DashboardCallout } from './DashboardCallout.js';
import { PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';

const SERVICE_KEYWORDS: Record<string, string[]> = {
  'power-washing': [
    'power wash',
    'pressure wash',
    'siding',
    'driveway',
    'concrete',
    'patio',
    'mildew',
  ],
  'lawn-care': ['lawn', 'mow', 'edge', 'hedge', 'leaf', 'yard', 'grass', 'shrub', 'mulch'],
  hauling: [
    'haul',
    'junk',
    'cleanout',
    'appliance',
    'debris',
    'estate',
    'sofa',
    'couch',
    'mattress',
  ],
  'light-repairs': [
    'repair',
    'gutter',
    'fence',
    'mount',
    'tv',
    'shelf',
    'caulk',
    'handyman',
    'door',
  ],
};

function pickRelatedServices(post: {
  title: string;
  excerpt: string;
  tags: string[];
  body: string;
}): string[] {
  const haystack =
    `${post.title} ${post.excerpt} ${post.tags.join(' ')} ${post.body.slice(0, 4000)}`.toLowerCase();
  const scored = Object.entries(SERVICE_KEYWORDS).map(([slug, kws]) => {
    const hits = kws.reduce((n, kw) => n + (haystack.includes(kw) ? 1 : 0), 0);
    return { slug, hits };
  });
  return scored
    .filter((s) => s.hits > 0)
    .sort((a, b) => b.hits - a.hits)
    .slice(0, 3)
    .map((s) => s.slug);
}

function pickRelatedPosts(slug: string, tags: string[], category: string) {
  return listedPosts(BLOG_POSTS)
    .filter((p) => p.slug !== slug)
    .map((p) => {
      const tagOverlap = p.tags.filter((t) => tags.includes(t)).length;
      const sameCat = p.category === category ? 1 : 0;
      return { post: p, score: tagOverlap * 2 + sameCat };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)
    .map((x) => x.post);
}

function pickRelatedCities(text: string) {
  const lower = text.toLowerCase();
  return CITIES.filter((c) => lower.includes(c.name.toLowerCase())).slice(0, 6);
}

interface Props {
  slug: string;
}

interface BlogImage {
  src: string;
  alt: string;
  photographer: string;
  photographerUrl: string;
  source: string;
  query?: string;
  width?: number;
  height?: number;
}

interface BlogAudio {
  slug: string;
  src: string;
  bytes: number;
  chunks: number;
  voice: string;
  model: string;
}

const BLOG_IMAGES = blogImagesManifest as Record<
  string,
  { slug: string; images: BlogImage[] } | undefined
>;
const BLOG_AUDIO = blogAudioManifest as Record<string, BlogAudio | undefined>;

function formatDate(iso: string): string {
  const d = new Date(iso + 'T12:00:00');
  return d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
}

function BlogFigure({
  image,
  priority = false,
  className = 'mx-auto mb-10 max-w-3xl',
}: {
  image: BlogImage;
  priority?: boolean;
  className?: string;
}) {
  const safeSrc = image.src.replace(/^\/blog-images\//, '/guides/blog-images/');
  const webp = safeSrc.replace(/\.jpe?g$/i, '.webp');
  const avif = safeSrc.replace(/\.jpe?g$/i, '.avif');
  return (
    <figure
      className={`${className} overflow-hidden rounded-2xl border border-brand-line bg-bg-elevated shadow-[0_24px_60px_-30px_rgba(0,0,0,0.75)]`}
    >
      <picture>
        <source srcSet={avif} type="image/avif" />
        <source srcSet={webp} type="image/webp" />
        <img
          src={safeSrc}
          alt={image.alt}
          width={image.width ?? 1400}
          height={image.height ?? 900}
          loading={priority ? 'eager' : 'lazy'}
          fetchPriority={priority ? 'high' : undefined}
          decoding="async"
          className="aspect-[14/9] w-full object-cover"
        />
      </picture>
      <figcaption className="border-t border-brand-line bg-bg-elevated px-4 py-2.5 text-xs text-brand-mute">
        Photo:{' '}
        <a
          href={image.photographerUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="underline-hover hover:text-brand-accent"
        >
          {image.photographer}
        </a>{' '}
        · {image.source}
      </figcaption>
    </figure>
  );
}

export function BlogPost({ slug }: Props) {
  const surfaceProps = useThemeToolsSurface('blog-post');
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const lp = (path: string): string => localizedPath(locale, path);

  const post = useMemo(() => BLOG_POSTS.find((p) => p.slug === slug), [slug]);
  const sortedListed = useMemo(
    () => [...listedPosts(BLOG_POSTS)].sort((a, b) => (a.date < b.date ? 1 : -1)),
    [],
  );
  const { prevPost, nextPost } = useMemo(() => {
    if (!post) return { prevPost: null, nextPost: null };
    const idx = sortedListed.findIndex((p) => p.slug === post.slug);
    if (idx === -1) return { prevPost: null, nextPost: null };
    return {
      prevPost: idx < sortedListed.length - 1 ? sortedListed[idx + 1] ?? null : null,
      nextPost: idx > 0 ? sortedListed[idx - 1] ?? null : null,
    };
  }, [post, sortedListed]);

  if (!post) {
    return (
      <section className="section">
        <div className="container-pad max-w-2xl text-center">
          <h1 className="font-display text-4xl font-extrabold">Post not found</h1>
          <p className="mt-4 text-brand-mute">That article moved or never existed.</p>
          <a href={lp('/blog')} className="btn-primary mt-6 inline-block">
            ← Back to all posts
          </a>
        </div>
      </section>
    );
  }

  const related = useMemo(
    () => (post ? pickRelatedPosts(post.slug, post.tags, post.category) : []),
    [post],
  );
  const relatedServices = useMemo(
    () =>
      post
        ? pickRelatedServices(post)
            .map((s) => SERVICES.find((sv) => sv.slug === s))
            .filter(Boolean)
        : [],
    [post],
  );
  const relatedCities = useMemo(
    () =>
      post ? pickRelatedCities(`${post.title} ${post.excerpt} ${post.body.slice(0, 4000)}`) : [],
    [post],
  );
  const imagesEntry = BLOG_IMAGES[post.slug];
  const images = imagesEntry?.images ?? [];
  const audio = BLOG_AUDIO[post.slug];

  const heroImage = images[0];
  const midImage = images[1];
  const tailImage = images[2];

  const dossier = useMemo(() => {
    const inferredWorkType =
      post.serviceKey ||
      (post.category === 'Power washing'
        ? 'power-washing'
        : post.category === 'Lawn care'
          ? 'yard-work'
          : post.category === 'Hauling'
            ? 'junk-removal'
            : post.category === 'Repairs'
              ? 'handyman'
              : 'moving-labor');
    const townSlug = post.citySlug || 'newark';
    return buildLongFormPageAuthorityDossier({
      modifierSlug: post.slug,
      town: { slug: townSlug },
      workTypeSlug: inferredWorkType,
      canonicalPath: `/blog/${post.slug}`,
      prefilledBookingPath: `/book?city=${encodeURIComponent(townSlug)}&service=${encodeURIComponent(inferredWorkType)}&crew=1&hours=2&ref=blog-${encodeURIComponent(post.slug)}`,
    });
  }, [post]);

  const [readProgressPct, setReadProgressPct] = useState(14);
  const [linkCopied, setLinkCopied] = useState(false);

  useEffect(() => {
    const base = `${post.title} · Brick Labor Newark`;
    document.title = base.length <= 60 ? base : `${post.title.slice(0, 44)}… · Brick Labor`;
    return () => {
      document.title = 'Brick Labor · $50/hr Property Crew Newark NJ';
    };
  }, [post.title]);

  useEffect(() => {
    const onScroll = () => {
      const docEl = document.documentElement;
      const scrollTop = window.scrollY || docEl.scrollTop || 0;
      const maxScroll = Math.max(1, docEl.scrollHeight - window.innerHeight);
      const pct = Math.max(6, Math.min(100, Math.round((scrollTop / maxScroll) * 100)));
      setReadProgressPct(pct);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const jumpToElement = (selector: string) => {
    const el = document.querySelector(selector);
    el?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  };

  const canonicalArticleUrl = `https://bricklabor.com/blog/${post.slug}`;

  const copyCanonicalLink = async () => {
    try {
      await navigator.clipboard.writeText(canonicalArticleUrl);
      setLinkCopied(true);
      window.setTimeout(() => setLinkCopied(false), 2200);
    } catch {
      setLinkCopied(true);
    }
  };

  return (
    <article
      className="section relative overflow-hidden"
      data-theme-tools-surface={surfaceProps['data-theme-tools-surface']}
      data-theme-tools-pricing-model={surfaceProps['data-theme-tools-pricing-model']}
    >
      {/* @theme.tools/blog Top Scroll-Driven Reading Progress Bar */}
      <div
        data-testid="tt-blog-reading-progress"
        role="progressbar"
        aria-label="Article reading progress"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={readProgressPct}
        className="fixed inset-x-0 top-0 z-40 h-1 bg-white/10"
      >
        <div
          style={{ width: `${readProgressPct}%` }}
          className="h-full bg-gradient-to-r from-[#ff6b1a] via-[#ff9248] to-emerald-400 transition-all duration-150"
        />
      </div>

      <div
        className="pointer-events-none absolute inset-0 -z-10 grid-pattern opacity-50"
        aria-hidden="true"
      />
      <div
        className="bcl-hero-glow pointer-events-none absolute -top-32 -right-32 -z-10 h-[420px] w-[420px] rounded-full bg-brand-accent/12 blur-3xl"
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-px bg-gradient-to-r from-transparent via-brand-accent/40 to-transparent"
        aria-hidden="true"
      />

      <div className="container-pad">
        <nav aria-label="Breadcrumb" className="mx-auto mb-6 max-w-3xl text-sm text-brand-mute">
          <a href={lp('/')} className="underline-hover">
            Home
          </a>
          <span className="mx-2">/</span>
          <a href={lp('/blog')} className="underline-hover">
            Blog
          </a>
          <span className="mx-2">/</span>
          <span className="text-brand-ink">{post.category}</span>
        </nav>

        <header className="mx-auto mb-10 max-w-3xl">
          <div className="mb-4 flex flex-wrap items-center gap-2">
            <span className="rounded-full border border-brand-accent/35 bg-brand-accent/10 px-3 py-1 font-mono text-xs uppercase tracking-widest text-brand-accent">
              {post.category}
            </span>
            <span className="font-mono text-xs uppercase tracking-widest text-brand-mute">
              · {post.readMinutes}
            </span>
          </div>
          <h1 className="text-4xl sm:text-5xl font-extrabold leading-[1.05]">{post.title}</h1>
          <p className="mt-5 text-lg text-brand-mute leading-relaxed">{post.excerpt}</p>
          <div className="mt-6 flex flex-wrap items-center justify-between gap-4 border-y border-brand-line/70 py-3.5 text-sm text-brand-mute">
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
              <span className="font-semibold text-brand-ink">
                <a
                  href="https://linkedin.com/in/brianzalewski"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="underline-hover hover:text-brand-accent"
                >
                  {post.author}
                </a>
              </span>
              <span aria-hidden>·</span>
              <time dateTime={post.date}>{formatDate(post.date)}</time>
              {post.updated !== post.date && (
                <>
                  <span aria-hidden>·</span>
                  <span>
                    reviewed <time dateTime={post.updated}>{formatDate(post.updated)}</time>
                  </span>
                </>
              )}
            </div>
            {post.tags && post.tags.length > 0 && (
              <ul className="flex flex-wrap gap-1.5" aria-label="Article tags">
                {post.tags.slice(0, 4).map((tag) => (
                  <li
                    key={tag}
                    className="rounded-md border border-brand-line bg-bg-elevated px-2 py-0.5 font-mono text-[11px] text-brand-mute"
                  >
                    #{tag}
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Clean Borderless Jump Links Into Article Sections */}
          <div
            data-testid="tt-blog-multimedia-badges"
            className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-brand-mute"
          >
            <span className="font-mono text-[10px] font-bold uppercase tracking-wider text-brand-accent">
              In this article:
            </span>
            {[
              { label: 'Audio Overview', target: '[data-testid="atf-podcast-player"]' },
              { label: 'Before & After Comparison', target: '[data-testid="tt-multimedia-before-after-slider"]' },
              { label: 'Newark Surface Guide', target: '[data-testid="tt-multimedia-surface-tabs"]' },
              { label: '20-Min Sample Routine', target: '[data-testid="tt-multimedia-step-reel"]' },
              { label: 'Field Photography', target: '[data-testid="tt-multimedia-photo-gallery"]' },
              { label: '5-Min Prep Checklist', target: '[data-testid="tt-multimedia-prep-checklist"]' },
              { label: 'Citations [1–8]', target: '[data-testid="collapsible-citations-drawer"]' },
            ].map((pill) => (
              <button
                key={pill.label}
                type="button"
                onClick={() => jumpToElement(pill.target)}
                className="underline-hover hover:text-brand-ink transition"
              >
                {pill.label}
              </button>
            ))}
          </div>
        </header>

        {heroImage && <BlogFigure image={heroImage} priority className="mx-auto mb-10 max-w-3xl" />}

        <div className="mb-10 w-full">
          <FieldServicePodcastPlayer
            episode={dossier.podcast}
            audioSrc={audio?.src}
            bookingUrl="https://bricklabor.com/book"
          />
        </div>

        <div
          className="prose-bcl mx-auto max-w-3xl"
          dangerouslySetInnerHTML={{ __html: post.body }}
        />

        {/* Editorial Multimedia Sections Flowing Directly Inside Article Column */}
        <div className="mx-auto max-w-3xl">
          <ArticleMultimediaSuite
            townName={dossier.townHeritage.townName}
            state={dossier.townHeritage.state}
            isPowerWash={post.category.toLowerCase().includes('power') || post.slug.includes('power-washing')}
            bookingUrl="https://bricklabor.com/book"
          />
        </div>

        {midImage && <BlogFigure image={midImage} className="mx-auto mt-10 max-w-3xl" />}

        {tailImage && <BlogFigure image={tailImage} className="mx-auto mt-6 max-w-3xl" />}

        {/* Popped-Out Collapsible References Drawer (Outside the max-w-3xl prose container & Collapsed by Default) */}
        <div className="mx-auto mt-14 max-w-5xl">
          <AuthorityDossierTail dossier={dossier} />
        </div>

        {/* Open Author Bio + 1-Click Share Bar Flowing in Article Column */}
        <section
          data-testid="tt-blog-author-and-share"
          aria-label="Author biography and article sharing"
          className="mx-auto mt-12 max-w-3xl border-t border-white/10 pt-8"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4">
            <div className="flex items-center gap-3.5">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-[#ff6b1a]/45 bg-[#ff6b1a]/15 font-display text-lg font-extrabold text-[#ff985a]">
                BZ
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="font-display text-base font-extrabold text-[#f5f2ed]">
                    {post.author}
                  </h3>
                  <span className="font-mono text-[10px] font-bold uppercase tracking-wider text-emerald-300">
                    · Verified Newark Field Lead
                  </span>
                </div>
                <p className="text-xs text-[#9ba1ab]">
                  Founder &amp; Lead Field Supervisor at Brick Labor · Newark, NJ (07102) &amp; Parsippany (07054)
                </p>
              </div>
            </div>
            <a
              href="https://linkedin.com/in/brianzalewski"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center font-mono text-xs font-semibold text-[#ff985a] hover:text-white transition"
            >
              LinkedIn Profile ↗
            </a>
          </div>

          <p className="mt-2 text-xs sm:text-sm text-[#c5c0b8] leading-relaxed">
            Brian leads Brick Labor’s $50/hr property labor crews across Newark, Essex County, and all 564 New Jersey municipalities—specializing in 500 PSI historic masonry soft-washing, 4.0 GPM rotary surface cleaning, moving labor, yard care, and same-day hauling.
          </p>

          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-white/10">
            <span className="font-mono text-[10px] font-bold uppercase tracking-wider text-[#9ba1ab]">
              Share this article:
            </span>
            <div className="flex flex-wrap items-center gap-3">
              <a
                href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(post.title)}&url=${encodeURIComponent(canonicalArticleUrl)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="font-mono text-xs font-semibold text-[#d6d1c9] hover:text-[#ff985a] transition"
              >
                Post on X ↗
              </a>
              <a
                href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(canonicalArticleUrl)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="font-mono text-xs font-semibold text-[#d6d1c9] hover:text-[#ff985a] transition"
              >
                LinkedIn ↗
              </a>
              <button
                type="button"
                onClick={() => void copyCanonicalLink()}
                data-testid="tt-blog-copy-link-button"
                className="font-mono text-xs font-bold text-[#ff985a] hover:text-white transition"
              >
                {linkCopied ? '✓ Link Copied' : 'Copy Link'}
              </button>
            </div>
          </div>
        </section>

        <aside className="mx-auto mt-12 max-w-3xl border-t border-white/10 pt-8">
          <p className="eyebrow mb-2">Flat $50/hr per person</p>
          <h2 className="font-display text-2xl font-extrabold">Hire the crew</h2>
          <p className="mt-2 text-brand-mute">
            Same flat{' '}
            <a href={lp('/#pricing')} className="text-brand-accent underline-hover">
              $50/hr per person
            </a>{' '}
            across NJ + NYC. Book a slot from the{' '}
            <a href={lp(`/book?ref=blog-${post.slug}`)} className="text-brand-accent underline-hover">
              live calendar
            </a>
            , text{' '}
            <a href={PHONE_TEL_HREF} className="text-brand-accent underline-hover">
              (855) 82LABOR
            </a>
            , or email{' '}
            <a href="mailto:hey@bricklabor.com" className="text-brand-accent underline-hover">
              hey@bricklabor.com
            </a>
            .
          </p>
          <div className="mt-5 flex flex-wrap gap-3">
            <a href={lp(`/book?ref=blog-${post.slug}`)} className="btn-primary btn-arrow">
              Book a crew <span data-btn-arrow aria-hidden="true">→</span>
            </a>
            <a href={PHONE_TEL_HREF} className="btn-ghost">
              (855) 82LABOR
            </a>
            <a href={lp('/#testimonials')} className="btn-ghost">
              Read reviews
            </a>
          </div>
        </aside>

        <DashboardCallout source={`blog-${post.slug}`} context="your existing jobs" />

        {(prevPost || nextPost) && (
          <nav
            className="mx-auto mt-12 max-w-3xl grid gap-4 border-t border-brand-line pt-8 sm:grid-cols-2"
            aria-label="Post navigation"
          >
            {prevPost ? (
              <a
                href={lp(`/blog/${prevPost.slug}`)}
                rel="prev"
                className="card-hover group block"
              >
                <p className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
                  ← Previous
                </p>
                <p className="mt-2 font-display text-base font-bold leading-snug text-brand-ink group-hover:text-brand-accent">
                  {prevPost.title}
                </p>
              </a>
            ) : (
              <span />
            )}
            {nextPost ? (
              <a
                href={lp(`/blog/${nextPost.slug}`)}
                rel="next"
                className="card-hover group block sm:text-right"
              >
                <p className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
                  Next →
                </p>
                <p className="mt-2 font-display text-base font-bold leading-snug text-brand-ink group-hover:text-brand-accent">
                  {nextPost.title}
                </p>
              </a>
            ) : (
              <span />
            )}
          </nav>
        )}

        {relatedServices.length > 0 && (
          <section className="mx-auto mt-12 max-w-3xl">
            <p className="eyebrow mb-2">Service hubs</p>
            <h2 className="font-display text-xl font-extrabold">Related services</h2>
            <p className="mt-2 text-sm text-brand-mute">
              The crew does more than what this post covers — every service runs the same{' '}
              <a href={lp('/#pricing')} className="text-brand-accent underline-hover">
                flat-rate pricing
              </a>
              .
            </p>
            <ul className="mt-4 grid gap-4 sm:grid-cols-3">
              {relatedServices.map(
                (svc) =>
                  svc && (
                    <li
                      key={svc.slug}
                      className="group overflow-hidden rounded-2xl border border-brand-line bg-bg-elevated transition-all duration-[333ms] hover:-translate-y-1 hover:border-brand-accent/60 hover:shadow-[0_18px_50px_-20px_rgba(255,107,26,0.45)]"
                    >
                      <a href={lp(`/services/${svc.slug}`)} className="block">
                        <div className="relative aspect-[16/10] overflow-hidden bg-bg-primary">
                          <picture>
                            <source srcSet={serviceHeroImage(svc).avif} type="image/avif" />
                            <source srcSet={serviceHeroImage(svc).webp} type="image/webp" />
                            <img
                              src={serviceHeroImage(svc).jpg}
                              alt={`${svc.name} — Newark crew`}
                              loading="lazy"
                              decoding="async"
                              className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                            />
                          </picture>
                          <div
                            className="absolute inset-0 bg-gradient-to-t from-bg-primary via-bg-primary/40 to-transparent"
                            aria-hidden
                          />
                        </div>
                        <div className="p-4">
                          <p className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
                            Service
                          </p>
                          <h3 className="mt-1.5 font-display text-base font-bold leading-snug text-brand-ink group-hover:text-brand-accent">
                            {svc.name}
                          </h3>
                          <p className="mt-1.5 text-xs text-brand-mute">{svc.ogTagline}</p>
                        </div>
                      </a>
                    </li>
                  ),
              )}
            </ul>
          </section>
        )}

        {relatedCities.length > 0 && (
          <section className="mx-auto mt-12 max-w-3xl">
            <h2 className="font-display text-xl font-extrabold">Cities we mentioned</h2>
            <p className="mt-2 text-sm text-brand-mute">
              We cover all of these on the same Newark dispatch. See the{' '}
              <a href={lp('/#coverage')} className="text-brand-accent underline-hover">
                full coverage map
              </a>{' '}
              or jump straight to a city page.
            </p>
            <ul className="mt-4 flex flex-wrap gap-2 text-sm">
              {relatedCities.map((c) => (
                <li key={c.slug}>
                  <a
                    href={lp(`/c/${c.slug}`)}
                    className="inline-block rounded-full border border-brand-line bg-bg-elevated px-3 py-1.5 text-brand-mute underline-hover hover:border-brand-accent hover:text-brand-accent"
                  >
                    {c.name}, {c.state}
                  </a>
                </li>
              ))}
            </ul>
          </section>
        )}

        <JsonLd data={personBrian()} />

        {related.length > 0 && (
          <section className="mx-auto mt-16 max-w-3xl">
            <p className="eyebrow mb-2">Field archive</p>
            <h2 className="font-display text-xl font-extrabold">More from the field</h2>
            <p className="mt-2 text-sm text-brand-mute">
              Hand-picked from the{' '}
              <a href={lp('/blog')} className="text-brand-accent underline-hover">
                full property care archive
              </a>{' '}
              — same crew, same flat rate.
            </p>
            <ul className="mt-4 grid gap-4 sm:grid-cols-3">
              {related.map((r) => (
                <li key={r.slug} className="card-hover group flex flex-col justify-between">
                  <div>
                    <p className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
                      {r.category}
                    </p>
                    <h3 className="mt-2 font-display text-base font-bold leading-snug">
                      <a
                        href={lp(`/blog/${r.slug}`)}
                        className="text-brand-ink underline-hover group-hover:text-brand-accent"
                      >
                        {r.title}
                      </a>
                    </h3>
                    <p className="mt-2 text-xs text-brand-mute line-clamp-3">{r.excerpt}</p>
                  </div>
                </li>
              ))}
            </ul>
            <p className="mt-6 text-sm text-brand-mute">
              Looking for something else? Browse{' '}
              <a href={lp('/blog')} className="text-brand-accent underline-hover">
                every post
              </a>
              ,{' '}
              <a href={lp('/#faq')} className="text-brand-accent underline-hover">
                scan the FAQ
              </a>
              , or{' '}
              <a href={lp('/#contact')} className="text-brand-accent underline-hover">
                drop us a note
              </a>
              .
            </p>
          </section>
        )}
      </div>
    </article>
  );
}
