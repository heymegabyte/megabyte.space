import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { BeforeAfterGallery, DEFAULT_PAIRS } from './BeforeAfterGallery.js';
import { Contact } from './Contact.js';
import { CrewShowcase, DEFAULT_CREW } from './CrewShowcase.js';
import { OwnerBio } from './OwnerBio.js';
import PhotoQuoteUpload from './PhotoQuoteUpload.js';
import PhotoSmsEstimate from './PhotoSmsEstimate.js';
import { Reviews } from './Reviews.js';

/**
 * Homepage-only below-the-fold section group, code-split out of the shared
 * SPA entry chunk via React.lazy in `App.tsx`. These sections render ONLY on
 * `/` (verified homepage-only), carry NO SEO/GEO-critical JSON-LD (the
 * FAQPage + Review structured data live on the eager-rendered `<FAQ>` and
 * `<Testimonials>` that bracket this group), and sit well below the fold.
 *
 * Splitting them into their own chunk removes their JavaScript from the entry
 * bundle that every one of the 450+ pSEO city/service pages downloads but
 * never renders — shrinking render-blocking initial JS on those pages and
 * lifting LCP across the pSEO surface. On `/` itself the chunk streams in
 * below the fold behind a reserved-height Suspense fallback, so there is no
 * CLS and the LCP hero is untouched.
 */
export default function HomeMidSections() {
  useThemeToolsSurface('home-mid-sections');
  return (
    <>
      <CrewShowcase crew={DEFAULT_CREW} />
      <Reviews />
      <PhotoQuoteUpload />
      <PhotoSmsEstimate />
      <BeforeAfterGallery pairs={DEFAULT_PAIRS} />
      <OwnerBio />
      <Contact />
    </>
  );
}
