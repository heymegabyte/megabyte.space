import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useMemo, useState } from 'react';
import {
  HOURLY_RATE_USD,
  LANDING_MATRIX_DIMENSIONS,
  LANDING_MATRIX_PAGES,
  RECURRING_DISCOUNT_PCT,
  computeMatrixPageEstimate,
  getLandingMatrixPage,
  type LandingMatrixDimensionId,
  type LandingMatrixPage as LandingMatrixPageEntry,
} from '@theme.tools/seo-geo/field-service/landing-matrix';
import {
  MATRIX_WORK_TYPES,
  TERRITORY_07054_100MI_BREAKDOWN,
  buildLongFormPageAuthorityDossier,
  buildMatrix3DPageJson,
  calculateMatrix3DPageCounts,
} from '@theme.tools/seo-geo/field-service/matrix-3d-engine';
import { CITIES, getCityBySlug } from '../data/cities.js';
import { PHONE_DISPLAY, PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { FieldServicePodcastPlayer } from './FieldServicePodcastPlayer.js';
import { MarkdownGuideArticle } from './MarkdownGuideArticle.js';
import { CollapsibleCitationsDrawer } from './CollapsibleCitationsDrawer.js';

export interface LandingMatrixPageProps {
  readonly slug?: string;
  readonly townSlug?: string;
  readonly workTypeSlug?: string;
}

const CITY_LABELS: Readonly<Record<string, string>> = {
  newark: 'Newark',
  'jersey-city': 'Jersey City',
  hoboken: 'Hoboken',
  montclair: 'Montclair',
  maplewood: 'Maplewood',
  summit: 'Summit',
  morristown: 'Morristown',
  'east-orange': 'East Orange',
  elizabeth: 'Elizabeth',
  paterson: 'Paterson',
  'fort-lee': 'Fort Lee',
  bloomfield: 'Bloomfield',
  secaucus: 'Secaucus',
  livingston: 'Livingston',
  'west-orange': 'West Orange',
  'south-orange': 'South Orange',
  clifton: 'Clifton',
  cranford: 'Cranford',
  edison: 'Edison',
  union: 'Union',
  parsippany: 'Parsippany',
  'parsippany-troy-hills': 'Parsippany-Troy Hills',
  irvington: 'Irvington',
  westfield: 'Westfield',
  ridgewood: 'Ridgewood',
  millburn: 'Millburn',
};

function formatCityName(slug: string): string {
  return CITY_LABELS[slug] ?? slug.replace(/-/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}

export function LandingMatrixPage({ slug, townSlug, workTypeSlug }: LandingMatrixPageProps) {
  useThemeToolsSurface(
    townSlug && workTypeSlug && slug
      ? `3d-${townSlug}-${workTypeSlug}-${slug}`
      : slug
        ? `for-${slug}`
        : 'for-index',
  );
  const locale =
    typeof window !== 'undefined' ? stripLocalePrefix(window.location.pathname).locale : 'en';
  const lp = (path: string) => localizedPath(locale, path);
  const [selectedDimension, setSelectedDimension] = useState<'all' | LandingMatrixDimensionId>('all');
  const [query, setQuery] = useState('');
  const [previewTown, setPreviewTown] = useState(townSlug ?? 'newark');
  const [previewWorkType, setPreviewWorkType] = useState(workTypeSlug ?? 'moving-labor');
  const [previewModifier, setPreviewModifier] = useState(slug ?? '3-movers-4-hours-walkup-brigade');

  const detailPage = useMemo(() => (slug ? getLandingMatrixPage(slug) : undefined), [slug]);

  const spec3D = useMemo(() => {
    const activeTownSlug = townSlug ?? previewTown;
    const activeWorkSlug = workTypeSlug ?? detailPage?.primaryServiceSlug ?? previewWorkType;
    const activeModSlug = slug ?? previewModifier;
    const cityObj = getCityBySlug(activeTownSlug);
    return buildMatrix3DPageJson({
      town: cityObj
        ? {
            slug: cityObj.slug,
            name: cityObj.name,
            county: cityObj.county,
            state: cityObj.state,
            lat: cityObj.lat,
            lng: cityObj.lng,
          }
        : { slug: activeTownSlug, name: formatCityName(activeTownSlug) },
      workTypeSlug: activeWorkSlug,
      modifierSlug: activeModSlug,
    });
  }, [townSlug, workTypeSlug, slug, detailPage, previewTown, previewWorkType, previewModifier]);

  const counts1450 = useMemo(() => calculateMatrix3DPageCounts({ G: 1450, W: 9, M: 30 }), []);

  const filteredPages = useMemo(() => {
    const q = query.trim().toLowerCase();
    return LANDING_MATRIX_PAGES.filter((page) => {
      if (selectedDimension !== 'all' && page.dimension !== selectedDimension) return false;
      if (!q) return true;
      return (
        page.title.toLowerCase().includes(q) ||
        page.answerCapsule.toLowerCase().includes(q) ||
        page.eyebrow.toLowerCase().includes(q) ||
        page.slug.toLowerCase().includes(q)
      );
    });
  }, [selectedDimension, query]);

  if (townSlug && workTypeSlug && slug && spec3D && detailPage) {
    return (
      <MatrixDetailView
        page={detailPage}
        spec3D={spec3D}
        townSlug={townSlug}
        workTypeSlug={workTypeSlug}
        lp={lp}
      />
    );
  }

  if (slug && detailPage) {
    return (
      <MatrixDetailView
        page={detailPage}
        spec3D={undefined}
        townSlug={townSlug ?? 'newark'}
        workTypeSlug={workTypeSlug ?? detailPage.primaryServiceSlug}
        lp={lp}
      />
    );
  }

  return (
    <div className="min-h-screen bg-bg-primary text-brand-ink">
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-brand-line py-16 sm:py-24">
        <div className="bcl-hero-glow" aria-hidden="true" />
        <div className="absolute inset-0 grid-pattern opacity-35 pointer-events-none" aria-hidden="true" />
        <div className="container-pad relative">
          <nav aria-label="Breadcrumb" className="mb-5 flex items-center gap-2 font-mono text-xs uppercase tracking-[0.16em] text-brand-mute">
            <a href={lp('/')} className="hover:text-brand-accent transition-colors">Home</a>
            <span aria-hidden="true">/</span>
            <span className="text-brand-accent" aria-current="page">Solutions Matrix</span>
          </nav>
          <p className="eyebrow mb-3">7-Axis Landing Page Matrix · $50/hr Per Crew Member · 2,000+ Word Authority Dossiers</p>
          <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight max-w-4xl leading-[1.06]">
            Every way to book hourly property labor — by{' '}
            <span className="text-gradient">town, work type, building archetype, container &amp; crew block.</span>
          </h1>
          <p
            data-answer-capsule="true"
            className="mt-6 max-w-3xl text-lg sm:text-xl text-brand-mute leading-relaxed"
          >
            Beyond our 51 New Jersey city hubs and 450 city × service pages, Brick Labor indexes every job across all 564 New Jersey municipalities and 1,450 towns within 100 miles of ZIP 07054 (Parsippany-Troy Hills) by physical building archetype, customer-rented truck or container, life-event scenario, crew × hour block, and recurring discount cadence—all billed at a transparent <strong className="text-brand-ink">$50/hr per crew member</strong> (1-hour minimum).
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            <a
              href="https://bricklabor.com/book"
              data-testid="matrix-index-primary-book-cta"
              className="btn btn-primary btn-arrow"
            >
              <span>Book Your Hourly Crew at bricklabor.com/book</span>
              <span data-btn-arrow aria-hidden="true">→</span>
            </a>
            <a
              href={lp('/for/3-movers-4-hours-walkup-brigade')}
              className="btn btn-ghost font-mono text-xs"
            >
              Explore Flagship 3-Movers-4-Hours Dossier (2,000+ Words + Podcast) →
            </a>
          </div>

          {/* 7-Axis Overview Strip */}
          <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <a
              href={lp('/locations')}
              className="card card-hover p-4 flex flex-col justify-between"
            >
              <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-brand-accent">Axis 1–3 · Geography</span>
              <span className="mt-1 font-display text-lg font-bold text-brand-ink">51 Seed Cities · 1,450 Towns in 07054 Radius</span>
              <span className="mt-2 text-xs text-brand-mute">Hyperlocal dispatch distances, municipal permits &amp; Census housing data →</span>
            </a>
            <a
              href={lp('/buildings')}
              className="card card-hover p-4 flex flex-col justify-between"
            >
              <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-brand-accent">Axis 4 · Building COI Registry</span>
              <span className="mt-1 font-display text-lg font-bold text-brand-ink">25 Named NJ High-Rises</span>
              <span className="mt-2 text-xs text-brand-mute">Freight cab dimensions, dock rules &amp; $1M–$5M COI templates on file →</span>
            </a>
            <a
              href={lp('/vs')}
              className="card card-hover p-4 flex flex-col justify-between"
            >
              <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-brand-accent">Axis 5 · Competitor Rubrics</span>
              <span className="mt-1 font-display text-lg font-bold text-brand-ink">Brick Labor vs. National Apps</span>
              <span className="mt-2 text-xs text-brand-mute">Side-by-side pricing &amp; insurance vs. Lugg, Dolly, TaskRabbit &amp; Bellhop →</span>
            </a>
            <a
              href="https://bricklabor.com/book"
              className="card card-hover p-4 flex flex-col justify-between border-brand-accent/50"
            >
              <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-brand-accent">Axis 6–7 · Below (30 Guides)</span>
              <span className="mt-1 font-display text-lg font-bold text-brand-ink">Archetypes · Containers · Scenarios · Crew Blocks</span>
              <span className="mt-2 text-xs text-brand-mute">Pre-configured crew × hour estimates ready to lock in at $50/hr →</span>
            </a>
          </div>
        </div>
      </section>

      {/* Interactive 3D Matrix Composer (Town × Work Type × Specialty Modifier) */}
      <section className="border-b border-brand-line bg-bg-elevated/60 py-12">
        <div className="container-pad">
          <div className="rounded-2xl border border-brand-line bg-bg-elevated p-6 sm:p-8">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
              <div>
                <p className="eyebrow mb-2">
                  3D JSON Page Matrix · 07054 100-Mile Corridor ({counts1450.G.toLocaleString()} Towns × {counts1450.W} Work Types × {counts1450.M} Modifiers)
                </p>
                <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-brand-ink">
                  Compose any 3D landing page: Town × Work Type × Specialty Modifier
                </h2>
                <p className="mt-1 text-sm text-brand-mute">
                  Full 3D hierarchy across {TERRITORY_07054_100MI_BREAKDOWN.length} states ({counts1450.totals.userHierarchyFullCartesian.toLocaleString()} total 1D+2D+3D pages; {counts1450.totals.semanticallyPrunedHighIntentTotal.toLocaleString()} semantically pruned high-intent pages).
                </p>
              </div>
              {spec3D && (
                <a
                  href={lp(spec3D.canonicalPath)}
                  className="btn btn-primary btn-arrow whitespace-nowrap"
                >
                  <span>Open 3D Page ({spec3D.coordinates.townName})</span>
                  <span data-btn-arrow aria-hidden="true">→</span>
                </a>
              )}
            </div>

            <div className="mt-6 grid gap-4 sm:grid-cols-3">
              <label className="block">
                <span className="field-label">1. Town / Municipality (G)</span>
                <select
                  value={previewTown}
                  onChange={(e) => setPreviewTown(e.target.value)}
                  className="field-input text-sm"
                >
                  {CITIES.map((c) => (
                    <option key={c.slug} value={c.slug}>
                      {c.name}, {c.state} ({c.county} County)
                    </option>
                  ))}
                </select>
              </label>
              <label className="block">
                <span className="field-label">2. Work Type (W)</span>
                <select
                  value={previewWorkType}
                  onChange={(e) => setPreviewWorkType(e.target.value)}
                  className="field-input text-sm"
                >
                  {MATRIX_WORK_TYPES.map((w) => (
                    <option key={w.slug} value={w.slug}>
                      {w.name}
                    </option>
                  ))}
                </select>
              </label>
              <label className="block">
                <span className="field-label">3. Specialty Modifier (M)</span>
                <select
                  value={previewModifier}
                  onChange={(e) => setPreviewModifier(e.target.value)}
                  className="field-input text-sm"
                >
                  {LANDING_MATRIX_PAGES.map((m) => (
                    <option key={m.slug} value={m.slug}>
                      {m.title}
                    </option>
                  ))}
                </select>
              </label>
            </div>

            {spec3D && (
              <details className="mt-5 rounded-xl border border-brand-line bg-bg-primary p-4">
                <summary className="cursor-pointer font-mono text-xs uppercase tracking-[0.15em] text-brand-accent">
                  Inspect Generated JSON Page Blueprint ({spec3D.canonicalPath}) · {spec3D.componentBlocks.length} Page Sections
                </summary>
                <pre className="mt-3 max-h-72 overflow-auto font-mono text-xs text-brand-mute">
                  {JSON.stringify(spec3D, null, 2)}
                </pre>
              </details>
            )}
          </div>
        </div>
      </section>

      {/* Filter Bar & 30-Page Matrix Grid */}
      <section className="section-tight">
        <div className="container-pad">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 pb-8 border-b border-brand-line">
            <div className="flex flex-wrap gap-2" role="tablist" aria-label="Filter matrix dimensions">
              <button
                type="button"
                role="tab"
                aria-selected={selectedDimension === 'all'}
                onClick={() => setSelectedDimension('all')}
                className={`rounded-full px-4 py-2 font-mono text-xs uppercase tracking-[0.14em] transition-colors ${
                  selectedDimension === 'all'
                    ? 'bg-brand-accent text-bg-primary font-bold'
                    : 'border border-brand-line bg-bg-elevated text-brand-mute hover:border-brand-accent hover:text-brand-ink'
                }`}
              >
                All Dimensions ({LANDING_MATRIX_PAGES.length})
              </button>
              {LANDING_MATRIX_DIMENSIONS.map((dim) => {
                const count = LANDING_MATRIX_PAGES.filter((p) => p.dimension === dim.id).length;
                const active = selectedDimension === dim.id;
                return (
                  <button
                    key={dim.id}
                    type="button"
                    role="tab"
                    aria-selected={active}
                    onClick={() => setSelectedDimension(dim.id)}
                    className={`rounded-full px-4 py-2 font-mono text-xs uppercase tracking-[0.14em] transition-colors ${
                      active
                        ? 'bg-brand-accent text-bg-primary font-bold'
                        : 'border border-brand-line bg-bg-elevated text-brand-mute hover:border-brand-accent hover:text-brand-ink'
                    }`}
                  >
                    {dim.shortLabel} ({count})
                  </button>
                );
              })}
            </div>
            <div className="w-full lg:w-72">
              <input
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Filter by PODS, walk-up, U-Haul, estate..."
                aria-label="Search landing page matrix"
                className="field-input text-sm"
              />
            </div>
          </div>

          {selectedDimension !== 'all' && (
            <div className="mt-6 rounded-2xl border border-brand-accent/40 bg-bg-elevated p-5">
              {LANDING_MATRIX_DIMENSIONS.filter((d) => d.id === selectedDimension).map((dim) => (
                <div key={dim.id}>
                  <p className="font-mono text-xs uppercase tracking-[0.16em] text-brand-accent">{dim.label} · {dim.urlPattern}</p>
                  <p className="mt-1 text-sm text-brand-ink">{dim.searchIntentSummary}</p>
                  <p className="mt-1 text-xs text-brand-mute">Uniqueness &amp; HCU anchor: {dim.uniquenessAnchor}</p>
                </div>
              ))}
            </div>
          )}

          {/* Cards Grid */}
          <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredPages.map((page) => {
              const est = computeMatrixPageEstimate(page);
              return (
                <article
                  key={page.slug}
                  data-testid={`matrix-card-${page.slug}`}
                  className="card card-hover flex flex-col justify-between p-6"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <span className="rounded-full border border-brand-line bg-bg-primary px-2.5 py-1 font-mono text-[10px] uppercase tracking-[0.15em] text-brand-accent">
                        {page.dimensionLabel}
                      </span>
                      <span className="font-mono text-xs text-brand-mute">
                        {page.recommendedCrew} crew × {page.recommendedHours}h ·{' '}
                        <strong className="text-brand-ink">${est.estimatedTotalUsd}</strong>
                      </span>
                    </div>
                    <h2 className="font-display text-xl font-bold text-brand-ink leading-snug">
                      <a href={lp(`/for/${page.slug}`)} className="hover:text-brand-accent transition-colors">
                        {page.title}
                      </a>
                    </h2>
                    <p className="mt-3 text-sm text-brand-mute leading-relaxed line-clamp-4">
                      {page.answerCapsule}
                    </p>
                  </div>

                  <div className="mt-6 pt-4 border-t border-brand-line/60 flex items-center justify-between gap-3">
                    <a
                      href={lp(`/for/${page.slug}`)}
                      className="font-mono text-xs uppercase tracking-[0.14em] text-brand-ink hover:text-brand-accent transition-colors"
                    >
                      Read 2,000+ word guide →
                    </a>
                    <a
                      href="https://bricklabor.com/book"
                      className="rounded-lg bg-brand-accent px-3.5 py-2 font-display text-xs font-bold text-bg-primary hover:bg-brand-accentHover transition-colors"
                    >
                      Book (${est.estimatedTotalUsd}) →
                    </a>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}

function MatrixDetailView({
  page,
  spec3D,
  townSlug,
  workTypeSlug,
  lp,
}: {
  readonly page: LandingMatrixPageEntry;
  readonly spec3D?: ReturnType<typeof buildMatrix3DPageJson>;
  readonly townSlug: string;
  readonly workTypeSlug: string;
  readonly lp: (path: string) => string;
}) {
  const est = computeMatrixPageEstimate(page);
  const cityObj = getCityBySlug(townSlug);
  const dossier = useMemo(
    () =>
      buildLongFormPageAuthorityDossier({
        modifierSlug: page.slug,
        workTypeSlug,
        town: cityObj
          ? {
              slug: cityObj.slug,
              name: cityObj.name,
              county: cityObj.county,
              state: cityObj.state,
              lat: cityObj.lat,
              lng: cityObj.lng,
            }
          : { slug: townSlug, name: formatCityName(townSlug) },
        canonicalPath: spec3D ? spec3D.canonicalPath : `/for/${page.slug}`,
        prefilledBookingPath: spec3D ? spec3D.pricing.bookingHref : est.bookingHref,
      }),
    [page.slug, workTypeSlug, cityObj, townSlug, spec3D, est.bookingHref],
  );

  // Interactive @theme.tools Crew × Hours & Cadence Calculator state
  const [calcCrew, setCalcCrew] = useState<1 | 2 | 3 | 4>(page.recommendedCrew);
  const [calcHours, setCalcHours] = useState<number>(page.recommendedHours);
  const [calcCadence, setCalcCadence] = useState<
    'one-time' | 'daily' | 'weekly' | 'biweekly' | 'monthly'
  >(page.recurringPlan ?? 'one-time');

  const calcDiscountPct =
    calcCadence === 'one-time' ? 0 : RECURRING_DISCOUNT_PCT[calcCadence];
  const calcRatePerPerson = Number(
    (HOURLY_RATE_USD * (1 - calcDiscountPct / 100)).toFixed(2),
  );
  const calcTotalUsd = Number((calcCrew * calcHours * calcRatePerPerson).toFixed(2));
  const calcBookUrl = `https://bricklabor.com/book?city=${encodeURIComponent(dossier.townHeritage.townSlug)}&service=${encodeURIComponent(workTypeSlug)}&crew=${calcCrew}&hours=${calcHours}${calcCadence !== 'one-time' ? `&recurring=${calcCadence}` : ''}&from=${encodeURIComponent(page.slug)}`;

  const siblings = LANDING_MATRIX_PAGES.filter(
    (p) => p.dimension === page.dimension && p.slug !== page.slug,
  );
  const displayEyebrow = spec3D ? spec3D.seo.eyebrow : page.eyebrow;
  const displayTitle = spec3D ? spec3D.seo.h1 : page.title;
  const displayCapsule = spec3D ? spec3D.seo.answerCapsule : page.answerCapsule;
  const displaySpecs = spec3D ? spec3D.operationalSpecs : page.operationalSpecs;
  const baseFaqs = spec3D ? spec3D.faqs : page.faqs;
  const displayFaqs =
    baseFaqs.length >= 5
      ? baseFaqs
      : [
          ...baseFaqs,
          {
            q: `How does Brick Labor's $${est.effectiveHourlyRatePerPersonUsd}/hr per-worker pricing and 15-minute increment billing work for ${page.title}?`,
            a: `Every job is billed at a transparent $${est.effectiveHourlyRatePerPersonUsd}/hr per crew member with a 1-hour minimum and exact 15-minute ($12.50) increments after hour 1. For this ${page.recommendedCrew}-person, ${page.recommendedHours}-hour scope, your estimated total is $${est.estimatedTotalUsd} with $0 hidden truck, fuel, or stair surcharges.`,
          },
          {
            q: `Are all commercial tools, dollies, moving pads, and wash equipment included in the $${est.effectiveHourlyRatePerPersonUsd}/hr rate?`,
            a: `Yes. Every crew arrives with commercial-grade equipment included at $0 extra charge—including 4-wheel dollies, quilted furniture pads, forearm lifting straps, neoprene floor runners, and 4.0 GPM commercial pressure washers or 16-inch rotary surface cleaners on exterior wash jobs.`,
          },
          {
            q: `Is there a travel fee or zone surcharge in ${dossier.townHeritage.townName}, ${dossier.townHeritage.state} (${dossier.townHeritage.county} County)?`,
            a: `No. ${dossier.townHeritage.townName} is inside our active $0-travel-fee dispatch corridor (${dossier.townHeritage.distanceFromNewarkMiles} mi from our 07102 Newark hub and ${dossier.townHeritage.distanceFrom07054Miles} mi from our 07054 Parsippany-Troy Hills regional origin). Your clock starts when the crew arrives at your property and stops when the work is finished.`,
          },
          {
            q: `Can I save with standing recurring hourly service in ${dossier.townHeritage.townName}?`,
            a: `Yes. Homeowners, storefronts, and property managers who schedule standing recurring service automatically unlock our discounted hourly tiers: Daily (-12% at $44/hr), Weekly (-8% at $46/hr), Biweekly (-5% at $47.50/hr), and Monthly (-3% at $48.50/hr).`,
          },
        ];

  const [allFaqsOpen, setAllFaqsOpen] = useState<boolean | null>(null);
  const isPowerWash =
    workTypeSlug === 'power-washing' ||
    page.primaryServiceSlug === 'power-washing' ||
    page.slug === 'newark-power-washing-free-sample-work';
  const workerNounSingular = isPowerWash ? 'Tech' : 'Crew Member';
  const workerNounPlural = isPowerWash ? 'Techs' : 'Crew';

  const heroBgSrc = `/cities/${dossier.townHeritage.townSlug}/hero.jpg`;
  const heroVisualCards = isPowerWash
    ? [
        {
          src: '/guides/power-washing/hero.jpg',
          badge: 'FREE SAMPLE SPOT',
          title: 'Driveways & Sidewalks',
          subtitle: 'See a clean 2ft × 2ft patch first',
        },
        {
          src:
            dossier.townHeritage.townSlug === 'newark'
              ? '/cities/newark/local-4.jpg'
              : `/cities/${dossier.townHeritage.townSlug}/1.jpg`,
          badge: `${dossier.townHeritage.townName.toUpperCase()} STONEWORK`,
          title: 'Brownstone & Patios',
          subtitle: 'Gentle soap & low-pressure rinse',
        },
        {
          src:
            dossier.townHeritage.townSlug === 'newark'
              ? '/cities/newark/local-1.jpg'
              : `/cities/${dossier.townHeritage.townSlug}/2.jpg`,
          badge: `${dossier.townHeritage.townName.toUpperCase()} MASONRY`,
          title: 'Brick Porches & Siding',
          subtitle: 'Lifts grime while protecting mortar',
        },
      ]
    : [
        {
          src: `/cities/${dossier.townHeritage.townSlug}/local-1.jpg`,
          badge: `${dossier.townHeritage.townName.toUpperCase()} CREW`,
          title: `${page.recommendedCrew} Crew × ${page.recommendedHours} Hrs ($${est.estimatedTotalUsd})`,
          subtitle: 'Flat $50/hr per worker · $0 travel fee',
        },
        {
          src: `/cities/${dossier.townHeritage.townSlug}/local-2.jpg`,
          badge: 'GEAR INCLUDED ($0)',
          title: 'Dollies, Pads & Tools',
          subtitle: 'Included at no extra charge',
        },
        {
          src: `/cities/${dossier.townHeritage.townSlug}/3.jpg`,
          badge: `${dossier.townHeritage.county.toUpperCase()} COUNTY`,
          title: '1-Hr Min · 15-Min Increments',
          subtitle: 'Simple, honest hourly billing',
        },
      ];

  return (
    <div
      data-testid="landing-matrix-authority-page"
      data-word-count={dossier.wordCount}
      data-primary-keyword={dossier.keywordCluster.primaryKeyword}
      className="min-h-screen bg-bg-primary text-brand-ink"
    >
      {/* ═══════════════════════════════════════════════════════════════════════
          SECTION 1: FULL-BLEED PHOTOGRAPHIC HERO + 3 NEWARK PHOTOS + SIMPLE BOOKING CARD
          ═══════════════════════════════════════════════════════════════════════ */}
      <section className="relative overflow-hidden border-b border-black/85 pt-8 pb-11 sm:pt-11 sm:pb-14 shadow-[0_18px_40px_-18px_rgba(0,0,0,0.92)]">
        <div className="pointer-events-none absolute inset-0" aria-hidden="true">
          <img
            src={heroBgSrc}
            alt=""
            width={1920}
            height={1080}
            loading="eager"
            decoding="async"
            className="h-full w-full object-cover opacity-65"
          />
          <div
            className="absolute inset-0"
            style={{
              background:
                'linear-gradient(105deg, rgba(6,6,16,0.88) 0%, rgba(6,6,16,0.68) 45%, rgba(6,6,16,0.46) 72%, rgba(6,6,16,0.90) 100%)',
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-bg-primary via-bg-primary/30 to-transparent" />
          <div className="absolute inset-0 grid-pattern opacity-40" />
          <div className="bcl-hero-glow absolute -top-40 -right-40 h-[500px] w-[500px] rounded-full bg-brand-accent/20 blur-3xl" />
        </div>

        <div className="container-pad relative">
          <nav
            aria-label="Breadcrumb"
            className="mb-4 flex flex-wrap items-center gap-2 font-mono text-xs uppercase tracking-[0.16em] text-brand-mute"
          >
            <a href={lp('/')} className="hover:text-brand-accent transition-colors">Home</a>
            <span aria-hidden="true">/</span>
            <a href={lp(`/c/${dossier.townHeritage.townSlug}`)} className="hover:text-brand-accent transition-colors">
              {dossier.townHeritage.townName}, {dossier.townHeritage.state}
            </a>
            <span aria-hidden="true">/</span>
            <a href={lp(`/services/${isPowerWash ? 'power-washing' : workTypeSlug}`)} className="hover:text-brand-accent transition-colors">
              {isPowerWash ? 'Power Washing' : page.dimensionLabel}
            </a>
            <span aria-hidden="true">/</span>
            <span className="text-brand-accent" aria-current="page">
              {isPowerWash ? 'Free Sample Guide' : page.title}
            </span>
          </nav>

          {/* Simple Trust Badges */}
          <div className="mb-4 flex flex-wrap items-center gap-2.5">
            <span
              data-testid="page-word-count-badge"
              className="rounded-full border border-emerald-500/40 bg-emerald-500/15 px-3.5 py-1 font-mono text-[11px] font-bold text-emerald-300"
            >
              {isPowerWash
                ? '✓ Free 2ft × 2ft Sample Spot Washed First ($0)'
                : `✓ Flat $${est.effectiveHourlyRatePerPersonUsd}/hr ${dossier.townHeritage.townName} Guide`}
            </span>
            <span
              data-testid="primary-keyword-badge"
              className="rounded-full border border-brand-accent/40 bg-brand-accent/15 px-3.5 py-1 font-mono text-[11px] font-bold text-brand-accent"
            >
              ★ {dossier.townHeritage.townName}, {dossier.townHeritage.state} · $50/hr Per Worker · $0 Travel Fee
            </span>
          </div>

          <div className="grid gap-8 lg:gap-10 lg:grid-cols-12 lg:items-start">
            {/* Hero Left Column */}
            <div className="lg:col-span-7">
              <p className="eyebrow mb-2.5">
                {isPowerWash
                  ? `${dossier.townHeritage.townName.toUpperCase()}, ${dossier.townHeritage.state} HOMEOWNER GUIDE · $50/HR PER WORKER`
                  : displayEyebrow}
              </p>
              <h1
                data-testid="matrix-detail-title"
                className="font-display text-4xl sm:text-6xl font-extrabold tracking-tight leading-[1.04]"
              >
                {isPowerWash ? (
                  <>
                    {dossier.townHeritage.townName} Power Washing.{' '}
                    <span className="text-gradient block mt-1">
                      Free Sample Spot First.
                    </span>
                  </>
                ) : (
                  displayTitle
                )}
              </h1>

              {/* Simple, Plain-English 2-Sentence Lead */}
              <p
                data-answer-capsule="true"
                className="mt-4 sm:mt-5 max-w-2xl text-base sm:text-lg text-brand-ink/90 leading-relaxed"
              >
                {isPowerWash
                  ? `Want to see how clean your ${dossier.townHeritage.townName} brick porch, brownstone steps, patio, or concrete driveway will get before committing to the full job? Our crew washes a free 2ft × 2ft sample spot first so you can see the difference in person — and then we finish the rest at a flat $50/hr per worker (1-hour minimum, 15-minute increments after hour 1, $0 travel fee).`
                  : displayCapsule}
              </p>

              {/* 3 Simple Newark & Power-Washing Photos Right in the Hero */}
              <div
                data-testid="atf-hero-photo-strip"
                className="mt-6 grid gap-3.5 sm:grid-cols-3"
              >
                {heroVisualCards.map((card) => (
                  <div
                    key={card.title}
                    className="group relative flex flex-col justify-between overflow-hidden rounded-2xl border border-black/85 bg-[#0c1017] shadow-[0_22px_54px_-18px_rgba(0,0,0,0.92),0_0_0_1px_rgba(0,0,0,0.9),inset_0_1px_0_rgba(255,255,255,0.035)] transition-all hover:border-brand-accent/70"
                  >
                    <div className="relative aspect-[16/10] w-full overflow-hidden bg-[#080b12]">
                      <img
                        src={card.src}
                        alt={`${card.title} in ${dossier.townHeritage.townName}, ${dossier.townHeritage.state}`}
                        width={600}
                        height={375}
                        loading="eager"
                        className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                      <span className="absolute left-2.5 top-2.5 rounded-md border border-black/85 bg-[#080b10]/90 px-2.5 py-0.5 font-mono text-[9px] font-bold uppercase tracking-wider text-brand-accent shadow-sm">
                        {card.badge}
                      </span>
                    </div>
                    <div className="px-4 py-3.5">
                      <p className="font-display text-xs sm:text-sm font-extrabold text-brand-ink leading-snug">
                        {card.title}
                      </p>
                      <p className="mt-1 text-[11px] text-brand-mute leading-tight">
                        {card.subtitle}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Hero Right Column: Simple, Clean Instant Quote & Booking Card */}
            <aside
              data-testid="interactive-hourly-calculator"
              className="lg:col-span-5 lg:sticky lg:top-24"
            >
              <div className="overflow-hidden rounded-2xl border border-black/85 bg-[#0c1017]/95 shadow-[0_28px_68px_-20px_rgba(0,0,0,0.95),0_0_0_1px_rgba(0,0,0,0.9),inset_0_1px_0_rgba(255,255,255,0.045)] backdrop-blur-md">
                <div className="h-[3px] w-full bg-gradient-to-r from-[#ff6b1a] via-[#ff8a47] to-transparent" aria-hidden="true" />
                <div className="relative grid grid-cols-2 h-32 overflow-hidden border-b border-black/85">
                  <div className="relative overflow-hidden">
                    <img
                      src={isPowerWash ? '/guides/power-washing/surface-cleaner.jpg' : `/cities/${dossier.townHeritage.townSlug}/local-1.jpg`}
                      alt={`${dossier.townHeritage.townName} equipment`}
                      width={480}
                      height={270}
                      loading="eager"
                      className="h-full w-full object-cover"
                    />
                    <span className="absolute bottom-2.5 left-2.5 rounded-md border border-black/85 bg-[#080b10]/90 px-2 py-0.5 font-mono text-[9px] font-bold uppercase text-brand-accent">
                      {isPowerWash ? 'All Wash Gear Included ($0)' : 'All Tools Included ($0)'}
                    </span>
                  </div>
                  <div className="relative overflow-hidden border-l border-black/85">
                    <img
                      src={dossier.townHeritage.townSlug === 'newark' ? '/cities/newark/local-4.jpg' : `/cities/${dossier.townHeritage.townSlug}/2.jpg`}
                      alt={`${dossier.townHeritage.townName}, ${dossier.townHeritage.state}`}
                      width={480}
                      height={270}
                      loading="eager"
                      className="h-full w-full object-cover"
                    />
                    <span className="absolute bottom-2.5 right-2.5 rounded-md border border-black/85 bg-[#080b10]/90 px-2 py-0.5 font-mono text-[9px] font-bold uppercase text-emerald-300">
                      ● {dossier.townHeritage.townName} Home Base
                    </span>
                  </div>
                </div>

                <div className="p-5 sm:p-6">
                  <p className="font-mono text-xs uppercase tracking-[0.16em] text-brand-accent">
                    Simple Hourly Estimate
                  </p>
                  <div className="mt-2 flex items-baseline gap-2.5">
                    <span className="font-display text-4xl sm:text-5xl font-extrabold text-brand-ink">
                      ${calcTotalUsd}
                    </span>
                    <span className="font-mono text-xs text-brand-mute">
                      ({calcCrew} {calcCrew === 1 ? 'worker' : 'workers'} × {calcHours} hrs @ ${calcRatePerPerson}/hr)
                    </span>
                  </div>

                  {/* Simple Crew & Hours Selector */}
                  <div className="mt-4 grid grid-cols-2 gap-3 rounded-xl border border-black/85 bg-[#080b12]/90 p-3.5 shadow-inner">
                    <div>
                      <span className="font-mono text-[10px] uppercase tracking-wider text-brand-mute block mb-1.5">
                        Workers ({calcCrew})
                      </span>
                      <div className="grid grid-cols-4 gap-1.5">
                        {([1, 2, 3, 4] as const).map((n) => (
                          <button
                            key={n}
                            type="button"
                            onClick={() => setCalcCrew(n)}
                            className={`rounded-md border py-1.5 font-mono text-xs font-bold transition ${
                              calcCrew === n
                                ? 'border-brand-accent bg-brand-accent text-bg-primary shadow-sm'
                                : 'border-black/85 bg-[#0c1017] text-brand-ink hover:border-brand-accent'
                            }`}
                          >
                            {n}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <span className="font-mono text-[10px] uppercase tracking-wider text-brand-mute block mb-1.5">
                        Hours ({calcHours}h)
                      </span>
                      <div className="grid grid-cols-4 gap-1.5">
                        {[1, 2, 3, 4].map((h) => (
                          <button
                            key={h}
                            type="button"
                            onClick={() => setCalcHours(h)}
                            className={`rounded-md border py-1.5 font-mono text-xs font-bold transition ${
                              calcHours === h
                                ? 'border-brand-accent bg-brand-accent text-bg-primary shadow-sm'
                                : 'border-black/85 bg-[#0c1017] text-brand-ink hover:border-brand-accent'
                            }`}
                          >
                            {h}h
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <ul className="mt-4 space-y-2 text-xs sm:text-sm text-brand-mute border-t border-white/10 pt-3.5">
                    {isPowerWash ? (
                      <>
                        <li>✓ <strong className="text-brand-ink">Free 2ft × 2ft sample spot</strong> washed first</li>
                        <li>✓ <strong className="text-brand-ink">Washer, surface cleaner &amp; soap</strong> included ($0)</li>
                      </>
                    ) : (
                      <>
                        <li>✓ <strong className="text-brand-ink">Flat $50/hr per worker</strong> (1-hr minimum)</li>
                        <li>✓ <strong className="text-brand-ink">All dollies, pads &amp; tools</strong> included ($0)</li>
                      </>
                    )}
                    <li>✓ <strong className="text-brand-ink">15-minute increments</strong> ($12.50) after hour 1</li>
                    <li>✓ <strong className="text-brand-ink">$0 travel fee</strong> anywhere in {dossier.townHeritage.townName}</li>
                  </ul>

                  <div className="mt-5 flex flex-col gap-2.5">
                    <a
                      href="https://bricklabor.com/book"
                      data-testid="hero-primary-book-cta"
                      className="btn btn-primary btn-arrow w-full text-center"
                    >
                      <span>
                        {isPowerWash
                          ? `Book Free Sample + ${calcHours}-Hr Wash ($${calcTotalUsd})`
                          : `Book ${calcCrew} Crew × ${calcHours} Hrs ($${calcTotalUsd})`}
                      </span>
                      <span data-btn-arrow aria-hidden="true">→</span>
                    </a>
                    <div className="grid grid-cols-2 gap-2.5">
                      <a
                        href={calcBookUrl}
                        data-testid="calculator-book-cta"
                        className="rounded-xl border border-brand-accent/40 bg-brand-accent/10 px-3 py-2 text-center font-mono text-[11px] font-bold text-brand-accent hover:bg-brand-accent/20 transition-colors"
                      >
                        Pre-Filled Form →
                      </a>
                      <a
                        href={PHONE_TEL_HREF}
                        className="rounded-xl border border-black/85 bg-[#080b12] px-3 py-2 text-center font-mono text-[11px] font-bold text-brand-ink shadow-inner hover:border-brand-accent transition-colors"
                      >
                        Call {PHONE_DISPLAY}
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </aside>
          </div>
        </div>
      </section>

      {/* ═══════════════════════════════════════════════════════════════════════
          MAIN GUIDE BODY: AUDIO BRIEFING + 2,300-WORD MARKDOWN-TO-HTML GUIDE + FAQ
          ═══════════════════════════════════════════════════════════════════════ */}
      <section className="pt-8 pb-16 sm:pt-11 sm:pb-24">
        <div className="container-pad">
          {/* 1. Spoken-Voice Audio Briefing Player Right Below ATF Hero */}
          <FieldServicePodcastPlayer
            episode={dossier.podcast}
            bookingUrl="https://bricklabor.com/book"
          />

          {/* 2. Sizable 2,300+ Word Plain-English Markdown Guide Rendered as Beautiful HTML (.prose-bcl) With Large Inline Newark Photos */}
          <MarkdownGuideArticle
            dossier={dossier}
            page={page}
            isPowerWash={isPowerWash}
            estimatedTotalUsd={est.estimatedTotalUsd}
            bookingUrl="https://bricklabor.com/book"
          />

          {/* 3. Comprehensive Keyword-Aligned Frequently Asked Questions (>= 5 FAQs) */}
          <section
            id="guide-faq-section"
            data-testid="tt-comprehensive-faq-accordion"
            aria-label={`Frequently Asked Questions about ${displayTitle}`}
            className="mt-12 mb-12 border-t border-white/10 pt-10"
          >
            <div className="w-full">
              <div className="mb-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
                <div className="max-w-3xl">
                  <p className="font-mono text-xs uppercase tracking-[0.16em] text-brand-accent mb-1.5">
                    {dossier.townHeritage.townName}, {dossier.townHeritage.state} Homeowner FAQ
                  </p>
                  <h2 className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight text-brand-ink">
                    Frequently Asked Questions ({displayFaqs.length})
                  </h2>
                  <p className="mt-2 text-sm sm:text-base text-brand-mute leading-relaxed">
                    Direct answers about our free 2ft × 2ft test spot, 500 PSI historic brick soft-washing, 16-inch rotary concrete cleaning, and $50/hr rate in {dossier.townHeritage.townName}, {dossier.townHeritage.state}.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setAllFaqsOpen((prev) => (prev === true ? false : true))}
                  className="shrink-0 self-start sm:self-auto rounded-xl border border-black/85 bg-[#0c1017] px-3.5 py-2 font-mono text-xs font-bold text-brand-accent shadow-md hover:border-brand-accent transition"
                >
                  {allFaqsOpen === true ? 'Collapse All FAQs' : `Expand All (${displayFaqs.length})`}
                </button>
              </div>
              <div className="space-y-3">
                {displayFaqs.map((faq, idx) => (
                  <details
                    key={faq.q}
                    data-testid="faq-accordion-item"
                    className="group rounded-2xl border border-black/85 bg-[#0c1017] px-6 py-4 sm:px-7 sm:py-5 shadow-[0_18px_42px_-18px_rgba(0,0,0,0.9),0_0_0_1px_rgba(0,0,0,0.88),inset_0_1px_0_rgba(255,255,255,0.03)] transition-colors open:border-brand-accent/50 hover:border-brand-accent/40"
                    open={allFaqsOpen !== null ? allFaqsOpen : idx < 2}
                  >
                    <summary className="flex cursor-pointer list-none items-center justify-between gap-6 font-display text-base sm:text-lg font-bold text-brand-ink hover:text-brand-accent transition">
                      <span>{faq.q}</span>
                      <span className="shrink-0 font-mono text-base text-brand-accent transition-transform group-open:rotate-45">
                        +
                      </span>
                    </summary>
                    <div className="mt-3 max-w-4xl border-t border-black/80 pt-3 pr-4 text-sm sm:text-[1.01rem] text-brand-mute leading-[1.75]">
                      {faq.a}
                    </div>
                  </details>
                ))}
              </div>
            </div>
          </section>

          {/* 4. Universal Collapsed-by-Default Gorgeous Citations & Reference Table [1–8] */}
          <CollapsibleCitationsDrawer
            references={dossier.references}
            townName={dossier.townHeritage.townName}
            bookingUrl="https://bricklabor.com/book"
          />

          {/* Related Guides Footer Strip */}
          {siblings.length > 0 && (
            <div className="mt-10 pt-8 border-t border-white/10">
              <span className="block mb-4 font-mono text-xs uppercase tracking-[0.16em] text-brand-accent">
                Related Guides in {page.dimensionLabel}:
              </span>
              <div className="grid gap-3.5 sm:grid-cols-2">
                {siblings.map((sib) => {
                  const sibEst = computeMatrixPageEstimate(sib);
                  return (
                    <a
                      key={sib.slug}
                      href={lp(`/for/${sib.slug}`)}
                      className="flex items-center justify-between gap-3 rounded-2xl border border-black/85 bg-[#0c1017] px-5 py-4 text-xs sm:text-[13.5px] font-medium text-brand-mute shadow-[0_18px_40px_-16px_rgba(0,0,0,0.88),0_0_0_1px_rgba(0,0,0,0.88),inset_0_1px_0_rgba(255,255,255,0.03)] hover:border-brand-accent hover:text-brand-ink transition-colors"
                    >
                      <span className="leading-snug font-semibold text-brand-ink/90">{sib.title}</span>
                      <span className="shrink-0 inline-flex items-center gap-1.5 rounded-full border border-black/85 bg-[#080b12] px-2.5 py-1 font-mono text-[11px] font-bold text-brand-accent">
                        <span>${sibEst.estimatedTotalUsd}</span>
                        <span aria-hidden="true">→</span>
                      </span>
                    </a>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

export default LandingMatrixPage;
