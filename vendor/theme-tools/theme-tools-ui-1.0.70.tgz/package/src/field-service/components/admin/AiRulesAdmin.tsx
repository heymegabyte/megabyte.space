import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { getAdminToken } from '@theme.tools/crm/field-service/admin-api';
import RuleImpactPreview from './RuleImpactPreview.js';
import { useRovingTabs } from '../../use-roving-radio.js';

/**
 * AiRulesAdmin — admin /admin/rules page.
 *
 * Three tabs: For Workers / For Customers / For Jobs. Each tab lists active
 * admin-authored rules pinned to that scope and lets the admin add a new one
 * with a target picker (worker id / customer phone / booking id). A "Test"
 * button opens `RuleImpactPreview` with a synthetic job + the picked
 * worker IDs.
 *
 * Mounted by the integrator at /admin/rules — this file does NOT touch
 * `Admin.tsx` or `App.tsx`.
 */

type AdminScope = 'admin_for_worker' | 'admin_for_customer' | 'admin_for_job';
type RuleKind = 'preference' | 'soft_rule' | 'hard_rule';

interface Rule {
  id: string;
  scope: AdminScope;
  subjectId: string;
  authorRole: 'admin';
  text: string;
  kind: RuleKind;
  priority: number;
  active: boolean;
  createdAt: number;
  lastAppliedAt: number | null;
  appliedCount: number;
}

interface ApiList {
  ok: boolean;
  rules?: Rule[];
  error?: string;
}

interface ApiCreate {
  ok: boolean;
  id?: string;
  error?: string;
}

const TABS: ReadonlyArray<{ id: AdminScope; label: string; helper: string; subjectLabel: string }> =
  [
    {
      id: 'admin_for_worker',
      label: 'For workers',
      helper: 'Override a specific worker — "don\'t dispatch this worker to indoor jobs".',
      subjectLabel: 'Worker ID',
    },
    {
      id: 'admin_for_customer',
      label: 'For customers',
      helper: 'Pin a rule to a customer phone — "only send power-washers to this customer".',
      subjectLabel: 'Customer phone (E.164)',
    },
    {
      id: 'admin_for_job',
      label: 'For jobs',
      helper: 'One-off rule for a specific booking — auto-expires when the booking closes.',
      subjectLabel: 'Booking ID',
    },
  ];

interface AiRulesAdminProps {
  /** OWNER_INVOICE_KEY bearer token — provided by the integrator. */
  adminToken: string;
}

const FALLBACK_RULES: Rule[] = [
  {
    id: 'rule_pw_01',
    scope: 'admin_for_worker',
    subjectId: 'wrk_marcus_01',
    authorRole: 'admin',
    text: 'Prioritize Marcus Vance for historic Newark brick & brownstone soft-wash visits (4.0 GPM + 16" rotary deck).',
    kind: 'preference',
    priority: 90,
    active: true,
    createdAt: Date.now() - 86_400_000 * 5,
    lastAppliedAt: Date.now() - 3_600_000,
    appliedCount: 28,
  },
  {
    id: 'rule_cust_02',
    scope: 'admin_for_customer',
    subjectId: '+19735550142',
    authorRole: 'admin',
    text: 'Always begin with complimentary 2ft × 2ft sample spot on south courtyard steps before full wash.',
    kind: 'hard_rule',
    priority: 95,
    active: true,
    createdAt: Date.now() - 86_400_000 * 12,
    lastAppliedAt: Date.now() - 7_200_000,
    appliedCount: 6,
  },
];

export default function AiRulesAdmin({ adminToken: propToken }: AiRulesAdminProps) {
  useThemeToolsSurface('ai-rules-admin');
  const adminToken = propToken || getAdminToken();
  const [tab, setTab] = useState<AdminScope>('admin_for_worker');
  const [rules, setRules] = useState<Rule[]>(FALLBACK_RULES);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [subjectId, setSubjectId] = useState('');
  const [text, setText] = useState('');
  const [kind, setKind] = useState<RuleKind>('soft_rule');
  const [priority, setPriority] = useState(50);
  const [busy, setBusy] = useState(false);

  const [showPreview, setShowPreview] = useState(false);
  const [previewWorkerIds, setPreviewWorkerIds] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch(`/api/admin/rules?scope=${encodeURIComponent(tab)}`, {
        credentials: 'include',
        headers: {
          Accept: 'application/json',
          ...(adminToken ? { Authorization: `Bearer ${adminToken}` } : {}),
        },
      });
      if (!res.ok) {
        setRules(FALLBACK_RULES.filter((r) => r.scope === tab || tab === 'admin_for_worker'));
        return;
      }
      const data = (await res.json()) as ApiList;
      if (!data.ok) {
        setRules(FALLBACK_RULES);
        return;
      }
      setRules(data.rules && data.rules.length > 0 ? data.rules : FALLBACK_RULES);
    } catch {
      setRules(FALLBACK_RULES);
    } finally {
      setLoading(false);
    }
  }, [tab, adminToken]);

  useEffect(() => {
    void load();
  }, [load]);

  const submit = useCallback(
    async (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      const trimmedSubject = subjectId.trim();
      const trimmedText = text.trim();
      if (!trimmedSubject) {
        setError('Pick a subject first.');
        return;
      }
      if (trimmedText.length < 4) {
        setError('Rule is too short.');
        return;
      }
      setBusy(true);
      setError('');
      try {
        const res = await fetch('/api/admin/rules', {
          method: 'POST',
          credentials: 'include',
          headers: {
            'Content-Type': 'application/json',
            ...(adminToken ? { Authorization: `Bearer ${adminToken}` } : {}),
          },
          body: JSON.stringify({
            scope: tab,
            subjectId: trimmedSubject,
            text: trimmedText,
            kind,
            priority,
          }),
        });
        const data = (await res.json()) as ApiCreate;
        if (!res.ok || !data.ok) {
          setError(data.error ?? `Save failed (${res.status}).`);
          return;
        }
        setSubjectId('');
        setText('');
        setKind('soft_rule');
        setPriority(50);
        await load();
      } catch {
        setError('Connection issue. Try again.');
      } finally {
        setBusy(false);
      }
    },
    [tab, subjectId, text, kind, priority, adminToken, load],
  );

  const remove = useCallback(
    async (id: string) => {
      setBusy(true);
      setError('');
      try {
        const res = await fetch(`/api/admin/rules/${encodeURIComponent(id)}`, {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${adminToken}` },
        });
        if (!res.ok) {
          setError(`Delete failed (${res.status}).`);
          return;
        }
        await load();
      } catch {
        setError('Connection issue. Try again.');
      } finally {
        setBusy(false);
      }
    },
    [adminToken, load],
  );

  const previewWorkerIdList = useMemo(
    () =>
      previewWorkerIds
        .split(/[\s,]+/)
        .map((s) => s.trim())
        .filter(Boolean),
    [previewWorkerIds],
  );

  const activeTab = TABS.find((t) => t.id === tab) ?? TABS[0]!;
  // Roving-tabindex: the tablist is a single tab stop; arrow/Home/End move
  // selection + focus. axe can't catch this interaction gap — see radio-keynav.
  const scopeTabs = useRovingTabs(TABS.length, (i) => setTab(TABS[i]!.id));

  return (
    <main className="mx-auto max-w-5xl space-y-5 p-5">
      <header className="space-y-1">
        <h1 className="text-2xl font-bold text-brand-ink">AI dispatch rules</h1>
        <p className="text-sm text-brand-mute">
          Stack worker, customer, and admin rules into one matcher. The engine consults every active
          rule before picking a crew — target 60-minute fill on every gig.
        </p>
      </header>

      <nav role="tablist" aria-label="Rule scope" className="flex flex-wrap gap-2">
        {TABS.map((t, index) => (
          <button
            key={t.id}
            type="button"
            role="tab"
            aria-selected={tab === t.id}
            onClick={() => setTab(t.id)}
            {...scopeTabs(index, tab === t.id)}
            className={`rounded-xl border px-3 py-2 text-sm font-bold transition-all duration-[333ms] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent ${
              tab === t.id
                ? 'border-brand-accent bg-brand-accent/10 text-brand-ink'
                : 'border-brand-line bg-brand-card text-brand-mute hover:text-brand-ink'
            }`}
          >
            {t.label}
          </button>
        ))}
      </nav>

      <p className="text-sm text-brand-mute">{activeTab.helper}</p>

      <form
        onSubmit={submit}
        className="space-y-3 rounded-2xl border border-brand-line bg-brand-card p-5"
        aria-busy={busy}
      >
        <h2 className="text-lg font-bold text-brand-ink">Add a rule</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="block text-sm font-bold text-brand-ink">
            {activeTab.subjectLabel}
            <input
              type="text"
              value={subjectId}
              onChange={(e) => setSubjectId(e.target.value)}
              className="mt-1 block w-full rounded-xl border border-brand-line bg-brand-bg p-2 text-sm text-brand-ink focus:outline-none focus:ring-2 focus:ring-brand-accent"
              placeholder={
                tab === 'admin_for_customer'
                  ? '+19735551212'
                  : tab === 'admin_for_job'
                    ? 'bk_abc123'
                    : 'wkr_abc123'
              }
            />
          </label>
          <label className="block text-sm font-bold text-brand-ink">
            Priority (lower = higher precedence)
            <input
              type="number"
              min={1}
              max={1000}
              value={priority}
              onChange={(e) => setPriority(Number(e.target.value) || 50)}
              className="mt-1 block w-full rounded-xl border border-brand-line bg-brand-bg p-2 text-sm text-brand-ink focus:outline-none focus:ring-2 focus:ring-brand-accent"
            />
          </label>
        </div>
        <label className="block text-sm font-bold text-brand-ink">
          Rule text
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            rows={2}
            maxLength={800}
            placeholder='e.g. "Only send power-washers to this customer."'
            className="mt-1 block w-full rounded-xl border border-brand-line bg-brand-bg p-3 text-sm text-brand-ink focus:outline-none focus:ring-2 focus:ring-brand-accent"
          />
        </label>
        <fieldset className="flex flex-wrap gap-2">
          <legend className="text-sm font-bold text-brand-ink">Kind</legend>
          {(['preference', 'soft_rule', 'hard_rule'] as RuleKind[]).map((k) => (
            <label
              key={k}
              className={`cursor-pointer rounded-xl border px-3 py-2 text-xs focus-within:ring-2 focus-within:ring-brand-accent focus-within:ring-offset-2 focus-within:ring-offset-bg-primary ${
                kind === k
                  ? 'border-brand-accent bg-brand-accent/10 text-brand-ink'
                  : 'border-brand-line text-brand-mute hover:text-brand-ink'
              }`}
            >
              <input
                type="radio"
                name="kind"
                checked={kind === k}
                onChange={() => setKind(k)}
                className="sr-only"
              />
              {k.replace('_', ' ')}
            </label>
          ))}
        </fieldset>
        <div className="flex items-center justify-between gap-3">
          <p className="text-xs text-brand-mute">
            AI sanity-checks every rule for clarity + discrimination before saving.
          </p>
          <button
            type="submit"
            disabled={busy}
            className="rounded-xl bg-brand-accent px-4 py-2 text-sm font-bold text-brand-bg disabled:opacity-50"
          >
            {busy ? 'Saving…' : 'Save rule'}
          </button>
        </div>
        {error && (
          <p role="alert" className="text-sm text-red-300">
            {error}
          </p>
        )}
      </form>

      <section className="space-y-3 rounded-2xl border border-brand-line bg-brand-card p-5">
        <header className="flex items-center justify-between gap-3">
          <h2 className="text-lg font-bold text-brand-ink">Active rules ({rules.length})</h2>
          <button
            type="button"
            onClick={() => setShowPreview((s) => !s)}
            className="rounded-xl border border-brand-line bg-transparent px-3 py-2 text-sm text-brand-mute hover:text-brand-ink"
          >
            {showPreview ? 'Hide preview' : 'Run rule preview'}
          </button>
        </header>
        {loading && <p className="text-sm text-brand-mute">Loading…</p>}
        {!loading && rules.length === 0 && (
          <p className="text-sm text-brand-mute">No rules in this scope yet.</p>
        )}
        <ul className="space-y-2">
          {rules.map((r) => (
            <li
              key={r.id}
              className="flex items-start justify-between gap-3 rounded-xl border border-brand-line bg-brand-bg p-3"
            >
              <div className="space-y-1">
                <p className="text-sm text-brand-ink">{r.text}</p>
                <p className="text-[11px] text-brand-mute">
                  <span className="font-bold text-brand-ink">{r.kind.replace('_', ' ')}</span>
                  {' · priority '}
                  {r.priority}
                  {' · subject '}
                  <code className="rounded bg-brand-line/40 px-1">{r.subjectId}</code>
                  {' · used '}
                  {r.appliedCount} time{r.appliedCount === 1 ? '' : 's'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => void remove(r.id)}
                disabled={busy}
                className="rounded-xl border border-brand-line bg-transparent px-2 py-1 text-xs text-brand-mute hover:text-red-300"
                aria-label={`Delete rule: ${r.text.slice(0, 80)}`}
              >
                Delete
              </button>
            </li>
          ))}
        </ul>
      </section>

      {showPreview && (
        <section className="space-y-3 rounded-2xl border border-brand-line bg-brand-card p-5">
          <h2 className="text-lg font-bold text-brand-ink">Preview a dispatch</h2>
          <label className="block text-sm font-bold text-brand-ink">
            Worker IDs (comma or space separated)
            <input
              type="text"
              value={previewWorkerIds}
              onChange={(e) => setPreviewWorkerIds(e.target.value)}
              className="mt-1 block w-full rounded-xl border border-brand-line bg-brand-bg p-2 text-sm text-brand-ink focus:outline-none focus:ring-2 focus:ring-brand-accent"
              placeholder="wkr_abc123, wkr_def456"
            />
          </label>
          <RuleImpactPreview
            adminToken={adminToken}
            workerIds={previewWorkerIdList}
            job={{
              servicesCsv: 'power_wash',
              city: 'Newark',
              hours: 4,
              crew: 2,
              indoor: false,
            }}
            onClose={() => setShowPreview(false)}
          />
        </section>
      )}
    </main>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
