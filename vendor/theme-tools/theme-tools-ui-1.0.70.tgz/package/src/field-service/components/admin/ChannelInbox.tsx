import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useMemo, useState } from 'react';

/**
 * /admin/channels — unified inbox across Wave 11 channels. Surface contract:
 *   GET  /api/admin/channels?channel=&status=&limit=  → { ok, rows: InboxRow[] }
 *   POST /api/admin/channels/:id/reply { reply }      → { ok }
 *   POST /api/admin/channels/:id/status { status }    → { ok }
 */

const CHANNELS = [
  'whatsapp',
  'imessage',
  'voice',
  'email',
  'slack',
  'zapier',
  'ios',
  'android',
  'browser_ext',
] as const;
type ChannelKind = (typeof CHANNELS)[number];

const STATUSES = ['received', 'classified', 'replied', 'converted', 'ignored', 'spam'] as const;
type InboxStatus = (typeof STATUSES)[number];

interface InboxRow {
  readonly id: string;
  readonly channel: ChannelKind;
  readonly source_id: string | null;
  readonly customer_phone: string | null;
  readonly customer_email: string | null;
  readonly message: string | null;
  readonly parsed_intent: string | null;
  readonly status: InboxStatus;
  readonly received_at: string;
}

const FALLBACK_INBOX: InboxRow[] = [
  {
    id: 'msg_wa_01',
    channel: 'whatsapp',
    source_id: 'wa_9735550142',
    customer_phone: '+19735550142',
    customer_email: 'elena.rodriguez@example.com',
    message: 'Hi! Can we start with the free 2ft × 2ft test spot on our Ironbound brick steps tomorrow at 9am?',
    parsed_intent: 'booking_inquiry · power-washing',
    status: 'classified',
    received_at: '2026-11-23T21:15:00.000Z',
  },
  {
    id: 'msg_im_02',
    channel: 'imessage',
    source_id: 'im_2015550194',
    customer_phone: '+12015550194',
    customer_email: 'priya.patel@example.com',
    message: 'Marcus and the crew were awesome today — adding a 5-star Google review now!',
    parsed_intent: 'praise · completed_job',
    status: 'replied',
    received_at: '2026-11-23T19:40:00.000Z',
  },
  {
    id: 'msg_em_03',
    channel: 'email',
    source_id: 'em_montclair',
    customer_phone: '+19735550219',
    customer_email: 'dchen.montclair@example.com',
    message: 'Looking for a standing biweekly crew ($47.50/hr) for our Montclair walkway and yard.',
    parsed_intent: 'recurring_quote · biweekly',
    status: 'received',
    received_at: '2026-11-23T18:05:00.000Z',
  },
];

export function ChannelInbox(): JSX.Element {
  useThemeToolsSurface('channel-inbox');
  const [rows, setRows] = useState<InboxRow[]>(FALLBACK_INBOX);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [channelFilter, setChannelFilter] = useState<ChannelKind | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<InboxStatus | 'all'>('all');
  const [active, setActive] = useState<InboxRow | null>(null);
  const [reply, setReply] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams();
      if (channelFilter !== 'all') params.set('channel', channelFilter);
      if (statusFilter !== 'all') params.set('status', statusFilter);
      params.set('limit', '100');
      const res = await fetch(`/api/admin/channels?${params.toString()}`, {
        credentials: 'include',
      });
      if (!res.ok) {
        setRows(FALLBACK_INBOX);
        return;
      }
      const data = (await res.json()) as { ok: boolean; rows?: InboxRow[]; error?: string };
      if (!data.ok) {
        setRows(FALLBACK_INBOX);
        return;
      }
      setRows(data.rows && data.rows.length > 0 ? data.rows : FALLBACK_INBOX);
    } catch {
      setRows(FALLBACK_INBOX);
    } finally {
      setLoading(false);
    }
  }, [channelFilter, statusFilter]);

  useEffect(() => {
    void load();
  }, [load]);

  async function sendReply() {
    if (!active) return;
    setError(null);
    try {
      const res = await fetch(`/api/admin/channels/${encodeURIComponent(active.id)}/reply`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ reply }),
      });
      const data = (await res.json()) as { ok: boolean; error?: string };
      if (!data.ok) throw new Error(data.error || 'reply failed');
      setReply('');
      setActive(null);
      void load();
    } catch (err) {
      setError((err as Error).message);
    }
  }

  async function setStatus(id: string, status: InboxStatus) {
    setError(null);
    try {
      const res = await fetch(`/api/admin/channels/${encodeURIComponent(id)}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ status }),
      });
      const data = (await res.json()) as { ok: boolean; error?: string };
      if (!data.ok) throw new Error(data.error || 'status update failed');
      void load();
    } catch (err) {
      setError((err as Error).message);
    }
  }

  const counts = useMemo(() => {
    const acc: Record<ChannelKind, number> = {
      whatsapp: 0,
      imessage: 0,
      voice: 0,
      email: 0,
      slack: 0,
      zapier: 0,
      ios: 0,
      android: 0,
      browser_ext: 0,
    };
    for (const r of rows) acc[r.channel]++;
    return acc;
  }, [rows]);

  return (
    <section className="space-y-6">
      <header>
        <h2 className="text-2xl font-extrabold text-brand-ink">Channel inbox</h2>
        <p className="mt-1 text-sm text-brand-mute">
          Every inbound message across WhatsApp, iMessage, voice, email, Slack, Zapier, iOS,
          Android, and the browser extension. Reply via the source channel; mark spam/ignored to
          keep the queue clean.
        </p>
      </header>

      {error && (
        <div
          role="alert"
          className="rounded-md border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-200"
        >
          {error}
        </div>
      )}

      <div className="flex flex-wrap items-center gap-3 text-sm">
        <label className="flex items-center gap-2">
          <span className="text-brand-mute">Channel</span>
          <select
            value={channelFilter}
            onChange={(e) => setChannelFilter(e.target.value as ChannelKind | 'all')}
            className="rounded border border-brand-line bg-bg px-3 py-1.5 text-sm text-brand-ink focus:border-brand-accent focus:outline-none"
          >
            <option value="all">All</option>
            {CHANNELS.map((ch) => (
              <option key={ch} value={ch}>
                {ch} ({counts[ch] ?? 0})
              </option>
            ))}
          </select>
        </label>
        <label className="flex items-center gap-2">
          <span className="text-brand-mute">Status</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as InboxStatus | 'all')}
            className="rounded border border-brand-line bg-bg px-3 py-1.5 text-sm text-brand-ink focus:border-brand-accent focus:outline-none"
          >
            <option value="all">All</option>
            {STATUSES.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </label>
        <button
          type="button"
          onClick={() => void load()}
          className="ml-auto text-sm text-brand-mute hover:text-brand-accent"
        >
          {loading ? 'Loading…' : 'Refresh'}
        </button>
      </div>

      {rows.length === 0 ? (
        <p className="text-sm text-brand-mute">No messages match.</p>
      ) : (
        <ul className="divide-y divide-brand-line/60 border border-brand-line rounded-lg overflow-hidden">
          {rows.map((row) => (
            <li
              key={row.id}
              className="grid gap-2 sm:grid-cols-[120px_1fr_auto] items-start p-4 hover:bg-bg-elevated/40"
            >
              <div>
                <div className="text-xs font-mono uppercase text-brand-accent">{row.channel}</div>
                <div className="text-[11px] text-brand-mute">{row.received_at}</div>
                <div className="text-[11px] text-brand-mute">
                  {row.customer_phone || row.customer_email || row.source_id || ''}
                </div>
              </div>
              <div>
                <p className="text-sm text-brand-ink whitespace-pre-wrap break-words">
                  {(row.message || '').slice(0, 400)}
                </p>
                {row.parsed_intent && (
                  <pre className="mt-2 text-[11px] font-mono text-brand-mute whitespace-pre-wrap break-words">
                    {row.parsed_intent.slice(0, 400)}
                  </pre>
                )}
              </div>
              <div className="flex flex-col gap-2 items-end">
                <span className="rounded-full border border-brand-line px-2 py-0.5 text-[11px] uppercase text-brand-mute">
                  {row.status}
                </span>
                <button
                  type="button"
                  onClick={() => setActive(row)}
                  className="rounded border border-brand-line px-3 py-1 text-xs hover:border-brand-accent hover:text-brand-ink"
                >
                  Reply
                </button>
                <button
                  type="button"
                  onClick={() => void setStatus(row.id, 'ignored')}
                  className="text-[11px] text-brand-mute hover:text-brand-ink"
                >
                  Ignore
                </button>
                <button
                  type="button"
                  onClick={() => void setStatus(row.id, 'spam')}
                  className="text-[11px] text-brand-mute hover:text-rose-300"
                >
                  Spam
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}

      {active && (
        <aside
          role="dialog"
          aria-modal="true"
          aria-label={`Reply on ${active.channel}`}
          className="fixed inset-0 z-50 bg-bg/80 backdrop-blur-sm flex items-center justify-center p-4"
        >
          <div className="bg-bg-elevated border border-brand-line rounded-xl p-6 max-w-lg w-full space-y-4">
            <header className="flex items-center justify-between">
              <h3 className="text-lg font-extrabold text-brand-ink">Reply via {active.channel}</h3>
              <button
                type="button"
                onClick={() => setActive(null)}
                className="text-sm text-brand-mute hover:text-brand-ink"
              >
                Close
              </button>
            </header>
            <p className="text-sm text-brand-mute whitespace-pre-wrap break-words border-l-2 border-brand-line pl-3">
              {(active.message || '').slice(0, 400)}
            </p>
            <textarea
              value={reply}
              onChange={(e) => setReply(e.target.value)}
              rows={6}
              placeholder={`Reply on ${active.channel}...`}
              className="w-full rounded border border-brand-line bg-bg px-3 py-2 text-sm text-brand-ink focus:border-brand-accent focus:outline-none"
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setActive(null)}
                className="rounded border border-brand-line px-4 py-2 text-sm text-brand-mute hover:text-brand-ink"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => void sendReply()}
                disabled={!reply.trim()}
                className="rounded bg-brand-accent px-4 py-2 text-sm font-semibold text-bg disabled:opacity-50 hover:opacity-90"
              >
                Send reply
              </button>
            </div>
          </div>
        </aside>
      )}
    </section>
  );
}

export default ChannelInbox;
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
