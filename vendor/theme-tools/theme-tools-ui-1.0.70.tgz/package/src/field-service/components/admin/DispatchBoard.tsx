import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useMemo, useState } from 'react';

/**
 * DispatchBoard — unassigned-gig dispatcher panel.
 *
 * Two-column layout:
 *   - Left: open/dispatched/partial gigs (from `/admin/entities/jobs?status=pending`)
 *   - Right: active workers (from `/admin/entities/workers?active=true`)
 *
 * Click a gig → click a crew → POST `/api/admin/dispatch/override` with the
 * canonical payload `{ gigId, workerId, reason, asShiftLead }`.
 *
 * When a gig is selected, fires `/api/ai/crew-match` with the gig's text and
 * highlights the top-2 returned workerIds with a cyan ring so the operator
 * can pick AI-recommended crew with one click.
 */

interface GigRow {
  id: string;
  customer_name: string | null;
  customer_phone: string | null;
  city: string | null;
  zip: string | null;
  preferred_date: string | null;
  preferred_time: string | null;
  services_csv: string | null;
  hours: number | null;
  crew: number | null;
}

interface WorkerRow {
  id: string;
  first_name: string;
  last_name: string;
  phone: string;
  tier: string;
  status: string;
  city: string | null;
  rating_avg: number | null;
  jobs_completed: number;
}

interface CrewMatch {
  workerId: string;
  score: number;
  topSkills: string[];
}

export function DispatchBoard({ bearer }: { bearer: string }) {
  useThemeToolsSurface('dispatch-board');
  const [gigs, setGigs] = useState<GigRow[]>([]);
  const [workers, setWorkers] = useState<WorkerRow[]>([]);
  const [pickedGig, setPickedGig] = useState<GigRow | null>(null);
  const [pickedWorker, setPickedWorker] = useState<WorkerRow | null>(null);
  const [matches, setMatches] = useState<CrewMatch[]>([]);
  const [reason, setReason] = useState('');
  const [status, setStatus] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const headers = useCallback(
    (): HeadersInit => ({
      'content-type': 'application/json',
      ...(bearer ? { authorization: `Bearer ${bearer}` } : {}),
    }),
    [bearer],
  );

  const refresh = useCallback(async () => {
    setLoading(true);
    setStatus('');
    try {
      const [jobsRes, workersRes] = await Promise.all([
        fetch('/admin/entities/jobs?status=pending&limit=50', {
          headers: headers(),
          credentials: 'include',
        }),
        fetch('/admin/entities/workers?active=true&limit=100', {
          headers: headers(),
          credentials: 'include',
        }),
      ]);
      const jobsJson = (await jobsRes.json()) as { ok: boolean; jobs?: GigRow[]; error?: string };
      const workersJson = (await workersRes.json()) as {
        ok: boolean;
        workers?: WorkerRow[];
        error?: string;
      };
      if (!jobsRes.ok || !jobsJson.ok) {
        setStatus(jobsJson.error ?? `Jobs HTTP ${jobsRes.status}`);
      }
      setGigs(jobsJson.jobs ?? []);
      setWorkers(workersJson.workers ?? []);
    } catch (err) {
      setStatus((err as Error).message);
    } finally {
      setLoading(false);
    }
  }, [headers]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  // When a gig is picked, ask the AI matcher for the top crews.
  useEffect(() => {
    if (!pickedGig) {
      setMatches([]);
      return;
    }
    let cancelled = false;
    void (async () => {
      const jobText = [
        pickedGig.services_csv ?? '',
        pickedGig.city ?? '',
        `${pickedGig.hours ?? 2}h job for ${pickedGig.customer_name ?? 'customer'}`,
      ]
        .filter(Boolean)
        .join(' — ');
      try {
        const res = await fetch('/api/ai/crew-match', {
          method: 'POST',
          credentials: 'include',
          headers: headers(),
          body: JSON.stringify({ jobText, topK: 5, city: pickedGig.city ?? undefined }),
        });
        const json = (await res.json()) as { ok: boolean; matches?: CrewMatch[] };
        if (!cancelled && json.ok) setMatches(json.matches ?? []);
      } catch {
        /* silently ignore — highlight ring is decorative */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [pickedGig, headers]);

  const aiTop2 = useMemo(() => new Set(matches.slice(0, 2).map((m) => m.workerId)), [matches]);

  async function assign() {
    if (!pickedGig || !pickedWorker) return setStatus('Pick a gig and a crew first.');
    if (reason.trim().length < 3) return setStatus('Add a one-line reason.');
    setSubmitting(true);
    setStatus('');
    try {
      const res = await fetch('/api/admin/dispatch/override', {
        method: 'POST',
        credentials: 'include',
        headers: headers(),
        body: JSON.stringify({
          gigId: pickedGig.id,
          workerId: pickedWorker.id,
          reason: reason.trim(),
          asShiftLead: false,
        }),
      });
      const json = (await res.json()) as { ok: boolean; error?: string };
      if (!res.ok || !json.ok) {
        setStatus(json.error ?? `Failed: ${res.status}`);
      } else {
        setStatus(`Assigned ${pickedWorker.first_name} → gig ${pickedGig.id.slice(0, 8)}…`);
        setPickedGig(null);
        setPickedWorker(null);
        setReason('');
        void refresh();
      }
    } catch (err) {
      setStatus((err as Error).message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <section className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-brand-ink">Dispatch board</h2>
          <p className="mt-1 text-sm text-brand-mute">
            Pick an open gig + a crew → assign. AI-suggested top-2 ring highlight.
          </p>
        </div>
        <button
          type="button"
          onClick={() => void refresh()}
          disabled={loading}
          className="rounded-md border border-brand-line bg-bg-primary px-3 py-1.5 text-xs text-brand-ink hover:border-brand-accent disabled:opacity-50"
        >
          {loading ? 'Loading…' : 'Refresh'}
        </button>
      </div>

      <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-2">
        <div>
          <p className="mb-2 font-mono text-[10px] uppercase tracking-widest text-brand-mute">
            Unassigned gigs ({gigs.length})
          </p>
          {gigs.length === 0 ? (
            <p className="rounded-md border border-dashed border-brand-line p-4 text-sm text-brand-mute">
              No pending gigs. New paid bookings appear here.
            </p>
          ) : (
            <ul className="space-y-2">
              {gigs.map((g) => {
                const picked = pickedGig?.id === g.id;
                return (
                  <li key={g.id}>
                    <button
                      type="button"
                      onClick={() => setPickedGig(picked ? null : g)}
                      className={`w-full rounded-md border px-3 py-2 text-left text-sm transition ${
                        picked
                          ? 'border-brand-accent bg-brand-accent/10 text-brand-ink'
                          : 'border-brand-line bg-bg-primary text-brand-ink hover:border-brand-accent'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold">{g.customer_name ?? 'Customer'}</span>
                        <span className="font-mono text-[10px] text-brand-mute">
                          {g.preferred_date} {g.preferred_time}
                        </span>
                      </div>
                      <p className="mt-0.5 text-xs text-brand-mute">
                        {g.city ?? '—'} · {g.services_csv ?? 'services tbd'} · {g.hours ?? 2}h ·
                        crew {g.crew ?? 1}
                      </p>
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        <div>
          <p className="mb-2 font-mono text-[10px] uppercase tracking-widest text-brand-mute">
            Available crew ({workers.length})
          </p>
          {workers.length === 0 ? (
            <p className="rounded-md border border-dashed border-brand-line p-4 text-sm text-brand-mute">
              No active crew. Onboard a worker first.
            </p>
          ) : (
            <ul className="max-h-96 space-y-2 overflow-y-auto pr-1">
              {workers.map((w) => {
                const picked = pickedWorker?.id === w.id;
                const aiPick = aiTop2.has(w.id);
                return (
                  <li key={w.id}>
                    <button
                      type="button"
                      onClick={() => setPickedWorker(picked ? null : w)}
                      className={`w-full rounded-md border px-3 py-2 text-left text-sm transition ${
                        picked
                          ? 'border-brand-accent bg-brand-accent/10 text-brand-ink'
                          : aiPick
                            ? 'border-brand-line bg-bg-primary text-brand-ink ring-2 ring-brand-accent/60 hover:border-brand-accent'
                            : 'border-brand-line bg-bg-primary text-brand-ink hover:border-brand-accent'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold">
                          {w.first_name} {w.last_name}
                          {aiPick && (
                            <span className="ml-2 font-mono text-[9px] uppercase tracking-widest text-brand-accent">
                              AI pick
                            </span>
                          )}
                        </span>
                        <span className="font-mono text-[10px] text-brand-mute">{w.tier}</span>
                      </div>
                      <p className="mt-0.5 text-xs text-brand-mute">
                        {w.city ?? '—'} · {w.jobs_completed} jobs ·{' '}
                        {w.rating_avg != null ? `${w.rating_avg.toFixed(1)}★` : 'no rating'}
                      </p>
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </div>

      {(pickedGig || pickedWorker) && (
        <div className="mt-4 rounded-md border border-brand-line bg-bg-primary p-3">
          <p className="mb-2 font-mono text-[10px] uppercase tracking-widest text-brand-mute">
            Assignment
          </p>
          <p className="text-sm text-brand-ink">
            {pickedGig ? `Gig: ${pickedGig.id.slice(0, 12)}…` : '(no gig)'} →{' '}
            {pickedWorker ? `${pickedWorker.first_name} ${pickedWorker.last_name}` : '(no crew)'}
          </p>
          <input
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="one-line reason (e.g. regular customer requested)"
            className="mt-2 w-full rounded-md border border-brand-line bg-bg-elevated px-3 py-2 text-sm text-brand-ink"
          />
          <button
            type="button"
            onClick={() => void assign()}
            disabled={submitting || !pickedGig || !pickedWorker}
            className="mt-2 rounded-md bg-brand-accent px-3 py-2 text-sm font-semibold text-black hover:brightness-110 disabled:opacity-50"
          >
            {submitting ? 'Assigning…' : 'Assign'}
          </button>
        </div>
      )}
      {status && <p className="mt-3 text-xs text-brand-mute">{status}</p>}
    </section>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
