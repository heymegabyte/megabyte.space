import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { useEffect, useState } from 'react';

interface Dispute {
  id: string;
  gig_id: string | null;
  worker_id: string | null;
  booking_id: string | null;
  kind: string;
  severity: string;
  reported_by: string;
  body: string | null;
  status: string;
  created_at: string;
}

interface ApiResponse {
  ok: true;
  disputes: Dispute[];
}

const SEVERITY_TONE: Record<string, string> = {
  critical: 'border-red-500/50 bg-red-500/10',
  high: 'border-amber-500/50 bg-amber-500/10',
  medium: 'border-amber-400/30 bg-amber-400/5',
  low: 'border-white/10 bg-white/[0.02]',
};

export function DisputeQueue({ headers }: { headers: HeadersInit }) {
  useThemeToolsSurface('dispute-queue');
  const [rows, setRows] = useState<Dispute[]>([]);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    let cancelled = false;
    fetch('/api/admin/disputes/queue', { headers, credentials: 'include' })
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error(`status_${r.status}`))))
      .then((json: ApiResponse) => {
        if (!cancelled) setRows(json.disputes ?? []);
      })
      .catch(() => {
        if (!cancelled) {
          setRows([]);
          setError('');
        }
      });
    return () => {
      cancelled = true;
    };
  }, [headers]);

  if (error) return <p className="text-sm text-red-300">{error}</p>;
  if (rows.length === 0) {
    return <p className="text-brand-mute text-sm">No open disputes. Quiet day.</p>;
  }

  return (
    <ul className="space-y-3" data-testid="dispute-queue">
      {rows.map((d) => (
        <li
          key={d.id}
          className={['rounded-lg border p-3', SEVERITY_TONE[d.severity] ?? SEVERITY_TONE.low].join(
            ' ',
          )}
        >
          <div className="mb-1 flex flex-wrap items-center gap-2 text-xs">
            <span className="rounded bg-white/10 px-1.5 py-0.5 uppercase">{d.kind}</span>
            <span className="rounded bg-white/10 px-1.5 py-0.5 uppercase">{d.severity}</span>
            <span className="rounded bg-white/10 px-1.5 py-0.5 uppercase">{d.status}</span>
            <span className="text-brand-mute">reported by {d.reported_by}</span>
            <span className="text-brand-mute ml-auto">
              {new Date(d.created_at).toLocaleString()}
            </span>
          </div>
          <p className="text-sm">{d.body ?? '(no narrative)'}</p>
          <div className="text-brand-mute mt-1 font-mono text-[10px]">
            {d.booking_id && <>booking:{d.booking_id} </>}
            {d.gig_id && <>gig:{d.gig_id} </>}
            {d.worker_id && <>worker:{d.worker_id}</>}
          </div>
        </li>
      ))}
    </ul>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
