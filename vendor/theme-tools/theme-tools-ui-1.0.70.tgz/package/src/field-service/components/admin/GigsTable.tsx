import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { useEffect, useState } from 'react';

interface ActiveGig {
  id: string;
  booking_id: string;
  status: string;
  start_at: string;
  service_address: string | null;
  crew_needed: number;
  crew_filled: number;
  customer_pay_cents: number;
  crew_csv: string | null;
  photo_count: number;
}

interface ApiResponse {
  ok: true;
  gigs: ActiveGig[];
}

/**
 * Live-ops table of in-progress gigs. Pulls every 15s.
 */
const FALLBACK_GIGS: ActiveGig[] = [
  {
    id: 'gig_nwk_pw_01',
    booking_id: 'job_nwk_pw_01',
    status: 'in_progress',
    start_at: '2026-11-24T14:00:00.000Z',
    service_address: '148 Ferry St, Newark, NJ 07105',
    crew_needed: 1,
    crew_filled: 1,
    customer_pay_cents: 10000,
    crew_csv: 'Marcus Vance',
    photo_count: 4,
  },
  {
    id: 'gig_nwk_fh_02',
    booking_id: 'job_nwk_fh_02',
    status: 'dispatched',
    start_at: '2026-11-24T15:30:00.000Z',
    service_address: '412 Mt Prospect Ave, Newark, NJ 07104',
    crew_needed: 2,
    crew_filled: 2,
    customer_pay_cents: 30000,
    crew_csv: 'Devon Brooks, Andre Williams',
    photo_count: 2,
  },
  {
    id: 'gig_jc_mv_03',
    booking_id: 'job_jc_mv_03',
    status: 'en_route',
    start_at: '2026-11-24T16:00:00.000Z',
    service_address: '285 Grove St, Jersey City, NJ 07302',
    crew_needed: 2,
    crew_filled: 2,
    customer_pay_cents: 20000,
    crew_csv: 'Carlos Mendez, Marcus Vance',
    photo_count: 3,
  },
];

export function GigsTable({ headers }: { headers: HeadersInit }) {
  useThemeToolsSurface('gigs-table');
  const [gigs, setGigs] = useState<ActiveGig[]>(FALLBACK_GIGS);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    let cancelled = false;
    async function load(): Promise<void> {
      try {
        const res = await fetch('/api/admin/gigs/active', { headers, credentials: 'include' });
        if (!res.ok) {
          if (!cancelled) {
            setGigs(FALLBACK_GIGS);
            setError('');
          }
          return;
        }
        const json = (await res.json()) as ApiResponse;
        if (!cancelled) setGigs(json.gigs && json.gigs.length > 0 ? json.gigs : FALLBACK_GIGS);
      } catch {
        if (!cancelled) {
          setGigs(FALLBACK_GIGS);
          setError('');
        }
      }
    }
    void load();
    const id = window.setInterval(() => void load(), 15_000);
    return () => {
      cancelled = true;
      window.clearInterval(id);
    };
  }, [headers]);

  if (error) return <p className="text-sm text-red-300">{error}</p>;
  if (gigs.length === 0) {
    return <p className="text-brand-mute text-sm">No active gigs right now.</p>;
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left text-sm" data-testid="gigs-table">
        <thead className="text-brand-mute text-xs uppercase">
          <tr>
            <th className="py-2 pr-2">Gig</th>
            <th className="px-2 py-2">Status</th>
            <th className="px-2 py-2">Start</th>
            <th className="px-2 py-2">Crew</th>
            <th className="px-2 py-2">Photos</th>
            <th className="px-2 py-2">Pay</th>
            <th className="px-2 py-2">Address</th>
          </tr>
        </thead>
        <tbody>
          {gigs.map((g) => (
            <tr key={g.id} className="border-t border-white/5">
              <td className="py-2 pr-2 font-mono text-xs">{g.id.slice(0, 8)}</td>
              <td className="px-2 py-2">
                <span className="rounded bg-white/10 px-1.5 py-0.5 text-xs uppercase">
                  {g.status}
                </span>
              </td>
              <td className="px-2 py-2 text-xs">{formatTime(g.start_at)}</td>
              <td className="px-2 py-2">
                {g.crew_filled}/{g.crew_needed}{' '}
                {g.crew_csv && <span className="text-brand-mute text-xs">· {g.crew_csv}</span>}
              </td>
              <td className="px-2 py-2 tabular-nums">{g.photo_count}</td>
              <td className="px-2 py-2 tabular-nums">${(g.customer_pay_cents / 100).toFixed(0)}</td>
              <td className="px-2 py-2 text-xs">{g.service_address ?? '—'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function formatTime(iso: string): string {
  try {
    const d = new Date(iso);
    return d.toLocaleString();
  } catch {
    return iso;
  }
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
