import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useMemo, useState } from 'react';

/**
 * HeatmapCalendar — 30-day booking density grid (GitHub-style).
 *
 * Pulls the admin dashboard feed (`/api/dashboard/feed`) and the today
 * snapshot (`/api/admin/today`), buckets booking events into 30 daily counts,
 * and renders a 5-row × 7-column heatmap where each cell is shaded with the
 * brand accent at an opacity proportional to that day's count. Hover any
 * cell for a date + count tooltip. A "less / more" legend sits below the
 * grid for orientation.
 */

interface FeedEvent {
  id: string;
  kind: string;
  at: string;
}

interface DayCell {
  iso: string;
  date: Date;
  count: number;
  weekday: number;
}

interface TodaySnapshot {
  openGigs: number;
  pendingPayments: number;
  revenueTodayCents: number;
}

function isoDay(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
    d.getDate(),
  ).padStart(2, '0')}`;
}

function fmtDate(d: Date): string {
  return d.toLocaleDateString(undefined, {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });
}

export function HeatmapCalendar({ bearer }: { bearer: string }) {
  useThemeToolsSurface('heatmap-calendar');
  const [cells, setCells] = useState<DayCell[]>([]);
  const [today, setToday] = useState<TodaySnapshot | null>(null);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState('');

  const headers = useCallback(
    (): HeadersInit => ({
      'content-type': 'application/json',
      authorization: `Bearer ${bearer}`,
    }),
    [bearer],
  );

  const load = useCallback(async () => {
    if (!bearer) return;
    setLoading(true);
    setStatus('');
    try {
      const [feedRes, todayRes] = await Promise.all([
        fetch('/api/dashboard/feed', { headers: headers() }),
        fetch('/api/admin/today', { headers: headers() }),
      ]);
      const feedJson = (await feedRes.json()) as {
        ok: boolean;
        events?: FeedEvent[];
        error?: string;
      };
      const todayJson = (await todayRes.json()) as {
        ok: boolean;
        today?: {
          openGigs: number;
          pendingPayments: number;
          revenueTodayCents: number;
        };
        error?: string;
      };
      if (!feedRes.ok || !feedJson.ok) {
        setStatus(feedJson.error ?? `Feed HTTP ${feedRes.status}`);
      }
      if (todayRes.ok && todayJson.ok && todayJson.today) {
        setToday({
          openGigs: todayJson.today.openGigs,
          pendingPayments: todayJson.today.pendingPayments,
          revenueTodayCents: todayJson.today.revenueTodayCents,
        });
      }

      // Build 35 cells (5 weeks × 7 days) ending today.
      const grid: DayCell[] = [];
      const now = new Date();
      now.setHours(0, 0, 0, 0);
      for (let i = 34; i >= 0; i--) {
        const d = new Date(now);
        d.setDate(d.getDate() - i);
        grid.push({ iso: isoDay(d), date: d, count: 0, weekday: d.getDay() });
      }
      const byIso = new Map(grid.map((c) => [c.iso, c]));
      for (const ev of feedJson.events ?? []) {
        if (ev.kind !== 'booking') continue;
        const t = new Date(ev.at);
        if (Number.isNaN(t.getTime())) continue;
        t.setHours(0, 0, 0, 0);
        const cell = byIso.get(isoDay(t));
        if (cell) cell.count += 1;
      }
      setCells(grid);
    } catch (err) {
      setStatus((err as Error).message);
    } finally {
      setLoading(false);
    }
  }, [bearer, headers]);

  useEffect(() => {
    void load();
  }, [load]);

  const max = useMemo(() => Math.max(1, ...cells.map((c) => c.count)), [cells]);
  const totalBookings = useMemo(() => cells.reduce((s, c) => s + c.count, 0), [cells]);

  // 5 columns of 7 rows (week starts Sunday).
  // We render by row (weekday) and column (week index) for a Mon-down layout.
  const weeks: DayCell[][] = useMemo(() => {
    const out: DayCell[][] = [];
    for (let w = 0; w < 5; w++) {
      out.push(cells.slice(w * 7, w * 7 + 7));
    }
    return out;
  }, [cells]);

  if (!bearer) {
    return (
      <section className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
        <h2 className="text-xl font-bold text-brand-ink">Booking heatmap</h2>
        <p className="mt-2 text-sm text-brand-mute">
          Add the owner key above to load the 30-day heatmap.
        </p>
      </section>
    );
  }

  return (
    <section className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-brand-ink">Booking heatmap</h2>
          <p className="mt-1 text-sm text-brand-mute">
            Last 30 days · {totalBookings} bookings
            {today && (
              <span className="ml-2">
                · today: {today.openGigs} open gigs · ${(today.revenueTodayCents / 100).toFixed(0)}{' '}
                revenue
              </span>
            )}
          </p>
        </div>
        <button
          type="button"
          onClick={() => void load()}
          disabled={loading}
          className="rounded-md border border-brand-line bg-bg-primary px-3 py-1.5 text-xs text-brand-ink hover:border-brand-accent disabled:opacity-50"
        >
          {loading ? 'Loading…' : 'Refresh'}
        </button>
      </div>

      {status && <p className="mt-3 text-xs text-red-400">{status}</p>}

      {cells.length === 0 ? (
        <p className="mt-4 rounded-md border border-dashed border-brand-line p-4 text-sm text-brand-mute">
          No data loaded yet.
        </p>
      ) : (
        <>
          <div className="mt-5 flex gap-1.5" role="group" aria-label="30-day booking heatmap">
            {weeks.map((week, wIdx) => (
              <div key={wIdx} className="flex flex-col gap-1.5">
                {week.map((cell) => {
                  const opacity = cell.count === 0 ? 0.08 : 0.2 + (cell.count / max) * 0.8;
                  return (
                    <div
                      key={cell.iso}
                      title={`${fmtDate(cell.date)} · ${cell.count} booking${
                        cell.count === 1 ? '' : 's'
                      }`}
                      aria-label={`${fmtDate(cell.date)}, ${cell.count} bookings`}
                      className="h-6 w-6 rounded-sm border border-brand-line/60"
                      style={{
                        backgroundColor: `rgba(0, 229, 255, ${opacity})`,
                      }}
                    />
                  );
                })}
              </div>
            ))}
            <div className="ml-3 flex flex-col gap-1.5 self-start">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((wd) => (
                <span
                  key={wd}
                  className="h-6 font-mono text-[10px] uppercase tracking-widest text-brand-mute"
                >
                  {wd}
                </span>
              ))}
            </div>
          </div>

          <div className="mt-4 flex items-center gap-2">
            <span className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
              less
            </span>
            {[0.1, 0.3, 0.5, 0.7, 0.95].map((o) => (
              <span
                key={o}
                className="h-3 w-3 rounded-sm border border-brand-line/60"
                style={{ backgroundColor: `rgba(0, 229, 255, ${o})` }}
              />
            ))}
            <span className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
              more
            </span>
          </div>
        </>
      )}
    </section>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
