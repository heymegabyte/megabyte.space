import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { useEffect, useRef } from 'react';

/**
 * KeyboardShortcutsOverlay — modal listing every admin dashboard shortcut.
 *
 * Toggle:
 *   - `Cmd+/` (mac) or `Ctrl+/` (win/linux) flips the open state via the
 *     parent-supplied onClose handler. Wire the same handler in the parent
 *     to also set `open` true so the toggle is bi-directional.
 *   - `Esc` always closes.
 *
 * Focus-trapped while open; restores focus to the previously-focused element
 * on close. `role="dialog"` + `aria-modal="true"` for screen readers.
 */

interface Shortcut {
  keys: string;
  label: string;
}

const SHORTCUTS: Shortcut[] = [
  { keys: 'Cmd+K', label: 'Open command palette' },
  { keys: 'Cmd+/', label: 'Toggle this overlay' },
  { keys: 'g d', label: 'Go to dashboard' },
  { keys: 'g p', label: 'Go to plans' },
  { keys: 'g a', label: 'Go to admin AI' },
  { keys: 'g j', label: 'Go to jobs' },
  { keys: 'g c', label: 'Go to customers' },
  { keys: 'g w', label: 'Go to workers' },
  { keys: '/', label: 'Focus global search' },
  { keys: 'n', label: 'New booking' },
  { keys: 'r', label: 'Refresh current panel' },
  { keys: 'Esc', label: 'Close any modal' },
];

function isToggleHotkey(e: KeyboardEvent): boolean {
  // Cmd+/ on mac, Ctrl+/ on win/linux. Some keyboards send '?' with shift.
  if (!(e.metaKey || e.ctrlKey)) return false;
  return e.key === '/' || e.key === '?';
}

export function KeyboardShortcutsOverlay({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const panelRef = useRef<HTMLDivElement>(null);
  const closeBtnRef = useRef<HTMLButtonElement>(null);
  const lastFocusRef = useRef<HTMLElement | null>(null);

  // Global toggle hotkey listener — works whether the overlay is open or not.
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (isToggleHotkey(e)) {
        e.preventDefault();
        onClose();
      }
    }
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  // While open: Esc + focus trap + restore focus on close.
  useEffect(() => {
    if (!open) return;
    lastFocusRef.current = document.activeElement as HTMLElement | null;

    // Defer focus to next frame so the dialog is mounted.
    requestAnimationFrame(() => closeBtnRef.current?.focus({ preventScroll: true }));

    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
        return;
      }
      if (e.key !== 'Tab') return;
      const root = panelRef.current;
      if (!root) return;
      const focusables = Array.from(
        root.querySelectorAll<HTMLElement>(
          'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"]), input, select, textarea',
        ),
      );
      if (focusables.length === 0) return;
      const first = focusables[0]!;
      const last = focusables[focusables.length - 1]!;
      const active = document.activeElement as HTMLElement | null;
      if (e.shiftKey && active === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && active === last) {
        e.preventDefault();
        first.focus();
      }
    }
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('keydown', onKey);
      lastFocusRef.current?.focus({ preventScroll: true });
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="kb-shortcuts-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
    >
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        ref={panelRef}
        data-enter
        className="relative max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-brand-line bg-bg-elevated p-6 shadow-2xl"
      >
        <div className="flex items-start justify-between">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-widest text-brand-accent">
              Reference
            </p>
            <h2 id="kb-shortcuts-title" className="mt-1 text-xl font-bold text-brand-ink">
              Keyboard shortcuts
            </h2>
            <p className="mt-1 text-sm text-brand-mute">
              Press{' '}
              <kbd className="rounded border border-brand-line bg-bg-primary px-1.5 py-0.5 font-mono text-xs">
                Cmd
              </kbd>
              <span className="mx-1 text-brand-mute">+</span>
              <kbd className="rounded border border-brand-line bg-bg-primary px-1.5 py-0.5 font-mono text-xs">
                /
              </kbd>{' '}
              anywhere to toggle this overlay.
            </p>
          </div>
          <button
            ref={closeBtnRef}
            type="button"
            onClick={onClose}
            aria-label="Close keyboard shortcuts"
            className="rounded-md border border-brand-line bg-bg-primary px-2 py-1 text-xs text-brand-ink hover:border-brand-accent"
          >
            Esc
          </button>
        </div>

        <ul className="mt-6 grid grid-cols-1 gap-2 sm:grid-cols-2">
          {SHORTCUTS.map((s) => (
            <li
              key={s.keys}
              className="flex items-center justify-between rounded-md border border-brand-line bg-bg-primary px-3 py-2"
            >
              <span className="text-sm text-brand-ink">{s.label}</span>
              <span className="ml-3 flex flex-wrap gap-1">
                {s.keys.split(' ').map((part, idx) => (
                  <kbd
                    key={`${part}-${idx}`}
                    className="rounded border border-brand-line bg-bg-elevated px-1.5 py-0.5 font-mono text-[11px] text-brand-accent"
                  >
                    {part}
                  </kbd>
                ))}
              </span>
            </li>
          ))}
        </ul>

        <p className="mt-5 font-mono text-[10px] uppercase tracking-widest text-brand-mute">
          Tip — sequence shortcuts like <span className="text-brand-accent">g d</span> mean press{' '}
          <span className="text-brand-accent">g</span> then{' '}
          <span className="text-brand-accent">d</span> within ~1 second.
        </p>
      </div>
    </div>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
