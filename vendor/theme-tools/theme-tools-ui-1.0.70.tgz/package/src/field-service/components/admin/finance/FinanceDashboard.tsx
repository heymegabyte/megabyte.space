import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { lazy, Suspense } from 'react';

const RevenueForecastChart = lazy(() => import('./RevenueForecastChart.js'));
const ProfitByZip = lazy(() => import('./ProfitByZip.js'));
const ProfitByService = lazy(() => import('./ProfitByService.js'));
const WorkerProfitabilityRanking = lazy(() => import('./WorkerProfitabilityRanking.js'));
const TipReconciliation = lazy(() => import('./TipReconciliation.js'));
const RefundFraudQueue = lazy(() => import('./RefundFraudQueue.js'));
const ChargebackDrafts = lazy(() => import('./ChargebackDrafts.js'));
const PricingExperimentRunner = lazy(() => import('./PricingExperimentRunner.js'));

/**
 * /admin/finance dashboard — orchestrates the 8 finance widgets in a
 * 12-column responsive grid. Forecast + experiment runner go full-width
 * (chart-heavy); profit panels share a 2-col layout; refund + chargeback
 * stack on the right rail for an "inbox" feel.
 *
 * All inner components lazy-load to keep the initial Admin bundle slim.
 */
export default function FinanceDashboard() {
  useThemeToolsSurface('finance-dashboard');
  return (
    <main className="min-h-screen bg-[#070a0f] text-white space-y-6">
      <header className="rounded-2xl border border-black/85 bg-[#0c1017] p-5 sm:p-6 shadow-[0_24px_60px_-20px_rgba(0,0,0,0.92),0_0_0_1px_rgba(0,0,0,0.9),inset_0_1px_0_rgba(255,255,255,0.035)]">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="font-mono text-xs uppercase tracking-wider text-brand-accent">
              Admin · Finance Workbench
            </p>
            <h1 className="font-display text-2xl sm:text-3xl font-extrabold mt-1">
              Money in, money out
            </h1>
            <p className="text-sm text-brand-mute mt-1 max-w-2xl">
              Revenue forecasts, profit-by-ZIP + service, tips, advances, refund-fraud scoring,
              chargeback drafts, and pricing experiments.
            </p>
          </div>
          <nav aria-label="Finance sub-navigation" className="flex flex-wrap items-center gap-2">
            <a
              href="/admin/finance"
              aria-current="page"
              className="rounded-xl border border-brand-accent bg-brand-accent/15 px-3.5 py-2 font-mono text-xs font-bold text-brand-accent"
            >
              Overview
            </a>
            <a
              href="/admin/finance/1099"
              className="rounded-xl border border-black/85 bg-[#080b12] px-3.5 py-2 font-mono text-xs font-semibold text-brand-mute hover:border-brand-accent hover:text-brand-ink transition"
            >
              1099-NEC E-File →
            </a>
            <a
              href="/admin/finance/fraud"
              className="rounded-xl border border-black/85 bg-[#080b12] px-3.5 py-2 font-mono text-xs font-semibold text-brand-mute hover:border-brand-accent hover:text-brand-ink transition"
            >
              AI Fraud Queue →
            </a>
          </nav>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <div className="lg:col-span-12">
          <Suspense fallback={<DashboardPlaceholder label="Forecast" />}>
            <RevenueForecastChart days={14} />
          </Suspense>
        </div>

        <div className="lg:col-span-6">
          <Suspense fallback={<DashboardPlaceholder label="Profit by ZIP" />}>
            <ProfitByZip />
          </Suspense>
        </div>

        <div className="lg:col-span-6">
          <Suspense fallback={<DashboardPlaceholder label="Profit by service" />}>
            <ProfitByService />
          </Suspense>
        </div>

        <div className="lg:col-span-6">
          <Suspense fallback={<DashboardPlaceholder label="Worker profitability" />}>
            <WorkerProfitabilityRanking />
          </Suspense>
        </div>

        <div className="lg:col-span-6">
          <Suspense fallback={<DashboardPlaceholder label="Tip reconciliation" />}>
            <TipReconciliation />
          </Suspense>
        </div>

        <div className="lg:col-span-12">
          <Suspense fallback={<DashboardPlaceholder label="Pricing experiment" />}>
            <PricingExperimentRunner />
          </Suspense>
        </div>

        <div className="lg:col-span-6">
          <Suspense fallback={<DashboardPlaceholder label="Refund fraud queue" />}>
            <RefundFraudQueue />
          </Suspense>
        </div>

        <div className="lg:col-span-6">
          <Suspense fallback={<DashboardPlaceholder label="Chargeback drafts" />}>
            <ChargebackDrafts />
          </Suspense>
        </div>
      </div>
    </main>
  );
}

function DashboardPlaceholder({ label }: { label: string }) {
  return (
    <section className="rounded-2xl bg-slate-900/60 ring-1 ring-white/5 p-5 animate-pulse">
      <p className="text-xs text-slate-500">Loading {label}…</p>
    </section>
  );
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
