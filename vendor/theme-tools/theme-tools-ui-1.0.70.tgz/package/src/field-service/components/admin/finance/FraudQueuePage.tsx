import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { useCallback, useEffect, useState } from 'react';
import { adminFetch, formatCents } from '@theme.tools/billing/field-service/finance-shared';

interface FraudItem {
  id: string;
  adminEventId: string;
  bookingId: string | null;
  customerEmail: string | null;
  amountCents: number;
  verdict: 'fraud' | 'legit' | 'unclear';
  confidence: number;
  reasoning: string;
  signals: string[];
  autoApproved: boolean;
  reviewedAt: string | null;
  humanOverride: string | null;
  eventKind: string;
  eventSummary: string;
  eventTs: number;
  createdAt: string;
}

/**
 * /admin/finance/fraud — AI-classified refund-fraud queue. Pulls recent
 * `refund_classifications` rows from the worker, lets ops filter by verdict
 * and approve/reject/escalate each one. Auto-approved items (legit ≥ 0.85
 * confidence) sit at the top in a separate "Ready" stack.
 */
export default function FraudQueuePage() {
  useThemeToolsSurface('fraud-queue-page');
  const [items, setItems] = useState<FraudItem[] | null>(null);
  const [filter, setFilter] = useState<'all' | 'fraud' | 'legit' | 'unclear'>('all');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setError(null);
    try {
      const q = filter === 'all' ? '' : `?verdict=${filter}`;
      const res = await adminFetch(`/api/admin/fraud${q}`);
      const json = (await res.json()) as { ok: boolean; items?: FraudItem[]; error?: string };
      if (!json.ok) throw new Error(json.error ?? 'load_failed');
      setItems(json.items ?? []);
    } catch (err) {
      setError((err as Error).message);
    }
  }, [filter]);

  useEffect(() => {
    void load();
  }, [load]);

  async function runClassifier() {
    setBusy(true);
    setError(null);
    try {
      const res = await adminFetch(`/api/admin/fraud/run`, {
        method: 'POST',
        body: JSON.stringify({ limit: 20 }),
      });
      const json = (await res.json()) as { ok: boolean; error?: string };
      if (!json.ok) throw new Error(json.error ?? 'run_failed');
      await load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function review(id: string, decision: 'approved' | 'rejected' | 'escalated') {
    setError(null);
    const res = await adminFetch(`/api/admin/fraud/${id}/review`, {
      method: 'POST',
      body: JSON.stringify({ decision }),
    });
    const json = (await res.json()) as { ok: boolean; error?: string };
    if (!json.ok) setError(json.error ?? 'review_failed');
    else await load();
  }

  const counts = items
    ? {
        all: items.length,
        fraud: items.filter((i) => i.verdict === 'fraud').length,
        legit: items.filter((i) => i.verdict === 'legit').length,
        unclear: items.filter((i) => i.verdict === 'unclear').length,
      }
    : { all: 0, fraud: 0, legit: 0, unclear: 0 };

  return (
    <main className="min-h-screen bg-[#070a0f] text-white space-y-6">
      <header className="rounded-2xl border border-black/85 bg-[#0c1017] p-5 sm:p-6 shadow-[0_24px_60px_-20px_rgba(0,0,0,0.92),0_0_0_1px_rgba(0,0,0,0.9),inset_0_1px_0_rgba(255,255,255,0.035)]">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="font-mono text-xs uppercase tracking-wider text-brand-accent">
              Admin · Finance · Fraud queue
            </p>
            <h1 className="font-display text-2xl sm:text-3xl font-extrabold mt-1">
              AI refund triage
            </h1>
            <p className="text-sm text-brand-mute mt-1 max-w-2xl">
              Recent refund events scored by Claude Haiku via AI Gateway. Legit ≥ 0.85 confidence is
              auto-approved (ready for one-click refund); fraud holds for human review.
            </p>
          </div>
          <nav aria-label="Finance sub-navigation" className="flex flex-wrap items-center gap-2">
            <a
              href="/admin/finance"
              className="rounded-xl border border-black/85 bg-[#080b12] px-3.5 py-2 font-mono text-xs font-semibold text-brand-mute hover:border-brand-accent hover:text-brand-ink transition"
            >
              ← Overview
            </a>
            <a
              href="/admin/finance/1099"
              className="rounded-xl border border-black/85 bg-[#080b12] px-3.5 py-2 font-mono text-xs font-semibold text-brand-mute hover:border-brand-accent hover:text-brand-ink transition"
            >
              1099-NEC E-File
            </a>
            <a
              href="/admin/finance/fraud"
              aria-current="page"
              className="rounded-xl border border-brand-accent bg-brand-accent/15 px-3.5 py-2 font-mono text-xs font-bold text-brand-accent"
            >
              AI Fraud Queue
            </a>
          </nav>
        </div>
      </header>

      <div className="space-y-6">
        <section className="rounded-2xl bg-slate-900/60 ring-1 ring-white/5 p-5">
          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={runClassifier}
              disabled={busy}
              className="bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-slate-950 font-medium rounded-md px-4 py-2"
            >
              {busy ? 'Classifying…' : 'Run classifier on new refund events'}
            </button>
            <div className="ml-auto inline-flex rounded-md ring-1 ring-white/10 overflow-hidden text-xs">
              {(['all', 'fraud', 'unclear', 'legit'] as const).map((v) => (
                <button
                  key={v}
                  type="button"
                  onClick={() => setFilter(v)}
                  className={`px-3 py-1.5 uppercase tracking-wide ${
                    filter === v
                      ? 'bg-cyan-500 text-slate-950'
                      : 'bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  {v} · {counts[v]}
                </button>
              ))}
            </div>
          </div>
          {error && <p className="text-sm text-rose-400 mt-3">{error}</p>}
        </section>

        <ul className="space-y-3">
          {!items && <li className="text-slate-500 text-sm">Loading…</li>}
          {items && items.length === 0 && (
            <li className="text-slate-500 text-sm rounded-2xl bg-slate-900/60 ring-1 ring-white/5 p-5">
              Queue empty. Click "Run classifier" to ingest recent refund events.
            </li>
          )}
          {items?.map((i) => (
            <li
              key={i.id}
              className="rounded-2xl bg-slate-900/60 ring-1 ring-white/5 p-5 grid sm:grid-cols-[1fr_auto] gap-4 items-start"
            >
              <div>
                <div className="flex flex-wrap items-center gap-2 mb-2">
                  <VerdictPill verdict={i.verdict} confidence={i.confidence} />
                  {i.autoApproved && (
                    <span className="text-xs uppercase tracking-wide bg-emerald-500/15 text-emerald-300 ring-1 ring-emerald-500/30 px-2 py-0.5 rounded">
                      Auto-ready
                    </span>
                  )}
                  {i.reviewedAt && (
                    <span className="text-xs text-slate-500">
                      Reviewed: {i.humanOverride ?? 'noted'}
                    </span>
                  )}
                </div>
                <p className="text-white font-medium">{i.eventSummary}</p>
                <p className="text-xs text-slate-400 mt-1">
                  {i.eventKind} · {new Date(i.eventTs).toLocaleString()}
                </p>
                <p className="text-sm text-slate-300 mt-2">{i.reasoning}</p>
                {i.signals.length > 0 && (
                  <ul className="flex flex-wrap gap-1 mt-2">
                    {i.signals.map((s, idx) => (
                      <li
                        key={idx}
                        className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded"
                      >
                        {s}
                      </li>
                    ))}
                  </ul>
                )}
                <div className="text-xs text-slate-500 mt-2 space-x-3">
                  {i.bookingId && (
                    <span>
                      Booking: <span className="text-slate-300">{i.bookingId}</span>
                    </span>
                  )}
                  {i.customerEmail && <span>· {i.customerEmail}</span>}
                  {i.amountCents > 0 && <span>· {formatCents(i.amountCents)}</span>}
                </div>
              </div>
              <div className="flex flex-col gap-2">
                {!i.reviewedAt && (
                  <>
                    <button
                      type="button"
                      onClick={() => review(i.id, 'approved')}
                      className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-md px-3 py-1.5 text-sm font-medium"
                    >
                      Approve refund
                    </button>
                    <button
                      type="button"
                      onClick={() => review(i.id, 'rejected')}
                      className="bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 ring-1 ring-rose-500/30 rounded-md px-3 py-1.5 text-sm"
                    >
                      Reject
                    </button>
                    <button
                      type="button"
                      onClick={() => review(i.id, 'escalated')}
                      className="bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-md px-3 py-1.5 text-sm"
                    >
                      Escalate
                    </button>
                  </>
                )}
              </div>
            </li>
          ))}
        </ul>
      </div>
    </main>
  );
}

function VerdictPill({
  verdict,
  confidence,
}: {
  verdict: 'fraud' | 'legit' | 'unclear';
  confidence: number;
}) {
  const styles: Record<string, string> = {
    fraud: 'bg-rose-500/15 text-rose-300 ring-rose-500/30',
    legit: 'bg-emerald-500/15 text-emerald-300 ring-emerald-500/30',
    unclear: 'bg-amber-500/15 text-amber-300 ring-amber-500/30',
  };
  return (
    <span
      className={`px-2 py-0.5 rounded-full text-xs uppercase tracking-wide ring-1 ${styles[verdict]}`}
    >
      {verdict} · {Math.round(confidence * 100)}%
    </span>
  );
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
