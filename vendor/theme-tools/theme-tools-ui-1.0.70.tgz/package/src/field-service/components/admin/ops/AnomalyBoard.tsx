import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { useMemo } from 'react';
import type { Anomaly } from '@theme.tools/crm/field-service/admin-ops-types';
import { severityClass } from '@theme.tools/crm/field-service/admin-ops-types';

interface Props {
  anomalies: readonly Anomaly[];
  onResolve?: (id: string) => void;
}

/**
 * AnomalyBoard — feed of detected anomalies, sorted by severity then recency.
 * Each row shows the kind, the operator-readable note, and a one-click
 * "Mark resolved" button when `onResolve` is supplied.
 */
export default function AnomalyBoard({ anomalies, onResolve }: Props) {
  useThemeToolsSurface('anomaly-board');
  const sorted = useMemo(() => {
    const rank = { critical: 0, high: 1, medium: 2, low: 3 } as const;
    return [...anomalies].sort((a, b) => {
      const sevDiff = rank[a.severity] - rank[b.severity];
      if (sevDiff !== 0) return sevDiff;
      return b.detected_at.localeCompare(a.detected_at);
    });
  }, [anomalies]);

  if (sorted.length === 0) {
    return (
      <div className="rounded-xl border border-zinc-800 bg-zinc-950 p-6 text-center">
        <p className="text-zinc-400">No open anomalies. Everything's quiet.</p>
      </div>
    );
  }

  return (
    <ul className="space-y-2">
      {sorted.map((a) => {
        const payload = typeof a.payload === 'string' ? {} : a.payload;
        return (
          <li
            key={a.id}
            className="flex flex-col gap-2 rounded-xl border border-zinc-800 bg-zinc-950 p-4 sm:flex-row sm:items-center sm:justify-between"
          >
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span
                  className={`rounded-md border px-2 py-0.5 text-xs font-medium uppercase tracking-wide ${severityClass(a.severity)}`}
                >
                  {a.severity}
                </span>
                <span className="font-mono text-sm text-zinc-200">{a.kind}</span>
                <span className="text-xs text-zinc-500">
                  {new Date(a.detected_at).toLocaleString()}
                </span>
              </div>
              <p className="mt-1 text-sm text-zinc-300">{payload.note ?? 'Anomaly detected.'}</p>
              {typeof payload.z_score === 'number' && (
                <p className="mt-1 font-mono text-xs text-zinc-500">
                  z = {payload.z_score.toFixed(2)} · observed {payload.observed} · baseline{' '}
                  {payload.baseline_mean} ± {payload.baseline_stdev}
                </p>
              )}
            </div>
            {onResolve && (
              <button
                type="button"
                onClick={() => onResolve(a.id)}
                className="self-start rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-1.5 text-sm font-medium text-zinc-200 hover:bg-zinc-800 sm:self-center"
              >
                Mark resolved
              </button>
            )}
          </li>
        );
      })}
    </ul>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
