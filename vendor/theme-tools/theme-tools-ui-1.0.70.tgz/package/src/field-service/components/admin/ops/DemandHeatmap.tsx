import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { useMemo } from 'react';
import type { DemandCell } from '@theme.tools/crm/field-service/admin-ops-types';

interface Props {
  cells: readonly DemandCell[];
  /** Override the column ordering. Defaults to sorted unique day list. */
  days?: readonly string[];
  /** Override the row ordering. Defaults to sorted unique zip list. */
  zips?: readonly string[];
}

/**
 * DemandHeatmap — CSS-only zip × day grid where each cell's background
 * intensity tracks `predicted_bookings`. No external chart library. Pure
 * Tailwind via inline `style.backgroundColor` so colors interpolate
 * smoothly without listing every shade in the safelist.
 */
export default function DemandHeatmap({ cells, days, zips }: Props) {
  useThemeToolsSurface('demand-heatmap');
  const { uniqueDays, uniqueZips, byKey, max } = useMemo(() => {
    const dSet = new Set<string>();
    const zSet = new Set<string>();
    const byKey = new Map<string, DemandCell>();
    let max = 0;
    for (const c of cells) {
      dSet.add(c.day);
      zSet.add(c.zip);
      byKey.set(`${c.zip}|${c.day}`, c);
      if (c.predicted_bookings > max) max = c.predicted_bookings;
    }
    return {
      uniqueDays: days ?? [...dSet].sort(),
      uniqueZips: zips ?? [...zSet].sort(),
      byKey,
      max,
    };
  }, [cells, days, zips]);

  if (uniqueDays.length === 0 || uniqueZips.length === 0) {
    return (
      <div className="rounded-xl border border-zinc-800 bg-zinc-950 p-6 text-center">
        <p className="text-zinc-400">No forecast data yet — POST /api/admin/ops/forecast.</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto rounded-xl border border-zinc-800 bg-zinc-950 p-3">
      <table className="min-w-full border-separate border-spacing-1 text-xs">
        <thead>
          <tr>
            <th className="sticky left-0 z-10 bg-zinc-950 p-1 text-left font-medium text-zinc-400">
              zip \ day
            </th>
            {uniqueDays.map((d) => (
              <th key={d} className="p-1 font-mono font-normal text-zinc-500">
                {d.slice(5)}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {uniqueZips.map((zip) => (
            <tr key={zip}>
              <th className="sticky left-0 z-10 bg-zinc-950 p-1 text-left font-mono font-medium text-zinc-300">
                {zip}
              </th>
              {uniqueDays.map((d) => {
                const cell = byKey.get(`${zip}|${d}`);
                const v = cell?.predicted_bookings ?? 0;
                const intensity = max > 0 ? v / max : 0;
                const bg = `rgba(80, 170, 227, ${0.08 + intensity * 0.72})`;
                return (
                  <td
                    key={d}
                    title={
                      cell
                        ? `${zip} · ${d}: ${cell.predicted_bookings} bookings (conf ${Math.round(cell.confidence * 100)}%)`
                        : `${zip} · ${d}: no forecast`
                    }
                    className="h-8 min-w-[36px] rounded-md text-center font-mono text-zinc-100"
                    style={{ backgroundColor: cell ? bg : 'rgba(40,40,52,0.4)' }}
                  >
                    {v || ''}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
      <p className="mt-2 text-xs text-zinc-500">
        Intensity = predicted bookings normalized to the max in view. Hover for confidence.
      </p>
    </div>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
