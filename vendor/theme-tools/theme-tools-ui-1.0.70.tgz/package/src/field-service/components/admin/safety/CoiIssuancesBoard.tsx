import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useState } from 'react';

/**
 * COI issuances board. Lists every Certificate of Insurance with status,
 * expiry, and a download link. Includes the issue-new form.
 */

interface CoiRow {
  id: string;
  partner_id: string | null;
  customer_id: string | null;
  policy_number: string;
  expires_at: string;
  issued_at: string;
  vendor: string;
}

export function CoiIssuancesBoard({ auth }: { readonly auth: HeadersInit }) {
  useThemeToolsSurface('coi-issuances-board');
  const [rows, setRows] = useState<CoiRow[]>([]);
  const [error, setError] = useState('');
  const [issuing, setIssuing] = useState(false);
  const [result, setResult] = useState('');

  const reload = useCallback(async () => {
    setError('');
    try {
      const res = await fetch('/api/admin/safety/coi-list', { headers: auth });
      if (res.status === 404) {
        setRows([]);
        return;
      }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = (await res.json()) as { rows?: CoiRow[] };
      setRows(data.rows ?? []);
    } catch (err) {
      setError((err as Error).message);
    }
  }, [auth]);

  useEffect(() => {
    void reload();
  }, [reload]);

  async function onIssue(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setIssuing(true);
    setResult('');
    try {
      const form = new FormData(e.currentTarget);
      const payload = {
        insuredName: String(form.get('insuredName') ?? ''),
        insuredAddress: String(form.get('insuredAddress') ?? '') || undefined,
        coverageStartIso: String(form.get('coverageStartIso') ?? ''),
        coverageEndIso: String(form.get('coverageEndIso') ?? ''),
        aggregateLimitCents: Number(form.get('aggregate') ?? '0') * 100,
        perOccurrenceLimitCents: Number(form.get('perOcc') ?? '0') * 100,
        notes: String(form.get('notes') ?? '') || undefined,
      };
      const res = await fetch('/api/admin/safety/issue-coi', {
        method: 'POST',
        headers: { ...auth, 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = (await res.json()) as { ok?: boolean; id?: string; policyNumber?: string };
      if (!data.ok) throw new Error('issue failed');
      setResult(`Issued ${data.policyNumber} (id ${data.id}).`);
      await reload();
    } catch (err) {
      setResult(`Error: ${(err as Error).message}`);
    } finally {
      setIssuing(false);
    }
  }

  return (
    <section aria-labelledby="coi-h" className="space-y-4">
      <header>
        <h2 id="coi-h" className="text-xl font-bold">
          Certificates of insurance
        </h2>
        <p className="text-brand-mute text-sm">
          PDFs stored in R2 under <code>coi/&lt;id&gt;.pdf</code>.
        </p>
      </header>

      <form
        onSubmit={onIssue}
        className="rounded-lg border border-brand-line bg-brand-ink/40 p-4 space-y-3"
      >
        <p className="text-sm font-medium">Issue new COI</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <input
            required
            name="insuredName"
            placeholder="Insured name (e.g. 123 Property Mgmt LLC)"
            className="rounded-md border border-brand-line bg-brand-bg px-3 py-2 text-sm"
          />
          <input
            name="insuredAddress"
            placeholder="Insured address"
            className="rounded-md border border-brand-line bg-brand-bg px-3 py-2 text-sm"
          />
          <input
            required
            type="date"
            name="coverageStartIso"
            className="rounded-md border border-brand-line bg-brand-bg px-3 py-2 text-sm"
          />
          <input
            required
            type="date"
            name="coverageEndIso"
            className="rounded-md border border-brand-line bg-brand-bg px-3 py-2 text-sm"
          />
          <input
            required
            type="number"
            min="0"
            step="1000"
            name="aggregate"
            placeholder="Aggregate limit (USD)"
            className="rounded-md border border-brand-line bg-brand-bg px-3 py-2 text-sm"
          />
          <input
            required
            type="number"
            min="0"
            step="1000"
            name="perOcc"
            placeholder="Per occurrence (USD)"
            className="rounded-md border border-brand-line bg-brand-bg px-3 py-2 text-sm"
          />
        </div>
        <textarea
          name="notes"
          placeholder="Notes (optional)"
          rows={2}
          maxLength={500}
          className="w-full rounded-md border border-brand-line bg-brand-bg px-3 py-2 text-sm"
        />
        <button
          type="submit"
          disabled={issuing}
          className="btn btn-primary text-sm disabled:opacity-60"
        >
          {issuing ? 'Issuing…' : 'Issue COI'}
        </button>
        {result && <p className="text-brand-accent text-sm">{result}</p>}
      </form>

      {error && <p className="text-rose-400 text-sm">{error}</p>}
      {rows.length === 0 && <p className="text-brand-mute text-sm">No COIs on file.</p>}
      {rows.length > 0 && (
        <ul className="space-y-1 text-sm">
          {rows.map((r) => (
            <li
              key={r.id}
              className="flex flex-wrap items-center justify-between gap-2 rounded-md border border-brand-line bg-brand-ink/40 px-3 py-2"
            >
              <span className="font-mono text-xs">{r.policy_number}</span>
              <span className="text-brand-mute text-xs">expires {r.expires_at.slice(0, 10)}</span>
              <span className="text-brand-mute text-xs">{r.vendor}</span>
              <a
                className="text-brand-accent text-xs underline"
                href={`/api/admin/safety/coi/${r.id}`}
              >
                Download PDF
              </a>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
