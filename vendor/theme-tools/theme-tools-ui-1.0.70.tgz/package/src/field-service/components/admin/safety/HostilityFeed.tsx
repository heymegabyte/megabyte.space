import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { useEffect, useState } from 'react';

/**
 * Hostility feed — recent hostility=1 SMS sentiment rows. Sourced from the
 * compliance_audit table filtered by kind='sentiment.scanned' with the
 * payload containing hostility=true.
 *
 * Admin can rescan a phone or message body via /api/admin/safety/scan-sentiment.
 */

interface AuditItem {
  id: string;
  kind: string;
  severity: string;
  ts: string;
  actor: string | null;
  payload: Record<string, unknown> | null;
}

export function HostilityFeed({ auth }: { readonly auth: HeadersInit }) {
  useThemeToolsSurface('hostility-feed');
  const [items, setItems] = useState<AuditItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [text, setText] = useState('');
  const [phone, setPhone] = useState('');
  const [scanning, setScanning] = useState(false);
  const [scanResult, setScanResult] = useState<string>('');

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    (async () => {
      try {
        const res = await fetch(
          '/api/admin/compliance/audit-trail?kind=sentiment.scanned&severity=high&limit=50',
          { headers: auth },
        );
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = (await res.json()) as { items?: AuditItem[] };
        if (!cancelled) setItems(data.items ?? []);
      } catch (err) {
        if (!cancelled) setError((err as Error).message);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [auth]);

  async function onScan(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!text.trim() || !phone.trim()) return;
    setScanning(true);
    setScanResult('');
    try {
      const res = await fetch('/api/admin/safety/scan-sentiment', {
        method: 'POST',
        headers: { ...auth, 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, senderPhone: phone }),
      });
      const data = (await res.json()) as {
        ok?: boolean;
        result?: { hostility?: boolean; sentiment?: number };
      };
      if (!data.ok) throw new Error('scan failed');
      setScanResult(
        `Hostility: ${data.result?.hostility ? 'YES' : 'no'} · Sentiment ${(data.result?.sentiment ?? 0).toFixed(2)}`,
      );
    } catch (err) {
      setScanResult(`Error: ${(err as Error).message}`);
    } finally {
      setScanning(false);
    }
  }

  return (
    <section aria-labelledby="hostility-h" className="space-y-4">
      <header>
        <h2 id="hostility-h" className="text-xl font-bold">
          Hostility feed
        </h2>
        <p className="text-brand-mute text-sm">
          AI-flagged inbound SMS (hostility=1, severity=high).
        </p>
      </header>

      <form
        onSubmit={onScan}
        className="rounded-lg border border-brand-line bg-brand-ink/40 p-4 space-y-3"
      >
        <p className="text-sm font-medium">Manual scan</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <input
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="+19735551234"
            className="rounded-md border border-brand-line bg-brand-bg px-3 py-2 text-sm"
          />
          <button
            type="submit"
            disabled={scanning}
            className="btn btn-primary text-sm disabled:opacity-60"
          >
            {scanning ? 'Scanning…' : 'Scan'}
          </button>
        </div>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Paste SMS body…"
          rows={3}
          maxLength={2000}
          className="w-full rounded-md border border-brand-line bg-brand-bg px-3 py-2 text-sm"
        />
        {scanResult && <p className="text-brand-accent text-sm">{scanResult}</p>}
      </form>

      {error && <p className="text-rose-400 text-sm">Failed to load: {error}</p>}
      {loading && <p className="text-brand-mute text-sm">Loading…</p>}

      {!loading && items.length === 0 && (
        <p className="text-brand-mute text-sm">No hostility-flagged messages.</p>
      )}

      {!loading && items.length > 0 && (
        <ul className="space-y-2">
          {items.map((item) => (
            <li
              key={item.id}
              className="rounded-md border border-rose-900/40 bg-rose-900/10 p-3 text-sm"
            >
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-brand-mute">
                <span className="font-mono">{item.ts}</span>
                <span className="rounded-full bg-rose-900/30 px-2 py-0.5 text-rose-200">
                  {item.severity}
                </span>
              </div>
              <pre className="mt-1 whitespace-pre-wrap text-xs">
                {JSON.stringify(item.payload, null, 2)}
              </pre>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
