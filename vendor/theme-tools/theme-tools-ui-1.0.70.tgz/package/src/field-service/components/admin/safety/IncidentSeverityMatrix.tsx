import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { useEffect, useState } from 'react';

/**
 * Incident severity matrix. 4x4 grid (severity × kind), counts only — links
 * over to the main /admin#incidents queue for action.
 *
 * Data source: /api/incidents/admin/list (the existing route in
 * workers/main/src/routes/incidents.ts). We aggregate client-side.
 */

interface IncidentRow {
  id: string;
  kind: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  status: string;
  created_at: string;
}

const KINDS = [
  'injury',
  'property_damage',
  'vehicle_accident',
  'customer_dispute',
  'no_show',
  'unsafe_site',
  'panic_button',
  'other',
] as const;
const SEVERITIES = ['low', 'medium', 'high', 'critical'] as const;

export function IncidentSeverityMatrix({ auth }: { readonly auth: HeadersInit }) {
  useThemeToolsSurface('incident-severity-matrix');
  const [rows, setRows] = useState<IncidentRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError('');
    (async () => {
      try {
        const res = await fetch('/api/incidents/admin/list', { headers: auth });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = (await res.json()) as { incidents?: IncidentRow[] };
        if (!cancelled) setRows(data.incidents ?? []);
      } catch (err) {
        if (!cancelled) setError((err as Error).message);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [auth]);

  const buckets = aggregate(rows);
  const total = rows.length;
  const open = rows.filter((r) => r.status === 'open' || r.status === 'investigating').length;

  return (
    <section aria-labelledby="incidents-matrix-h">
      <header className="mb-3 flex items-end justify-between">
        <div>
          <h2 id="incidents-matrix-h" className="text-xl font-bold">
            Incidents
          </h2>
          <p className="text-brand-mute text-sm">
            {open} open · {total} all-time
          </p>
        </div>
        <a className="text-brand-accent text-sm underline" href="/admin#incidents">
          Open queue →
        </a>
      </header>

      {error && <p className="text-rose-400 text-sm">Failed to load: {error}</p>}
      {loading && <p className="text-brand-mute text-sm">Loading…</p>}

      {!loading && (
        <div className="overflow-x-auto">
          <table className="min-w-full border-collapse text-sm">
            <thead>
              <tr>
                <th className="border-b border-brand-line p-2 text-left text-xs uppercase tracking-wider text-brand-mute">
                  Kind \ Severity
                </th>
                {SEVERITIES.map((s) => (
                  <th
                    key={s}
                    className="border-b border-brand-line p-2 text-center text-xs uppercase tracking-wider text-brand-mute"
                  >
                    {s}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {KINDS.map((k) => (
                <tr key={k}>
                  <th className="border-b border-brand-line p-2 text-left font-medium">{k}</th>
                  {SEVERITIES.map((s) => {
                    const n = buckets[`${k}|${s}`] ?? 0;
                    return (
                      <td
                        key={s}
                        className={
                          'border-b border-brand-line p-2 text-center font-mono ' +
                          severityCellClass(s, n)
                        }
                      >
                        {n}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}

function aggregate(rows: IncidentRow[]): Record<string, number> {
  const out: Record<string, number> = {};
  for (const r of rows) {
    const key = `${r.kind}|${r.severity}`;
    out[key] = (out[key] ?? 0) + 1;
  }
  return out;
}

function severityCellClass(s: string, n: number): string {
  if (n === 0) return 'text-brand-mute';
  if (s === 'critical') return 'bg-rose-900/30 text-rose-300';
  if (s === 'high') return 'bg-amber-900/30 text-amber-300';
  if (s === 'medium') return 'bg-yellow-900/20 text-yellow-200';
  return 'text-brand-fg';
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
