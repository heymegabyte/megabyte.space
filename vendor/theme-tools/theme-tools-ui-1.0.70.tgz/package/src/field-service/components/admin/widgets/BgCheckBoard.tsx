import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function BgCheckBoard({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('bg-check-board');
  return (
    <GenericTable title="Background-check board" endpoint="/bg-check-board" adminKey={adminKey} />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
