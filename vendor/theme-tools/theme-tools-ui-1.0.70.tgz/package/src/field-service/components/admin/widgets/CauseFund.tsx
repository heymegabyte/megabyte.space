import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function CauseFund({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('cause-fund');
  return <GenericTable title="Cause fund breakdown" endpoint="/cause-fund" adminKey={adminKey} />;
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
