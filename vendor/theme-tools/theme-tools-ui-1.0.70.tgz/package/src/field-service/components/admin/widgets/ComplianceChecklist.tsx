import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { WidgetShell, bigNumber } from './WidgetShell.js';

interface Check {
  id: string;
  label: string;
  ok: boolean;
}

export default function ComplianceChecklist({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('compliance-checklist');
  return (
    <WidgetShell
      title="Compliance checklist"
      endpoint="/compliance-checklist"
      adminKey={adminKey}
      render={(raw) => {
        const d = raw as { checks?: Check[]; passing?: number; total?: number };
        return (
          <>
            {bigNumber('passing', `${d.passing ?? 0} / ${d.total ?? 0}`)}
            <ul style={{ marginTop: 8, paddingLeft: 16, fontSize: 12 }}>
              {(d.checks ?? []).map((ch) => (
                <li key={ch.id} style={{ color: ch.ok ? 'var(--color-action-violet)' : 'var(--color-danger-soft)' }}>
                  {ch.ok ? '✓' : '✗'} {ch.label}
                </li>
              ))}
            </ul>
          </>
        );
      }}
    />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
