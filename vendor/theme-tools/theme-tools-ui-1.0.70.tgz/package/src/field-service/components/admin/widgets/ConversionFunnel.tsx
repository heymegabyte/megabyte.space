import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function ConversionFunnel({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('conversion-funnel');
  return (
    <GenericTable
      title="Conversion funnel (30d)"
      endpoint="/conversion-funnel"
      adminKey={adminKey}
    />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
