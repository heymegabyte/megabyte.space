import { Card, ThemeToolsPageSurface, useThemeToolsSurface } from '../../../field-service-primitives.js';
/**
 * EeatStrip — visible Experience/Expertise/Authoritativeness/Trustworthiness
 * signals rendered as real HTML body text (LLMs / AI search engines like
 * ChatGPT, Perplexity, and Google AI Overviews do not fetch JSON-LD on direct
 * read — facts MUST be in the visible DOM to be cited).
 *
 * Mounted on the homepage (inside OwnerBio), every city page (CityPage), and
 * every service hub via the prerender shell. Keep the copy concrete: real
 * names, real numbers, dated review stamp, and identifier placeholders
 * (USDOT/MC#) so dispatch + insurance auditors can find them.
 */
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { eeatStripCopy } from '@theme.tools/i18n-a11y/field-service/eeat-strip-copy';

const REVIEWED = '2026-05-19';

// Gorgeous-by-default: each trust card lifts on hover (the project 333ms standard,
// reduced-motion-gated) so the E-E-A-T grid reads as crafted, not static.
const cardClass =
  'rounded-xl border border-black/85 bg-[#0c1017] p-4 shadow-[0_18px_44px_-18px_rgba(0,0,0,0.92),0_0_0_1px_rgba(0,0,0,0.85),inset_0_1px_0_rgba(255,255,255,0.035)] transition-all duration-[333ms] hover:-translate-y-0.5 hover:border-brand-accent/50 motion-reduce:transition-none motion-reduce:hover:translate-y-0';

// The USDOT / MC# authority identifiers render as styled pills (enumerable values
// are pills, never plain inline text) — same accent-pill treatment as the live tracker.
const pillClass =
  'inline-flex items-center rounded-full border border-brand-accent/30 bg-brand-accent/10 px-2.5 py-0.5 font-mono text-xs font-medium text-brand-accent transition-all duration-[333ms] hover:-translate-y-0.5 hover:bg-brand-accent/20 motion-reduce:transition-none motion-reduce:hover:translate-y-0';

export interface EeatStripProps {
  readonly variant?: 'home' | 'city' | 'service';
  readonly cityName?: string;
  readonly serviceName?: string;
}

export function EeatStrip({ variant = 'home', cityName, serviceName }: EeatStripProps) {
  useThemeToolsSurface('eeat-strip');
  // Keep a mirror-locale visitor in /es · /pt: localize internal `/` hrefs.
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const lp = (p: string) => (p.startsWith('/') ? localizedPath(locale, p) : p);
  const copy = eeatStripCopy(locale);
  const scope =
    variant === 'city' && cityName
      ? `${copy.scopeCityPre}${cityName}`
      : variant === 'service' && serviceName
        ? `${copy.scopeServicePre}${serviceName.toLowerCase()}`
        : copy.scopeDefault;
  const [experience, expertise, authority, trust] = copy.cards;

  return (
    <ThemeToolsPageSurface
      as="section"
      surface="eeat-strip"
      aria-labelledby="eeat-heading"
      className="section-tight"
      data-component="eeat-strip"
    >
      <div className="container-pad max-w-5xl">
        <Card className="rounded-2xl border border-black/85 bg-[#0c1017] p-6 sm:p-8 shadow-[0_26px_64px_-22px_rgba(0,0,0,0.92),0_0_0_1px_rgba(0,0,0,0.9),inset_0_1px_0_rgba(255,255,255,0.035)]">
          <p className="eyebrow mb-3">
            {copy.eyebrowPre}
            {scope}
          </p>
          <h2 id="eeat-heading" className="text-2xl sm:text-3xl font-extrabold mb-5">
            {copy.titlePre}
            <span className="text-gradient">{copy.titleAccent}</span>
          </h2>
          <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4 text-sm">
            <li className={cardClass}>
              <p className="font-mono text-[10px] uppercase tracking-widest text-brand-accent">
                {experience.label}
              </p>
              <p className="mt-2 font-display text-base font-bold text-brand-ink">
                {experience.value}
              </p>
              <p className="mt-1 text-xs text-brand-mute leading-relaxed">{experience.body}</p>
            </li>
            <li className={cardClass}>
              <p className="font-mono text-[10px] uppercase tracking-widest text-brand-accent">
                {expertise.label}
              </p>
              <p className="mt-2 font-display text-base font-bold text-brand-ink">
                {expertise.value}
              </p>
              <p className="mt-1 text-xs text-brand-mute leading-relaxed">{expertise.body}</p>
            </li>
            <li className={cardClass}>
              <p className="font-mono text-[10px] uppercase tracking-widest text-brand-accent">
                {authority.label}
              </p>
              <p className="mt-2 flex flex-wrap gap-1.5">
                <span data-eeat="usdot" className={pillClass}>
                  USDOT {copy.pendingWord}
                </span>
                <span data-eeat="mc" className={pillClass}>
                  MC# {copy.pendingWord}
                </span>
              </p>
              <p className="mt-1 text-xs text-brand-mute leading-relaxed">{authority.body}</p>
            </li>
            <li className={cardClass}>
              <p className="font-mono text-[10px] uppercase tracking-widest text-brand-accent">
                {trust.label}
              </p>
              <p className="mt-2 font-display text-base font-bold text-brand-ink">{trust.value}</p>
              <p className="mt-1 text-xs text-brand-mute leading-relaxed">{trust.body}</p>
            </li>
          </ul>
          <p className="mt-5 text-xs font-mono text-brand-mute">
            {copy.reviewedPre}
            <time dateTime={REVIEWED}>{REVIEWED}</time>
            {copy.reviewedByPre}
            <a
              href="https://linkedin.com/in/brianzalewski"
              target="_blank"
              rel="noopener noreferrer"
              className="text-brand-accent underline-hover"
            >
              Brian Zalewski
            </a>
            {copy.reviewedRole}
            <a href={lp('/sources')} className="text-brand-accent underline-hover">
              {copy.citationList}
            </a>
            {copy.andSep}
            <a href={lp('/#about')} className="text-brand-accent underline-hover">
              {copy.ownerBio}
            </a>
            {copy.reviewedPost}
          </p>
        </Card>
      </div>
    </ThemeToolsPageSurface>
  );
}
