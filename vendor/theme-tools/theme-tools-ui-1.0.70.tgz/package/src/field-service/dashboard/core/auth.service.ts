import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { WAVE4_PARTNER_SPECS } from '@theme.tools/integrations/field-service-partner-adapters';
/**
 * AuthService — session-cookie-backed identity for the dashboard SPA.
 *
 * The Worker sets `bcl_cust_sid` or `bcl_work_sid` (HttpOnly), so the browser
 * cannot read the token. We rely on `GET /api/auth/whoami` to hydrate the
 * client-side identity signal at app boot and after auth-mutating actions.
 *
 * CONTRACT NOTE (fixed 2026-06-03): the worker returns a NESTED envelope
 * `{ ok: true, whoami: { role, view_as, tenant_id, displayName, email, workerId,
 * isSuperAdmin, … } }` — NOT a flat `AuthWhoami`. The prior implementation
 * spread the top-level body, so `role`/`authenticated`/`tenantId`/`userId` were
 * always undefined → the role-switcher, X-View-As header, tenant seed, and
 * account menu silently degraded to "Guest". `mapWhoami()` now parses the real
 * shape. (React's UnifiedDashboard already reads `{ ok, whoami }`, so the worker
 * response is unchanged — the drift was purely client-side.)
 */
import { HttpClient } from '@angular/common/http';
import { Injectable, computed, inject, signal } from '@angular/core';
import { firstValueFrom } from 'rxjs';

export type DashboardRole = 'customer' | 'crew' | 'super_admin';

export interface AuthWhoami {
  readonly userId: string | null;
  readonly email: string | null;
  readonly displayName: string | null;
  readonly role: DashboardRole | null;
  readonly tenantId: string | null;
  readonly viewAs: DashboardRole | null;
  /**
   * The dashboard personas this identity may switch between. A single-role user
   * holds exactly one; a dual customer+crew holds two; a super-admin holds all
   * three (they can walk in any persona's shoes via view-as). Drives whether the
   * navbar role-switcher renders (>1 = show it). Mapped from the worker's
   * `roles[]` (admin + super_admin both collapse to the `super_admin` persona).
   */
  readonly availableRoles: readonly DashboardRole[];
  readonly authenticated: boolean;
}

/** The worker's nested whoami snapshot (subset we consume). */
interface WhoamiSnap {
  role?: string | null;
  roles?: string[] | null;
  view_as?: string | null;
  tenant_id?: string | null;
  displayName?: string | null;
  email?: string | null;
  workerId?: string | null;
  isSuperAdmin?: boolean;
}

export const EMPTY_WHOAMI: AuthWhoami = {
  userId: null,
  email: null,
  displayName: null,
  role: null,
  tenantId: null,
  viewAs: null,
  availableRoles: [],
  authenticated: false,
};

/** The full switchable persona set a super-admin gets. Order = display order. */
const ALL_ROLES: readonly DashboardRole[] = ['customer', 'crew', 'super_admin'];

/**
 * Pure: map the worker's `roles[]` (`customer|crew|admin|super_admin`) onto the
 * dashboard's 3-persona space, deduped + in display order. A super-admin is
 * always granted the FULL set (they can view-as anyone); everyone else gets only
 * the personas they actually hold. Absent/garbled → derived from `role`.
 */
function mapAvailableRoles(snap: WhoamiSnap, primary: DashboardRole | null): DashboardRole[] {
  if (snap.isSuperAdmin || primary === 'super_admin') return [...ALL_ROLES];
  const raw = Array.isArray(snap.roles) ? snap.roles : [];
  const mapped = raw.map((r) => mapRole(r)).filter((r): r is DashboardRole => r !== null);
  const set = new Set<DashboardRole>(mapped);
  if (set.size === 0 && primary) set.add(primary);
  // Return in canonical display order so the switcher is stable.
  return ALL_ROLES.filter((r) => set.has(r));
}

/** Map the worker's role token onto the dashboard's 3-role space. */
function mapRole(raw: string | null | undefined): DashboardRole | null {
  switch (raw) {
    case 'customer':
      return 'customer';
    case 'crew':
      return 'crew';
    case 'admin':
    case 'super_admin':
      return 'super_admin';
    default:
      return null; // 'guest' / unknown / missing
  }
}

/**
 * Pure: map the worker's `{ ok, whoami }` envelope (or a bare snap) onto the
 * flat `AuthWhoami` the dashboard signals expect. Tolerant of the unauth shape
 * and of a missing/garbled body (→ EMPTY_WHOAMI).
 */
export function mapWhoami(body: unknown): AuthWhoami {
  if (!body || typeof body !== 'object') return EMPTY_WHOAMI;
  const env = body as { ok?: boolean; whoami?: WhoamiSnap };
  const snap: WhoamiSnap | undefined = env.whoami ?? (body as WhoamiSnap);
  if (!snap || typeof snap !== 'object') return EMPTY_WHOAMI;

  const role = snap.isSuperAdmin ? 'super_admin' : mapRole(snap.role);
  const viewAs = mapRole(snap.view_as) ?? role;
  const email = typeof snap.email === 'string' ? snap.email : null;
  const userId = email ?? (typeof snap.workerId === 'string' ? snap.workerId : null);
  // An unauthenticated (guest/unknown) snap has no switchable roles.
  const availableRoles = role === null ? [] : mapAvailableRoles(snap, role);

  return {
    userId,
    email,
    displayName: typeof snap.displayName === 'string' ? snap.displayName : null,
    role,
    tenantId: typeof snap.tenant_id === 'string' ? snap.tenant_id : null,
    viewAs,
    availableRoles,
    authenticated: role !== null,
  };
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);

  readonly whoami = signal<AuthWhoami>(EMPTY_WHOAMI);
  readonly authenticated = computed(() => this.whoami().authenticated);
  readonly displayName = computed(
    () => this.whoami().displayName ?? this.whoami().email ?? 'Guest',
  );

  /** Guards against overlapping whoami fetches when several events fire together. */
  private hydrating: Promise<void> | null = null;
  private hydrateSeq = 0;
  /** Ensures the focus/visibility/pageshow listeners are wired at most once. */
  private autoRehydrateWired = false;

  /**
   * Re-fetch `/api/auth/whoami` and update the identity signal. Concurrent calls
   * share one in-flight request so a burst of focus/visibility events issues a
   * single fetch. A network/parse failure resets to the unauthenticated snapshot.
   */
  async hydrate(options?: { force?: boolean }): Promise<void> {
    if (this.hydrating && !options?.force) return this.hydrating;
    const seq = ++this.hydrateSeq;
    let run: Promise<void> | null = null;
    run = (async () => {
      try {
        const body = await firstValueFrom(
          this.http.get<unknown>('/api/auth/whoami', { withCredentials: true }),
        );
        if (seq === this.hydrateSeq) {
          this.whoami.set(mapWhoami(body));
        }
      } catch {
        if (seq === this.hydrateSeq) {
          this.whoami.set(EMPTY_WHOAMI);
        }
      } finally {
        if (this.hydrating === run) {
          this.hydrating = null;
        }
      }
    })();
    this.hydrating = run;
    return run;
  }

  /**
   * Re-hydrate identity whenever the tab regains focus / becomes visible / is
   * restored from the bfcache.
   *
   * WHY (root cause of the "Guest after login" report): sign-in happens on the
   * SEPARATE React `/login` + `/me` surface, then the user returns to this
   * Angular `/dashboard` SPA. The awaited app-initializer hydrates whoami ONCE at
   * cold boot; a `/dashboard` instance that was already mounted (or restored from
   * bfcache after the cross-SPA round-trip) kept its stale `EMPTY_WHOAMI` → the
   * account menu showed "Guest" and every feature 401'd into a "Sign in" empty
   * state even though the `bcl_cust_sid` cookie was now set. Re-hydrating on
   * focus/visibility/pageshow makes the dashboard pick up a session established
   * elsewhere WITHOUT a hard reload. The server's whoami remains the sole
   * authority — this never widens access, it only refreshes the client snapshot.
   *
   * Idempotent: safe to call more than once (listeners wired at most once).
   * No-op outside a browser (SSR guard), though this SPA is client-only today.
   */
  startAutoRehydrate(): void {
    if (this.autoRehydrateWired) return;
    if (typeof document === 'undefined' || typeof window === 'undefined') return;
    this.autoRehydrateWired = true;

    const refresh = (): void => {
      void this.hydrate();
    };

    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') refresh();
    });
    window.addEventListener('focus', refresh);
    // `pageshow` with `persisted` fires when the page is restored from the
    // back/forward cache (the common path back from the React /login → /me flow).
    window.addEventListener('pageshow', (e) => {
      if ((e as PageTransitionEvent).persisted) {
        this.whoami.set(EMPTY_WHOAMI);
        void this.hydrate({ force: true });
      }
    });
  }

  async signOut(): Promise<void> {
    try {
      await firstValueFrom(this.http.post('/api/auth/signout', {}, { withCredentials: true }));
    } finally {
      this.whoami.set(EMPTY_WHOAMI);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'auth-service',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
