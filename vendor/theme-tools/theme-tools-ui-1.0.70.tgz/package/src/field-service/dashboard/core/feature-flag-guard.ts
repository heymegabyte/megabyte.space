import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { WAVE4_PARTNER_SPECS } from '@theme.tools/integrations/field-service-partner-adapters';
/**
 * feature-flag-guard.ts — Angular CanActivate guard that 404s any lazy route
 * when its owning feature flag is off.
 *
 * Usage in app.routes.ts:
 *
 *   {
 *     path: 'crew/payout',
 *     canActivate: [featureFlagGuard('instant_payout_rtp')],
 *     loadComponent: () => import('./features/crew/payout-request.component').then(m => m.PayoutRequestComponent),
 *   }
 *
 * The flag MUST reference a live (migration-seeded) key — a route guarded by a
 * DELETED flag is dark-forever (the guard always denies). The
 * `validate-orphaned-flag-guards.mjs` build gate enforces this.
 *
 * If the flag is off, the guard redirects to '/' (route doesn't exist from
 * the user's perspective) — never 403 per [[feature-flags]] § Anti-patterns.
 */

import { CanActivateFn, CanMatchFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { FeatureFlagService } from './feature-flag.service';

export function featureFlagGuard(key: string): CanActivateFn {
  return async () => {
    const flagSvc = inject(FeatureFlagService);
    const router = inject(Router);
    const flags = await firstValueFrom(flagSvc.flags$);
    if (flags[key]) return true;
    router.navigate(['/']);
    return false;
  };
}

/**
 * CanMatch variant — returns false (WITHOUT redirecting) so the router falls
 * THROUGH to the next same-path route when the flag is off. Use when a
 * flag-gated route shares its path with a fallback route (e.g. the new
 * crew_job_detail_v2 `/jobs/:id` sitting in front of the legacy JobTracking
 * `/jobs/:id`): flag on → the new page matches; flag off → it declines the
 * match and the legacy route serves instead. featureFlagGuard (CanActivate)
 * can't do this — a denied activation blocks the URL rather than trying the
 * next route.
 */
export function featureFlagCanMatch(key: string): CanMatchFn {
  return async () => {
    const flagSvc = inject(FeatureFlagService);
    const flags = await firstValueFrom(flagSvc.flags$);
    return Boolean(flags[key]);
  };
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'feature-flag-guard',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_PARTNER_SPECS_COUNT = Object.keys(WAVE4_PARTNER_SPECS).length;
