import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { WAVE4_PARTNER_SPECS } from '@theme.tools/integrations/field-service-partner-adapters';
/**
 * feature-flag.service.ts — Angular 21 signal-driven feature flag service.
 *
 * Per the [[rxjs-first-angular]] rule: HTTP returns Observable<T>, signals
 * are bridged at the template/component boundary via toSignal(). The service
 * exposes:
 *   - flags$           — Observable<Record<string, boolean>> for compose
 *   - flags()          — Signal<Record<string, boolean>> for templates
 *   - isOn(key)        — Signal<boolean> for single-flag templates
 *   - refresh()        — re-fetch (call after admin mutation)
 *
 * Auto-refresh every 60s. `refresh()` pushes a "now" tick into the trigger
 * subject so the stream re-fetches immediately AND continues the 60s cadence
 * afterwards. Without the trigger merged in, the original `nudge` signal was
 * dead code and `refresh()` was a no-op.
 *
 * Pair with FeatureFlagGuard (CanActivate) at the route level to gate
 * lazy-loaded feature dirs.
 */

import { Injectable, computed, inject } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { HttpClient } from '@angular/common/http';
import {
  Observable,
  Subject,
  catchError,
  map,
  merge,
  of,
  shareReplay,
  startWith,
  switchMap,
  timer,
} from 'rxjs';

type FlagMap = Record<string, boolean>;

@Injectable({ providedIn: 'root' })
export class FeatureFlagService {
  private readonly http = inject(HttpClient);
  private readonly nudge$ = new Subject<void>();

  /**
   * Observable stream — `merge(timer60s, nudge)` triggers a fetch. The 60s
   * timer fires `0, 60_000, 120_000…`. `nudge$` is a manual ping from
   * `refresh()`. Both feed `switchMap → fetchOnce`. `shareReplay({refCount:
   * false})` keeps the stream warm across navigations so the guard doesn't
   * pay a fresh fetch on every route activation.
   */
  readonly flags$: Observable<FlagMap> = merge(
    timer(0, 60_000).pipe(map(() => null)),
    this.nudge$.pipe(map(() => null)),
  ).pipe(
    startWith(null),
    switchMap(() => this.fetchOnce$()),
    shareReplay({ bufferSize: 1, refCount: false }),
  );

  /** Signal at template boundary — never inside services per [[rxjs-first-angular]]. */
  readonly flags = toSignal(this.flags$, { initialValue: {} as FlagMap });

  /** Single-flag accessor. Memoized via computed(). */
  isOn(key: string) {
    return computed(() => Boolean(this.flags()[key]));
  }

  /** Trigger an immediate re-fetch. Used after admin flag mutations. */
  refresh(): void {
    this.nudge$.next();
  }

  private fetchOnce$(): Observable<FlagMap> {
    return this.http.get<{ ok: boolean; flags: FlagMap }>('/api/feature-flags').pipe(
      map((r) => r?.flags ?? {}),
      catchError(() => of({} as FlagMap)),
    );
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'feature-flag-service',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
