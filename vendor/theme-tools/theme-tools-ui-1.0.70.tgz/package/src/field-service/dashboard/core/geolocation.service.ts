import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { WAVE4_PARTNER_SPECS } from '@theme.tools/integrations/field-service-partner-adapters';
/**
 * GeolocationService — battery-aware GPS streaming for crew workers.
 *
 * Throttle rules:
 *   - battery <10% OR not charging + <20%: emit every 60s
 *   - battery <20%: emit every 30s
 *   - charging: emit every 5s
 *   - otherwise: emit every 10s
 *
 * Distance filter: drop any update <10m from the last emitted position.
 *
 * Signals: `position`, `error`, `isStreaming`. Methods: `start()`, `stop()`.
 */
import { Injectable, signal } from '@angular/core';

export interface CrewPosition {
  readonly lat: number;
  readonly lng: number;
  readonly heading: number | null;
  readonly speed: number | null;
  readonly accuracy: number;
  readonly battery: number | null;
  readonly charging: boolean | null;
  readonly ts: number;
}

interface BatteryLike {
  readonly level: number;
  readonly charging: boolean;
  addEventListener?(type: string, listener: () => void): void;
}

@Injectable({ providedIn: 'root' })
export class GeolocationService {
  readonly position = signal<CrewPosition | null>(null);
  readonly error = signal<string | null>(null);
  readonly isStreaming = signal<boolean>(false);

  private watchId: number | null = null;
  private throttleTimer: ReturnType<typeof setInterval> | null = null;
  private latestRaw: CrewPosition | null = null;
  private lastEmitted: CrewPosition | null = null;
  private battery: BatteryLike | null = null;
  private onEmit: ((p: CrewPosition) => void) | null = null;

  /** Start streaming. `onEmit` fires whenever a throttled+distance-filtered point is ready. */
  async start(onEmit?: (p: CrewPosition) => void): Promise<void> {
    if (this.isStreaming()) return;
    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      this.error.set('Geolocation API not available');
      return;
    }
    this.onEmit = onEmit ?? null;
    this.error.set(null);

    // Wire battery if available; ignore failures (Safari + most desktop browsers don't expose it).
    try {
      const nav = navigator as Navigator & { getBattery?: () => Promise<BatteryLike> };
      if (nav.getBattery) {
        this.battery = await nav.getBattery();
        const refresh = () => this.restartTicker();
        this.battery?.addEventListener?.('levelchange', refresh);
        this.battery?.addEventListener?.('chargingchange', refresh);
      }
    } catch {
      this.battery = null;
    }

    this.watchId = navigator.geolocation.watchPosition(
      (pos) => {
        this.latestRaw = {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          heading: Number.isFinite(pos.coords.heading) ? pos.coords.heading : null,
          speed: Number.isFinite(pos.coords.speed) ? pos.coords.speed : null,
          accuracy: pos.coords.accuracy,
          battery: this.battery ? Math.round(this.battery.level * 100) : null,
          charging: this.battery ? this.battery.charging : null,
          ts: Date.now(),
        };
        this.position.set(this.latestRaw);
      },
      (err) => this.error.set(err.message),
      { enableHighAccuracy: true, maximumAge: 5_000, timeout: 30_000 },
    );

    this.isStreaming.set(true);
    this.restartTicker();
  }

  stop(): void {
    if (this.watchId !== null && typeof navigator !== 'undefined') {
      navigator.geolocation.clearWatch(this.watchId);
    }
    this.watchId = null;
    if (this.throttleTimer) clearInterval(this.throttleTimer);
    this.throttleTimer = null;
    this.isStreaming.set(false);
    this.position.set(null);
    this.latestRaw = null;
    this.lastEmitted = null;
  }

  private restartTicker(): void {
    if (this.throttleTimer) clearInterval(this.throttleTimer);
    const intervalMs = this.computeIntervalMs();
    this.throttleTimer = setInterval(() => this.maybeEmit(), intervalMs);
  }

  private computeIntervalMs(): number {
    if (this.battery?.charging) return 5_000;
    const level = this.battery ? this.battery.level : 1;
    if (level < 0.1) return 60_000;
    if (level < 0.2) return 30_000;
    return 10_000;
  }

  private maybeEmit(): void {
    const next = this.latestRaw;
    if (!next) return;
    if (this.lastEmitted) {
      const m = haversineMeters(this.lastEmitted.lat, this.lastEmitted.lng, next.lat, next.lng);
      if (m < 10) return;
    }
    this.lastEmitted = next;
    this.onEmit?.(next);
  }
}

function haversineMeters(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6_371_000;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'geolocation-service',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_PARTNER_SPECS_COUNT = Object.keys(WAVE4_PARTNER_SPECS).length;
