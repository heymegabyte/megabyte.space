import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { WAVE4_PARTNER_SPECS } from '@theme.tools/integrations/field-service-partner-adapters';
/**
 * PastBookingsService — GP-08 unified "Past" history data layer
 * (flag: past_bookings_unified).
 *
 * A dual-role person (customer AND crew, per whoami roles) has TWO separate
 * histories today: their booked jobs (GET /api/customer/jobs?filter=past) and
 * the gigs they WORKED as crew (GET /api/work/gigs → .completed[]). GP-08
 * interweaves both into ONE reverse-chronological list where each row carries a
 * role badge — "as Customer" (they hired the crew) or "as Crew" (they were the
 * crew) — so the same page serves both personas with one simple design.
 *
 * No new worker endpoint: both source endpoints already exist, are self-scoped
 * to the caller's own session (customer cookie / worker cookie), and return the
 * shapes we need — so we fetch both and merge client-side (simplest approach;
 * never widens access). Each branch is fetched ONLY when the caller can have it:
 * the customer branch when authenticated, the crew branch when the active
 * persona is crew (or a super-admin viewing crew). A 401/404 on either branch
 * degrades that branch to empty (the other still renders) — never a crash.
 *
 * Per [[rxjs-first-angular]]: HttpClient returns Observable<T>; signals are
 * bridged at the component boundary, never inside the service.
 */
import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, catchError, forkJoin, map, of } from 'rxjs';

/** Which role a past entry was performed as. */
export type PastRole = 'customer' | 'crew';

/** One unified past-history row — same shape regardless of source role. */
export interface PastBookingRow {
  /** Stable per-source id: booking id (customer) or gig id (crew). */
  readonly id: string;
  /** Which persona this entry belongs to — drives the badge + the tap target. */
  readonly role: PastRole;
  /** Sort key + display date: epoch ms of the job (completed/scheduled). */
  readonly whenMs: number;
  /** Human service label (e.g. "Junk removal", or a street address for crew). */
  readonly service: string;
  /** Secondary line — city (customer) or the served address (crew). */
  readonly subtitle: string;
  /** Money for THIS role: what the customer paid, or what the crew earned. */
  readonly amountCents: number;
  /** Contextual money caption ("Paid" vs "Earned"). */
  readonly amountLabel: string;
  /** Wire status → statusBadge() maps it to a Spartan variant + label. */
  readonly status: string;
}

/** Normalized load result the component renders — never throws. */
export interface PastBookingsResult {
  readonly ok: boolean;
  readonly items: readonly PastBookingRow[];
  /** 'unauthorized' when neither branch was reachable due to auth; else ''. */
  readonly error: string;
}

/** Wire shape of a customer past booking (subset of GET /api/customer/jobs). */
interface CustomerPastRow {
  readonly id: string;
  readonly service?: string;
  readonly preferredDate?: string;
  readonly completedAt?: string | null;
  readonly customerVisibleAt?: string | null;
  readonly totalCents?: number;
  readonly status?: string;
  readonly city?: string;
  readonly address?: string;
}
interface CustomerJobsEnvelope {
  readonly ok?: boolean;
  readonly items?: readonly CustomerPastRow[];
}

/** Wire shape of a crew completed gig (GET /api/work/gigs → .completed[]). */
interface CrewCompletedRow {
  readonly id: string;
  readonly start_at?: string | null;
  readonly service_address?: string | null;
  readonly earnings_cents?: number;
  readonly tip_cents?: number;
  readonly check_out_at?: string | null;
}
interface WorkGigsEnvelope {
  readonly completed?: readonly CrewCompletedRow[];
}

/** Pure: SQL/ISO date-time (or `undefined`) → epoch ms, 0 when unparseable. */
export function toEpochMs(value: string | null | undefined): number {
  if (!value) return 0;
  const t = Date.parse(value);
  return Number.isFinite(t) ? t : 0;
}

/** Pure: map a customer past-booking wire row → a unified row (role=customer). */
export function customerToRow(r: CustomerPastRow): PastBookingRow {
  const whenMs = toEpochMs(r.completedAt ?? r.customerVisibleAt ?? r.preferredDate);
  return {
    id: r.id,
    role: 'customer',
    whenMs,
    service: r.service?.trim() || 'Crew visit',
    subtitle: [r.address, r.city].filter(Boolean).join(', ') || 'Brick Labor',
    amountCents: Math.max(0, Math.round(r.totalCents ?? 0)),
    amountLabel: 'Paid',
    status: r.status ?? 'completed',
  };
}

/** Pure: map a crew completed-gig wire row → a unified row (role=crew). */
export function crewToRow(r: CrewCompletedRow): PastBookingRow {
  const whenMs = toEpochMs(r.check_out_at ?? r.start_at);
  const earned = Math.max(0, Math.round((r.earnings_cents ?? 0) + (r.tip_cents ?? 0)));
  return {
    id: r.id,
    role: 'crew',
    whenMs,
    service: r.service_address?.trim() || 'Crew gig',
    subtitle: 'Worked as crew',
    amountCents: earned,
    amountLabel: 'Earned',
    status: 'completed',
  };
}

/** Pure: merge both source lists into ONE reverse-chronological list. */
export function mergePast(
  customer: readonly PastBookingRow[],
  crew: readonly PastBookingRow[],
): readonly PastBookingRow[] {
  return [...customer, ...crew].sort((a, b) => b.whenMs - a.whenMs);
}

@Injectable({ providedIn: 'root' })
export class PastBookingsService {
  private readonly http = inject(HttpClient);

  /**
   * Fetch + merge the caller's past history. Callers pass which branches the
   * signed-in persona can actually have so we never fire an endpoint that would
   * 401 (a super-admin has no worker cookie; a signed-out visitor has neither).
   *
   * @param includeCustomer fetch the customer past-bookings branch
   * @param includeCrew     fetch the crew completed-gigs branch
   */
  history$(includeCustomer: boolean, includeCrew: boolean): Observable<PastBookingsResult> {
    const customer$: Observable<readonly PastBookingRow[]> = includeCustomer
      ? this.http
          .get<CustomerJobsEnvelope>('/api/customer/jobs?filter=past', { withCredentials: true })
          .pipe(
            map((r) => (r?.items ?? []).map(customerToRow)),
            catchError(() => of<readonly PastBookingRow[]>([])),
          )
      : of<readonly PastBookingRow[]>([]);

    const crew$: Observable<readonly PastBookingRow[]> = includeCrew
      ? this.http
          .get<WorkGigsEnvelope>('/api/work/gigs', { withCredentials: true })
          .pipe(
            map((r) => (r?.completed ?? []).map(crewToRow)),
            catchError(() => of<readonly PastBookingRow[]>([])),
          )
      : of<readonly PastBookingRow[]>([]);

    return forkJoin([customer$, crew$]).pipe(
      map(([customer, crew]): PastBookingsResult => {
        const items = mergePast(customer, crew);
        return { ok: true, items, error: '' };
      }),
      catchError(() =>
        of<PastBookingsResult>({ ok: false, items: [], error: 'unauthorized' }),
      ),
    );
  }
}

/** Pure: cents → "$1,234" (whole-dollar, tabular-friendly). */
export function pastMoney(cents: number | null | undefined): string {
  return '$' + Math.max(0, Math.round((cents ?? 0) / 100)).toLocaleString('en-US');
}

/**
 * Pure: epoch ms → "Sep 12, 2026" (empty when 0/unknown). strictTemplates-safe.
 */
export function pastDate(whenMs: number): string {
  if (!whenMs) return 'Date unavailable';
  return new Date(whenMs).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

/**
 * Pure: role → the SPA detail route for a row. Customer past bookings open the
 * booking detail (/bookings/:id); crew gigs open the live/job detail
 * (/jobs/:id). Returned as a routerLink array.
 */
export function pastDetailLink(row: PastBookingRow): readonly string[] {
  return row.role === 'crew' ? ['/jobs', row.id] : ['/bookings', row.id];
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'past-bookings-service',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_PARTNER_SPECS_COUNT = Object.keys(WAVE4_PARTNER_SPECS).length;
