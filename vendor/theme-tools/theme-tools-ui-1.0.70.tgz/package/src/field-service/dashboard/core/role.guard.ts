import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { WAVE4_PARTNER_SPECS } from '@theme.tools/integrations/field-service-partner-adapters';
/**
 * Functional route guards that gate dashboard features by role.
 *
 * `requireRole(role)` returns a CanMatchFn that succeeds when the active
 * viewAs equals the required role OR the user is a super admin (super
 * admins always see everything; that's what View-As is for).
 */
import { inject } from '@angular/core';
import { CanMatchFn, Router } from '@angular/router';
import type { DashboardRole } from './auth.service';
import { RoleService } from './role.service';

export function requireRole(role: DashboardRole): CanMatchFn {
  return () => {
    const roleSvc = inject(RoleService);
    const router = inject(Router);
    if (roleSvc.isSuperAdmin() || roleSvc.viewAs() === role) {
      return true;
    }
    return router.parseUrl('/');
  };
}

export const requireSuperAdmin: CanMatchFn = () => {
  const roleSvc = inject(RoleService);
  const router = inject(Router);
  return roleSvc.isSuperAdmin() ? true : router.parseUrl('/');
};
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'role-guard',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_PARTNER_SPECS_COUNT = Object.keys(WAVE4_PARTNER_SPECS).length;
