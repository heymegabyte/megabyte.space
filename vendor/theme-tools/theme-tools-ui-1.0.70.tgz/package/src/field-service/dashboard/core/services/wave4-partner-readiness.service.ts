import { Injectable } from '@angular/core';
import {
  WAVE4_PARTNER_SPECS,
  evaluateAllWave4Partners,
  evaluateWave4PartnerReadiness,
  type Wave4PartnerFlagKey,
  type Wave4ReadinessResult,
} from '@theme.tools/integrations/field-service-partner-adapters';
import {
  buildComprehensiveCategoryDiagnostic,
  buildCustomerPrepChecklist,
  calculatePackingMaterials,
  calculateSurfaceProtectionKit,
  evaluateCrewArrivalVerification,
  evaluateCurbAndParkingClearance,
  type ComprehensiveCategoryDiagnostic,
  type ComprehensiveCategoryDiagnosticOptions,
  type CrewArrivalVerificationInput,
  type CrewArrivalVerificationResult,
  type CurbClearanceEvaluation,
  type CustomerPrepChecklistPlan,
  type PackingMaterialEstimate,
  type SurfaceProtectionKit,
} from '@theme.tools/scheduling/field-service/theme-tools-field-service-bridge';
import {
  auditFullPlatformStandards,
  type FullPlatformStandardsAudit,
} from '@theme-tools/shared-utils/field-service/theme-tools-platform-suite';
import {
  evaluateAgentSkillsConformance,
  evaluateCategorySkillMatrix,
  type AgentSkillsConformanceEvaluation,
  type AgentSkillsConformanceInput,
  type CategorySkillMatrixSummary,
} from '@theme-tools/shared-utils/field-service/agent-skills-matrix';

@Injectable({ providedIn: 'root' })
export class Wave4PartnerReadinessService {
  readonly specs = WAVE4_PARTNER_SPECS;

  evaluatePartner(
    flagKey: Wave4PartnerFlagKey,
    flagEnabled: boolean,
    allowSimulation = true,
  ): Wave4ReadinessResult {
    return evaluateWave4PartnerReadiness(flagKey, {
      flagEnabled,
      allowSimulation,
      env: {},
    });
  }

  evaluateCategoryPartners(
    categorySlug: string,
    enabledFlags: Partial<Record<Wave4PartnerFlagKey, boolean>> = {},
  ): Wave4ReadinessResult[] {
    return evaluateAllWave4Partners(enabledFlags, {}, true).filter(
      (res) => this.specs[res.flagKey].categorySlug === categorySlug,
    );
  }

  getPartnerSpec(flagKey: Wave4PartnerFlagKey) {
    return this.specs[flagKey];
  }

  getRequiredEnvVars(flagKey: Wave4PartnerFlagKey): readonly string[] {
    return this.specs[flagKey].requiredEnvVars;
  }

  getFallbackSummary(flagKey: Wave4PartnerFlagKey): string {
    return this.specs[flagKey].failClosedFallbackSummary;
  }

  getConsumerCompatibilityMatrix(): {
    reactWeb: boolean;
    angularDashboard: boolean;
    cloudflareWorkers: boolean;
    totalCategories: number;
  } {
    return {
      reactWeb: true,
      angularDashboard: true,
      cloudflareWorkers: true,
      totalCategories: 9,
    };
  }

  getAllPartnerKeys(): Wave4PartnerFlagKey[] {
    return Object.keys(this.specs) as Wave4PartnerFlagKey[];
  }

  getCustomerPrepChecklist(
    categorySlug: string,
    cityOrMunicipality = 'Newark',
    hasDriveway = false,
  ): CustomerPrepChecklistPlan {
    return buildCustomerPrepChecklist(categorySlug, cityOrMunicipality, hasDriveway);
  }

  evaluateCurbClearance(
    categorySlug: string,
    cityOrMunicipality = 'Newark',
    hasDriveway = false,
  ): CurbClearanceEvaluation {
    return evaluateCurbAndParkingClearance({
      categorySlug,
      cityOrMunicipality,
      hasDriveway,
    });
  }

  evaluateArrivalVerification(input: CrewArrivalVerificationInput): CrewArrivalVerificationResult {
    return evaluateCrewArrivalVerification(input);
  }

  calculateSurfaceProtection(
    flooringType: 'hardwood' | 'marble-stone' | 'carpet' | 'tile-vinyl',
    flightsOfStairs: number,
    doorwayCount: number,
  ): SurfaceProtectionKit {
    return calculateSurfaceProtectionKit({
      flooringType,
      flightsOfStairs,
      doorwayCount,
    });
  }

  calculatePackingKit(bedroomCount: number, fragileKitchenLoad = false): PackingMaterialEstimate {
    return calculatePackingMaterials({
      bedroomCount,
      fragileKitchenLoad,
    });
  }

  /**
   * Computes the full 9-category @theme.tools engineering diagnostic bundle
   * (elevator window capacity, 60/40 axle load balance, spigot GPM & PSI drop,
   * historic plaster fastener protocol, turf renovation, turnover SLA, and
   * paint-prep moisture/dew-point gate) at $50/hr per crew member.
   */
  getComprehensiveCategoryDiagnostic(
    categorySlug: string,
    options: ComprehensiveCategoryDiagnosticOptions = {},
  ): ComprehensiveCategoryDiagnostic {
    return buildComprehensiveCategoryDiagnostic(categorySlug, options);
  }

  auditPlatformStandards(
    categorySlug = 'moving-labor',
    cityOrMunicipality = 'Newark',
  ): FullPlatformStandardsAudit {
    return auditFullPlatformStandards(categorySlug, cityOrMunicipality);
  }

  auditAgentSkillsMatrix(
    input: AgentSkillsConformanceInput = {},
  ): AgentSkillsConformanceEvaluation {
    return evaluateAgentSkillsConformance(input);
  }

  getCategorySkillMatrix(categorySlug: string): CategorySkillMatrixSummary {
    return evaluateCategorySkillMatrix(categorySlug);
  }
}
