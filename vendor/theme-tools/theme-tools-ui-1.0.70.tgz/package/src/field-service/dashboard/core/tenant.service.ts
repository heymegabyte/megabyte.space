import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { WAVE4_PARTNER_SPECS } from '@theme.tools/integrations/field-service-partner-adapters';
/**
 * TenantService — exposes the active tenant for multi-tenant routing + headers.
 *
 * For B2B accounts (commercial properties / property managers) a single user
 * may belong to several tenants. The chosen one feeds the `X-Tenant-Id`
 * header via the http interceptor.
 */
import { Injectable, computed, inject, signal } from '@angular/core';
import { AuthService } from './auth.service';

export interface TenantMembership {
  readonly tenantId: string;
  readonly name: string;
  readonly role: 'owner' | 'admin' | 'member' | 'viewer';
}

@Injectable({ providedIn: 'root' })
export class TenantService {
  private readonly auth = inject(AuthService);

  readonly memberships = signal<readonly TenantMembership[]>([]);
  readonly activeTenantId = signal<string | null>(null);
  readonly activeTenant = computed<TenantMembership | null>(() => {
    const id = this.activeTenantId();
    if (!id) return null;
    return this.memberships().find((m) => m.tenantId === id) ?? null;
  });

  hydrate(): void {
    // First call seeds the active tenant from the whoami payload's `tenantId`.
    // Real list of memberships comes from `GET /api/tenants/me` in Wave 26.
    const seed = this.auth.whoami().tenantId;
    if (seed && this.activeTenantId() === null) {
      this.activeTenantId.set(seed);
    }
  }

  setActiveTenant(tenantId: string): void {
    this.activeTenantId.set(tenantId);
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'tenant-service',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_PARTNER_SPECS_COUNT = Object.keys(WAVE4_PARTNER_SPECS).length;
