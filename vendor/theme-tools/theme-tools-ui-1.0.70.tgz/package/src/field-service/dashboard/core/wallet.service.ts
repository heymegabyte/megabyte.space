import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
/**
 * WalletService — GP-09 wallet/balance data layer (flag: wallet_balance_menu).
 *
 * Reads GET /api/wallet/summary — a role-aware, self-scoped balance the worker
 * derives from the SAME money math as the crew payouts + earnings + referral
 * surfaces (never a hardcoded number). Cash-out reuses the existing
 * CrewEarningsService.requestPayout$ (POST /api/crew/payout-instant); this service
 * owns only the read + the customer card-on-file top-up intent.
 *
 * Per [[rxjs-first-angular]]: HTTP returns Observable<T>, retries once, and
 * normalizes errors into a typed result the component renders. 404 (flag off) is
 * surfaced as 'unavailable' so the page shows an empty state, never a crash.
 */
import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, catchError, map, of, retry } from 'rxjs';

/** Crew wallet — mirrors CrewWalletDto in workers/main/src/routes/wallet-summary.ts. */
export interface CrewWallet {
  readonly role: 'crew';
  readonly availableCents: number;
  readonly availableJobs: number;
  readonly postedCents: number;
  readonly weekGrossCents: number;
  readonly weekTipsCents: number;
  readonly weekGigs: number;
  readonly lifetimeCents: number;
  readonly instantFeeCents: number;
  readonly minCashoutCents: number;
  readonly cashoutReady: boolean;
  readonly eligibleGigs: number;
}

/** Customer wallet — mirrors CustomerWalletDto in the worker. */
export interface CustomerWallet {
  readonly role: 'customer';
  readonly creditCents: number;
  readonly lifetimeSpentCents: number;
  readonly bookingsCount: number;
  readonly lastPaymentCents: number;
  readonly lastPaymentAt: string | null;
  readonly hasCardOnFile: boolean;
}

export type Wallet = CrewWallet | CustomerWallet;

/** Normalized result the component renders — never throws. */
export interface WalletResult {
  readonly ok: boolean;
  readonly wallet?: Wallet;
  /** 'unavailable' (flag off / 404), 'unauthorized' (401), or a generic code. */
  readonly error?: string;
}

interface WalletEnvelope {
  ok: boolean;
  wallet?: Wallet;
  error?: string;
}

@Injectable({ providedIn: 'root' })
export class WalletService {
  private readonly http = inject(HttpClient);

  /** Fetch the signed-in user's wallet summary. 404 → 'unavailable' (flag dark). */
  summary$(): Observable<WalletResult> {
    return this.http
      .get<WalletEnvelope>('/api/wallet/summary', { withCredentials: true })
      .pipe(
        retry({ count: 1, delay: 600 }),
        map<WalletEnvelope, WalletResult>((r) => ({
          ok: Boolean(r?.ok),
          wallet: r?.wallet,
          error: r?.ok ? undefined : (r?.error ?? 'wallet_failed'),
        })),
        catchError((err) =>
          of<WalletResult>({
            ok: false,
            error:
              err?.status === 404
                ? 'unavailable'
                : err?.status === 401
                  ? 'unauthorized'
                  : (err?.error?.error ?? 'wallet_failed'),
          }),
        ),
      );
  }
}

/** Pure: cents → "$1,234.56" (tabular-friendly). Exported for template + tests. */
export function formatUsd(cents: number | null | undefined): string {
  const n = Math.max(0, Math.round(cents ?? 0)) / 100;
  return n.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
}

/**
 * Pure: derive the wallet button's headline + sub-stat for a wallet (or a null
 * wallet while loading). strictTemplates-safe — callers pass `wallet ?? null`.
 */
export function walletButtonStats(wallet: Wallet | null | undefined): {
  readonly headline: string;
  readonly label: string;
  readonly sub: string;
} {
  if (!wallet) return { headline: '—', label: 'Wallet', sub: 'View balance' };
  if (wallet.role === 'crew') {
    return {
      headline: formatUsd(wallet.availableCents),
      label: 'Available to cash out',
      sub: `${formatUsd(wallet.weekGrossCents + wallet.weekTipsCents)} this week`,
    };
  }
  return {
    headline: formatUsd(wallet.creditCents),
    label: 'Store credit',
    sub:
      wallet.lifetimeSpentCents > 0
        ? `${formatUsd(wallet.lifetimeSpentCents)} lifetime`
        : 'Add a card',
  };
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'wallet-service',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
