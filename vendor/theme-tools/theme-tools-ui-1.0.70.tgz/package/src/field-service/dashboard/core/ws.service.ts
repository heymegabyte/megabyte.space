import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { WAVE4_PARTNER_SPECS } from '@theme.tools/integrations/field-service-partner-adapters';
/**
 * WsService — generic WebSocket client with exponential backoff reconnect.
 *
 * Exposes both an Observable<MessageEvent> stream (Rx ergonomics) AND a
 * Signal<unknown> that mirrors the latest parsed message body. Caller picks
 * whichever fits the component's reactivity model.
 *
 * Backoff: 1s → 2s → 4s … capped at 30s. Reset on successful open.
 */
import { Injectable, signal, type Signal } from '@angular/core';
import { Observable } from 'rxjs';

export interface WsHandle {
  /** Hot stream of every parsed message event since subscribe time. */
  readonly stream$: Observable<MessageEvent<string>>;
  /** Signal mirroring the latest parsed message body (JSON when possible). */
  readonly latest: Signal<unknown>;
  /** Send a JSON-serialisable payload. Buffered until socket opens. */
  send(payload: unknown): void;
  /** Close the socket + stop reconnecting. */
  close(): void;
  /** True while the underlying socket is OPEN. */
  readonly isOpen: Signal<boolean>;
}

@Injectable({ providedIn: 'root' })
export class WsService {
  connect(url: string): WsHandle {
    const latest = signal<unknown>(null);
    const isOpen = signal<boolean>(false);
    const queue: string[] = [];
    let socket: WebSocket | null = null;
    let attempt = 0;
    let stopped = false;
    let reconnectTimer: ReturnType<typeof setTimeout> | null = null;
    let observerEmit: ((ev: MessageEvent<string>) => void) | null = null;

    const open = (): void => {
      if (stopped) return;
      try {
        socket = new WebSocket(url);
      } catch {
        scheduleReconnect();
        return;
      }
      socket.addEventListener('open', () => {
        attempt = 0;
        isOpen.set(true);
        // Flush queued sends.
        while (queue.length > 0 && socket?.readyState === WebSocket.OPEN) {
          const next = queue.shift();
          if (next) socket.send(next);
        }
      });
      socket.addEventListener('message', (ev) => {
        const data = typeof ev.data === 'string' ? ev.data : '';
        let parsed: unknown = data;
        try {
          parsed = JSON.parse(data);
        } catch {
          // keep raw string
        }
        latest.set(parsed);
        observerEmit?.(ev as MessageEvent<string>);
      });
      socket.addEventListener('close', () => {
        isOpen.set(false);
        if (!stopped) scheduleReconnect();
      });
      socket.addEventListener('error', () => {
        try {
          socket?.close();
        } catch {
          /* noop */
        }
      });
    };

    const scheduleReconnect = (): void => {
      const delay = Math.min(30_000, 1_000 * Math.pow(2, attempt));
      attempt += 1;
      reconnectTimer = setTimeout(open, delay);
    };

    const stream$ = new Observable<MessageEvent<string>>((subscriber) => {
      observerEmit = (ev) => subscriber.next(ev);
      open();
      return () => {
        observerEmit = null;
      };
    });

    return {
      stream$,
      latest,
      isOpen,
      send: (payload: unknown) => {
        const text = typeof payload === 'string' ? payload : JSON.stringify(payload);
        if (socket?.readyState === WebSocket.OPEN) {
          socket.send(text);
        } else {
          queue.push(text);
          if (!socket) open();
        }
      },
      close: () => {
        stopped = true;
        if (reconnectTimer) clearTimeout(reconnectTimer);
        try {
          socket?.close();
        } catch {
          /* noop */
        }
        isOpen.set(false);
      },
    };
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'ws-service',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_PARTNER_SPECS_COUNT = Object.keys(WAVE4_PARTNER_SPECS).length;
