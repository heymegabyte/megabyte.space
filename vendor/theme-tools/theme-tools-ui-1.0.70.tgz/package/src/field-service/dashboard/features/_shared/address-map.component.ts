import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * AddressMapComponent — the Angular twin of the React `src/web/components/AddressMap.tsx`.
 *
 * A stylish, KEYLESS Google Maps panel for any address surface. Emits the classic
 * `maps.google.com/maps?q=…&output=embed` iframe — NO API key required (this repo
 * runs keyless for Google, per [[google-maps-panels]]) — framed on-brand: rounded
 * border + gradient top-accent hairline, a muted grayscale filter that colorises on
 * hover, and a bottom scrim with a pin badge + the address. This is the STATIC
 * destination panel for the smartphone Job Detail page (the live MapLibre puck map
 * is a separate en-route surface). `frame-src https://www.google.com
 * https://maps.google.com` must be allowed in the worker CSP + public/_headers.
 *
 * A11y + resilience: `loading="lazy"` + a `title`; the address is ALWAYS also
 * present as real text (the map is enhancement, never the only source). Guards
 * empty/blank addresses (renders nothing). prefers-reduced-motion disables the
 * hover colorise transition. Selector `app-address-map` matches the golden-path
 * spec's `[data-testid="address-map"] iframe` locator.
 */
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  input,
} from '@angular/core';
import { DomSanitizer, type SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-address-map',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (query(); as q) {
      <div
        data-testid="address-map"
        class="group relative overflow-hidden rounded-xl border border-border bg-card shadow-[0_12px_34px_-18px_rgba(0,0,0,0.75)]"
        [style.height]="height()"
      >
        <!-- Brand backdrop + pin behind the iframe so a slow tile load never flashes black. -->
        <div
          class="pointer-events-none absolute inset-0 flex items-center justify-center"
          style="background: radial-gradient(circle at 50% 40%, rgba(255,107,26,0.08), transparent 70%);"
          aria-hidden="true"
        >
          <svg viewBox="0 0 24 24" class="h-8 w-8 text-border" fill="currentColor">
            <path
              d="M12 2a7 7 0 0 0-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z"
            />
          </svg>
        </div>
        <div
          class="pointer-events-none absolute inset-x-0 top-0 z-10 h-0.5 bg-gradient-to-r from-transparent via-primary/70 to-transparent"
          aria-hidden="true"
        ></div>
        <iframe
          [title]="'Map showing ' + address()"
          [src]="src()"
          loading="lazy"
          referrerpolicy="no-referrer-when-downgrade"
          class="address-map-frame relative z-[1] block h-full w-full border-0"
        ></iframe>
        <div
          class="pointer-events-none absolute inset-x-0 bottom-0 z-10 flex items-center gap-2 bg-gradient-to-t from-background/95 via-background/70 to-transparent px-3 pb-2.5 pt-7"
        >
          <span
            class="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-[0_0_10px_-1px_rgba(255,107,26,0.7)]"
            aria-hidden="true"
          >
            <svg viewBox="0 0 24 24" class="h-3 w-3" fill="currentColor">
              <path
                d="M12 2a7 7 0 0 0-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z"
              />
            </svg>
          </span>
          <span class="truncate text-xs font-semibold text-foreground">{{ address() }}</span>
        </div>
      </div>
    }
  `,
  styles: [
    `
      .address-map-frame {
        filter: grayscale(0.3) contrast(1.05) brightness(0.92);
        transition: filter 500ms;
      }
      :host(:hover) .address-map-frame,
      .group:hover .address-map-frame {
        filter: none;
      }
      @media (prefers-reduced-motion: reduce) {
        .address-map-frame {
          transition: none;
        }
      }
    `,
  ],
})
export class AddressMapComponent {
  private readonly sanitizer = inject(DomSanitizer);

  /** A human address / place query (e.g. "123 Main St, Newark, NJ"). */
  readonly address = input.required<string>();
  /** CSS height for the map frame (default 11rem ≈ 176px). */
  readonly height = input<string>('11rem');

  /** URL-encoded, trimmed query — empty string when the address is blank. */
  readonly query = computed(() => encodeURIComponent((this.address() ?? '').trim()));

  /** Keyless Google embed URL, sanitized for the iframe [src] binding. */
  readonly src = computed<SafeResourceUrl>(() =>
    this.sanitizer.bypassSecurityTrustResourceUrl(
      `https://maps.google.com/maps?q=${this.query()}&z=15&hl=en&output=embed`,
    ),
  );
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'address-map-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
