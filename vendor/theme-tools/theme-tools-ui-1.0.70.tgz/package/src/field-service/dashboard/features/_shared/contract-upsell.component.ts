import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * ContractUpsellComponent — SCAN-24 contract-conversion upsell (`<bcl-contract-upsell>`).
 *
 * The FIRST proactive nudge converting a REPEAT one-time booker onto a recurring
 * hourly contract — Brick Labor's only standing-revenue lever. A dismissible card
 * shown to a signed-in customer who has >=1 completed booking AND no active
 * recurring contract; its CTA opens the existing /book?recurring flow. The
 * "save up to N%" figure is the REAL max recurring discount reported by the
 * server (derived from src/shared/recurring.ts) — never fabricated here.
 *
 * Self-gating (mirrors ReceivedRatingComponent / CarbonImpactCardComponent):
 * fetches GET /api/contract-upsell/eligibility exactly once, and ONLY when a
 * signed-in visitor AND the `contract_conversion_upsell` server flag is live (the
 * public flag map, incl. the E2E-override-cookie seam). While the flag is dark the
 * endpoint 404s and this card renders nothing — no console error. Dismissal
 * persists in localStorage so a busy owner isn't nagged every visit.
 *
 * Brand accent = ORANGE (bcl-accent), never cyan (per the project's brand rule).
 * Standalone, signals, OnPush, zoneless-safe.
 */
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  effect,
  inject,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { AuthService } from '../../core/auth.service';
import { FeatureFlagService } from '../../core/feature-flag.service';

/** The server flag gating GET /api/contract-upsell/eligibility (404 when dark). */
const CONTRACT_UPSELL_FLAG = 'contract_conversion_upsell';
/** localStorage key remembering a dismissal (per browser — a soft nudge, not a block). */
const DISMISS_KEY = 'bcl_contract_upsell_dismissed';

/** Response of GET /api/contract-upsell/eligibility (mirrors src/shared/contract-upsell.ts). */
interface EligibilityResponse {
  readonly ok: boolean;
  readonly eligible?: boolean;
  readonly completedBookings?: number;
  readonly hasActiveContract?: boolean;
  readonly topDiscountPct?: number;
  readonly cta?: string;
}

/** Pure: "once" for one booking, "N times" otherwise — drives the headline copy. */
export function bookingCountPhrase(n: number): string {
  return n === 1 ? 'once' : `${n} times`;
}

@Component({
  selector: 'bcl-contract-upsell',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (loading()) {
      <aside
        data-testid="contract-upsell-loading"
        role="status"
        class="rounded-2xl border border-bcl-border bg-bcl-bg-elev p-5 text-sm text-bcl-ink-muted"
      >
        Checking your recurring-service savings…
      </aside>
    } @else if (failed()) {
      <aside
        data-testid="contract-upsell-error"
        role="alert"
        class="rounded-2xl border border-red-400/40 bg-red-500/10 p-5 text-sm text-bcl-ink"
      >
        <p>We couldn't check your recurring-service savings.</p>
        <button
          type="button"
          data-testid="contract-upsell-retry"
          class="mt-2 min-h-[44px] font-semibold text-bcl-accent underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
          (click)="retry()"
        >
          Try again
        </button>
      </aside>
    } @else if (visible()) {
      <aside
        data-testid="contract-upsell-card"
        class="relative overflow-hidden rounded-2xl border border-bcl-accent/30 bg-gradient-to-br from-bcl-accent/12 to-bcl-accent/[0.04] p-5 sm:p-6"
        [attr.aria-label]="'Save on recurring service'"
      >
        <span
          aria-hidden="true"
          class="pointer-events-none absolute -right-8 -top-8 size-32 rounded-full bg-bcl-accent/15 blur-2xl"
        ></span>
        <button
          type="button"
          data-testid="contract-upsell-dismiss"
          class="absolute right-3 top-3 z-20 inline-flex size-8 items-center justify-center rounded-full text-bcl-ink-muted transition hover:bg-bcl-accent/10 hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
          [attr.aria-label]="'Dismiss recurring-contract suggestion'"
          (click)="dismiss()"
        >
          <span aria-hidden="true" class="text-lg leading-none">×</span>
        </button>
        <div class="relative z-10">
          <p class="bcl-eyebrow mb-2 text-bcl-accent">Save on every visit</p>
          <h3 class="font-display text-lg font-extrabold text-bcl-ink sm:text-xl">
            You've booked us {{ phrase() }} — put your crew on a schedule and save up to
            <span class="text-bcl-accent">{{ discountPct() }}%</span>.
          </h3>
          <p class="mt-1 max-w-xl text-sm text-bcl-ink-muted">
            Same crew, standing slot, locked hourly rate. Daily, weekly, biweekly, or monthly — each
            earns a recurring discount off your per-hour rate.
          </p>
          <div class="mt-4">
            <a
              data-testid="contract-upsell-cta"
              [href]="cta()"
              class="inline-flex min-h-[44px] items-center justify-center rounded-xl bg-bcl-accent px-5 py-2.5 text-sm font-semibold text-bcl-bg transition hover:brightness-110 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-bcl-accent"
            >
              Set up a recurring contract →
            </a>
          </div>
        </div>
      </aside>
    }
  `,
})
export class ContractUpsellComponent {
  private readonly http = inject(HttpClient);
  private readonly auth = inject(AuthService);
  private readonly flags = inject(FeatureFlagService);
  private readonly flagOn = this.flags.isOn(CONTRACT_UPSELL_FLAG);
  private fetched = false;

  /** Successful eligibility payload, or null while unloaded / not eligible / dark. */
  private readonly loaded = signal<{
    eligible: boolean;
    completedBookings: number;
    topDiscountPct: number;
    cta: string;
  } | null>(null);
  /** Dismissed this session (seeded from localStorage) → never re-render. */
  private readonly dismissed = signal<boolean>(this.readDismissed());
  protected readonly loading = signal(false);
  protected readonly failed = signal(false);

  /** Render only when signed in, flag live, eligible, loaded, and not dismissed. */
  protected readonly visible = computed(
    () =>
      this.auth.authenticated() &&
      this.flagOn() &&
      !this.dismissed() &&
      (this.loaded()?.eligible ?? false),
  );
  protected readonly phrase = computed(() =>
    bookingCountPhrase(this.loaded()?.completedBookings ?? 0),
  );
  protected readonly discountPct = computed(() => this.loaded()?.topDiscountPct ?? 0);
  protected readonly cta = computed(() => this.loaded()?.cta ?? '/book?recurring=1');

  constructor() {
    // Fetch exactly once, only when signed in AND the flag is live. While dark the
    // flag isn't in the public map → we never probe the 404 endpoint → no console
    // error. Skip entirely if already dismissed. Self-activates on flag promotion.
    effect(() => {
      if (this.auth.authenticated() && this.flagOn() && !this.dismissed() && !this.fetched) {
        this.fetched = true;
        void this.refresh();
      }
    });
  }

  dismiss(): void {
    this.dismissed.set(true);
    try {
      localStorage.setItem(DISMISS_KEY, '1');
    } catch {
      /* storage disabled — dismissal still holds for this session via the signal */
    }
  }

  retry(): void {
    void this.refresh();
  }

  private readDismissed(): boolean {
    try {
      return localStorage.getItem(DISMISS_KEY) === '1';
    } catch {
      return false;
    }
  }

  private async refresh(): Promise<void> {
    this.loading.set(true);
    this.failed.set(false);
    try {
      const resp = await firstValueFrom(
        this.http.get<EligibilityResponse>('/api/contract-upsell/eligibility', {
          withCredentials: true,
        }),
      );
      if (resp?.ok && resp.eligible) {
        this.loaded.set({
          eligible: true,
          completedBookings: resp.completedBookings ?? 0,
          topDiscountPct: resp.topDiscountPct ?? 0,
          cta: resp.cta ?? '/book?recurring=1',
        });
      } else {
        this.loaded.set(null);
      }
    } catch {
      // The flag + customer checks already passed before this request, so a
      // transport failure is actionable rather than a dark-feature condition.
      this.loaded.set(null);
      this.failed.set(true);
    } finally {
      this.loading.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'contract-upsell-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
