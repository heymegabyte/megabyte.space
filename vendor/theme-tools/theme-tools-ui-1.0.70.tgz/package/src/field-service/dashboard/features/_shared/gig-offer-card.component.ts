import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
/**
 * GigOfferCardComponent — bottom-sheet offer card with 30s countdown.
 *
 * Wired via BroadcastChannel('bcl-offers') by the service worker push handler;
 * caller hydrates the `offer` input from the channel message. Countdown is a
 * circular SVG ring that drains accent → warn → danger as seconds tick down.
 * Accept/Decline → POST /api/gig/respond.
 *
 * A real ARIA APG modal (role="alertdialog", aria-modal): CDK `cdkTrapFocus` +
 * `cdkTrapFocusAutoCapture` move focus INTO the panel on render, trap Tab/Shift+Tab
 * inside, and restore focus to the trigger on close; body scroll locks while the
 * offer covers the viewport. axe-core is blind to every one of those interaction
 * gaps, so the behavior spec is the only guard. Mirrors the live `tip-dialog`
 * a11y kit (extend-the-platform-primitive, not a parallel one). Esc is INTENTIONALLY
 * NOT a dismiss here — an alertdialog is a forced choice, and a payout offer must
 * record an explicit accept/decline (or expire), never silently vanish on a keypress.
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  effect,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { A11yModule } from '@angular/cdk/a11y';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { interval } from 'rxjs';

export interface GigOffer {
  readonly gigId: string;
  readonly bookingId: string;
  readonly serviceLabel: string;
  readonly pickup: string;
  readonly dropoff: string | null;
  readonly etaMinutes: number;
  readonly payoutCents: number;
  readonly expiresAt: number; // epoch ms
}

@Component({
  selector: 'bcl-gig-offer-card',
  standalone: true,
  imports: [A11yModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (offer(); as o) {
      <div
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="offer-title"
        cdkTrapFocus
        [cdkTrapFocusAutoCapture]="true"
        class="fixed inset-x-0 bottom-0 z-50 mx-auto w-full max-w-md rounded-t-3xl bg-bcl-bg-elev p-6 ring-1 ring-bcl-border shadow-2xl"
        style="padding-bottom: max(1.5rem, env(safe-area-inset-bottom));"
        data-testid="gig-offer"
      >
        <div class="flex items-start gap-4">
          <svg viewBox="0 0 36 36" class="h-16 w-16 shrink-0" aria-hidden="true">
            <circle
              cx="18"
              cy="18"
              r="15.9155"
              fill="none"
              stroke="rgba(244,244,255,0.08)"
              stroke-width="3"
            />
            <circle
              cx="18"
              cy="18"
              r="15.9155"
              fill="none"
              [attr.stroke]="ringStroke()"
              stroke-width="3"
              stroke-linecap="round"
              transform="rotate(-90 18 18)"
              [attr.stroke-dasharray]="dasharray()"
            />
            <text x="18" y="20.5" text-anchor="middle" font-size="9" fill="#f4f4f5">
              {{ secondsLeft() }}s
            </text>
          </svg>
          <div class="min-w-0 flex-1">
            <h3 id="offer-title" class="truncate text-base font-semibold text-bcl-ink">
              {{ o.serviceLabel }}
            </h3>
            <p class="truncate text-sm text-bcl-ink-muted">{{ o.pickup }}</p>
            @if (o.dropoff) {
              <p class="truncate text-xs text-bcl-ink-muted">→ {{ o.dropoff }}</p>
            }
            <p class="mt-1 text-sm text-bcl-ink">
              <span class="font-semibold text-bcl-accent">{{ formatMoney(o.payoutCents) }}</span>
              · ETA {{ o.etaMinutes }}m
            </p>
          </div>
        </div>

        @if (isExpired()) {
          <p
            class="mt-5 rounded-lg bg-bcl-bg-elev px-4 py-3 text-center text-sm font-semibold text-bcl-ink-muted ring-1 ring-bcl-border"
            role="status"
            data-testid="gig-offer-expired"
          >
            This offer expired.
          </p>
        } @else {
          <div class="mt-5 grid grid-cols-2 gap-3">
            <button
              type="button"
              (click)="respond('decline')"
              [disabled]="busyState()"
              data-testid="gig-offer-decline"
              class="min-h-[44px] rounded-lg bg-bcl-bg-elev px-4 text-sm font-semibold text-bcl-ink ring-1 ring-bcl-border hover:bg-white/5 disabled:opacity-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
            >
              <span class="inline-block min-w-[8ch] text-center">Decline</span>
            </button>
            <button
              type="button"
              (click)="respond('accept')"
              [disabled]="busyState()"
              data-testid="gig-offer-accept"
              class="min-h-[44px] rounded-lg bg-bcl-accent px-4 text-sm font-semibold text-bcl-bg hover:bg-bcl-accent-2 disabled:opacity-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
            >
              <span class="inline-block min-w-[8ch] text-center">{{
                busyState() ? 'Working…' : 'Accept'
              }}</span>
            </button>
          </div>
          @if (error(); as e) {
            <p
              class="mt-3 text-center text-sm text-destructive"
              role="alert"
              data-testid="gig-offer-error"
            >
              {{ e }}
            </p>
          }
        }
      </div>
    }
  `,
})
export class GigOfferCardComponent {
  private readonly destroyRef = inject(DestroyRef);

  readonly offer = input<GigOffer | null>(null);
  /**
   * Optional parent-driven in-flight flag. When a HOST (e.g. the crew job-detail
   * page) owns the accept/decline network call — hitting the real first-Y-wins
   * `/api/work/gigs/:id/accept` via the (accepted)/(declined) outputs rather than
   * this card's built-in `/api/gig/respond` — it passes its own pending state here
   * so both buttons disable + show "Working…" during the request. Defaults false,
   * so the broadcast-driven crew-console usage (which uses the internal `respond`)
   * is unchanged.
   */
  readonly busy = input(false);
  /**
   * Who owns the accept/decline NETWORK call. Default `true` = this card POSTs
   * `/api/gig/respond` itself (the broadcast-driven crew-console usage). A HOST that
   * owns the real first-Y-wins `/api/work/gigs/:id/accept` (crew job-detail) passes
   * `false`: the card then ONLY emits (accepted)/(declined) and the host does the
   * network + its own error surface — never a double-dispatch.
   */
  readonly selfManaged = input(true);
  readonly pending = signal(false);
  /** Self-managed respond() failure (gig already taken / rate-limited / offline). */
  readonly error = signal<string | null>(null);
  readonly accepted = output<GigOffer>();
  readonly declined = output<GigOffer>();
  readonly expired = output<GigOffer>();
  readonly now = signal(Date.now());

  /** Buttons disable while EITHER the internal respond() or the host is in flight. */
  readonly busyState = computed(() => this.pending() || this.busy());

  /** The countdown has drained — force a decision-locked "expired" state. */
  readonly isExpired = computed(() => {
    const o = this.offer();
    return !!o && this.secondsLeft() === 0;
  });

  constructor() {
    interval(250)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(() => this.now.set(Date.now()));
    effect(() => {
      const o = this.offer();
      if (o && this.now() >= o.expiresAt && this.secondsLeft() === 0) {
        this.expired.emit(o);
      }
    });
    // Lock body scroll while the modal offer covers the viewport (aria-modal ⇒
    // background is inert); restore it the moment the offer clears. Mirrors the
    // React `useBodyScrollLock` kit + the live tip-dialog.
    effect(() => {
      if (typeof document === 'undefined') return;
      document.body.style.overflow = this.offer() ? 'hidden' : '';
    });
  }

  readonly secondsLeft = computed(() => {
    const o = this.offer();
    if (!o) return 0;
    return Math.max(0, Math.ceil((o.expiresAt - this.now()) / 1000));
  });

  readonly dasharray = computed(() => {
    const o = this.offer();
    if (!o) return '0 100';
    const total = Math.max(1, Math.round((o.expiresAt - (o.expiresAt - 30_000)) / 1000));
    const frac = Math.max(0, Math.min(1, this.secondsLeft() / total));
    const filled = (frac * 100).toFixed(2);
    return `${filled} ${(100 - +filled).toFixed(2)}`;
  });

  ringStroke(): string {
    const s = this.secondsLeft();
    if (s <= 5) return '#ef4444';
    if (s <= 15) return '#f59e0b';
    return '#ff6b1a';
  }

  formatMoney(cents: number): string {
    return `$${(cents / 100).toFixed(2)}`;
  }

  async respond(action: 'accept' | 'decline'): Promise<void> {
    const o = this.offer();
    if (!o || this.busyState() || this.isExpired()) return;
    // Host-managed mode: the parent owns the real network call
    // (/api/work/gigs/:id/accept) via the outputs + its own error surface. Just
    // emit — never double-dispatch /api/gig/respond here.
    if (!this.selfManaged()) {
      if (action === 'accept') this.accepted.emit(o);
      else this.declined.emit(o);
      return;
    }
    this.pending.set(true);
    this.error.set(null);
    try {
      const res = await fetch('/api/gig/respond', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ gigId: o.gigId, action }),
      });
      // Raw fetch does NOT throw on 4xx — gate on res.ok so a rate-limited (429),
      // expired-session (401), or otherwise-rejected response never reports a FALSE
      // accept/decline. The crew keeps the offer card + a retriable error instead of
      // the gig silently vanishing from their queue.
      if (!res.ok) {
        this.error.set(
          res.status === 429
            ? 'Too many taps — wait a moment and try again.'
            : res.status === 401
              ? 'Your session expired — sign in again.'
              : 'Could not record your response — try again.',
        );
        return;
      }
      if (action === 'accept') this.accepted.emit(o);
      else this.declined.emit(o);
    } catch {
      this.error.set('Connection lost — try again.');
    } finally {
      this.pending.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'gig-offer-card-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
