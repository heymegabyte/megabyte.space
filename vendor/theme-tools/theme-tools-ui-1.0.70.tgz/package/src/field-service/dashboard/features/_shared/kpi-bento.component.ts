import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * bcl-kpi-bento — cinematic KPI bento grid for the dashboard home view.
 *
 * Replaces the flat 3-column card row with a visually layered bento that
 * uses:
 *  - Glass cards (`.bcl-glass`) with hairline gradient borders
 *  - Eyebrow labels (`.bcl-eyebrow`) with the accent rule
 *  - Rolling counters (BclRollingCounterComponent) for every numeric value
 *  - Trend pill that compares value-vs-baseline (▲/▼ + pct)
 *  - Optional sparkline-style strip (CSS-only) when trend data is supplied
 *
 * Pure presentational — accepts an `items` input and renders. The home
 * component is responsible for fetching + reshaping data.
 *
 * Accepts a `loading` flag so the bento shows skeleton placeholders without
 * a separate state-handling component.
 */
import { ChangeDetectionStrategy, Component, Input, computed, signal } from '@angular/core';
import { BclRollingCounterComponent } from './rolling-counter.component';

export interface KpiBentoItem {
  readonly key: string;
  readonly label: string;
  readonly value: number;
  readonly prefix?: string;
  readonly suffix?: string;
  readonly decimals?: number;
  readonly hint: string;
  /** Optional baseline for trend pill — when set, renders ▲X% or ▼X%. */
  readonly baseline?: number;
  /** Optional sparkline (small array of last N values, 4-12 ideal). */
  readonly spark?: readonly number[];
  /** Tone accents the trend pill + sparkline color. */
  readonly tone?: 'accent' | 'success' | 'warn' | 'danger';
  /** Optional emphasis — `wide` makes the cell span 2 columns at md+. */
  readonly span?: 'normal' | 'wide';
}

@Component({
  selector: 'bcl-kpi-bento',
  standalone: true,
  imports: [BclRollingCounterComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section class="bcl-bento" data-testid="kpi-bento">
      @for (item of items; track item.key) {
        <article
          class="bcl-glass bcl-fade-in relative overflow-hidden p-5"
          [class.md\\:col-span-2]="item.span === 'wide'"
          [attr.data-tone]="item.tone ?? 'accent'"
        >
          <header class="mb-3 flex items-start justify-between gap-3">
            <p class="bcl-eyebrow">{{ item.label }}</p>
            @if (item.baseline !== undefined && item.baseline !== null) {
              <span
                class="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-mono font-bold"
                [class.bg-bcl-success\\/15]="trend(item) >= 0"
                [class.text-bcl-success]="trend(item) >= 0"
                [class.bg-bcl-warn\\/15]="trend(item) < 0"
                [class.text-bcl-warn]="trend(item) < 0"
              >
                <span aria-hidden="true">{{ trend(item) >= 0 ? '▲' : '▼' }}</span>
                {{ trendPct(item) }}%
              </span>
            }
          </header>

          @if (loading) {
            <div class="h-10 w-32 animate-pulse rounded bg-white/10"></div>
          } @else {
            <p class="bcl-tabular text-4xl font-extrabold text-bcl-ink">
              <bcl-rolling-counter
                [value]="item.value"
                [prefix]="item.prefix ?? null"
                [suffix]="item.suffix ?? null"
                [decimals]="item.decimals ?? 0"
              />
            </p>
          }

          <p class="mt-2 text-xs text-bcl-ink-muted leading-relaxed">{{ item.hint }}</p>

          @if (item.spark && item.spark.length > 1) {
            <div
              class="mt-4 flex items-end gap-0.5 h-12"
              role="img"
              aria-label="Last {{ item.spark.length }} values"
            >
              @for (v of normalizedSpark(item); track $index) {
                <span
                  class="flex-1 rounded-sm"
                  [style.height.%]="v"
                  [class.bg-bcl-success\\/80]="(item.tone ?? 'accent') === 'success'"
                  [class.bg-bcl-warn\\/80]="(item.tone ?? 'accent') === 'warn'"
                  [class.bg-red-400\\/80]="(item.tone ?? 'accent') === 'danger'"
                  [class.bg-bcl-accent\\/80]="(item.tone ?? 'accent') === 'accent'"
                  aria-hidden="true"
                ></span>
              }
            </div>
          }

          <span
            aria-hidden="true"
            class="pointer-events-none absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-bcl-accent/40 to-transparent opacity-60"
          ></span>
        </article>
      }
    </section>
  `,
})
export class BclKpiBentoComponent {
  @Input() items: ReadonlyArray<KpiBentoItem> = [];
  @Input() loading = false;

  trend(item: KpiBentoItem): number {
    if (item.baseline === undefined || item.baseline === null || item.baseline === 0) return 0;
    return item.value - item.baseline;
  }

  trendPct(item: KpiBentoItem): number {
    if (item.baseline === undefined || item.baseline === null || item.baseline === 0) return 0;
    return Math.round((Math.abs(this.trend(item)) / item.baseline) * 100);
  }

  normalizedSpark(item: KpiBentoItem): readonly number[] {
    if (!item.spark || item.spark.length === 0) return [];
    const max = Math.max(...item.spark, 1);
    return item.spark.map((v) => Math.max(6, Math.round((v / max) * 100)));
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'kpi-bento-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
