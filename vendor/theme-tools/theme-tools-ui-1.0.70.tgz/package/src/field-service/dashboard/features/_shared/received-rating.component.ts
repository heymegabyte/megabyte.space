import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * ReceivedRatingComponent — GP-07 received-reputation chip (`<bcl-received-rating>`).
 *
 * The DISPLAY half of the two-sided crew↔customer rating loop: shows the SIGNED-IN
 * user's OWN received star average + count. A CREW sees the reputation customers
 * gave them; a CUSTOMER sees the reputation crews gave them — the endpoint resolves
 * the role server-side from the session, so this chip never has to know which.
 *
 * Self-gating (mirrors CarbonImpactCardComponent): fetches GET
 * /api/mutual-ratings/received exactly once, and ONLY when a signed-in visitor AND
 * the `mutual_ratings` server flag is live (the public flag map, incl. the
 * E2E-override-cookie seam). While the flag is dark the endpoint 404s and this chip
 * renders nothing — no console error for guests or signed-in users. Zero ratings →
 * a friendly "New" pill, never a fake 0.0.
 *
 * Brand accent = ORANGE (bcl-accent), stars orange — never cyan (per the project's
 * brand-accent rule). Standalone, signals, OnPush, zoneless-safe.
 */
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  effect,
  inject,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { AuthService } from '../../core/auth.service';
import { FeatureFlagService } from '../../core/feature-flag.service';

/** The server flag gating GET /api/mutual-ratings/received (404 when dark). */
const MUTUAL_RATINGS_FLAG = 'mutual_ratings';

/** Response of GET /api/mutual-ratings/received (mirrors src/shared/mutual-ratings.ts). */
interface ReceivedRatingResponse {
  readonly ok: boolean;
  readonly role?: 'crew' | 'customer';
  readonly average?: number | null;
  readonly count?: number;
}

/** Pure: compact "4.8" style average, or null when there's no sample. */
export function displayAverage(average: number | null, count: number): string | null {
  if (!count || average === null || Number.isNaN(average)) return null;
  return (Math.round(average * 10) / 10).toFixed(1);
}

@Component({
  selector: 'bcl-received-rating',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (eligible() && state() === 'loading') {
      <span role="status" class="text-xs text-bcl-ink-muted">Loading your rating…</span>
    } @else if (eligible() && state() === 'error') {
      <span
        data-testid="received-rating-error"
        class="inline-flex min-h-11 items-center gap-2 rounded-full border border-bcl-danger/50 px-3 py-1 text-xs text-bcl-ink"
      >
        <span role="alert">Rating unavailable.</span>
        <button
          type="button"
          class="min-h-9 rounded-full px-2 font-semibold text-bcl-accent underline underline-offset-2 focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
          (click)="retry()"
        >
          Try again
        </button>
      </span>
    } @else if (visible()) {
      <div
        data-testid="received-rating-chip"
        class="inline-flex min-h-[28px] items-center gap-1.5 rounded-full bg-bcl-accent/12 px-3 py-1 text-sm font-semibold text-bcl-accent ring-1 ring-bcl-accent/30"
        [attr.aria-label]="ariaLabel()"
        [title]="ariaLabel()"
      >
        <!-- Orange star — brand accent, never cyan. -->
        <span aria-hidden="true" class="text-bcl-accent">★</span>
        @if (avg(); as a) {
          <span class="tabular-nums">{{ a }}</span>
          <span class="font-normal text-bcl-accent/80">({{ count() }})</span>
        } @else {
          <span class="font-normal text-bcl-accent/80">New</span>
        }
      </div>
    }
  `,
})
export class ReceivedRatingComponent {
  private readonly http = inject(HttpClient);
  private readonly auth = inject(AuthService);
  private readonly flags = inject(FeatureFlagService);
  private readonly flagOn = this.flags.isOn(MUTUAL_RATINGS_FLAG);
  private fetched = false;

  private readonly loaded = signal<{ average: number | null; count: number } | null>(null);
  protected readonly state = signal<'idle' | 'loading' | 'ready' | 'error'>('idle');
  protected readonly eligible = computed(() => this.auth.authenticated() && this.flagOn());

  /** Only render once we have a successful response AND flag+auth still hold. */
  protected readonly visible = computed(
    () => this.auth.authenticated() && this.flagOn() && this.loaded() !== null,
  );
  protected readonly avg = computed(() => {
    const r = this.loaded();
    return r ? displayAverage(r.average, r.count) : null;
  });
  protected readonly count = computed(() => this.loaded()?.count ?? 0);
  protected readonly ariaLabel = computed(() => {
    const r = this.loaded();
    if (!r || r.count === 0) return 'You have no ratings yet';
    const a = displayAverage(r.average, r.count);
    return `Your rating: ${a} out of 5, from ${r.count} ${r.count === 1 ? 'review' : 'reviews'}`;
  });

  constructor() {
    // Fetch exactly once, only when signed in AND the flag is live. While dark the
    // flag isn't in the public map → we never probe the 404 endpoint → no console
    // error. Self-activates the moment the flag is promoted.
    effect(() => {
      if (this.auth.authenticated() && this.flagOn() && !this.fetched) {
        this.fetched = true;
        this.state.set('loading');
        void this.refresh();
      }
    });
  }

  private async refresh(): Promise<void> {
    try {
      const resp = await firstValueFrom(
        this.http.get<ReceivedRatingResponse>('/api/mutual-ratings/received', {
          withCredentials: true,
        }),
      );
      if (resp?.ok) {
        this.loaded.set({ average: resp.average ?? null, count: resp.count ?? 0 });
        this.state.set('ready');
      } else {
        this.loaded.set(null);
        this.state.set('error');
      }
    } catch {
      this.loaded.set(null);
      this.state.set('error');
    }
  }

  protected retry(): void {
    this.state.set('loading');
    void this.refresh();
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'received-rating-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
