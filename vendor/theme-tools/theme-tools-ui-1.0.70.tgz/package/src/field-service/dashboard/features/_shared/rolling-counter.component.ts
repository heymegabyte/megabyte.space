import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * BclRollingCounter — animated numeric KPI display. Relocated shared/ui →
 * features/_shared during the Spartan rebuild (bespoke cinematic primitive per
 * the cinematic-ui-patterns rule); cockpit semantic tokens.
 *
 * Counts up from 0 to `value` via `requestAnimationFrame` using easeOutQuart
 * over `duration` ms (default 600). Snaps instantly if `prefers-reduced-motion`
 * is set, on SSR, or on subsequent re-renders within `tickThresholdMs`.
 *
 * Locale-formats via `Intl.NumberFormat` (`en-US` default). `prefix` /
 * `suffix` slots cover `$`, `+`, `%`, `×`, units, etc.
 * `aria-label` always reflects the final formatted value — screen readers
 * hear the truth on first focus, never the rolling intermediate.
 *
 * `font-variant-numeric: tabular-nums` keeps digits from reflowing mid-count.
 */
import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  effect,
  inject,
  input,
  signal,
  computed,
  PLATFORM_ID,
  DestroyRef,
} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

function easeOutQuart(t: number): number {
  return 1 - Math.pow(1 - t, 4);
}

@Component({
  selector: 'bcl-rolling-counter',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <span
      class="inline-flex items-baseline gap-1 font-mono tabular-nums"
      [attr.aria-label]="ariaLabel()"
      role="status"
      aria-live="polite"
      data-testid="rolling-counter"
    >
      @if (prefix(); as p) {
        <span class="text-muted-foreground">{{ p }}</span>
      }
      <span aria-hidden="true">{{ formatted() }}</span>
      @if (suffix(); as s) {
        <span class="text-muted-foreground">{{ s }}</span>
      }
    </span>
  `,
})
export class BclRollingCounterComponent {
  readonly value = input.required<number>();
  readonly decimals = input<number>(0);
  readonly duration = input<number>(600);
  readonly prefix = input<string | null>(null);
  readonly suffix = input<string | null>(null);
  readonly locale = input<string>('en-US');

  readonly current = signal<number>(0);

  private readonly platformId = inject(PLATFORM_ID);
  private readonly destroyRef = inject(DestroyRef);
  private rafId: number | null = null;

  readonly formatter = computed(
    () =>
      new Intl.NumberFormat(this.locale(), {
        minimumFractionDigits: this.decimals(),
        maximumFractionDigits: this.decimals(),
      }),
  );

  readonly formatted = computed(() => this.formatter().format(this.current()));
  readonly ariaLabel = computed(() => {
    const parts: string[] = [];
    if (this.prefix()) parts.push(this.prefix() as string);
    parts.push(this.formatter().format(this.value()));
    if (this.suffix()) parts.push(this.suffix() as string);
    return parts.join('');
  });

  constructor() {
    this.destroyRef.onDestroy(() => {
      if (this.rafId !== null) cancelAnimationFrame(this.rafId);
    });
    effect(() => {
      const target = this.value();
      this.animate(target);
    });
  }

  private animate(target: number): void {
    if (!isPlatformBrowser(this.platformId)) {
      this.current.set(target);
      return;
    }
    const reduce =
      typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce || this.duration() <= 0) {
      this.current.set(target);
      return;
    }
    if (this.rafId !== null) cancelAnimationFrame(this.rafId);
    const start = this.current();
    const delta = target - start;
    if (delta === 0) return;
    const startTs = performance.now();
    const dur = this.duration();
    const tick = (now: number): void => {
      const t = Math.min(1, (now - startTs) / dur);
      const eased = easeOutQuart(t);
      this.current.set(start + delta * eased);
      if (t < 1) {
        this.rafId = requestAnimationFrame(tick);
      } else {
        this.current.set(target);
        this.rafId = null;
      }
    };
    this.rafId = requestAnimationFrame(tick);
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'rolling-counter-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
