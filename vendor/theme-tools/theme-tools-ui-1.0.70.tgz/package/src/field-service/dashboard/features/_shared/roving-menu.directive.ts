import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { AfterViewInit, Directive, ElementRef, EventEmitter, HostListener, Output, inject } from '@angular/core';
import { nextRadioIndex } from '@theme.tools/i18n-a11y/field-service/radio-keynav';

/** Vertical-menu navigation keys (ArrowLeft/Right are reserved for submenus, ignored here). */
const VERTICAL_KEYS = new Set(['ArrowDown', 'ArrowUp', 'Home', 'End']);
/** Keys that dismiss the menu and return focus to its trigger. */
const DISMISS_KEYS = new Set(['Escape', 'Tab']);

/**
 * WCAG APG menu-button keyboard behavior for a custom `role="menu"` opened from a
 * trigger button (Angular).
 *
 * The APG menu pattern requires that, once the menu opens, focus moves INTO it and
 * the operator navigates between `role="menuitem"` entries with the arrow keys
 * (Down/Up, wrapping at the ends) plus Home/End — never by Tabbing through every
 * item. Escape (and Tab) close the menu and return focus to the trigger. A naive
 * `role="menu"` `<ul>` of independently-Tabbable buttons with NO keyboard handling
 * FAILS this pattern: a keyboard-only operator can't arrow between items, can't
 * Escape to close, and focus never enters the menu on open. axe-core does NOT catch
 * any of this — it is an interaction-pattern gap, not a static attribute one — so it
 * is locked by the colocated behavior spec instead.
 *
 * The menu is a single tab stop via roving `tabindex` (active item `0`, rest `-1`),
 * mirroring {@link RovingTablistDirective}. On open the first item is focused. The
 * directive only MOVES focus + emits `dismiss`; it never activates an item, so a
 * `<button role="menuitem">` still commits its own action on Enter/Space/click with
 * zero state side-effects from arrowing.
 *
 * Opt-in via the `bclRovingMenu` attribute so it never auto-hijacks a `role="menu"`
 * whose items are non-native custom components. Reuses the role-agnostic index math
 * from the canonical `radio-keynav` helper (gated to vertical keys) so menus, tabs,
 * and radio groups can never drift apart.
 *
 * @example
 * <ul role="menu" bclRovingMenu (dismiss)="close(); trigger.focus()">
 *   <li><button role="menuitem">Profile</button></li>
 *   <li><button role="menuitem">Sign out</button></li>
 * </ul>
 */
@Directive({
  selector: '[bclRovingMenu]',
  standalone: true,
})
export class RovingMenuDirective implements AfterViewInit {
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef);

  /** Emitted on Escape/Tab — the host closes the menu AND restores focus to its trigger. */
  @Output() readonly dismiss = new EventEmitter<void>();

  ngAfterViewInit(): void {
    const items = this.items();
    if (!items.length) return;
    this.applyRoving(items, 0);
    // APG: when a menu button opens its menu, focus moves to the first item.
    items[0]?.focus();
  }

  /**
   * All menu-item descendants of the menu, in DOM order. Covers the three APG
   * menu item roles — `menuitem`, `menuitemradio` (e.g. the role-switcher's persona
   * options), `menuitemcheckbox` — because the roving index math is role-agnostic;
   * a too-narrow `[role="menuitem"]`-only query silently left a `menuitemradio`
   * menu with NO focus-on-open and dead arrow keys (an exact-match attribute
   * selector never matches `menuitemradio`).
   */
  private items(): HTMLElement[] {
    return Array.from(
      this.host.nativeElement.querySelectorAll<HTMLElement>(
        '[role="menuitem"],[role="menuitemradio"],[role="menuitemcheckbox"]',
      ),
    );
  }

  private applyRoving(items: HTMLElement[], activeIndex: number): void {
    items.forEach((it, i) => it.setAttribute('tabindex', i === activeIndex ? '0' : '-1'));
  }

  /** Arrow/Home/End move focus between items (wrapping); Escape/Tab dismiss the menu. */
  @HostListener('keydown', ['$event'])
  onKeydown(event: KeyboardEvent): void {
    if (DISMISS_KEYS.has(event.key)) {
      event.preventDefault();
      this.dismiss.emit();
      return;
    }
    if (!VERTICAL_KEYS.has(event.key)) return;
    const items = this.items();
    if (!items.length) return;
    const focused = items.findIndex((it) => it === document.activeElement);
    const current = focused >= 0 ? focused : 0;
    const next = nextRadioIndex(current, items.length, event.key);
    if (next === null) return;
    event.preventDefault();
    this.applyRoving(items, next);
    items[next]?.focus();
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'roving-menu-directive',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
