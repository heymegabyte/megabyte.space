import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * StatusTimelineComponent — 6-step ride status timeline (domain UI, shared by
 * booking-detail + crew job-tracking). Relocated from the deprecated shared/ui
 * into features/_shared during the Spartan rebuild (Wave 3c) so the old shared/
 * can be deleted in Wave 12. Styled on the cockpit semantic tokens (the HLM
 * theme bridge), prefers-reduced-motion-aware.
 *
 * Steps: requested · matched · enroute · arrived · working · complete.
 *
 * SCAN-64 — the timeline can now also render the timestamp each reached step
 * happened. Pass the optional `transitions` input ({step, at:epochSeconds}[],
 * from GET /api/ride/:id/timeline, flag `crew_job_timeline`) and each reached
 * step shows a localized time (e.g. "2:14 PM") beneath its label — turning the
 * static stepper into a live timestamped receipt. When `transitions` is empty
 * (flag dark, or a surface that doesn't fetch it) the component renders exactly
 * as before, with no per-step time.
 */
import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';

export type RideStatusStep =
  | 'requested'
  | 'matched'
  | 'enroute'
  | 'arrived'
  | 'working'
  | 'complete';

/** One reached transition — the step + the epoch-SECONDS moment it happened. */
export interface RideStatusTransition {
  readonly step: RideStatusStep;
  readonly at: number;
}

interface Step {
  readonly key: RideStatusStep;
  readonly label: string;
}

const STEPS: readonly Step[] = [
  { key: 'requested', label: 'Requested' },
  { key: 'matched', label: 'Matched' },
  { key: 'enroute', label: 'En route' },
  { key: 'arrived', label: 'Arrived' },
  { key: 'working', label: 'Working' },
  { key: 'complete', label: 'Complete' },
];

/**
 * Format an epoch-seconds moment as a short local time label ("2:14 PM"). Never
 * throws — returns '' on a bad input. Mirrors the shared worker-side
 * formatTransitionTime so server + client render identically.
 */
export function formatStepTime(atSeconds: number): string {
  if (!Number.isFinite(atSeconds) || atSeconds <= 0) return '';
  try {
    return new Date(atSeconds * 1000).toLocaleTimeString(undefined, {
      hour: 'numeric',
      minute: '2-digit',
    });
  } catch {
    return '';
  }
}

@Component({
  selector: 'bcl-status-timeline',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <ol
      data-testid="status-timeline"
      class="status-timeline flex w-full items-center justify-between gap-2"
      aria-label="Ride status timeline"
      role="list"
    >
      @for (step of steps; track step.key; let i = $index) {
        <li
          class="flex flex-1 flex-col items-center gap-1.5"
          [attr.aria-current]="step.key === current() ? 'step' : null"
        >
          <span
            class="flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-semibold ring-2 transition-colors"
            [class.bg-primary]="i <= activeIndex()"
            [class.text-primary-foreground]="i <= activeIndex()"
            [class.ring-primary]="i <= activeIndex()"
            [class.bg-muted]="i > activeIndex()"
            [class.text-muted-foreground]="i > activeIndex()"
            [class.ring-border]="i > activeIndex()"
            [class.animate-pulse]="i === activeIndex() && !reducedMotion"
            >{{ i + 1 }}</span
          >
          <span
            class="text-center text-[11px] uppercase tracking-wider"
            [class.text-primary]="step.key === current()"
            [class.text-foreground]="i < activeIndex()"
            [class.text-muted-foreground]="i > activeIndex()"
            >{{ step.label }}</span
          >
          @if (stepTime(step.key); as t) {
            <time
              data-testid="timeline-step-time"
              class="text-center text-[10px] font-medium tabular-nums text-muted-foreground"
              [attr.datetime]="stepIso(step.key)"
              >{{ t }}</time
            >
          }
        </li>
      }
    </ol>
  `,
})
export class StatusTimelineComponent {
  readonly current = input<RideStatusStep>('requested');
  /**
   * Optional timestamped transitions (SCAN-64). When provided, each reached step
   * renders the localized time it happened. Absent/empty → no per-step time.
   */
  readonly transitions = input<readonly RideStatusTransition[]>([]);
  readonly steps = STEPS;
  readonly reducedMotion =
    typeof globalThis !== 'undefined' &&
    typeof globalThis.matchMedia === 'function' &&
    globalThis.matchMedia('(prefers-reduced-motion: reduce)').matches;

  readonly activeIndex = computed(() => {
    const idx = STEPS.findIndex((s) => s.key === this.current());
    return idx < 0 ? 0 : idx;
  });

  /** Map step → epoch-seconds, derived once from the transitions input. */
  private readonly timeByStep = computed<ReadonlyMap<RideStatusStep, number>>(() => {
    const m = new Map<RideStatusStep, number>();
    for (const t of this.transitions()) {
      if (t && typeof t.at === 'number' && t.at > 0) m.set(t.step, t.at);
    }
    return m;
  });

  /** The localized time label for a step, or '' when it has no timestamp. */
  stepTime(step: RideStatusStep): string {
    const at = this.timeByStep().get(step);
    return at ? formatStepTime(at) : '';
  }

  /** ISO datetime for the <time> element's machine-readable attr, or null. */
  stepIso(step: RideStatusStep): string | null {
    const at = this.timeByStep().get(step);
    return at ? new Date(at * 1000).toISOString() : null;
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'status-timeline-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
