import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * TerminalCheckoutCardComponent — crew-facing in-field card-present payment.
 *
 * Drives the full Square Terminal money loop the worker backend already exposes
 * but no UI reached: pick a paired reader → send the amount → watch the live
 * status pill (Waiting → Tapping → Paid) → cancel an unpaid checkout. Closes
 * item 8's stated REMAINS ("crew/operator UI to drive create→poll→done with the
 * terminalStatusView pill; device-pairing list").
 *
 * Backend (all `bcl_work_sid`-gated, soft-503 when SQUARE_ACCESS_TOKEN unset):
 *   GET  /api/work/terminal-checkout/devices    — paired readers
 *   POST /api/work/terminal-checkout            — create (device shows amount)
 *   GET  /api/work/terminal-checkout/:id        — poll status
 *   POST /api/work/terminal-checkout/:id/cancel — abort an UNPAID checkout
 *
 * Crew-only: parent gates render on `isCrew`. Self-gates anyway — a 401/503
 * degrades to honest copy, never a false "Paid".
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HlmButton } from '../../shared/ui-spartan';
import {
  isTerminalCheckoutCancelable,
  isTerminalCheckoutTerminal,
  normalizeTerminalStatus,
  terminalStatusView,
  type TerminalCheckoutStatus,
} from '@theme.tools/crm/field-service/terminal-status';

/** A paired reader returned by `GET /api/work/terminal-checkout/devices`. */
export interface TerminalDevice {
  readonly id: string;
  readonly name: string;
  readonly status: 'available' | 'busy' | 'offline';
}

const DEVICE_STORAGE_KEY = 'bcl_terminal_device';
const POLL_INTERVAL_MS = 3000;

/**
 * Convert a crew-entered dollar amount to integer cents, clamped to the
 * worker's accepted range (≥ $0.50, the Square Terminal minimum). Null / NaN /
 * negative → 0, which the UI treats as "not chargeable yet".
 *
 * @example terminalAmountToCents(12.5) // → 1250
 * @example terminalAmountToCents(null) // → 0
 */
export function terminalAmountToCents(dollars: number | null | undefined): number {
  if (dollars === null || dollars === undefined || !Number.isFinite(dollars)) return 0;
  const cents = Math.round(dollars * 100);
  return cents < 0 ? 0 : cents;
}

/**
 * Map a worker error response to honest crew-facing copy. The card NEVER shows
 * a false "Paid" — every non-2xx becomes a specific, actionable message.
 *
 * @example terminalCreateErrorMessage(503) // → reader not connected message
 */
export function terminalCreateErrorMessage(status: number, code?: string): string {
  if (status === 503 || code === 'square_disabled')
    return 'In-person card readers aren’t connected yet. Take payment another way for now.';
  if (status === 401) return 'Your crew session expired. Sign in again to take a payment.';
  if (status === 429) return 'Too many attempts. Wait a moment and try again.';
  if (status === 400) return 'That checkout looks off. Check the amount and reader, then retry.';
  if (status === 409 || code === 'not_cancelable')
    return 'This checkout can’t be canceled — it already finished. Refresh to see the result.';
  if (status === 404 || code === 'checkout_not_found')
    return 'That checkout is no longer on the reader. Start a new charge.';
  return 'The reader didn’t respond. Check it’s on and paired, then try again.';
}

@Component({
  selector: 'bcl-terminal-checkout-card',
  standalone: true,
  imports: [FormsModule, HlmButton],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="rounded-xl border border-border bg-card p-4">
      <div class="flex items-start justify-between gap-3">
        <div>
          <h3 class="text-sm font-semibold text-foreground">Collect payment in person</h3>
          <p class="text-xs text-muted-foreground">Tap, insert, or swipe on your Square reader.</p>
        </div>
        @if (checkoutId()) {
          <span
            class="inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium transition-all duration-[333ms]"
            [class]="view().tile"
            role="status"
            [attr.aria-label]="'Payment status: ' + view().label"
          >
            <span class="h-2 w-2 rounded-full" [class]="view().dot" aria-hidden="true"></span>
            {{ view().label }}
          </span>
        }
      </div>

      @if (!checkoutId()) {
        <!-- Compose a new charge -->
        <div class="mt-4 grid gap-3">
          <label class="block">
            <span class="text-xs uppercase tracking-wider text-muted-foreground">Amount</span>
            <div class="mt-1 flex items-center rounded-lg border border-border bg-background transition-all duration-[333ms] focus-within:ring-2 focus-within:ring-primary">
              <span class="pl-3 text-base text-muted-foreground" aria-hidden="true">$</span>
              <input
                type="number"
                inputmode="decimal"
                min="0.50"
                step="0.50"
                [(ngModel)]="amountDollars"
                class="min-h-[44px] w-full bg-transparent px-2 text-base text-foreground focus:outline-none"
                aria-label="Charge amount in dollars"
                placeholder="0.00"
                data-testid="terminal-amount"
              />
            </div>
          </label>

          @if (devices().length > 0) {
            <fieldset>
              <legend class="text-xs uppercase tracking-wider text-muted-foreground">Reader</legend>
              <div class="mt-1 flex flex-wrap gap-2">
                @for (d of devices(); track d.id) {
                  <label
                    class="inline-flex min-h-[44px] cursor-pointer items-center gap-2 rounded-full border px-3 text-sm transition-all duration-[333ms] hover:-translate-y-0.5"
                    [class.border-primary]="deviceId() === d.id"
                    [class.bg-primary/10]="deviceId() === d.id"
                    [class.border-border]="deviceId() !== d.id"
                  >
                    <input
                      type="radio"
                      name="bcl-terminal-device"
                      class="accent-primary"
                      [value]="d.id"
                      [checked]="deviceId() === d.id"
                      (change)="selectDevice(d.id)"
                    />
                    <span
                      class="h-2 w-2 rounded-full"
                      [class.bg-emerald-400]="d.status === 'available'"
                      [class.bg-amber-400]="d.status === 'busy'"
                      [class.bg-slate-500]="d.status === 'offline'"
                      aria-hidden="true"
                    ></span>
                    {{ d.name }}
                  </label>
                }
              </div>
            </fieldset>
          } @else {
            <label class="block">
              <span class="text-xs uppercase tracking-wider text-muted-foreground">Reader device ID</span>
              <input
                type="text"
                [ngModel]="deviceId()"
                (ngModelChange)="setDeviceId($event)"
                class="mt-1 min-h-[44px] w-full rounded-lg border border-border bg-background px-3 text-base text-foreground transition-all duration-[333ms] focus:outline-none focus:ring-2 focus:ring-primary"
                aria-label="Square reader device ID"
                placeholder="device-xxxxxxxx"
                data-testid="terminal-device-id"
              />
              @if (devicesError()) {
                <span class="mt-1 block text-xs text-muted-foreground">{{ devicesError() }}</span>
              }
            </label>
          }

          <button
            hlmBtn
            type="button"
            (click)="create()"
            [disabled]="!canSend()"
            data-testid="terminal-send"
            class="transition-all duration-[333ms]"
          >
            {{ pending() ? 'Sending…' : 'Send ' + amountLabel() + ' to reader' }}
          </button>
        </div>
      } @else {
        <!-- Active checkout -->
        <div class="mt-4 rounded-lg border p-3 transition-all duration-[333ms]" [class]="view().tile">
          <p class="text-2xl font-bold text-foreground">{{ amountLabel() }}</p>
          <p class="mt-1 text-sm text-muted-foreground">{{ view().sublabel }}</p>
        </div>

        <div class="mt-3 flex flex-wrap gap-2">
          @if (!view().done) {
            <button
              hlmBtn
              variant="outline"
              type="button"
              (click)="pollOnce()"
              [disabled]="pending()"
              class="transition-all duration-[333ms]"
            >
              Refresh
            </button>
          }
          @if (cancelable()) {
            <button
              hlmBtn
              variant="outline"
              type="button"
              (click)="cancel()"
              [disabled]="pending()"
              data-testid="terminal-cancel"
              class="text-red-500 transition-all duration-[333ms]"
            >
              Cancel charge
            </button>
          }
          @if (view().done) {
            <button
              hlmBtn
              type="button"
              (click)="reset()"
              data-testid="terminal-new"
              class="transition-all duration-[333ms]"
            >
              New charge
            </button>
          }
        </div>
      }

      @if (error(); as e) {
        <p
          class="mt-3 rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground"
          role="alert"
          data-testid="terminal-error"
        >
          {{ e }}
        </p>
      }
    </div>
  `,
})
export class TerminalCheckoutCardComponent {
  private readonly destroyRef = inject(DestroyRef);

  readonly bookingId = input.required<string>();
  readonly defaultAmountCents = input<number>(0);

  /** Emits once a checkout reaches COMPLETED — the parent can refresh balances. */
  readonly paid = output<{ bookingId: string; amountCents: number }>();

  amountDollars: number | null = null;
  readonly deviceId = signal<string>('');
  readonly devices = signal<TerminalDevice[]>([]);
  readonly devicesError = signal<string | null>(null);
  readonly checkoutId = signal<string | null>(null);
  readonly status = signal<TerminalCheckoutStatus>('UNKNOWN');
  readonly pending = signal<boolean>(false);
  readonly error = signal<string | null>(null);

  readonly view = computed(() => terminalStatusView(this.status()));
  readonly cancelable = computed(() => isTerminalCheckoutCancelable(this.status()));

  private pollTimer: ReturnType<typeof setTimeout> | null = null;
  private initialized = false;

  constructor() {
    this.destroyRef.onDestroy(() => this.stopPolling());
    // Restore the last reader the crew used (read once, browser-only).
    try {
      const saved = globalThis.localStorage?.getItem(DEVICE_STORAGE_KEY);
      if (saved) this.deviceId.set(saved);
    } catch {
      /* private mode / SSR — no-op */
    }
  }

  ngOnInit(): void {
    if (this.initialized) return;
    this.initialized = true;
    const cents = this.defaultAmountCents();
    if (cents > 0) this.amountDollars = Math.round(cents) / 100;
    void this.loadDevices();
  }

  // A plain method (not computed) — it reads the non-signal `amountDollars`
  // field, which a computed() can't track; re-evaluated each change detection.
  canSend(): boolean {
    if (this.pending()) return false;
    if (terminalAmountToCents(this.amountDollars) < 50) return false;
    return this.deviceId().trim().length >= 8;
  }

  amountLabel(): string {
    const cents = this.checkoutId() ? this.activeAmountCents : terminalAmountToCents(this.amountDollars);
    return `$${(cents / 100).toFixed(2)}`;
  }

  private activeAmountCents = 0;

  selectDevice(id: string): void {
    this.setDeviceId(id);
  }

  setDeviceId(id: string): void {
    this.deviceId.set(id);
    try {
      if (id.trim()) globalThis.localStorage?.setItem(DEVICE_STORAGE_KEY, id.trim());
    } catch {
      /* no-op */
    }
  }

  async loadDevices(): Promise<void> {
    this.devicesError.set(null);
    try {
      const res = await fetch('/api/work/terminal-checkout/devices', { credentials: 'include' });
      if (!res.ok) {
        this.devicesError.set(
          res.status === 503
            ? 'Reader list unavailable — enter the device ID shown on your reader.'
            : 'Couldn’t load readers — enter the device ID manually.',
        );
        return;
      }
      const body = (await res.json()) as { devices?: TerminalDevice[] };
      const list = Array.isArray(body.devices) ? body.devices : [];
      this.devices.set(list);
      // Auto-select the remembered reader if it's still paired, else the first.
      const remembered = this.deviceId();
      if (!remembered || !list.some((d) => d.id === remembered)) {
        const firstAvailable = list.find((d) => d.status === 'available') ?? list[0];
        if (firstAvailable) this.deviceId.set(firstAvailable.id);
      }
    } catch {
      this.devicesError.set('Couldn’t load readers — enter the device ID manually.');
    }
  }

  async create(): Promise<void> {
    if (!this.canSend()) return;
    const amountCents = terminalAmountToCents(this.amountDollars);
    this.pending.set(true);
    this.error.set(null);
    try {
      const res = await fetch('/api/work/terminal-checkout', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amountCents, deviceId: this.deviceId().trim(), bookingId: this.bookingId() }),
      });
      if (!res.ok) {
        const body = (await res.json().catch(() => ({}))) as { code?: string; error?: string };
        this.error.set(terminalCreateErrorMessage(res.status, body.code ?? body.error));
        return;
      }
      const body = (await res.json()) as { checkout?: { id?: string; status?: string } };
      const id = body.checkout?.id ?? '';
      if (!id) {
        this.error.set(terminalCreateErrorMessage(502));
        return;
      }
      this.activeAmountCents = amountCents;
      this.checkoutId.set(id);
      this.status.set(normalizeTerminalStatus(body.checkout?.status) || 'PENDING');
      this.schedulePoll();
    } catch {
      this.error.set('Connection issue. Check your signal and try again.');
    } finally {
      this.pending.set(false);
    }
  }

  async pollOnce(): Promise<void> {
    const id = this.checkoutId();
    if (!id) return;
    this.error.set(null);
    try {
      const res = await fetch(`/api/work/terminal-checkout/${encodeURIComponent(id)}`, {
        credentials: 'include',
      });
      if (!res.ok) {
        const body = (await res.json().catch(() => ({}))) as { code?: string; error?: string };
        this.error.set(terminalCreateErrorMessage(res.status, body.code ?? body.error));
        return;
      }
      const body = (await res.json()) as { status?: string };
      const next = normalizeTerminalStatus(body.status);
      this.status.set(next);
      if (isTerminalCheckoutTerminal(next)) {
        this.stopPolling();
        if (next === 'COMPLETED') this.paid.emit({ bookingId: this.bookingId(), amountCents: this.activeAmountCents });
      } else {
        this.schedulePoll();
      }
    } catch {
      // Transient — keep the loop alive; the next tick retries.
      this.schedulePoll();
    }
  }

  async cancel(): Promise<void> {
    const id = this.checkoutId();
    if (!id || !this.cancelable()) return;
    this.pending.set(true);
    this.error.set(null);
    this.stopPolling();
    try {
      const res = await fetch(`/api/work/terminal-checkout/${encodeURIComponent(id)}/cancel`, {
        method: 'POST',
        credentials: 'include',
      });
      const body = (await res.json().catch(() => ({}))) as { status?: string; code?: string; error?: string };
      if (!res.ok) {
        this.error.set(terminalCreateErrorMessage(res.status, body.code ?? body.error));
        // A 409 means it finished mid-cancel — reflect the true status.
        if (res.status === 409 && body.status) this.status.set(normalizeTerminalStatus(body.status));
        return;
      }
      this.status.set(normalizeTerminalStatus(body.status) || 'CANCELED');
    } catch {
      this.error.set('Connection issue while canceling. Refresh to confirm the reader state.');
    } finally {
      this.pending.set(false);
    }
  }

  reset(): void {
    this.stopPolling();
    this.checkoutId.set(null);
    this.status.set('UNKNOWN');
    this.error.set(null);
    this.activeAmountCents = 0;
    this.amountDollars = null;
    const cents = this.defaultAmountCents();
    if (cents > 0) this.amountDollars = Math.round(cents) / 100;
  }

  private schedulePoll(): void {
    this.stopPolling();
    this.pollTimer = setTimeout(() => void this.pollOnce(), POLL_INTERVAL_MS);
  }

  private stopPolling(): void {
    if (this.pollTimer !== null) {
      clearTimeout(this.pollTimer);
      this.pollTimer = null;
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'terminal-checkout-card-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
