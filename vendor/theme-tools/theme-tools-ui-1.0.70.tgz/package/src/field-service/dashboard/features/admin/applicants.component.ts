import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * AdminApplicantsComponent — Angular+Spartan port of the React ApplicantsBrowser.
 * Operator review surface for crew-intake applicants on the unified Angular
 * dashboard. This is the cutover blocker: /admin/applicants existed only in
 * React; porting it here lets the dual dashboards be dissolved.
 *
 *   GET  /api/admin/applicants?status=          → { ok, applicants:[…] }
 *   GET  /api/admin/applicants/:id               → { ok, applicant }
 *   POST /api/admin/applicants/:id/transition     { to }
 *   POST /api/admin/applicants/:id/background/invite
 *   POST /api/admin/applicants/:id/background/bypass    { reason }
 * ownerOrSuperAdmin gate (session cookie). dispatch_ready is refused server-side
 * until every required check clears.
 */
import { ChangeDetectionStrategy, Component, type OnInit, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HlmCardImports } from '../../shared/ui-spartan';

interface ListRow {
  readonly id: string;
  readonly status: string;
  readonly name: string;
  readonly city: string;
  readonly wantsDriver: boolean;
  readonly emailVerified: boolean;
  readonly phoneVerified: boolean;
}
interface ChecklistItem {
  readonly key: string;
  readonly label: string;
  readonly done: boolean;
  readonly applicable: boolean;
}
interface AdminApplicant {
  readonly id: string;
  readonly status: string;
  readonly legalFirstName: string;
  readonly legalLastName: string;
  readonly email: string;
  readonly phone: string;
  readonly city: string;
  readonly zip: string;
  readonly wantsDriver: boolean;
  readonly aiDispatchProfile: string | null;
  readonly aiCrewLeadPotential: string | null;
  readonly aiSafetyNotes: string[];
  readonly driver: {
    readonly licenseState: string | null;
    readonly frontUploaded: boolean;
    readonly backUploaded: boolean;
    readonly identityStatus: string | null;
    /** True when the stored ID ref is a dev stub (`mock_id_…`) — never really verified. */
    readonly identityMock: boolean;
    readonly mvrStatus: string | null;
  };
  readonly checklist: ChecklistItem[];
}

/** Pure: humanize a snake_case applicant status for display. Exported for tests. */
export function applicantStatusLabel(s: string): string {
  return s.replace(/_/g, ' ');
}

/** Pure: the checklist items an operator should see (applicable only). */
export function filterApplicable(items: readonly ChecklistItem[]): ChecklistItem[] {
  return items.filter((c) => c.applicable);
}

/**
 * Pure: humanize a single dispatch-blocked reason into a sentence-case label.
 * Server sends snake_case keys (e.g. `email_unverified`); render one pill each.
 * Exported for tests.
 */
export function humanizeBlocker(reason: string): string {
  const cleaned = reason.replace(/_/g, ' ').replace(/\s+/g, ' ').trim();
  if (!cleaned) return 'Requirement not met';
  return cleaned.charAt(0).toUpperCase() + cleaned.slice(1);
}

const STATUS_FILTERS = [
  '',
  'profile_complete',
  'needs_phone_screen',
  'conditionally_approved',
  'background_check_invited',
  'driver_docs_needed',
  'dispatch_ready',
  'rejected',
] as const;

const ACTIONS: ReadonlyArray<{ label: string; to: string; tone?: 'primary' | 'danger' }> = [
  { label: 'Phone screen done', to: 'needs_phone_screen' },
  { label: 'Conditionally approve', to: 'conditionally_approved' },
  { label: 'Background review', to: 'background_check_review' },
  { label: 'Approve driver', to: 'driver_approved' },
  { label: 'Dispatch-ready', to: 'dispatch_ready', tone: 'primary' },
  { label: 'Reject', to: 'rejected', tone: 'danger' },
  { label: 'Deactivate', to: 'inactive' },
];

@Component({
  selector: 'app-admin-applicants',
  standalone: true,
  imports: [...HlmCardImports],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div hlmCard data-testid="admin-applicants">
      <div hlmCardHeader>
        <h3 hlmCardTitle>Crew applicants</h3>
        <p hlmCardDescription>
          Review the Apply-to-Work pipeline + move applicants through statuses.
        </p>
      </div>
      <div hlmCardContent>
        <div class="mb-3 flex flex-wrap gap-2">
          @for (s of statusFilters; track s) {
            <button
              type="button"
              (click)="setStatus(s)"
              [attr.aria-pressed]="status() === s"
              class="rounded-full border px-3 py-1 text-xs focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
              [class.border-bcl-accent]="status() === s"
              [class.text-bcl-ink]="status() === s"
              [class.border-bcl-border]="status() !== s"
              [class.text-bcl-ink-muted]="status() !== s"
            >
              {{ s ? label(s) : 'all' }}
            </button>
          }
        </div>

        @if (loading()) {
          <p class="text-sm text-bcl-ink-muted">Loading applicants…</p>
        } @else if (error()) {
          <div role="status">
            <p class="text-sm text-bcl-warn">{{ error() }}</p>
            @if (blockers().length) {
              <ul
                class="mt-2 flex flex-wrap gap-1.5"
                aria-label="Unmet dispatch requirements"
                data-testid="applicant-blockers"
              >
                @for (b of blockers(); track b) {
                  <li
                    class="inline-flex min-h-[24px] items-center gap-1 rounded-full border border-bcl-warn/40 bg-bcl-warn/10 px-2.5 py-1 text-xs text-bcl-warn transition-all duration-[333ms] hover:-translate-y-0.5 hover:border-bcl-warn"
                  >
                    <span aria-hidden="true">⚠</span>{{ blockerLabel(b) }}
                  </li>
                }
              </ul>
            }
          </div>
        } @else {
          @if (rows().length === 0) {
            <p class="text-sm text-bcl-ink-muted">No applicants in this status.</p>
          } @else {
            <table class="w-full text-left text-sm">
              <thead class="text-xs uppercase tracking-wider text-bcl-ink-muted">
                <tr>
                  <th class="py-2">Name</th>
                  <th>City</th>
                  <th>Status</th>
                  <th>Verified</th>
                  <th>Driver</th>
                </tr>
              </thead>
              <tbody>
                @for (r of rows(); track r.id) {
                  <tr
                    class="border-t border-bcl-border transition-colors duration-[333ms] hover:bg-bcl-bg-elev focus-within:bg-bcl-bg-elev"
                  >
                    <td class="py-2 font-medium text-bcl-ink">
                      <button
                        type="button"
                        (click)="open(r.id)"
                        [attr.aria-label]="'Open applicant ' + (r.name || r.id)"
                        data-testid="applicant-open"
                        class="rounded text-left transition-colors duration-[333ms] hover:text-bcl-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
                      >
                        {{ r.name || '—' }}
                      </button>
                    </td>
                    <td class="text-bcl-ink-muted">{{ r.city }}</td>
                    <td>
                      <span class="font-mono text-xs">{{ r.status }}</span>
                    </td>
                    <td class="text-xs">
                      {{ r.emailVerified ? '✉︎' : '·' }} {{ r.phoneVerified ? '☎︎' : '·' }}
                    </td>
                    <td class="text-xs">{{ r.wantsDriver ? 'yes' : '—' }}</td>
                  </tr>
                }
              </tbody>
            </table>
          }
        }

        @if (selected(); as a) {
          <div class="mt-4 rounded-xl border border-bcl-border p-4" data-testid="applicant-detail">
            <div class="flex items-start justify-between gap-3">
              <div>
                <h4 class="text-base font-semibold text-bcl-ink">
                  {{ a.legalFirstName }} {{ a.legalLastName }}
                </h4>
                <p class="text-xs text-bcl-ink-muted">
                  {{ a.email }} · {{ a.phone }} · {{ a.city }} {{ a.zip }}
                </p>
                <p class="mt-1 font-mono text-xs text-bcl-accent">{{ a.status }}</p>
              </div>
              <button type="button" (click)="selected.set(null)" class="text-xs text-bcl-ink-muted focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring">
                close ✕
              </button>
            </div>

            @if (a.aiDispatchProfile) {
              <div class="mt-3 rounded-lg border border-bcl-border p-3">
                <p class="text-[10px] uppercase tracking-wider text-bcl-ink-muted">
                  AI dispatch profile · crew-lead {{ a.aiCrewLeadPotential }}
                </p>
                <p class="mt-1 text-sm text-bcl-ink">{{ a.aiDispatchProfile }}</p>
                @for (n of a.aiSafetyNotes; track n) {
                  <p class="mt-1 text-xs text-bcl-warn">⚠ {{ n }}</p>
                }
              </div>
            }

            @if (a.wantsDriver) {
              <p class="mt-3 text-xs text-bcl-ink-muted">
                Driver: {{ a.driver.licenseState ?? '—' }} · front
                {{ a.driver.frontUploaded ? '✓' : '✗' }} · back
                {{ a.driver.backUploaded ? '✓' : '✗' }} · identity
                {{ a.driver.identityStatus ?? '—' }} · mvr {{ a.driver.mvrStatus ?? '—' }}
              </p>
              @if (a.driver.identityMock) {
                <p
                  class="mt-2 inline-flex min-h-[24px] items-center gap-1 rounded-full border border-bcl-warn/40 bg-bcl-warn/10 px-2.5 py-0.5 text-[11px] font-medium text-bcl-warn"
                  role="status"
                  aria-label="Identity not verified — dev stub only, do not promote as verified"
                >
                  ⚠ Identity not really verified — dev stub (no Stripe Identity key)
                </p>
              }
            }

            <div class="mt-3">
              <p class="text-[10px] uppercase tracking-wider text-bcl-ink-muted">Checklist</p>
              <ul class="mt-1 grid grid-cols-2 gap-1 text-xs">
                @for (c of applicableChecklist(a); track c.key) {
                  <li [class.text-bcl-success]="c.done" [class.text-bcl-ink-muted]="!c.done">
                    {{ c.done ? '✓' : '○' }} {{ c.label }}
                  </li>
                }
              </ul>
            </div>

            <div class="mt-4 flex flex-wrap gap-2">
              <button
                type="button"
                (click)="inviteBackground(a.id)"
                class="rounded-md border border-bcl-border px-3 py-1.5 text-xs text-bcl-ink-muted focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
              >
                Invite background
              </button>
              <button
                type="button"
                (click)="bypassBackground(a.id)"
                class="rounded-md border border-bcl-border px-3 py-1.5 text-xs text-bcl-ink-muted focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                title="Manually clear the Checkr background (+ MVR for drivers) — logged to audit"
              >
                Bypass Checkr
              </button>
              @for (act of actions; track act.to) {
                <button
                  type="button"
                  (click)="transition(a.id, act.to)"
                  class="rounded-md px-3 py-1.5 text-xs font-medium focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                  [class.bg-bcl-accent]="act.tone === 'primary'"
                  [class.text-bcl-bg]="act.tone === 'primary'"
                  [class.border]="act.tone !== 'primary'"
                  [class.border-bcl-border]="!act.tone"
                  [class.text-bcl-ink-muted]="!act.tone"
                  [class.border-destructive]="act.tone === 'danger'"
                  [class.text-destructive]="act.tone === 'danger'"
                >
                  {{ act.label }}
                </button>
              }
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class AdminApplicantsComponent implements OnInit {
  private readonly http = inject(HttpClient);
  readonly statusFilters = STATUS_FILTERS;
  readonly actions = ACTIONS;
  readonly rows = signal<readonly ListRow[]>([]);
  readonly status = signal<string>('');
  readonly loading = signal(true);
  readonly error = signal('');
  /** Dispatch-blocked reasons, rendered as one warn pill each. */
  readonly blockers = signal<readonly string[]>([]);
  readonly selected = signal<AdminApplicant | null>(null);

  blockerLabel(reason: string): string {
    return humanizeBlocker(reason);
  }

  ngOnInit(): void {
    void this.load();
  }

  label(s: string): string {
    return applicantStatusLabel(s);
  }

  applicableChecklist(a: AdminApplicant): ChecklistItem[] {
    return filterApplicable(a.checklist);
  }

  setStatus(s: string): void {
    this.status.set(s);
    void this.load();
  }

  private async get<T>(path: string): Promise<T | null> {
    return firstValueFrom(
      this.http
        .get<T>(`/api/admin/applicants${path}`, { withCredentials: true })
        .pipe(catchError(() => of(null))),
    );
  }
  private async post<T>(path: string): Promise<T | null> {
    return firstValueFrom(
      this.http
        .post<T>(`/api/admin/applicants${path}`, {}, { withCredentials: true })
        .pipe(catchError(() => of(null))),
    );
  }

  async load(): Promise<void> {
    this.loading.set(true);
    this.error.set('');
    this.blockers.set([]);
    const r = await this.get<{ ok: boolean; applicants?: ListRow[] }>(
      this.status() ? `?status=${encodeURIComponent(this.status())}` : '',
    );
    this.loading.set(false);
    if (!r?.ok || !r.applicants) {
      this.error.set('Sign in as an operator to view applicants.');
      return;
    }
    this.rows.set(r.applicants);
  }

  async open(id: string): Promise<void> {
    const r = await this.get<{ ok: boolean; applicant?: AdminApplicant }>(`/${id}`);
    if (r?.ok && r.applicant) this.selected.set(r.applicant);
  }

  async transition(id: string, to: string): Promise<void> {
    const r = await firstValueFrom(
      this.http
        .post<{
          ok: boolean;
          applicant?: AdminApplicant;
          blockers?: string[];
          code?: string;
        }>(`/api/admin/applicants/${id}/transition`, { to }, { withCredentials: true })
        .pipe(catchError(() => of(null))),
    );
    if (!r?.ok) {
      if (r?.code === 'dispatch_blocked') {
        this.error.set('Clear these before this applicant can move forward:');
        this.blockers.set(r.blockers ?? []);
      } else {
        this.error.set('Transition not allowed.');
        this.blockers.set([]);
      }
      return;
    }
    this.error.set('');
    this.blockers.set([]);
    if (r.applicant) this.selected.set(r.applicant);
    void this.load();
  }

  async inviteBackground(id: string): Promise<void> {
    const r = await this.post<{ ok: boolean; applicant?: AdminApplicant }>(
      `/${id}/background/invite`,
    );
    if (r?.ok && r.applicant) this.selected.set(r.applicant);
    void this.load();
  }

  /** Manually clear the Checkr step (background + driver MVR). Reason is audited. */
  async bypassBackground(id: string): Promise<void> {
    const reason = (
      globalThis.prompt('Reason for manually bypassing the Checkr check (logged to audit):') ?? ''
    ).trim();
    if (reason.length < 3) return;
    const r = await firstValueFrom(
      this.http
        .post<{ ok: boolean; applicant?: AdminApplicant }>(
          `/api/admin/applicants/${id}/background/bypass`,
          { reason },
          { withCredentials: true },
        )
        .pipe(catchError(() => of(null))),
    );
    if (r?.ok && r.applicant) this.selected.set(r.applicant);
    void this.load();
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'applicants-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
