import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * AdminClassificationRiskComponent — crew (1099) misclassification-RISK
 * decision-support on the admin console. Live surface = Angular
 * /dashboard/admin/classification-risk.
 *
 * Wires the previously-unwired pure DOL six-factor engine
 * (src/shared/worker-classification.ts) to a UI via the worker API:
 *   GET  /api/admin/classification/platform-defaults → grounded Brick Labor posture + its assessment
 *   POST /api/admin/classification/assess { ...signals } → ClassificationResult
 * Both are super-admin-gated and 404 when the crew_classification_risk flag is
 * dark. The component self-gates on FeatureFlagService.isOn(...) and renders a
 * disabled note when off.
 *
 * Tri-state inputs (Yes / No / Unknown) preserve the engine's honest semantic:
 * an UNKNOWN signal is neutral, never assumed favorable. Results stream live on
 * every change (debounced, race-guarded via switchMap) — no manual run button.
 *
 * DECISION-SUPPORT, never legal advice — it surfaces risk for human + counsel
 * review and makes NO legal determination. Pure helpers (bandTone, factorPct,
 * leanLabel) are unit-tested.
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  type OnInit,
  computed,
  inject,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { HttpClient } from '@angular/common/http';
import { Subject, debounceTime, firstValueFrom, switchMap } from 'rxjs';
import { HlmCardImports } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';
import { FeatureFlagService } from '../../core/feature-flag.service';

/** Server flag gating the whole surface (route 404s when dark). */
const FLAG = 'crew_classification_risk';

type FactorLean = 'independent' | 'neutral' | 'employee';
type RiskBand = 'low' | 'moderate' | 'elevated' | 'high';
type Supervision = 'none' | 'light' | 'direct';
type Permanence = 'per_job' | 'ongoing_at_will' | 'indefinite';

/** Mirror of the shared EngagementSignals shape (worker is the authority). */
export interface EngagementSignals {
  canDeclineJobsFreely?: boolean;
  setsOwnSchedule?: boolean;
  setsOrNegotiatesRate?: boolean;
  freeToWorkForCompetitors?: boolean;
  providesOwnToolsAndVehicle?: boolean;
  marketsOwnSpecializedSkill?: boolean;
  requiredToWearCompanyBranding?: boolean;
  requiresCompanySpecificTraining?: boolean;
  exclusiveToCompany?: boolean;
  supervision?: Supervision;
  permanence?: Permanence;
  workIsCoreService?: boolean;
}

interface FactorAssessment {
  readonly key: string;
  readonly label: string;
  readonly lean: FactorLean;
  readonly employeeLeanScore: number;
  readonly rationale: string;
}

export interface ClassificationResult {
  readonly riskScore: number;
  readonly band: RiskBand;
  readonly factors: readonly FactorAssessment[];
  readonly redFlags: readonly string[];
  readonly guardrails: readonly string[];
}

interface AssessResponse {
  readonly ok: boolean;
  readonly result?: ClassificationResult;
}
interface DefaultsResponse {
  readonly ok: boolean;
  readonly signals?: EngagementSignals;
  readonly result?: ClassificationResult;
}

/** One tri-state boolean signal field. */
interface BoolField {
  readonly key: keyof EngagementSignals;
  readonly label: string;
  readonly hint: string;
}

/** Pure: band → a tone key for color classes. */
export function bandTone(band: RiskBand): 'ok' | 'info' | 'warn' | 'danger' {
  switch (band) {
    case 'low':
      return 'ok';
    case 'moderate':
      return 'info';
    case 'elevated':
      return 'warn';
    case 'high':
      return 'danger';
  }
}

/** Pure: clamp an employee-lean score to a 0-100 bar width percentage. */
export function factorPct(employeeLeanScore: number): number {
  if (!Number.isFinite(employeeLeanScore)) return 50;
  return Math.max(0, Math.min(100, Math.round(employeeLeanScore)));
}

/** Pure: human label for a factor lean. */
export function leanLabel(lean: FactorLean): string {
  if (lean === 'independent') return 'Independent';
  if (lean === 'employee') return 'Employee';
  return 'Neutral';
}

@Component({
  selector: 'app-admin-classification-risk',
  standalone: true,
  imports: [...HlmCardImports, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="grid gap-4" data-testid="admin-classification-risk">
      <div hlmCard bclReveal>
        <div hlmCardHeader>
          <h3 hlmCardTitle>Crew classification risk</h3>
          <p hlmCardDescription>
            Model a crew engagement against the DOL 2026 six-factor economic-reality test. Decision
            support for you + counsel — not legal advice, and not a legal determination.
          </p>
        </div>
      </div>

      @if (!enabled()) {
        <div
          hlmCard
          bclReveal
          class="p-5 text-sm text-bcl-ink-muted"
          role="status"
          data-testid="classification-disabled"
        >
          This tool is turned off. Enable the
          <span class="text-bcl-accent">crew_classification_risk</span> flag in
          <a class="underline hover:text-bcl-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring" routerLink="/admin/flags">Feature flags</a>
          to use it.
        </div>
      } @else {
        <div class="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
          <!-- Inputs -->
          <div hlmCard bclReveal>
            <div hlmCardHeader>
              <h4 hlmCardTitle class="text-base">How is this crew engaged?</h4>
              <p hlmCardDescription>
                Seeded with Brick Labor's platform posture. "Unknown" stays neutral — never assumed
                in your favor.
              </p>
            </div>
            <div hlmCardContent class="grid gap-3">
              @for (f of boolFields; track f.key) {
                <div class="grid gap-1.5">
                  <div class="flex items-baseline justify-between gap-2">
                    <span class="text-sm text-bcl-ink">{{ f.label }}</span>
                  </div>
                  <p class="text-xs text-bcl-ink-muted">{{ f.hint }}</p>
                  <div class="inline-flex gap-1" role="group" [attr.aria-label]="f.label">
                    <button
                      type="button"
                      class="rounded-md px-2.5 py-1 text-xs ring-1 transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                      [class.ring-bcl-accent]="boolVal(f.key) === true"
                      [class.bg-bcl-accent\/15]="boolVal(f.key) === true"
                      [class.text-bcl-accent]="boolVal(f.key) === true"
                      [class.ring-bcl-border]="boolVal(f.key) !== true"
                      [class.text-bcl-ink-muted]="boolVal(f.key) !== true"
                      (click)="setBool(f.key, true)"
                    >
                      Yes
                    </button>
                    <button
                      type="button"
                      class="rounded-md px-2.5 py-1 text-xs ring-1 transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                      [class.ring-bcl-warn]="boolVal(f.key) === false"
                      [class.bg-bcl-warn\/15]="boolVal(f.key) === false"
                      [class.text-bcl-warn]="boolVal(f.key) === false"
                      [class.ring-bcl-border]="boolVal(f.key) !== false"
                      [class.text-bcl-ink-muted]="boolVal(f.key) !== false"
                      (click)="setBool(f.key, false)"
                    >
                      No
                    </button>
                    <button
                      type="button"
                      class="rounded-md px-2.5 py-1 text-xs ring-1 transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                      [class.ring-bcl-accent]="boolVal(f.key) === undefined"
                      [class.text-bcl-ink]="boolVal(f.key) === undefined"
                      [class.ring-bcl-border]="boolVal(f.key) !== undefined"
                      [class.text-bcl-ink-muted]="boolVal(f.key) !== undefined"
                      (click)="setBool(f.key, undefined)"
                    >
                      Unknown
                    </button>
                  </div>
                </div>
              }

              <!-- Supervision -->
              <div class="grid gap-1.5">
                <span class="text-sm text-bcl-ink">Supervision of how the work is done</span>
                <div class="inline-flex gap-1" role="group" aria-label="Supervision">
                  @for (opt of supervisionOpts; track opt.v) {
                    <button
                      type="button"
                      class="rounded-md px-2.5 py-1 text-xs ring-1 transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                      [class.ring-bcl-accent]="signals().supervision === opt.v"
                      [class.bg-bcl-accent\/15]="signals().supervision === opt.v"
                      [class.text-bcl-accent]="signals().supervision === opt.v"
                      [class.ring-bcl-border]="signals().supervision !== opt.v"
                      [class.text-bcl-ink-muted]="signals().supervision !== opt.v"
                      (click)="setSupervision(opt.v)"
                    >
                      {{ opt.label }}
                    </button>
                  }
                </div>
              </div>

              <!-- Permanence -->
              <div class="grid gap-1.5">
                <span class="text-sm text-bcl-ink">Permanence of the relationship</span>
                <div class="inline-flex gap-1" role="group" aria-label="Permanence">
                  @for (opt of permanenceOpts; track opt.v) {
                    <button
                      type="button"
                      class="rounded-md px-2.5 py-1 text-xs ring-1 transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                      [class.ring-bcl-accent]="signals().permanence === opt.v"
                      [class.bg-bcl-accent\/15]="signals().permanence === opt.v"
                      [class.text-bcl-accent]="signals().permanence === opt.v"
                      [class.ring-bcl-border]="signals().permanence !== opt.v"
                      [class.text-bcl-ink-muted]="signals().permanence !== opt.v"
                      (click)="setPermanence(opt.v)"
                    >
                      {{ opt.label }}
                    </button>
                  }
                </div>
              </div>
            </div>
          </div>

          <!-- Result -->
          <div hlmCard bclReveal>
            <div hlmCardHeader>
              <h4 hlmCardTitle class="text-base">Risk assessment</h4>
              <p hlmCardDescription>Higher = more employee-like = higher misclassification risk.</p>
            </div>
            <div hlmCardContent class="grid gap-4">
              @if (error()) {
                <p class="text-sm text-bcl-warn" role="status">{{ error() }}</p>
              } @else if (!result()) {
                <p class="text-sm text-bcl-ink-muted">Assessing…</p>
              } @else {
                <!-- Score + band -->
                <div class="flex items-center gap-4" data-testid="risk-score">
                  <div class="text-4xl font-semibold tabular-nums text-bcl-ink">
                    {{ result()!.riskScore }}<span class="text-lg text-bcl-ink-muted">/100</span>
                  </div>
                  <span
                    class="rounded-full px-3 py-1 text-xs uppercase tracking-wider ring-1"
                    [class.text-bcl-accent]="tone() === 'ok'"
                    [class.ring-bcl-accent\/40]="tone() === 'ok'"
                    [class.text-bcl-ink]="tone() === 'info'"
                    [class.ring-bcl-border]="tone() === 'info'"
                    [class.text-bcl-warn]="tone() === 'warn' || tone() === 'danger'"
                    [class.ring-bcl-warn\/40]="tone() === 'warn' || tone() === 'danger'"
                    >{{ result()!.band }} risk</span
                  >
                </div>

                <!-- Factors -->
                <div class="grid gap-2">
                  @for (f of result()!.factors; track f.key) {
                    <div class="grid gap-1">
                      <div class="flex items-baseline justify-between gap-2 text-xs">
                        <span class="text-bcl-ink">{{ f.label }}</span>
                        <span
                          class="font-mono uppercase tracking-wider"
                          [class.text-bcl-accent]="f.lean === 'independent'"
                          [class.text-bcl-ink-muted]="f.lean === 'neutral'"
                          [class.text-bcl-warn]="f.lean === 'employee'"
                          >{{ lean(f.lean) }}</span
                        >
                      </div>
                      <div class="h-1.5 overflow-hidden rounded-full bg-bcl-bg-elev">
                        <div
                          class="h-full rounded-full transition-all"
                          [class.bg-bcl-accent]="f.lean === 'independent'"
                          [class.bg-bcl-ink-muted]="f.lean === 'neutral'"
                          [class.bg-bcl-warn]="f.lean === 'employee'"
                          [style.width.%]="pct(f.employeeLeanScore)"
                        ></div>
                      </div>
                      <p class="text-[11px] text-bcl-ink-muted">{{ f.rationale }}</p>
                    </div>
                  }
                </div>

                <!-- Red flags -->
                @if (result()!.redFlags.length) {
                  <div class="grid gap-1.5">
                    <span class="text-xs font-mono uppercase tracking-wider text-bcl-warn"
                      >Red flags</span
                    >
                    <ul class="grid gap-1">
                      @for (rf of result()!.redFlags; track rf) {
                        <li
                          class="rounded-md border border-bcl-warn/30 bg-bcl-warn/5 px-3 py-1.5 text-xs text-bcl-ink"
                        >
                          {{ rf }}
                        </li>
                      }
                    </ul>
                  </div>
                }

                <!-- Guardrails -->
                @if (result()!.guardrails.length) {
                  <div class="grid gap-1.5" data-testid="guardrails">
                    <span class="text-xs font-mono uppercase tracking-wider text-bcl-accent"
                      >Guardrails to lower risk</span
                    >
                    <ul class="grid gap-1">
                      @for (g of result()!.guardrails; track g) {
                        <li
                          class="flex gap-2 rounded-md border border-bcl-border bg-bcl-bg-elev px-3 py-1.5 text-xs text-bcl-ink"
                        >
                          <span class="text-bcl-accent">&rarr;</span><span>{{ g }}</span>
                        </li>
                      }
                    </ul>
                  </div>
                } @else {
                  <p class="text-xs text-bcl-ink-muted">
                    No guardrails — this engagement already reads as a genuine independent contractor.
                  </p>
                }
              }
              <p class="mt-1 text-[11px] text-bcl-ink-muted">
                Grounded in the DOL 2024 Independent Contractor final rule (29 CFR 795). New Jersey's
                stricter "ABC" test layers on top. Review material risk with counsel.
              </p>
            </div>
          </div>
        </div>
      }
    </div>
  `,
})
export class AdminClassificationRiskComponent implements OnInit {
  private readonly http = inject(HttpClient);
  private readonly flags = inject(FeatureFlagService);
  private readonly destroyRef = inject(DestroyRef);

  readonly enabled = this.flags.isOn(FLAG);
  readonly signals = signal<EngagementSignals>({});
  readonly result = signal<ClassificationResult | null>(null);
  readonly error = signal<string>('');
  readonly tone = computed(() => {
    const r = this.result();
    return r ? bandTone(r.band) : 'info';
  });

  readonly lean = leanLabel;
  readonly pct = factorPct;

  private readonly assess$ = new Subject<EngagementSignals>();

  readonly boolFields: readonly BoolField[] = [
    {
      key: 'canDeclineJobsFreely',
      label: 'Can decline offered jobs freely',
      hint: 'No penalty or deactivation for turning a job down.',
    },
    {
      key: 'setsOwnSchedule',
      label: 'Sets their own schedule',
      hint: 'Chooses their own availability vs. assigned shifts.',
    },
    {
      key: 'setsOrNegotiatesRate',
      label: 'Sets or negotiates their rate',
      hint: 'Has a say in pay — an opportunity for profit.',
    },
    {
      key: 'freeToWorkForCompetitors',
      label: 'Free to work for competitors',
      hint: 'Not restricted to Brick Labor only.',
    },
    {
      key: 'providesOwnToolsAndVehicle',
      label: 'Provides own tools / vehicle',
      hint: 'Significant personal investment in equipment.',
    },
    {
      key: 'marketsOwnSpecializedSkill',
      label: 'Markets own specialized skill',
      hint: 'Runs their own business / advertises a trade.',
    },
    {
      key: 'requiredToWearCompanyBranding',
      label: 'Required to wear company branding',
      hint: 'Held out to customers AS the company.',
    },
    {
      key: 'requiresCompanySpecificTraining',
      label: 'Requires company-specific training',
      hint: 'Mandatory training as a condition of work.',
    },
    {
      key: 'exclusiveToCompany',
      label: 'Exclusive to the company',
      hint: 'Cannot take outside work.',
    },
    {
      key: 'workIsCoreService',
      label: 'Their labor IS the core service',
      hint: 'For a labor marketplace this is usually yes — an honest employee-leaning pull.',
    },
  ];

  readonly supervisionOpts: ReadonlyArray<{ v: Supervision; label: string }> = [
    { v: 'none', label: 'None' },
    { v: 'light', label: 'Light' },
    { v: 'direct', label: 'Direct' },
  ];
  readonly permanenceOpts: ReadonlyArray<{ v: Permanence; label: string }> = [
    { v: 'per_job', label: 'Per job' },
    { v: 'ongoing_at_will', label: 'Ongoing' },
    { v: 'indefinite', label: 'Indefinite' },
  ];

  constructor() {
    // Live assessment: every change pushes to assess$, debounced + race-guarded
    // via switchMap so only the newest POST's result lands.
    this.assess$
      .pipe(
        debounceTime(250),
        switchMap((s) =>
          this.http.post<AssessResponse>('/api/admin/classification/assess', s, {
            withCredentials: true,
          }),
        ),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe({
        next: (r) => {
          if (r?.ok && r.result) {
            this.result.set(r.result);
            this.error.set('');
          } else {
            this.error.set('Could not assess — check your operator session.');
          }
        },
        error: () => this.error.set('Sign in as an operator to use the classification tool.'),
      });
  }

  ngOnInit(): void {
    if (this.enabled()) void this.loadDefaults();
  }

  /** Seed the form + first result from the grounded platform posture. */
  async loadDefaults(): Promise<void> {
    try {
      const r = await firstValueFrom(
        this.http.get<DefaultsResponse>('/api/admin/classification/platform-defaults', {
          withCredentials: true,
        }),
      );
      if (r?.ok && r.signals) this.signals.set(r.signals);
      if (r?.ok && r.result) this.result.set(r.result);
    } catch {
      this.error.set('Sign in as an operator to use the classification tool.');
    }
  }

  boolVal(key: keyof EngagementSignals): boolean | undefined {
    return this.signals()[key] as boolean | undefined;
  }

  setBool(key: keyof EngagementSignals, val: boolean | undefined): void {
    const next = { ...this.signals() };
    if (val === undefined) delete next[key];
    else (next as Record<string, unknown>)[key] = val;
    this.signals.set(next);
    this.assess$.next(next);
  }

  setSupervision(v: Supervision): void {
    const next = { ...this.signals(), supervision: v };
    this.signals.set(next);
    this.assess$.next(next);
  }

  setPermanence(v: Permanence): void {
    const next = { ...this.signals(), permanence: v };
    this.signals.set(next);
    this.assess$.next(next);
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'classification-risk-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
