import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * ContentComponent — operator surface to curate the two content features that
 * shipped with admin APIs but no dashboard UI: Help Center articles
 * (/api/help-center) and the "What we don't do" list (/api/what-we-dont-do).
 *
 * Lists every row across all statuses (the admin GET returns draft + published +
 * archived; super-admins bypass the public feature flag), shows a status pill,
 * and lets the operator publish / unpublish (→ draft) / archive each row via the
 * existing PATCH /:id { status } endpoint. This is the missing "integrated into
 * the admin dashboard" surface for content the operator now needs to manage.
 *
 * No new backend: pure frontend port of existing admin CRUD. Spartan black/orange.
 */
import { ChangeDetectionStrategy, Component, DestroyRef, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RouterLink } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { catchError, finalize, of } from 'rxjs';

interface Article {
  readonly id: string;
  readonly title: string;
  readonly category: string;
  status: string;
}
interface DontDoItem {
  readonly id: string;
  readonly itemTitle: string;
  readonly category: string;
  status: string;
}
type Status = 'draft' | 'published' | 'archived';

@Component({
  selector: 'app-admin-content',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="bcl-rise mb-5 rounded-2xl border border-bcl-border bcl-grain p-6">
      <p class="bcl-eyebrow mb-2">Admin · Content</p>
      <h1 class="font-display text-3xl font-extrabold tracking-tight text-bcl-ink">
        Help Center &amp; “What we don’t do”
      </h1>
      <p class="mt-2 max-w-2xl text-sm text-bcl-ink-muted">
        Curate, publish, and archive customer-facing content. Public visibility is also gated by the
        <code class="text-bcl-accent">help_center</code> /
        <code class="text-bcl-accent">what_we_dont_do</code> flags — promote those from
        <a routerLink="/admin/flags" class="text-bcl-accent underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring">Flags</a> to go live.
      </p>
    </header>

    <!-- Help Center articles -->
    <section class="bcl-glass mb-5 p-5" data-testid="content-help">
      <h2 class="mb-3 font-display text-lg font-bold text-bcl-ink">Help Center articles</h2>
      <form
        class="mb-5 grid gap-3 rounded-xl border border-bcl-border p-4 md:grid-cols-2"
        data-testid="content-help-create"
        (submit)="createArticle($event)"
      >
        <label class="grid gap-1 text-xs text-bcl-ink-muted">
          Title
          <input
            class="rounded-lg border border-bcl-border bg-transparent px-3 py-2 text-sm text-bcl-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
            [value]="newTitle()"
            (input)="newTitle.set($any($event.target).value)"
            required
          />
        </label>
        <label class="grid gap-1 text-xs text-bcl-ink-muted">
          Slug
          <input
            class="rounded-lg border border-bcl-border bg-transparent px-3 py-2 text-sm text-bcl-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
            [value]="newSlug()"
            (input)="newSlug.set($any($event.target).value)"
            pattern="[a-z0-9]+(?:-[a-z0-9]+)*"
            required
          />
        </label>
        <label class="grid gap-1 text-xs text-bcl-ink-muted">
          Category
          <input
            class="rounded-lg border border-bcl-border bg-transparent px-3 py-2 text-sm text-bcl-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
            [value]="newCategory()"
            (input)="newCategory.set($any($event.target).value)"
            required
          />
        </label>
        <label class="grid gap-1 text-xs text-bcl-ink-muted md:col-span-2">
          Article body (Markdown)
          <textarea
            class="min-h-32 rounded-lg border border-bcl-border bg-transparent px-3 py-2 text-sm text-bcl-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
            [value]="newBody()"
            (input)="newBody.set($any($event.target).value)"
            required
          ></textarea>
        </label>
        <div class="flex items-center gap-3 md:col-span-2">
          <button
            type="submit"
            [disabled]="createBusy() || !canCreateArticle()"
            class="rounded-lg border border-bcl-accent bg-bcl-accent/10 px-4 py-2 text-sm font-semibold text-bcl-accent disabled:opacity-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
          >
            {{ createBusy() ? 'Creating…' : 'Create draft' }}
          </button>
          @if (createError()) {
            <p class="text-xs text-amber-300" role="alert">{{ createError() }}</p>
          }
        </div>
      </form>
      @if (helpError()) {
        <p
          class="rounded-lg border border-amber-500/30 bg-amber-500/5 p-3 text-xs text-amber-300"
          role="alert"
        >
          {{ helpError() }}
        </p>
      } @else if (helpLoading()) {
        <p class="text-sm text-bcl-ink-muted">Loading…</p>
      } @else if (articles().length === 0) {
        <p class="text-sm text-bcl-ink-muted" data-testid="content-help-empty">No articles yet.</p>
      } @else {
        <ul class="divide-y divide-bcl-border" role="list">
          @for (a of articles(); track a.id) {
            <li class="flex flex-wrap items-center justify-between gap-3 py-2.5">
              <div class="min-w-0">
                <p class="truncate text-sm font-medium text-bcl-ink">{{ a.title }}</p>
                <p class="text-xs text-bcl-ink-muted">{{ a.category }}</p>
              </div>
              <div class="flex items-center gap-2">
                <span [class]="pillClass(a.status)">{{ a.status }}</span>
                @for (act of actionsFor(a.status); track act.status) {
                  <button
                    type="button"
                    (click)="setStatus('help', a, act.status)"
                    [disabled]="busy().has(a.id)"
                    class="rounded-lg border border-bcl-border px-2.5 py-1 text-xs text-bcl-ink-muted transition-all duration-[333ms] disabled:opacity-50 hover:border-bcl-accent hover:text-bcl-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
                  >
                    {{ act.label }}
                  </button>
                }
              </div>
            </li>
          }
        </ul>
      }
    </section>

    <!-- What we don't do -->
    <section class="bcl-glass p-5" data-testid="content-wwd">
      <h2 class="mb-3 font-display text-lg font-bold text-bcl-ink">What we don’t do</h2>
      <form
        class="mb-5 grid gap-3 rounded-xl border border-bcl-border p-4 md:grid-cols-2"
        data-testid="content-wwd-create"
        (submit)="createItem($event)"
      >
        <label class="grid gap-1 text-xs text-bcl-ink-muted">
          Item title
          <input
            class="rounded-lg border border-bcl-border bg-transparent px-3 py-2 text-sm text-bcl-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
            [value]="newItemTitle()"
            (input)="newItemTitle.set($any($event.target).value)"
            required
          />
        </label>
        <label class="grid gap-1 text-xs text-bcl-ink-muted">
          Category
          <input
            class="rounded-lg border border-bcl-border bg-transparent px-3 py-2 text-sm text-bcl-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
            [value]="newItemCategory()"
            (input)="newItemCategory.set($any($event.target).value)"
            required
          />
        </label>
        <label class="grid gap-1 text-xs text-bcl-ink-muted md:col-span-2">
          Explanation
          <textarea
            class="min-h-24 rounded-lg border border-bcl-border bg-transparent px-3 py-2 text-sm text-bcl-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
            [value]="newItemExplanation()"
            (input)="newItemExplanation.set($any($event.target).value)"
            required
          ></textarea>
        </label>
        <div class="flex items-center gap-3 md:col-span-2">
          <button
            type="submit"
            [disabled]="itemCreateBusy() || !canCreateItem()"
            class="rounded-lg border border-bcl-accent bg-bcl-accent/10 px-4 py-2 text-sm font-semibold text-bcl-accent disabled:opacity-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
          >
            {{ itemCreateBusy() ? 'Creating…' : 'Create draft' }}
          </button>
          @if (itemCreateError()) {
            <p class="text-xs text-amber-300" role="alert">{{ itemCreateError() }}</p>
          }
        </div>
      </form>
      @if (wwdError()) {
        <p
          class="rounded-lg border border-amber-500/30 bg-amber-500/5 p-3 text-xs text-amber-300"
          role="alert"
        >
          {{ wwdError() }}
        </p>
      } @else if (wwdLoading()) {
        <p class="text-sm text-bcl-ink-muted">Loading…</p>
      } @else if (items().length === 0) {
        <p class="text-sm text-bcl-ink-muted" data-testid="content-wwd-empty">No items yet.</p>
      } @else {
        <ul class="divide-y divide-bcl-border" role="list">
          @for (it of items(); track it.id) {
            <li class="flex flex-wrap items-center justify-between gap-3 py-2.5">
              <div class="min-w-0">
                <p class="truncate text-sm font-medium text-bcl-ink">{{ it.itemTitle }}</p>
                <p class="text-xs text-bcl-ink-muted">{{ it.category }}</p>
              </div>
              <div class="flex items-center gap-2">
                <span [class]="pillClass(it.status)">{{ it.status }}</span>
                @for (act of actionsFor(it.status); track act.status) {
                  <button
                    type="button"
                    (click)="setStatus('wwd', it, act.status)"
                    [disabled]="busy().has(it.id)"
                    class="rounded-lg border border-bcl-border px-2.5 py-1 text-xs text-bcl-ink-muted transition-all duration-[333ms] disabled:opacity-50 hover:border-bcl-accent hover:text-bcl-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
                  >
                    {{ act.label }}
                  </button>
                }
              </div>
            </li>
          }
        </ul>
      }
    </section>
  `,
  imports: [RouterLink],
})
export class ContentComponent {
  private readonly http = inject(HttpClient);
  private readonly destroyRef = inject(DestroyRef);

  readonly articles = signal<Article[]>([]);
  readonly items = signal<DontDoItem[]>([]);
  readonly helpLoading = signal(true);
  readonly wwdLoading = signal(true);
  readonly helpError = signal<string | null>(null);
  readonly wwdError = signal<string | null>(null);
  readonly busy = signal<Set<string>>(new Set());
  readonly createBusy = signal(false);
  readonly createError = signal<string | null>(null);
  readonly newTitle = signal('');
  readonly newSlug = signal('');
  readonly newCategory = signal('');
  readonly newBody = signal('');
  readonly itemCreateBusy = signal(false);
  readonly itemCreateError = signal<string | null>(null);
  readonly newItemTitle = signal('');
  readonly newItemCategory = signal('');
  readonly newItemExplanation = signal('');

  constructor() {
    this.http
      .get<{ ok: boolean; admin?: boolean; articles?: Article[] }>('/api/help-center', {
        withCredentials: true,
      })
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError((e: { status?: number }) => {
          this.helpError.set(this.errLabel(e.status, 'help_center'));
          return of({ ok: false, articles: [] as Article[] });
        }),
        finalize(() => this.helpLoading.set(false)),
      )
      .subscribe((r) => this.articles.set(r.articles ?? []));

    this.http
      .get<{ ok: boolean; items?: DontDoItem[] }>('/api/what-we-dont-do', {
        withCredentials: true,
      })
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError((e: { status?: number }) => {
          this.wwdError.set(this.errLabel(e.status, 'what_we_dont_do'));
          return of({ ok: false, items: [] as DontDoItem[] });
        }),
        finalize(() => this.wwdLoading.set(false)),
      )
      .subscribe((r) => this.items.set(r.items ?? []));
  }

  /** Status-aware action buttons: which transitions to offer from the current status. */
  actionsFor(status: string): readonly { status: Status; label: string }[] {
    if (status === 'published')
      return [
        { status: 'draft', label: 'Unpublish' },
        { status: 'archived', label: 'Archive' },
      ];
    if (status === 'draft')
      return [
        { status: 'published', label: 'Publish' },
        { status: 'archived', label: 'Archive' },
      ];
    return [{ status: 'draft', label: 'Restore' }]; // archived → back to draft
  }

  canCreateArticle(): boolean {
    return Boolean(
      this.newTitle().trim() &&
        /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(this.newSlug().trim()) &&
        this.newCategory().trim() &&
        this.newBody().trim(),
    );
  }

  createArticle(event: Event): void {
    event.preventDefault();
    if (this.createBusy() || !this.canCreateArticle()) return;
    this.createBusy.set(true);
    this.createError.set(null);
    this.http
      .post<{ ok: boolean; article?: Article }>(
        '/api/help-center',
        {
          title: this.newTitle().trim(),
          slug: this.newSlug().trim(),
          category: this.newCategory().trim(),
          bodyMarkdown: this.newBody().trim(),
          status: 'draft',
        },
        { withCredentials: true },
      )
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError(() => {
          this.createError.set('Could not create the draft. Check the fields and try again.');
          return of<{ ok: boolean; article?: Article }>({ ok: false });
        }),
        finalize(() => this.createBusy.set(false)),
      )
      .subscribe((response) => {
        if (!response.ok || !response.article) return;
        this.articles.update((articles) => [response.article!, ...articles]);
        this.newTitle.set('');
        this.newSlug.set('');
        this.newCategory.set('');
        this.newBody.set('');
      });
  }

  canCreateItem(): boolean {
    return Boolean(
      this.newItemTitle().trim() &&
        this.newItemCategory().trim() &&
        this.newItemExplanation().trim(),
    );
  }

  createItem(event: Event): void {
    event.preventDefault();
    if (this.itemCreateBusy() || !this.canCreateItem()) return;
    this.itemCreateBusy.set(true);
    this.itemCreateError.set(null);
    this.http
      .post<{ ok: boolean; item?: DontDoItem }>(
        '/api/what-we-dont-do',
        {
          itemTitle: this.newItemTitle().trim(),
          category: this.newItemCategory().trim(),
          itemExplanation: this.newItemExplanation().trim(),
          status: 'draft',
        },
        { withCredentials: true },
      )
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError(() => {
          this.itemCreateError.set('Could not create the draft. Check the fields and try again.');
          return of<{ ok: boolean; item?: DontDoItem }>({ ok: false });
        }),
        finalize(() => this.itemCreateBusy.set(false)),
      )
      .subscribe((response) => {
        if (!response.ok || !response.item) return;
        this.items.update((items) => [response.item!, ...items]);
        this.newItemTitle.set('');
        this.newItemCategory.set('');
        this.newItemExplanation.set('');
      });
  }

  setStatus(kind: 'help' | 'wwd', row: Article | DontDoItem, status: Status): void {
    const base = kind === 'help' ? '/api/help-center' : '/api/what-we-dont-do';
    this.busy.update((s) => new Set(s).add(row.id));
    this.http
      .patch<{ ok: boolean }>(`${base}/${row.id}`, { status }, { withCredentials: true })
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError(() => of({ ok: false })),
        finalize(() =>
          this.busy.update((s) => {
            const next = new Set(s);
            next.delete(row.id);
            return next;
          }),
        ),
      )
      .subscribe((r) => {
        if (!r.ok) return;
        if (kind === 'help')
          this.articles.update((list) => list.map((a) => (a.id === row.id ? { ...a, status } : a)));
        else this.items.update((list) => list.map((i) => (i.id === row.id ? { ...i, status } : i)));
      });
  }

  pillClass(status: string): string {
    const base = 'rounded-full px-2.5 py-0.5 text-[11px] font-medium capitalize ';
    if (status === 'published') return base + 'bg-emerald-500/15 text-emerald-200';
    if (status === 'draft') return base + 'bg-amber-500/15 text-amber-200';
    return base + 'bg-bcl-ink-muted/10 text-bcl-ink-muted';
  }

  private errLabel(status: number | undefined, flag: string): string {
    if (status === 401) return 'Sign in as a super-admin to manage content.';
    if (status === 404)
      return `Enable the ${flag} flag (or sign in as super-admin) to manage this content.`;
    return `Failed to load (HTTP ${status}).`;
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'content-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
