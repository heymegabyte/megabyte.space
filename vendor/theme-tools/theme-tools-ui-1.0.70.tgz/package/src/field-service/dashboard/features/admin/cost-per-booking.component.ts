import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
/**
 * AdminCostPerBookingComponent — unit-economics (cost per completed booking) on
 * the admin console. Live surface = Angular /dashboard/admin.
 *
 * Unblocked 2026-06-03: `/api/admin/cost-per-booking` migrated from
 * OWNER_INVOICE_KEY Bearer-only to the shared `ownerOrSuperAdmin` gate.
 *   GET /api/admin/cost-per-booking → { ok, range_days, inputs:{completed_bookings,…},
 *        total_cost_cents, cost_per_booking_cents, breakdown_cents:{twilio,resend,stripe_fees,worker_payouts,ad_spend} }
 * Pure read. Pure helpers dollars/breakdownRows unit-tested.
 */
import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { HlmCardImports } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';
import { BclRollingCounterComponent } from '../_shared/rolling-counter.component';

export interface CostBreakdown {
  readonly twilio: number;
  readonly resend: number;
  readonly stripe_fees: number;
  readonly worker_payouts: number;
  readonly ad_spend: number;
}
export interface CostReport {
  readonly ok: boolean;
  readonly range_days: number;
  readonly inputs?: { readonly completed_bookings: number };
  readonly total_cost_cents: number;
  readonly cost_per_booking_cents: number;
  readonly breakdown_cents: CostBreakdown;
}

/** Pure: cents → $ with 2 decimals. */
export function dollars(cents: number): string {
  if (!Number.isFinite(cents)) return '$0.00';
  return `$${(cents / 100).toFixed(2)}`;
}

/** Pure: ordered breakdown rows (label + cents), largest first. */
export function breakdownRows(b: CostBreakdown): ReadonlyArray<{ label: string; cents: number }> {
  return [
    { label: 'Worker payouts', cents: b.worker_payouts },
    { label: 'Ad spend', cents: b.ad_spend },
    { label: 'Stripe fees', cents: b.stripe_fees },
    { label: 'Twilio (SMS)', cents: b.twilio },
    { label: 'Resend (email)', cents: b.resend },
  ]
    .filter((r) => Number.isFinite(r.cents))
    .sort((a, z) => z.cents - a.cents);
}

const ZERO_BREAKDOWN: CostBreakdown = {
  twilio: 0,
  resend: 0,
  stripe_fees: 0,
  worker_payouts: 0,
  ad_spend: 0,
};

@Component({
  selector: 'app-admin-cost-per-booking',
  standalone: true,
  imports: [...HlmCardImports, BclRollingCounterComponent, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div hlmCard bclReveal data-testid="admin-cost-per-booking">
      <div hlmCardHeader>
        <h3 hlmCardTitle>Unit economics</h3>
        <p hlmCardDescription>Blended cost per completed booking (last {{ rangeDays() }} days).</p>
      </div>
      <div hlmCardContent>
        @if (loading()) {
          <p class="text-sm text-bcl-ink-muted">Loading unit economics…</p>
        } @else if (error()) {
          <p class="text-sm text-bcl-warn" role="status">{{ error() }}</p>
        } @else {
          <div class="mb-4 flex items-baseline gap-3">
            <span class="font-mono text-3xl tabular-nums text-bcl-accent">
              <bcl-rolling-counter [value]="cpb() / 100" [decimals]="2" prefix="$" />
            </span>
            <span class="text-sm text-bcl-ink-muted">/ booking · {{ completed() }} completed</span>
          </div>
          <ul class="grid gap-1.5">
            @for (r of rows(); track r.label) {
              <li class="flex items-center justify-between gap-2 text-sm">
                <span class="text-bcl-ink-muted">{{ r.label }}</span>
                <span class="font-mono tabular-nums text-bcl-ink">{{ money(r.cents) }}</span>
              </li>
            }
            <li class="mt-1 flex items-center justify-between gap-2 border-t border-bcl-border pt-1.5 text-sm">
              <span class="font-semibold text-bcl-ink">Total cost</span>
              <span class="font-mono font-semibold tabular-nums text-bcl-ink">{{ money(total()) }}</span>
            </li>
          </ul>
        }
      </div>
    </div>
  `,
})
export class AdminCostPerBookingComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly loading = signal(true);
  readonly error = signal<string>('');
  readonly cpb = signal(0);
  readonly total = signal(0);
  readonly completed = signal(0);
  readonly rangeDays = signal(30);
  readonly rows = signal<ReadonlyArray<{ label: string; cents: number }>>([]);

  readonly money = dollars;

  ngOnInit(): void {
    void this.load();
  }

  async load(): Promise<void> {
    this.loading.set(true);
    this.error.set('');
    try {
      const r = await firstValueFrom(
        this.http.get<CostReport>('/api/admin/cost-per-booking', { withCredentials: true }),
      );
      if (!r?.ok) throw new Error('not_ok');
      this.cpb.set(r.cost_per_booking_cents ?? 0);
      this.total.set(r.total_cost_cents ?? 0);
      this.completed.set(r.inputs?.completed_bookings ?? 0);
      this.rangeDays.set(r.range_days ?? 30);
      this.rows.set(breakdownRows(r.breakdown_cents ?? ZERO_BREAKDOWN));
    } catch {
      this.error.set('Sign in as an operator to view unit economics.');
    } finally {
      this.loading.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'cost-per-booking-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
