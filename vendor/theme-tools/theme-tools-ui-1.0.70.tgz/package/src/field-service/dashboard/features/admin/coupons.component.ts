import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
/**
 * AdminCouponsComponent — first-booking coupon funnel analytics on the admin
 * console. Live surface = Angular /dashboard/admin.
 *
 * Unblocked 2026-06-03: `/api/admin/coupons` was OWNER_INVOICE_KEY Bearer-only;
 * migrated to the shared `ownerOrSuperAdmin` gate so the cookie-auth SPA can call
 * it with the super-admin session. Read-only analytics:
 *   GET /api/admin/coupons → { ok, today, week, month, allTime:{issued,redeemed,conversionRate}, perCity:[{city,issued,redeemed,conversionRate}] }
 * Pure helpers formatPct/conversionTone unit-tested.
 */
import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { HlmCardImports } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

export interface CouponWindow {
  readonly issued: number;
  readonly redeemed: number;
  readonly conversionRate: number;
}
export interface CouponCityRow extends CouponWindow {
  readonly city: string;
}
interface CouponsResponse {
  readonly ok: boolean;
  readonly today?: CouponWindow;
  readonly week?: CouponWindow;
  readonly month?: CouponWindow;
  readonly allTime?: CouponWindow;
  readonly perCity?: readonly CouponCityRow[];
}

/** Pure: a 0–1 rate as a one-decimal percentage. */
export function formatPct(rate: number): string {
  if (!Number.isFinite(rate)) return '0.0%';
  return `${(Math.max(0, Math.min(1, rate)) * 100).toFixed(1)}%`;
}

/** Pure: tone band for a conversion rate. */
export function conversionTone(rate: number): 'high' | 'mid' | 'low' {
  if (rate >= 0.4) return 'high';
  if (rate >= 0.15) return 'mid';
  return 'low';
}

const ZERO: CouponWindow = { issued: 0, redeemed: 0, conversionRate: 0 };

@Component({
  selector: 'app-admin-coupons',
  standalone: true,
  imports: [...HlmCardImports, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div hlmCard bclReveal data-testid="admin-coupons">
      <div hlmCardHeader>
        <h3 hlmCardTitle>First-booking coupons</h3>
        <p hlmCardDescription>Issued vs redeemed + conversion across time windows and cities.</p>
      </div>
      <div hlmCardContent>
        @if (loading()) {
          <p class="text-sm text-bcl-ink-muted">Loading coupon funnel…</p>
        } @else if (error()) {
          <p class="text-sm text-bcl-warn" role="status">{{ error() }}</p>
        } @else {
          <div class="grid grid-cols-2 gap-3 sm:grid-cols-4">
            @for (w of windows(); track w.label) {
              <div class="rounded-md border border-bcl-border bg-bcl-bg-elev p-3">
                <p class="font-mono text-[10px] uppercase tracking-wider text-bcl-ink-muted">{{ w.label }}</p>
                <p class="mt-1 font-mono text-lg tabular-nums text-bcl-ink">{{ w.data.redeemed }}/{{ w.data.issued }}</p>
                <p
                  class="font-mono text-xs tabular-nums"
                  [class.text-bcl-success]="tone(w.data.conversionRate) === 'high'"
                  [class.text-bcl-accent]="tone(w.data.conversionRate) === 'mid'"
                  [class.text-bcl-ink-muted]="tone(w.data.conversionRate) === 'low'"
                >{{ pct(w.data.conversionRate) }} conv.</p>
              </div>
            }
          </div>

          @if (perCity().length > 0) {
            <p class="mb-2 mt-5 font-mono text-[10px] uppercase tracking-wider text-bcl-ink-muted">By city</p>
            <ul class="grid gap-1.5">
              @for (r of perCity(); track r.city) {
                <li class="flex items-center justify-between gap-2 rounded-md border border-bcl-border bg-bcl-bg px-3 py-1.5 text-sm">
                  <span class="text-bcl-ink">{{ r.city }}</span>
                  <span class="font-mono tabular-nums text-bcl-ink-muted">
                    {{ r.redeemed }}/{{ r.issued }} · <span [class.text-bcl-success]="tone(r.conversionRate) === 'high'">{{ pct(r.conversionRate) }}</span>
                  </span>
                </li>
              }
            </ul>
          }
        }
      </div>
    </div>
  `,
})
export class AdminCouponsComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly loading = signal(true);
  readonly error = signal<string>('');
  readonly today = signal<CouponWindow>(ZERO);
  readonly week = signal<CouponWindow>(ZERO);
  readonly month = signal<CouponWindow>(ZERO);
  readonly allTime = signal<CouponWindow>(ZERO);
  readonly perCity = signal<readonly CouponCityRow[]>([]);

  readonly pct = formatPct;
  readonly tone = conversionTone;

  windows(): ReadonlyArray<{ label: string; data: CouponWindow }> {
    return [
      { label: 'Today', data: this.today() },
      { label: '7 days', data: this.week() },
      { label: '30 days', data: this.month() },
      { label: 'All time', data: this.allTime() },
    ];
  }

  ngOnInit(): void {
    void this.load();
  }

  async load(): Promise<void> {
    this.loading.set(true);
    this.error.set('');
    try {
      const r = await firstValueFrom(
        this.http.get<CouponsResponse>('/api/admin/coupons', { withCredentials: true }),
      );
      if (!r?.ok) throw new Error('not_ok');
      this.today.set(r.today ?? ZERO);
      this.week.set(r.week ?? ZERO);
      this.month.set(r.month ?? ZERO);
      this.allTime.set(r.allTime ?? ZERO);
      this.perCity.set(r.perCity ?? []);
    } catch {
      this.error.set('Sign in as an operator to view coupon analytics.');
    } finally {
      this.loading.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'coupons-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
