import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * AdminDisputesComponent — operator complaint/dispute console on the admin dashboard.
 *
 * The live operator surface for the worker/customer incident + dispute queue
 * (injuries, property damage, customer_dispute, no_show, panic_button, …). Reads
 * the full queue and lets the operator triage each one: investigate, escalate,
 * resolve (with a resolution note), or dismiss. This is the BACKLOG item-14
 * "Complaint/dispute admin dashboard" surface — the backend was mounted but had
 * no live Angular console.
 *
 * Verified by mount (`app.route('/api/incidents', incidents)`, admin guard
 * migrated 2026-06-18 from a Bearer-only check to `ownerOrSuperAdmin` so the
 * cookie super_admin session reaches it):
 *   GET   /api/incidents/admin/list?status=…  → { ok, incidents[] }
 *   PATCH /api/incidents/admin/:id            ← { status?, severity?, resolution? }
 *
 * Status pills + severity pills (gorgeous-by-default — never comma-joined),
 * rolling-counter summary strip, dark cockpit, 4-state. Pure helpers unit-tested.
 */
import { ChangeDetectionStrategy, Component, OnInit, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { firstValueFrom } from 'rxjs';
import { HlmButton, HlmSkeleton, ToastService, ConfirmDialog } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';
import { BclRollingCounterComponent } from '../_shared/rolling-counter.component';
import { DisputeEvidenceComponent } from './dispute-evidence.component';
import { DisputeMediationComponent } from './dispute-mediation.component';

export type IncidentStatus = 'open' | 'investigating' | 'resolved' | 'escalated' | 'dismissed';
export type IncidentSeverity = 'low' | 'medium' | 'high' | 'critical';

export interface Incident {
  readonly id: string;
  readonly gig_id: string | null;
  readonly worker_id: string | null;
  readonly booking_id: string | null;
  readonly kind: string;
  readonly severity: string;
  readonly reported_by: string;
  readonly body: string;
  readonly status: string;
  readonly resolution: string | null;
  readonly created_at: string;
  readonly resolved_at: string | null;
  /** Crew payout-ledger state for this job+worker (joined server-side); null when no ledger row. */
  readonly payout_state?: string | null;
  readonly payout_blocked_by?: string | null;
}

/** Payout-ledger states from which an operator `admin_hold` is a legal transition. */
const HOLDABLE_PAYOUT_STATES: ReadonlySet<string> = new Set([
  '', // no ledger row yet — the store upserts a fresh `on_hold` row
  'locked',
  'in_review',
  'available',
  'failed',
]);

/**
 * Pure: what payout-hold control (if any) an incident's crew payout can take —
 * mirrors the worker payout state machine EXACTLY so the toggle never 409s.
 *   'release' — payout is currently frozen (`on_hold`); operator can lift it
 *   'hold'    — payout is freezable (no row yet, or locked/in_review/available/failed)
 *   'none'    — not actionable (no gig/worker, or already processing/paid)
 * Unit-tested.
 */
export function payoutHoldAction(
  gigId: string | null | undefined,
  workerId: string | null | undefined,
  payoutState: string | null | undefined,
): 'hold' | 'release' | 'none' {
  if (!gigId || !workerId) return 'none';
  const s = payoutState ?? '';
  if (s === 'on_hold') return 'release';
  return HOLDABLE_PAYOUT_STATES.has(s) ? 'hold' : 'none';
}

const SEVERITY_ORDER: readonly IncidentSeverity[] = ['low', 'medium', 'high', 'critical'];

/** Pure: severity ordinal (higher = more severe). Unit-tested. */
export function severityRank(s: string): number {
  const i = SEVERITY_ORDER.indexOf(s as IncidentSeverity);
  return i < 0 ? 0 : i;
}

/** Pure: a status is terminal when no further triage applies. Unit-tested. */
export function isTerminal(status: string): boolean {
  return status === 'resolved' || status === 'dismissed';
}

/** Pure: chip classes for an incident status. Unit-tested. */
export function statusChip(status: string): string {
  switch (status) {
    case 'resolved':
      return 'bg-bcl-success/10 text-bcl-success ring-bcl-success/30';
    case 'investigating':
      return 'bg-bcl-accent/10 text-bcl-accent ring-bcl-accent/30';
    case 'escalated':
      return 'bg-destructive/10 text-destructive ring-destructive/30';
    case 'dismissed':
      return 'bg-bcl-bg-elev text-bcl-ink-muted ring-bcl-border';
    default: // open
      return 'bg-bcl-warn/10 text-bcl-warn ring-bcl-warn/30';
  }
}

/** Pure: chip classes for a severity. Unit-tested. */
export function severityChip(severity: string): string {
  switch (severity) {
    case 'critical':
    case 'high':
      return 'bg-destructive/10 text-destructive ring-destructive/30';
    case 'medium':
      return 'bg-bcl-warn/10 text-bcl-warn ring-bcl-warn/30';
    default: // low
      return 'bg-bcl-bg-elev text-bcl-ink-muted ring-bcl-border';
  }
}

/** Pure: humanise an incident kind (snake_case → Title Case). Unit-tested. */
export function kindLabel(kind: string): string {
  return kind
    .split('_')
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');
}

/** Pure: actionable-queue tallies (open / investigating / escalated). Unit-tested. */
export function disputeSummary(rows: readonly Incident[]): {
  open: number;
  investigating: number;
  escalated: number;
  total: number;
} {
  let open = 0;
  let investigating = 0;
  let escalated = 0;
  for (const r of rows) {
    if (r.status === 'open') open += 1;
    else if (r.status === 'investigating') investigating += 1;
    else if (r.status === 'escalated') escalated += 1;
  }
  return { open, investigating, escalated, total: rows.length };
}

// ──────────────────────────────────────────────────────────────────────────
// Operator <-> party message thread (BACKLOG item 14 "message-parties").
// The worker persists an append-only thread per incident and best-effort SMS-
// delivers operator replies to the chosen party. This is the dashboard surface
// that consumes it. Mirrors src/shared/incident-thread.ts (the dashboard can't
// import src/shared) — kept in lockstep by these unit-tested pure helpers.
// ──────────────────────────────────────────────────────────────────────────

/** Max message length — mirrors the worker `MAX_MESSAGE_LEN`. */
export const THREAD_MAX_LEN = 1500;

/** Who an operator message is directed to. */
export type ThreadAudience = 'customer' | 'crew' | 'both';

/** A persisted thread message (operator outbound or party inbound). */
export interface IncidentMessage {
  readonly id: string;
  readonly incident_id: string;
  readonly author_role: string; // operator | customer | crew | system
  readonly author_label: string | null;
  readonly audience: string | null; // customer|crew|both for operator msgs; null inbound
  readonly body: string;
  readonly delivered_sms: number;
  readonly created_at: string;
}

/** Operator audience picker — default "both" first. */
export const THREAD_AUDIENCES: readonly { value: ThreadAudience; label: string }[] = [
  { value: 'both', label: 'Customer & crew' },
  { value: 'customer', label: 'Customer only' },
  { value: 'crew', label: 'Crew only' },
];

/** Pure: display name for a message author. Prefers an explicit label. Unit-tested. */
export function threadAuthorLabel(role: string, label?: string | null): string {
  const trimmed = label?.trim();
  if (trimmed) return trimmed;
  switch (role) {
    case 'operator':
      return 'Operator';
    case 'customer':
      return 'Customer';
    case 'crew':
      return 'Crew';
    case 'system':
      return 'System';
    default:
      return 'Unknown';
  }
}

/** Pure: directed label for an operator message's audience; '' for inbound. Unit-tested. */
export function threadAudienceLabel(audience?: string | null): string {
  switch (audience) {
    case 'customer':
      return 'To customer';
    case 'crew':
      return 'To crew';
    case 'both':
      return 'To customer & crew';
    default:
      return '';
  }
}

/** Pure: is this an operator-authored (outbound) message? Unit-tested. */
export function isOperatorMessage(role: string): boolean {
  return role === 'operator';
}

/** Pure: can this draft be sent — non-empty trimmed within the cap? Unit-tested. */
export function canSendMessage(body: string): boolean {
  const t = body.trim();
  return t.length > 0 && t.length <= THREAD_MAX_LEN;
}

interface StatusFilter {
  readonly label: string;
  readonly value: IncidentStatus | '';
}

const STATUS_FILTERS: readonly StatusFilter[] = [
  { label: 'All', value: '' },
  { label: 'Open', value: 'open' },
  { label: 'Investigating', value: 'investigating' },
  { label: 'Escalated', value: 'escalated' },
  { label: 'Resolved', value: 'resolved' },
  { label: 'Dismissed', value: 'dismissed' },
];

@Component({
  selector: 'app-admin-disputes',
  standalone: true,
  imports: [
    DatePipe,
    HlmButton,
    HlmSkeleton,
    BclRevealDirective,
    BclRollingCounterComponent,
    DisputeEvidenceComponent,
    DisputeMediationComponent,
    ConfirmDialog,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="mb-4 flex flex-wrap items-start justify-between gap-3">
      <div>
        <h1 class="text-2xl font-bold text-foreground">Complaints &amp; disputes</h1>
        <p class="text-sm text-muted-foreground">
          Triage the worker + customer incident queue. Investigate, escalate, resolve, or dismiss.
        </p>
      </div>
      <button hlmBtn variant="secondary" size="sm" (click)="refresh()" [disabled]="loading()">
        Refresh
      </button>
    </header>

    @if (loaded()) {
      <section
        bclReveal
        class="mb-5 grid grid-cols-1 gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-3"
        aria-label="Dispute queue summary"
      >
        <div class="bg-card px-4 py-3">
          <p class="font-mono text-[11px] uppercase tracking-wider text-bcl-warn">Open</p>
          <p class="bcl-tabular mt-1 text-2xl font-bold text-foreground">
            <bcl-rolling-counter [value]="summary().open" />
          </p>
        </div>
        <div class="bg-card px-4 py-3">
          <p class="font-mono text-[11px] uppercase tracking-wider text-bcl-accent">Investigating</p>
          <p class="bcl-tabular mt-1 text-2xl font-bold text-foreground">
            <bcl-rolling-counter [value]="summary().investigating" />
          </p>
        </div>
        <div class="bg-card px-4 py-3">
          <p class="font-mono text-[11px] uppercase tracking-wider text-destructive">Escalated</p>
          <p class="bcl-tabular mt-1 text-2xl font-bold text-foreground">
            <bcl-rolling-counter [value]="summary().escalated" />
          </p>
        </div>
      </section>
    }

    <nav
      class="mb-4 flex flex-wrap items-center gap-2"
      aria-label="Filter disputes by status"
    >
      @for (f of statusFilters; track f.value) {
        <button
          type="button"
          (click)="setFilter(f.value)"
          [attr.aria-pressed]="activeFilter() === f.value"
          class="rounded-full px-3 py-1 text-sm font-medium ring-1 transition-all [transition-duration:0.333s] hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent focus-visible:ring-offset-1 focus-visible:ring-offset-bcl-bg"
          [class]="
            activeFilter() === f.value
              ? 'bg-bcl-accent/15 text-bcl-accent ring-bcl-accent/40'
              : 'bg-bcl-bg-elev text-muted-foreground ring-bcl-border hover:text-foreground'
          "
        >
          {{ f.label }}
        </button>
      }
    </nav>

    @if (error(); as e) {
      <div
        class="mb-4 flex items-center justify-between gap-3 rounded-xl border border-destructive/40 bg-destructive/5 px-4 py-3"
        role="alert"
      >
        <p class="text-sm text-foreground">Dispute queue — {{ e }}</p>
        <button hlmBtn variant="outline" size="sm" (click)="refresh()">Try again</button>
      </div>
    }

    @if (loading() && !loaded()) {
      <div class="space-y-3" aria-label="Loading dispute queue">
        <div hlmSkeleton class="h-28 w-full"></div>
        <div hlmSkeleton class="h-28 w-full"></div>
        <div hlmSkeleton class="h-28 w-full"></div>
      </div>
    } @else if (!error()) {
      @if (incidents().length === 0) {
        <div
          class="rounded-xl border border-dashed border-border p-10 text-center"
          bclReveal
        >
          <p class="text-sm font-medium text-foreground">No disputes in this view.</p>
          <p class="mt-1 text-sm text-muted-foreground">
            A clean queue — nothing to triage right now.
          </p>
        </div>
      } @else {
        <ul class="space-y-3" aria-label="Dispute queue">
          @for (it of incidents(); track it.id) {
            <li bclReveal class="rounded-xl border border-border bg-card/60 p-4">
              <div class="flex flex-wrap items-center gap-2">
                <span class="font-semibold text-foreground">{{ label(it.kind) }}</span>
                <span
                  class="rounded-full px-2 py-0.5 text-xs font-semibold ring-1"
                  [class]="sevChip(it.severity)"
                  >{{ it.severity }}</span
                >
                <span
                  class="rounded-full px-2 py-0.5 text-xs font-semibold ring-1"
                  [class]="statChip(it.status)"
                  >{{ it.status }}</span
                >
                <span class="text-xs text-muted-foreground">via {{ it.reported_by }}</span>
                <span class="ml-auto bcl-tabular text-xs text-muted-foreground"
                  >#{{ it.id.slice(0, 8) }} · {{ it.created_at | date: 'short' }}</span
                >
              </div>

              <p class="mt-2 whitespace-pre-line text-sm text-foreground">{{ it.body }}</p>

              @if (it.booking_id) {
                <app-dispute-evidence [bookingId]="it.booking_id" />
                <!-- SCAN-51: the AI-drafted mediation reply (flag-dark; self-hides when
                     the flag is off or no mediation was recorded). Read-only. -->
                <app-dispute-mediation [bookingId]="it.booking_id" />
              }

              @if (payoutAction(it); as pa) {
                @if (pa !== 'none') {
                  <div
                    class="mt-3 flex flex-wrap items-center gap-2 rounded-lg border px-3 py-2"
                    [class]="
                      pa === 'release'
                        ? 'border-destructive/40 bg-destructive/5'
                        : 'border-border bg-bcl-bg-elev/60'
                    "
                  >
                    @if (pa === 'release') {
                      <span
                        class="rounded-full bg-destructive/10 px-2 py-0.5 text-xs font-semibold text-destructive ring-1 ring-destructive/30"
                        >Crew payout frozen</span
                      >
                      <span class="text-xs text-muted-foreground">
                        This job's crew payout is held while the dispute is open.
                      </span>
                      <button
                        hlmBtn
                        variant="outline"
                        size="sm"
                        class="ml-auto"
                        [disabled]="payoutBusy() === it.id"
                        (click)="requestPayout(it, 'release')"
                      >
                        Release payout
                      </button>
                    } @else {
                      <span class="font-mono text-[10px] uppercase tracking-wider text-bcl-warn"
                        >Crew payout</span
                      >
                      <span class="text-xs text-muted-foreground">
                        Freeze this job's crew payout while you investigate.
                      </span>
                      <button
                        hlmBtn
                        variant="secondary"
                        size="sm"
                        class="ml-auto"
                        [disabled]="payoutBusy() === it.id"
                        (click)="requestPayout(it, 'hold')"
                      >
                        Freeze crew payout
                      </button>
                    }
                  </div>
                }
              }

              @if (it.resolution) {
                <p class="mt-2 rounded-lg border border-bcl-success/20 bg-bcl-success/5 px-3 py-2 text-sm text-foreground">
                  <span class="font-mono text-[10px] uppercase tracking-wider text-bcl-success">Resolution</span><br />
                  {{ it.resolution }}
                </p>
              }

              @if (!terminal(it.status)) {
                <div class="mt-3 border-t border-border pt-3">
                  <label class="sr-only" [attr.for]="'note-' + it.id">Resolution note for {{ label(it.kind) }}</label>
                  <input
                    [id]="'note-' + it.id"
                    type="text"
                    [value]="noteFor(it.id)"
                    (input)="setNote(it.id, $event)"
                    placeholder="Resolution note (saved with Resolve / Dismiss)…"
                    class="mb-2 w-full rounded-lg border border-border bg-bcl-bg-elev px-3 py-2 text-sm text-foreground placeholder:text-bcl-ink-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
                  />
                  <div class="flex flex-wrap justify-end gap-2">
                    @if (it.status !== 'investigating') {
                      <button hlmBtn variant="secondary" size="sm" [disabled]="busy() === it.id" (click)="setStatus(it, 'investigating')">
                        Investigate
                      </button>
                    }
                    @if (it.status !== 'escalated') {
                      <button hlmBtn variant="outline" size="sm" [disabled]="busy() === it.id" (click)="setStatus(it, 'escalated')">
                        Escalate
                      </button>
                    }
                    <button hlmBtn variant="ghost" size="sm" [disabled]="busy() === it.id" (click)="setStatus(it, 'dismissed')">
                      Dismiss
                    </button>
                    <button hlmBtn size="sm" [disabled]="busy() === it.id" (click)="setStatus(it, 'resolved')">
                      Resolve
                    </button>
                  </div>
                </div>
              }

              <div class="mt-3 border-t border-border pt-3">
                <button
                  type="button"
                  (click)="toggleThread(it)"
                  [attr.aria-expanded]="openThread() === it.id"
                  class="flex items-center gap-2 text-sm font-medium text-bcl-accent transition-all [transition-duration:0.333s] hover:translate-x-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent focus-visible:ring-offset-1 focus-visible:ring-offset-bcl-bg"
                >
                  <span>{{ openThread() === it.id ? 'Hide messages' : 'Messages' }}</span>
                  @if (threadCount(it.id) > 0) {
                    <span class="rounded-full bg-bcl-accent/15 px-2 py-0.5 text-xs font-semibold text-bcl-accent ring-1 ring-bcl-accent/30">
                      {{ threadCount(it.id) }}
                    </span>
                  }
                </button>

                @if (openThread() === it.id) {
                  <div class="mt-3" data-testid="incident-thread" bclReveal>
                    @if (threadLoading() === it.id) {
                      <div hlmSkeleton class="h-16 w-full"></div>
                    } @else {
                      @if (msgsFor(it.id).length === 0) {
                        <p class="text-xs text-muted-foreground">
                          No messages yet — start the conversation below.
                        </p>
                      } @else {
                        <ul class="space-y-2" aria-label="Message thread">
                          @for (m of msgsFor(it.id); track m.id) {
                            <li class="flex" [class.justify-end]="isOperator(m.author_role)">
                              <div class="max-w-[85%] rounded-lg px-3 py-2 text-sm" [class]="bubbleClass(m.author_role)">
                                <div class="mb-0.5 flex items-center gap-2 text-[10px] uppercase tracking-wider opacity-70">
                                  <span>{{ authorName(m) }}</span>
                                  @if (audienceTag(m.audience); as tag) {
                                    <span>· {{ tag }}</span>
                                  }
                                  @if (m.delivered_sms > 0) {
                                    <span title="Delivered by SMS">· SMS</span>
                                  }
                                  <span class="ml-auto bcl-tabular">{{ m.created_at | date: 'short' }}</span>
                                </div>
                                <p class="whitespace-pre-line">{{ m.body }}</p>
                              </div>
                            </li>
                          }
                        </ul>
                      }

                      <div class="mt-3 rounded-lg border border-border bg-bcl-bg-elev/60 p-2">
                        <div class="mb-2 flex flex-wrap items-center gap-2">
                          <span class="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Reply to</span>
                          @for (a of threadAudiences; track a.value) {
                            <button
                              type="button"
                              (click)="setAudience(it.id, a.value)"
                              [attr.aria-pressed]="audienceFor(it.id) === a.value"
                              class="rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 transition-all [transition-duration:0.333s] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
                              [class]="
                                audienceFor(it.id) === a.value
                                  ? 'bg-bcl-accent/15 text-bcl-accent ring-bcl-accent/40'
                                  : 'bg-bcl-bg-elev text-muted-foreground ring-bcl-border hover:text-foreground'
                              "
                            >
                              {{ a.label }}
                            </button>
                          }
                        </div>
                        <label class="sr-only" [attr.for]="'msg-' + it.id">Reply on {{ label(it.kind) }}</label>
                        <textarea
                          [id]="'msg-' + it.id"
                          rows="2"
                          [value]="draftFor(it.id)"
                          (input)="setDraft(it.id, $event)"
                          [attr.maxlength]="threadMaxLen"
                          placeholder="Type a reply to the customer / crew…"
                          class="w-full resize-y rounded-lg border border-border bg-bcl-bg px-3 py-2 text-sm text-foreground placeholder:text-bcl-ink-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
                        ></textarea>
                        <div class="mt-2 flex flex-wrap items-center justify-end gap-2">
                          <span class="mr-auto text-[10px] text-muted-foreground">
                            SMS-delivered to each party that opted in.
                          </span>
                          <button
                            hlmBtn
                            size="sm"
                            [disabled]="!sendable(it.id) || threadSending() === it.id"
                            (click)="sendMessage(it)"
                          >
                            {{ threadSending() === it.id ? 'Sending…' : 'Send' }}
                          </button>
                        </div>
                      </div>
                    }
                  </div>
                }
              </div>
            </li>
          }
        </ul>
      }
    }

    <app-confirm-dialog
      [open]="pendingPayout() !== null"
      [title]="payoutDialogTitle()"
      [description]="payoutDialogDesc()"
      [confirmLabel]="payoutConfirmLabel()"
      (confirmed)="confirmPayout()"
      (cancelled)="pendingPayout.set(null)"
    />
  `,
})
export class AdminDisputesComponent implements OnInit {
  private readonly http = inject(HttpClient);
  private readonly toast = inject(ToastService);

  readonly statusFilters = STATUS_FILTERS;
  readonly threadAudiences = THREAD_AUDIENCES;
  readonly threadMaxLen = THREAD_MAX_LEN;

  readonly loading = signal(false);
  readonly loaded = signal(false);
  readonly error = signal<string | null>(null);
  readonly incidents = signal<readonly Incident[]>([]);
  readonly activeFilter = signal<IncidentStatus | ''>('');
  /** Incident id currently mutating — disables that card's buttons. */
  readonly busy = signal<string | null>(null);
  /** Incident id whose payout hold/release is mutating — disables that toggle. */
  readonly payoutBusy = signal<string | null>(null);
  /** A pending payout freeze/release awaiting the operator's confirm (never fires on a single click). */
  readonly pendingPayout = signal<{ it: Incident; kind: 'hold' | 'release' } | null>(null);
  readonly payoutDialogTitle = computed(() =>
    this.pendingPayout()?.kind === 'release' ? 'Release payout hold?' : 'Freeze crew payout?',
  );
  readonly payoutDialogDesc = computed(() => {
    const p = this.pendingPayout();
    if (!p) return '';
    const job = p.it.gig_id ? p.it.gig_id.slice(0, 8) : 'this job';
    return p.kind === 'release'
      ? `Lift the operator hold and let the crew payout for job ${job} proceed.`
      : `Freeze the crew payout for job ${job} while the dispute is open. You can release it later.`;
  });
  readonly payoutConfirmLabel = computed(() =>
    this.pendingPayout()?.kind === 'release' ? 'Release' : 'Freeze',
  );
  private readonly notes = signal<Record<string, string>>({});

  /** Incident id whose message thread is expanded (one open at a time). */
  readonly openThread = signal<string | null>(null);
  /** Incident id whose thread is currently loading. */
  readonly threadLoading = signal<string | null>(null);
  /** Incident id whose reply is currently sending. */
  readonly threadSending = signal<string | null>(null);
  private readonly threadMessages = signal<Record<string, readonly IncidentMessage[]>>({});
  private readonly threadDrafts = signal<Record<string, string>>({});
  private readonly threadAudienceSel = signal<Record<string, ThreadAudience>>({});

  readonly summary = computed(() => disputeSummary(this.incidents()));

  ngOnInit(): void {
    void this.refresh();
  }

  statChip(status: string): string {
    return statusChip(status);
  }
  sevChip(severity: string): string {
    return severityChip(severity);
  }
  label(kind: string): string {
    return kindLabel(kind);
  }
  terminal(status: string): boolean {
    return isTerminal(status);
  }
  payoutAction(it: Incident): 'hold' | 'release' | 'none' {
    return payoutHoldAction(it.gig_id, it.worker_id, it.payout_state);
  }
  noteFor(id: string): string {
    return this.notes()[id] ?? '';
  }

  // ── Message thread (operator <-> party) ──────────────────────────────────
  msgsFor(id: string): readonly IncidentMessage[] {
    return this.threadMessages()[id] ?? [];
  }
  threadCount(id: string): number {
    return this.msgsFor(id).length;
  }
  draftFor(id: string): string {
    return this.threadDrafts()[id] ?? '';
  }
  audienceFor(id: string): ThreadAudience {
    return this.threadAudienceSel()[id] ?? 'both';
  }
  authorName(m: IncidentMessage): string {
    return threadAuthorLabel(m.author_role, m.author_label);
  }
  audienceTag(audience: string | null): string {
    return threadAudienceLabel(audience);
  }
  isOperator(role: string): boolean {
    return isOperatorMessage(role);
  }
  sendable(id: string): boolean {
    return canSendMessage(this.draftFor(id));
  }
  bubbleClass(role: string): string {
    return isOperatorMessage(role)
      ? 'bg-bcl-accent/15 text-foreground'
      : 'bg-bcl-bg-elev text-foreground ring-1 ring-bcl-border';
  }

  setDraft(id: string, ev: Event): void {
    const value = (ev.target as HTMLTextAreaElement).value;
    this.threadDrafts.update((m) => ({ ...m, [id]: value }));
  }
  setAudience(id: string, value: ThreadAudience): void {
    this.threadAudienceSel.update((m) => ({ ...m, [id]: value }));
  }

  async toggleThread(it: Incident): Promise<void> {
    if (this.openThread() === it.id) {
      this.openThread.set(null);
      return;
    }
    this.openThread.set(it.id);
    await this.loadThread(it.id);
  }

  private async loadThread(id: string): Promise<void> {
    this.threadLoading.set(id);
    try {
      const resp = await firstValueFrom(
        this.http.get<{ ok: boolean; messages?: IncidentMessage[] }>(
          `/api/incidents/admin/${encodeURIComponent(id)}/messages`,
          { withCredentials: true },
        ),
      );
      this.threadMessages.update((m) => ({ ...m, [id]: resp?.messages ?? [] }));
    } catch (err) {
      this.toast.error('Could not load messages', undefined, (err as Error).message);
    } finally {
      this.threadLoading.set(null);
    }
  }

  /** Operator replies to the customer/crew on a dispute (SPEC: "message parties"). */
  async sendMessage(it: Incident): Promise<void> {
    const body = this.draftFor(it.id).trim();
    if (!canSendMessage(body)) return;
    const audience = this.audienceFor(it.id);
    this.threadSending.set(it.id);
    try {
      await firstValueFrom(
        this.http.post(
          `/api/incidents/admin/${encodeURIComponent(it.id)}/messages`,
          { body, audience },
          { withCredentials: true },
        ),
      );
      this.threadDrafts.update((m) => ({ ...m, [it.id]: '' }));
      this.toast.success('Message sent');
      await this.loadThread(it.id);
    } catch (err) {
      this.toast.error('Could not send message — try again', undefined, (err as Error).message);
    } finally {
      this.threadSending.set(null);
    }
  }

  setNote(id: string, ev: Event): void {
    const value = (ev.target as HTMLInputElement).value;
    this.notes.update((m) => ({ ...m, [id]: value }));
  }

  setFilter(value: IncidentStatus | ''): void {
    if (this.activeFilter() === value) return;
    this.activeFilter.set(value);
    void this.refresh();
  }

  async refresh(): Promise<void> {
    this.loading.set(true);
    this.error.set(null);
    const status = this.activeFilter();
    const url = status
      ? `/api/incidents/admin/list?status=${encodeURIComponent(status)}`
      : '/api/incidents/admin/list';
    try {
      const resp = await firstValueFrom(
        this.http.get<{ ok: boolean; incidents?: Incident[] }>(url, { withCredentials: true }),
      );
      this.incidents.set(resp?.incidents ?? []);
      this.loaded.set(true);
    } catch (err) {
      this.error.set(`Failed to load: ${(err as Error).message}`);
    } finally {
      this.loading.set(false);
    }
  }

  async setStatus(it: Incident, status: IncidentStatus): Promise<void> {
    this.busy.set(it.id);
    const note = this.noteFor(it.id).trim();
    const body: { status: IncidentStatus; resolution?: string } = { status };
    if (note && (status === 'resolved' || status === 'dismissed')) body.resolution = note;
    try {
      await firstValueFrom(
        this.http.patch(`/api/incidents/admin/${encodeURIComponent(it.id)}`, body, {
          withCredentials: true,
        }),
      );
      this.toast.success(`Incident #${it.id.slice(0, 8)}… marked ${status}`);
      await this.refresh();
    } catch (err) {
      this.toast.error('Update failed — try again', undefined, (err as Error).message);
    } finally {
      this.busy.set(null);
    }
  }

  /**
   * Open the confirm dialog for a payout freeze/release. The Freeze/Release buttons
   * route HERE, never to {@link holdPayout}/{@link releasePayout} directly — freezing
   * or releasing a crew member's pay is money-trust and must never fire on a misclick.
   */
  requestPayout(it: Incident, kind: 'hold' | 'release'): void {
    if (!it.gig_id || !it.worker_id || this.payoutBusy() === it.id) return;
    this.pendingPayout.set({ it, kind });
  }

  /** The dialog's explicit confirmation → fire the real freeze/release. */
  async confirmPayout(): Promise<void> {
    const p = this.pendingPayout();
    this.pendingPayout.set(null);
    if (!p) return;
    await (p.kind === 'release' ? this.releasePayout(p.it) : this.holdPayout(p.it));
  }

  /** Freeze this job's crew payout (SPEC: "freeze worker payout for that job"). */
  async holdPayout(it: Incident): Promise<void> {
    if (!it.gig_id || !it.worker_id) return;
    this.payoutBusy.set(it.id);
    try {
      await firstValueFrom(
        this.http.post(
          '/api/admin/fraud/payout-hold',
          { jobId: it.gig_id, workerId: it.worker_id, reason: `dispute:${it.id.slice(0, 8)}` },
          { withCredentials: true },
        ),
      );
      this.toast.success('Crew payout frozen for this job');
      await this.refresh();
    } catch (err) {
      this.toast.error('Could not freeze payout — try again', undefined, (err as Error).message);
    } finally {
      this.payoutBusy.set(null);
    }
  }

  /** Lift the operator hold on this job's crew payout. */
  async releasePayout(it: Incident): Promise<void> {
    if (!it.gig_id || !it.worker_id) return;
    this.payoutBusy.set(it.id);
    try {
      await firstValueFrom(
        this.http.post(
          '/api/admin/fraud/payout-release',
          { jobId: it.gig_id, workerId: it.worker_id },
          { withCredentials: true },
        ),
      );
      this.toast.success('Crew payout hold released');
      await this.refresh();
    } catch (err) {
      this.toast.error('Could not release payout — try again', undefined, (err as Error).message);
    } finally {
      this.payoutBusy.set(null);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'disputes-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
