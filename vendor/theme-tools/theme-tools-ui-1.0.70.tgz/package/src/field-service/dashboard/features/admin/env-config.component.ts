import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * EnvConfigComponent — super-admin config visibility at /admin/env-config.
 *
 * Surfaces GET /api/super-admin/env-readonly: NAMES of configured env vars (never
 * values), the list of expected-but-missing secrets, and present bindings. Lets an
 * operator see what's wired without exposing any secret value. Was bearer-only with
 * no dashboard surface; auth migrated to ownerOrSuperAdmin 2026-06-07.
 */
import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HlmCardImports } from '../../shared/ui-spartan';

export interface ConfiguredVar {
  readonly key: string;
  readonly presence: 'set' | 'empty' | 'binding';
  readonly length: number | null;
}

interface EnvResponse {
  readonly ok: boolean;
  readonly configured?: readonly ConfiguredVar[];
  readonly missing?: readonly string[];
  readonly bindings?: readonly string[];
  readonly error?: string;
}

/** Tailwind classes for a configured-var presence badge. Tested. */
export function presenceBadgeClass(presence: string): string {
  switch (presence) {
    case 'set':
      return 'bg-green-500/15 text-green-300 ring-green-500/30';
    case 'binding':
      return 'bg-primary/15 text-primary ring-primary/30';
    default: // empty
      return 'bg-amber-500/15 text-amber-300 ring-amber-500/30';
  }
}

@Component({
  selector: 'app-admin-env-config',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [...HlmCardImports],
  template: `
    <header class="mb-4">
      <h1 class="text-2xl font-bold text-foreground">Config &amp; secrets</h1>
      <p class="text-sm text-muted-foreground">
        Which env vars + bindings are wired — names only, never values.
      </p>
    </header>

    @if (error(); as e) {
      <div hlmCard class="p-4"><p class="text-sm text-destructive">{{ e }}</p></div>
    } @else if (loaded()) {
      @if (missing().length > 0) {
        <div hlmCard class="mb-4 border-amber-500/30 p-4">
          <h3 class="text-sm font-semibold text-amber-300">Missing secrets ({{ missing().length }})</h3>
          <div class="mt-2 flex flex-wrap gap-1.5">
            @for (k of missing(); track k) {
              <span class="rounded-full bg-amber-500/15 px-2 py-0.5 font-mono text-xs text-amber-300 ring-1 ring-amber-500/30">{{ k }}</span>
            }
          </div>
        </div>
      }

      <div hlmCard class="mb-4 p-4">
        <h3 class="mb-2 text-sm font-semibold text-foreground">Configured ({{ configured().length }})</h3>
        <ul role="list" class="divide-y divide-border">
          @for (v of configured(); track v.key) {
            <li class="flex items-center justify-between gap-2 py-2">
              <span class="font-mono text-sm text-foreground">{{ v.key }}</span>
              <span class="flex items-center gap-2">
                @if (v.length != null) {
                  <span class="font-mono text-xs text-muted-foreground">len {{ v.length }}</span>
                }
                <span class="rounded-full px-2 py-0.5 text-xs ring-1" [class]="presenceClass(v.presence)">{{ v.presence }}</span>
              </span>
            </li>
          }
        </ul>
      </div>

      @if (bindings().length > 0) {
        <div hlmCard class="p-4">
          <h3 class="mb-2 text-sm font-semibold text-foreground">Bindings ({{ bindings().length }})</h3>
          <div class="flex flex-wrap gap-1.5">
            @for (b of bindings(); track b) {
              <span class="rounded-full bg-background px-2 py-0.5 font-mono text-xs text-muted-foreground ring-1 ring-border">{{ b }}</span>
            }
          </div>
        </div>
      }
    } @else {
      <p class="text-sm text-muted-foreground">Loading…</p>
    }
  `,
})
export class EnvConfigComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly configured = signal<readonly ConfiguredVar[]>([]);
  readonly missing = signal<readonly string[]>([]);
  readonly bindings = signal<readonly string[]>([]);
  readonly loaded = signal<boolean>(false);
  readonly error = signal<string | null>(null);

  presenceClass(p: string): string {
    return presenceBadgeClass(p);
  }

  async ngOnInit(): Promise<void> {
    const r = await firstValueFrom(
      this.http
        .get<EnvResponse>('/api/super-admin/env-readonly')
        .pipe(catchError(() => of({ ok: false, error: 'Failed to load config' } as EnvResponse))),
    );
    if (r.ok) {
      this.configured.set(r.configured ?? []);
      this.missing.set(r.missing ?? []);
      this.bindings.set(r.bindings ?? []);
      this.loaded.set(true);
    } else {
      this.error.set(r.error ?? 'Unknown error');
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'env-config-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
