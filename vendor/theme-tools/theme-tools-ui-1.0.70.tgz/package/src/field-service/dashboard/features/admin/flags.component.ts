import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * FlagsComponent — feature flag toggle grid.
 *
 * `GET /api/admin/flags` returns every flag (key, scope, scope_id, enabled,
 * description, updated_at). We render the table and let the operator flip
 * each row with `<bcl-toggle>`. Toggling POSTs `/api/admin/flags/toggle`
 * which audit-logs.
 */
import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  computed,
  inject,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';
import {
  HlmButton,
  HlmInput,
  HlmSwitch,
  HlmSkeleton,
  ToastService,
} from '../../shared/ui-spartan';
import { BclRollingCounterComponent } from '../_shared/rolling-counter.component';

interface FlagRow {
  readonly key: string;
  readonly scope: 'global' | 'tenant' | 'user';
  readonly scope_id: string;
  readonly enabled: boolean;
  readonly stage?: string;
  readonly rollout_percent?: number;
  readonly description: string;
  readonly updated_at: number;
}

/** Tailwind classes for a flag's promotion-stage badge. */
export function stageBadgeClass(stage: string | undefined): string {
  switch (stage) {
    case 'stable':
      return 'bg-bcl-success/15 text-bcl-success ring-bcl-success/30';
    case 'beta':
      return 'bg-primary/15 text-primary ring-primary/30';
    case 'deprecated':
      return 'bg-bcl-warn/15 text-bcl-warn ring-bcl-warn/30';
    case 'killswitch':
      return 'bg-bcl-danger/15 text-bcl-danger ring-bcl-danger/30';
    case 'override':
      return 'bg-bcl-violet/15 text-bcl-violet ring-bcl-violet/30';
    default: // experimental
      return 'bg-muted text-muted-foreground ring-border';
  }
}

@Component({
  selector: 'app-admin-flags',
  standalone: true,
  imports: [
    DatePipe,
    ReactiveFormsModule,
    HlmButton,
    HlmInput,
    HlmSwitch,
    HlmSkeleton,
    BclRollingCounterComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="mb-4 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
      <div>
        <h1 class="text-2xl font-bold text-foreground">Feature flags</h1>
        <p class="text-sm text-muted-foreground">
          Per-flag, per-scope on/off. Toggling audit-logs immediately. Scopes: global (default),
          tenant, user.
        </p>
      </div>
      <div class="flex items-center gap-2">
        <input
          hlmInput
          type="search"
          [formControl]="filterCtrl"
          placeholder="Filter by key…"
          class="h-9 w-48"
          aria-label="Filter feature flags by key"
        />
        <button hlmBtn variant="secondary" (click)="refresh()">Refresh</button>
      </div>
    </header>

    @if (flags().length > 0) {
      <!-- Cockpit summary strip — at-a-glance flag state. Counters roll
           (cinematic-ui-patterns); the ratio bar shows enabled share. -->
      <section
        class="mb-4 grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-3"
        aria-label="Feature flag summary"
      >
        <div class="bg-card px-4 py-3">
          <p class="font-mono text-[11px] uppercase tracking-wider text-bcl-accent">Total</p>
          <p class="bcl-tabular mt-1 text-2xl font-bold text-foreground">
            <bcl-rolling-counter [value]="summary().total" />
          </p>
        </div>
        <div class="bg-card px-4 py-3">
          <p class="font-mono text-[11px] uppercase tracking-wider text-bcl-accent">Enabled</p>
          <p class="bcl-tabular mt-1 text-2xl font-bold text-foreground">
            <bcl-rolling-counter [value]="summary().enabled" />
          </p>
        </div>
        <div class="bg-card px-4 py-3">
          <p class="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">Disabled</p>
          <p class="bcl-tabular mt-1 text-2xl font-bold text-foreground">
            <bcl-rolling-counter [value]="summary().disabled" />
          </p>
        </div>
        <div
          class="col-span-3 bg-card px-4 py-2"
          role="progressbar"
          [attr.aria-valuenow]="summary().pct"
          aria-valuemin="0"
          aria-valuemax="100"
          [attr.aria-label]="summary().enabled + ' of ' + summary().total + ' flags enabled'"
        >
          <div class="h-1.5 w-full overflow-hidden rounded-full bg-background">
            <div
              class="h-full rounded-full bg-bcl-accent transition-[width] duration-500"
              [style.width.%]="summary().pct"
            ></div>
          </div>
        </div>
      </section>
    }

    @if (error(); as e) {
      <div
        class="mb-4 flex items-center justify-between gap-3 rounded-xl border border-destructive/40 bg-destructive/5 px-4 py-3"
        role="alert"
      >
        <p class="text-sm text-foreground">Feature flags — {{ e }}</p>
        <button hlmBtn variant="outline" size="sm" (click)="refresh()">Try again</button>
      </div>
    }

    @if (loading() && flags().length === 0) {
      <div class="space-y-2" aria-label="Loading feature flags">
        <div hlmSkeleton class="h-16 w-full"></div>
        <div hlmSkeleton class="h-16 w-full"></div>
        <div hlmSkeleton class="h-16 w-full"></div>
      </div>
    } @else if (flags().length === 0) {
      <div class="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
        No flags defined. Add flags by POSTing to /api/admin/flags/toggle; once defined they live
        here for toggling.
      </div>
    } @else {
      <ul role="list" class="flex flex-col divide-y divide-border rounded-xl border border-border bg-card">
        @for (f of visible(); track flagKey(f)) {
          <li class="flex flex-col gap-2 p-4 sm:flex-row sm:items-center sm:justify-between">
            <div class="min-w-0">
              <p class="flex items-center gap-2 font-mono text-sm text-foreground">
                {{ f.key }}
                <span class="rounded-full bg-background px-2 py-0.5 text-xs text-muted-foreground ring-1 ring-border">
                  {{ f.scope }}{{ f.scope_id ? ':' + f.scope_id : '' }}
                </span>
                @if (f.stage) {
                  <span class="rounded-full px-2 py-0.5 text-xs ring-1" [class]="stageClass(f.stage)">
                    {{ f.stage }}
                  </span>
                }
                @if ((f.rollout_percent ?? 0) > 0 && (f.rollout_percent ?? 0) < 100) {
                  <span class="font-mono text-xs text-muted-foreground">{{ f.rollout_percent }}% rollout</span>
                }
              </p>
              @if (f.description) {
                <p class="mt-1 text-xs text-muted-foreground">{{ f.description }}</p>
              }
              @if (f.updated_at) {
                <p class="mt-1 text-xs text-muted-foreground">
                  Updated {{ f.updated_at * 1000 | date: 'short' }}
                </p>
              }
            </div>
            <hlm-switch
              [checked]="f.enabled"
              [label]="f.enabled ? 'On' : 'Off'"
              [ariaLabel]="(f.enabled ? 'Disable ' : 'Enable ') + f.key"
              (changed)="toggle(f, $event)"
            />
          </li>
        }
      </ul>
    }
  `,
})
export class FlagsComponent implements OnInit {
  private readonly http = inject(HttpClient);
  private readonly toast = inject(ToastService);

  readonly flags = signal<readonly FlagRow[]>([]);
  readonly loading = signal<boolean>(false);
  readonly error = signal<string | null>(null);
  readonly filterCtrl = new FormControl<string>('', { nonNullable: true });
  readonly filterText = signal<string>('');

  readonly visible = (): readonly FlagRow[] => {
    const t = this.filterText().trim().toLowerCase();
    if (!t) return this.flags();
    return this.flags().filter((f) => f.key.toLowerCase().includes(t));
  };

  /** At-a-glance counts for the cockpit summary strip. */
  readonly summary = computed(() => {
    const all = this.flags();
    const total = all.length;
    const enabled = all.filter((f) => f.enabled).length;
    return { total, enabled, disabled: total - enabled, pct: total ? Math.round((enabled / total) * 100) : 0 };
  });

  constructor() {
    this.filterCtrl.valueChanges
      .pipe(takeUntilDestroyed())
      .subscribe((v) => this.filterText.set(v ?? ''));
  }

  ngOnInit(): void {
    void this.refresh();
  }

  flagKey(f: FlagRow): string {
    return `${f.key}|${f.scope}|${f.scope_id}`;
  }

  /** Stage badge classes (delegates to the tested pure helper). */
  stageClass(stage: string | undefined): string {
    return stageBadgeClass(stage);
  }

  async refresh(): Promise<void> {
    this.loading.set(true);
    this.error.set(null);
    try {
      const r = await firstValueFrom(
        this.http.get<{ ok: boolean; flags?: readonly FlagRow[]; warning?: string }>(
          '/api/admin/flags',
          { withCredentials: true },
        ),
      );
      this.flags.set(r.flags ?? []);
      if (r.warning) this.error.set(`Warning: ${r.warning}`);
    } catch (err) {
      this.error.set(`Failed to load flags: ${(err as Error).message}`);
    } finally {
      this.loading.set(false);
    }
  }

  async toggle(f: FlagRow, enabled: boolean): Promise<void> {
    // Optimistic: flip immediately, revert on failure.
    const prev = this.flags();
    this.flags.set(
      prev.map((row) =>
        row.key === f.key && row.scope === f.scope && row.scope_id === f.scope_id
          ? { ...row, enabled }
          : row,
      ),
    );
    try {
      await firstValueFrom(
        this.http.post(
          '/api/admin/flags/toggle',
          {
            key: f.key,
            scope: f.scope,
            scope_id: f.scope_id,
            enabled,
            description: f.description,
          },
          { withCredentials: true },
        ),
      );
      this.toast.success(`${f.key} ${enabled ? 'enabled' : 'disabled'} · just now`);
    } catch (err) {
      const msg = (err as Error).message;
      this.flags.set(prev);
      this.error.set(`Toggle failed: ${msg}`);
      this.toast.error('Toggle failed — reverted', undefined, msg);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'flags-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
