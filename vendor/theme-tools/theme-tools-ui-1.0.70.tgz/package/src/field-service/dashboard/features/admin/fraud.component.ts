import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * AdminFraudComponent — AI-classified refund-fraud queue on the admin console.
 * Live surface = Angular /dashboard/admin.
 *
 * Unblocked 2026-06-03: `/api/admin/fraud` migrated from OWNER_INVOICE_KEY Bearer-only
 * to the shared `ownerOrSuperAdmin` gate, so the cookie-auth SPA can read it.
 *   GET /api/admin/fraud → { ok, items:[{id,bookingId,customerEmail,amountCents,verdict,
 *        confidence,reasoning,signals[],autoApproved,reviewedAt,...}] }
 * READ-ONLY here: the POST /:id/review human-verdict + POST /run (re)classification are
 * operator actions, surfaced as a follow-up. Pure helpers verdictTone/formatConfidence/
 * dollars/isReviewed unit-tested.
 */
import { ChangeDetectionStrategy, Component, OnInit, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { HlmCardImports } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

export type FraudVerdict = 'fraud' | 'legit' | 'unclear';

export interface FraudItem {
  readonly id: string;
  readonly bookingId: string | null;
  readonly customerEmail: string | null;
  readonly amountCents: number;
  readonly verdict: FraudVerdict;
  readonly confidence: number;
  readonly reasoning: string;
  readonly autoApproved: boolean;
  readonly reviewedAt: string | null;
}

/** Pure: badge tone for a verdict. */
export function verdictTone(v: FraudVerdict): 'danger' | 'safe' | 'warn' {
  if (v === 'fraud') return 'danger';
  if (v === 'legit') return 'safe';
  return 'warn';
}

/** Pure: 0–1 confidence as a one-decimal percent. */
export function formatConfidence(c: number): string {
  if (!Number.isFinite(c)) return '0%';
  return `${(Math.max(0, Math.min(1, c)) * 100).toFixed(0)}%`;
}

/** Pure: cents → $ string. */
export function dollars(cents: number): string {
  if (!Number.isFinite(cents)) return '$0';
  return `$${(cents / 100).toFixed(2)}`;
}

/** Pure: a row a human has already reviewed. */
export function isReviewed(item: Pick<FraudItem, 'reviewedAt'>): boolean {
  return !!item.reviewedAt;
}

interface FraudResponse {
  readonly ok: boolean;
  readonly items?: readonly FraudItem[];
}

@Component({
  selector: 'app-admin-fraud',
  standalone: true,
  imports: [...HlmCardImports, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div hlmCard bclReveal data-testid="admin-fraud">
      <div hlmCardHeader class="flex flex-row items-center justify-between gap-3">
        <div>
          <h3 hlmCardTitle>
            Refund-fraud queue
            @if (pendingCount() > 0) {
              <span class="ml-2 rounded-full bg-destructive/20 px-2 py-0.5 text-xs text-destructive">{{ pendingCount() }} to review</span>
            }
          </h3>
          <p hlmCardDescription>AI-classified refund requests. Approving a refund is an operator action.</p>
        </div>
      </div>
      <div hlmCardContent>
        @if (loading()) {
          <p class="text-sm text-bcl-ink-muted">Loading fraud queue…</p>
        } @else if (error()) {
          <p class="text-sm text-bcl-warn" role="status">{{ error() }}</p>
        } @else if (items().length === 0) {
          <p class="text-sm text-bcl-ink-muted">No refund classifications yet.</p>
        } @else {
          <ul class="grid gap-2">
            @for (it of items(); track it.id) {
              <li class="rounded-md border border-bcl-border bg-bcl-bg-elev px-3 py-2 text-sm">
                <div class="flex items-center justify-between gap-2">
                  <span class="flex items-center gap-2 min-w-0">
                    <span
                      class="shrink-0 rounded-full px-2 py-0.5 text-xs ring-1"
                      [class.text-destructive]="tone(it.verdict) === 'danger'"
                      [class.ring-destructive\/40]="tone(it.verdict) === 'danger'"
                      [class.text-bcl-success]="tone(it.verdict) === 'safe'"
                      [class.ring-bcl-success\/40]="tone(it.verdict) === 'safe'"
                      [class.text-bcl-warn]="tone(it.verdict) === 'warn'"
                      [class.ring-bcl-warn\/40]="tone(it.verdict) === 'warn'"
                    >{{ it.verdict }} · {{ conf(it.confidence) }}</span>
                    <span class="truncate font-mono text-bcl-ink">{{ amount(it.amountCents) }}</span>
                  </span>
                  <span class="shrink-0 text-xs" [class.text-bcl-success]="reviewed(it)" [class.text-bcl-ink-muted]="!reviewed(it)">
                    {{ reviewed(it) ? 'Reviewed' : (it.autoApproved ? 'Auto-OK' : 'Pending') }}
                  </span>
                </div>
                @if (it.reasoning) {
                  <p class="mt-1 truncate text-xs text-bcl-ink-muted">{{ it.reasoning }}</p>
                }
              </li>
            }
          </ul>
        }
      </div>
    </div>
  `,
})
export class AdminFraudComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly items = signal<readonly FraudItem[]>([]);
  readonly loading = signal(true);
  readonly error = signal<string>('');
  readonly pendingCount = computed(() => this.items().filter((i) => !isReviewed(i) && !i.autoApproved).length);

  readonly tone = verdictTone;
  readonly conf = formatConfidence;
  readonly amount = dollars;
  readonly reviewed = isReviewed;

  ngOnInit(): void {
    void this.load();
  }

  async load(): Promise<void> {
    this.loading.set(true);
    this.error.set('');
    try {
      const r = await firstValueFrom(
        this.http.get<FraudResponse>('/api/admin/fraud', { withCredentials: true }),
      );
      this.items.set(r?.ok ? (r.items ?? []) : []);
    } catch {
      this.error.set('Sign in as an operator to view the fraud queue.');
    } finally {
      this.loading.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'fraud-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
