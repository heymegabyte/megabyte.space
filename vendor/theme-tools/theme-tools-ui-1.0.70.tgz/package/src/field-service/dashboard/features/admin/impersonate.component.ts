import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * AdminImpersonateComponent — impersonate-as-customer control on the admin
 * console. Angular port of the React impersonation banner/control. Live surface
 * = Angular /dashboard/admin (super-admin session).
 *
 * Verified by mount (`app.route('/api/admin/impersonate', adminImpersonate)`,
 * auth migrated 2026-06-04 to `ownerOrSuperAdmin`):
 *   GET  /api/admin/impersonate/status → { ok, active, marker? }
 *   POST /api/admin/impersonate/start  { contact, channel, reason } → { ok, redirect }
 *   POST /api/admin/impersonate/stop   → { ok, contact }
 *
 * Start mints a real `bcl_cust_sid` customer session for the operator scoped to
 * a contact + a non-HttpOnly marker cookie, then redirects to /me. Because it
 * grants the operator another user's session it is SENSITIVE — gated behind a
 * confirm dialog with a mandatory reason (audit-logged + admin-event on the
 * worker). Stop is always-safe de-escalation. Dark cockpit, bclReveal. Pure
 * helpers unit-tested.
 */
import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';
import { HlmButton, HlmInput, HlmDialog, ToastService } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

export type ImpersonateChannel = 'email' | 'sms';

export interface ImpersonateMarker {
  readonly contact: string;
  readonly channel: string;
  readonly startedAt: string;
  readonly sessionId?: string;
}

interface StatusResponse {
  readonly ok: boolean;
  readonly active: boolean;
  readonly marker?: ImpersonateMarker;
}

/** Pure: email shape check (mirrors the worker's looksLikeEmail). Unit-tested. */
export function looksLikeEmail(value: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
}

/** Pure: whether (contact, channel) would pass the worker's normalizeContact. Unit-tested. */
export function validContact(contact: string, channel: ImpersonateChannel): boolean {
  const trimmed = (contact || '').trim();
  if (channel === 'email') return looksLikeEmail(trimmed);
  const digits = trimmed.replace(/\D/g, '');
  return digits.length >= 10;
}

/** Pure: human channel label. Unit-tested. */
export function channelLabel(channel: string): string {
  return channel === 'sms' ? 'SMS' : 'Email';
}

/** Pure: a one-line summary of the active impersonation marker. Unit-tested. */
export function markerLabel(marker: ImpersonateMarker | null | undefined): string {
  if (!marker?.contact) return 'No active impersonation';
  const t = marker.startedAt ? Date.parse(marker.startedAt) : NaN;
  const since = Number.isNaN(t)
    ? ''
    : ` · since ${new Date(t).toLocaleString(undefined, { hour: 'numeric', minute: '2-digit' })}`;
  return `${marker.contact}${since}`;
}

@Component({
  selector: 'app-admin-impersonate',
  standalone: true,
  imports: [HlmButton, HlmInput, HlmDialog, FormsModule, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="mb-4">
      <h1 class="text-2xl font-bold text-foreground">Impersonate a customer</h1>
      <p class="text-sm text-muted-foreground">
        Browse as a customer to debug their account. Every start/stop is audit-logged.
      </p>
    </header>

    @if (active()) {
      <section
        bclReveal
        class="mb-4 flex flex-wrap items-center gap-3 rounded-xl border border-bcl-warn/40 bg-bcl-warn/5 px-4 py-3"
        role="status"
        data-testid="impersonate-active"
      >
        <span class="inline-block h-2.5 w-2.5 animate-pulse rounded-full bg-bcl-warn"></span>
        <div class="min-w-0">
          <p class="text-sm font-semibold text-foreground">Impersonation active</p>
          <p class="truncate text-xs text-muted-foreground">{{ markerText() }}</p>
        </div>
        <button hlmBtn variant="destructive" size="sm" class="ml-auto" [disabled]="busy()" (click)="stop()" data-testid="impersonate-stop">
          Exit impersonation
        </button>
      </section>
    } @else {
      <section bclReveal class="rounded-xl border border-border bg-card/60 p-4" data-testid="impersonate-idle">
        <p class="mb-3 text-sm text-muted-foreground">Not currently impersonating anyone.</p>
        <button hlmBtn (click)="openStart()" data-testid="impersonate-start-open">Start impersonation</button>
      </section>
    }

    @if (error(); as e) {
      <div class="mt-4 rounded-xl border border-destructive/40 bg-destructive/5 px-4 py-3 text-sm text-foreground" role="alert">
        {{ e }}
      </div>
    }

    <!-- Sensitive: confirm + mandatory reason before minting a customer session. -->
    <app-dialog [open]="starting()" (openChange)="$event ? null : closeStart()" ariaLabel="Start impersonation">
      <div class="flex flex-col gap-3">
        <div>
          <h2 class="text-lg font-bold text-foreground">Start impersonation</h2>
          <p class="text-sm text-muted-foreground">
            Mints a real customer session for you + redirects to their view. Audit-logged.
          </p>
        </div>
        <label class="text-sm text-foreground">
          Channel
          <select
            class="mt-1 w-full rounded-md border border-input bg-background px-2 py-2 text-sm text-foreground"
            [(ngModel)]="channelValue"
            aria-label="Contact channel"
            data-testid="impersonate-channel"
          >
            <option value="email">Email</option>
            <option value="sms">SMS</option>
          </select>
        </label>
        <label class="text-sm text-foreground">
          {{ channelValue === 'sms' ? 'Phone' : 'Email' }}
          <input
            hlmInput
            class="mt-1 w-full"
            [(ngModel)]="contactValue"
            [placeholder]="channelValue === 'sms' ? '+15551234567' : 'customer@example.com'"
            aria-label="Customer contact"
            data-testid="impersonate-contact"
          />
        </label>
        <label class="text-sm text-foreground">
          Reason (required)
          <textarea
            hlmInput
            rows="2"
            class="mt-1 w-full"
            [(ngModel)]="reasonValue"
            placeholder="e.g. debugging a failed booking on their account"
            aria-label="Reason"
            data-testid="impersonate-reason"
          ></textarea>
        </label>
        <div class="flex justify-end gap-2">
          <button hlmBtn variant="outline" (click)="closeStart()">Cancel</button>
          <button
            hlmBtn
            [disabled]="!canStart() || busy()"
            (click)="confirmStart()"
            data-testid="impersonate-start-confirm"
          >
            Start as customer
          </button>
        </div>
      </div>
    </app-dialog>
  `,
})
export class AdminImpersonateComponent implements OnInit {
  private readonly http = inject(HttpClient);
  private readonly toast = inject(ToastService);

  readonly active = signal(false);
  readonly marker = signal<ImpersonateMarker | null>(null);
  readonly busy = signal(false);
  readonly error = signal<string | null>(null);

  readonly starting = signal(false);
  contactValue = '';
  channelValue: ImpersonateChannel = 'email';
  reasonValue = '';

  ngOnInit(): void {
    void this.refresh();
  }

  markerText(): string {
    return markerLabel(this.marker());
  }
  canStart(): boolean {
    return validContact(this.contactValue, this.channelValue) && this.reasonValue.trim().length >= 3;
  }

  async refresh(): Promise<void> {
    this.error.set(null);
    try {
      const r = await firstValueFrom(
        this.http.get<StatusResponse>('/api/admin/impersonate/status', { withCredentials: true }),
      );
      this.active.set(!!r?.active);
      this.marker.set(r?.marker ?? null);
    } catch (err) {
      this.error.set(`Couldn't load status: ${(err as Error).message}`);
    }
  }

  openStart(): void {
    this.contactValue = '';
    this.channelValue = 'email';
    this.reasonValue = '';
    this.starting.set(true);
  }
  closeStart(): void {
    this.starting.set(false);
  }

  async confirmStart(): Promise<void> {
    if (!this.canStart()) return;
    this.busy.set(true);
    try {
      const r = await firstValueFrom(
        this.http.post<{ ok: boolean; redirect?: string }>(
          '/api/admin/impersonate/start',
          { contact: this.contactValue.trim(), channel: this.channelValue, reason: this.reasonValue.trim() },
          { withCredentials: true },
        ),
      );
      this.closeStart();
      // The worker minted a customer session for this browser; land on their view.
      const redirect = r?.redirect || '/me';
      if (typeof globalThis !== 'undefined' && globalThis.location) {
        globalThis.location.href = redirect;
      } else {
        await this.refresh();
      }
    } catch (err) {
      this.toast.error('Could not start impersonation', undefined, (err as Error).message);
    } finally {
      this.busy.set(false);
    }
  }

  async stop(): Promise<void> {
    this.busy.set(true);
    try {
      await firstValueFrom(
        this.http.post('/api/admin/impersonate/stop', {}, { withCredentials: true }),
      );
      this.toast.success('Impersonation ended');
      await this.refresh();
    } catch (err) {
      this.toast.error('Could not stop impersonation', undefined, (err as Error).message);
    } finally {
      this.busy.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'impersonate-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
