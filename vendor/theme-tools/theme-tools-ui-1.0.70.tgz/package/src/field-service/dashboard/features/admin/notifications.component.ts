import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * AdminNotificationsComponent — the operator events inbox at /admin/notifications.
 *
 * Surfaces GET /api/admin/notifications (the admin_events table: manual refunds,
 * fraud holds, flag toggles, safety/SOS, etc. with severity). The endpoint was
 * specced for "/admin/notifications" but had no dashboard component + was
 * OWNER_INVOICE_KEY-bearer-only; auth migrated to the shared ownerOrSuperAdmin gate
 * 2026-06-07 so the dashboard session can read it.
 */
import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HlmCardImports } from '../../shared/ui-spartan';

export type AdminEventSeverity = 'info' | 'warn' | 'error' | 'critical';

export interface AdminEvent {
  readonly id: string;
  readonly ts: number;
  readonly kind: string;
  readonly severity: AdminEventSeverity;
  readonly actor: string | null;
  readonly target_type: string | null;
  readonly target_id: string | null;
  readonly summary: string;
  readonly details: string | null;
}

interface EventsResponse {
  readonly ok: boolean;
  readonly events?: readonly AdminEvent[];
  readonly nextCursor?: number | null;
  readonly error?: string;
}

/** Tailwind classes for an event's severity badge. Tested. */
export function severityBadgeClass(sev: string): string {
  switch (sev) {
    case 'critical':
      return 'bg-red-500/20 text-red-300 ring-red-500/40';
    case 'error':
      return 'bg-red-500/15 text-red-300 ring-red-500/30';
    case 'warn':
      return 'bg-amber-500/15 text-amber-300 ring-amber-500/30';
    default: // info
      return 'bg-muted text-muted-foreground ring-border';
  }
}

@Component({
  selector: 'app-admin-notifications',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [...HlmCardImports, DatePipe],
  template: `
    <header class="mb-4">
      <h1 class="text-2xl font-bold text-foreground">Notifications</h1>
      <p class="text-sm text-muted-foreground">Operator events — refunds, fraud, flags, safety.</p>
    </header>

    <div class="mb-3 flex flex-wrap gap-2">
      @for (s of severities; track s) {
        <button
          type="button"
          class="rounded-full px-3 py-1 text-xs ring-1 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
          [class]="filter() === s ? 'bg-primary text-primary-foreground ring-primary' : 'bg-background text-muted-foreground ring-border'"
          (click)="setFilter(s)"
        >
          {{ s === '' ? 'All' : s }}
        </button>
      }
    </div>

    @if (error(); as e) {
      <div hlmCard class="p-4"><p class="text-sm text-destructive">{{ e }}</p></div>
    } @else if (events().length > 0) {
      <ul role="list" class="flex flex-col divide-y divide-border rounded-xl border border-border bg-card">
        @for (ev of events(); track ev.id) {
          <li class="flex items-start gap-3 p-4">
            <span class="mt-0.5 shrink-0 rounded-full px-2 py-0.5 text-xs ring-1" [class]="sevClass(ev.severity)">
              {{ ev.severity }}
            </span>
            <div class="min-w-0 flex-1">
              <p class="text-sm text-foreground">{{ ev.summary }}</p>
              <p class="mt-0.5 font-mono text-xs text-muted-foreground">
                {{ ev.kind }}@if (ev.actor) { · {{ ev.actor }} }@if (ev.target_id) { · {{ ev.target_type }}:{{ ev.target_id }} }
              </p>
            </div>
            <span class="shrink-0 text-xs text-muted-foreground">{{ ev.ts | date: 'short' }}</span>
          </li>
        }
      </ul>
      @if (nextCursor() != null) {
        <div class="mt-3 flex justify-center">
          <button
            type="button"
            class="rounded-md border border-border px-4 py-2 text-sm text-muted-foreground hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
            (click)="loadMore()"
          >
            Load older
          </button>
        </div>
      }
    } @else if (loading()) {
      <p class="text-sm text-muted-foreground">Loading…</p>
    } @else {
      <div hlmCard class="p-6 text-center">
        <p class="text-sm text-muted-foreground">No operator events{{ filter() ? ' at this severity' : '' }} yet.</p>
      </div>
    }
  `,
})
export class AdminNotificationsComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly events = signal<readonly AdminEvent[]>([]);
  readonly nextCursor = signal<number | null>(null);
  readonly loading = signal<boolean>(false);
  readonly error = signal<string | null>(null);
  readonly filter = signal<'' | AdminEventSeverity>('');

  readonly severities: readonly ('' | AdminEventSeverity)[] = ['', 'info', 'warn', 'error', 'critical'];

  sevClass(sev: string): string {
    return severityBadgeClass(sev);
  }

  ngOnInit(): void {
    void this.load(true);
  }

  setFilter(s: '' | AdminEventSeverity): void {
    if (this.filter() === s) return;
    this.filter.set(s);
    void this.load(true);
  }

  loadMore(): void {
    void this.load(false);
  }

  private async load(reset: boolean): Promise<void> {
    this.loading.set(true);
    this.error.set(null);
    const params = new URLSearchParams({ limit: '50' });
    if (this.filter()) params.set('severity', this.filter());
    if (!reset && this.nextCursor() != null) params.set('cursor', String(this.nextCursor()));
    const r = await firstValueFrom(
      this.http
        .get<EventsResponse>(`/api/admin/notifications?${params.toString()}`)
        .pipe(catchError(() => of({ ok: false, error: 'Failed to load notifications' } as EventsResponse))),
    );
    if (r.ok) {
      this.events.update((cur) => (reset ? (r.events ?? []) : [...cur, ...(r.events ?? [])]));
      this.nextCursor.set(r.nextCursor ?? null);
    } else {
      this.error.set(r.error ?? 'Unknown error');
    }
    this.loading.set(false);
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'notifications-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
