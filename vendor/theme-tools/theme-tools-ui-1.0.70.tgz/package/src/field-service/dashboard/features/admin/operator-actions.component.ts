import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * AdminOperatorActionsComponent — the consolidated operator-actions panel: the
 * closing move for admin parity once read-surfaces are exhausted. Each button
 * fires an existing session-gated POST (compute/maintenance only — no money, no
 * customer outreach), behind a confirm dialog, and shows the result.
 *
 * All endpoints are session-gated via the shared `ownerOrSuperAdmin` gate:
 *   POST /api/admin/ops/run-anomalies   → { ok, fired }
 *   POST /api/admin/fraud/run           → { ok, classified }
 *   POST /api/admin/backup/d1           → { ok, tables[] }
 *   POST /api/admin/weekly-report/generate → { ok, recipient }   (internal email)
 * Pure helper summarizeResult unit-tested.
 */
import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { HlmCardImports, HlmButton, ConfirmDialog } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

interface OperatorAction {
  readonly id: string;
  readonly label: string;
  readonly description: string;
  readonly endpoint: string;
  readonly body: Record<string, unknown>;
  readonly confirm: string;
}

const ACTIONS: readonly OperatorAction[] = [
  {
    id: 'run-anomalies',
    label: 'Run anomaly detection',
    description: 'Scan revenue/rating/SLA/no-show detectors and record any anomalies.',
    endpoint: '/api/admin/ops/run-anomalies',
    body: {},
    confirm: 'Run all anomaly detectors now?',
  },
  {
    id: 'run-fraud',
    label: 'Classify refund fraud',
    description: 'AI-classify unreviewed refund requests into the fraud queue.',
    endpoint: '/api/admin/fraud/run',
    body: { limit: 20 },
    confirm: 'Run AI fraud classification on pending refund requests?',
  },
  {
    id: 'run-backup',
    label: 'Back up D1 → R2',
    description: 'Export every D1 table as gzipped NDJSON to the R2 backups bucket.',
    endpoint: '/api/admin/backup/d1',
    body: {},
    confirm: 'Run a full D1 → R2 backup now?',
  },
  {
    id: 'weekly-report',
    label: 'Generate weekly report',
    description: 'Compose the weekly board narrative and email it to the operator.',
    endpoint: '/api/admin/weekly-report/generate',
    body: {},
    confirm: 'Generate + email the weekly report now?',
  },
];

/** Pure: a human one-liner from the various action response shapes. */
export function summarizeResult(json: Record<string, unknown> | null): string {
  if (!json) return 'No response';
  if (json['ok'] === false) return `Error: ${String(json['error'] ?? 'failed')}`;
  if (typeof json['fired'] === 'number') return `${json['fired']} anomalies fired`;
  if (typeof json['classified'] === 'number') return `Classified ${json['classified']}`;
  if (Array.isArray(json['tables'])) return `Backed up ${(json['tables'] as unknown[]).length} tables`;
  if (typeof json['recipient'] === 'string') return `Report emailed to ${json['recipient']}`;
  return 'Done';
}

@Component({
  selector: 'app-admin-operator-actions',
  standalone: true,
  imports: [...HlmCardImports, HlmButton, ConfirmDialog, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div hlmCard bclReveal data-testid="admin-operator-actions">
      <div hlmCardHeader>
        <h3 hlmCardTitle>Operator actions</h3>
        <p hlmCardDescription>On-demand maintenance + reports. Each runs immediately on confirm.</p>
      </div>
      <div hlmCardContent>
        <ul class="grid gap-3">
          @for (a of actions; track a.id) {
            <li class="rounded-md border border-bcl-border bg-bcl-bg-elev p-3">
              <div class="flex items-start justify-between gap-3">
                <div class="min-w-0">
                  <p class="font-semibold text-bcl-ink">{{ a.label }}</p>
                  <p class="mt-0.5 text-xs text-bcl-ink-muted">{{ a.description }}</p>
                </div>
                <button hlmBtn variant="outline" class="shrink-0" [disabled]="running() === a.id" (click)="run(a)" [attr.data-testid]="'op-' + a.id">
                  {{ running() === a.id ? 'Running…' : 'Run' }}
                </button>
              </div>
              @if (result()[a.id]; as r) {
                <p class="mt-2 text-xs" [class.text-bcl-success]="!r.startsWith('Error')" [class.text-destructive]="r.startsWith('Error')" role="status">{{ r }}</p>
              }
            </li>
          }
        </ul>
      </div>
    </div>

    <!-- Spartan confirm (focus-trapped + Esc/backdrop) — replaces native confirm(). -->
    @if (pending(); as p) {
      <app-confirm-dialog
        [open]="true"
        [title]="p.label"
        [description]="p.confirm"
        [confirmLabel]="'Run now'"
        (confirmed)="execute(p)"
        (cancelled)="cancel()"
      />
    }
  `,
})
export class AdminOperatorActionsComponent {
  private readonly http = inject(HttpClient);

  readonly actions = ACTIONS;
  readonly running = signal<string | null>(null);
  readonly result = signal<Record<string, string>>({});
  /** The action awaiting confirmation (null = dialog closed). */
  readonly pending = signal<OperatorAction | null>(null);

  /** Open the confirm dialog for an action. */
  run(a: OperatorAction): void {
    this.pending.set(a);
  }

  cancel(): void {
    this.pending.set(null);
  }

  /** Fire the action after confirmation, via HttpClient (interceptors apply). */
  async execute(a: OperatorAction): Promise<void> {
    this.pending.set(null);
    this.running.set(a.id);
    try {
      const json = await firstValueFrom(
        this.http.post<Record<string, unknown>>(a.endpoint, a.body, { withCredentials: true }),
      );
      this.setResult(a.id, summarizeResult(json ?? null));
    } catch (err) {
      const status = (err as { status?: number }).status;
      this.setResult(a.id, status ? `Error: ${status}` : 'Error: network');
    } finally {
      this.running.set(null);
    }
  }

  private setResult(id: string, msg: string): void {
    this.result.set({ ...this.result(), [id]: msg });
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'operator-actions-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
