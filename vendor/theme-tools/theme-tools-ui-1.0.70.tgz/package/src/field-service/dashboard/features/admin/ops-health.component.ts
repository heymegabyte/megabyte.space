import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * AdminOpsHealthComponent — SLO health + open operational anomalies on the admin
 * console. Live surface = Angular /dashboard/admin.
 *
 * Unblocked 2026-06-03: `/api/admin/ops` migrated from OWNER_INVOICE_KEY Bearer-only
 * to the shared `ownerOrSuperAdmin` gate.
 *   GET /api/admin/ops/health    → { ok, slos:[{slo,value,target,breached,ts}] }
 *   GET /api/admin/ops/anomalies?status=open → { ok, anomalies:[{id,kind,severity,detected_at,resolved_at}] }
 * Read-only (run-anomalies / forecast / resolve are operator actions). Pure helpers
 * sloOk/anomalyTone/formatMetric unit-tested.
 */
import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HlmCardImports } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

export interface Slo {
  readonly slo: string;
  readonly value: number;
  readonly target: number;
  readonly breached: boolean;
}
export interface OpsAnomaly {
  readonly id: string;
  readonly kind: string;
  readonly severity: string;
  readonly detected_at: string;
  readonly resolved_at: string | null;
}

/** Pure: an SLO is healthy when not breached. */
export function sloOk(s: Pick<Slo, 'breached'>): boolean {
  return !s.breached;
}

/** Pure: tone band for an anomaly severity. */
export function anomalyTone(severity: string): 'danger' | 'warn' | 'info' {
  const s = (severity ?? '').toLowerCase();
  if (s === 'critical' || s === 'high') return 'danger';
  if (s === 'medium' || s === 'warn' || s === 'warning') return 'warn';
  return 'info';
}

/** Pure: compact "value / target" metric string. */
export function formatMetric(value: number, target: number): string {
  const v = Number.isFinite(value) ? value : 0;
  const t = Number.isFinite(target) ? target : 0;
  return `${v} / ${t}`;
}

interface HealthResponse {
  readonly ok: boolean;
  readonly slos?: readonly Slo[];
}
interface AnomaliesResponse {
  readonly ok: boolean;
  readonly anomalies?: readonly OpsAnomaly[];
}

@Component({
  selector: 'app-admin-ops-health',
  standalone: true,
  imports: [...HlmCardImports, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div hlmCard bclReveal data-testid="admin-ops-health">
      <div hlmCardHeader>
        <h3 hlmCardTitle>
          Ops health
          @if (breachedCount() > 0) {
            <span class="ml-2 rounded-full bg-destructive/20 px-2 py-0.5 text-xs text-destructive">{{ breachedCount() }} breached</span>
          }
        </h3>
        <p hlmCardDescription>Live SLOs + open operational anomalies.</p>
      </div>
      <div hlmCardContent>
        @if (loading()) {
          <p class="text-sm text-bcl-ink-muted">Loading ops health…</p>
        } @else if (error()) {
          <p class="text-sm text-bcl-warn" role="status">{{ error() }}</p>
        } @else {
          @if (slos().length > 0) {
            <div class="grid grid-cols-2 gap-2 sm:grid-cols-3">
              @for (s of slos(); track s.slo) {
                <div class="rounded-md border border-bcl-border bg-bcl-bg-elev p-2.5">
                  <p class="font-mono text-[10px] uppercase tracking-wider text-bcl-ink-muted">{{ s.slo }}</p>
                  <p
                    class="mt-1 font-mono text-sm tabular-nums"
                    [class.text-bcl-success]="ok(s)"
                    [class.text-destructive]="!ok(s)"
                  >{{ metric(s.value, s.target) }}</p>
                </div>
              }
            </div>
          } @else {
            <p class="text-sm text-bcl-ink-muted">No SLO metrics in the last hour.</p>
          }

          @if (anomalies().length > 0) {
            <p class="mb-2 mt-5 font-mono text-[10px] uppercase tracking-wider text-bcl-ink-muted">Open anomalies</p>
            <ul class="grid gap-2">
              @for (a of anomalies(); track a.id) {
                <li class="flex items-center justify-between gap-2 rounded-md border border-bcl-border bg-bcl-bg px-3 py-2 text-sm">
                  <span class="flex items-center gap-2 min-w-0">
                    <span
                      class="shrink-0 rounded-full px-2 py-0.5 text-[10px] uppercase tracking-wider ring-1"
                      [class.text-destructive]="tone(a.severity) === 'danger'"
                      [class.ring-destructive\/40]="tone(a.severity) === 'danger'"
                      [class.text-bcl-warn]="tone(a.severity) === 'warn'"
                      [class.ring-bcl-warn\/40]="tone(a.severity) === 'warn'"
                      [class.text-bcl-ink-muted]="tone(a.severity) === 'info'"
                      [class.ring-bcl-border]="tone(a.severity) === 'info'"
                    >{{ a.severity || 'info' }}</span>
                    <span class="truncate text-bcl-ink">{{ a.kind }}</span>
                  </span>
                </li>
              }
            </ul>
          } @else {
            <p class="mt-4 text-sm text-bcl-success" role="status">✓ No open anomalies.</p>
          }
        }
      </div>
    </div>
  `,
})
export class AdminOpsHealthComponent implements OnInit {
  readonly slos = signal<readonly Slo[]>([]);
  readonly anomalies = signal<readonly OpsAnomaly[]>([]);
  readonly loading = signal(true);
  readonly error = signal<string>('');

  private readonly http = inject(HttpClient);

  readonly ok = sloOk;
  readonly tone = anomalyTone;
  readonly metric = formatMetric;

  breachedCount(): number {
    return this.slos().filter((s) => s.breached).length;
  }

  ngOnInit(): void {
    void this.load();
  }

  async load(): Promise<void> {
    this.loading.set(true);
    this.error.set('');
    try {
      const opts = { withCredentials: true } as const;
      const [h, a] = await Promise.all([
        firstValueFrom(this.http.get<HealthResponse>('/api/admin/ops/health', opts)),
        firstValueFrom(
          this.http
            .get<AnomaliesResponse>('/api/admin/ops/anomalies?status=open', opts)
            .pipe(catchError(() => of(null))),
        ),
      ]);
      this.slos.set(h?.ok ? (h.slos ?? []) : []);
      this.anomalies.set(a?.ok ? (a.anomalies ?? []) : []);
    } catch {
      this.error.set('Sign in as an operator to view ops health.');
    } finally {
      this.loading.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'ops-health-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
