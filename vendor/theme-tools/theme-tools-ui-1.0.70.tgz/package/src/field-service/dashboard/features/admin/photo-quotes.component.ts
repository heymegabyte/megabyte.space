import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { ChangeDetectionStrategy, Component, DestroyRef, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { catchError, finalize, of } from 'rxjs';

type IntakeStatus =
  | 'processing'
  | 'pending_approval'
  | 'rejected'
  | 'sending'
  | 'sent'
  | 'send_failed'
  | 'processing_failed';

interface PhotoIntake {
  readonly id: string;
  readonly from_phone: string;
  readonly service_hint: string;
  readonly condition: string | null;
  readonly estimated_min_cents: number | null;
  readonly estimated_max_cents: number | null;
  readonly suggested_crew: number | null;
  readonly suggested_hours: number | null;
  readonly ai_used: number;
  readonly created_at: string;
  readonly approval_status: IntakeStatus;
  readonly send_error: string | null;
}

@Component({
  selector: 'app-admin-photo-quotes',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="bcl-rise mb-5 rounded-2xl border border-bcl-border bcl-grain p-6">
      <p class="bcl-eyebrow mb-2">Admin · Photo estimates</p>
      <h1 class="font-display text-3xl font-extrabold tracking-tight text-bcl-ink">
        Photo estimate review
      </h1>
      <p class="mt-2 max-w-2xl text-sm text-bcl-ink-muted">
        Review AI-assisted MMS estimates before any price band is sent. Approval sends the stored
        proposal once; rejection records the decision without contacting the customer.
      </p>
    </header>

    @if (error()) {
      <div class="mb-4 rounded-xl border border-amber-500/30 bg-amber-500/5 p-4" role="alert">
        <p class="text-sm text-amber-300">{{ error() }}</p>
        <button
          type="button"
          class="mt-3 min-h-11 rounded-lg border border-bcl-accent px-4 py-2 text-sm font-semibold text-bcl-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
          (click)="load()"
        >Retry</button>
      </div>
    } @else if (loading()) {
      <p class="text-sm text-bcl-ink-muted" role="status">Loading photo estimates…</p>
    } @else if (intakes().length === 0) {
      <p class="bcl-glass p-5 text-sm text-bcl-ink-muted" data-testid="photo-quotes-empty">
        No photo estimates are waiting or recently decided.
      </p>
    } @else {
      <ul class="grid gap-4" aria-label="Photo estimate review queue">
        @for (intake of intakes(); track intake.id) {
          <li class="bcl-glass p-5" [attr.data-status]="intake.approval_status">
            <div class="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p class="font-semibold text-bcl-ink">{{ serviceLabel(intake.service_hint) }}</p>
                <p class="mt-1 text-xs text-bcl-ink-muted">
                  {{ maskedPhone(intake.from_phone) }} · {{ intake.created_at }}
                </p>
              </div>
              <span class="rounded-full border border-bcl-border px-2.5 py-1 text-xs text-bcl-ink-muted">
                {{ statusLabel(intake.approval_status) }}
              </span>
            </div>
            <dl class="mt-4 grid gap-2 text-sm sm:grid-cols-3">
              <div><dt class="text-bcl-ink-muted">Estimate</dt><dd class="text-bcl-ink">{{ band(intake) }}</dd></div>
              <div><dt class="text-bcl-ink-muted">Crew</dt><dd class="text-bcl-ink">{{ intake.suggested_crew ?? '—' }}</dd></div>
              <div><dt class="text-bcl-ink-muted">Hours</dt><dd class="text-bcl-ink">{{ intake.suggested_hours ?? '—' }}</dd></div>
            </dl>
            @if (intake.send_error) {
              <p class="mt-3 text-sm text-amber-300" role="status">Delivery failed. Approval can be retried safely.</p>
            }
            @if (intake.approval_status === 'pending_approval' || intake.approval_status === 'send_failed') {
              <div class="mt-4 flex flex-wrap gap-3">
                <button
                  type="button"
                  class="min-h-11 rounded-lg bg-bcl-accent px-4 py-2 text-sm font-semibold text-black disabled:opacity-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
                  [disabled]="busyId() === intake.id"
                  (click)="decide(intake.id, 'approve')"
                >{{ busyId() === intake.id ? 'Sending…' : 'Approve and send' }}</button>
                @if (intake.approval_status === 'pending_approval') {
                  <button
                    type="button"
                    class="min-h-11 rounded-lg border border-bcl-border px-4 py-2 text-sm font-semibold text-bcl-ink disabled:opacity-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
                    [disabled]="busyId() === intake.id"
                    (click)="decide(intake.id, 'reject')"
                  >Reject</button>
                }
              </div>
            }
          </li>
        }
      </ul>
    }
  `,
})
export class AdminPhotoQuotesComponent {
  private readonly http = inject(HttpClient);
  private readonly destroyRef = inject(DestroyRef);

  readonly intakes = signal<PhotoIntake[]>([]);
  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly busyId = signal<string | null>(null);

  constructor() {
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.error.set(null);
    this.http
      .get<{ ok: boolean; intakes: PhotoIntake[] }>('/api/photo-sms-intake/admin/recent')
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError(() => {
          this.error.set('Photo estimates could not be loaded. Nothing was changed.');
          return of({ ok: false, intakes: [] });
        }),
        finalize(() => this.loading.set(false)),
      )
      .subscribe((response) => {
        if (response.ok) this.intakes.set(response.intakes);
      });
  }

  decide(id: string, decision: 'approve' | 'reject'): void {
    this.busyId.set(id);
    this.error.set(null);
    this.http
      .post<{ ok: boolean; status: IntakeStatus }>(
        `/api/photo-sms-intake/admin/${encodeURIComponent(id)}/decision`,
        { decision },
      )
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError(() => {
          this.error.set(
            decision === 'approve'
              ? 'The estimate was not sent. You can retry approval safely.'
              : 'The estimate was not rejected. Please retry.',
          );
          return of({ ok: false, status: 'send_failed' as IntakeStatus });
        }),
        finalize(() => this.busyId.set(null)),
      )
      .subscribe((response) => {
        if (response.ok) this.load();
      });
  }

  maskedPhone(phone: string): string {
    return phone.length >= 4 ? `••• ••• ${phone.slice(-4)}` : 'Phone hidden';
  }

  serviceLabel(value: string): string {
    return value === 'unspecified'
      ? 'Unclassified job'
      : value.replaceAll('-', ' ').replace(/\b\w/g, (letter) => letter.toUpperCase());
  }

  statusLabel(status: IntakeStatus): string {
    return status.replaceAll('_', ' ');
  }

  band(intake: PhotoIntake): string {
    if (intake.estimated_min_cents == null || intake.estimated_max_cents == null) return '—';
    return `$${Math.round(intake.estimated_min_cents / 100)}–$${Math.round(intake.estimated_max_cents / 100)}`;
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'photo-quotes-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
