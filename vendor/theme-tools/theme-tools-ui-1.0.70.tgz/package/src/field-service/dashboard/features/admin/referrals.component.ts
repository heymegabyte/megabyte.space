import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * AdminReferralsComponent — referral-milestones console on the admin surface.
 * Angular port of the React admin referral surface. Live surface =
 * Angular /dashboard/admin (super-admin session).
 *
 * Verified by mount (`app.route('/api/admin/referrals', adminReferralMilestones)`,
 * auth migrated 2026-06-04 to `ownerOrSuperAdmin` so the session cookie works):
 *   GET  /api/admin/referrals/milestones        → { ok, milestones:[…] }
 *   POST /api/admin/referrals/award/:phone       { delta, reason } → { ok, milestone }
 *
 * Lists customers by referral count, surfaces who's unlocked a free move, and
 * lets the owner manually award a credit when a referral closes outside the
 * automated flow (audit-logged on the worker). Full 4-state, rolling-counter
 * summary strip, reason-capture award dialog (no window.prompt), dark cockpit.
 */
import { ChangeDetectionStrategy, Component, OnInit, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';
import { HlmButton, HlmInput, HlmSkeleton, HlmDialog, ToastService } from '../../shared/ui-spartan';
import { BclRollingCounterComponent } from '../_shared/rolling-counter.component';
import { BclRevealDirective } from '../../shared/reveal.directive';

export interface MilestoneRow {
  readonly customer_phone: string;
  readonly count: number;
  readonly last_reward_at: string | null;
  readonly total_rewarded_cents: number;
  readonly free_move_unlocked_at: string | null;
  readonly updated_at: string;
}

interface ListResponse {
  readonly ok: boolean;
  readonly milestones?: readonly MilestoneRow[];
}

/** Pure: phone → last-4 mask for the ops list. Unit-tested. */
export function maskPhone(phone: string): string {
  const digits = (phone || '').replace(/\D/g, '');
  return digits.length >= 4 ? `•••• ${digits.slice(-4)}` : '••••';
}

/** Pure: cents → "$N" (whole dollars). Unit-tested. */
export function dollarsFromCents(cents: number): string {
  return `$${Math.round((cents || 0) / 100).toLocaleString()}`;
}

/** Pure: whether this customer has unlocked a free move. Unit-tested. */
export function hasFreeMove(row: Pick<MilestoneRow, 'free_move_unlocked_at'>): boolean {
  return !!row.free_move_unlocked_at;
}

/** Pure: aggregate the milestone rows into the summary strip. Unit-tested. */
export function milestoneSummary(rows: readonly MilestoneRow[]): {
  tracked: number;
  totalRewardedDollars: number;
  freeMoveUnlocks: number;
} {
  let cents = 0;
  let unlocks = 0;
  for (const r of rows) {
    cents += r.total_rewarded_cents || 0;
    if (r.free_move_unlocked_at) unlocks += 1;
  }
  return {
    tracked: rows.length,
    totalRewardedDollars: Math.round(cents / 100),
    freeMoveUnlocks: unlocks,
  };
}

@Component({
  selector: 'app-admin-referrals',
  standalone: true,
  imports: [HlmButton, HlmInput, HlmSkeleton, HlmDialog, FormsModule, BclRollingCounterComponent, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="mb-4 flex flex-wrap items-start justify-between gap-3">
      <div>
        <h1 class="text-2xl font-bold text-foreground">Referral milestones</h1>
        <p class="text-sm text-muted-foreground">
          Top referrers + who's unlocked a free move. Award a credit when a referral closes off-flow.
        </p>
      </div>
      <button hlmBtn variant="secondary" size="sm" (click)="refresh()" [disabled]="loading()">Refresh</button>
    </header>

    @if (rows().length > 0) {
      <section
        bclReveal
        class="mb-4 grid grid-cols-1 gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-3"
        aria-label="Referral summary"
      >
        <div class="bg-card px-4 py-3">
          <p class="font-mono text-[11px] uppercase tracking-wider text-bcl-accent">Referrers tracked</p>
          <p class="bcl-tabular mt-1 text-2xl font-bold text-foreground">
            <bcl-rolling-counter [value]="summary().tracked" />
          </p>
        </div>
        <div class="bg-card px-4 py-3">
          <p class="font-mono text-[11px] uppercase tracking-wider text-bcl-success">Rewards paid</p>
          <p class="bcl-tabular mt-1 text-2xl font-bold text-foreground">
            <bcl-rolling-counter [value]="summary().totalRewardedDollars" prefix="$" />
          </p>
        </div>
        <div class="bg-card px-4 py-3">
          <p class="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">Free moves unlocked</p>
          <p class="bcl-tabular mt-1 text-2xl font-bold text-foreground">
            <bcl-rolling-counter [value]="summary().freeMoveUnlocks" />
          </p>
        </div>
      </section>
    }

    @if (error(); as e) {
      <div
        class="mb-4 flex items-center justify-between gap-3 rounded-xl border border-destructive/40 bg-destructive/5 px-4 py-3"
        role="alert"
      >
        <p class="text-sm text-foreground">Referrals — {{ e }}</p>
        <button hlmBtn variant="outline" size="sm" (click)="refresh()">Try again</button>
      </div>
    }

    @if (loading() && rows().length === 0) {
      <div class="space-y-2" aria-label="Loading referral milestones">
        <div hlmSkeleton class="h-14 w-full"></div>
        <div hlmSkeleton class="h-14 w-full"></div>
        <div hlmSkeleton class="h-14 w-full"></div>
      </div>
    } @else if (rows().length === 0 && !error()) {
      <div class="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
        No referral activity yet. Awards you grant here will show up in this ledger.
      </div>
    } @else {
      <ul class="space-y-2">
        @for (row of rows(); track row.customer_phone) {
          <li
            bclReveal
            class="flex flex-wrap items-center gap-3 rounded-lg border border-border bg-card/60 px-4 py-3"
          >
            <span class="bcl-tabular text-sm font-medium text-foreground">{{ mask(row.customer_phone) }}</span>
            <span
              class="rounded-full bg-background px-2 py-0.5 text-xs font-semibold text-bcl-accent ring-1 ring-border"
            >{{ row.count }} referral{{ row.count === 1 ? '' : 's' }}</span>
            @if (freeMove(row)) {
              <span class="rounded-full bg-bcl-success/10 px-2 py-0.5 text-xs font-semibold text-bcl-success ring-1 ring-bcl-success/30">
                Free move unlocked
              </span>
            }
            <span class="bcl-tabular ml-auto text-sm text-muted-foreground">{{ dollars(row.total_rewarded_cents) }} paid</span>
            <button
              hlmBtn
              variant="outline"
              size="sm"
              (click)="openAward(row.customer_phone)"
              [attr.data-testid]="'referral-award-' + row.customer_phone"
            >
              Award
            </button>
          </li>
        }
      </ul>
    }

    <!-- Manual award dialog (audit-logged credit, no window.prompt). -->
    <app-dialog [open]="!!awarding()" (openChange)="$event ? null : closeAward()" ariaLabel="Award referral credit">
      @if (awarding(); as phone) {
        <div class="flex flex-col gap-3">
          <div>
            <h2 class="text-lg font-bold text-foreground">Award referral credit</h2>
            <p class="text-sm text-muted-foreground">
              {{ mask(phone) }} — adds referrals + the tier reward. Audit-logged.
            </p>
          </div>
          <label class="text-sm text-foreground">
            Referrals to credit
            <input
              hlmInput
              type="number"
              min="1"
              max="20"
              class="mt-1 w-full"
              [(ngModel)]="deltaValue"
              aria-label="Referrals to credit"
              data-testid="referral-delta"
            />
          </label>
          <textarea
            hlmInput
            rows="2"
            [(ngModel)]="reasonValue"
            placeholder="Reason (e.g. friend mentioned at checkout)…"
            aria-label="Award reason"
            data-testid="referral-reason"
          ></textarea>
          <div class="flex justify-end gap-2">
            <button hlmBtn variant="outline" (click)="closeAward()">Cancel</button>
            <button
              hlmBtn
              [disabled]="deltaValue < 1 || busy() === phone"
              (click)="confirmAward()"
              data-testid="referral-award-confirm"
            >
              Award credit
            </button>
          </div>
        </div>
      }
    </app-dialog>
  `,
})
export class AdminReferralsComponent implements OnInit {
  private readonly http = inject(HttpClient);
  private readonly toast = inject(ToastService);

  readonly loading = signal(false);
  readonly rows = signal<readonly MilestoneRow[]>([]);
  readonly error = signal<string | null>(null);
  readonly busy = signal<string | null>(null);

  readonly awarding = signal<string | null>(null);
  deltaValue = 1;
  reasonValue = '';

  readonly summary = computed(() => milestoneSummary(this.rows()));

  ngOnInit(): void {
    void this.refresh();
  }

  mask(phone: string): string {
    return maskPhone(phone);
  }
  dollars(cents: number): string {
    return dollarsFromCents(cents);
  }
  freeMove(row: MilestoneRow): boolean {
    return hasFreeMove(row);
  }

  async refresh(): Promise<void> {
    this.loading.set(true);
    this.error.set(null);
    try {
      const r = await firstValueFrom(
        this.http.get<ListResponse>('/api/admin/referrals/milestones', { withCredentials: true }),
      );
      this.rows.set(r?.ok ? (r.milestones ?? []) : []);
    } catch (err) {
      this.error.set(`Failed to load milestones: ${(err as Error).message}`);
      this.rows.set([]);
    } finally {
      this.loading.set(false);
    }
  }

  openAward(phone: string): void {
    this.deltaValue = 1;
    this.reasonValue = '';
    this.awarding.set(phone);
  }
  closeAward(): void {
    this.awarding.set(null);
  }

  async confirmAward(): Promise<void> {
    const phone = this.awarding();
    if (!phone || this.deltaValue < 1) return;
    this.busy.set(phone);
    try {
      await firstValueFrom(
        this.http.post(
          `/api/admin/referrals/award/${encodeURIComponent(phone)}`,
          { delta: Math.min(20, Math.max(1, Math.round(this.deltaValue))), reason: this.reasonValue.trim() },
          { withCredentials: true },
        ),
      );
      this.toast.success(`Credited ${this.mask(phone)}`);
      this.closeAward();
      await this.refresh();
    } catch (err) {
      this.toast.error('Award failed', undefined, (err as Error).message);
    } finally {
      this.busy.set(null);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'referrals-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
