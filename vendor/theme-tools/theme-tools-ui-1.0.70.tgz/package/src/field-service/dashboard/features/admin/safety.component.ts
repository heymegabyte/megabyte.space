import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * AdminSafetyComponent — safety + compliance read panel on the admin console.
 * Angular port of the read surfaces of the React safety view. Live surface =
 * Angular /dashboard/admin (super-admin session).
 *
 * Verified by mount (`app.route('/api/admin/safety', safety)`, auth migrated
 * 2026-06-04 to `ownerOrSuperAdmin`):
 *   GET /api/admin/safety/wc-claims          → { ok, claims[] }
 *   GET /api/admin/safety/osha-certs/expiring?withinDays=60 → { ok, certs[] }
 *   GET /api/admin/safety/blocklist          → { ok, blocklist[] }
 *
 * READ-ONLY by design. The action endpoints (issue-COI, draft-WC-claim,
 * forgery-scan, sentiment-scan, bg-check renewal, block/unblock address) are
 * AI/document/mutation operations → operator-run, NOT wired here per "ship the
 * STATUS, gate the ACTION". Three sub-sections each with its own empty state,
 * rolling-counter summary strip, dark cockpit. Pure helpers unit-tested.
 */
import { ChangeDetectionStrategy, Component, OnInit, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { HlmButton, HlmSkeleton } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';
import { BclRollingCounterComponent } from '../_shared/rolling-counter.component';

export interface WcClaim {
  readonly id: string;
  readonly worker_id: string;
  readonly incident_id: string;
  readonly status: string;
  readonly carrier_ref: string | null;
  readonly submitted_at: string | null;
  readonly created_at: string;
}

export interface OshaCert {
  readonly id: string;
  readonly worker_id: string;
  readonly kind: string;
  readonly issued_at: string | null;
  readonly expires_at: string;
  readonly issuer: string | null;
  readonly verified_at: string | null;
}

export interface BlocklistEntry {
  readonly address_normalized: string;
  readonly reason: string;
  readonly added_at: string;
  readonly added_by: string;
  readonly notes: string | null;
}

/** Pure: whole days from now to an ISO date (negative = past). Unit-tested. */
export function daysUntil(iso: string, nowMs: number): number {
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return 0;
  return Math.round((t - nowMs) / 86_400_000);
}

/** Pure: cert expiry urgency bucket. Unit-tested. */
export function certUrgency(expiresAtIso: string, nowMs: number): 'expired' | 'soon' | 'upcoming' {
  const d = daysUntil(expiresAtIso, nowMs);
  if (d < 0) return 'expired';
  if (d <= 14) return 'soon';
  return 'upcoming';
}

/** Pure: chip classes for a cert urgency. Unit-tested. */
export function certUrgencyChip(urgency: 'expired' | 'soon' | 'upcoming'): string {
  switch (urgency) {
    case 'expired':
      return 'bg-destructive/10 text-destructive ring-destructive/30';
    case 'soon':
      return 'bg-bcl-warn/10 text-bcl-warn ring-bcl-warn/30';
    default:
      return 'bg-bcl-bg-elev text-bcl-ink-muted ring-bcl-border';
  }
}

/** Pure: chip classes for a WC-claim status. Unit-tested. */
export function wcStatusChip(status: string): string {
  switch (status) {
    case 'accepted':
    case 'closed':
      return 'bg-bcl-success/10 text-bcl-success ring-bcl-success/30';
    case 'submitted':
    case 'investigating':
      return 'bg-bcl-accent/10 text-bcl-accent ring-bcl-accent/30';
    case 'denied':
    case 'rejected':
      return 'bg-destructive/10 text-destructive ring-destructive/30';
    default: // draft / open / unknown
      return 'bg-bcl-warn/10 text-bcl-warn ring-bcl-warn/30';
  }
}

/** Pure: summary strip — open WC claims, certs expiring ≤14d, blocked addresses. Unit-tested. */
export function safetySummary(
  data: { claims: readonly WcClaim[]; certs: readonly OshaCert[]; blocklist: readonly BlocklistEntry[] },
  nowMs: number,
): { openClaims: number; certsExpiringSoon: number; blocked: number } {
  const openClaims = data.claims.filter((c) => c.status !== 'closed' && c.status !== 'denied').length;
  const certsExpiringSoon = data.certs.filter((c) => certUrgency(c.expires_at, nowMs) !== 'upcoming').length;
  return { openClaims, certsExpiringSoon, blocked: data.blocklist.length };
}

@Component({
  selector: 'app-admin-safety',
  standalone: true,
  imports: [HlmButton, HlmSkeleton, BclRevealDirective, BclRollingCounterComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="mb-4 flex flex-wrap items-start justify-between gap-3">
      <div>
        <h1 class="text-2xl font-bold text-foreground">Safety &amp; compliance</h1>
        <p class="text-sm text-muted-foreground">
          WC claims, expiring certifications, and the address blocklist. Actions are operator-run.
        </p>
      </div>
      <button hlmBtn variant="secondary" size="sm" (click)="refresh()" [disabled]="loading()">Refresh</button>
    </header>

    @if (loaded()) {
      <section
        bclReveal
        class="mb-5 grid grid-cols-1 gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-3"
        aria-label="Safety summary"
      >
        <div class="bg-card px-4 py-3">
          <p class="font-mono text-[11px] uppercase tracking-wider text-bcl-warn">Open WC claims</p>
          <p class="bcl-tabular mt-1 text-2xl font-bold text-foreground">
            <bcl-rolling-counter [value]="summary().openClaims" />
          </p>
        </div>
        <div class="bg-card px-4 py-3">
          <p class="font-mono text-[11px] uppercase tracking-wider text-destructive">Certs expiring ≤14d</p>
          <p class="bcl-tabular mt-1 text-2xl font-bold text-foreground">
            <bcl-rolling-counter [value]="summary().certsExpiringSoon" />
          </p>
        </div>
        <div class="bg-card px-4 py-3">
          <p class="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">Blocked addresses</p>
          <p class="bcl-tabular mt-1 text-2xl font-bold text-foreground">
            <bcl-rolling-counter [value]="summary().blocked" />
          </p>
        </div>
      </section>
    }

    @if (error(); as e) {
      <div
        class="mb-4 flex items-center justify-between gap-3 rounded-xl border border-destructive/40 bg-destructive/5 px-4 py-3"
        role="alert"
      >
        <p class="text-sm text-foreground">Safety panel — {{ e }}</p>
        <button hlmBtn variant="outline" size="sm" (click)="refresh()">Try again</button>
      </div>
    }

    @if (loading() && !loaded()) {
      <div class="space-y-3" aria-label="Loading safety panel">
        <div hlmSkeleton class="h-24 w-full"></div>
        <div hlmSkeleton class="h-24 w-full"></div>
      </div>
    } @else if (!error()) {
      <div class="grid gap-4 lg:grid-cols-2">
        <!-- Workers' comp claims -->
        <section bclReveal class="rounded-xl border border-border bg-card/60 p-4" aria-labelledby="wc-title">
          <h2 id="wc-title" class="mb-2 text-sm font-semibold text-foreground">Workers' comp claims</h2>
          @if (claims().length === 0) {
            <p class="text-sm text-muted-foreground">No WC claims on file.</p>
          } @else {
            <ul class="space-y-1.5">
              @for (cl of claims(); track cl.id) {
                <li class="flex items-center gap-2 text-sm">
                  <span class="bcl-tabular text-foreground">#{{ cl.id.slice(0, 8) }}</span>
                  <span class="rounded-full px-2 py-0.5 text-xs font-semibold ring-1" [class]="wcChip(cl.status)">{{ cl.status }}</span>
                  <span class="ml-auto truncate text-xs text-muted-foreground">{{ cl.carrier_ref || 'no carrier ref' }}</span>
                </li>
              }
            </ul>
          }
        </section>

        <!-- Expiring certifications -->
        <section bclReveal class="rounded-xl border border-border bg-card/60 p-4" aria-labelledby="cert-title">
          <h2 id="cert-title" class="mb-2 text-sm font-semibold text-foreground">Expiring certifications (≤60d)</h2>
          @if (certs().length === 0) {
            <p class="text-sm text-muted-foreground">No certifications expiring soon.</p>
          } @else {
            <ul class="space-y-1.5">
              @for (ct of certs(); track ct.id) {
                <li class="flex items-center gap-2 text-sm">
                  <span class="font-medium text-foreground">{{ ct.kind }}</span>
                  <span class="text-xs text-muted-foreground">{{ ct.worker_id.slice(0, 8) }}</span>
                  <span class="ml-auto rounded-full px-2 py-0.5 text-xs font-semibold ring-1" [class]="certChip(ct.expires_at)">
                    {{ expiryLabel(ct.expires_at) }}
                  </span>
                </li>
              }
            </ul>
          }
        </section>

        <!-- Address blocklist -->
        <section bclReveal class="rounded-xl border border-border bg-card/60 p-4 lg:col-span-2" aria-labelledby="block-title">
          <h2 id="block-title" class="mb-2 text-sm font-semibold text-foreground">Address blocklist</h2>
          @if (blocklist().length === 0) {
            <p class="text-sm text-muted-foreground">No blocked addresses.</p>
          } @else {
            <ul class="space-y-1.5">
              @for (b of blocklist(); track b.address_normalized) {
                <li class="flex items-center gap-2 text-sm">
                  <span class="truncate text-foreground">{{ b.address_normalized }}</span>
                  <span class="ml-auto truncate text-xs text-muted-foreground">{{ b.reason }}</span>
                </li>
              }
            </ul>
          }
        </section>
      </div>
    }
  `,
})
export class AdminSafetyComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly loading = signal(false);
  readonly loaded = signal(false);
  readonly error = signal<string | null>(null);
  readonly claims = signal<readonly WcClaim[]>([]);
  readonly certs = signal<readonly OshaCert[]>([]);
  readonly blocklist = signal<readonly BlocklistEntry[]>([]);

  readonly summary = computed(() =>
    safetySummary(
      { claims: this.claims(), certs: this.certs(), blocklist: this.blocklist() },
      Date.now(),
    ),
  );

  ngOnInit(): void {
    void this.refresh();
  }

  wcChip(status: string): string {
    return wcStatusChip(status);
  }
  certChip(iso: string): string {
    return certUrgencyChip(certUrgency(iso, Date.now()));
  }
  expiryLabel(iso: string): string {
    const d = daysUntil(iso, Date.now());
    if (d < 0) return `expired ${Math.abs(d)}d ago`;
    if (d === 0) return 'expires today';
    return `${d}d left`;
  }

  async refresh(): Promise<void> {
    this.loading.set(true);
    this.error.set(null);
    try {
      const opts = { withCredentials: true } as const;
      const [wc, certs, block] = await Promise.all([
        firstValueFrom(this.http.get<{ ok: boolean; claims?: WcClaim[] }>('/api/admin/safety/wc-claims', opts)),
        firstValueFrom(
          this.http.get<{ ok: boolean; certs?: OshaCert[] }>('/api/admin/safety/osha-certs/expiring?withinDays=60', opts),
        ),
        firstValueFrom(this.http.get<{ ok: boolean; blocklist?: BlocklistEntry[] }>('/api/admin/safety/blocklist', opts)),
      ]);
      this.claims.set(wc?.claims ?? []);
      this.certs.set(certs?.certs ?? []);
      this.blocklist.set(block?.blocklist ?? []);
      this.loaded.set(true);
    } catch (err) {
      this.error.set(`Failed to load: ${(err as Error).message}`);
    } finally {
      this.loading.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'safety-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
