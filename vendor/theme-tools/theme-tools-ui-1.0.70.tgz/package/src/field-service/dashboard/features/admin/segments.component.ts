import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * SegmentsComponent — customer-segment builder at /admin/segments.
 *
 * Surfaces the last operator write-action (previously React-admin-only):
 *   • build a segment from allowlisted rule rows (field/op/value) → POST
 *     /api/admin/widgets/segment/save
 *   • list saved segments → run a bulk action (SMS blast / email export /
 *     tag apply) → POST /api/admin/widgets/bulk-action
 * Auth: adminWidgets middleware accepts the super-admin session (pass 21).
 */
import { ChangeDetectionStrategy, Component, type OnInit, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HlmCardImports, StateBlockComponent, type SurfaceState } from '../../shared/ui-spartan';

const FIELDS = ['city', 'zip', 'status', 'source', 'total_cents', 'created_at'] as const;
const OPS = ['eq', 'ne', 'gt', 'gte', 'lt', 'lte', 'contains'] as const;
const OP_LABEL: Record<(typeof OPS)[number], string> = {
  eq: '=', ne: '≠', gt: '>', gte: '≥', lt: '<', lte: '≤', contains: 'contains',
};
const BULK = [
  { action: 'sms_blast', label: 'SMS blast', needs: 'message' },
  { action: 'email_export', label: 'Email export', needs: '' },
  { action: 'tag_apply', label: 'Apply tag', needs: 'tag' },
] as const;

interface Rule {
  field: (typeof FIELDS)[number];
  op: (typeof OPS)[number];
  value: string;
}
interface Segment {
  readonly id: string;
  readonly name: string;
  readonly query: string;
  readonly created_at?: string;
}

@Component({
  selector: 'app-admin-segments',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [...HlmCardImports, StateBlockComponent],
  template: `
    <header class="mb-4">
      <h1 class="text-2xl font-bold text-foreground">Customer segments</h1>
      <p class="text-sm text-muted-foreground">
        Build a segment from rules, then run a bulk action on it.
      </p>
    </header>

    <div hlmCard class="mb-4 p-4">
      <label class="block">
        <span class="text-xs text-muted-foreground">Segment name</span>
        <input
          type="text"
          class="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground"
          placeholder="Newark high-value lapsed"
          [value]="name()"
          (input)="name.set($any($event.target).value)"
        />
      </label>

      <div class="mt-3 space-y-2">
        @for (r of rules(); track $index) {
          <div class="flex flex-wrap items-center gap-2">
            <select
              class="rounded-md border border-input bg-background px-2 py-1.5 text-sm text-foreground"
              [value]="r.field"
              (change)="setRule($index, 'field', $any($event.target).value)"
            >
              @for (f of fields; track f) { <option [value]="f">{{ f }}</option> }
            </select>
            <select
              class="rounded-md border border-input bg-background px-2 py-1.5 text-sm text-foreground"
              [value]="r.op"
              (change)="setRule($index, 'op', $any($event.target).value)"
            >
              @for (o of ops; track o) { <option [value]="o">{{ opLabel(o) }}</option> }
            </select>
            <input
              type="text"
              class="flex-1 rounded-md border border-input bg-background px-2 py-1.5 text-sm text-foreground"
              placeholder="value"
              [value]="r.value"
              (input)="setRule($index, 'value', $any($event.target).value)"
            />
            <button
              type="button"
              class="rounded-md border border-border px-2 py-1.5 text-xs text-muted-foreground hover:text-destructive focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
              (click)="removeRule($index)"
              [disabled]="rules().length <= 1"
              aria-label="Remove rule"
            >
              ✕
            </button>
          </div>
        }
      </div>

      <div class="mt-3 flex items-center justify-between">
        <button type="button" class="text-sm text-primary hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring" (click)="addRule()">
          + Add rule
        </button>
        <button
          type="button"
          class="rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
          [disabled]="busy() || !canSave()"
          (click)="save()"
        >
          {{ busy() ? 'Saving…' : 'Save segment' }}
        </button>
      </div>
      @if (msg(); as m) {
        <p class="mt-2 text-xs" [class.text-destructive]="m.startsWith('!')" [class.text-emerald-400]="!m.startsWith('!')">
          {{ m.startsWith('!') ? m.slice(1) : m }}
        </p>
      }
    </div>

    <h2 class="mb-2 font-mono text-xs uppercase tracking-wider text-primary">Saved segments</h2>
    <app-state-block
      [state]="listState()"
      emptyTitle="No segments yet."
      emptyHint="Build a segment above and save it to run bulk actions."
      errorTitle="Couldn't load saved segments"
      [errorDetail]="loadError() ?? ''"
      (retry)="refresh()"
    >
      <div class="grid gap-3">
        @for (s of segments(); track s.id) {
          <div hlmCard class="p-4">
            <div class="flex items-center justify-between gap-2">
              <span class="text-sm font-semibold text-foreground">{{ s.name }}</span>
              <span class="font-mono text-[11px] text-muted-foreground">{{ ruleSummary(s.query) }}</span>
            </div>
            <div class="mt-3 flex flex-wrap gap-2">
              @for (b of bulk; track b.action) {
                <button
                  type="button"
                  class="rounded-md border border-border px-3 py-1.5 text-xs text-primary hover:bg-primary/10 disabled:opacity-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                  [disabled]="bulkBusy() === s.id + b.action"
                  (click)="runBulk(s, b.action, b.needs)"
                >
                  {{ bulkBusy() === s.id + b.action ? '…' : b.label }}
                </button>
              }
            </div>
            @if (bulkMsg()[s.id]; as bm) {
              <p class="mt-1 text-xs text-emerald-400">{{ bm }}</p>
            }
          </div>
        }
      </div>
    </app-state-block>
  `,
})
export class SegmentsComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly fields = FIELDS;
  readonly ops = OPS;
  readonly bulk = BULK;

  readonly name = signal<string>('');
  readonly rules = signal<Rule[]>([{ field: 'city', op: 'eq', value: '' }]);
  readonly segments = signal<readonly Segment[]>([]);
  readonly segmentsLoading = signal<boolean>(true);
  readonly loadError = signal<string | null>(null);
  readonly busy = signal<boolean>(false);
  readonly msg = signal<string | null>(null);
  readonly bulkBusy = signal<string | null>(null);
  readonly bulkMsg = signal<Record<string, string>>({});

  /** 4-state machine for the saved-segments list (loading → error → empty → ready). */
  readonly listState = computed<SurfaceState>(() => {
    if (this.segmentsLoading()) return 'loading';
    if (this.loadError()) return 'error';
    return this.segments().length === 0 ? 'empty' : 'ready';
  });

  opLabel(o: (typeof OPS)[number]): string {
    return OP_LABEL[o];
  }
  canSave(): boolean {
    return this.name().trim().length > 0 && this.rules().every((r) => r.value.trim().length > 0);
  }
  ruleSummary(query: string): string {
    try {
      const arr = JSON.parse(query) as Rule[];
      return arr.map((r) => `${r.field} ${OP_LABEL[r.op] ?? r.op} ${r.value}`).join(' · ');
    } catch {
      return '—';
    }
  }

  ngOnInit(): void {
    void this.refresh();
  }

  /**
   * (Re)load the saved segments. A FAILED fetch now sets `loadError` → the list
   * renders a distinct error + retry (via <app-state-block>) instead of the
   * "No segments yet." empty state, which is reserved for a genuine empty result.
   * `segmentsLoading` gates a skeleton so the empty text never flashes pre-fetch.
   */
  async refresh(): Promise<void> {
    this.segmentsLoading.set(true);
    this.loadError.set(null);
    const r = await firstValueFrom(
      this.http
        .get<{ ok?: boolean; segments?: Segment[] }>('/api/admin/widgets/segments', { withCredentials: true })
        .pipe(catchError(() => of({ ok: false } as { ok?: boolean; segments?: Segment[] }))),
    );
    this.segmentsLoading.set(false);
    if (r.ok && Array.isArray(r.segments)) {
      this.segments.set(r.segments);
    } else {
      this.loadError.set("We couldn't load your saved segments. Try again.");
    }
  }

  addRule(): void {
    this.rules.update((rs) => [...rs, { field: 'city', op: 'eq', value: '' }]);
  }
  removeRule(i: number): void {
    this.rules.update((rs) => rs.filter((_, idx) => idx !== i));
  }
  setRule(i: number, key: keyof Rule, value: string): void {
    this.rules.update((rs) => rs.map((r, idx) => (idx === i ? { ...r, [key]: value } : r)));
  }

  async save(): Promise<void> {
    if (!this.canSave()) return;
    this.busy.set(true);
    this.msg.set(null);
    const r = await firstValueFrom(
      this.http
        .post<{ ok?: boolean; error?: string }>(
          '/api/admin/widgets/segment/save',
          { name: this.name().trim(), query: this.rules() },
          { withCredentials: true },
        )
        .pipe(catchError((e) => of({ ok: false, error: e?.error?.error ?? 'Save failed' }))),
    );
    this.busy.set(false);
    if (r.ok === false) {
      this.msg.set(`!${r.error ?? 'Save failed'}`);
      return;
    }
    this.msg.set('Segment saved.');
    this.name.set('');
    this.rules.set([{ field: 'city', op: 'eq', value: '' }]);
    await this.refresh();
  }

  async runBulk(s: Segment, action: string, needs: string): Promise<void> {
    let payload = '';
    if (needs) {
      payload = (globalThis.prompt(`${needs} for "${s.name}":`) || '').trim();
      if (!payload) return;
    }
    this.bulkBusy.set(s.id + action);
    const r = await firstValueFrom(
      this.http
        .post<{ ok?: boolean; error?: string; queued?: number }>(
          '/api/admin/widgets/bulk-action',
          { segment_id: s.id, action, ...(payload ? { payload } : {}) },
          { withCredentials: true },
        )
        .pipe(catchError((e) => of({ ok: false, error: e?.error?.error ?? 'Failed' }))),
    );
    this.bulkBusy.set(null);
    const text = r.ok === false ? `Failed: ${r.error ?? ''}` : 'Queued.';
    this.bulkMsg.update((m) => ({ ...m, [s.id]: text }));
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'segments-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
