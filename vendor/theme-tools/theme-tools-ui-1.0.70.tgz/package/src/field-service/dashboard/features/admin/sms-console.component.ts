import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * SmsConsoleComponent — Admin SMS console on the admin console.
 * Live surface = Angular /dashboard/admin/sms.
 *
 * SCAN-11: wires the previously-DEAD `workers/main/src/routes/admin-sms.ts`
 * (mounted this fire at /api/admin/sms, now `ownerOrSuperAdmin`-gated) into a
 * reachable operator surface:
 *   GET  /api/admin/sms/templates → { ok, templates:[{id,label,body,bytes}] }
 *   GET  /api/admin/sms/gate      → { ok, liveSendArmed, reason }
 *   POST /api/admin/sms/quarterly-nudge { template, dryRun } → dry-run preview
 *        (recipientCount + MASKED sampleRecipients) OR 423 when live-send locked
 *   GET  /api/admin/sms/recent    → { ok, scheduled:[…] } (masked phones)
 *
 * SAFETY: real marketing outreach (TCPA) is Brian-gated. The live-send control is
 * DISABLED unless the worker reports `liveSendArmed` (the SMS_QUARTERLY_LIVE_SEND
 * env killswitch). Dry-run + templates + recent are always usable — the console is
 * a genuine, non-dead-end observability + preview surface without arming outreach.
 *
 * Pure helpers (statusTone/formatTs) unit-tested.
 */
import { ChangeDetectionStrategy, Component, OnInit, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import {
  HlmCardImports,
  HlmButton,
  HlmBadge,
  StateBlockComponent,
  type SurfaceState,
} from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';
import { A11yModule } from '@angular/cdk/a11y';
import { focusRadioAtIndex, nextRadioIndex, rovingTabIndex } from '@theme.tools/i18n-a11y/field-service/radio-keynav';

export interface SmsTemplate {
  /** Server field is `id` (spring|summer|fall|winter) — see services/sms-templates.ts. */
  readonly id: string;
  readonly label: string;
  readonly body: string;
  readonly bytes: number;
}

export interface DryRunSample {
  readonly phone: string;
  readonly name: string | null;
  readonly lastBooked: string;
}

export interface DryRunResult {
  readonly ok: boolean;
  readonly dryRun: boolean;
  readonly template: string;
  readonly body: string;
  readonly bytes: number;
  readonly recipientCount: number;
  readonly sampleRecipients: readonly DryRunSample[];
}

export interface RecentSend {
  readonly id: string;
  readonly kind: string;
  readonly status: string;
  readonly send_after: string;
  readonly sent_at: string | null;
  readonly skip_reason: string | null;
  readonly to_phone: string;
  readonly booking_id: string | null;
  readonly gig_id: string | null;
}

/** Pure: tone band for a scheduled-SMS status. */
export function statusTone(status: string): 'default' | 'secondary' | 'destructive' {
  const s = (status ?? '').toLowerCase();
  if (s === 'sent' || s === 'delivered') return 'default';
  if (s === 'failed' || s === 'error') return 'destructive';
  return 'secondary'; // sending / pending / skipped
}

/** Pure: short human timestamp; echoes the raw string when unparseable. */
export function formatTs(iso: string | null): string {
  if (!iso) return '—';
  const t = Date.parse(iso);
  return Number.isNaN(t)
    ? iso
    : new Date(t).toLocaleString(undefined, {
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
      });
}

interface TemplatesResponse {
  readonly ok: boolean;
  readonly templates?: readonly SmsTemplate[];
}
interface GateResponse {
  readonly ok: boolean;
  readonly liveSendArmed: boolean;
  readonly reason: string;
}
interface RecentResponse {
  readonly ok: boolean;
  readonly scheduled?: readonly RecentSend[];
}

@Component({
  selector: 'app-admin-sms-console',
  standalone: true,
  imports: [...HlmCardImports, HlmButton, HlmBadge, StateBlockComponent, BclRevealDirective, A11yModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div hlmCard bclReveal data-testid="admin-sms-console">
      <div hlmCardHeader>
        <h3 hlmCardTitle>SMS console</h3>
        <p hlmCardDescription>
          Preview + send the quarterly re-engagement nudge to opted-in past customers, and review
          recent transactional sends. Live marketing sends are gated for safety.
        </p>
      </div>

      <div hlmCardContent class="flex flex-col gap-6">
        <app-state-block
          [state]="state()"
          [emptyTitle]="'No templates available'"
          [errorTitle]="'Could not load the SMS console'"
          [errorDetail]="error()"
          (retry)="reload()"
        >
          <!-- ready -->
          <div class="flex flex-col gap-6">
            <!-- Template picker -->
            <fieldset class="flex flex-col gap-2">
              <legend class="mb-1 text-sm font-semibold text-bcl-ink">Seasonal template</legend>
              <div
                class="grid gap-2 sm:grid-cols-2"
                role="radiogroup"
                aria-label="Seasonal template"
                (keydown)="onTemplateKey($event)"
              >
                @for (t of templates(); track t.id; let i = $index) {
                  <button
                    type="button"
                    role="radio"
                    [attr.tabindex]="roveTemplate(i)"
                    [attr.aria-checked]="selected() === t.id"
                    (click)="select(t.id)"
                    data-testid="sms-template-option"
                    class="flex flex-col items-start gap-1 rounded-lg border px-3 py-2 text-left text-sm transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                    [class.border-bcl-accent]="selected() === t.id"
                    [class.bg-bcl-accent\\/10]="selected() === t.id"
                    [class.border-bcl-border]="selected() !== t.id"
                  >
                    <span class="font-semibold capitalize text-bcl-ink">{{ t.label || t.id }}</span>
                    <span class="text-xs text-bcl-ink-muted">{{ t.body }}</span>
                    <span class="font-mono text-[11px] text-bcl-ink-muted">{{ t.bytes }} bytes</span>
                  </button>
                }
              </div>
            </fieldset>

            <!-- Actions -->
            <div class="flex flex-wrap items-center gap-3">
              <button
                hlmBtn
                type="button"
                (click)="dryRun()"
                [disabled]="busy() || !selected()"
                data-testid="sms-dry-run"
              >
                <span class="inline-block min-w-[9ch] text-center">{{
                  busy() ? 'Previewing…' : 'Preview recipients'
                }}</span>
              </button>

              <button
                hlmBtn
                type="button"
                variant="destructive"
                [disabled]="!liveArmed() || busy() || !selected()"
                (click)="requestLiveSend()"
                data-testid="sms-live-send"
                [attr.title]="gateReason()"
              >
                <span class="inline-block min-w-[9ch] text-center">Send live</span>
              </button>

              @if (!liveArmed()) {
                <span
                  class="inline-flex items-center gap-1 rounded-full bg-bcl-bg-elev/60 px-2.5 py-1 text-[11px] font-mono uppercase tracking-wider text-bcl-ink-muted"
                  data-testid="sms-live-gate-note"
                >
                  Live send locked
                </span>
              }
            </div>

            <!-- Destructive-safety: a real mass SMS never fires on a single click. The
                 "Send live" button opens this confirm-the-blast-radius alertdialog (focus-
                 trapped + Esc-dismissable) showing the dry-run recipient count. -->
            @if (confirmingSend()) {
              <div
                class="mt-1 rounded-lg border border-destructive/50 bg-destructive/10 p-4"
                role="alertdialog"
                aria-label="Confirm live SMS send"
                data-testid="sms-live-confirm"
                cdkTrapFocus
                [cdkTrapFocusAutoCapture]="true"
                (keydown.escape)="cancelSend()"
              >
                <p class="text-sm font-semibold text-bcl-ink">
                  @if (preview(); as p) {
                    Send this SMS to {{ p.recipientCount }} customer{{
                      p.recipientCount === 1 ? '' : 's'
                    }}?
                  } @else {
                    Send this SMS live to all matching customers?
                  }
                </p>
                <p class="mt-1 text-xs text-bcl-ink-muted">
                  Real text messages — this cannot be undone. Preview recipients first to see the
                  exact count.
                </p>
                <div class="mt-3 flex flex-wrap gap-3">
                  <button
                    hlmBtn
                    type="button"
                    variant="destructive"
                    [disabled]="busy()"
                    (click)="confirmSend()"
                    data-testid="sms-live-confirm-send"
                  >
                    <span class="inline-block min-w-[9ch] text-center">{{
                      busy() ? 'Sending…' : 'Yes, send live'
                    }}</span>
                  </button>
                  <button
                    hlmBtn
                    type="button"
                    variant="outline"
                    (click)="cancelSend()"
                    data-testid="sms-live-confirm-cancel"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            }
            @if (gateReason()) {
              <p class="-mt-3 text-xs text-bcl-ink-muted">{{ gateReason() }}</p>
            }

            <!-- Dry-run preview -->
            @if (preview(); as p) {
              <div
                class="rounded-lg border border-bcl-border bg-bcl-bg-elev/40 p-4"
                data-testid="sms-dry-run-result"
                aria-live="polite"
              >
                <p class="text-sm font-semibold text-bcl-ink">
                  {{ p.recipientCount }} recipient{{ p.recipientCount === 1 ? '' : 's' }} match
                  <span class="font-normal text-bcl-ink-muted">({{ p.bytes }} bytes / message)</span>
                </p>
                <p class="mt-2 whitespace-pre-wrap text-sm text-bcl-ink">{{ p.body }}</p>
                @if (p.sampleRecipients.length > 0) {
                  <ul class="mt-3 grid gap-1">
                    @for (r of p.sampleRecipients; track r.phone) {
                      <li class="font-mono text-xs text-bcl-ink-muted">
                        {{ r.phone }} · {{ r.name || 'customer' }} · last booked {{ r.lastBooked }}
                      </li>
                    }
                  </ul>
                } @else {
                  <p class="mt-2 text-xs text-bcl-ink-muted">
                    No opted-in customers are idle a full quarter right now — nothing would send.
                  </p>
                }
              </div>
            }

            <!-- Recent sends -->
            <div class="flex flex-col gap-2">
              <h4 class="text-sm font-semibold text-bcl-ink">Recent sends</h4>
              @if (recent().length === 0) {
                <p class="text-xs text-bcl-ink-muted">No recent scheduled SMS.</p>
              } @else {
                <ul class="grid gap-1.5">
                  @for (s of recent(); track s.id) {
                    <li
                      class="flex items-center justify-between gap-2 rounded-md border border-bcl-border bg-bcl-bg-elev/40 px-3 py-2 text-sm"
                    >
                      <span class="min-w-0">
                        <span class="font-mono text-xs text-bcl-ink">{{ s.to_phone }}</span>
                        <span class="ml-2 text-xs text-bcl-ink-muted">{{ s.kind }}</span>
                      </span>
                      <span class="flex items-center gap-2">
                        <span class="text-[11px] text-bcl-ink-muted">{{
                          when(s.sent_at ?? s.send_after)
                        }}</span>
                        <span hlmBadge [variant]="tone(s.status)" class="capitalize">{{
                          s.status
                        }}</span>
                      </span>
                    </li>
                  }
                </ul>
              }
            </div>
          </div>
        </app-state-block>
      </div>
    </div>
  `,
})
export class SmsConsoleComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly templates = signal<readonly SmsTemplate[]>([]);
  readonly recent = signal<readonly RecentSend[]>([]);
  readonly selected = signal<string>('');
  readonly preview = signal<DryRunResult | null>(null);
  readonly liveArmed = signal(false);
  readonly gateReason = signal<string>('');
  readonly state = signal<SurfaceState>('loading');
  readonly error = signal<string>('');
  readonly busy = signal(false);
  /** Confirm-the-blast-radius gate: the live-send button opens this, never fires directly. */
  readonly confirmingSend = signal(false);

  readonly tone = statusTone;
  readonly when = formatTs;

  ngOnInit(): void {
    void this.reload();
  }

  select(key: string): void {
    this.selected.set(key);
    this.preview.set(null);
  }

  /** Index of the selected template (0 when none) — the radiogroup's single tab stop. */
  private readonly activeTemplateIndex = computed(() => {
    const sel = this.selected();
    const i = this.templates().findIndex((t) => t.id === sel);
    return i < 0 ? 0 : i;
  });

  /** Roving tabindex for the template option at `i`: 0 for the active option, else -1. */
  roveTemplate(i: number): 0 | -1 {
    return rovingTabIndex(i, this.activeTemplateIndex());
  }

  /** ARIA radio-group arrow/Home/End keyboard nav across the seasonal templates. */
  onTemplateKey(event: KeyboardEvent): void {
    const tpls = this.templates();
    const next = nextRadioIndex(this.activeTemplateIndex(), tpls.length, event.key);
    if (next === null) return;
    event.preventDefault();
    const t = tpls[next];
    if (t === undefined) return;
    this.select(t.id);
    focusRadioAtIndex(event.currentTarget as HTMLElement, next);
  }

  async reload(): Promise<void> {
    this.state.set('loading');
    this.error.set('');
    try {
      const [tpl, gate, recent] = await Promise.all([
        firstValueFrom(
          this.http.get<TemplatesResponse>('/api/admin/sms/templates', { withCredentials: true }),
        ),
        firstValueFrom(
          this.http.get<GateResponse>('/api/admin/sms/gate', { withCredentials: true }),
        ),
        firstValueFrom(
          this.http.get<RecentResponse>('/api/admin/sms/recent', { withCredentials: true }),
        ),
      ]);
      const templates = tpl?.ok ? (tpl.templates ?? []) : [];
      this.templates.set(templates);
      this.liveArmed.set(gate?.ok ? gate.liveSendArmed : false);
      this.gateReason.set(gate?.reason ?? '');
      this.recent.set(recent?.ok ? (recent.scheduled ?? []) : []);
      const first = templates[0];
      if (first && !this.selected()) this.selected.set(first.id);
      this.state.set(templates.length === 0 ? 'empty' : 'ready');
    } catch (err) {
      const status = (err as { status?: number }).status;
      this.error.set(
        status === 401 || status === 403
          ? 'Sign in as an operator to use the SMS console.'
          : `Failed to load (HTTP ${status ?? '?'}). Try again.`,
      );
      this.state.set('error');
    }
  }

  async dryRun(): Promise<void> {
    const template = this.selected();
    if (!template || this.busy()) return;
    this.busy.set(true);
    try {
      const r = await firstValueFrom(
        this.http.post<DryRunResult>(
          '/api/admin/sms/quarterly-nudge',
          { template, dryRun: true },
          { withCredentials: true },
        ),
      );
      this.preview.set(r);
    } catch {
      this.preview.set(null);
      this.error.set('Preview failed — try again.');
      this.state.set('error');
    } finally {
      this.busy.set(false);
    }
  }

  /**
   * Open the confirm-the-blast-radius dialog. The destructive "Send live" button
   * routes HERE, never to {@link liveSend} directly — a single misclick must never
   * fire a real mass SMS. The dialog surfaces the dry-run recipient count.
   */
  requestLiveSend(): void {
    if (!this.liveArmed() || !this.selected() || this.busy()) return;
    this.confirmingSend.set(true);
  }

  /** Dismiss the confirm dialog without sending. */
  cancelSend(): void {
    this.confirmingSend.set(false);
  }

  /** The dialog's explicit confirmation → fire the real live send. */
  async confirmSend(): Promise<void> {
    this.confirmingSend.set(false);
    await this.liveSend();
  }

  async liveSend(): Promise<void> {
    // Defence in depth: the worker refuses (423) unless SMS_QUARTERLY_LIVE_SEND is
    // armed, and the button is disabled while `liveArmed()` is false. This guard is
    // the third layer so a programmatic click can never bypass the gate.
    if (!this.liveArmed() || !this.selected() || this.busy()) return;
    this.busy.set(true);
    try {
      await firstValueFrom(
        this.http.post(
          '/api/admin/sms/quarterly-nudge',
          { template: this.selected(), dryRun: false },
          { withCredentials: true },
        ),
      );
      await this.reload();
    } catch {
      this.error.set('Live send was refused — the safety gate may be locked.');
      this.state.set('error');
    } finally {
      this.busy.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'sms-console-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
