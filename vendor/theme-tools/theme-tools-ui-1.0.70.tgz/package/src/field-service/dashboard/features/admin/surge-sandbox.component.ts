import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
/**
 * SurgeSandboxComponent — interactive surge what-if at /admin/surge-sandbox.
 *
 * Surfaces the operator surge-sandbox (POST /api/admin/widgets/surge-sandbox,
 * previously React-admin-only): pick a date/time/ZIP + a crew-supply level and
 * preview the exact surge multiplier the booking flow would apply, with the
 * per-factor breakdown. Auth: the adminWidgets middleware accepts the super-
 * admin session (migrated pass 21), so this carries `withCredentials`.
 */
import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HlmCardImports } from '../../shared/ui-spartan';

interface SurgeReason {
  readonly kind: string;
  readonly factor: number;
  readonly label: string;
  readonly detail: string;
}
interface SurgeResult {
  readonly multiplier: number;
  readonly reasons: readonly SurgeReason[];
}
interface SandboxResponse {
  readonly ok: boolean;
  readonly result?: SurgeResult;
  readonly error?: string;
}

@Component({
  selector: 'app-admin-surge-sandbox',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [...HlmCardImports, FormsModule],
  template: `
    <header class="mb-4">
      <h1 class="text-2xl font-bold text-foreground">Surge sandbox</h1>
      <p class="text-sm text-muted-foreground">
        Preview the exact surge multiplier the booking flow would apply for a hypothetical job.
      </p>
    </header>

    <div hlmCard class="mb-4 grid gap-4 p-4 sm:grid-cols-2">
      <label class="block">
        <span class="text-xs text-muted-foreground">Date</span>
        <input
          type="date"
          class="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground"
          [(ngModel)]="date"
        />
      </label>
      <label class="block">
        <span class="text-xs text-muted-foreground">Time</span>
        <input
          type="time"
          class="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground"
          [(ngModel)]="time"
        />
      </label>
      <label class="block">
        <span class="text-xs text-muted-foreground">ZIP (optional)</span>
        <input
          type="text"
          inputmode="numeric"
          maxlength="5"
          placeholder="07102"
          class="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground"
          [(ngModel)]="zip"
        />
      </label>
      <label class="block">
        <span class="text-xs text-muted-foreground">Crew supply — {{ supplyPct() }}% available</span>
        <input
          type="range"
          min="0"
          max="1"
          step="0.05"
          class="mt-3 w-full accent-primary"
          [(ngModel)]="supply"
        />
      </label>
      <div class="sm:col-span-2 flex justify-end">
        <button
          type="button"
          class="rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
          [disabled]="busy()"
          (click)="compute()"
        >
          {{ busy() ? 'Computing…' : 'Preview surge' }}
        </button>
      </div>
    </div>

    @if (error(); as e) {
      <div hlmCard class="mb-4 p-4"><p class="text-sm text-destructive">{{ e }}</p></div>
    }

    @if (result(); as r) {
      <div hlmCard class="p-4">
        <div class="flex items-baseline gap-2">
          <span class="font-mono text-3xl font-bold tabular-nums text-foreground">{{ r.multiplier.toFixed(2) }}×</span>
          <span class="text-sm text-muted-foreground">
            {{ r.multiplier > 1 ? '+' + pct(r.multiplier) + '% surge' : 'no surge' }}
          </span>
        </div>
        @if (r.reasons.length > 0) {
          <ul class="mt-4 grid gap-2">
            @for (reason of r.reasons; track reason.kind) {
              <li class="flex items-start justify-between gap-3 rounded-md border border-border/50 p-2.5">
                <div>
                  <div class="text-sm font-semibold text-foreground">{{ reason.label }}</div>
                  <div class="text-xs text-muted-foreground">{{ reason.detail }}</div>
                </div>
                <span class="shrink-0 rounded-full bg-primary/15 px-2 py-0.5 font-mono text-xs text-primary">
                  ×{{ reason.factor.toFixed(2) }}
                </span>
              </li>
            }
          </ul>
        } @else {
          <p class="mt-3 text-sm text-muted-foreground">Base rate — none of the surge factors apply.</p>
        }
      </div>
    }
  `,
})
export class SurgeSandboxComponent {
  private readonly http = inject(HttpClient);

  readonly date = signal<string>('');
  readonly time = signal<string>('');
  readonly zip = signal<string>('');
  readonly supply = signal<number>(1);
  readonly result = signal<SurgeResult | null>(null);
  readonly busy = signal<boolean>(false);
  readonly error = signal<string | null>(null);

  supplyPct(): number {
    return Math.round(this.supply() * 100);
  }
  pct(mult: number): number {
    return Math.round((mult - 1) * 100);
  }

  async compute(): Promise<void> {
    this.busy.set(true);
    this.error.set(null);
    const body: Record<string, unknown> = { supply: Number(this.supply()) };
    if (this.date()) body['preferredDate'] = this.date();
    if (this.time()) body['preferredTime'] = this.time();
    if (this.zip()) body['zip'] = this.zip();
    const r = await firstValueFrom(
      this.http
        .post<SandboxResponse>('/api/admin/widgets/surge-sandbox', body, { withCredentials: true })
        .pipe(catchError(() => of({ ok: false, error: 'Compute failed' } as SandboxResponse))),
    );
    this.busy.set(false);
    if (r.ok && r.result) this.result.set(r.result);
    else this.error.set(r.error ?? 'Compute failed');
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'surge-sandbox-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
