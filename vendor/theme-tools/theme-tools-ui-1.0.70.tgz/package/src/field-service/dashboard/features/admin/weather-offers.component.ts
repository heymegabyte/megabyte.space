import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { CommonModule } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

interface WeatherOffer {
  id: string;
  bookingId: string;
  reason: string;
  proposedNewAt: string;
  noticeSentAt: string | null;
  opsEscalatedAt: string | null;
  forecastSummary: { notes?: string[] };
}

@Component({
  selector: 'bcl-weather-offers',
  standalone: true,
  imports: [CommonModule],
  template: `
    <main class="mx-auto max-w-5xl space-y-6 p-4 sm:p-6">
      <header><p class="text-sm text-muted-foreground">Scheduling</p><h1 class="text-2xl font-bold">Weather reschedule offers</h1></header>
      @if (loading()) { <p role="status">Loading weather offers…</p> }
      @else if (error()) {
        <div role="alert" class="rounded-lg border border-destructive/40 p-4">
          <p>Weather offers are temporarily unavailable.</p>
          <button class="mt-3 min-h-11 rounded-md border px-4 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring" (click)="load()">Try again</button>
        </div>
      } @else {
        <section aria-labelledby="pending-weather"><h2 id="pending-weather" class="text-lg font-semibold">Waiting for customer</h2>
          @if (pending().length === 0) { <p class="mt-2 rounded-lg border p-4">No customers are waiting on a weather choice.</p> }
          <div class="mt-3 space-y-3">@for (offer of pending(); track offer.id) { <ng-container [ngTemplateOutlet]="card" [ngTemplateOutletContext]="{ $implicit: offer }" /> }</div>
        </section>
        <section aria-labelledby="digest-weather"><h2 id="digest-weather" class="text-lg font-semibold">No-reply follow-up</h2>
          @if (digest().length === 0) { <p class="mt-2 rounded-lg border p-4">No escalated offers need follow-up.</p> }
          <div class="mt-3 space-y-3">@for (offer of digest(); track offer.id) { <ng-container [ngTemplateOutlet]="card" [ngTemplateOutletContext]="{ $implicit: offer }" /> }</div>
        </section>
      }
      <ng-template #card let-offer>
        <article class="rounded-xl border p-4">
          <div class="flex flex-wrap items-start justify-between gap-3"><h3 class="font-semibold">Booking {{ offer.bookingId }}</h3><span class="rounded-full border px-3 py-1 text-sm">{{ offer.reason }}</span></div>
          <p class="mt-2 break-words text-sm text-muted-foreground">{{ notes(offer) }}</p>
          <dl class="mt-2 text-sm"><dt class="font-medium">Proposed time</dt><dd>{{ offer.proposedNewAt | date:'medium' }}</dd><dt class="mt-2 font-medium">Customer notice</dt><dd>{{ offer.noticeSentAt ? 'Sent' : 'Not sent — contact manually' }}</dd></dl>
        </article>
      </ng-template>
    </main>
  `,
})
export class WeatherOffersComponent implements OnInit {
  private readonly http = inject(HttpClient);
  readonly pending = signal<WeatherOffer[]>([]);
  readonly digest = signal<WeatherOffer[]>([]);
  readonly loading = signal(true);
  readonly error = signal(false);
  ngOnInit(): void { void this.load(); }
  async load(): Promise<void> {
    this.loading.set(true); this.error.set(false);
    try {
      const [pending, digest] = await Promise.all([
        firstValueFrom(this.http.get<{ offers: WeatherOffer[] }>('/api/weather-reschedule-agent/pending')),
        firstValueFrom(this.http.get<{ offers: WeatherOffer[] }>('/api/weather-reschedule-agent/digest/morning')),
      ]);
      this.pending.set(pending.offers ?? []); this.digest.set(digest.offers ?? []);
    } catch { this.error.set(true); }
    finally { this.loading.set(false); }
  }
  notes(offer: WeatherOffer): string { return offer.forecastSummary.notes?.join(' · ') || 'Weather threshold reached.'; }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'weather-offers-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
