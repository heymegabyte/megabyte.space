import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * auth-contract.ts — typed contract + pure routing helpers for the Angular
 * /login flow (contract-first-ai / zod-everywhere spirit: one place defines the
 * worker auth API shapes the dashboard consumes).
 *
 * The OTP flow is audience-split in the worker:
 *   customer → POST /api/auth/client/start|verify     body {contact[, code]}
 *   crew     → POST /api/work/auth/start|verify        body {phone[, code]}
 *   admin    → POST /api/admin/auth/request-code|verify-code  body {contact[, code]}
 * identify  → POST /api/auth/identify  body {identifier} → {roles, hasPasskey}
 */
import type { DashboardRole } from '../../core/auth.service';

export interface IdentifyResult {
  readonly roles: DashboardRole[];
  readonly hasPasskey: boolean;
  readonly otpSent?: boolean;
  readonly magicLinkSent?: boolean;
}

export type LoginStep = 'contact' | 'pick-role' | 'code' | 'done';

export interface AudienceEndpoints {
  /** URL that sends the OTP. */
  readonly startUrl: string;
  /** URL that verifies the OTP + sets the session cookie. */
  readonly verifyUrl: string;
  /** Body field name carrying the contact (customer/admin: `contact`; crew: `phone`). */
  readonly contactField: 'contact' | 'phone';
}

/** Pure: the worker endpoints + body shape for a given role's OTP flow. */
export function loginEndpoints(role: DashboardRole): AudienceEndpoints {
  switch (role) {
    case 'crew':
      return { startUrl: '/api/work/auth/start', verifyUrl: '/api/work/auth/verify', contactField: 'phone' };
    case 'super_admin':
      return {
        startUrl: '/api/admin/auth/request-code',
        verifyUrl: '/api/admin/auth/verify-code',
        contactField: 'contact',
      };
    case 'customer':
    default:
      return { startUrl: '/api/auth/client/start', verifyUrl: '/api/auth/client/verify', contactField: 'contact' };
  }
}

/**
 * Pure: which role to default the OTP audience to after identify. Prefers the
 * most-privileged known role so an admin who is also a customer lands on admin,
 * but a single-role contact uses that role. Returns null when no roles match
 * (the form still lets the user proceed — never leaks existence).
 */
export function preferredRole(roles: DashboardRole[]): DashboardRole | null {
  if (roles.includes('super_admin')) return 'super_admin';
  if (roles.includes('crew')) return 'crew';
  if (roles.includes('customer')) return 'customer';
  return null;
}

/** Pure: do we need the role picker? (more than one distinct sign-in audience). */
export function needsRolePicker(roles: DashboardRole[]): boolean {
  return new Set(roles).size > 1;
}

const SAFE_NEXT = /^\/[A-Za-z0-9/_-]*$/; // same-origin path only

/**
 * Pure: where to land after a verified login. Honors a safe `?next=` path;
 * otherwise the role's home. Rejects open-redirects (must be a same-origin path).
 */
export function landingRoute(role: DashboardRole, next?: string | null): string {
  if (next && SAFE_NEXT.test(next) && !next.startsWith('//')) return next;
  switch (role) {
    case 'crew':
      return '/jobs';
    case 'super_admin':
      return '/admin';
    case 'customer':
    default:
      return '/';
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'auth-contract',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
