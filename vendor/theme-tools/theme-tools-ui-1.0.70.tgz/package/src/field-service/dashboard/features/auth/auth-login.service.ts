import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * AuthLoginService — RxJS client for the /login flow (rxjs-first-angular:
 * every backend call is an Observable; the component bridges to signals at the
 * template). withCredentials so the session cookie round-trips. All endpoints +
 * body shapes come from auth-contract.ts.
 */
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { type Observable, map, of, catchError } from 'rxjs';
import type { DashboardRole } from '../../core/auth.service';
import { loginEndpoints, type IdentifyResult } from './auth-contract';

@Injectable({ providedIn: 'root' })
export class AuthLoginService {
  private readonly http = inject(HttpClient);

  /** Disclose which sign-in audiences an identifier maps to (+ passkey hint). */
  identify(identifier: string): Observable<IdentifyResult> {
    return this.http
      .post<Partial<IdentifyResult>>('/api/auth/identify', { identifier: identifier.trim() }, { withCredentials: true })
      .pipe(
        map((r) => ({
          roles: (r.roles ?? []) as DashboardRole[],
          hasPasskey: Boolean(r.hasPasskey),
          otpSent: r.otpSent,
          magicLinkSent: r.magicLinkSent,
        })),
        // identify must never leak existence by erroring differently — empty on failure.
        catchError(() => of({ roles: [] as DashboardRole[], hasPasskey: false })),
      );
  }

  /** Send the OTP for the chosen audience. Resolves true on a 2xx. */
  requestCode(role: DashboardRole, contact: string): Observable<boolean> {
    const ep = loginEndpoints(role);
    return this.http
      .post(ep.startUrl, { [ep.contactField]: contact.trim() }, { withCredentials: true, observe: 'response' })
      .pipe(
        map((res) => res.status >= 200 && res.status < 300),
        catchError(() => of(false)),
      );
  }

  /** Verify the OTP; a 2xx sets the session cookie. */
  verifyCode(role: DashboardRole, contact: string, code: string): Observable<boolean> {
    const ep = loginEndpoints(role);
    return this.http
      .post(
        ep.verifyUrl,
        { [ep.contactField]: contact.trim(), code: code.trim() },
        { withCredentials: true, observe: 'response' },
      )
      .pipe(
        map((res) => res.status >= 200 && res.status < 300),
        catchError(() => of(false)),
      );
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'auth-login-service',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
