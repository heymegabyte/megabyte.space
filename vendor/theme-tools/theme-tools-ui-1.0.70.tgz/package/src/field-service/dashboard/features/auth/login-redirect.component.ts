import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';

/**
 * Login retirement shim. Sign-in is unified on the React `/login` page (Google +
 * GitHub + magic-email — one screen for customers, crew, and operators). The
 * Angular dashboard no longer owns a login surface, so any hit to the dashboard
 * `/login` route hard-redirects to the canonical React page, preserving any
 * `?next=`/`?as=` params so post-auth role routing still resolves.
 */
@Component({
  selector: 'app-login-redirect',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `<p class="p-6 text-sm text-muted-foreground">Redirecting to sign-in…</p>`,
})
export class LoginRedirectComponent implements OnInit {
  ngOnInit(): void {
    if (typeof window === 'undefined') return;
    const search = window.location.search ?? '';
    window.location.replace(`/login${search}`);
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'login-redirect-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
