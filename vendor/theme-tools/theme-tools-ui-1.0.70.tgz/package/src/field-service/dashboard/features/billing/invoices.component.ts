import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
/**
 * BillingInvoicesComponent — Stripe invoices list with PDF download link.
 *
 * Empty state guides first-time users; error panel offers retry + report when
 * the Stripe round-trip fails; skeleton rows match the table geometry while
 * loading.
 */
import { ChangeDetectionStrategy, Component, OnInit, computed, inject } from '@angular/core';
import { type ColumnDef, flexRenderComponent } from '@tanstack/angular-table';
import { SmartTableComponent } from '../../shared/ui-spartan';
import { money } from '@theme.tools/billing/field-service/money';
import { StatusPillComponent } from '../_shared/status-pill.component';
import { BillingService, Invoice } from './billing.service';

interface InvoiceRow extends Record<string, unknown> {
  readonly id: string;
  readonly date: string;
  readonly amount: string;
  readonly status: Invoice['status'];
  readonly pdf: string;
}

@Component({
  selector: 'app-billing-invoices',
  standalone: true,
  imports: [SmartTableComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (svc.error(); as err) {
      <div
        class="flex items-center justify-between gap-3 rounded-xl border border-destructive/40 bg-destructive/5 px-4 py-3"
        role="alert"
      >
        <p class="text-sm text-foreground">Couldn't load invoices — {{ err }}</p>
        <button
          type="button"
          (click)="reload()"
          class="rounded-md border border-border px-3 py-1 text-xs text-muted-foreground hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        >
          Try again
        </button>
      </div>
    } @else if (svc.invoices().length === 0 && !svc.loading()) {
      <div class="rounded-xl border border-dashed border-border p-10 text-center">
        <p class="text-2xl" aria-hidden="true">🧾</p>
        <p class="mt-2 text-base font-semibold text-foreground">No invoices yet</p>
        <p class="mx-auto mt-1 max-w-md text-sm text-muted-foreground">
          After your first job — or each visit on a recurring contract — every receipt shows up here
          with a PDF you can download.
        </p>
      </div>
    } @else {
      <app-smart-table
        [data]="rows()"
        [columns]="cols"
        [loading]="svc.loading() && svc.invoices().length === 0"
        [filterable]="true"
        filterPlaceholder="Filter invoices…"
        emptyText="No invoices match this filter."
        (rowActivate)="onActivate($event)"
      />
    }
  `,
})
export class BillingInvoicesComponent implements OnInit {
  readonly svc = inject(BillingService);

  readonly cols: ColumnDef<InvoiceRow>[] = [
    { accessorKey: 'date', header: 'Date' },
    { accessorKey: 'amount', header: 'Amount' },
    {
      accessorKey: 'status',
      header: 'Status',
      // Render the raw Stripe status as a gorgeous, brand-tokened pill instead of
      // plain lowercase text. Sorting/filtering still operate on the raw value.
      cell: (info) =>
        flexRenderComponent(StatusPillComponent, {
          inputs: { status: info.getValue() as string },
        }),
    },
    { accessorKey: 'pdf', header: 'PDF' },
  ];

  readonly rows = computed<InvoiceRow[]>(() =>
    this.svc.invoices().map((i) => ({
      id: i.id,
      date: new Date(i.date).toLocaleDateString(),
      amount: money(i.amountCents),
      status: i.status,
      pdf: i.pdfUrl ? 'Download' : '—',
    })),
  );

  ngOnInit(): void {
    this.svc.error.set(null); // clear a stale sibling-tab error on entry — the shared error signal is
    // only cleared INSIDE a load, which a cached tab skips, so a prior tab's failure would show here.
    if (this.svc.invoices().length === 0) void this.reload();
  }

  reload(): void {
    void this.svc.loadInvoices();
  }

  onActivate(r: InvoiceRow): void {
    const inv = this.svc.invoices().find((i) => i.id === r.id);
    if (inv?.pdfUrl) globalThis.open(inv.pdfUrl, '_blank', 'noopener,noreferrer');
    else if (inv?.hostedUrl) globalThis.open(inv.hostedUrl, '_blank', 'noopener,noreferrer');
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'invoices-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
