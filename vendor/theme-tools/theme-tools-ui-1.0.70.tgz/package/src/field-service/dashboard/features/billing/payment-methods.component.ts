import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
/**
 * BillingPaymentMethodsComponent — list cards/ACH on file with add/remove.
 *
 * Adding a card opens the Stripe Customer Portal in a new tab (we never
 * reimplement card collection client-side). Removal calls our Worker which
 * proxies a Stripe API delete.
 */
import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import {
  HlmCardImports,
  HlmButton,
  HlmBadge,
  ConfirmDialog,
  ToastService,
} from '../../shared/ui-spartan';
import { BillingService, PaymentMethod } from './billing.service';

@Component({
  selector: 'app-billing-payment-methods',
  standalone: true,
  imports: [...HlmCardImports, HlmButton, HlmBadge, ConfirmDialog],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div hlmCard>
      <div hlmCardHeader>
        <h3 hlmCardTitle>Payment methods</h3>
        <p hlmCardDescription>Cards and ACH on file</p>
      </div>
      <div hlmCardContent>
        <ul class="divide-y divide-border">
          @for (m of svc.paymentMethods(); track m.id; let i = $index) {
            <li
              data-testid="pm-row"
              [style.animation-delay.ms]="i * 70"
              class="bcl-rise -mx-2 flex items-center justify-between rounded-lg px-2 py-3 transition-[transform,background-color] duration-[333ms] hover:-translate-y-0.5 hover:bg-muted/40"
            >
              <div class="flex items-center gap-3">
                <span
                  hlmBadge
                  variant="secondary"
                  data-testid="pm-brand-pill"
                  [attr.aria-label]="(m.kind === 'ach' ? 'Bank account' : 'Card') + ': ' + brandLabel(m.brand)"
                  class="inline-flex min-h-[24px] items-center font-mono text-[0.7rem] uppercase tracking-wider transition-[transform,box-shadow] duration-[333ms] hover:-translate-y-0.5"
                  >{{ brandLabel(m.brand) }}</span
                >
                <div>
                  <p class="text-sm font-medium text-foreground">
                    ····{{ m.last4 }}
                    @if (m.isDefault) {
                      <span class="ml-2"><span hlmBadge variant="success">Default</span></span>
                    }
                  </p>
                  @if (m.kind === 'card' && m.expMonth && m.expYear) {
                    <p class="text-xs text-muted-foreground">Expires {{ pad(m.expMonth) }}/{{ m.expYear }}</p>
                  } @else if (m.kind === 'ach') {
                    <p class="text-xs text-muted-foreground">Bank account · ACH</p>
                  }
                </div>
              </div>
              <button
                hlmBtn
                variant="ghost"
                size="sm"
                data-testid="pm-remove"
                [attr.aria-label]="'Remove ' + brandLabel(m.brand) + ' ending ' + m.last4"
                class="min-h-[24px] transition-[transform,color] duration-[333ms] hover:-translate-y-0.5 focus-visible:ring-2 focus-visible:ring-[var(--bcl-ring)] focus-visible:ring-offset-1"
                (click)="askRemove(m)"
              >
                Remove
              </button>
            </li>
          } @empty {
            <li class="py-6 text-sm text-muted-foreground">
              No payment methods on file. Add one to keep service active.
            </li>
          }
        </ul>
        <div class="mt-4 flex gap-2">
          <button hlmBtn [disabled]="busy()" (click)="addCard()">Add card</button>
          <button hlmBtn variant="secondary" [disabled]="busy()" (click)="addAch()">Add bank (ACH)</button>
        </div>
        @if (error(); as e) {
          <p class="mt-3 text-sm text-destructive" role="alert">{{ e }}</p>
        }
      </div>
    </div>
    <app-confirm-dialog
      [open]="!!toRemove()"
      title="Remove payment method"
      description="This card will no longer be charged. If it's your only method, the next invoice may fail."
      confirmLabel="Remove"
      (confirmed)="confirmRemove()"
      (cancelled)="toRemove.set(null)"
    />
  `,
})
export class BillingPaymentMethodsComponent implements OnInit {
  readonly svc = inject(BillingService);
  private readonly toast = inject(ToastService);
  readonly busy = signal<boolean>(false);
  readonly error = signal<string | null>(null);
  readonly toRemove = signal<PaymentMethod | null>(null);

  ngOnInit(): void {
    if (this.svc.paymentMethods().length === 0) void this.svc.loadPaymentMethods();
  }

  pad(n: number): string {
    return n.toString().padStart(2, '0');
  }

  /** Card/bank brand as a mono-uppercase pill label (visa → VISA, ACH → ACH). */
  brandLabel(brand: string): string {
    return (brand || 'CARD').toUpperCase();
  }

  async addCard(): Promise<void> {
    await this.launchPortal('/billing/payment-methods');
  }

  async addAch(): Promise<void> {
    await this.launchPortal('/billing/payment-methods?method=ach');
  }

  private async launchPortal(returnPath: string): Promise<void> {
    this.busy.set(true);
    this.error.set(null);
    try {
      const url = await this.svc.openPortal(returnPath);
      globalThis.open(url, '_blank', 'noopener,noreferrer');
      this.toast.info('Opened Stripe portal in a new tab');
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Failed to open billing portal';
      this.error.set(msg);
      this.toast.error("Couldn't open Stripe portal", undefined, msg);
    } finally {
      this.busy.set(false);
    }
  }

  askRemove(m: PaymentMethod): void {
    this.toRemove.set(m);
  }

  async confirmRemove(): Promise<void> {
    const m = this.toRemove();
    if (!m) return;
    this.busy.set(true);
    try {
      await this.svc.removePaymentMethod(m.id);
      this.toRemove.set(null);
      this.toast.success(`Removed ${m.brand} ····${m.last4} · just now`);
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Remove failed';
      this.error.set(msg);
      this.toast.error('Remove failed — try again', undefined, msg);
    } finally {
      this.busy.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'payment-methods-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
