import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
/**
 * AddToCalendarComponent — Google/Apple/Outlook add-to-calendar for a booking.
 * Angular port of the React `customer/AddToCalendarMenu`. Live surface = Angular
 * /dashboard.
 *
 * Probes GET /api/ics-calendar-invites/:id/google on init; self-gates (hides) on
 * 404 (ics_calendar_invites flag off / not owned). Apple downloads the .ics blob;
 * Google/Outlook fetch a redirect URL and open it. Dark-cockpit Spartan buttons.
 */
import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  inject,
  input,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { HlmButton } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

interface LinkResponse {
  readonly ok?: boolean;
  readonly result?: { readonly url?: string };
}

@Component({
  selector: 'app-add-to-calendar',
  standalone: true,
  imports: [HlmButton, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (available()) {
      <div bclReveal class="mt-4 flex flex-wrap items-center gap-2" data-testid="add-to-calendar">
        <span class="text-sm text-muted-foreground">Add to calendar:</span>
        <button hlmBtn variant="outline" type="button" (click)="apple()" [disabled]="busy()">
          Apple / .ics
        </button>
        <button hlmBtn variant="outline" type="button" (click)="provider('google')" [disabled]="busy()">
          Google
        </button>
        <button hlmBtn variant="outline" type="button" (click)="provider('outlook')" [disabled]="busy()">
          Outlook
        </button>
        @if (error()) {
          <span class="text-xs text-destructive" role="alert">{{ error() }}</span>
        }
      </div>
    }
  `,
})
export class AddToCalendarComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly bookingId = input.required<string>();

  readonly available = signal(false);
  readonly busy = signal(false);
  readonly error = signal<string>('');

  ngOnInit(): void {
    void this.probe();
  }

  private base(): string {
    return `/api/ics-calendar-invites/${encodeURIComponent(this.bookingId())}`;
  }

  async probe(): Promise<void> {
    try {
      const res = await fetch(`${this.base()}/google`, { credentials: 'include' });
      // 404 = flag off / not owned → hide; anything else = feature is live.
      this.available.set(res.status !== 404);
    } catch {
      this.available.set(false);
    }
  }

  async provider(which: 'google' | 'outlook'): Promise<void> {
    this.busy.set(true);
    this.error.set('');
    try {
      const r = await firstValueFrom(
        this.http.get<LinkResponse>(`${this.base()}/${which}`, { withCredentials: true }),
      );
      if (r?.ok && r.result?.url) {
        window.open(r.result.url, '_blank', 'noopener,noreferrer');
      }
      else this.error.set('Could not open the calendar link.');
    } catch {
      this.error.set('Could not open the calendar link.');
    } finally {
      this.busy.set(false);
    }
  }

  async apple(): Promise<void> {
    this.busy.set(true);
    this.error.set('');
    try {
      const res = await fetch(`${this.base()}.ics`, { credentials: 'include' });
      if (!res.ok) {
        this.error.set('Could not download the calendar file.');
        return;
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      window.open(url, '_blank', 'noopener,noreferrer');
      setTimeout(() => URL.revokeObjectURL(url), 10_000);
    } catch {
      this.error.set('Could not download the calendar file.');
    } finally {
      this.busy.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'add-to-calendar-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
