import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
/**
 * BookingDetailComponent — single-booking view, rebuilt on Spartan (Wave 3c).
 * Hand-rolled shared (card/skeleton/button/status-pill) → Spartan ui-spartan
 * (HlmCard family, StateBlock, HlmButton, HlmBadge + statusBadge). The 6-step
 * timeline now lives in features/_shared. Status fetch is RxJS-first
 * (toObservable(id+reloadTick) → switchMap → toSignal); the reschedule/cancel
 * mutations stay imperative HttpClient calls (one-shot actions) with explicit
 * busy signals. Contract unchanged: GET /api/customer/jobs/:id,
 * PATCH …/bookings/:id/reschedule, POST …/jobs/:id/cancel.
 */
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { toObservable, toSignal } from '@angular/core/rxjs-interop';
import { firstValueFrom, of, switchMap, map, startWith, catchError, distinctUntilChanged } from 'rxjs';
import {
  HlmCardImports,
  HlmButton,
  HlmBadge,
  HlmInput,
  HlmSpinner,
  StateBlockComponent,
  type SurfaceState,
} from '../../shared/ui-spartan';
import { routeFade, reducedMotion } from '../../shared/animations';
import { formatUsdCents } from '@theme.tools/billing/field-service/money';
import { statusBadge } from '@theme.tools/crm/field-service/status-badge';
import { AuthService } from '../../core/auth.service';
import { FeatureFlagService } from '../../core/feature-flag.service';
import {
  StatusTimelineComponent,
  type RideStatusStep,
} from '../_shared/status-timeline.component';
import { BookingPhotosComponent } from './booking-photos.component';
import { CompletionProofComponent } from './completion-proof.component';
import { AddToCalendarComponent } from './add-to-calendar.component';
import { PredictNextCardComponent } from './predict-next-card.component';
import { FavoriteCrewComponent } from './favorite-crew.component';
import { NpsSurveyComponent } from './nps-survey.component';

interface CrewMember {
  readonly workerId: string;
  readonly firstName: string;
  readonly lastInitial: string;
  readonly avatarUrl: string | null;
  readonly isLead: boolean;
  readonly status: string;
}

interface BookingDetail {
  readonly id: string;
  readonly status: string;
  readonly paymentStatus: string;
  readonly preferredDate: string;
  readonly preferredTime: string;
  readonly hours: number;
  readonly crew: number;
  readonly services: readonly string[];
  readonly address: string;
  readonly city: string;
  readonly zip: string;
  readonly notes: string;
  readonly pricing: {
    readonly totalCents: number;
    readonly baseLaborCents: number;
    readonly rentalsCents: number;
    readonly surgeCents: number;
    readonly tipCents: number;
  };
  readonly timeline: {
    readonly scheduledAt: string | null;
    readonly paidAt: string | null;
    readonly completedAt: string | null;
    readonly canceledAt: string | null;
  };
  readonly crewMembers: readonly CrewMember[];
  readonly hasRecap: boolean;
  readonly receiptUrl: string | null;
}

interface BookingDetailResponse {
  readonly ok: boolean;
  readonly booking: BookingDetail;
}

interface RescheduleForm {
  newDate: FormControl<string | null>;
  newTime: FormControl<string | null>;
}

interface LoadState {
  readonly state: SurfaceState;
  readonly booking: BookingDetail | null;
  readonly error: string;
}

@Component({
  selector: 'app-booking-detail',
  standalone: true,
  imports: [
    ...HlmCardImports,
    HlmButton,
    HlmBadge,
    HlmInput,
    HlmSpinner,
    StateBlockComponent,
    StatusTimelineComponent,
    BookingPhotosComponent,
    CompletionProofComponent,
    AddToCalendarComponent,
    PredictNextCardComponent,
    FavoriteCrewComponent,
    NpsSurveyComponent,
    ReactiveFormsModule,
    RouterLink,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <a
      routerLink="/bookings"
      class="mb-4 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
    >
      <span aria-hidden="true">←</span> All bookings
    </a>

    <app-state-block
      [state]="view().state"
      [errorDetail]="view().error"
      errorTitle="Couldn't load this booking"
      [emptyTitle]="emptyTitle()"
      [emptyHint]="emptyHint()"
      [emptyCta]="emptyCta()"
      (retry)="reload()"
      (emptyAction)="emptyAction()"
    >
      @if (booking(); as b) {
        <header class="mb-6">
          <div class="mb-2 flex flex-wrap items-center gap-2">
            <span hlmBadge [variant]="badge(b.paymentStatus).variant">{{
              badge(b.paymentStatus).label
            }}</span>
            <ul
              role="list"
              aria-label="Services requested"
              class="flex flex-wrap gap-1.5"
            >
              @for (svc of b.services.length ? b.services : ['crew']; track svc; let i = $index) {
                <li
                  class="rounded-full border border-bcl-accent/30 bg-bcl-accent/10 px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-bcl-accent transition-all duration-[333ms] hover:-translate-y-px hover:border-bcl-accent hover:bg-bcl-accent/20"
                  [style.animation-delay]="i * 60 + 'ms'"
                >{{ svc }}</li>
              }
            </ul>
          </div>
          <h1 class="text-2xl font-bold text-foreground">
            {{ b.address }}, {{ b.city }} {{ b.zip }}
          </h1>
          <p class="mt-1 text-sm text-muted-foreground">
            {{ b.preferredDate }} · {{ b.preferredTime }} · {{ b.hours }}h · crew of {{ b.crew }}
          </p>
        </header>

        <div hlmCard>
          <div hlmCardHeader>
            <h3 hlmCardTitle>Status</h3>
            <p hlmCardDescription>Live updates as your crew progresses.</p>
          </div>
          <div hlmCardContent>
            <bcl-status-timeline [current]="timelineStep()" />
          </div>
        </div>

        <div class="mt-4 grid gap-4 md:grid-cols-2">
          <div hlmCard>
            <div hlmCardHeader>
              <h3 hlmCardTitle>Your crew</h3>
              <p hlmCardDescription>Verified, background-checked.</p>
            </div>
            <div hlmCardContent>
              @if (b.crewMembers.length === 0) {
                <p class="text-sm text-muted-foreground">Crew assignment pending.</p>
              } @else {
                <ul class="space-y-2">
                  @for (m of b.crewMembers; track m.workerId) {
                    <li class="flex items-center gap-3">
                      <div
                        class="flex size-10 items-center justify-center rounded-full bg-muted font-mono text-sm text-primary ring-1 ring-border"
                        aria-hidden="true"
                      >
                        @if (m.avatarUrl) {
                          <img
                            [src]="m.avatarUrl"
                            [alt]="m.firstName + ' avatar'"
                            class="size-full rounded-full object-cover"
                          />
                        } @else {
                          {{ m.firstName[0] }}{{ m.lastInitial }}
                        }
                      </div>
                      <div class="min-w-0 flex-1">
                        <p class="text-sm font-medium text-foreground">
                          {{ m.firstName }} {{ m.lastInitial }}.
                          @if (m.isLead) {<span class="text-xs text-primary">· Lead</span>}
                        </p>
                        <p class="text-xs text-muted-foreground">{{ m.status }}</p>
                      </div>
                    </li>
                  }
                </ul>
              }
            </div>
          </div>

          <div hlmCard>
            <div hlmCardHeader>
              <h3 hlmCardTitle>Payment</h3>
              <p hlmCardDescription>Itemized breakdown.</p>
            </div>
            <div hlmCardContent>
              <dl class="space-y-1 text-sm">
                <div class="flex justify-between">
                  <dt class="text-muted-foreground">Labor</dt>
                  <dd class="font-mono tabular-nums text-foreground">{{ money(b.pricing.baseLaborCents) }}</dd>
                </div>
                @if (b.pricing.rentalsCents > 0) {
                  <div class="flex justify-between">
                    <dt class="text-muted-foreground">Rentals</dt>
                    <dd class="font-mono tabular-nums text-foreground">{{ money(b.pricing.rentalsCents) }}</dd>
                  </div>
                }
                @if (b.pricing.surgeCents > 0) {
                  <div class="flex justify-between">
                    <dt class="text-muted-foreground">Surge</dt>
                    <dd class="font-mono tabular-nums text-foreground">{{ money(b.pricing.surgeCents) }}</dd>
                  </div>
                }
                @if (b.pricing.tipCents > 0) {
                  <div class="flex justify-between">
                    <dt class="text-muted-foreground">Tip</dt>
                    <dd class="font-mono tabular-nums text-foreground">{{ money(b.pricing.tipCents) }}</dd>
                  </div>
                }
                <div class="flex justify-between border-t border-border pt-2">
                  <dt class="font-semibold text-foreground">Total</dt>
                  <dd class="font-mono text-base tabular-nums text-primary">{{ money(b.pricing.totalCents) }}</dd>
                </div>
              </dl>
              <div class="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2">
                <a
                  [href]="'/api/customer/jobs/' + b.id + '/receipt.pdf'"
                  target="_blank"
                  rel="noopener noreferrer"
                  data-testid="receipt-pdf-download"
                  class="inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs font-medium text-primary
                         transition-all duration-[333ms] hover:-translate-y-0.5 hover:bg-primary/10
                         focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                  aria-label="Download payment receipt as PDF"
                >
                  Download receipt (PDF) ↓
                </a>
                @if (b.receiptUrl) {
                  <a
                    [href]="b.receiptUrl"
                    target="_blank"
                    rel="noopener noreferrer"
                    class="inline-block text-xs text-muted-foreground transition-colors duration-[333ms] hover:text-primary hover:underline"
                  >
                    View Square receipt →
                  </a>
                }
              </div>
            </div>
          </div>
        </div>

        <app-add-to-calendar [bookingId]="b.id" />
        <app-predict-next-card />
        <app-favorite-crew [crew]="b.crewMembers" />
        <app-booking-photos [bookingId]="b.id" />
        @if (showCompletionProof()) {
          <app-completion-proof [bookingId]="b.id" />
        }
        @if (b.status === 'completed' || b.status === 'review_requested') {
          <app-nps-survey class="mt-4 block" [bookingId]="b.id" />
        }

        @if (canRebook()) {
          <div hlmCard class="mt-4 border-bcl-accent/30">
            <div
              hlmCardContent
              class="flex flex-wrap items-center justify-between gap-3 py-4"
            >
              <div class="min-w-0">
                <p class="text-sm font-semibold text-foreground">Need the crew again?</p>
                <p class="text-xs text-muted-foreground">
                  Rebook this exact job — same scope, prefilled. Tweak anything before you confirm.
                </p>
              </div>
              <a
                routerLink="/quotes/new"
                [queryParams]="{ from: b.id }"
                data-testid="rebook-cta"
                aria-label="Book this crew again with the same job details"
                class="inline-flex min-h-[44px] items-center gap-1 rounded-md bg-primary px-4 py-2
                       text-sm font-semibold text-primary-foreground transition-all duration-[333ms]
                       hover:-translate-y-0.5 hover:bg-primary/90 hover:shadow-md
                       focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
              >
                Book this crew again
                <span aria-hidden="true">→</span>
              </a>
            </div>
          </div>
        }

        @if (canReschedule()) {
          <div hlmCard class="mt-4">
            <div hlmCardHeader>
              <h3 hlmCardTitle>Reschedule</h3>
              <p hlmCardDescription>Pick a new date or time.</p>
            </div>
            <div hlmCardContent>
              <form [formGroup]="rescheduleForm" (ngSubmit)="onReschedule()" class="flex flex-wrap items-end gap-3">
                <label class="flex flex-col text-sm">
                  <span class="mb-1 text-muted-foreground">New date</span>
                  <input hlmInput type="date" formControlName="newDate" data-testid="reschedule-date" />
                </label>
                <label class="flex flex-col text-sm">
                  <span class="mb-1 text-muted-foreground">New time</span>
                  <input hlmInput type="time" formControlName="newTime" data-testid="reschedule-time" />
                </label>
                <button hlmBtn type="submit" [disabled]="!rescheduleForm.valid || rescheduling()">
                  @if (rescheduling()) { <app-spinner [size]="16" /> Saving… } @else { Reschedule }
                </button>
                <button hlmBtn variant="destructive" type="button" [disabled]="canceling()" (click)="onCancel()">
                  @if (canceling()) { <app-spinner [size]="16" /> Canceling… } @else { Cancel booking }
                </button>
              </form>
              @if (rescheduleError()) {
                <p class="mt-2 text-xs text-destructive" role="alert">{{ rescheduleError() }}</p>
              }
              @if (rescheduleSuccess()) {
                <p class="mt-2 text-xs text-bcl-success" role="status">Updated. Reloading…</p>
              }
              @if (cancelError()) {
                <p class="mt-2 text-xs text-destructive" role="alert">{{ cancelError() }}</p>
              }
            </div>
          </div>
        }

        @if (accessNotesOn() && canEditNotes()) {
          <div hlmCard class="mt-4 border-bcl-accent/30" data-testid="access-notes-editor">
            <div hlmCardHeader>
              <h3 hlmCardTitle>Access & instructions</h3>
              <p hlmCardDescription>
                Gate codes, parking, which door, pets — anything that helps the crew get in and work faster.
              </p>
            </div>
            <div hlmCardContent>
              <form [formGroup]="notesForm" (ngSubmit)="onSaveNotes()">
                <label class="flex flex-col text-sm">
                  <span id="access-notes-label" class="mb-1 text-muted-foreground">Instructions for your crew</span>
                  <textarea
                    formControlName="notes"
                    data-testid="access-notes-input"
                    rows="4"
                    maxlength="2000"
                    aria-labelledby="access-notes-label"
                    aria-describedby="access-notes-hint"
                    placeholder="e.g. Gate code 1234. Park in the driveway. Leave boxes in the garage. Friendly dog in the yard."
                    class="w-full rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground
                           placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2
                           focus-visible:ring-primary"
                  ></textarea>
                </label>
                <div class="mt-2 flex flex-wrap items-center justify-between gap-2">
                  <p id="access-notes-hint" class="text-xs text-muted-foreground" aria-live="polite">
                    {{ notesLength() }} / 2000 · only your crew + dispatch can see this
                  </p>
                  <button hlmBtn type="submit" [disabled]="savingNotes() || !notesForm.valid">
                    @if (savingNotes()) { <app-spinner [size]="16" /> Saving… } @else { Save instructions }
                  </button>
                </div>
                @if (notesError()) {
                  <p class="mt-2 text-xs text-destructive" role="alert" data-testid="access-notes-error">
                    {{ notesError() }}
                  </p>
                }
                @if (notesSuccess()) {
                  <p class="mt-2 text-xs text-bcl-success" role="status" data-testid="access-notes-success">
                    Saved. Your crew will see this.
                  </p>
                }
              </form>
            </div>
          </div>
        }
      }
    </app-state-block>
  `,
})
export class BookingDetailComponent {
  private readonly http = inject(HttpClient);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly fb = inject(FormBuilder);
  protected readonly reducedMotion = reducedMotion;

  protected readonly badge = statusBadge;
  protected readonly rescheduling = signal(false);
  protected readonly canceling = signal(false);
  protected readonly rescheduleError = signal<string | null>(null);
  protected readonly rescheduleSuccess = signal(false);
  protected readonly cancelError = signal<string | null>(null);
  private readonly reloadTick = signal(0);

  // fire-143 — editable post-booking access instructions. Public (the spec drives
  // onSaveNotes + reads these) — save gates success on the response (fire-133/138 class).
  readonly savingNotes = signal(false);
  readonly notesError = signal<string | null>(null);
  readonly notesSuccess = signal(false);

  private readonly id = toSignal(
    this.route.paramMap.pipe(
      map((params) => params.get('id') ?? ''),
      distinctUntilChanged(),
    ),
    { initialValue: this.route.snapshot.paramMap.get('id') ?? '' },
  );
  private readonly auth = inject(AuthService);
  private readonly flags = inject(FeatureFlagService);

  /** fire-143 — client gate for the access-instructions editor (server route also 404s when off). */
  protected readonly accessNotesOn = this.flags.isOn('customer_access_notes');

  /**
   * Guest deep-linking /dashboard/bookings/:id (the `requireRole('customer')`
   * guard passes because `RoleService.viewAs` defaults to 'customer' when
   * whoami is empty) must NOT fire the authed fetch — the worker 401s it and
   * the raw 401 leaks a console error. Signed out → skip the request, show a
   * sign-in affordance. (Mirrors BookingsComponent.)
   */
  protected readonly needsAuth = computed(() => !this.auth.authenticated());
  protected readonly emptyTitle = computed(() =>
    this.needsAuth() ? 'Sign in to see this booking' : 'Booking not found',
  );
  protected readonly emptyHint = computed(() =>
    this.needsAuth()
      ? 'Log in to view this job, track its status, reschedule, or grab the receipt.'
      : 'This booking may have been removed, or the link is stale.',
  );
  protected readonly emptyCta = computed(() => (this.needsAuth() ? 'Sign in →' : ''));

  /** RxJS-first load: id+reloadTick → GET → 4-state, bridged at template. */
  protected readonly view = toSignal(
    toObservable(
      computed(() => ({
        id: this.id(),
        tick: this.reloadTick(),
        authed: this.auth.authenticated(),
      })),
    ).pipe(
      switchMap(({ id, authed }) => {
        // Signed out → skip the authed fetch (no console 401); render sign-in empty state.
        if (!authed) return of<LoadState>({ state: 'empty', booking: null, error: '' });
        return this.http
          .get<BookingDetailResponse>(`/api/customer/jobs/${id}`, { withCredentials: true })
          .pipe(
            map((resp): LoadState => {
              const booking = resp?.booking ?? null;
              if (booking) {
                this.rescheduleForm.patchValue({
                  newDate: booking.preferredDate,
                  newTime: normalizeTime(booking.preferredTime),
                });
                // Seed the access-instructions editor with the stored notes.
                this.notesForm.patchValue({ notes: booking.notes ?? '' });
              }
              return { state: booking ? 'ready' : 'empty', booking, error: '' };
            }),
            catchError((err) =>
              of<LoadState>({
                state: 'error',
                booking: null,
                error: (err as Error)?.message ?? 'Network error',
              }),
            ),
            startWith<LoadState>({ state: 'loading', booking: null, error: '' }),
          );
      }),
    ),
    { initialValue: { state: 'loading', booking: null, error: '' } as LoadState },
  );

  /** Empty-state action: sign in when signed out (else the empty state is terminal). */
  protected emptyAction(): void {
    if (this.needsAuth()) {
      void this.router.navigate(['/login'], {
        queryParams: { as: 'customer', next: `/bookings/${this.id()}` },
      });
    }
  }

  protected readonly booking = computed(() => this.view().booking);

  /**
   * The proof-of-work panel only makes sense once a crew has begun documenting
   * the job — before that the package is an empty 0/N and adds noise. Show it
   * from arrival onward (the component itself self-hides if the package endpoint
   * returns nothing / is unauthorized).
   */
  protected readonly showCompletionProof = computed(() => {
    const b = this.booking();
    if (!b) return false;
    return ['arrived', 'in_progress', 'completed', 'review_requested'].includes(
      b.status.toLowerCase(),
    );
  });

  protected readonly canReschedule = computed(() => {
    const b = this.booking();
    if (!b) return false;
    return !['completed', 'canceled', 'review_requested'].includes(b.status);
  });

  /**
   * Access instructions help the crew find + enter the property, so they're
   * editable right up until the job is done (same window as reschedule). The
   * server additionally blocks only canceled bookings (409) — the client is a
   * touch more conservative (hides for completed too, where editing is moot).
   */
  protected readonly canEditNotes = computed(() => {
    const b = this.booking();
    if (!b) return false;
    return !['completed', 'canceled', 'review_requested'].includes(b.status);
  });

  /**
   * Rebook is the highest-intent repeat-revenue moment: a customer reviewing a
   * finished (or canceled) job is the likeliest to book again. Offer a one-tap
   * deep link into the same `/quotes/new?from=<id>` prefill flow the bookings
   * list uses, so the prior scope is replayed. Pure navigation → autonomous-tier.
   */
  protected readonly canRebook = computed(() => {
    const b = this.booking();
    if (!b) return false;
    return ['completed', 'review_requested', 'canceled'].includes(b.status);
  });

  protected readonly timelineStep = computed<RideStatusStep>(() => {
    const b = this.booking();
    if (!b) return 'requested';
    const s = b.status.toLowerCase();
    if (s === 'completed' || s === 'review_requested') return 'complete';
    if (s === 'in_progress') return 'working';
    if (s === 'arrived') return 'arrived';
    if (s === 'en_route' || s === 'enroute') return 'enroute';
    if (s === 'confirmed') return 'matched';
    return 'requested';
  });

  readonly rescheduleForm: FormGroup<RescheduleForm> = this.fb.group({
    newDate: this.fb.control<string | null>(null, Validators.required),
    newTime: this.fb.control<string | null>(null, Validators.required),
  });

  /** fire-143 — access-instructions editor form (seeded from booking.notes on load). */
  readonly notesForm = this.fb.group({
    notes: this.fb.control('', { nonNullable: true, validators: [Validators.maxLength(2000)] }),
  });

  /** Live character count for the notes textarea (aria-live hint). */
  protected readonly notesLength = toSignal(
    this.notesForm.controls.notes.valueChanges.pipe(
      startWith(this.notesForm.controls.notes.value),
      map((v) => (v ?? '').length),
    ),
    { initialValue: 0 },
  );

  protected reload(): void {
    this.reloadTick.update((n) => n + 1);
  }

  protected money(cents: number): string {
    return formatUsdCents(cents);
  }

  protected async onReschedule(): Promise<void> {
    const b = this.booking();
    const v = this.rescheduleForm.value;
    if (!b || !v.newDate || !v.newTime) return;
    this.rescheduling.set(true);
    this.rescheduleError.set(null);
    this.rescheduleSuccess.set(false);
    try {
      const newStart = new Date(`${v.newDate}T${v.newTime}:00Z`).toISOString();
      await firstValueFrom(
        this.http.patch(
          `/api/customer/bookings/${b.id}/reschedule`,
          { newStart },
          { withCredentials: true },
        ),
      );
      this.rescheduleSuccess.set(true);
      this.reload();
    } catch (e: unknown) {
      this.rescheduleError.set(
        (e as { error?: { error?: string } })?.error?.error ?? 'Could not reschedule.',
      );
    } finally {
      this.rescheduling.set(false);
    }
  }

  protected async onCancel(): Promise<void> {
    const b = this.booking();
    if (!b) return;
    const ok = globalThis.confirm?.('Cancel this booking? This cannot be undone.');
    if (!ok) return;
    this.canceling.set(true);
    this.cancelError.set(null);
    try {
      await firstValueFrom(
        this.http.post(`/api/customer/jobs/${b.id}/cancel`, {}, { withCredentials: true }),
      );
      await this.router.navigate(['/bookings'], { queryParams: { tab: 'past' } });
    } catch (e: unknown) {
      // Destructive action must not fail silently — the booking would look
      // cancelled (button re-enabled) while still live.
      this.cancelError.set(
        (e as { error?: { error?: string } })?.error?.error ?? 'Could not cancel the booking.',
      );
      this.canceling.set(false);
    }
  }

  /**
   * fire-143 — save the access instructions. Gates success on the response: a
   * failed PATCH (401/409/429/5xx → firstValueFrom rejects) is an assertive
   * error with NO false success and NO reload (stale notes must not look saved).
   */
  async onSaveNotes(): Promise<void> {
    const b = this.booking();
    if (!b || this.savingNotes()) return;
    const notes = this.notesForm.controls.notes.value ?? '';
    this.savingNotes.set(true);
    this.notesError.set(null);
    this.notesSuccess.set(false);
    try {
      await firstValueFrom(
        this.http.patch(
          `/api/customer/bookings/${b.id}/notes`,
          { notes },
          { withCredentials: true },
        ),
      );
      this.notesSuccess.set(true);
      this.reload();
    } catch (e: unknown) {
      this.notesError.set(accessNotesError((e as { error?: { code?: string } })?.error?.code));
    } finally {
      this.savingNotes.set(false);
    }
  }
}

/** Map an access-notes PATCH error code to friendly, actionable copy. */
function accessNotesError(code: string | undefined): string {
  switch (code) {
    case 'rate_limited':
      return 'Too many changes too fast — wait a minute and try again.';
    case 'unauthorized':
      return 'Please sign in again to save your instructions.';
    case 'not_editable':
      return 'This booking can no longer be edited.';
    case 'not_found':
      return "We couldn't find this booking.";
    default:
      return 'Could not save your instructions. Try again.';
  }
}

/** Normalize "9:00 am" / "09:00" / "9 PM" → "HH:MM" for input[type=time]. */
function normalizeTime(t: string): string {
  if (!t) return '09:00';
  const m = /^(\d{1,2})(?::(\d{2}))?\s*(am|pm)?$/i.exec(t.trim());
  if (!m) return '09:00';
  let h = Number(m[1]);
  const mm = m[2] ? Number(m[2]) : 0;
  const period = m[3]?.toLowerCase();
  if (period === 'pm' && h < 12) h += 12;
  if (period === 'am' && h === 12) h = 0;
  return `${String(h).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'booking-detail-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
