import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
/**
 * BookingPhotosComponent — per-booking before/after media on the booking detail.
 *
 * Replaces the standalone customer "Photos" tab (a flat, context-stripped archive
 * across every job). Photos belong WITH the job that produced them: each booking
 * carries up to 4 "before" + 4 "after" items (the job-completion gate already
 * requires 4+4), and videos are supported (mime video/* → <video>). Live surface =
 * Angular /dashboard.
 *
 * Fetches GET /api/jobs/:bookingId/photos (auth-gated server-side: owner customer
 * OR cancel-token OR crew/admin → 401/404 otherwise). Self-hides when the job has
 * no media yet. Dark-cockpit styling, mirrors the sibling per-booking component
 * (add-to-calendar).
 */
import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  computed,
  inject,
  input,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { HlmCardImports } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

export interface BookingPhoto {
  readonly id: string;
  readonly bookingId: string;
  readonly kind: string | null;
  readonly mime: string | null;
  readonly url: string;
  readonly uploadedAt: string;
}

interface PhotosResponse {
  readonly ok: boolean;
  readonly counts?: { readonly start: number; readonly end: number; readonly required: number };
  readonly photos?: readonly BookingPhoto[];
}

/** Pure: which group a stored kind belongs to (start/before = before; end/after = after). */
export function photoGroup(kind: string | null): 'before' | 'after' | 'other' {
  switch ((kind ?? '').toLowerCase()) {
    case 'start':
    case 'before':
      return 'before';
    case 'end':
    case 'after':
      return 'after';
    default:
      return 'other';
  }
}

/** Pure: true when the media item is a video (renders as <video> not <img>). */
export function isVideo(mime: string | null): boolean {
  return (mime ?? '').toLowerCase().startsWith('video/');
}

@Component({
  selector: 'app-booking-photos',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [HlmCardImports, BclRevealDirective],
  template: `
    @if (photos().length > 0) {
      <section hlmCard bclReveal class="mt-4 p-4">
        <header class="mb-3 flex items-center justify-between">
          <h3 class="text-sm font-semibold tracking-wide text-[--ps-ink]">Job photos &amp; video</h3>
          @if (counts(); as c) {
            <span class="font-mono text-xs text-[--ps-ink-accent]">
              {{ c.start }}/{{ c.required }} before · {{ c.end }}/{{ c.required }} after
            </span>
          }
        </header>

        @if (before().length > 0) {
          <p class="mb-1 text-xs uppercase tracking-wider text-[--ps-ink-accent]">Before</p>
          <div class="mb-3 grid grid-cols-4 gap-2">
            @for (p of before(); track p.id) {
              <a
                [href]="p.url"
                target="_blank"
                rel="noopener noreferrer"
                class="block aspect-square overflow-hidden rounded-lg border border-white/10 bg-black/40 focus-visible:outline focus-visible:outline-2 focus-visible:outline-[--ps-accent]"
              >
                @if (video(p)) {
                  <video [src]="p.url" class="h-full w-full object-cover" muted playsinline preload="metadata" [attr.aria-label]="'Job before video, uploaded ' + p.uploadedAt"></video>
                } @else {
                  <img [src]="p.url" loading="lazy" decoding="async" class="h-full w-full object-cover" [attr.alt]="'Job before photo, uploaded ' + p.uploadedAt" />
                }
              </a>
            }
          </div>
        }

        @if (after().length > 0) {
          <p class="mb-1 text-xs uppercase tracking-wider text-[--ps-ink-accent]">After</p>
          <div class="grid grid-cols-4 gap-2">
            @for (p of after(); track p.id) {
              <a
                [href]="p.url"
                target="_blank"
                rel="noopener noreferrer"
                class="block aspect-square overflow-hidden rounded-lg border border-white/10 bg-black/40 focus-visible:outline focus-visible:outline-2 focus-visible:outline-[--ps-accent]"
              >
                @if (video(p)) {
                  <video [src]="p.url" class="h-full w-full object-cover" muted playsinline preload="metadata" [attr.aria-label]="'Job after video, uploaded ' + p.uploadedAt"></video>
                } @else {
                  <img [src]="p.url" loading="lazy" decoding="async" class="h-full w-full object-cover" [attr.alt]="'Job after photo, uploaded ' + p.uploadedAt" />
                }
              </a>
            }
          </div>
        }
      </section>
    } @else if (loadError()) {
      <section hlmCard class="mt-4 p-4" data-testid="booking-photos-error">
        <p class="text-sm text-[--ps-ink]" role="alert">Couldn't load this job's photos.</p>
        <button
          type="button"
          (click)="reload()"
          data-testid="booking-photos-retry"
          class="mt-2 inline-flex items-center gap-1 rounded-md border border-[--ps-accent]/40 px-3 py-1.5 text-xs font-semibold text-[--ps-accent] transition-colors hover:bg-[--ps-accent]/10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-[--ps-accent]"
        >
          Retry
        </button>
      </section>
    }
  `,
})
export class BookingPhotosComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly bookingId = input.required<string>();

  readonly photos = signal<readonly BookingPhoto[]>([]);
  readonly counts = signal<{ start: number; end: number; required: number } | null>(null);
  /**
   * fire-145 — a TRANSIENT fetch failure (network / 5xx) must NOT be conflated
   * with a legitimate empty / 401 / 404 (which correctly self-hides). When true,
   * the gallery shows an error band + Retry instead of silently hiding a
   * completed job's before/after proof (the fire-134 lying-empty class).
   */
  readonly loadError = signal(false);

  readonly before = computed(() => this.photos().filter((p) => photoGroup(p.kind) === 'before'));
  readonly after = computed(() => this.photos().filter((p) => photoGroup(p.kind) === 'after'));

  group(p: BookingPhoto): 'before' | 'after' | 'other' {
    return photoGroup(p.kind);
  }
  video(p: BookingPhoto): boolean {
    return isVideo(p.mime);
  }

  async ngOnInit(): Promise<void> {
    await this.load();
  }

  /**
   * Fetch the job media. 401/404 (not owner / no booking) + an empty result
   * self-hide (photos stays []); a TRANSIENT failure (network status 0 or server
   * 5xx) surfaces an error band + Retry so a real job's proof isn't lost silently.
   */
  async load(): Promise<void> {
    const id = this.bookingId();
    if (!id) return;
    try {
      const res = await firstValueFrom(
        this.http.get<PhotosResponse>(`/api/jobs/${encodeURIComponent(id)}/photos`),
      );
      if (res?.ok) {
        this.photos.set(res.photos ?? []);
        this.counts.set(res.counts ?? null);
      }
      this.loadError.set(false);
    } catch (e: unknown) {
      const status = (e as { status?: number } | null)?.status ?? 0;
      this.loadError.set(status === 0 || status >= 500);
    }
  }

  /** Retry after a transient error (the Retry button). */
  reload(): Promise<void> {
    this.loadError.set(false);
    return this.load();
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'booking-photos-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
