import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
/**
 * BookingsComponent — customer bookings list with Upcoming / Past tabs, rebuilt
 * on the Spartan ui-spartan layer (Wave 3). 4-state via <app-state-block>,
 * status pills via HlmBadge + the shared statusBadge() mapper, RxJS-first data
 * (per rxjs-first-angular: HttpClient observable → toSignal at the template
 * boundary, never firstValueFrom). Contract unchanged: GET
 * /api/customer/jobs?filter=upcoming|past → { ok, items, nextCursor }.
 *
 * A card-list (not a dense SmartTable) is the right surface here — low row
 * count, mobile-first, customer-facing. SmartTable is reserved for the dense,
 * sortable crew/admin browsers (W4/W5).
 */
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { toObservable, toSignal } from '@angular/core/rxjs-interop';
import { of, switchMap, map, startWith, catchError } from 'rxjs';
import { HlmBadge, StateBlockComponent, type SurfaceState } from '../../shared/ui-spartan';
import { fadeUpItem, listStagger, routeFade, reducedMotion } from '../../shared/animations';
import { formatUsdCents } from '@theme.tools/billing/field-service/money';
import { statusBadge } from '@theme.tools/crm/field-service/status-badge';
import { RovingTablistDirective } from '../_shared/roving-tablist.directive';
import { AuthService } from '../../core/auth.service';

interface BookingListItem {
  readonly id: string;
  readonly service: string;
  readonly preferredDate: string;
  readonly preferredTime: string;
  readonly hours: number;
  readonly crew: number;
  readonly totalCents: number;
  readonly status: string;
  readonly paymentStatus: string;
  readonly address: string;
  readonly city: string;
}

interface BookingsResponse {
  readonly ok: boolean;
  readonly items: readonly BookingListItem[];
  readonly nextCursor: string | null;
}

type Filter = 'upcoming' | 'past';

interface LoadState {
  readonly state: SurfaceState;
  readonly items: readonly BookingListItem[];
  readonly error: string;
}

@Component({
  selector: 'app-bookings',
  standalone: true,
  imports: [HlmBadge, StateBlockComponent, RouterLink, RovingTablistDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [listStagger, fadeUpItem, routeFade],
  template: `
    <header class="mb-6">
      <h1 class="text-2xl font-bold text-foreground">Bookings</h1>
      <p class="mt-1 text-sm text-muted-foreground">
        Your upcoming jobs and past visits, all in one place.
      </p>
    </header>

    <div
      role="tablist"
      bclRovingTablist
      aria-label="Booking timeframe"
      class="mb-4 inline-flex rounded-lg border border-border bg-card p-1"
      data-testid="bookings-tabs"
    >
      @for (t of tabs; track t.key) {
        <button
          type="button"
          role="tab"
          [attr.aria-selected]="filter() === t.key"
          (click)="setFilter(t.key)"
          class="min-h-[44px] rounded-md px-4 py-1.5 text-sm font-medium transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
          [class.bg-primary]="filter() === t.key"
          [class.text-primary-foreground]="filter() === t.key"
          [class.text-muted-foreground]="filter() !== t.key"
        >
          {{ t.label }}
        </button>
      }
    </div>

    <app-state-block
      [state]="view().state"
      [errorDetail]="view().error"
      errorTitle="Couldn't load your bookings"
      [emptyTitle]="emptyTitle()"
      [emptyHint]="emptyHint()"
      [emptyCta]="emptyCta()"
      (retry)="reload()"
      (emptyAction)="emptyAction()"
    >
      <!-- Booking rows — staggered fade-up on each enter -->
      <ul
        class="space-y-2"
        [@listStagger]="view().items.length"
        [@.disabled]="reducedMotion()"
      >
        @for (b of view().items; track b.id) {
          <li [@fadeUpItem]>
            <a
              [routerLink]="['/bookings', b.id]"
              class="block min-h-[44px] rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
              [attr.data-testid]="'booking-row-' + b.id"
            >
              <div class="flex items-start justify-between gap-3">
                <div class="min-w-0 flex-1">
                  <div class="mb-1 flex items-center gap-2">
                    <span hlmBadge [variant]="badge(b.paymentStatus).variant">{{
                      badge(b.paymentStatus).label
                    }}</span>
                    <span class="font-mono text-xs uppercase text-muted-foreground">{{
                      b.service
                    }}</span>
                  </div>
                  <p class="truncate text-sm font-medium text-foreground">
                    {{ b.address }}@if (b.city) {<span>, {{ b.city }}</span>}
                  </p>
                  <p class="mt-1 text-xs text-muted-foreground">
                    {{ b.preferredDate }} · {{ b.preferredTime }} · {{ b.hours }}h · crew of
                    {{ b.crew }}
                  </p>
                </div>
                <div class="flex flex-col items-end gap-2">
                  <p class="font-mono text-base tabular-nums text-primary">
                    {{ dollars(b.totalCents) }}
                  </p>
                  @if (filter() === 'past') {
                    <a
                      [routerLink]="['/quotes', 'new']"
                      [queryParams]="{ from: b.id }"
                      (click)="$event.stopPropagation()"
                      class="rounded-md border border-border bg-background px-2 py-1 text-xs text-muted-foreground hover:border-primary hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                    >
                      Rebook →
                    </a>
                  }
                </div>
              </div>
            </a>
          </li>
        }
      </ul>
    </app-state-block>
  `,
})
export class BookingsComponent {
  private readonly http = inject(HttpClient);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly auth = inject(AuthService);

  /**
   * A guest reaching /dashboard/bookings (the shell renders for everyone, no
   * hard redirect) must NOT fire the authed `/api/customer/jobs` fetch — the
   * worker correctly 401s it, but the raw 401 leaks a console error and the
   * surface degrades to a generic "couldn't load" panel. When signed out we
   * skip the request entirely and show a sign-in affordance instead.
   */
  protected readonly needsAuth = computed(() => !this.auth.authenticated());

  /** Bound to [@.disabled] on animated containers — skips all triggers for reduced-motion users. */
  protected readonly reducedMotion = reducedMotion;

  readonly tabs = [
    { key: 'upcoming' as const, label: 'Upcoming' },
    { key: 'past' as const, label: 'Past' },
  ];

  protected readonly badge = statusBadge;

  private readonly initialTab: Filter = (() => {
    const t = this.route.snapshot.queryParamMap.get('tab');
    return t === 'past' ? 'past' : 'upcoming';
  })();

  protected readonly filter = signal<Filter>(this.initialTab);
  /** Manual reload nonce — bump to re-fire the stream after an error retry. */
  private readonly reloadTick = signal(0);

  protected readonly emptyTitle = computed(() => {
    if (this.needsAuth()) return 'Sign in to see your bookings';
    return this.filter() === 'upcoming' ? 'No bookings yet' : 'No past jobs';
  });
  protected readonly emptyHint = computed(() => {
    if (this.needsAuth()) {
      return 'Log in to track upcoming jobs, grab receipts, and rebook in one tap.';
    }
    return this.filter() === 'upcoming'
      ? 'When you book the crew, your jobs will show up here.'
      : 'Once a job wraps up, it lands here with your recap and receipt.';
  });
  protected readonly emptyCta = computed(() => (this.needsAuth() ? 'Sign in →' : 'Book the crew →'));

  /** RxJS-first: filter+reload signals → HTTP → 4-state, bridged at template. */
  private readonly source$ = toObservable(
    computed(() => ({ filter: this.filter(), tick: this.reloadTick(), authed: this.auth.authenticated() })),
  );
  protected readonly view = toSignal(
    this.source$.pipe(
      switchMap(({ filter, authed }) => {
        // Signed out → skip the authed fetch (no console 401); render sign-in empty state.
        if (!authed) return of<LoadState>({ state: 'empty', items: [], error: '' });
        return this.http
          .get<BookingsResponse>(`/api/customer/jobs?filter=${filter}`, { withCredentials: true })
          .pipe(
            map((resp): LoadState => {
              const items = resp?.items ?? [];
              return { state: items.length ? 'ready' : 'empty', items, error: '' };
            }),
            catchError((err) =>
              of<LoadState>({
                state: 'error',
                items: [],
                error: (err as Error)?.message ?? 'Network error',
              }),
            ),
            startWith<LoadState>({ state: 'loading', items: [], error: '' }),
          );
      }),
    ),
    { initialValue: { state: 'loading', items: [], error: '' } as LoadState },
  );

  protected setFilter(f: Filter): void {
    if (this.filter() === f) return;
    this.filter.set(f);
    void this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { tab: f },
      queryParamsHandling: 'merge',
    });
  }

  protected reload(): void {
    this.reloadTick.update((n) => n + 1);
  }

  protected book(): void {
    void this.router.navigateByUrl('/quotes/new');
  }

  /** Empty-state primary action: sign in when signed out, else start a booking. */
  protected emptyAction(): void {
    if (this.needsAuth()) {
      void this.router.navigate(['/login'], { queryParams: { as: 'customer', next: '/bookings' } });
      return;
    }
    this.book();
  }

  protected dollars(cents: number): string {
    return formatUsdCents(cents);
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'bookings-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
