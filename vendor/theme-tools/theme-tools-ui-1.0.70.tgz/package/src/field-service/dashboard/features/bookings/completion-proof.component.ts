import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
/**
 * CompletionProofComponent — the customer's proof-of-work panel on a booking.
 *
 * Renders the read-only completion-package verdict computed by the shared engine
 * (`src/shared/completion-package.ts`) and served at
 * `GET /api/jobs/:bookingId/completion-package`. It is the customer-facing third
 * of the three surfaces that engine feeds (crew "complete" button · THIS proof
 * view · operator dispute evidence) — they all render the IDENTICAL requirement
 * set so a customer sees exactly what gates their job's completion and final
 * charge: 4 before + 4 after photos, the close-out checklist, and (on $500+ jobs)
 * a walkthrough video.
 *
 * Read-only: it REPORTS the package, it never changes the completion gate or
 * moves money. Self-hides when the job has no package state yet, when the fetch
 * is unauthorized (guest 401 / not-found 404 → no console error), so it only
 * appears once a crew has begun documenting the job. Live surface = Angular
 * /dashboard. Dark-cockpit Spartan styling, mirrors the sibling per-booking
 * components (booking-photos, add-to-calendar).
 */
import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  computed,
  inject,
  input,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { HlmCardImports } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

/** One requirement row of the completion package (mirrors the worker engine shape). */
export interface CompletionRequirement {
  readonly id: string;
  readonly label: string;
  readonly satisfied: boolean;
}

/** The completion-package verdict shape returned by the read-only endpoint. */
export interface CompletionAssessment {
  readonly complete: boolean;
  readonly videoRequired: boolean;
  readonly requirements: readonly CompletionRequirement[];
  readonly missing: readonly CompletionRequirement[];
  readonly satisfiedCount: number;
  readonly requiredCount: number;
  /** Satisfaction fraction in [0, 1]. */
  readonly progress: number;
}

interface CompletionPackageResponse {
  readonly ok: boolean;
  readonly bookingId?: string;
  readonly completionLockedAt?: string | null;
  readonly assessment?: CompletionAssessment;
}

/**
 * Whole-percent progress for the proof bar, clamped to [0, 100].
 *
 * @param a - The completion assessment from the endpoint.
 * @returns The satisfaction percentage rounded to an integer in [0, 100].
 * @example completionProofProgressPct({ progress: 4 / 6, ... }) // → 67
 */
export function completionProofProgressPct(a: CompletionAssessment): number {
  const pct = Math.round((a.progress ?? 0) * 100);
  return Math.min(100, Math.max(0, pct));
}

/**
 * Customer-facing headline summarizing the package state.
 *
 * @param a - The completion assessment from the endpoint.
 * @returns A celebratory line when complete, else an "N of M proof steps" count.
 * @example completionProofHeadline({ complete: false, satisfiedCount: 4, requiredCount: 6, ... })
 * // → '4 of 6 proof steps complete'
 */
export function completionProofHeadline(a: CompletionAssessment): string {
  if (a.complete) return 'Your job is fully documented';
  return `${a.satisfiedCount} of ${a.requiredCount} proof steps complete`;
}

/**
 * Same-origin download URL for the customer's 1-page completion-evidence PDF.
 *
 * Hits `GET /api/jobs/:bookingId/completion-package/export` — the matching
 * customer's cookie session authorizes it via `isAuthorizedReader` (email/phone
 * match), so the customer can save the same portable proof record the operator
 * dispute panel exports, for their own files (landlord, insurer, dispute).
 *
 * @param bookingId - The booking whose evidence record to export.
 * @returns The encoded export endpoint path.
 * @example completionProofExportUrl('bk 1') // → '/api/jobs/bk%201/completion-package/export'
 */
export function completionProofExportUrl(bookingId: string): string {
  return `/api/jobs/${encodeURIComponent(bookingId)}/completion-package/export`;
}

@Component({
  selector: 'app-completion-proof',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [HlmCardImports, BclRevealDirective],
  template: `
    @if (assessment(); as a) {
      <section hlmCard bclReveal class="mt-4 p-4" data-testid="completion-proof">
        <header class="mb-3 flex items-center justify-between gap-3">
          <div>
            <h3 class="text-sm font-semibold tracking-wide text-foreground">Proof of work</h3>
            <p class="mt-0.5 text-xs text-muted-foreground">{{ headline() }}</p>
          </div>
          @if (a.complete) {
            <span
              class="rounded-full border border-bcl-success/40 bg-bcl-success/10 px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-bcl-success"
              data-testid="completion-proof-complete"
            >✓ Complete</span>
          } @else {
            <span
              class="rounded-full border border-bcl-accent/30 bg-bcl-accent/10 px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-bcl-accent"
            >In progress</span>
          }
        </header>

        <!-- Progress bar -->
        <div
          class="mb-3 h-1.5 w-full overflow-hidden rounded-full bg-white/10"
          role="progressbar"
          [attr.aria-valuenow]="pct()"
          aria-valuemin="0"
          aria-valuemax="100"
          [attr.aria-label]="'Completion package ' + pct() + ' percent done'"
        >
          <div
            class="h-full rounded-full bg-bcl-accent transition-[width] duration-[333ms] ease-out motion-reduce:transition-none"
            [style.width.%]="pct()"
          ></div>
        </div>

        <!-- Requirement rows -->
        <ul role="list" class="space-y-1.5" aria-label="Completion requirements">
          @for (r of a.requirements; track r.id; let i = $index) {
            <li
              class="flex items-center gap-2 text-sm"
              [style.animation-delay]="i * 50 + 'ms'"
            >
              <span
                class="flex size-4 flex-none items-center justify-center rounded-full font-mono text-[10px] leading-none"
                [class]="r.satisfied
                  ? 'bg-bcl-success/20 text-bcl-success'
                  : 'bg-white/10 text-muted-foreground'"
                aria-hidden="true"
              >{{ r.satisfied ? '✓' : '·' }}</span>
              <span [class]="r.satisfied ? 'text-foreground' : 'text-muted-foreground'">{{ r.label }}</span>
            </li>
          }
        </ul>

        @if (!a.complete) {
          <p class="mt-3 text-xs text-muted-foreground">
            Your crew is still assembling the record. We charge the final balance only
            after the work is documented and either you confirm or the 24-hour window passes.
          </p>
        }

        <!-- Save the portable proof-of-work record (PDF) for your own files -->
        <a
          [href]="exportUrl()"
          target="_blank"
          rel="noopener"
          class="mt-3 inline-flex items-center gap-1.5 rounded-md border border-bcl-accent/40 bg-bcl-accent/10 px-3 py-1.5 font-mono text-[10px] uppercase tracking-wider text-bcl-accent transition-all duration-[333ms] hover:-translate-y-0.5 hover:bg-bcl-accent/20 focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent motion-reduce:transition-none"
          data-testid="completion-proof-export"
          >Save proof of work (PDF)</a
        >
      </section>
    }
  `,
})
export class CompletionProofComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly bookingId = input.required<string>();

  readonly assessment = signal<CompletionAssessment | null>(null);

  protected readonly pct = computed(() => {
    const a = this.assessment();
    return a ? completionProofProgressPct(a) : 0;
  });
  protected readonly headline = computed(() => {
    const a = this.assessment();
    return a ? completionProofHeadline(a) : '';
  });
  protected readonly exportUrl = computed(() => completionProofExportUrl(this.bookingId()));

  async ngOnInit(): Promise<void> {
    const id = this.bookingId();
    if (!id) return;
    try {
      const res = await firstValueFrom(
        this.http.get<CompletionPackageResponse>(
          `/api/jobs/${encodeURIComponent(id)}/completion-package`,
          { withCredentials: true },
        ),
      );
      if (res?.ok && res.assessment) {
        this.assessment.set(res.assessment);
      }
    } catch {
      // Owner-only / not-found / dark → self-hide (assessment stays null).
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'completion-proof-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
