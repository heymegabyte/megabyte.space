import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
/**
 * CalendarComponent — customer view of upcoming + recent bookings.
 *
 * Reads /api/dashboard/feed to pull recent booking events, groups them
 * by day, and surfaces an Apple-Calendar-style next-7-days strip + a
 * detailed list. Keeps the surface dependency-free (no calendar lib);
 * mid-fidelity for first ship, can be upgraded to FullCalendar later.
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  ElementRef,
  computed,
  effect,
  inject,
  signal,
  untracked,
  viewChildren,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RouterLink } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { catchError, finalize, of } from 'rxjs';
import { HlmButton, HlmSkeleton } from '../../shared/ui-spartan';
import { AuthService } from '../../core/auth.service';
import { routeFade, reducedMotion } from '../../shared/animations';

/**
 * Roving-tabindex keyboard navigation for the horizontal 7-day strip. ARIA APG
 * requires a composite widget to be a SINGLE tab stop: arrow keys move the
 * active cell, Home/End jump to the ends. axe-core cannot detect a missing
 * roving pattern (it is an interaction gap, not a static-attribute one), so this
 * pure helper is unit-pinned in the spec instead.
 *
 * @param currentIndex - Index of the currently-active day cell.
 * @param count - Total number of cells (always 7 here; ≥1 required).
 * @param key - The `KeyboardEvent.key` value.
 * @returns The next active index, or `null` when the key is not a navigation key.
 * @example
 * nextDayIndex(0, 7, 'ArrowRight') // → 1
 * nextDayIndex(6, 7, 'ArrowRight') // → 0  (wraps)
 * nextDayIndex(3, 7, 'Home')       // → 0
 * nextDayIndex(1, 7, 'Tab')        // → null
 */
export function nextDayIndex(currentIndex: number, count: number, key: string): number | null {
  if (count <= 0) return null;
  const i = Math.min(Math.max(currentIndex, 0), count - 1);
  if (key === 'ArrowRight' || key === 'ArrowDown') return (i + 1) % count;
  if (key === 'ArrowLeft' || key === 'ArrowUp') return (i - 1 + count) % count;
  if (key === 'Home') return 0;
  if (key === 'End') return count - 1;
  return null;
}

interface FeedEvent {
  readonly id: string;
  readonly kind: string;
  readonly title: string;
  readonly subtitle: string;
  readonly at: string;
  readonly href?: string;
}

interface DayBucket {
  readonly iso: string;
  readonly weekday: string;
  readonly day: number;
  readonly events: readonly FeedEvent[];
  readonly isToday: boolean;
}

@Component({
  selector: 'app-calendar',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  imports: [RouterLink, HlmButton, HlmSkeleton],
  template: `
    <header class="bcl-rise mb-6 rounded-2xl border border-bcl-border bcl-grain p-6">
      <p class="bcl-eyebrow mb-2">Customer · Calendar</p>
      <h1 class="font-display text-3xl font-extrabold tracking-tight text-bcl-ink">
        Your bookings — at a glance
      </h1>
      <p class="mt-2 max-w-2xl text-sm text-bcl-ink-muted">
        Next 7 days plus a chronological event feed. Pick any day — by tap or
        arrow keys — to filter the feed below to just that day.
      </p>
    </header>

    <section
      class="mb-6 grid grid-cols-7 gap-2"
      role="group"
      aria-label="Filter the feed by day — arrow keys move, Enter selects"
    >
      @for (b of next7(); track b.iso; let i = $index) {
        <button
          #dayCell
          type="button"
          data-testid="cal-day"
          class="bcl-glass bcl-fade-in flex flex-col items-center rounded-xl border p-3 text-center transition-[transform,border-color,background-color] duration-[333ms] hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
          [class.border-bcl-accent]="selectedIso() === b.iso"
          [class.bg-bcl-bg-elev]="selectedIso() === b.iso"
          [class.border-bcl-border]="selectedIso() !== b.iso"
          [class.ring-2]="b.isToday && selectedIso() !== b.iso"
          [class.ring-bcl-accent]="b.isToday && selectedIso() !== b.iso"
          [tabindex]="i === rovingIdx() ? 0 : -1"
          [attr.aria-pressed]="selectedIso() === b.iso"
          [attr.aria-label]="dayAria(b)"
          (click)="selectDay(b.iso)"
          (keydown)="onDayKey($event, i)"
        >
          <span class="bcl-eyebrow text-[10px]">{{ b.weekday }}</span>
          <span
            class="bcl-tabular mt-1 font-display text-2xl font-extrabold"
            [class.text-bcl-accent]="b.isToday"
          >
            {{ b.day }}
          </span>
          @if (b.events.length > 0) {
            <span class="mt-2 inline-block size-2 rounded-full bg-bcl-accent"></span>
            <span class="bcl-tabular mt-1 text-[10px] text-bcl-ink-muted">
              {{ b.events.length }}
            </span>
          } @else {
            <span class="mt-2 inline-block size-2 rounded-full bg-bcl-ink-muted/20"></span>
            <span class="bcl-tabular mt-1 text-[10px] text-bcl-ink-muted" aria-hidden="true">—</span>
          }
        </button>
      }
    </section>

    <section>
      <div class="mb-3 flex items-center justify-between gap-3">
        <h2 class="bcl-eyebrow">Detailed event feed</h2>
        @if (selectedIso()) {
          <button
            type="button"
            data-testid="cal-day-clear"
            class="bcl-fade-in inline-flex items-center gap-1 rounded-full border border-bcl-accent/40 px-3 py-1 text-xs font-semibold text-bcl-accent transition-colors duration-[333ms] hover:bg-bcl-accent/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
            (click)="clearDay()"
          >
            {{ selectedLabel() }} · Clear ✕
          </button>
        }
      </div>
      @if (needsAuth()) {
        <!--
          /dashboard/calendar has no role guard, so this renders for guests.
          Skip the authed /api/dashboard/feed fetch (the worker 401s it → a red
          4xx on a signed-out visitor) and show a sign-in affordance instead.
        -->
        <div
          class="rounded-2xl border border-dashed border-bcl-border p-8 text-center"
          data-testid="calendar-signin"
        >
          <p class="text-2xl" aria-hidden="true">📅</p>
          <p class="mt-2 text-base font-semibold text-bcl-ink">Sign in to see your bookings</p>
          <p class="mx-auto mt-1 max-w-md text-sm text-bcl-ink-muted">
            Log in to view your next 7 days plus your full booking, payment, and crew event feed.
          </p>
          <a hlmBtn class="mt-4" [routerLink]="['/login']" [queryParams]="{ as: 'customer', next: '/calendar' }">
            Sign in →
          </a>
        </div>
      } @else if (loading()) {
        <ul class="space-y-2" data-testid="cal-feed-loading" aria-busy="true" aria-label="Loading your feed">
          @for (row of [1, 2, 3, 4]; track row) {
            <li class="bcl-glass flex items-start gap-3 p-4">
              <div class="min-w-0 flex-1 space-y-2">
                <div hlmSkeleton class="h-4 w-1/2"></div>
                <div hlmSkeleton class="h-3 w-3/4"></div>
              </div>
            </li>
          }
        </ul>
      } @else if (error()) {
        <div
          data-testid="cal-feed-error"
          role="alert"
          class="flex items-center justify-between gap-3 rounded-2xl border border-destructive/40 bg-destructive/5 px-4 py-3"
        >
          <p class="text-sm text-foreground">{{ error() }}</p>
          <button hlmBtn variant="outline" size="sm" (click)="reload()">Try again</button>
        </div>
      } @else if (visibleEvents().length === 0) {
        <p
          class="rounded-2xl border border-bcl-border bg-bcl-bg-elev/40 p-6 text-sm text-bcl-ink-muted"
        >
          @if (selectedIso()) {
            Nothing scheduled for {{ selectedLabel() }}. Pick another day or clear
            the filter to see your full feed.
          } @else {
            No recent activity. New bookings, payments, and crew assignments
            appear here as they happen.
          }
        </p>
      } @else {
        <ul class="space-y-2">
          @for (e of visibleEvents(); track e.id) {
            <li class="bcl-glass bcl-fade-in flex items-start gap-3 p-4">
              <span
                aria-hidden="true"
                class="mt-1 inline-block size-2 rounded-full"
                [class.bg-emerald-400]="e.kind === 'booking'"
                [class.bg-amber-400]="e.kind === 'sms' || e.kind === 'inbox'"
                [class.bg-bcl-accent]="e.kind === 'subscription' || e.kind === 'gig'"
                [class.bg-bcl-ink-muted]="e.kind === 'audit' || e.kind === 'system'"
              ></span>
              <div class="flex-1">
                <h3 class="font-semibold text-bcl-ink">{{ e.title }}</h3>
                <p class="mt-0.5 text-sm text-bcl-ink-muted">{{ e.subtitle }}</p>
                <p class="mt-1 font-mono text-[11px] text-bcl-ink-muted">{{ formatAt(e.at) }}</p>
              </div>
              @if (e.href) {
                <a
                  [href]="e.href"
                  class="text-xs text-bcl-accent underline self-center"
                  >Open →</a
                >
              }
            </li>
          }
        </ul>
      }
    </section>
  `,
})
export class CalendarComponent {
  protected readonly reducedMotion = reducedMotion;
  private readonly http = inject(HttpClient);
  private readonly destroyRef = inject(DestroyRef);
  private readonly auth = inject(AuthService);

  protected readonly needsAuth = computed(() => !this.auth.authenticated());

  readonly events = signal<FeedEvent[]>([]);
  readonly loading = signal(true);
  readonly error = signal<string | null>(null);

  /** ISO day the feed is filtered to, or null for the full feed. */
  readonly selectedIso = signal<string | null>(null);
  /** Index of the single tab stop in the 7-day strip (roving tabindex). */
  readonly rovingIdx = signal(0);

  private readonly dayCells = viewChildren<ElementRef<HTMLButtonElement>>('dayCell');

  /** Events scoped to the selected day, or the whole feed when none is picked. */
  readonly visibleEvents = computed<FeedEvent[]>(() => {
    const sel = this.selectedIso();
    if (!sel) return this.events();
    return this.events().filter((e) => {
      const d = new Date(e.at);
      return Number.isFinite(d.getTime()) && d.toISOString().slice(0, 10) === sel;
    });
  });

  /** Human label for the selected day chip, e.g. "WED 24". */
  readonly selectedLabel = computed(() => {
    const sel = this.selectedIso();
    const b = this.next7().find((d) => d.iso === sel);
    return b ? `${b.weekday} ${b.day}` : '';
  });

  readonly next7 = computed<DayBucket[]>(() => {
    const out: DayBucket[] = [];
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const evs = this.events();
    const evsByIso = new Map<string, FeedEvent[]>();
    for (const e of evs) {
      const d = new Date(e.at);
      if (!Number.isFinite(d.getTime())) continue;
      const iso = d.toISOString().slice(0, 10);
      const arr = evsByIso.get(iso) ?? [];
      arr.push(e);
      evsByIso.set(iso, arr);
    }
    for (let i = 0; i < 7; i++) {
      const d = new Date(today);
      d.setDate(today.getDate() + i);
      const iso = d.toISOString().slice(0, 10);
      out.push({
        iso,
        weekday: d.toLocaleDateString(undefined, { weekday: 'short' }).toUpperCase(),
        day: d.getDate(),
        events: evsByIso.get(iso) ?? [],
        isToday: i === 0,
      });
    }
    return out;
  });

  constructor() {
    let wasAuthed = this.auth.authenticated();
    effect(() => {
      const now = this.auth.authenticated();
      if (now && !wasAuthed) {
        untracked(() => this.reload());
      }
      wasAuthed = now;
    });
    this.reload();
  }

  /**
   * (Re)load the booking feed. Guest-reachable route (no role guard): never fire the authed feed
   * fetch when signed out — the worker 401s it. Extracted from the constructor (fire-125) so the
   * error state's "Try again" button can re-drive it; resets `error` + `loading` each call.
   */
  reload(): void {
    this.error.set(null);
    if (!this.auth.authenticated()) {
      this.loading.set(false);
      return;
    }
    this.loading.set(true);
    this.http
      .get<{ ok: boolean; events: FeedEvent[] }>('/api/dashboard/feed', {
        withCredentials: true,
      })
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError((err: { status?: number }) => {
          this.error.set(
            err.status === 401 ? 'Sign in to see your bookings.' : `Failed to load (HTTP ${err.status})`,
          );
          return of({ ok: false, events: [] as FeedEvent[] });
        }),
        finalize(() => this.loading.set(false)),
      )
      .subscribe((r) => this.events.set(r.events ?? []));
  }

  /** Accessible label naming the day + its job count + selected state. */
  dayAria(b: DayBucket): string {
    const n = b.events.length;
    const jobs = n === 0 ? 'no bookings' : `${n} booking${n === 1 ? '' : 's'}`;
    const sel = this.selectedIso() === b.iso ? ', selected' : '';
    return `${b.weekday} ${b.day}, ${jobs}${sel}`;
  }

  /** Toggle the day filter — re-selecting the active day clears it. */
  selectDay(iso: string): void {
    this.selectedIso.update((cur) => (cur === iso ? null : iso));
    const idx = this.next7().findIndex((d) => d.iso === iso);
    if (idx >= 0) this.rovingIdx.set(idx);
  }

  /** Drop the day filter and show the full feed. */
  clearDay(): void {
    this.selectedIso.set(null);
  }

  /** Roving-tabindex arrow navigation across the 7-day strip. */
  onDayKey(event: KeyboardEvent, index: number): void {
    const cells = this.next7();
    const next = nextDayIndex(index, cells.length, event.key);
    if (next === null) return;
    event.preventDefault();
    this.rovingIdx.set(next);
    this.dayCells()[next]?.nativeElement.focus();
  }

  formatAt(iso: string): string {
    try {
      return new Date(iso).toLocaleString(undefined, {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
      });
    } catch {
      return iso;
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'calendar-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
