import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * DayViewComponent — the single-day time-grid of the Brick Labor dispatch
 * calendar (/dashboard/calendar/day).
 *
 * A focused one-day view at finer 30-minute resolution: a half-hour-label
 * column + a single day column, with every /api/admin/bookings job for that
 * date placed in its start half-hour slot, height scaled by booked `hours`,
 * color-coded by service. Jobs with no parseable time fall into an "Untimed"
 * rail. Prev/next-day + Today navigation, URL-synced (?d=YYYY-MM-DD), and a
 * per-day operations strip (jobs · crew-hours · labor revenue) from the server's
 * canonical fields — never recomputed or invented.
 *
 * Mirrors WeekViewComponent's data + parsing + color logic at 30-min granularity.
 * The $50/hr legend mirrors the canonical worker HOURLY_RATE_CENTS (display-only;
 * server totals authoritative). Dependency-free, Spartan black/orange. Flag-gated
 * by `dashboard_calendar` at the route level.
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  effect,
  inject,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { catchError, finalize, of } from 'rxjs';
import { HOURLY_RATE_CENTS } from './week-view.component';
import { A11yModule } from '@angular/cdk/a11y';
import { JobDetailDrawerComponent } from './job-detail-drawer.component';
import { QuickCreateComponent, type CreatedBooking } from './quick-create.component';
import { detectConflicts, parseHourValue } from '@theme.tools/scheduling/field-service/calendar-conflicts';
import { RecurringContractsService } from './recurring-contracts.service';
import { projectOccurrences, occurrencePriceCents, type Occurrence } from '@theme.tools/scheduling/field-service/recurring-occurrences';
import { FreeBusyService } from './free-busy.service';
import { routeFade, reducedMotion } from '../../shared/animations';
import { HlmSkeleton } from '../../shared/ui-spartan';
import { CrewAssignmentsService } from './crew-assignments.service';
import { FeatureFlagService } from '../../core/feature-flag.service';

interface Booking {
  readonly id: string;
  readonly status: string;
  readonly customer_name: string | null;
  readonly city: string | null;
  readonly preferred_date: string | null;
  readonly preferred_time: string | null;
  readonly services_csv: string | null;
  readonly hours: number | null;
  readonly crew: number | null;
  readonly total_cents: number | null;
}

interface PlacedBooking {
  readonly booking: Booking;
  readonly startHour: number;
  readonly rowSpan: number; // in 30-min rows
}

const SLOT_START = 6; // 6am
const SLOT_END = 21; // 9pm
// Half-hour slots: 6.0, 6.5, … 21.0
const SLOTS: readonly number[] = Array.from(
  { length: (SLOT_END - SLOT_START) * 2 + 1 },
  (_, i) => SLOT_START + i * 0.5,
);

@Component({
  selector: 'app-calendar-day',
  standalone: true,
  imports: [RouterLink, A11yModule, JobDetailDrawerComponent, QuickCreateComponent, HlmSkeleton],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <header
      class="bcl-rise mb-5 flex flex-wrap items-end justify-between gap-4 rounded-2xl border border-bcl-border bcl-grain p-6"
    >
      <div class="min-w-0">
        <p class="bcl-eyebrow mb-2">Dispatch · Calendar</p>
        <h1 class="font-display text-3xl font-extrabold tracking-tight text-bcl-ink">
          {{ dayLabel() }}
        </h1>
        <p class="mt-2 text-sm text-bcl-ink-muted">
          {{ tz() }} · $50/hr per crew member · 1-hr min · 15-min blocks
        </p>
      </div>

      <div class="flex flex-wrap items-center gap-2">
        <nav
          class="flex overflow-hidden rounded-lg border border-bcl-border"
          aria-label="Calendar views"
        >
          <a
            routerLink="/calendar/month"
            class="px-3 py-1.5 text-xs text-bcl-ink-muted hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
            >Month</a
          >
          <a
            routerLink="/calendar/week"
            class="border-l border-bcl-border px-3 py-1.5 text-xs text-bcl-ink-muted hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
            >Week</a
          >
          <a
            routerLink="/calendar/day"
            class="border-l border-bcl-border bg-bcl-accent px-3 py-1.5 text-xs font-semibold text-bcl-bg focus-visible:outline focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-bcl-bg"
            aria-current="page"
            >Day</a
          >
          <a
            routerLink="/calendar/schedule"
            class="border-l border-bcl-border px-3 py-1.5 text-xs text-bcl-ink-muted hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
            >Schedule</a
          >
        </nav>
        <div class="flex items-center gap-1">
          <button
            type="button"
            (click)="prevDay()"
            class="grid size-9 place-items-center rounded-lg border border-bcl-border text-bcl-ink-muted transition-colors hover:border-bcl-accent hover:text-bcl-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
            aria-label="Previous day"
          >
            ‹
          </button>
          <button
            type="button"
            (click)="goToday()"
            class="rounded-lg border border-bcl-border px-3 py-1.5 text-xs font-semibold text-bcl-ink transition-colors hover:border-bcl-accent hover:text-bcl-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
            data-testid="cal-day-today"
          >
            Today
          </button>
          <button
            type="button"
            (click)="nextDay()"
            class="grid size-9 place-items-center rounded-lg border border-bcl-border text-bcl-ink-muted transition-colors hover:border-bcl-accent hover:text-bcl-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
            aria-label="Next day"
          >
            ›
          </button>
        </div>
        <button
          type="button"
          (click)="quickOpen.set(true)"
          class="rounded-lg bg-bcl-accent px-3 py-1.5 text-xs font-semibold text-bcl-bg transition-all duration-[333ms] hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent focus-visible:ring-offset-2 focus-visible:ring-offset-bcl-bg"
          data-testid="cal-day-new"
        >
          + New job
        </button>
      </div>
    </header>

    <section class="mb-5 grid grid-cols-3 gap-3" data-testid="cal-day-metrics">
      <div class="bcl-glass p-4">
        <p class="bcl-eyebrow text-[10px]">Scheduled jobs</p>
        <p
          class="bcl-tabular mt-1 font-display text-2xl font-extrabold text-bcl-ink"
          data-testid="cal-day-jobs"
        >
          {{ jobCount() }}
        </p>
      </div>
      <div class="bcl-glass p-4">
        <p class="bcl-eyebrow text-[10px]">Crew-hours</p>
        <p class="bcl-tabular mt-1 font-display text-2xl font-extrabold text-bcl-ink">
          {{ crewHours() }}
        </p>
      </div>
      <div class="bcl-glass p-4">
        <p class="bcl-eyebrow text-[10px]">Labor revenue</p>
        <p
          class="bcl-tabular mt-1 font-display text-2xl font-extrabold text-bcl-accent"
          data-testid="cal-day-revenue"
        >
          {{ revenueLabel() }}
        </p>
      </div>
    </section>

    @if (error()) {
      <p
        class="mb-3 rounded-2xl border border-amber-500/30 bg-amber-500/5 p-4 text-sm text-amber-300"
        role="alert"
      >
        {{ error() }}
      </p>
    }

    @if (conflictIds().size > 0) {
      <p
        class="mb-3 rounded-2xl border border-amber-500/40 bg-amber-500/10 p-3 text-sm text-amber-200"
        role="status"
        data-testid="cal-day-conflicts"
      >
        @if (crewAware()) {
          ⚠ {{ conflictIds().size }} job(s) double-book the same crew member today — reassign or
          reschedule.
        } @else {
          ⚠ {{ conflictIds().size }} job(s) overlap in time today — confirm crew coverage.
        }
      </p>
    }

    @if (crewRoster().length) {
      <div
        class="mb-3 flex flex-wrap items-center gap-2"
        role="group"
        aria-label="Crew view"
        data-testid="cal-day-crew-filter"
      >
        <button
          type="button"
          (click)="toggleLaneMode()"
          class="rounded-full border px-3 py-1 text-xs font-semibold transition-all duration-[333ms] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
          [class]="
            laneMode()
              ? 'border-bcl-accent bg-bcl-accent text-bcl-bg'
              : 'border-bcl-border text-bcl-ink-muted hover:border-bcl-accent hover:text-bcl-accent'
          "
          [attr.aria-pressed]="laneMode()"
          data-testid="cal-day-lane-toggle"
        >
          {{ laneMode() ? '↤ Time grid' : '⬓ Crew lanes' }}
        </button>
        @if (!laneMode()) {
          <button
            type="button"
            (click)="setCrewFilter(null)"
            class="rounded-full border px-3 py-1 text-xs font-medium transition-all duration-[333ms] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
            [class]="
              crewFilter() === null
                ? 'border-bcl-accent bg-bcl-accent text-bcl-bg'
                : 'border-bcl-border text-bcl-ink-muted hover:border-bcl-accent hover:text-bcl-accent'
            "
            [attr.aria-pressed]="crewFilter() === null"
          >
            All crew
          </button>
          @for (m of crewRoster(); track m.id) {
            <button
              type="button"
              (click)="setCrewFilter(m.id)"
              class="rounded-full border px-3 py-1 text-xs font-medium transition-all duration-[333ms] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
              [class]="
                crewFilter() === m.id
                  ? 'border-bcl-accent bg-bcl-accent text-bcl-bg'
                  : 'border-bcl-border text-bcl-ink-muted hover:border-bcl-accent hover:text-bcl-accent'
              "
              [attr.aria-pressed]="crewFilter() === m.id"
            >
              {{ m.name }}
            </button>
          }
        }
      </div>
    }

    @if (pendingMove(); as mv) {
      <div
        class="mb-3 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-bcl-accent/40 bg-bcl-accent/10 p-3 text-sm text-bcl-ink"
        role="alertdialog"
        aria-label="Confirm reschedule"
        data-testid="cal-day-move"
        cdkTrapFocus
        [cdkTrapFocusAutoCapture]="true"
        (keydown.escape)="cancelMove()"
      >
        <span
          >Move <strong>{{ mv.customer }}</strong> from {{ mv.from }} to <strong>{{ mv.to }}</strong
          >?</span
        >
        <span class="flex gap-2">
          <button
            type="button"
            (click)="confirmMove()"
            [disabled]="moving()"
            class="rounded-lg bg-bcl-accent px-3 py-1.5 text-xs font-semibold text-bcl-bg transition-all duration-[333ms] disabled:opacity-50 hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
            data-testid="cal-day-move-confirm"
          >
            {{ moving() ? 'Moving…' : 'Confirm' }}
          </button>
          <button
            type="button"
            (click)="cancelMove()"
            class="rounded-lg border border-bcl-border px-3 py-1.5 text-xs text-bcl-ink-muted transition-colors hover:border-bcl-accent hover:text-bcl-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
          >
            Cancel
          </button>
        </span>
      </div>
    }
    @if (moveError()) {
      <p
        class="mb-3 rounded-2xl border border-rose-500/30 bg-rose-500/5 p-3 text-xs text-rose-300"
        role="alert"
      >
        {{ moveError() }}
      </p>
    }

    @if (movingId()) {
      <p
        class="mb-3 flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-bcl-accent/40 bg-bcl-accent/10 p-3 text-sm text-bcl-ink"
        role="status"
        data-testid="cal-day-arm-hint"
      >
        <span>Pick a time slot to reschedule this job — no dragging needed.</span>
        <button
          type="button"
          (click)="cancelArm()"
          class="rounded-lg border border-bcl-border px-3 py-1.5 text-xs text-bcl-ink-muted transition-colors hover:border-bcl-accent hover:text-bcl-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
        >
          Cancel
        </button>
      </p>
    }

    @if (untimed().length) {
      <div class="mb-px grid border border-bcl-border" style="grid-template-columns: 4rem 1fr">
        <div
          class="grid place-items-center bg-bcl-bg py-1.5 text-[9px] uppercase tracking-wider text-bcl-ink-muted"
        >
          Any
        </div>
        <div class="bg-bcl-bg p-1.5">
          <ul class="flex flex-wrap gap-1">
            @for (b of untimed(); track b.id) {
              <li>
                <button
                  type="button"
                  [class]="chipClass(b) + ' w-full text-left'"
                  [title]="chipTitle(b)"
                  (click)="open(b)"
                >
                  {{ primaryService(b) }}
                </button>
              </li>
            }
          </ul>
        </div>
      </div>
    }

    @if (recurringUntimed().length) {
      <div
        class="mb-px grid border border-bcl-border"
        style="grid-template-columns: 4rem 1fr"
        data-testid="cal-day-recurring"
      >
        <div
          class="grid place-items-center bg-bcl-bg py-1.5 text-[9px] uppercase tracking-wider text-bcl-accent/70"
        >
          ↻
        </div>
        <div class="bg-bcl-bg p-1.5">
          <ul class="flex flex-wrap gap-1">
            @for (o of recurringUntimed(); track o.contractId) {
              <li>
                <span
                  class="block truncate rounded-md border border-dashed border-bcl-accent/50 bg-bcl-accent/5 px-1.5 py-1 text-[11px] leading-tight text-bcl-accent/80"
                  [title]="occTitle(o)"
                  >↻ {{ o.service }}</span
                >
              </li>
            }
          </ul>
        </div>
      </div>
    }

    @if (busyDay().length) {
      <div
        class="mb-px grid border border-bcl-border"
        style="grid-template-columns: 4rem 1fr"
        data-testid="cal-day-busy"
      >
        <div
          class="grid place-items-center bg-bcl-bg py-1.5 text-[9px] uppercase tracking-wider text-bcl-ink-muted"
        >
          ⊘
        </div>
        <div class="bg-bcl-bg p-1.5">
          <ul class="flex flex-wrap gap-1">
            @for (iv of busyDay(); track iv.start) {
              <li>
                <span
                  class="block truncate rounded-md bg-bcl-ink-muted/10 px-1.5 py-1 text-[11px] leading-tight text-bcl-ink-muted"
                  [title]="'Busy on Google Calendar'"
                  >busy {{ fmtRange(iv) }}</span
                >
              </li>
            }
          </ul>
        </div>
      </div>
    }

    @if (laneMode()) {
      <!-- Crew swimlanes: one lane per active crew member + an Unassigned lane -->
      <div
        class="flex gap-3 overflow-x-auto pb-2"
        role="group"
        [attr.aria-label]="'Crew lanes for ' + dayLabel()"
        data-testid="cal-day-lanes"
      >
        @for (lane of lanes(); track lane.id) {
          <section
            class="min-w-[12rem] flex-1 rounded-2xl border border-bcl-border bg-bcl-bg-elev/40 p-2"
            [attr.aria-label]="lane.name + ' lane'"
          >
            <header class="mb-2 flex items-center justify-between px-1">
              <h3 class="truncate text-xs font-semibold text-bcl-ink">{{ lane.name }}</h3>
              <span class="bcl-tabular text-[10px] text-bcl-ink-muted">{{
                lane.bookings.length
              }}</span>
            </header>
            <ul class="space-y-1">
              @for (b of lane.bookings; track b.id) {
                <li>
                  <button
                    type="button"
                    [class]="chipClass(b) + ' w-full text-left' + conflictCls(b)"
                    [title]="chipTitle(b)"
                    (click)="open(b)"
                  >
                    {{ b.preferred_time ?? 'untimed' }} · {{ primaryService(b) }}
                    @if (b.hours) {
                      · {{ b.hours }}h
                    }
                  </button>
                </li>
              } @empty {
                <li class="px-1 py-2 text-[10px] text-bcl-ink-muted">No jobs</li>
              }
            </ul>
          </section>
        }
      </div>
    } @else {
      <div
        class="grid overflow-hidden rounded-2xl border border-bcl-border bg-bcl-border"
        style="grid-template-columns: 4rem 1fr; gap: 1px"
        role="group"
        [attr.aria-label]="'Day time grid for ' + dayLabel()"
        data-testid="cal-day-grid"
      >
        @for (s of slots; track s) {
          <div class="bg-bcl-bg px-1.5 py-1 text-right bcl-tabular text-[10px] text-bcl-ink-muted">
            {{ slotLabel(s) }}
          </div>
          <div
            class="min-h-[34px] bg-bcl-bg p-1 transition-colors"
            [class.bg-bcl-accent]="dropSlot() === s"
            [class.bg-opacity-10]="dropSlot() === s"
            [class.ring-2]="isMoveTarget(s)"
            [class.ring-inset]="isMoveTarget(s)"
            [class.ring-bcl-accent]="isMoveTarget(s)"
            [class.cursor-pointer]="isMoveTarget(s)"
            [class.focus-visible:outline-none]="isMoveTarget(s)"
            [class.focus-visible:ring-2]="isMoveTarget(s)"
            [attr.role]="isMoveTarget(s) ? 'button' : null"
            [attr.tabindex]="isMoveTarget(s) ? 0 : null"
            [attr.data-testid]="isMoveTarget(s) ? 'cal-move-target' : null"
            [attr.aria-label]="
              isMoveTarget(s) ? 'Reschedule the selected job to ' + slotLabel(s) : null
            "
            (click)="isMoveTarget(s) && activateSlot(s)"
            (keydown.enter)="isMoveTarget(s) && activateSlot(s)"
            (keydown.space)="isMoveTarget(s) && $event.preventDefault(); isMoveTarget(s) && activateSlot(s)"
            (dragover)="onDragOver($event, s)"
            (dragleave)="onDragLeave(s)"
            (drop)="onDrop($event, s)"
          >
            <ul class="space-y-1">
              @for (p of bySlot().get(s) ?? []; track p.booking.id) {
                <li class="flex items-stretch gap-0.5" [style.min-height.px]="p.rowSpan * 30">
                  <button
                    type="button"
                    draggable="true"
                    (dragstart)="onDragStart($event, p.booking.id)"
                    [class]="
                      chipClass(p.booking) +
                      ' min-w-0 flex-1 cursor-grab text-left active:cursor-grabbing' +
                      conflictCls(p.booking)
                    "
                    [title]="chipTitle(p.booking)"
                    (click)="open(p.booking)"
                  >
                    {{ fmtTime(p.startHour) }} · {{ primaryService(p.booking) }}
                    @if (p.booking.hours) {
                      · {{ p.booking.hours }}h
                    }
                    @if (p.booking.crew) {
                      · {{ p.booking.crew }} crew
                    }
                  </button>
                  <!-- Single-pointer + keyboard reschedule alternative to drag
                       (WCAG 2.5.7 / 2.1.1): arms the job, then a time slot becomes
                       a click/Enter target. ≥24px (2.5.8). -->
                  <button
                    type="button"
                    (click)="armMove(p.booking.id)"
                    (keydown.enter)="$event.preventDefault(); armMove(p.booking.id)"
                    (keydown.space)="$event.preventDefault(); armMove(p.booking.id)"
                    [attr.aria-pressed]="movingId() === p.booking.id"
                    [attr.aria-label]="
                      movingId() === p.booking.id
                        ? 'Cancel moving ' + (p.booking.customer_name ?? 'job') + ' — pick a time, or press to cancel'
                        : 'Move ' + (p.booking.customer_name ?? 'job') + ' to another time without dragging'
                    "
                    [title]="movingId() === p.booking.id ? 'Cancel move' : 'Move to another time (no drag)'"
                    class="grid min-h-[24px] w-6 shrink-0 place-items-center rounded-md border text-[11px] leading-none transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
                    [class.border-bcl-accent]="movingId() === p.booking.id"
                    [class.bg-bcl-accent]="movingId() === p.booking.id"
                    [class.text-bcl-bg]="movingId() === p.booking.id"
                    [class.border-bcl-border]="movingId() !== p.booking.id"
                    [class.text-bcl-ink-muted]="movingId() !== p.booking.id"
                    [class.hover:border-bcl-accent]="movingId() !== p.booking.id"
                    [class.hover:text-bcl-accent]="movingId() !== p.booking.id"
                    data-testid="cal-move-chip"
                  >
                    @if (movingId() === p.booking.id) {
                      ✕
                    } @else {
                      ⇄
                    }
                  </button>
                </li>
              }
            </ul>
            @if (recurringBySlot().get(s); as occs) {
              <ul class="mt-1 space-y-1" data-testid="cal-day-recurring-slot">
                @for (o of occs; track o.contractId) {
                  <li>
                    <span
                      class="block truncate rounded-md border border-dashed border-bcl-accent/50 bg-bcl-accent/5 px-1.5 py-0.5 text-[11px] leading-tight text-bcl-accent/80"
                      [title]="occTitle(o)"
                      >↻ {{ o.time }} · {{ o.service }}</span
                    >
                  </li>
                }
              </ul>
            }
          </div>
        }
      </div>
    }

    @if (loading()) {
      <div
        class="mt-3 space-y-2"
        data-testid="cal-day-loading"
        aria-busy="true"
        aria-label="Loading schedule"
      >
        @for (row of [1, 2, 3]; track row) {
          <div class="bcl-glass flex items-center gap-3 p-3">
            <div hlmSkeleton class="h-4 w-14 shrink-0"></div>
            <div hlmSkeleton class="h-4 flex-1"></div>
          </div>
        }
      </div>
    } @else if (jobCount() === 0 && !error()) {
      <p
        class="mt-3 rounded-2xl border border-bcl-border bg-bcl-bg-elev/40 p-6 text-center text-sm text-bcl-ink-muted"
        data-testid="cal-day-empty"
      >
        No jobs scheduled for this day. Booked jobs and recurring contracts appear here in their
        time slots.
      </p>
    }

    <app-job-detail-drawer
      [booking]="selected()"
      (updated)="onUpdated($event)"
      (closed)="selected.set(null)"
    />
    <app-quick-create
      [open]="quickOpen()"
      [defaultDate]="dayIso()"
      (created)="onCreated($event)"
      (closed)="quickOpen.set(false)"
    />
  `,
})
export class DayViewComponent {
  protected readonly reducedMotion = reducedMotion;
  private readonly http = inject(HttpClient);
  private readonly destroyRef = inject(DestroyRef);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);

  readonly slots = SLOTS;
  readonly bookings = signal<Booking[]>([]);
  /** The job whose detail drawer is open (null = closed). */
  readonly selected = signal<Booking | null>(null);
  /** Whether the quick-create popover is open. */
  readonly quickOpen = signal(false);
  private readonly crewAssignments = inject(CrewAssignmentsService);
  private readonly flags = inject(FeatureFlagService);
  /** When on, conflict detection tightens to per-crew (same worker double-booked). */
  readonly crewAware = this.flags.isOn('calendar_crew_resource_view');
  /**
   * Booking ids that conflict on the same day. Default: any time overlap
   * (coverage warning). Crew-aware (flag on): only when the overlapping jobs
   * share an assigned worker — a real per-crew double-booking.
   */
  readonly conflictIds = computed(() => {
    const crewAware = this.crewAware();
    if (!crewAware) return detectConflicts(this.bookings());
    const byBooking = this.crewAssignments.byBooking();
    const items = this.bookings().map((b) => ({ ...b, workerIds: byBooking.get(b.id) ?? [] }));
    return detectConflicts(items, { crewAware: true });
  });

  /** Amber conflict ring appended to a chip when it overlaps another job. */
  conflictCls(b: Booking): string {
    return this.conflictIds().has(b.id) ? ' ring-2 ring-inset ring-amber-400/70' : '';
  }

  private readonly recurring = inject(RecurringContractsService);
  /** Recurring-contract occurrences projected onto the anchored day. */
  readonly recurringDay = computed<Occurrence[]>(() => {
    const iso = this.dayIso();
    const out: Occurrence[] = [];
    for (const ct of this.recurring.contracts()) out.push(...projectOccurrences(ct, iso, iso));
    return out;
  });
  /** Occurrences with no run-time (or off-grid) → the rail. */
  readonly recurringUntimed = computed<Occurrence[]>(() =>
    this.recurringDay().filter((o) => {
      const h = this.parseHour(o.time);
      return h === null || h < SLOT_START || h > SLOT_END;
    }),
  );
  /** Timed occurrences placed in the grid by start half-hour slot. */
  readonly recurringBySlot = computed<Map<number, Occurrence[]>>(() => {
    const map = new Map<number, Occurrence[]>();
    for (const o of this.recurringDay()) {
      const h = this.parseHour(o.time);
      if (h === null || h < SLOT_START || h > SLOT_END) continue;
      const slot = Math.floor(h * 2) / 2;
      const arr = map.get(slot) ?? [];
      arr.push(o);
      map.set(slot, arr);
    }
    return map;
  });
  occTitle(o: Occurrence): string {
    const price = occurrencePriceCents(HOURLY_RATE_CENTS, o.hours, o.crew, o.frequency);
    const who = o.customer_name ?? 'Recurring';
    return `${who} — ${o.service} · ${o.hours}h × ${o.crew} crew · ~$${(price / 100).toFixed(0)} (${o.frequency} contract)`;
  }

  private readonly freeBusy = inject(FreeBusyService);
  /** Google free/busy intervals that fall on the anchored day. */
  readonly busyDay = computed<{ start: string; end: string }[]>(() =>
    this.freeBusy.busy().filter((iv) => (iv.start ?? '').slice(0, 10) === this.dayIso()),
  );
  fmtRange(iv: { start: string; end: string }): string {
    return `${iv.start.slice(11, 16)}–${iv.end.slice(11, 16)}`;
  }
  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly dayIso = signal<string>(this.initialDay());
  readonly tz = signal<string>(this.resolveTz());
  /** Exposed for the guard test parity with the week view. */
  readonly hourlyRateCents = HOURLY_RATE_CENTS;

  /** Active-crew roster for the filter chips + swimlanes (empty when flag off). */
  readonly crewRoster = computed(() => (this.crewAware() ? this.crewAssignments.roster() : []));
  /** Selected crew member to filter the day by (null = all crew). */
  readonly crewFilter = signal<string | null>(null);
  setCrewFilter(id: string | null): void {
    this.crewFilter.set(this.crewFilter() === id ? null : id);
  }
  /** Swimlane mode (crew lanes) vs the default time grid. */
  readonly laneMode = signal(false);
  toggleLaneMode(): void {
    this.laneMode.set(!this.laneMode());
  }

  /** All of the day's jobs (date filter only) — the swimlanes split this by crew. */
  private readonly datedBookings = computed<Booking[]>(() =>
    this.bookings().filter((b) => (b.preferred_date ?? '').slice(0, 10) === this.dayIso()),
  );

  private readonly dayBookings = computed<Booking[]>(() => {
    const filterId = this.crewFilter();
    const byBooking = this.crewAssignments.byBooking();
    return this.datedBookings().filter((b) => {
      // Crew filter (only meaningful in crew-aware mode): keep jobs the selected
      // worker is assigned to.
      if (filterId && this.crewAware()) return (byBooking.get(b.id) ?? []).includes(filterId);
      return true;
    });
  });

  /**
   * Crew swimlanes: one lane per active crew member (jobs they're assigned to)
   * plus a trailing "Unassigned" lane for jobs with no claimed crew. A job with
   * two crew appears in both their lanes (standard resource-lane model).
   */
  readonly lanes = computed<{ id: string; name: string; bookings: Booking[] }[]>(() => {
    const byBooking = this.crewAssignments.byBooking();
    const dated = this.datedBookings();
    const out = this.crewRoster().map((m) => ({
      id: m.id,
      name: m.name,
      bookings: dated.filter((b) => (byBooking.get(b.id) ?? []).includes(m.id)),
    }));
    const unassigned = dated.filter((b) => (byBooking.get(b.id) ?? []).length === 0);
    out.push({ id: '__unassigned', name: 'Unassigned', bookings: unassigned });
    return out;
  });

  readonly untimed = computed<Booking[]>(() =>
    this.dayBookings().filter((b) => {
      const h = this.parseHour(b.preferred_time);
      return h === null || h < SLOT_START || h > SLOT_END;
    }),
  );

  readonly bySlot = computed<Map<number, PlacedBooking[]>>(() => {
    const map = new Map<number, PlacedBooking[]>();
    for (const b of this.dayBookings()) {
      const startHour = this.parseHour(b.preferred_time);
      if (startHour === null || startHour < SLOT_START || startHour > SLOT_END) continue;
      const slot = Math.floor(startHour * 2) / 2; // snap to nearest lower half-hour
      const rowSpan = Math.max(1, Math.round((b.hours ?? 1) * 2)); // hours → 30-min rows
      const arr = map.get(slot) ?? [];
      arr.push({ booking: b, startHour, rowSpan });
      map.set(slot, arr);
    }
    return map;
  });

  readonly jobCount = computed<number>(() => this.dayBookings().length);
  readonly crewHours = computed<number>(() =>
    this.dayBookings().reduce((n, b) => n + (b.hours ?? 0) * Math.max(1, b.crew ?? 1), 0),
  );
  readonly revenueLabel = computed<string>(() => {
    const cents = this.dayBookings().reduce((n, b) => n + (b.total_cents ?? 0), 0);
    return `$${(cents / 100).toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
  });

  readonly dayLabel = computed<string>(() =>
    this.parseIso(this.dayIso()).toLocaleDateString(undefined, {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      year: 'numeric',
    }),
  );

  constructor() {
    this.recurring.load(); // recurring overlay (no-op when flag off → 404 → [])
    // Google free/busy overlay — re-query when the anchored day changes.
    effect(() => {
      const iso = this.dayIso();
      this.freeBusy.load(`${iso}T00:00:00Z`, `${iso}T23:59:59Z`);
    });
    // Per-crew conflict data — load the day's assignments when the flag is on
    // (server 404s when off → empty map → falls back to the time-overlap warning).
    effect(() => {
      const iso = this.dayIso();
      if (this.crewAware()) this.crewAssignments.load(iso, iso);
    });
    this.http
      .get<{ ok: boolean; bookings: Booking[] }>('/api/admin/bookings?limit=500', {
        withCredentials: true,
      })
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError((err: { status?: number }) => {
          this.error.set(
            err.status === 401
              ? 'Sign in as an operator to view the dispatch calendar.'
              : `Failed to load the schedule (HTTP ${err.status}).`,
          );
          return of({ ok: false, bookings: [] as Booking[] });
        }),
        finalize(() => this.loading.set(false)),
      )
      .subscribe((r) => this.bookings.set(r.bookings ?? []));
  }

  prevDay(): void {
    this.shiftDay(-1);
  }
  nextDay(): void {
    this.shiftDay(1);
  }
  goToday(): void {
    this.setDay(this.isoDate(new Date()));
  }

  /** Open the job-detail drawer for a chip. */
  open(b: Booking): void {
    this.selected.set(b);
  }

  /** Drawer saved a status change — reflect it in the loaded list (canonical
   *  revenue/hours unchanged; only status mutates). */
  onUpdated(updated: {
    id: string;
    status: string;
    hours: number | null;
    total_cents: number | null;
  }): void {
    this.bookings.update((list) =>
      list.map((b) =>
        b.id === updated.id
          ? { ...b, status: updated.status, hours: updated.hours, total_cents: updated.total_cents }
          : b,
      ),
    );
    this.selected.set(null);
  }

  /** Quick-create returned a new booking — add it to the loaded list so it
   *  appears immediately (it lands on its preferred_date slot). */
  onCreated(b: CreatedBooking): void {
    this.bookings.update((list) => [...list, b as unknown as Booking]);
    this.quickOpen.set(false);
  }

  // ── Time-drag-reschedule (drop a job chip onto a different 30-min slot) ────
  private readonly draggingId = signal<string | null>(null);
  readonly dropSlot = signal<number | null>(null);
  /**
   * Keyboard + single-pointer reschedule (WCAG 2.5.7 / 2.1.1). `movingId` is the
   * booking a "Move" button armed — while set, every time slot becomes a focusable
   * click/Enter target reaching the SAME `pendingMove` the drag reaches, no drag.
   */
  readonly movingId = signal<string | null>(null);
  readonly pendingMove = signal<{
    id: string;
    customer: string;
    from: string;
    to: string;
    slot: number;
  } | null>(null);
  readonly moving = signal(false);
  readonly moveError = signal<string | null>(null);

  onDragStart(ev: DragEvent, id: string): void {
    this.draggingId.set(id);
    ev.dataTransfer?.setData('text/plain', id);
    if (ev.dataTransfer) ev.dataTransfer.effectAllowed = 'move';
  }
  onDragOver(ev: DragEvent, slot: number): void {
    ev.preventDefault();
    if (this.dropSlot() !== slot) this.dropSlot.set(slot);
  }
  onDragLeave(slot: number): void {
    if (this.dropSlot() === slot) this.dropSlot.set(null);
  }
  onDrop(ev: DragEvent, slot: number): void {
    ev.preventDefault();
    this.dropSlot.set(null);
    const id = ev.dataTransfer?.getData('text/plain') || this.draggingId();
    this.draggingId.set(null);
    if (!id) return;
    const b = this.bookings().find((x) => x.id === id);
    if (!b) return;
    const cur = this.parseHour(b.preferred_time);
    if (cur !== null && Math.floor(cur * 2) / 2 === slot) return; // same slot — no-op
    this.stageMove(b, slot);
  }

  // ── Keyboard / single-pointer reschedule (no drag) ────────────────────────
  /** Arm a job for a no-drag time move ("Move" button click OR Enter/Space). */
  armMove(id: string): void {
    this.movingId.set(this.movingId() === id ? null : id);
    this.dropSlot.set(null);
    this.moveError.set(null);
  }
  /** Cancel an armed move without rescheduling. */
  cancelArm(): void {
    this.movingId.set(null);
  }
  /** True while a time slot should act as a click/keyboard reschedule target. */
  isMoveTarget(slot: number): boolean {
    const id = this.movingId();
    if (!id) return false;
    const b = this.bookings().find((x) => x.id === id);
    if (!b) return false;
    const cur = this.parseHour(b.preferred_time);
    return cur === null || Math.floor(cur * 2) / 2 !== slot; // never its own slot
  }
  /** Activate a target slot (click or Enter/Space) → stage the same reschedule. */
  activateSlot(slot: number): void {
    const id = this.movingId();
    if (!id) return;
    const b = this.bookings().find((x) => x.id === id);
    this.movingId.set(null);
    if (!b) return;
    const cur = this.parseHour(b.preferred_time);
    if (cur !== null && Math.floor(cur * 2) / 2 === slot) return; // same slot — no-op
    this.stageMove(b, slot);
  }
  /** Shared: stage a pending time-reschedule (used by BOTH drop and keyboard/click). */
  private stageMove(b: Booking, slot: number): void {
    const cur = this.parseHour(b.preferred_time);
    this.pendingMove.set({
      id: b.id,
      customer: b.customer_name ?? 'Customer',
      from: cur !== null ? this.fmtTime(cur) : 'untimed',
      to: this.fmtTime(slot),
      slot,
    });
    this.moveError.set(null);
  }

  /** Confirm the pending time-reschedule → PATCH preferred_time (same day).
   *  Pricing (hours/crew/total) is untouched server-side. */
  confirmMove(): void {
    const mv = this.pendingMove();
    if (!mv) return;
    const h = Math.floor(mv.slot);
    const m = Math.round((mv.slot - h) * 60);
    const hhmm = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
    this.moving.set(true);
    this.moveError.set(null);
    this.http
      .patch<{ ok: boolean }>(
        `/api/admin/bookings/${mv.id}`,
        { preferred_time: hhmm },
        { withCredentials: true },
      )
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError(() => of({ ok: false })),
        finalize(() => this.moving.set(false)),
      )
      .subscribe((r) => {
        if (!r.ok) {
          this.moveError.set('Could not reschedule. Check your operator session and try again.');
          return;
        }
        this.bookings.update((list) =>
          list.map((b) => (b.id === mv.id ? { ...b, preferred_time: hhmm } : b)),
        );
        this.pendingMove.set(null);
      });
  }
  cancelMove(): void {
    this.pendingMove.set(null);
    this.moveError.set(null);
  }

  primaryService(b: Booking): string {
    return (b.services_csv ?? '').split(',')[0]?.trim().replace(/-/g, ' ') || 'job';
  }

  chipClass(b: Booking): string {
    const base = 'block truncate rounded-md px-1.5 py-1 text-[11px] leading-tight ';
    const svc = this.primaryService(b).toLowerCase();
    // Order matters: "junk removal" contains "mov" — match haul/junk first.
    if (svc.includes('haul') || svc.includes('junk'))
      return base + 'bg-emerald-500/15 text-emerald-200';
    if (svc.includes('clean')) return base + 'bg-sky-500/15 text-sky-200';
    if (svc.includes('yard') || svc.includes('lawn')) return base + 'bg-lime-500/15 text-lime-200';
    if (svc.includes('moving') || svc.includes('move'))
      return base + 'bg-bcl-accent/15 text-bcl-accent';
    // Fallback chip — text-bcl-ink (bright) not the muted tone (WCAG AA: muted-on-
    // muted-tint was ~2.2:1; bcl-ink clears 4.5:1).
    return base + 'bg-bcl-ink-muted/15 text-bcl-ink';
  }

  chipTitle(b: Booking): string {
    const who = b.customer_name ?? 'Customer';
    const where = b.city ? ` · ${b.city}` : '';
    const hrs = b.hours ? ` · ${b.hours}h` : '';
    const crew = b.crew ? ` · ${b.crew} crew` : '';
    return `${who}${where} — ${this.primaryService(b)}${hrs}${crew} · ${b.status}`;
  }

  slotLabel(s: number): string {
    const h = Math.floor(s);
    const half = s - h >= 0.5;
    if (half) return ''; // only label the top of each hour
    const period = h < 12 ? 'a' : 'p';
    const hour12 = h % 12 === 0 ? 12 : h % 12;
    return `${hour12}${period}`;
  }

  fmtTime(startHour: number): string {
    const h = Math.floor(startHour);
    const m = Math.round((startHour - h) * 60);
    const period = h < 12 ? 'am' : 'pm';
    const hour12 = h % 12 === 0 ? 12 : h % 12;
    return m === 0 ? `${hour12}${period}` : `${hour12}:${String(m).padStart(2, '0')}${period}`;
  }

  /** Parse "14:30", "2:30 PM", "9am", "08:00:00" → fractional hour, or null.
   *  Delegates to the shared calendar parser (single source of truth). */
  parseHour(raw: string | null): number | null {
    return parseHourValue(raw);
  }

  private shiftDay(delta: number): void {
    const d = this.parseIso(this.dayIso());
    d.setDate(d.getDate() + delta);
    this.setDay(this.isoDate(d));
  }

  private setDay(iso: string): void {
    this.dayIso.set(iso);
    void this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { d: iso },
      queryParamsHandling: 'merge',
      replaceUrl: true,
    });
  }

  private initialDay(): string {
    const raw = new URLSearchParams(
      typeof window === 'undefined' ? '' : window.location.search,
    ).get('d');
    if (raw && /^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;
    return this.isoDate(new Date());
  }

  private parseIso(iso: string): Date {
    const [y, m, d] = iso.split('-').map(Number);
    return new Date(y ?? 1970, (m ?? 1) - 1, d ?? 1);
  }

  private isoDate(d: Date): string {
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }

  private resolveTz(): string {
    try {
      return Intl.DateTimeFormat().resolvedOptions().timeZone || 'local';
    } catch {
      return 'local';
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'day-view-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
