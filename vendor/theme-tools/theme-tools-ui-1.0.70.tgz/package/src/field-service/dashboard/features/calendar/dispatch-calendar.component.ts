import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
/**
 * DispatchCalendarComponent — the month-view foundation of the Brick Labor
 * dispatch calendar command center (/dashboard/calendar/month).
 *
 * Reads real scheduled jobs from /api/admin/bookings and renders a
 * Google-Calendar-style 42-cell month grid: each booking placed on its
 * preferred_date, color-coded by service, with prev/next/Today navigation,
 * URL-synced range (?m=YYYY-MM), and a per-month operations strip —
 * scheduled jobs, total crew-hours, and total labor revenue. Revenue + hours
 * come straight from the server-computed canonical fields (total_cents, hours,
 * crew); the calendar NEVER recomputes or invents pricing.
 *
 * Dependency-free (no calendar lib) per the repo's bundle discipline +
 * Spartan black/orange. Week/day/schedule views, crew lanes, drag-reschedule,
 * conflict detection, and Google/ICS sync land in later increments.
 *
 * Flag-gated by `dashboard_calendar` at the route level.
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  effect,
  inject,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { catchError, finalize, of } from 'rxjs';
import { A11yModule } from '@angular/cdk/a11y';
import { JobDetailDrawerComponent } from './job-detail-drawer.component';
import { QuickCreateComponent, type CreatedBooking } from './quick-create.component';
import { detectConflicts } from '@theme.tools/scheduling/field-service/calendar-conflicts';
import { HOURLY_RATE_CENTS } from './week-view.component';
import { RecurringContractsService } from './recurring-contracts.service';
import { CrewAssignmentsService } from './crew-assignments.service';
import { FeatureFlagService } from '../../core/feature-flag.service';
import { projectOccurrences, occurrencePriceCents, type Occurrence } from '@theme.tools/scheduling/field-service/recurring-occurrences';
import { routeFade, reducedMotion } from '../../shared/animations';

interface Booking {
  readonly id: string;
  readonly status: string;
  readonly customer_name: string | null;
  readonly city: string | null;
  readonly preferred_date: string | null;
  readonly preferred_time: string | null;
  readonly services_csv: string | null;
  readonly hours: number | null;
  readonly crew: number | null;
  readonly total_cents: number | null;
}

interface DayCell {
  readonly iso: string;
  readonly day: number;
  readonly inMonth: boolean;
  readonly isToday: boolean;
  readonly bookings: readonly Booking[];
}

const WEEKDAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] as const;

@Component({
  selector: 'app-dispatch-calendar',
  standalone: true,
  imports: [RouterLink, A11yModule, JobDetailDrawerComponent, QuickCreateComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <header
      class="bcl-rise mb-5 flex flex-wrap items-end justify-between gap-4 rounded-2xl border border-bcl-border bcl-grain p-6"
    >
      <div class="min-w-0">
        <p class="bcl-eyebrow mb-2">Dispatch · Calendar</p>
        <h1 class="font-display text-3xl font-extrabold tracking-tight text-bcl-ink">
          {{ monthLabel() }}
        </h1>
        <p class="mt-2 text-sm text-bcl-ink-muted">{{ tz() }}</p>
      </div>

      <div class="flex flex-wrap items-center gap-2">
        <nav
          class="flex overflow-hidden rounded-lg border border-bcl-border"
          aria-label="Calendar views"
        >
          <a
            routerLink="/calendar/month"
            class="bg-bcl-accent px-3 py-1.5 text-xs font-semibold text-bcl-bg focus-visible:outline focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-bcl-bg"
            aria-current="page"
            >Month</a
          >
          <a
            routerLink="/calendar/week"
            class="border-l border-bcl-border px-3 py-1.5 text-xs text-bcl-ink-muted hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
            >Week</a
          >
          <a
            routerLink="/calendar/day"
            class="border-l border-bcl-border px-3 py-1.5 text-xs text-bcl-ink-muted hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
            >Day</a
          >
          <a
            routerLink="/calendar/schedule"
            class="border-l border-bcl-border px-3 py-1.5 text-xs text-bcl-ink-muted hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
            >Schedule</a
          >
        </nav>
        <div class="flex items-center gap-1">
          <button
            type="button"
            (click)="prevMonth()"
            class="grid size-9 place-items-center rounded-lg border border-bcl-border text-bcl-ink-muted transition-colors hover:border-bcl-accent hover:text-bcl-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
            aria-label="Previous month"
          >
            ‹
          </button>
          <button
            type="button"
            (click)="goToday()"
            class="rounded-lg border border-bcl-border px-3 py-1.5 text-xs font-semibold text-bcl-ink transition-colors hover:border-bcl-accent hover:text-bcl-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
            data-testid="cal-today"
          >
            Today
          </button>
          <button
            type="button"
            (click)="nextMonth()"
            class="grid size-9 place-items-center rounded-lg border border-bcl-border text-bcl-ink-muted transition-colors hover:border-bcl-accent hover:text-bcl-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
            aria-label="Next month"
          >
            ›
          </button>
        </div>
        <button
          type="button"
          (click)="quickOpen.set(true)"
          class="rounded-lg bg-bcl-accent px-3 py-1.5 text-xs font-semibold text-bcl-bg transition-all duration-[333ms] hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent focus-visible:ring-offset-2 focus-visible:ring-offset-bcl-bg"
          data-testid="cal-month-new"
        >
          + New job
        </button>
      </div>
    </header>

    <!-- Operations strip: jobs · crew-hours · revenue (canonical server totals). -->
    <section class="mb-5 grid grid-cols-3 gap-3" data-testid="cal-metrics">
      <div class="bcl-glass p-4">
        <p class="bcl-eyebrow text-[10px]">Scheduled jobs</p>
        <p
          class="bcl-tabular mt-1 font-display text-2xl font-extrabold text-bcl-ink"
          data-testid="cal-jobs"
        >
          {{ jobCount() }}
        </p>
      </div>
      <div class="bcl-glass p-4">
        <p class="bcl-eyebrow text-[10px]">Crew-hours</p>
        <p class="bcl-tabular mt-1 font-display text-2xl font-extrabold text-bcl-ink">
          {{ crewHours() }}
        </p>
      </div>
      <div class="bcl-glass p-4">
        <p class="bcl-eyebrow text-[10px]">Labor revenue</p>
        <p
          class="bcl-tabular mt-1 font-display text-2xl font-extrabold text-bcl-accent"
          data-testid="cal-revenue"
        >
          {{ revenueLabel() }}
        </p>
      </div>
    </section>

    @if (error()) {
      <p
        class="mb-3 rounded-2xl border border-amber-500/30 bg-amber-500/5 p-4 text-sm text-amber-300"
        role="alert"
      >
        {{ error() }}
      </p>
    }

    @if (conflictIds().size > 0) {
      <p
        class="mb-3 rounded-2xl border border-amber-500/40 bg-amber-500/10 p-3 text-sm text-amber-200"
        role="status"
        data-testid="cal-month-conflicts"
      >
        @if (crewAware()) {
          ⚠ {{ conflictIds().size }} job(s) double-book the same crew member this month — reassign
          or reschedule.
        } @else {
          ⚠ {{ conflictIds().size }} job(s) overlap in time this month — confirm crew coverage.
        }
      </p>
    }

    @if (pendingMove(); as mv) {
      <div
        class="mb-3 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-bcl-accent/40 bg-bcl-accent/10 p-3 text-sm text-bcl-ink"
        role="alertdialog"
        aria-label="Confirm reschedule"
        data-testid="cal-month-move"
        cdkTrapFocus
        [cdkTrapFocusAutoCapture]="true"
        (keydown.escape)="cancelMove()"
      >
        <span
          >Move <strong>{{ mv.customer }}</strong> from {{ mv.from }} to <strong>{{ mv.to }}</strong
          >?</span
        >
        <span class="flex gap-2">
          <button
            type="button"
            (click)="confirmMove()"
            [disabled]="moving()"
            class="rounded-lg bg-bcl-accent px-3 py-1.5 text-xs font-semibold text-bcl-bg transition-all duration-[333ms] disabled:opacity-50 hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
            data-testid="cal-month-move-confirm"
          >
            {{ moving() ? 'Moving…' : 'Confirm' }}
          </button>
          <button
            type="button"
            (click)="cancelMove()"
            class="rounded-lg border border-bcl-border px-3 py-1.5 text-xs text-bcl-ink-muted transition-colors hover:border-bcl-accent hover:text-bcl-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
          >
            Cancel
          </button>
        </span>
      </div>
    }
    @if (moveError()) {
      <p
        class="mb-3 rounded-2xl border border-rose-500/30 bg-rose-500/5 p-3 text-xs text-rose-300"
        role="alert"
      >
        {{ moveError() }}
      </p>
    }

    @if (movingId()) {
      <p
        class="mb-3 flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-bcl-accent/40 bg-bcl-accent/10 p-3 text-sm text-bcl-ink"
        role="status"
        data-testid="cal-month-arm-hint"
      >
        <span>Pick a day to reschedule this job — no dragging needed.</span>
        <button
          type="button"
          (click)="cancelArm()"
          class="rounded-lg border border-bcl-border px-3 py-1.5 text-xs text-bcl-ink-muted transition-colors hover:border-bcl-accent hover:text-bcl-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
        >
          Cancel
        </button>
      </p>
    }

    <div
      class="grid grid-cols-7 gap-px overflow-hidden rounded-t-2xl border border-bcl-border bg-bcl-border"
      aria-hidden="true"
    >
      @for (w of weekdays; track w) {
        <div class="bg-bcl-bg px-2 py-2 text-center bcl-eyebrow text-[10px]">{{ w }}</div>
      }
    </div>

    <div
      class="grid grid-cols-7 gap-px overflow-hidden rounded-b-2xl border border-x-bcl-border border-b-bcl-border bg-bcl-border"
      role="group"
      [attr.aria-label]="'Month grid for ' + monthLabel()"
      data-testid="cal-month-grid"
    >
      @for (cell of cells(); track cell.iso) {
        <div
          class="min-h-[104px] bg-bcl-bg p-1.5 transition-colors"
          [class.opacity-80]="!cell.inMonth"
          [class.bg-bcl-bg-elev]="cell.isToday"
          [class.ring-2]="dropTarget() === cell.iso || isMoveTarget(cell.iso)"
          [class.ring-inset]="dropTarget() === cell.iso || isMoveTarget(cell.iso)"
          [class.ring-bcl-accent]="dropTarget() === cell.iso || isMoveTarget(cell.iso)"
          [class.cursor-pointer]="isMoveTarget(cell.iso)"
          [class.rounded-md]="isMoveTarget(cell.iso)"
          [class.focus-visible:outline-none]="isMoveTarget(cell.iso)"
          [class.focus-visible:ring-2]="isMoveTarget(cell.iso)"
          [class.focus-visible:ring-offset-2]="isMoveTarget(cell.iso)"
          [attr.role]="isMoveTarget(cell.iso) ? 'button' : null"
          [attr.tabindex]="isMoveTarget(cell.iso) ? 0 : null"
          [attr.data-testid]="isMoveTarget(cell.iso) ? 'cal-move-target' : null"
          [attr.aria-label]="
            isMoveTarget(cell.iso) ? 'Reschedule the selected job to ' + cell.iso : null
          "
          (click)="isMoveTarget(cell.iso) && activateCell(cell.iso)"
          (keydown.enter)="isMoveTarget(cell.iso) && activateCell(cell.iso)"
          (keydown.space)="isMoveTarget(cell.iso) && $event.preventDefault(); isMoveTarget(cell.iso) && activateCell(cell.iso)"
          (dragover)="onDragOver($event, cell.iso)"
          (dragleave)="onDragLeave(cell.iso)"
          (drop)="onDrop($event, cell.iso)"
        >
          <div class="mb-1 flex items-center justify-between px-0.5">
            <span
              class="bcl-tabular grid size-6 place-items-center rounded-full text-xs"
              [class.bg-bcl-accent]="cell.isToday"
              [class.text-bcl-bg]="cell.isToday"
              [class.font-bold]="cell.isToday"
              [class.text-bcl-ink-muted]="!cell.isToday"
              >{{ cell.day }}</span
            >
            @if (cell.bookings.length > 3) {
              <span class="bcl-tabular text-[10px] text-bcl-ink-muted"
                >+{{ cell.bookings.length - 3 }}</span
              >
            }
          </div>
          <ul class="space-y-1">
            @for (b of cell.bookings.slice(0, 3); track b.id) {
              <li class="flex items-stretch gap-0.5">
                <button
                  type="button"
                  draggable="true"
                  (dragstart)="onDragStart($event, b.id)"
                  [class]="
                    chipClass(b) +
                    ' min-w-0 flex-1 cursor-grab text-left active:cursor-grabbing' +
                    conflictCls(b)
                  "
                  [title]="chipTitle(b)"
                  (click)="open(b)"
                >
                  {{ b.preferred_time }} {{ primaryService(b) }}
                </button>
                <!-- Single-pointer + keyboard reschedule alternative to drag
                     (WCAG 2.5.7 / 2.1.1): arms the job, then a day cell becomes a
                     click/Enter target. Sized ≥24px (2.5.8 target size). -->
                <button
                  type="button"
                  (click)="armMove(b.id)"
                  (keydown.enter)="$event.preventDefault(); armMove(b.id)"
                  (keydown.space)="$event.preventDefault(); armMove(b.id)"
                  [attr.aria-pressed]="movingId() === b.id"
                  [attr.aria-label]="
                    movingId() === b.id
                      ? 'Cancel moving ' + (b.customer_name ?? 'job') + ' — pick a day, or press this to cancel'
                      : 'Move ' + (b.customer_name ?? 'job') + ' to another day without dragging'
                  "
                  [title]="movingId() === b.id ? 'Cancel move' : 'Move to another day (no drag)'"
                  class="grid min-h-[24px] w-6 shrink-0 place-items-center rounded-md border text-[11px] leading-none transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
                  [class.border-bcl-accent]="movingId() === b.id"
                  [class.bg-bcl-accent]="movingId() === b.id"
                  [class.text-bcl-bg]="movingId() === b.id"
                  [class.border-bcl-border]="movingId() !== b.id"
                  [class.text-bcl-ink-muted]="movingId() !== b.id"
                  [class.hover:border-bcl-accent]="movingId() !== b.id"
                  [class.hover:text-bcl-accent]="movingId() !== b.id"
                  data-testid="cal-move-chip"
                >
                  @if (movingId() === b.id) {
                    ✕
                  } @else {
                    ⇄
                  }
                </button>
              </li>
            }
            @for (o of recurringFor(cell.iso); track o.contractId) {
              <li>
                <span
                  class="block truncate rounded-md border border-dashed border-bcl-accent/50 bg-bcl-accent/5 px-1.5 py-1 text-[11px] leading-tight text-bcl-accent/80"
                  [title]="occTitle(o)"
                  data-testid="cal-recurring-occ"
                  >↻ {{ o.service }}</span
                >
              </li>
            }
          </ul>
        </div>
      }
    </div>

    @if (loading()) {
      <p class="mt-3 text-center text-sm text-bcl-ink-muted">Loading schedule…</p>
    } @else if (jobCount() === 0 && !error()) {
      <p
        class="mt-3 rounded-2xl border border-bcl-border bg-bcl-bg-elev/40 p-6 text-center text-sm text-bcl-ink-muted"
        data-testid="cal-empty"
      >
        No jobs scheduled this month. Booked jobs and recurring contracts appear here on their
        dates.
      </p>
    }

    <app-job-detail-drawer
      [booking]="selected()"
      (updated)="onUpdated($event)"
      (closed)="selected.set(null)"
    />
    <app-quick-create
      [open]="quickOpen()"
      [defaultDate]="defaultCreateDate()"
      (created)="onCreated($event)"
      (closed)="quickOpen.set(false)"
    />
  `,
})
export class DispatchCalendarComponent {
  protected readonly reducedMotion = reducedMotion;
  private readonly http = inject(HttpClient);
  private readonly destroyRef = inject(DestroyRef);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);

  readonly weekdays = WEEKDAYS;
  readonly bookings = signal<Booking[]>([]);
  /** The job whose detail drawer is open (null = closed). */
  readonly selected = signal<Booking | null>(null);
  /** Whether the quick-create popover is open. */
  readonly quickOpen = signal(false);
  /** Drag-reschedule state. */
  private readonly draggingId = signal<string | null>(null);
  readonly dropTarget = signal<string | null>(null);
  /**
   * Keyboard + single-pointer reschedule state (WCAG 2.5.7 Dragging Movements /
   * 2.1.1 Keyboard). `movingId` is the booking a "Move" button armed — while set,
   * every day cell becomes a focusable click/Enter target that reaches the SAME
   * `pendingMove` confirm the drag reaches, with NO dragging required.
   */
  readonly movingId = signal<string | null>(null);
  readonly pendingMove = signal<{ id: string; customer: string; from: string; to: string } | null>(
    null,
  );
  readonly moving = signal(false);
  readonly moveError = signal<string | null>(null);
  private readonly crewAssignments = inject(CrewAssignmentsService);
  private readonly flags = inject(FeatureFlagService);
  /** When on, conflict detection tightens to per-crew (same worker double-booked). */
  readonly crewAware = this.flags.isOn('calendar_crew_resource_view');
  /**
   * Booking ids that conflict on the same day. Default: any time overlap
   * (coverage warning). Crew-aware (flag on): only when overlapping jobs share
   * an assigned worker — a real per-crew double-booking.
   */
  readonly conflictIds = computed(() => {
    if (!this.crewAware()) return detectConflicts(this.bookings());
    const byBooking = this.crewAssignments.byBooking();
    const items = this.bookings().map((b) => ({ ...b, workerIds: byBooking.get(b.id) ?? [] }));
    return detectConflicts(items, { crewAware: true });
  });

  private readonly recurring = inject(RecurringContractsService);
  /** Projected recurring-contract occurrences for the visible 42-cell range,
   *  grouped by date (overlay; empty when calendar_recurring_contracts is off). */
  readonly recurringByDate = computed<Map<string, Occurrence[]>>(() => {
    const cells = this.cells();
    if (cells.length === 0) return new Map();
    const from = cells[0]!.iso;
    const to = cells[cells.length - 1]!.iso;
    const map = new Map<string, Occurrence[]>();
    for (const ct of this.recurring.contracts()) {
      for (const occ of projectOccurrences(ct, from, to)) {
        const arr = map.get(occ.date) ?? [];
        arr.push(occ);
        map.set(occ.date, arr);
      }
    }
    return map;
  });

  recurringFor(iso: string): Occurrence[] {
    return this.recurringByDate().get(iso) ?? [];
  }
  occTitle(o: Occurrence): string {
    const price = occurrencePriceCents(HOURLY_RATE_CENTS, o.hours, o.crew, o.frequency);
    const who = o.customer_name ?? 'Recurring';
    return `${who} — ${o.service} · ${o.hours}h × ${o.crew} crew · ~$${(price / 100).toFixed(0)} (${o.frequency} contract)`;
  }

  /** Amber conflict ring appended to a chip when it overlaps another job. */
  conflictCls(b: Booking): string {
    return this.conflictIds().has(b.id) ? ' ring-2 ring-inset ring-amber-400/70' : '';
  }
  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly anchor = signal<{ year: number; month: number }>(this.initialAnchor());
  readonly tz = signal<string>(this.resolveTz());

  private readonly byDate = computed<Map<string, Booking[]>>(() => {
    const map = new Map<string, Booking[]>();
    for (const b of this.bookings()) {
      const iso = (b.preferred_date ?? '').slice(0, 10);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) continue;
      const arr = map.get(iso) ?? [];
      arr.push(b);
      map.set(iso, arr);
    }
    return map;
  });

  readonly cells = computed<DayCell[]>(() => {
    const { year, month } = this.anchor();
    const first = new Date(year, month, 1);
    const offset = (first.getDay() + 6) % 7;
    const start = new Date(year, month, 1 - offset);
    const todayIso = this.isoDate(new Date());
    const byDate = this.byDate();
    const out: DayCell[] = [];
    for (let i = 0; i < 42; i++) {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      const iso = this.isoDate(d);
      out.push({
        iso,
        day: d.getDate(),
        inMonth: d.getMonth() === month,
        isToday: iso === todayIso,
        bookings: byDate.get(iso) ?? [],
      });
    }
    return out;
  });

  private readonly monthBookings = computed<Booking[]>(() =>
    this.cells()
      .filter((c) => c.inMonth)
      .flatMap((c) => c.bookings),
  );

  readonly jobCount = computed<number>(() => this.monthBookings().length);
  readonly crewHours = computed<number>(() =>
    this.monthBookings().reduce((n, b) => n + (b.hours ?? 0) * Math.max(1, b.crew ?? 1), 0),
  );
  readonly revenueLabel = computed<string>(() => {
    const cents = this.monthBookings().reduce((n, b) => n + (b.total_cents ?? 0), 0);
    return `$${(cents / 100).toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
  });

  readonly monthLabel = computed<string>(() => {
    const { year, month } = this.anchor();
    return new Date(year, month, 1).toLocaleDateString(undefined, {
      month: 'long',
      year: 'numeric',
    });
  });

  constructor() {
    this.recurring.load(); // overlay data (no-op render when the flag is off → 404 → [])
    // Per-crew conflict data — load the visible 42-cell range's assignments when
    // the flag is on (server 404s when off → empty map → time-overlap fallback).
    effect(() => {
      const cells = this.cells();
      if (this.crewAware() && cells.length === 42) {
        this.crewAssignments.load(cells[0]!.iso, cells[41]!.iso);
      }
    });
    this.http
      .get<{ ok: boolean; bookings: Booking[] }>('/api/admin/bookings?limit=500', {
        withCredentials: true,
      })
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError((err: { status?: number }) => {
          this.error.set(
            err.status === 401
              ? 'Sign in as an operator to view the dispatch calendar.'
              : `Failed to load the schedule (HTTP ${err.status}).`,
          );
          return of({ ok: false, bookings: [] as Booking[] });
        }),
        finalize(() => this.loading.set(false)),
      )
      .subscribe((r) => this.bookings.set(r.bookings ?? []));
  }

  prevMonth(): void {
    const { year, month } = this.anchor();
    this.setAnchor(month === 0 ? { year: year - 1, month: 11 } : { year, month: month - 1 });
  }
  nextMonth(): void {
    const { year, month } = this.anchor();
    this.setAnchor(month === 11 ? { year: year + 1, month: 0 } : { year, month: month + 1 });
  }
  goToday(): void {
    const now = new Date();
    this.setAnchor({ year: now.getFullYear(), month: now.getMonth() });
  }

  /** Open the job-detail drawer for a chip. */
  open(b: Booking): void {
    this.selected.set(b);
  }

  /** Drawer saved a status change — reflect it in the loaded list. */
  onUpdated(updated: {
    id: string;
    status: string;
    hours: number | null;
    total_cents: number | null;
  }): void {
    this.bookings.update((list) =>
      list.map((b) =>
        b.id === updated.id
          ? { ...b, status: updated.status, hours: updated.hours, total_cents: updated.total_cents }
          : b,
      ),
    );
    this.selected.set(null);
  }

  /** Quick-create returned a new booking — add it to the loaded list. */
  onCreated(b: CreatedBooking): void {
    this.bookings.update((list) => [...list, b as unknown as Booking]);
    this.quickOpen.set(false);
  }

  // ── Drag-reschedule (drop a job chip onto a different day cell) ───────────
  onDragStart(ev: DragEvent, id: string): void {
    this.draggingId.set(id);
    ev.dataTransfer?.setData('text/plain', id);
    if (ev.dataTransfer) ev.dataTransfer.effectAllowed = 'move';
  }
  onDragOver(ev: DragEvent, iso: string): void {
    ev.preventDefault(); // allow drop
    if (this.dropTarget() !== iso) this.dropTarget.set(iso);
  }
  onDragLeave(iso: string): void {
    if (this.dropTarget() === iso) this.dropTarget.set(null);
  }
  onDrop(ev: DragEvent, iso: string): void {
    ev.preventDefault();
    this.dropTarget.set(null);
    const id = ev.dataTransfer?.getData('text/plain') || this.draggingId();
    this.draggingId.set(null);
    if (!id) return;
    const b = this.bookings().find((x) => x.id === id);
    if (!b) return;
    const from = (b.preferred_date ?? '').slice(0, 10);
    if (from === iso) return; // dropped on the same day — no-op
    this.stageMove(b, iso); // from-guard above matches the spec's same-day no-op
  }

  // ── Keyboard / single-pointer reschedule (no drag) ────────────────────────
  /** Arm a job for a no-drag move (a "Move" button click OR Enter/Space). */
  armMove(id: string): void {
    this.movingId.set(this.movingId() === id ? null : id);
    this.dropTarget.set(null);
    this.moveError.set(null);
  }
  /** Cancel an armed move without rescheduling. */
  cancelArm(): void {
    this.movingId.set(null);
  }
  /** True while a day cell should act as a click/keyboard reschedule target. */
  isMoveTarget(iso: string): boolean {
    const id = this.movingId();
    if (!id) return false;
    const b = this.bookings().find((x) => x.id === id);
    return !!b && (b.preferred_date ?? '').slice(0, 10) !== iso; // never its own day
  }
  /** Activate a target cell (click or Enter/Space) → stage the same reschedule. */
  activateCell(iso: string): void {
    const id = this.movingId();
    if (!id) return;
    const b = this.bookings().find((x) => x.id === id);
    this.movingId.set(null);
    if (!b) return;
    if ((b.preferred_date ?? '').slice(0, 10) === iso) return; // same day — no-op
    this.stageMove(b, iso);
  }
  /** Shared: stage a pending reschedule (used by BOTH drop and keyboard/click). */
  private stageMove(b: Booking, iso: string): void {
    this.pendingMove.set({
      id: b.id,
      customer: b.customer_name ?? 'Customer',
      from: (b.preferred_date ?? '').slice(0, 10) || '—',
      to: iso,
    });
    this.moveError.set(null);
  }

  /** Confirm the pending reschedule → PATCH preferred_date → move in the grid.
   *  Pricing (hours/crew/total) is untouched server-side. */
  confirmMove(): void {
    const mv = this.pendingMove();
    if (!mv) return;
    this.moving.set(true);
    this.moveError.set(null);
    this.http
      .patch<{ ok: boolean }>(
        `/api/admin/bookings/${mv.id}`,
        { preferred_date: mv.to },
        { withCredentials: true },
      )
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError(() => of({ ok: false })),
        finalize(() => this.moving.set(false)),
      )
      .subscribe((r) => {
        if (!r.ok) {
          this.moveError.set('Could not reschedule. Check your operator session and try again.');
          return;
        }
        this.bookings.update((list) =>
          list.map((b) => (b.id === mv.id ? { ...b, preferred_date: mv.to } : b)),
        );
        this.pendingMove.set(null);
      });
  }
  cancelMove(): void {
    this.pendingMove.set(null);
    this.moveError.set(null);
  }

  /** Default date for quick-create from the month view: first day of the
   *  visible month (operator can change it in the form). */
  defaultCreateDate(): string {
    const { year, month } = this.anchor();
    return `${year}-${String(month + 1).padStart(2, '0')}-01`;
  }

  primaryService(b: Booking): string {
    return (b.services_csv ?? '').split(',')[0]?.trim().replace(/-/g, ' ') || 'job';
  }

  /** Full Tailwind class string for a job chip, color-coded by primary service. */
  chipClass(b: Booking): string {
    const base =
      'block truncate rounded-md px-1.5 py-1 text-[11px] leading-tight focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent ';
    const svc = this.primaryService(b).toLowerCase();
    // Order matters: "junk removal" contains "mov" — match haul/junk first.
    if (svc.includes('haul') || svc.includes('junk'))
      return base + 'bg-emerald-500/15 text-emerald-200';
    if (svc.includes('clean')) return base + 'bg-sky-500/15 text-sky-200';
    if (svc.includes('yard') || svc.includes('lawn')) return base + 'bg-lime-500/15 text-lime-200';
    if (svc.includes('moving') || svc.includes('move'))
      return base + 'bg-bcl-accent/15 text-bcl-accent';
    // Fallback chip — text-bcl-ink (bright) not the muted tone: muted-on-muted-tint
    // was ~2.2:1 (WCAG AA fail on an interactive chip). bcl-ink clears 4.5:1.
    return base + 'bg-bcl-ink-muted/15 text-bcl-ink';
  }

  chipTitle(b: Booking): string {
    const who = b.customer_name ?? 'Customer';
    const where = b.city ? ` · ${b.city}` : '';
    const hrs = b.hours ? ` · ${b.hours}h` : '';
    const crew = b.crew ? ` · ${b.crew} crew` : '';
    return `${who}${where} — ${this.primaryService(b)}${hrs}${crew} · ${b.status}`;
  }

  private setAnchor(next: { year: number; month: number }): void {
    this.anchor.set(next);
    const m = `${next.year}-${String(next.month + 1).padStart(2, '0')}`;
    void this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { m },
      queryParamsHandling: 'merge',
      replaceUrl: true,
    });
  }

  private initialAnchor(): { year: number; month: number } {
    const raw = new URLSearchParams(
      typeof window === 'undefined' ? '' : window.location.search,
    ).get('m');
    const match = raw?.match(/^(\d{4})-(\d{2})$/);
    if (match) {
      const year = Number(match[1]);
      const month = Number(match[2]) - 1;
      if (month >= 0 && month <= 11) return { year, month };
    }
    const now = new Date();
    return { year: now.getFullYear(), month: now.getMonth() };
  }

  private isoDate(d: Date): string {
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }

  private resolveTz(): string {
    try {
      return Intl.DateTimeFormat().resolvedOptions().timeZone || 'local';
    } catch {
      return 'local';
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'dispatch-calendar-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
