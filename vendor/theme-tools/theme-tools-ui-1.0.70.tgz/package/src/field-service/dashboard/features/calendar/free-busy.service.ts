import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * FreeBusyService — loads the operator's Google free/busy intervals for a date
 * range from POST /api/google-calendar/freebusy, for the calendar's busy-block
 * overlay (avoid double-booking against the operator's external Google events).
 *
 * The endpoint is flag-gated (google_calendar_2way) + requires a connected
 * Google account, so a 404/error degrades to an empty list — the overlay simply
 * shows nothing until connected. Shared (providedIn root). `load(start, end)` is
 * called per visible range (sync-on-open); a 503 { retryable } is treated as
 * empty for this pass (the next range change re-queries).
 */
import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError, of } from 'rxjs';

export interface BusyInterval {
  readonly start: string; // ISO
  readonly end: string; // ISO
}

@Injectable({ providedIn: 'root' })
export class FreeBusyService {
  private readonly http = inject(HttpClient);
  /** Busy intervals for the last-loaded range (empty when off / not connected). */
  readonly busy = signal<BusyInterval[]>([]);
  private lastKey = '';

  load(startIso: string, endIso: string): void {
    const key = `${startIso}|${endIso}`;
    if (key === this.lastKey) return; // de-dupe identical range re-queries
    this.lastKey = key;
    this.http
      .post<{ ok: boolean; busy?: BusyInterval[] }>(
        '/api/google-calendar/freebusy',
        { startIso, endIso },
        { withCredentials: true },
      )
      .pipe(catchError(() => of({ ok: false, busy: [] as BusyInterval[] })))
      .subscribe((r) => this.busy.set(r.ok ? (r.busy ?? []) : []));
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'free-busy-service',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
