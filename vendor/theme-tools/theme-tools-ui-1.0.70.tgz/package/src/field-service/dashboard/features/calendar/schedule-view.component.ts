import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
/**
 * ScheduleViewComponent — the agenda/schedule view of the dispatch calendar
 * (/dashboard/calendar/schedule).
 *
 * A chronological, day-grouped list of upcoming scheduled jobs read from
 * /api/admin/bookings — fast to scan for "what's next", with a per-day subtotal
 * of crew-hours + labor revenue (canonical server-computed total_cents/hours/
 * crew — never recomputed). Complements the month grid; the week/day time-grid
 * views land later. Spartan black/orange, flag-gated `dashboard_calendar`.
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  inject,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RouterLink } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { catchError, finalize, of } from 'rxjs';
import { routeFade, reducedMotion } from '../../shared/animations';
import { HlmSkeleton } from '../../shared/ui-spartan';

interface Booking {
  readonly id: string;
  readonly status: string;
  readonly customer_name: string | null;
  readonly city: string | null;
  readonly preferred_date: string | null;
  readonly preferred_time: string | null;
  readonly services_csv: string | null;
  readonly hours: number | null;
  readonly crew: number | null;
  readonly total_cents: number | null;
}

interface DayGroup {
  readonly iso: string;
  readonly label: string;
  readonly isToday: boolean;
  readonly bookings: readonly Booking[];
  readonly crewHours: number;
  readonly revenueCents: number;
}

const HORIZON_DAYS = 45;

@Component({
  selector: 'app-schedule-view',
  standalone: true,
  imports: [RouterLink, HlmSkeleton],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <header class="bcl-rise mb-5 flex flex-wrap items-end justify-between gap-4 rounded-2xl border border-bcl-border bcl-grain p-6">
      <div class="min-w-0">
        <p class="bcl-eyebrow mb-2">Dispatch · Schedule</p>
        <h1 class="font-display text-3xl font-extrabold tracking-tight text-bcl-ink">Upcoming jobs</h1>
        <p class="mt-2 text-sm text-bcl-ink-muted" data-testid="sched-summary">
          {{ totalJobs() }} {{ totalJobs() === 1 ? 'job' : 'jobs' }} over the next {{ horizon }} days ·
          {{ totalCrewHours() }} crew-hours · {{ totalRevenueLabel() }} labor revenue
        </p>
      </div>
      <nav class="flex overflow-hidden rounded-lg border border-bcl-border" aria-label="Calendar views">
        <a routerLink="/calendar/month" class="px-3 py-1.5 text-xs text-bcl-ink-muted hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent">Month</a>
        <a routerLink="/calendar/week" class="border-l border-bcl-border px-3 py-1.5 text-xs text-bcl-ink-muted hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent">Week</a>
        <a routerLink="/calendar/day" class="border-l border-bcl-border px-3 py-1.5 text-xs text-bcl-ink-muted hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent">Day</a>
        <a routerLink="/calendar/schedule" class="border-l border-bcl-border bg-bcl-accent px-3 py-1.5 text-xs font-semibold text-bcl-bg focus-visible:outline focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-bcl-bg" aria-current="page">Schedule</a>
      </nav>
    </header>

    @if (error()) {
      <p class="mb-3 rounded-2xl border border-amber-500/30 bg-amber-500/5 p-4 text-sm text-amber-300" role="alert">{{ error() }}</p>
    }

    @if (loading()) {
      <div class="space-y-2" data-testid="sched-loading" aria-busy="true" aria-label="Loading schedule">
        @for (row of [1, 2, 3, 4]; track row) {
          <div class="bcl-glass flex items-center gap-3 p-3">
            <div hlmSkeleton class="h-4 w-14 shrink-0"></div>
            <div hlmSkeleton class="h-4 flex-1"></div>
          </div>
        }
      </div>
    } @else if (groups().length === 0 && !error()) {
      <p class="rounded-2xl border border-bcl-border bg-bcl-bg-elev/40 p-6 text-center text-sm text-bcl-ink-muted" data-testid="sched-empty">
        No jobs scheduled in the next {{ horizon }} days. Booked jobs + recurring contracts appear here as they land.
      </p>
    } @else {
      <div class="space-y-5" data-testid="sched-list">
        @for (g of groups(); track g.iso) {
          <section>
            <div class="mb-2 flex items-baseline justify-between gap-3 border-b border-bcl-border pb-1">
              <h2 class="font-display text-sm font-bold tracking-wide text-bcl-ink" [class.text-bcl-accent]="g.isToday">
                {{ g.label }}
              </h2>
              <p class="bcl-tabular text-xs text-bcl-ink-muted">
                {{ g.bookings.length }} · {{ g.crewHours }}h · {{ money(g.revenueCents) }}
              </p>
            </div>
            <ul class="space-y-2">
              @for (b of g.bookings; track b.id) {
                <li class="bcl-glass flex items-center gap-3 p-3">
                  <span class="bcl-tabular w-14 shrink-0 text-sm font-semibold text-bcl-ink">{{ b.preferred_time || '—' }}</span>
                  <span [class]="dotClass(b)" aria-hidden="true"></span>
                  <div class="min-w-0 flex-1">
                    <p class="truncate text-sm font-semibold text-bcl-ink">
                      {{ primaryService(b) }} · {{ b.customer_name || 'Customer' }}
                    </p>
                    <p class="truncate text-xs text-bcl-ink-muted">
                      {{ b.city || 'Newark' }} · {{ b.hours || 0 }}h · {{ b.crew || 1 }} crew · {{ b.status }}
                    </p>
                  </div>
                  <span class="bcl-tabular shrink-0 text-sm font-semibold text-bcl-accent">{{ money(b.total_cents || 0) }}</span>
                </li>
              }
            </ul>
          </section>
        }
      </div>
    }
  `,
})
export class ScheduleViewComponent {
  protected readonly reducedMotion = reducedMotion;
  private readonly http = inject(HttpClient);
  private readonly destroyRef = inject(DestroyRef);

  readonly horizon = HORIZON_DAYS;
  readonly bookings = signal<Booking[]>([]);
  readonly loading = signal(true);
  readonly error = signal<string | null>(null);

  readonly groups = computed<DayGroup[]>(() => {
    const todayIso = this.isoDate(new Date());
    const horizonIso = this.isoDate(this.addDays(new Date(), HORIZON_DAYS));
    const byDate = new Map<string, Booking[]>();
    for (const b of this.bookings()) {
      const iso = (b.preferred_date ?? '').slice(0, 10);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) continue;
      if (iso < todayIso || iso > horizonIso) continue;
      const arr = byDate.get(iso) ?? [];
      arr.push(b);
      byDate.set(iso, arr);
    }
    return [...byDate.keys()]
      .sort()
      .map((iso) => {
        const dayBookings = (byDate.get(iso) ?? []).slice().sort((a, b) =>
          (a.preferred_time ?? '').localeCompare(b.preferred_time ?? ''),
        );
        return {
          iso,
          label: this.dayLabel(iso),
          isToday: iso === todayIso,
          bookings: dayBookings,
          crewHours: dayBookings.reduce((n, b) => n + (b.hours ?? 0) * Math.max(1, b.crew ?? 1), 0),
          revenueCents: dayBookings.reduce((n, b) => n + (b.total_cents ?? 0), 0),
        };
      });
  });

  readonly totalJobs = computed(() => this.groups().reduce((n, g) => n + g.bookings.length, 0));
  readonly totalCrewHours = computed(() => this.groups().reduce((n, g) => n + g.crewHours, 0));
  readonly totalRevenueLabel = computed(() =>
    this.money(this.groups().reduce((n, g) => n + g.revenueCents, 0)),
  );

  constructor() {
    this.http
      .get<{ ok: boolean; bookings: Booking[] }>('/api/admin/bookings?limit=500', {
        withCredentials: true,
      })
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError((err: { status?: number }) => {
          this.error.set(
            err.status === 401
              ? 'Sign in as an operator to view the schedule.'
              : `Failed to load the schedule (HTTP ${err.status}).`,
          );
          return of({ ok: false, bookings: [] as Booking[] });
        }),
        finalize(() => this.loading.set(false)),
      )
      .subscribe((r) => this.bookings.set(r.bookings ?? []));
  }

  primaryService(b: Booking): string {
    return (b.services_csv ?? '').split(',')[0]?.trim().replace(/-/g, ' ') || 'job';
  }

  money(cents: number): string {
    return `$${(cents / 100).toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
  }

  /** Status dot, color-coded by primary service (junk before moving — "removal" contains "mov"). */
  dotClass(b: Booking): string {
    const base = 'size-2.5 shrink-0 rounded-full ';
    const svc = this.primaryService(b).toLowerCase();
    if (svc.includes('haul') || svc.includes('junk')) return base + 'bg-emerald-400';
    if (svc.includes('clean')) return base + 'bg-sky-400';
    if (svc.includes('yard') || svc.includes('lawn')) return base + 'bg-lime-400';
    if (svc.includes('moving') || svc.includes('move')) return base + 'bg-bcl-accent';
    return base + 'bg-bcl-ink-muted';
  }

  private dayLabel(iso: string): string {
    const parts = iso.split('-');
    const y = Number(parts[0] ?? 0);
    const m = Number(parts[1] ?? 1);
    const d = Number(parts[2] ?? 1);
    return new Date(y, m - 1, d).toLocaleDateString(undefined, {
      weekday: 'long',
      month: 'short',
      day: 'numeric',
    });
  }

  private addDays(d: Date, n: number): Date {
    const out = new Date(d);
    out.setDate(out.getDate() + n);
    return out;
  }

  private isoDate(d: Date): string {
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'schedule-view-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
