import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * CrewBlocklistCardComponent — "don't dispatch me to this customer again" on the
 * crew surface. Angular port of React `work/BlocklistEditor`. Live surface =
 * Angular /dashboard, crew audience. Crew-only feature (no customer/admin analog).
 *
 * GET /api/work/blocklist → { blocks:[{id,label,reason,customer_contact_hash}],
 * past:[{contact_hash,label,jobs_count,last_job_at}] }. Fully self-contained loop:
 * block a `past` customer (POST { contactHash }), unblock (DELETE /:id). Customers
 * are anonymized server-side (label `cust_xxxx`). Self-gates 401 → hide. Pure
 * helpers blockedHashes/availableToBlock are unit-tested in the spec.
 */
import { ChangeDetectionStrategy, Component, OnInit, signal } from '@angular/core';
import { HlmCardImports, HlmButton } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

export interface BlockEntry {
  readonly id: string;
  readonly customer_contact_hash: string;
  readonly label: string;
  readonly reason: string | null;
}

export interface PastCustomer {
  readonly contact_hash: string;
  readonly label: string;
  readonly jobs_count: number;
  readonly last_job_at: string | null;
}

/** Pure: set of already-blocked contact hashes. */
export function blockedHashes(blocks: readonly BlockEntry[]): Set<string> {
  return new Set(blocks.map((b) => b.customer_contact_hash));
}

/** Pure: past customers not already on the blocklist. */
export function availableToBlock(
  past: readonly PastCustomer[],
  blocks: readonly BlockEntry[],
): PastCustomer[] {
  const set = blockedHashes(blocks);
  return past.filter((p) => !set.has(p.contact_hash));
}

interface BlocklistResponse {
  readonly blocks?: readonly BlockEntry[];
  readonly past?: readonly PastCustomer[];
}

@Component({
  selector: 'app-crew-blocklist-card',
  standalone: true,
  imports: [...HlmCardImports, HlmButton, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (visible()) {
      <div hlmCard bclReveal data-testid="crew-blocklist-card">
        <div hlmCardHeader>
          <h3 hlmCardTitle>Customer blocklist</h3>
          <p hlmCardDescription>Customers you've asked not to be dispatched to again.</p>
        </div>
        <div hlmCardContent>
          @if (blocks().length > 0) {
            <ul class="mb-4 grid gap-2">
              @for (b of blocks(); track b.id) {
                <li class="flex items-center justify-between gap-2 rounded-md border border-bcl-border bg-bcl-bg-elev px-3 py-2 text-sm">
                  <span class="min-w-0">
                    <span class="font-mono text-bcl-ink">{{ b.label }}</span>
                    @if (b.reason) { <span class="ml-2 text-bcl-ink-muted">— {{ b.reason }}</span> }
                  </span>
                  <button hlmBtn variant="ghost" class="text-xs" [disabled]="pending().has(b.id)" (click)="unblock(b.id)">Unblock</button>
                </li>
              }
            </ul>
          } @else {
            <p class="mb-4 text-sm text-bcl-ink-muted">No blocked customers.</p>
          }

          @if (available().length > 0) {
            <p class="mb-2 font-mono text-[10px] uppercase tracking-wider text-bcl-ink-muted">Recent customers</p>
            <ul class="grid gap-2">
              @for (p of available(); track p.contact_hash) {
                <li class="flex items-center justify-between gap-2 rounded-md border border-bcl-border bg-bcl-bg px-3 py-2 text-sm">
                  <span class="min-w-0">
                    <span class="font-mono text-bcl-ink">{{ p.label }}</span>
                    <span class="ml-2 text-xs text-bcl-ink-muted">{{ p.jobs_count }} job{{ p.jobs_count === 1 ? '' : 's' }}</span>
                  </span>
                  <button hlmBtn variant="ghost" class="text-xs text-destructive" [disabled]="pending().has(p.contact_hash)" (click)="block(p.contact_hash)">Block</button>
                </li>
              }
            </ul>
          }

          @if (error(); as e) {
            <p class="mt-3 text-sm text-destructive" role="alert">{{ e }}</p>
          }
        </div>
      </div>
    }
  `,
})
export class CrewBlocklistCardComponent implements OnInit {
  readonly visible = signal(false);
  readonly blocks = signal<readonly BlockEntry[]>([]);
  readonly available = signal<readonly PastCustomer[]>([]);
  readonly pending = signal<Set<string>>(new Set());
  readonly error = signal<string>('');

  ngOnInit(): void {
    void this.reload();
  }

  async reload(): Promise<void> {
    this.error.set('');
    try {
      const res = await fetch('/api/work/blocklist', { credentials: 'include' });
      if (!res.ok) {
        this.visible.set(false); // 401 anon
        return;
      }
      const data = (await res.json().catch(() => null)) as BlocklistResponse | null;
      const blocks = data?.blocks ?? [];
      const past = data?.past ?? [];
      this.blocks.set(blocks);
      this.available.set(availableToBlock(past, blocks));
      this.visible.set(true);
    } catch {
      this.visible.set(false);
    }
  }

  private mark(key: string, on: boolean): void {
    const next = new Set(this.pending());
    if (on) next.add(key);
    else next.delete(key);
    this.pending.set(next);
  }

  async block(contactHash: string): Promise<void> {
    this.mark(contactHash, true);
    this.error.set('');
    try {
      const res = await fetch('/api/work/blocklist', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contactHash }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      await this.reload();
    } catch {
      this.error.set('Could not block that customer. Try again.');
    } finally {
      this.mark(contactHash, false);
    }
  }

  async unblock(id: string): Promise<void> {
    this.mark(id, true);
    this.error.set('');
    try {
      const res = await fetch(`/api/work/blocklist/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      await this.reload();
    } catch {
      this.error.set('Could not unblock. Try again.');
    } finally {
      this.mark(id, false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'blocklist-card-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
