import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * CrewCompletenessCardComponent — "what's left to start earning" onboarding gate
 * on the crew surface. Angular port of the React `work/CompletenessChecklist`.
 * Live surface = Angular /dashboard, crew audience.
 *
 * GET /api/work/completeness (worker-cookie gated) → { ok, score, readyToWork,
 * readyToReceivePayouts, checklist:[{id,label}] (the MISSING items), state }.
 * Self-gates: 401/404 → hide. When the checklist is empty and readyToWork, shows
 * the all-set success state. Dark cockpit. Pure helpers scoreTone/isAllSet/
 * clampScore are unit-tested in completeness-card.component.spec.ts.
 */
import { ChangeDetectionStrategy, Component, OnInit, signal } from '@angular/core';
import { HlmCardImports } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';
import { BclRollingCounterComponent } from '../_shared/rolling-counter.component';

export interface CompletenessItem {
  readonly id: string;
  readonly label: string;
}

export interface CompletenessReport {
  readonly ok: boolean;
  readonly score: number;
  readonly readyToWork: boolean;
  readonly readyToReceivePayouts: boolean;
  readonly checklist: readonly CompletenessItem[];
}

/** Pure: clamp a score into 0–100. */
export function clampScore(n: number): number {
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(100, Math.round(n)));
}

/** Pure: tone band for the score ring. */
export function scoreTone(score: number): 'low' | 'mid' | 'high' {
  const s = clampScore(score);
  if (s >= 100) return 'high';
  if (s >= 60) return 'mid';
  return 'low';
}

/** Pure: fully onboarded = nothing missing AND cleared to work. */
export function isAllSet(r: Pick<CompletenessReport, 'readyToWork' | 'checklist'>): boolean {
  return r.readyToWork && (r.checklist?.length ?? 0) === 0;
}

@Component({
  selector: 'app-crew-completeness-card',
  standalone: true,
  imports: [...HlmCardImports, BclRevealDirective, BclRollingCounterComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (visible()) {
      <div hlmCard bclReveal data-testid="crew-completeness-card">
        <div hlmCardHeader class="flex flex-row items-center justify-between gap-3">
          <div>
            <h3 hlmCardTitle>Get ready to earn</h3>
            <p hlmCardDescription>Finish these to unlock gig offers + payouts.</p>
          </div>
          <span
            class="shrink-0 rounded-full px-3 py-1 font-mono text-sm tabular-nums ring-1"
            [class.text-bcl-success]="tone() === 'high'"
            [class.ring-bcl-success\/40]="tone() === 'high'"
            [class.text-bcl-warn]="tone() === 'mid'"
            [class.ring-bcl-warn\/40]="tone() === 'mid'"
            [class.text-destructive]="tone() === 'low'"
            [class.ring-destructive\/40]="tone() === 'low'"
            aria-label="Profile completeness"
          ><bcl-rolling-counter [value]="score()" suffix="%" /></span>
        </div>
        <div hlmCardContent>
          @if (allSet()) {
            <p class="text-sm text-bcl-success" role="status">
              ✓ You're all set — gig offers and payouts are unlocked.
            </p>
          } @else {
            <div class="mb-3 flex flex-wrap gap-2 text-xs">
              <span
                class="rounded-full px-2 py-0.5 ring-1 ring-bcl-border"
                [class.text-bcl-success]="readyToWork()"
                [class.text-bcl-ink-muted]="!readyToWork()"
              >{{ readyToWork() ? '✓' : '○' }} Ready to work</span>
              <span
                class="rounded-full px-2 py-0.5 ring-1 ring-bcl-border"
                [class.text-bcl-success]="readyToPayout()"
                [class.text-bcl-ink-muted]="!readyToPayout()"
              >{{ readyToPayout() ? '✓' : '○' }} Payouts enabled</span>
            </div>
            <ul class="grid gap-1.5">
              @for (it of checklist(); track it.id) {
                <li class="flex items-center gap-2 text-sm text-bcl-ink">
                  <span class="text-destructive" aria-hidden="true">○</span>
                  {{ it.label }}
                </li>
              }
            </ul>
          }
        </div>
      </div>
    }
  `,
})
export class CrewCompletenessCardComponent implements OnInit {
  readonly visible = signal(false);
  readonly score = signal(0);
  readonly readyToWork = signal(false);
  readonly readyToPayout = signal(false);
  readonly checklist = signal<readonly CompletenessItem[]>([]);
  readonly allSet = signal(false);
  readonly tone = signal<'low' | 'mid' | 'high'>('low');

  ngOnInit(): void {
    void this.refresh();
  }

  async refresh(): Promise<void> {
    try {
      const res = await fetch('/api/work/completeness', { credentials: 'include' });
      if (!res.ok) {
        this.visible.set(false); // 401/404 → not a crew with a report
        return;
      }
      const r = (await res.json().catch(() => null)) as CompletenessReport | null;
      if (!r?.ok) {
        this.visible.set(false);
        return;
      }
      this.score.set(clampScore(r.score));
      this.tone.set(scoreTone(r.score));
      this.readyToWork.set(!!r.readyToWork);
      this.readyToPayout.set(!!r.readyToReceivePayouts);
      this.checklist.set(r.checklist ?? []);
      this.allSet.set(isAllSet(r));
      this.visible.set(true);
    } catch {
      this.visible.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'completeness-card-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
