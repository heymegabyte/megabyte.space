import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
/**
 * Crew self-service lazy routes.
 *
 * `hours_coach` (migration 0127), `crew_tier_ladder` + `wave28_onboarding_gamification`
 * (migration 0119) stay CUT — `featureFlagGuard` denies any deleted flag, and
 * `validate-orphaned-flag-guards.mjs` fails the build if a route is ever guarded by
 * a deleted flag again.
 *
 * `crew_earnings_dashboard` was RESURRECTED (migration 0144, roadmap decision #1) —
 * crew are Stripe Connect contractors who legally need a 1099-NEC earnings record.
 * The `earnings-ledger` route is flag-gated (dark by default) and reads the
 * flag-gated `/api/earnings/ledger`.
 *
 * Always-on crew earnings surface: `<bcl-earnings-ticker>` (today's gross/tips/gigs
 * via `/api/earnings/today`) + the payouts-status card + the 1099 card.
 */
import { Route } from '@angular/router';
import { featureFlagGuard } from '../../core/feature-flag-guard';

export const CREW_WAVE27_ROUTES: Route[] = [
  {
    path: 'payout',
    canActivate: [featureFlagGuard('instant_payout_rtp')],
    loadComponent: () => import('./payout-request.component').then((m) => m.PayoutRequestComponent),
  },
  {
    path: 'earnings-ledger',
    canActivate: [featureFlagGuard('crew_earnings_dashboard')],
    loadComponent: () =>
      import('./earnings-ledger.component').then((m) => m.CrewEarningsLedgerComponent),
  },
];
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'earnings-routes',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
