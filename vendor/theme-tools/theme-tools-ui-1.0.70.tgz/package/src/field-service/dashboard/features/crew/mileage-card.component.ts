import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * CrewMileageCardComponent — GPS-stamped, tax-deductible mileage logging on the
 * crew console. Angular port of React `work/MileageTracker`. Live surface =
 * Angular /dashboard, crew.
 *
 * Verified by mount (`app.route('/api/work/mileage', mileage)`):
 *   GET  /api/work/mileage[?year=YYYY] → { ok, logs:[{id,miles,started_at,ended_at,…}], totalMiles }
 *   POST /api/work/mileage/start  { lat, lng } → { ok, id }
 *   POST /api/work/mileage/stop   { id, lat, lng } → { ok, miles }
 * Active trip persisted to localStorage so a refresh doesn't lose the start
 * coordinate (mirrors React). Self-gates 401 → hide. Pure helpers parseActiveTrip/
 * formatMiles/isComplete unit-tested.
 */
import { ChangeDetectionStrategy, Component, OnInit, signal } from '@angular/core';
import { HlmCardImports, HlmButton } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';
import { BclRollingCounterComponent } from '../_shared/rolling-counter.component';
import { mileageToCsv, mileageCsvFilename } from '@theme.tools/billing/field-service/mileage-csv';

export interface MileageLog {
  readonly id: string;
  readonly miles: number | null;
  readonly started_at: string;
  readonly ended_at: string | null;
}

export interface ActiveTrip {
  readonly id: string;
  readonly startedAt: string;
}

const STORAGE_KEY = 'bcl-dash-mileage-active-v1';

/** Pure: safely parse the persisted active-trip blob (null on any problem). */
export function parseActiveTrip(raw: string | null): ActiveTrip | null {
  if (!raw) return null;
  try {
    const v = JSON.parse(raw) as Partial<ActiveTrip>;
    if (v && typeof v.id === 'string' && typeof v.startedAt === 'string') {
      return { id: v.id, startedAt: v.startedAt };
    }
    return null;
  } catch {
    return null;
  }
}

/** Pure: render miles with one decimal, em-dash when absent. */
export function formatMiles(miles: number | null): string {
  if (miles == null || !Number.isFinite(miles)) return '—';
  return `${miles.toFixed(1)} mi`;
}

/** Pure: a completed trip has an end timestamp. */
export function isComplete(log: Pick<MileageLog, 'ended_at'>): boolean {
  return !!log.ended_at;
}

interface MileageResponse {
  readonly ok: boolean;
  readonly logs?: readonly MileageLog[];
  readonly totalMiles?: number;
}

@Component({
  selector: 'app-crew-mileage-card',
  standalone: true,
  imports: [...HlmCardImports, HlmButton, BclRevealDirective, BclRollingCounterComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (visible()) {
      <div hlmCard bclReveal data-testid="crew-mileage-card">
        <div hlmCardHeader class="flex flex-row items-center justify-between gap-3">
          <div>
            <h3 hlmCardTitle>Mileage</h3>
            <p hlmCardDescription>GPS-logged miles for your tax-deductible export.</p>
          </div>
          <div class="flex shrink-0 items-center gap-3">
            <span class="font-mono text-sm tabular-nums text-bcl-accent" aria-label="Year-to-date miles">
              <bcl-rolling-counter [value]="totalMiles()" [decimals]="1" suffix=" mi" /> YTD
            </span>
            @if (logs().length > 0) {
              <button
                hlmBtn
                variant="outline"
                size="sm"
                class="transition-all duration-[333ms] hover:-translate-y-0.5 hover:shadow-md motion-reduce:transition-none motion-reduce:hover:translate-y-0"
                (click)="exportCsv()"
                data-testid="mileage-csv-export"
                aria-label="Download mileage as CSV for tax filing"
              >
                Download CSV
              </button>
            }
          </div>
        </div>
        <div hlmCardContent>
          @if (active()) {
            <div class="mb-3 flex items-center justify-between gap-3 rounded-md border border-bcl-warn/40 bg-bcl-warn/10 px-3 py-2 text-sm">
              <span class="text-bcl-warn" role="status">Trip in progress…</span>
              <button hlmBtn variant="destructive" [disabled]="busy()" (click)="stop()" data-testid="mileage-stop">
                {{ busy() ? 'Saving…' : 'Stop trip' }}
              </button>
            </div>
          } @else {
            <button hlmBtn [disabled]="busy()" (click)="start()" data-testid="mileage-start">
              {{ busy() ? 'Starting…' : 'Start trip' }}
            </button>
          }

          @if (error(); as e) {
            <p class="mt-3 text-sm text-destructive" role="alert">{{ e }}</p>
          }

          @if (logs().length > 0) {
            <p class="mb-2 mt-5 font-mono text-[10px] uppercase tracking-wider text-bcl-ink-muted">Recent trips</p>
            <ul class="grid gap-2">
              @for (lg of logs(); track lg.id) {
                <li class="flex items-center justify-between gap-2 rounded-md border border-bcl-border bg-bcl-bg-elev px-3 py-2 text-sm">
                  <span class="text-bcl-ink-muted">{{ day(lg.started_at) }}</span>
                  <span class="font-mono tabular-nums" [class.text-bcl-ink]="done(lg)" [class.text-bcl-warn]="!done(lg)">
                    {{ done(lg) ? miles(lg.miles) : 'in progress' }}
                  </span>
                </li>
              }
            </ul>
          }
        </div>
      </div>
    }
  `,
})
export class CrewMileageCardComponent implements OnInit {
  readonly visible = signal(false);
  readonly logs = signal<readonly MileageLog[]>([]);
  readonly totalMiles = signal(0);
  readonly active = signal<ActiveTrip | null>(null);
  readonly busy = signal(false);
  readonly error = signal<string>('');

  readonly miles = formatMiles;
  readonly done = isComplete;

  ngOnInit(): void {
    this.active.set(parseActiveTrip(this.readStore()));
    void this.reload();
  }

  /**
   * Download the year's mileage log as a CSV for tax filing. Pure serialization
   * lives in {@link mileageToCsv}; this owns only the Blob + anchor click. No-op
   * when there are no trips (the button is hidden in that state anyway).
   */
  exportCsv(): void {
    const rows = this.logs();
    if (rows.length === 0) return;
    const blob = new Blob([mileageToCsv(rows, this.totalMiles())], {
      type: 'text/csv;charset=utf-8',
    });
    const url = URL.createObjectURL(blob);
    try {
      const a = globalThis.document.createElement('a');
      a.href = url;
      a.download = mileageCsvFilename();
      a.click();
    } finally {
      URL.revokeObjectURL(url);
    }
  }

  day(iso: string): string {
    const t = Date.parse(iso);
    return Number.isNaN(t)
      ? iso
      : new Date(t).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  }

  private readStore(): string | null {
    try {
      return globalThis.localStorage?.getItem(STORAGE_KEY) ?? null;
    } catch {
      return null;
    }
  }
  private writeStore(v: ActiveTrip | null): void {
    try {
      if (v) globalThis.localStorage?.setItem(STORAGE_KEY, JSON.stringify(v));
      else globalThis.localStorage?.removeItem(STORAGE_KEY);
    } catch {
      /* private mode / unavailable — non-fatal */
    }
  }

  async reload(): Promise<void> {
    try {
      const res = await fetch('/api/work/mileage', { credentials: 'include' });
      if (!res.ok) {
        this.visible.set(false); // 401 anon
        return;
      }
      const data = (await res.json().catch(() => null)) as MileageResponse | null;
      if (!data?.ok) {
        this.visible.set(false);
        return;
      }
      this.logs.set(data.logs ?? []);
      this.totalMiles.set(data.totalMiles ?? 0);
      this.visible.set(true);
    } catch {
      this.visible.set(false);
    }
  }

  private async coords(): Promise<{ lat: number; lng: number }> {
    if (!globalThis.navigator?.geolocation) throw new Error('no_geo');
    return new Promise((resolve, reject) => {
      globalThis.navigator.geolocation.getCurrentPosition(
        (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        () => reject(new Error('denied')),
        { enableHighAccuracy: true, timeout: 10_000, maximumAge: 30_000 },
      );
    });
  }

  async start(): Promise<void> {
    this.busy.set(true);
    this.error.set('');
    try {
      const { lat, lng } = await this.coords();
      const res = await fetch('/api/work/mileage/start', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lat, lng }),
      });
      const data = (await res.json().catch(() => null)) as { ok?: boolean; id?: string } | null;
      if (!data?.ok || !data.id) throw new Error('start_failed');
      const trip: ActiveTrip = { id: data.id, startedAt: new Date().toISOString() };
      this.writeStore(trip);
      this.active.set(trip);
      await this.reload();
    } catch (e) {
      this.error.set(
        e instanceof Error && e.message === 'denied'
          ? 'Location permission is needed to log mileage.'
          : 'Could not start the trip. Try again.',
      );
    } finally {
      this.busy.set(false);
    }
  }

  async stop(): Promise<void> {
    const trip = this.active();
    if (!trip) return;
    this.busy.set(true);
    this.error.set('');
    try {
      const { lat, lng } = await this.coords();
      const res = await fetch('/api/work/mileage/stop', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: trip.id, lat, lng }),
      });
      if (!res.ok) throw new Error('stop_failed');
      this.writeStore(null);
      this.active.set(null);
      await this.reload();
    } catch (e) {
      this.error.set(
        e instanceof Error && e.message === 'denied'
          ? 'Location permission is needed to close out the trip.'
          : 'Could not stop the trip. Try again.',
      );
    } finally {
      this.busy.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'mileage-card-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
