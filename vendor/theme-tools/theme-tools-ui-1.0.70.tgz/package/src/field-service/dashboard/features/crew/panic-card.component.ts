import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * CrewPanicCardComponent — on-shift safety / SOS surface on the crew console.
 * Angular port of React `work/PanicButton` (+ recent-events list). Live surface =
 * Angular /dashboard, crew. A real safety feature: the trigger pages ops — built
 * here, Brian deploys; tests exercise only the pure helpers, never a live POST.
 *
 * Verified by mount (`app.route('/api/work/panic', workPanic)`):
 *   POST /api/work/panic  { kind:'panic'|'harassment', notes?, lat?, lng? }
 *   GET  /api/work/panic  → { events:[{id,kind,notes,severity,acknowledged_at,created_at}] }
 * Best-effort geolocation on trigger. Self-gates 401 → hide. Pure helpers
 * kindLabel/isAcknowledged/formatEventTime unit-tested.
 */
import { ChangeDetectionStrategy, Component, OnInit, signal } from '@angular/core';
import { HlmCardImports, HlmButton } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

export type PanicKind = 'panic' | 'harassment';

export interface PanicEvent {
  readonly id: string;
  readonly kind: string;
  readonly notes: string | null;
  readonly severity: string;
  readonly acknowledged_at: string | null;
  readonly created_at: string;
}

const KIND_LABEL: Readonly<Record<PanicKind, string>> = {
  panic: 'Emergency SOS',
  harassment: 'Harassment report',
};

/** Pure: human label for a panic kind. */
export function kindLabel(kind: string): string {
  return KIND_LABEL[kind as PanicKind] ?? 'Safety alert';
}

/** Pure: an event ops has acknowledged. */
export function isAcknowledged(e: Pick<PanicEvent, 'acknowledged_at'>): boolean {
  return !!e.acknowledged_at;
}

/** Pure: short local date-time, tolerant of junk. */
export function formatEventTime(iso: string): string {
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return iso;
  return new Date(t).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
}

@Component({
  selector: 'app-crew-panic-card',
  standalone: true,
  imports: [...HlmCardImports, HlmButton, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (visible()) {
      <div hlmCard bclReveal data-testid="crew-panic-card" class="border-destructive/40">
        <div hlmCardHeader>
          <h3 hlmCardTitle>Safety</h3>
          <p hlmCardDescription>On a job and feel unsafe? Alert ops immediately — we'll call you.</p>
        </div>
        <div hlmCardContent>
          @if (sent()) {
            <p class="mb-3 rounded-md border border-bcl-success/40 bg-bcl-success/10 px-3 py-2 text-sm text-bcl-success" role="status">
              ✓ Alert sent — ops have been paged and will call you. Stay safe.
            </p>
          }
          <div class="flex flex-wrap gap-2">
            <button hlmBtn variant="destructive" [disabled]="busy()" (click)="confirmAndFire('panic')" data-testid="panic-sos">
              {{ busy() ? 'Sending…' : '🚨 Emergency SOS' }}
            </button>
            <button hlmBtn variant="outline" [disabled]="busy()" (click)="confirmAndFire('harassment')">
              Report harassment
            </button>
          </div>

          @if (error(); as e) {
            <p class="mt-3 text-sm text-destructive" role="alert">{{ e }}</p>
          }

          @if (events().length > 0) {
            <p class="mb-2 mt-5 font-mono text-[10px] uppercase tracking-wider text-bcl-ink-muted">Recent alerts</p>
            <ul class="grid gap-2">
              @for (ev of events(); track ev.id) {
                <li class="flex items-center justify-between gap-2 rounded-md border border-bcl-border bg-bcl-bg-elev px-3 py-2 text-sm">
                  <span class="min-w-0">
                    <span class="text-bcl-ink">{{ label(ev.kind) }}</span>
                    <span class="ml-2 text-xs text-bcl-ink-muted">{{ when(ev.created_at) }}</span>
                  </span>
                  <span
                    class="shrink-0 rounded-full px-2 py-0.5 text-xs ring-1"
                    [class.text-bcl-success]="ack(ev)"
                    [class.ring-bcl-success\/40]="ack(ev)"
                    [class.text-bcl-warn]="!ack(ev)"
                    [class.ring-bcl-warn\/40]="!ack(ev)"
                  >{{ ack(ev) ? 'Acknowledged' : 'Pending' }}</span>
                </li>
              }
            </ul>
          }
        </div>
      </div>
    }
  `,
})
export class CrewPanicCardComponent implements OnInit {
  readonly visible = signal(false);
  readonly events = signal<readonly PanicEvent[]>([]);
  readonly busy = signal(false);
  readonly sent = signal(false);
  readonly error = signal<string>('');

  readonly label = kindLabel;
  readonly ack = isAcknowledged;
  readonly when = formatEventTime;

  ngOnInit(): void {
    void this.reload();
  }

  async reload(): Promise<void> {
    try {
      const res = await fetch('/api/work/panic', { credentials: 'include' });
      if (!res.ok) {
        this.visible.set(false); // 401 anon
        return;
      }
      const data = (await res.json().catch(() => null)) as { events?: readonly PanicEvent[] } | null;
      this.events.set(data?.events ?? []);
      this.visible.set(true);
    } catch {
      this.visible.set(false);
    }
  }

  private async getGeo(): Promise<{ lat?: number; lng?: number }> {
    if (!globalThis.navigator?.geolocation) return {};
    return new Promise((resolve) => {
      const done = (v: { lat?: number; lng?: number }) => resolve(v);
      try {
        globalThis.navigator.geolocation.getCurrentPosition(
          (pos) => done({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
          () => done({}),
          { timeout: 5000, maximumAge: 60_000 },
        );
      } catch {
        done({});
      }
    });
  }

  async confirmAndFire(kind: PanicKind): Promise<void> {
    const msg =
      kind === 'panic'
        ? 'Send an emergency SOS to ops now?'
        : 'Report harassment to ops now?';
    if (!globalThis.confirm?.(msg)) return;
    this.busy.set(true);
    this.error.set('');
    try {
      const geo = await this.getGeo();
      const res = await fetch('/api/work/panic', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ kind, ...geo }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      this.sent.set(true);
      await this.reload();
    } catch {
      this.error.set("Couldn't send the alert. Call ops directly if this is an emergency.");
    } finally {
      this.busy.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'panic-card-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
