import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * PayoutRequestComponent — Wave 27 instant payout dialog.
 * Gated by feature flag `instant_payout_rtp`.
 *
 * Lets a crew worker request an instant payout via RTP (real-time) or ACH.
 * Server validates ≥10 completed gigs + ledger balance.
 */
import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HlmCardImports, HlmButton, HlmInput } from '../../shared/ui-spartan';
import { CrewEarningsService } from '../../core/crew-earnings.service';

@Component({
  selector: 'app-crew-payout-request',
  standalone: true,
  imports: [...HlmCardImports, HlmButton, HlmInput, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="mb-6">
      <h1 class="text-2xl font-bold text-foreground">Request instant payout</h1>
      <p class="text-sm text-muted-foreground">
        Cash out today. RTP arrives in seconds, ACH next business day.
      </p>
    </header>

    <div class="grid gap-4 md:grid-cols-[2fr_1fr]">
      <div hlmCard>
        <div hlmCardHeader><h3 hlmCardTitle>Amount + rail</h3></div>
        <div hlmCardContent>
          <div class="space-y-4">
            <div>
              <label for="amount" class="mb-1 block text-sm font-medium text-foreground">
                Amount (USD)
              </label>
              <input
                hlmInput
                id="amount"
                type="number"
                min="1"
                step="0.01"
                [ngModel]="amountDollars()"
                (ngModelChange)="setAmount($event)"
                class="w-full tabular-nums"
                placeholder="50.00"
                [attr.aria-invalid]="amountInvalid() ? 'true' : null"
                [attr.aria-describedby]="describedBy()"
              />
              <p id="payout-fee-hint" class="mt-1 text-xs text-muted-foreground">
                Fee: 1.5%, capped at $1.50. Brick Labor absorbs the fee on payouts under $100.
              </p>
              @if (amountConstraint(); as msg) {
                <p
                  id="payout-amount-constraint"
                  class="mt-1 text-xs font-medium text-destructive"
                  role="status"
                  aria-live="polite"
                >
                  {{ msg }}
                </p>
              }
            </div>

            <fieldset>
              <legend class="mb-2 block text-sm font-medium text-foreground">Rail</legend>
              <div class="grid gap-2 sm:grid-cols-2">
                <label
                  class="flex cursor-pointer items-start gap-3 rounded-lg px-4 py-3 ring-1 transition"
                  [class.ring-primary]="rail() === 'rtp'"
                  [class.bg-primary]="rail() === 'rtp'"
                  [class.bg-opacity-10]="rail() === 'rtp'"
                  [class.ring-border]="rail() !== 'rtp'"
                >
                  <input type="radio" name="rail" value="rtp" [checked]="rail() === 'rtp'" (change)="rail.set('rtp')" class="mt-1" />
                  <div>
                    <div class="font-medium text-foreground">RTP (instant)</div>
                    <div class="text-xs text-muted-foreground">
                      Seconds — works at participating banks, 24/7.
                    </div>
                  </div>
                </label>
                <label
                  class="flex cursor-pointer items-start gap-3 rounded-lg px-4 py-3 ring-1 transition"
                  [class.ring-primary]="rail() === 'ach'"
                  [class.bg-primary]="rail() === 'ach'"
                  [class.bg-opacity-10]="rail() === 'ach'"
                  [class.ring-border]="rail() !== 'ach'"
                >
                  <input type="radio" name="rail" value="ach" [checked]="rail() === 'ach'" (change)="rail.set('ach')" class="mt-1" />
                  <div>
                    <div class="font-medium text-foreground">ACH (next business day)</div>
                    <div class="text-xs text-muted-foreground">Slower but no eligibility gate.</div>
                  </div>
                </label>
              </div>
            </fieldset>

            <label class="flex items-start gap-2 text-sm text-muted-foreground">
              <input type="checkbox" [ngModel]="agreed()" (ngModelChange)="agreed.set($event)" class="mt-1" />
              <span>
                I confirm the amount is correct and authorize Brick Labor to transfer it to my
                linked account.
              </span>
            </label>

            <button hlmBtn type="button" class="w-full" (click)="submit()" [disabled]="!canSubmit() || submitting()">
              @if (submitting()) { Requesting… } @else { Request {{ formatAmount() }} payout }
            </button>

            @if (result(); as r) {
              @if (r.ok) {
                <div class="rounded-lg bg-bcl-success/10 px-4 py-3 text-sm text-foreground ring-1 ring-bcl-success/40">
                  Payout requested · status: {{ r.status }} · fee:
                  {{ ((r.fee_cents ?? 0) / 100).toFixed(2) }}
                </div>
              } @else {
                <div
                  class="rounded-lg bg-destructive/10 px-4 py-3 text-sm text-foreground ring-1 ring-destructive/40"
                  role="alert"
                  data-testid="payout-request-error"
                >
                  {{ errorMessage(r.error) }}
                  <a
                    href="mailto:hey@bricklabor.com?subject=Payout%20help"
                    class="ml-1 underline decoration-dotted hover:text-bcl-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                    >Contact support</a
                  >
                </div>
              }
            }
          </div>
        </div>
      </div>

      <div hlmCard>
        <div hlmCardHeader><h3 hlmCardTitle>Eligibility</h3></div>
        <div hlmCardContent>
          <ul class="space-y-2 text-sm text-muted-foreground">
            <li>≥ 10 completed gigs</li>
            <li>Active Stripe Connect account</li>
            <li>No open dispute / fraud hold</li>
            <li>Bank account verified</li>
          </ul>
        </div>
      </div>
    </div>
  `,
})
export class PayoutRequestComponent {
  private readonly svc = inject(CrewEarningsService);

  readonly rail = signal<'rtp' | 'ach'>('rtp');
  readonly submitting = signal(false);
  readonly result = signal<{
    ok: boolean;
    error?: string;
    fee_cents?: number;
    status?: string;
  } | null>(null);

  // Signals (not plain properties) so the template stays reactive under zoneless CD — the
  // derived aria-invalid / constraint / submit-disabled recompute the instant the amount changes.
  readonly amountDollars = signal(50);
  readonly agreed = signal(false);

  /** $1.00 minimum payout — matches the input's `min="1"`; below it the field is invalid. */
  readonly MIN_PAYOUT_CENTS = 100;

  /** Maps the payout-instant error CODE to a crew-facing message (no opaque codes on screen). */
  readonly errorMessage = payoutRequestErrorMessage;

  /** ngModel → signal bridge: coerce the raw input value to a finite number of dollars. */
  setAmount(v: unknown): void {
    const n = Number(v);
    this.amountDollars.set(Number.isFinite(n) ? n : 0);
  }

  private amountCents(): number {
    return Math.round((Number(this.amountDollars()) || 0) * 100);
  }

  canSubmit(): boolean {
    return this.agreed() && this.amountCents() >= this.MIN_PAYOUT_CENTS;
  }

  /** True when a POSITIVE amount is below the $1 minimum (empty/zero = incomplete, not invalid). */
  amountInvalid(): boolean {
    const c = this.amountCents();
    return c > 0 && c < this.MIN_PAYOUT_CENTS;
  }

  /** The announced reason the amount is rejected (polite live region); '' when valid/incomplete. */
  amountConstraint(): string {
    return this.amountInvalid() ? 'Minimum payout is $1.00.' : '';
  }

  /** Links the always-on fee hint, plus the constraint reason when the amount is invalid. */
  describedBy(): string {
    return this.amountInvalid() ? 'payout-fee-hint payout-amount-constraint' : 'payout-fee-hint';
  }

  formatAmount(): string {
    const n = Number(this.amountDollars()) || 0;
    return `$${n.toFixed(2)}`;
  }

  submit(): void {
    if (!this.canSubmit() || this.submitting()) return;
    const cents = this.amountCents();
    this.submitting.set(true);
    this.result.set(null);
    this.svc.requestPayout$(this.rail(), cents).subscribe((r) => {
      this.submitting.set(false);
      this.result.set({
        ok: r.ok,
        error: r.error,
        fee_cents: r.fee_cents,
        status: r.status,
      });
    });
  }
}

/**
 * Maps a `/api/crew/payout-instant` error CODE to a crew-facing message (mirrors
 * `startErrorMessage` for the payout-setup flow). Keeps opaque codes like
 * `insufficient_balance` / `stripe_account_required` off the crew's screen; a
 * "Contact support" link is rendered alongside for any unexpected failure.
 */
export function payoutRequestErrorMessage(code: string | undefined): string {
  switch (code) {
    case 'unauthorized':
      return 'Please sign in again to request a payout.';
    case 'rate_limited':
      return 'Too many attempts — try again in a few minutes.';
    case 'eligibility_failed':
      return 'We couldn’t verify your payout eligibility — try again shortly.';
    case 'stripe_account_required':
      return 'Finish setting up your payout account first, then request again.';
    case 'insufficient_balance':
      return 'That’s more than your available balance right now.';
    case 'payout_failed':
      return 'The payout didn’t go through — try again, or contact support if it keeps failing.';
    case 'network':
      return 'Connection issue — check your signal and try again.';
    default:
      return 'Payout failed. Try again or contact support.';
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'payout-request-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
