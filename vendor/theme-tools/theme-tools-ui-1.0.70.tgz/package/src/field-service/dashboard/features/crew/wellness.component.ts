import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * WellnessComponent — Wave 28 crew wellness hub (#56-60).
 *
 * Single screen exposing the five wellness features, each behind its own
 * feature flag. Sub-cards only render when their owning flag is on, so a
 * partial rollout is supported without code branches.
 *
 * Flags consulted:
 *   - wave28_eap_mental_health           → resources + redeem
 *   - wave28_flsa_break_enforce          → live break-status banner
 *   - wave28_anon_crew_feedback          → tip-line submit
 *   - wave28_financial_wellness_advance  → cash advance request
 *
 * Burnout detector (#56) is admin-facing — no surface here.
 */
import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { catchError, map, of } from 'rxjs';
import { HlmCardImports, HlmButton, HlmInput } from '../../shared/ui-spartan';
import { FeatureFlagService } from '../../core/feature-flag.service';

interface EapResource {
  id: string;
  kind: string;
  title: string;
  description: string;
  href: string;
  cta: string;
  badge?: string;
  redeemProvider?: string;
}

interface BreakStatus {
  required: boolean;
  reason?: string;
  active_break_id?: string;
  expires_at?: string;
  break_duration_minutes?: number;
}

interface AdvanceRow {
  id: string;
  amount_cents: number;
  status: string;
  requested_at: string;
}

@Component({
  selector: 'app-crew-wellness',
  standalone: true,
  imports: [...HlmCardImports, HlmButton, HlmInput, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="mb-6">
      <h1 class="text-2xl font-bold text-foreground">Wellness</h1>
      <p class="text-sm text-muted-foreground">
        Mental-health resources, FLSA break tracking, anonymous tip line, and emergency cash.
      </p>
    </header>

    @if (breakStatus(); as bs) {
      @if (bs.required) {
        <div hlmCard class="mb-4">
          <div hlmCardHeader><h3 hlmCardTitle>Mandatory break in effect</h3></div>
          <div hlmCardContent>
            <p class="text-foreground">
              You've worked 4+ consecutive hours. Dispatch is paused until
              <span class="font-semibold">{{ formatTime(bs.expires_at) }}</span>. Take care of
              yourself — Brian.
            </p>
          </div>
        </div>
      }
    }

    <div class="grid gap-4 md:grid-cols-2">
      @if (flags()['wave28_eap_mental_health']) {
        <div hlmCard>
          <div hlmCardHeader><h3 hlmCardTitle>Mental health resources</h3></div>
          <div hlmCardContent>
            @if (eapResources(); as rs) {
              <ul class="space-y-3">
                @for (r of rs; track r.id) {
                  <li class="rounded-lg p-3 ring-1 ring-border">
                    <div class="flex items-center justify-between gap-2">
                      <div>
                        <p class="font-medium text-foreground">{{ r.title }}</p>
                        <p class="text-xs text-muted-foreground">{{ r.description }}</p>
                      </div>
                      @if (r.badge) {
                        <span class="text-[10px] uppercase tracking-wide text-muted-foreground">{{ r.badge }}</span>
                      }
                    </div>
                    @if (r.redeemProvider) {
                      <button hlmBtn size="sm" type="button" class="mt-2" (click)="redeem(r.redeemProvider!)">{{ r.cta }}</button>
                    } @else {
                      <a [href]="r.href" target="_blank" rel="noopener" class="mt-2 inline-block text-sm text-primary hover:underline">
                        {{ r.cta }} →
                      </a>
                    }
                  </li>
                }
              </ul>
            } @else {
              <p class="py-6 text-center text-sm text-muted-foreground">Loading…</p>
            }
            @if (redeemResult(); as rr) {
              <div class="mt-3 rounded-lg bg-primary/10 p-3 text-sm ring-1 ring-primary/40">
                <p class="text-foreground">Code: <span class="font-mono">{{ rr.code }}</span></p>
                <p class="mt-1 text-xs text-muted-foreground">{{ rr.note }}</p>
              </div>
            }
          </div>
        </div>
      }

      @if (flags()['wave28_anon_crew_feedback']) {
        <div hlmCard>
          <div hlmCardHeader><h3 hlmCardTitle>Anonymous tip line</h3></div>
          <div hlmCardContent>
            <p class="mb-2 text-xs text-muted-foreground">
              Nothing identifying is stored — no name, no IP, no worker ID.
            </p>
            <textarea
              [(ngModel)]="feedbackBody"
              rows="4"
              maxlength="4000"
              class="w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
              placeholder="What's on your mind?"
            ></textarea>
            <button hlmBtn size="sm" type="button" class="mt-2" (click)="submitFeedback()" [disabled]="!feedbackBody.trim() || feedbackSubmitting()">
              @if (feedbackSubmitting()) { Sending… } @else { Send anonymously }
            </button>
            @if (feedbackResult()) {
              <p class="mt-2 text-xs text-muted-foreground">{{ feedbackResult() }}</p>
            }
          </div>
        </div>
      }

      @if (flags()['wave28_financial_wellness_advance']) {
        <div hlmCard>
          <div hlmCardHeader><h3 hlmCardTitle>Emergency cash advance</h3></div>
          <div hlmCardContent>
            <p class="mb-2 text-xs text-muted-foreground">
              Up to $200 against next payout. 0% fee. Once per 30 days.
            </p>
            <div class="flex items-end gap-2">
              <label class="flex-1">
                <span class="mb-1 block text-sm text-foreground">Amount (USD)</span>
                <input hlmInput type="number" min="10" max="200" step="1" [(ngModel)]="advanceDollars" class="w-full tabular-nums" />
              </label>
              <button hlmBtn type="button" (click)="requestAdvance()" [disabled]="advanceSubmitting() || advanceDollars < 10 || advanceDollars > 200">
                @if (advanceSubmitting()) { Requesting… } @else { Request }
              </button>
            </div>
            @if (advanceResult(); as ar) {
              <p class="mt-2 text-xs" [class.text-muted-foreground]="ar.ok" [class.text-destructive]="!ar.ok">
                {{ ar.message }}
              </p>
            }
            @if (advanceHistory().length > 0) {
              <ul class="mt-3 space-y-1 text-xs">
                @for (a of advanceHistory(); track a.id) {
                  <li class="flex justify-between text-muted-foreground">
                    <span>{{ formatTime(a.requested_at) }}</span>
                    <span class="tabular-nums">\${{ (a.amount_cents / 100).toFixed(0) }} · {{ a.status }}</span>
                  </li>
                }
              </ul>
            }
          </div>
        </div>
      }
    </div>
  `,
})
export class WellnessComponent {
  private readonly flagSvc = inject(FeatureFlagService);
  private readonly http = inject(HttpClient);

  readonly flags = this.flagSvc.flags;

  readonly eapResources = toSignal<EapResource[] | null>(
    this.http.get<{ ok: boolean; resources: EapResource[] }>('/api/wave28-eap/resources').pipe(
      map((r) => r?.resources ?? []),
      catchError(() => of([] as EapResource[])),
    ),
    { initialValue: null },
  );

  readonly breakStatus = toSignal<BreakStatus | null>(
    this.http
      .get<BreakStatus & { ok: boolean }>('/api/wave28-flsa-breaks/status')
      .pipe(catchError(() => of({ ok: false, required: false } as BreakStatus & { ok: boolean }))),
    { initialValue: null },
  );

  readonly redeemResult = signal<{ code: string; note: string } | null>(null);

  feedbackBody = '';
  readonly feedbackSubmitting = signal(false);
  readonly feedbackResult = signal<string | null>(null);

  advanceDollars = 100;
  readonly advanceSubmitting = signal(false);
  readonly advanceResult = signal<{ ok: boolean; message: string } | null>(null);
  readonly advanceHistory = signal<AdvanceRow[]>([]);

  constructor() {
    this.refreshAdvanceHistory();
  }

  redeem(provider: string): void {
    type R = { ok: boolean; code?: string; note?: string; error?: string };
    this.http
      .post<R>('/api/wave28-eap/redeem-credit', { provider })
      .pipe(catchError(() => of<R>({ ok: false, error: 'network' })))
      .subscribe((r) => {
        if (r.ok && r.code) {
          this.redeemResult.set({ code: r.code, note: r.note ?? '' });
        } else {
          this.redeemResult.set({
            code: '—',
            note:
              r.error === 'rate_limited' ? 'Limit reached — try again later.' : 'Could not redeem.',
          });
        }
      });
  }

  submitFeedback(): void {
    if (!this.feedbackBody.trim() || this.feedbackSubmitting()) return;
    this.feedbackSubmitting.set(true);
    type FR = { ok: boolean; message?: string; error?: string };
    this.http
      .post<FR>('/api/wave28-anon-feedback/submit', {
        channel: 'tip_line',
        body: this.feedbackBody,
      })
      .pipe(catchError(() => of<FR>({ ok: false, error: 'network' })))
      .subscribe((r) => {
        this.feedbackSubmitting.set(false);
        if (r.ok) {
          this.feedbackBody = '';
          this.feedbackResult.set(r.message ?? 'Received.');
        } else {
          this.feedbackResult.set(
            r.error === 'rate_limited' ? 'Rate limited — try later.' : 'Failed to send.',
          );
        }
      });
  }

  requestAdvance(): void {
    if (this.advanceSubmitting()) return;
    const cents = Math.round(this.advanceDollars * 100);
    if (cents < 1000 || cents > 20000) return;
    this.advanceSubmitting.set(true);
    type AR = { ok: boolean; status?: string; error?: string };
    this.http
      .post<AR>('/api/wave28-cash-advance/request', { amount_cents: cents })
      .pipe(catchError(() => of<AR>({ ok: false, error: 'network' })))
      .subscribe((r) => {
        this.advanceSubmitting.set(false);
        if (r.ok) {
          this.advanceResult.set({ ok: true, message: `Pending review — status: ${r.status}` });
          this.refreshAdvanceHistory();
        } else {
          this.advanceResult.set({ ok: false, message: r.error ?? 'Failed.' });
        }
      });
  }

  private refreshAdvanceHistory(): void {
    this.http
      .get<{ ok: boolean; rows: AdvanceRow[] }>('/api/wave28-cash-advance/me')
      .pipe(catchError(() => of({ ok: false, rows: [] as AdvanceRow[] })))
      .subscribe((r) => this.advanceHistory.set(r.rows ?? []));
  }

  formatTime(iso: string | undefined): string {
    if (!iso) return '—';
    const d = new Date(iso);
    if (isNaN(d.getTime())) return iso;
    return d.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    });
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'wellness-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
