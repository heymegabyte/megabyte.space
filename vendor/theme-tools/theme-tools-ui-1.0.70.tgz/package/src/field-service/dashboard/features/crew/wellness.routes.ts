import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * Wave 28 crew wellness lazy route (#56-60).
 *
 * Single screen at /crew/wellness — the component itself reads each owning
 * flag via FeatureFlagService and renders sub-cards conditionally, so a
 * partial rollout (e.g. only `wave28_eap_mental_health` flipped on) still
 * renders a useful page.
 *
 * The route guard checks the EAP flag as a coarse on/off — if ALL five
 * Wave 28 wellness flags are off, the whole route 404s. As soon as any of
 * them flips on the route resolves; the component handles the per-card
 * gate from there.
 */
import { Route } from '@angular/router';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { FeatureFlagService } from '../../core/feature-flag.service';

const WAVE28_WELLNESS_KEYS = [
  'wave28_burnout_detector',
  'wave28_eap_mental_health',
  'wave28_flsa_break_enforce',
  'wave28_anon_crew_feedback',
  'wave28_financial_wellness_advance',
];

export const CREW_WELLNESS_ROUTES: Route[] = [
  {
    path: 'wellness',
    canActivate: [
      async () => {
        const flagSvc = inject(FeatureFlagService);
        const router = inject(Router);
        const flags = await firstValueFrom(flagSvc.flags$);
        const anyOn = WAVE28_WELLNESS_KEYS.some((k) => flags[k]);
        if (anyOn) return true;
        router.navigate(['/']);
        return false;
      },
    ],
    loadComponent: () => import('./wellness.component').then((m) => m.WellnessComponent),
  },
];
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'wellness-routes',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
