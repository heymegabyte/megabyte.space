import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * CarbonImpactCardComponent — company-wide carbon-footprint transparency card on
 * the dashboard home. Angular port of the React `wave28/CarbonImpactCard` (live
 * surface = Angular /dashboard per the cutover).
 *
 * Fetches GET /api/wave28/carbon/dashboard (flag-gated server-side via
 * wave28_carbon_per_move_dashboard → 404 when dark). Self-gates: hides when dark,
 * the call fails, or there are no measured moves. Dark-cockpit Spartan styling.
 */
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  effect,
  inject,
  signal,
} from '@angular/core';
import { BclRevealDirective } from '../../shared/reveal.directive';
import { BclRollingCounterComponent } from '../_shared/rolling-counter.component';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { AuthService } from '../../core/auth.service';
import { FeatureFlagService } from '../../core/feature-flag.service';

/** Server flag gating GET /api/wave28/carbon/dashboard (404 when dark). */
const CARBON_FLAG = 'wave28_carbon_per_move_dashboard';

export interface CarbonTotals {
  readonly moves: number;
  readonly totalCo2Kg: number;
  readonly totalOffsetCents: number;
}

interface CarbonResponse {
  readonly ok: boolean;
  readonly totals?: CarbonTotals;
}

/** Pure: is there anything worth showing? */
export function hasCarbon(t: CarbonTotals | null): boolean {
  return !!t && t.moves > 0;
}

/** Pure: cents → 2-dp dollar display (offset cost is small, keep cents). */
export function offsetDollars(cents: number): string {
  return `$${(cents / 100).toFixed(2)}`;
}

@Component({
  selector: 'app-carbon-impact-card',
  standalone: true,
  imports: [BclRevealDirective, BclRollingCounterComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (visible()) {
      <section bclReveal bclReveal
        bclReveal
        data-testid="carbon-impact-card"
        class="rounded-xl bg-gradient-to-br from-emerald-500/8 to-transparent ring-1 ring-emerald-400/20 p-5 mb-6"
        aria-labelledby="carbon-title"
      >
        <header class="mb-2 flex items-baseline justify-between gap-3">
          <div>
            <p class="font-mono text-xs uppercase tracking-wide text-emerald-300">Transparency</p>
            <h2 id="carbon-title" class="text-lg font-semibold text-bcl-ink">Our carbon footprint</h2>
          </div>
          <span class="text-xs text-bcl-ink-muted tabular-nums">
            {{ totals()!.moves.toLocaleString() }} moves measured
          </span>
        </header>
        <p class="text-sm text-bcl-ink-muted">
          <strong class="text-2xl tabular-nums text-bcl-ink">
<bcl-rolling-counter [value]="totals()!.totalCo2Kg" suffix=" kg" />
          </strong>
          CO₂ emitted by our trucks since we started tracking. Offsetting via verified projects
          costs about {{ offset(totals()!.totalOffsetCents) }}.
        </p>
        <p class="mt-2 text-xs text-bcl-ink-muted">
          Computed from miles × truck MPG × EPA standard (8.887 kg CO₂/gallon).
        </p>
      </section>
    }
  `,
})
export class CarbonImpactCardComponent {
  private readonly http = inject(HttpClient);
  private readonly auth = inject(AuthService);
  private readonly flags = inject(FeatureFlagService);
  private readonly flagOn = this.flags.isOn(CARBON_FLAG);
  private fetched = false;

  readonly totals = signal<CarbonTotals | null>(null);
  readonly visible = computed(() => hasCarbon(this.totals()));

  constructor() {
    // Fetch exactly once, and only when a signed-in visitor AND the server flag
    // is live. The flag was cut (migration 0119) so it never reaches the public
    // payload → the card never probes the dead 404 endpoint → no browser console
    // error for guests OR signed-in customers. When the feature is rebuilt and
    // the flag re-allowlisted, the card self-activates.
    effect(() => {
      if (this.auth.authenticated() && this.flagOn() && !this.fetched) {
        this.fetched = true;
        void this.refresh();
      }
    });
  }

  async refresh(): Promise<void> {
    if (!this.auth.authenticated() || !this.flagOn()) {
      this.totals.set(null);
      return;
    }
    try {
      const resp = await firstValueFrom(
        this.http.get<CarbonResponse>('/api/wave28/carbon/dashboard', {
          withCredentials: true,
        }),
      );
      if (resp?.ok && resp.totals) this.totals.set(resp.totals);
      else this.totals.set(null);
    } catch {
      this.totals.set(null);
    }
  }

  offset(cents: number): string {
    return offsetDollars(cents);
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'carbon-impact-card-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
