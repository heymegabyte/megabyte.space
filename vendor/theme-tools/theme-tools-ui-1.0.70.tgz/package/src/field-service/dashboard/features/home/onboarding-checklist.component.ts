import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * OnboardingChecklist — persona-aware setup tasks on the home dashboard.
 *
 * The Worker returns:
 *   { ok, persona, tasks: [{ id, label, href, complete }] }
 *
 * Personas:
 *   - customer: payment method, invite household, save address, complete profile
 *   - crew:     background check, upload insurance, set availability, connect bank
 *   - admin:    provision first tenant, invite admin team, configure billing,
 *               add first feature flag
 *
 * Once every task is `complete`, the panel auto-retires (slides up). Users
 * can still surface it from /settings → "Setup checklist".
 */
import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  computed,
  inject,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { RoleService } from '../../core/role.service';
import { AuthService } from '../../core/auth.service';

interface ChecklistTask {
  readonly id: string;
  readonly label: string;
  readonly href?: string;
  readonly complete: boolean;
}

interface ChecklistResponse {
  readonly ok: boolean;
  readonly persona: 'customer' | 'crew' | 'super_admin';
  readonly tasks: readonly ChecklistTask[];
}

@Component({
  selector: 'app-onboarding-checklist',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (visible()) {
      <section
        class="rounded-xl bg-gradient-to-br from-bcl-accent/8 to-transparent ring-1 ring-bcl-accent/20 p-5 mb-6 transition-all"
        aria-labelledby="onboarding-title"
      >
        <header class="flex items-center justify-between mb-3">
          <div>
            <p class="font-mono text-xs uppercase tracking-wide text-bcl-accent">Get set up</p>
            <h2 id="onboarding-title" class="text-lg font-semibold text-bcl-ink">{{ title() }}</h2>
          </div>
          <button
            type="button"
            (click)="dismiss()"
            class="text-bcl-ink-muted hover:text-bcl-ink text-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
            aria-label="Dismiss onboarding checklist"
          >
            Dismiss
          </button>
        </header>

        <div class="flex items-center gap-3 mb-3">
          <div
            class="flex-1 h-2 rounded-full bg-bcl-bg-elev overflow-hidden"
            role="progressbar"
            [attr.aria-valuenow]="completedCount()"
            [attr.aria-valuemin]="0"
            [attr.aria-valuemax]="totalCount()"
            [attr.aria-label]="completedCount() + ' of ' + totalCount() + ' tasks complete'"
          >
            <div
              class="h-full bg-bcl-accent transition-[width]"
              [style.width.%]="progressPct()"
            ></div>
          </div>
          <span class="font-mono text-xs text-bcl-ink-muted">
            {{ completedCount() }}/{{ totalCount() }}
          </span>
        </div>

        <ul class="space-y-1.5">
          @for (t of tasks(); track t.id) {
            <li>
              <button
                type="button"
                (click)="activate(t)"
                class="flex w-full items-center gap-3 rounded-md px-2 py-1.5 text-left text-sm hover:bg-white/5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
              >
                <span
                  aria-hidden="true"
                  class="inline-flex items-center justify-center size-5 rounded-full ring-1"
                  [class.bg-bcl-accent]="t.complete"
                  [class.ring-bcl-accent]="t.complete"
                  [class.text-bcl-bg]="t.complete"
                  [class.bg-transparent]="!t.complete"
                  [class.ring-bcl-border]="!t.complete"
                >
                  @if (t.complete) {
                    <span class="text-[10px] font-bold">✓</span>
                  }
                </span>
                <span
                  [class.text-bcl-ink]="!t.complete"
                  [class.text-bcl-ink-muted]="t.complete"
                  [class.line-through]="t.complete"
                >
                  {{ t.label }}
                </span>
              </button>
            </li>
          }
        </ul>
      </section>
    }
  `,
})
export class OnboardingChecklistComponent implements OnInit {
  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);
  private readonly role = inject(RoleService);
  private readonly auth = inject(AuthService);

  readonly tasks = signal<readonly ChecklistTask[]>([]);
  readonly dismissed = signal<boolean>(false);

  readonly totalCount = computed(() => this.tasks().length);
  readonly completedCount = computed(() => this.tasks().filter((t) => t.complete).length);
  readonly progressPct = computed(() =>
    this.totalCount() === 0 ? 0 : Math.round((this.completedCount() / this.totalCount()) * 100),
  );
  readonly visible = computed(() => {
    if (this.dismissed()) return false;
    if (this.tasks().length === 0) return false;
    return this.completedCount() < this.totalCount();
  });

  readonly title = computed(() => {
    const persona = this.role.viewAs();
    if (persona === 'crew') return 'Get ready to take gigs';
    if (persona === 'super_admin') return 'Configure your operations';
    return 'Finish setting up your account';
  });

  ngOnInit(): void {
    void this.refresh();
  }

  async refresh(): Promise<void> {
    // Self-gate: the home index (/) renders for guests too — skip the
    // session-scoped onboarding fetch when signed out (no console 401, card
    // hides via the empty-tasks `visible()` computed).
    if (!this.auth.authenticated()) {
      this.tasks.set([]);
      return;
    }
    try {
      const resp = await firstValueFrom(
        this.http.get<ChecklistResponse>('/api/dashboard/onboarding', {
          withCredentials: true,
        }),
      );
      if (resp?.tasks) this.tasks.set(resp.tasks);
    } catch {
      this.tasks.set([]);
    }
  }

  activate(t: ChecklistTask): void {
    if (!t.href) return;
    if (t.href.startsWith('http')) {
      window.open(t.href, '_blank', 'noopener,noreferrer');
    } else {
      void this.router.navigateByUrl(t.href);
    }
  }

  dismiss(): void {
    this.dismissed.set(true);
    try {
      globalThis.localStorage?.setItem('bcl_onboarding_dismissed', '1');
    } catch {
      // ignore
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'onboarding-checklist-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
