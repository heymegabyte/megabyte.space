import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * RecurringPlansCardComponent — manage recurring hourly contracts on the
 * dashboard home. Angular port of the React `RecurringPlansPanel` +
 * `VacationHoldCard`. Live surface = Angular /dashboard.
 *
 * Reads GET /api/recurring-subscriptions/mine (session-scoped). Per plan the
 * customer can: see the standing cadence discount they earn, snooze (vacation
 * hold via POST /api/vacation-hold/pause), skip the next run (POST
 * /api/recurring-subscriptions/:id/skip-next), and cancel the contract (POST
 * /api/recurring-subscriptions/:id/cancel, two-step confirm so a stray tap can't
 * churn a paying customer). Self-gates: hides when the customer has no plans.
 * Dark-cockpit styling.
 *
 * Brick Labor's "subscription" is hourly crew on a standing cadence — NOT a SaaS
 * plan tier. The discount ladder below mirrors src/shared/recurring.ts.
 */
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  effect,
  inject,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { AuthService } from '../../core/auth.service';
import { FeatureFlagService } from '../../core/feature-flag.service';
import { HlmCardImports, HlmButton } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

/** Server flag gating GET /api/recurring-subscriptions/mine (404 when dark). */
const RECURRING_FLAG = 'recurring_subscriptions';
const VACATION_HOLD_FLAG = 'vacation_hold';

export type Frequency = 'daily' | 'weekly' | 'biweekly' | 'monthly';

export interface PlanSummary {
  readonly id: string;
  readonly frequency: Frequency;
  readonly status: 'active' | 'paused' | 'cancelled';
  readonly nextRunAt: string;
  readonly canPause: boolean;
  /** Present on the live /mine payload; older shapes fall back to status. */
  readonly canCancel?: boolean;
  readonly canSkip?: boolean;
  readonly canResume?: boolean;
  /** Present on the live /mine payload; older shapes fall back to status. */
  readonly canChangeFrequency?: boolean;
}

/** One switch-to target in the change-cadence picker. */
export interface CadenceOption {
  readonly frequency: Frequency;
  readonly label: string;
  readonly discount: string;
}

const FREQ_ORDER: ReadonlyArray<Frequency> = ['daily', 'weekly', 'biweekly', 'monthly'];

interface MineResponse {
  readonly ok: boolean;
  readonly subscriptions?: readonly PlanSummary[];
}

const FREQ_LABEL: Readonly<Record<Frequency, string>> = {
  daily: 'Daily',
  weekly: 'Weekly',
  biweekly: 'Biweekly',
  monthly: 'Monthly',
};

export function frequencyLabel(f: Frequency): string {
  return FREQ_LABEL[f] ?? 'Plan';
}

/**
 * Standing per-cadence discount — MUST stay in sync with the canonical
 * src/shared/recurring.ts RECURRING_PLANS ladder. The dashboard build can't
 * import src/shared, so a locked Jest test (FREQ_DISCOUNT parity) guards drift.
 */
export const FREQ_DISCOUNT: Readonly<Record<Frequency, number>> = {
  daily: 12,
  weekly: 8,
  biweekly: 5,
  monthly: 3,
};

/** Pure: cadence → "8% off" (empty string when there's no real discount). */
export function discountLabel(f: Frequency): string {
  const pct = FREQ_DISCOUNT[f] ?? 0;
  return pct > 0 ? `${pct}% off` : '';
}

/**
 * Canonical standard hourly rate: $50/hr per crew member (worker
 * `HOURLY_RATE_CENTS` = 5000; `laborCents = hours * crew * 5000`). The dashboard
 * build can't import src/shared, so the parity Jest spec below pins this to 5000.
 */
export const BASE_HOURLY_RATE_CENTS = 5000;

/** Pure: cadence → the per-crew-member hourly rate AFTER its standing discount, in cents. */
export function discountedHourlyCents(f: Frequency): number {
  const pct = FREQ_DISCOUNT[f] ?? 0;
  return Math.round((BASE_HOURLY_RATE_CENTS * (100 - pct)) / 100);
}

/** Pure: cents → compact USD, dropping a whole dollar's ".00" ("$46", "$47.50"). */
export function formatRateUsd(cents: number): string {
  const dollars = cents / 100;
  return `$${Number.isInteger(dollars) ? dollars.toFixed(0) : dollars.toFixed(2)}`;
}

/**
 * Pure: cadence → discounted hourly rate line ("$46/hr per crew member"). Empty
 * string when the cadence earns no real discount (one-time/custom never reach here).
 */
export function discountedHourlyLabel(f: Frequency): string {
  const pct = FREQ_DISCOUNT[f] ?? 0;
  if (pct <= 0) return '';
  return `${formatRateUsd(discountedHourlyCents(f))}/hr per crew member`;
}

/**
 * Pure: the cadences a customer can switch TO from `current` — every OTHER
 * cadence in catalog order (daily→weekly→biweekly→monthly), each carrying its
 * label + standing-discount badge so the picker shows the value of each switch.
 * The current cadence is excluded (switching to it is a server-side no-op).
 */
export function cadenceSwitchOptions(current: Frequency): readonly CadenceOption[] {
  return FREQ_ORDER.filter((f) => f !== current).map((f) => ({
    frequency: f,
    label: frequencyLabel(f),
    discount: discountLabel(f),
  }));
}

/**
 * Pure: a noon-UTC `next_run_at` ISO → a stable calendar date ("Jun 15, 2026").
 * Formats in UTC so the displayed day never drifts across the viewer's timezone.
 */
export function nextRunLabel(iso: string): string {
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return '';
  return new Date(t).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    timeZone: 'UTC',
  });
}

/** Pure: today (UTC) + n days → YYYY-MM-DD. */
export function addDaysYmd(fromYmd: string, days: number): string {
  const t = Date.parse(`${fromYmd}T00:00:00Z`);
  if (Number.isNaN(t)) return fromYmd;
  return new Date(t + days * 86_400_000).toISOString().slice(0, 10);
}

export const SNOOZE_PRESETS: ReadonlyArray<{ label: string; days: number }> = [
  { label: 'Snooze 14 days', days: 14 },
  { label: 'Snooze 30 days', days: 30 },
  { label: 'Snooze 60 days', days: 60 },
];

@Component({
  selector: 'app-recurring-plans-card',
  standalone: true,
  imports: [...HlmCardImports, HlmButton, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (visible()) {
      <div hlmCard bclReveal class="mb-6" data-testid="recurring-plans-card">
        <div hlmCardHeader>
          <h3 hlmCardTitle>Your recurring plans</h3>
          <p hlmCardDescription>Standing crew on a schedule — manage it without a phone call.</p>
        </div>
        <div hlmCardContent>
          @if (loading()) {
            <div class="space-y-2" aria-label="Loading recurring plans" data-testid="recurring-loading">
              <div class="h-16 animate-pulse rounded-lg bg-bcl-bg-elev"></div>
              <div class="h-16 animate-pulse rounded-lg bg-bcl-bg-elev"></div>
            </div>
          } @else if (loadError()) {
            <div class="rounded-lg border border-destructive/40 p-4" data-testid="recurring-load-error">
              <p class="text-sm text-destructive" role="alert">Recurring plans couldn't load.</p>
              <p class="mt-1 text-xs text-bcl-ink-muted">Check your connection and try again.</p>
              <button hlmBtn type="button" class="mt-3" (click)="load()">Try again</button>
            </div>
          } @else if (plans().length === 0) {
            <div class="rounded-lg border border-bcl-border bg-bcl-bg-elev/40 p-4" data-testid="recurring-empty">
              <p class="text-sm font-semibold text-bcl-ink">No recurring plans yet.</p>
              <p class="mt-1 text-xs text-bcl-ink-muted">Choose a standing cadence when you book your next crew.</p>
              <a hlmBtn class="mt-3" href="/book">Book recurring service</a>
            </div>
          } @else {
          <ul class="space-y-3">
            @for (p of plans(); track p.id) {
              <li class="rounded-lg border border-bcl-border bg-bcl-bg-elev/40 p-3">
                <div class="flex flex-wrap items-center justify-between gap-2">
                  <span class="font-semibold text-bcl-ink">{{ freq(p.frequency) }} plan</span>
                  <span class="flex items-center gap-2">
                    @if (discount(p.frequency)) {
                      <span
                        data-testid="recurring-discount"
                        class="rounded-full bg-bcl-success/15 px-2 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-wider text-bcl-success ring-1 ring-bcl-success/30 transition-all duration-[333ms]"
                        >{{ discount(p.frequency) }}</span
                      >
                    }
                    <span
                      class="rounded-full px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider text-bcl-ink-muted ring-1 ring-bcl-border"
                      >{{ p.status }}</span
                    >
                  </span>
                </div>
                @if (nextRun(p.nextRunAt) && p.status !== 'cancelled') {
                  <p class="mt-1 text-xs text-bcl-ink-muted">
                    Next visit <span class="text-bcl-ink">{{ nextRun(p.nextRunAt) }}</span>
                  </p>
                }
                @if (rate(p.frequency)) {
                  <p class="mt-1 text-xs text-bcl-ink-muted" data-testid="recurring-rate">
                    <span class="font-semibold text-bcl-success">{{ rate(p.frequency) }}</span>
                    <span>
                      · {{ discount(p.frequency) }} the {{ baseRateLabel }} standard rate</span
                    >
                  </p>
                }
                <div class="mt-2 flex flex-wrap items-center gap-2">
                  @if (showResume(p)) {
                    <button
                      hlmBtn
                      type="button"
                      data-testid="recurring-resume"
                      class="transition-all duration-[333ms]"
                      [disabled]="busy() === p.id"
                      (click)="resume(p.id)"
                    >
                      Resume plan
                    </button>
                  }
                  @if (p.canPause && vacationHoldOn()) {
                    @for (s of presets; track s.days) {
                      <button
                        hlmBtn
                        variant="outline"
                        type="button"
                        class="transition-all duration-[333ms]"
                        [disabled]="busy() === p.id"
                        (click)="snooze(p.id, s.days)"
                      >
                        {{ s.label }}
                      </button>
                    }
                  }
                  @if (showSkip(p)) {
                    <button
                      hlmBtn
                      variant="outline"
                      type="button"
                      data-testid="recurring-skip-next"
                      class="transition-all duration-[333ms]"
                      [disabled]="busy() === p.id"
                      (click)="skipNext(p.id)"
                    >
                      Skip next
                    </button>
                  }
                  @if (showChange(p)) {
                    <button
                      hlmBtn
                      variant="outline"
                      type="button"
                      data-testid="recurring-change-cadence"
                      class="transition-all duration-[333ms]"
                      [disabled]="busy() === p.id"
                      (click)="toggleChange(p.id)"
                    >
                      {{ changingCadence() === p.id ? 'Keep cadence' : 'Change cadence' }}
                    </button>
                  }
                  @if (showCancel(p)) {
                    @if (confirmingCancel() === p.id) {
                      <button
                        hlmBtn
                        variant="destructive"
                        type="button"
                        data-testid="recurring-cancel-confirm"
                        class="transition-all duration-[333ms]"
                        [disabled]="busy() === p.id"
                        (click)="cancel(p.id)"
                      >
                        Confirm cancel
                      </button>
                      <button
                        hlmBtn
                        variant="ghost"
                        type="button"
                        class="transition-all duration-[333ms]"
                        [disabled]="busy() === p.id"
                        (click)="confirmingCancel.set(null)"
                      >
                        Keep plan
                      </button>
                    } @else {
                      <button
                        hlmBtn
                        variant="ghost"
                        type="button"
                        data-testid="recurring-cancel"
                        class="text-bcl-ink-muted transition-all duration-[333ms] hover:text-destructive"
                        [disabled]="busy() === p.id"
                        (click)="confirmingCancel.set(p.id)"
                      >
                        Cancel plan
                      </button>
                    }
                  }
                </div>
                @if (changingCadence() === p.id) {
                  <div
                    class="mt-2 rounded-lg border border-bcl-border bg-bcl-bg-elev/60 p-2"
                    data-testid="recurring-cadence-picker"
                  >
                    <p class="mb-2 text-[11px] uppercase tracking-wider text-bcl-ink-muted">
                      Switch to
                    </p>
                    <div class="flex flex-wrap gap-2">
                      @for (opt of cadenceOptions(p); track opt.frequency) {
                        <button
                          hlmBtn
                          variant="outline"
                          type="button"
                          data-testid="recurring-cadence-option"
                          class="flex items-center gap-1.5 transition-all duration-[333ms]"
                          [disabled]="busy() === p.id"
                          (click)="changeFrequency(p.id, opt.frequency)"
                        >
                          <span>{{ opt.label }}</span>
                          @if (opt.discount) {
                            <span class="font-mono text-[10px] text-bcl-success">{{
                              opt.discount
                            }}</span>
                          }
                        </button>
                      }
                    </div>
                  </div>
                }
              </li>
            }
          </ul>
          }
          @if (error()) {
            <p class="mt-2 text-xs text-destructive" role="alert">{{ error() }}</p>
          }
          @if (notice()) {
            <p class="mt-2 text-xs text-bcl-success" role="status">{{ notice() }}</p>
          }
        </div>
      </div>
    }
  `,
})
export class RecurringPlansCardComponent {
  private readonly http = inject(HttpClient);
  private readonly auth = inject(AuthService);
  private readonly flags = inject(FeatureFlagService);
  private readonly flagOn = this.flags.isOn(RECURRING_FLAG);
  readonly vacationHoldOn = this.flags.isOn(VACATION_HOLD_FLAG);
  private fetched = false;

  readonly presets = SNOOZE_PRESETS;
  readonly plans = signal<readonly PlanSummary[]>([]);
  readonly loading = signal(false);
  readonly loadError = signal(false);
  readonly busy = signal<string | null>(null);
  readonly error = signal<string>('');
  readonly notice = signal<string>('');
  readonly confirmingCancel = signal<string | null>(null);
  readonly changingCadence = signal<string | null>(null);
  readonly visible = computed(() => this.auth.authenticated() && this.flagOn());

  constructor() {
    // Fetch once, only when signed in AND the recurring_subscriptions flag is
    // live (it's experimental/dark by default). Probing while dark 404s → a
    // browser console error on the most-trafficked route. Self-activates the
    // moment the flag is promoted.
    effect(() => {
      if (this.auth.authenticated() && this.flagOn() && !this.fetched) {
        this.fetched = true;
        void this.load();
      }
    });
  }

  async load(): Promise<void> {
    if (!this.auth.authenticated() || !this.flagOn()) {
      this.plans.set([]);
      return;
    }
    this.loading.set(true);
    this.loadError.set(false);
    try {
      const r = await firstValueFrom(
        this.http.get<MineResponse>('/api/recurring-subscriptions/mine', {
          withCredentials: true,
        }),
      );
      this.plans.set(r?.ok ? (r.subscriptions ?? []) : []);
    } catch {
      this.plans.set([]);
      this.loadError.set(true);
    } finally {
      this.loading.set(false);
    }
  }

  freq(f: Frequency): string {
    return frequencyLabel(f);
  }

  discount(f: Frequency): string {
    return discountLabel(f);
  }

  /** Discounted per-crew-member hourly rate line for the plan's cadence. */
  rate(f: Frequency): string {
    return discountedHourlyLabel(f);
  }

  /** The standard hourly rate the discount is taken off ("$50/hr"). */
  readonly baseRateLabel = `${formatRateUsd(BASE_HOURLY_RATE_CENTS)}/hr`;

  nextRun(iso: string): string {
    return nextRunLabel(iso);
  }

  /** Cancel is allowed unless the plan is already cancelled. */
  showCancel(p: PlanSummary): boolean {
    return p.canCancel ?? p.status !== 'cancelled';
  }

  /** Skip-next only advances an active plan's next run. */
  showSkip(p: PlanSummary): boolean {
    return p.canSkip ?? p.status === 'active';
  }

  /** Resume only reactivates a paused plan. */
  showResume(p: PlanSummary): boolean {
    return p.canResume ?? p.status === 'paused';
  }

  /** Cadence may be switched unless the plan is cancelled. */
  showChange(p: PlanSummary): boolean {
    return p.canChangeFrequency ?? p.status !== 'cancelled';
  }

  /** The other cadences this plan can switch to (excludes the current one). */
  cadenceOptions(p: PlanSummary): readonly CadenceOption[] {
    return cadenceSwitchOptions(p.frequency);
  }

  /** Open/close the change-cadence picker for one plan (clears the cancel confirm). */
  toggleChange(id: string): void {
    this.confirmingCancel.set(null);
    this.changingCadence.set(this.changingCadence() === id ? null : id);
  }

  async changeFrequency(id: string, frequency: Frequency): Promise<void> {
    this.startAction(id);
    try {
      const res = await fetch(
        `/api/recurring-subscriptions/${encodeURIComponent(id)}/change-frequency`,
        {
          method: 'POST',
          credentials: 'include',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ frequency }),
        },
      );
      if (!res.ok) {
        this.error.set('Could not change the cadence. Try again.');
        return;
      }
      this.changingCadence.set(null);
      this.notice.set(`Cadence switched to ${frequencyLabel(frequency).toLowerCase()}.`);
      await this.load();
    } catch {
      this.error.set('Network error. Try again.');
    } finally {
      this.busy.set(null);
    }
  }

  async snooze(id: string, days: number): Promise<void> {
    this.startAction(id);
    const today = new Date().toISOString().slice(0, 10);
    try {
      const res = await fetch('/api/vacation-hold/pause', {
        method: 'POST',
        credentials: 'include',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          recurringSubscriptionId: id,
          pausedFrom: today,
          pausedUntil: addDaysYmd(today, days),
          reason: 'vacation',
        }),
      });
      if (!res.ok) {
        this.error.set('Could not snooze the plan. Try again.');
        return;
      }
      this.notice.set('Snoozed — see you then.');
      await this.load();
    } catch {
      this.error.set('Network error. Try again.');
    } finally {
      this.busy.set(null);
    }
  }

  async skipNext(id: string): Promise<void> {
    this.startAction(id);
    try {
      const res = await fetch(`/api/recurring-subscriptions/${encodeURIComponent(id)}/skip-next`, {
        method: 'POST',
        credentials: 'include',
      });
      if (!res.ok) {
        this.error.set('Could not skip the next visit. Try again.');
        return;
      }
      this.notice.set('Next visit skipped.');
      await this.load();
    } catch {
      this.error.set('Network error. Try again.');
    } finally {
      this.busy.set(null);
    }
  }

  async resume(id: string): Promise<void> {
    this.startAction(id);
    try {
      const res = await fetch(`/api/recurring-subscriptions/${encodeURIComponent(id)}/resume`, {
        method: 'POST',
        credentials: 'include',
      });
      if (!res.ok) {
        this.error.set('Could not resume the plan. Try again.');
        return;
      }
      this.notice.set('Plan resumed — visits are scheduled again.');
      await this.load();
    } catch {
      this.error.set('Network error. Try again.');
    } finally {
      this.busy.set(null);
    }
  }

  async cancel(id: string): Promise<void> {
    this.startAction(id);
    try {
      const res = await fetch(`/api/recurring-subscriptions/${encodeURIComponent(id)}/cancel`, {
        method: 'POST',
        credentials: 'include',
      });
      if (!res.ok) {
        this.error.set('Could not cancel the plan. Try again.');
        return;
      }
      this.confirmingCancel.set(null);
      this.notice.set('Plan cancelled. No more visits will be scheduled.');
      await this.load();
    } catch {
      this.error.set('Network error. Try again.');
    } finally {
      this.busy.set(null);
    }
  }

  private startAction(id: string): void {
    this.busy.set(id);
    this.error.set('');
    this.notice.set('');
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'recurring-plans-card-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
