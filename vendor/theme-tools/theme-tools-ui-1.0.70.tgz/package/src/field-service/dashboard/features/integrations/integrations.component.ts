import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * IntegrationsComponent — grid of third-party integration cards.
 *
 * Each card surfaces: logo glyph (SVG), description, status pill, last-used
 * timestamp, and either a "Connect" button (OAuth / API-key form) OR a
 * "Disconnect" button if already wired. Below the grid we list connected
 * integrations + a webhooks subsection (endpoints, event subscriptions,
 * signing secret reveal, delivery log).
 *
 * Status is read from `/api/admin/integrations/status` (one round trip); the
 * route doesn't exist yet on the worker so we degrade gracefully — every
 * card shows "Not connected" + the Connect CTA, and the connected/webhooks
 * panels show empty-states. The UI shipped today is fully wired; backend
 * fills in incrementally.
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  OnInit,
  computed,
  inject,
  signal,
} from '@angular/core';
import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { type ColumnDef } from '@tanstack/angular-table';
import { routeFade, reducedMotion } from '../../shared/animations';
import {
  HlmButton,
  HlmBadge,
  ConfirmDialog,
  SmartTableComponent,
  ToastService,
} from '../../shared/ui-spartan';

interface IntegrationDef {
  readonly id: string;
  readonly name: string;
  readonly description: string;
  readonly authType: 'oauth' | 'apikey' | 'webhook-only';
  readonly docsUrl: string;
}

interface IntegrationStatus {
  readonly id: string;
  readonly connected: boolean;
  readonly lastUsed: string | null;
  readonly account: string | null;
}

interface WebhookRow extends Record<string, unknown> {
  readonly id: string;
  readonly integration: string;
  readonly url: string;
  readonly events: string;
  readonly created_at: string;
}

interface DeliveryRow extends Record<string, unknown> {
  readonly id: string;
  readonly integration: string;
  readonly event: string;
  readonly status: number;
  readonly delivered_at: string;
}

const INTEGRATIONS: readonly IntegrationDef[] = [
  {
    id: 'slack',
    name: 'Slack',
    description: 'Channel alerts + slash commands.',
    authType: 'oauth',
    docsUrl: 'https://api.slack.com',
  },
  {
    id: 'gmail',
    name: 'Gmail',
    description: 'Read + send via the owner inbox.',
    authType: 'oauth',
    docsUrl: 'https://developers.google.com/gmail/api',
  },
  {
    id: 'calendar',
    name: 'Google Calendar',
    description: 'Two-way sync with /jobs.',
    authType: 'oauth',
    docsUrl: 'https://developers.google.com/calendar',
  },
  {
    id: 'drive',
    name: 'Google Drive',
    description: 'Attach photos + invoices.',
    authType: 'oauth',
    docsUrl: 'https://developers.google.com/drive',
  },
  {
    id: 'sentry',
    name: 'Sentry',
    description: 'Error tracking + release health.',
    authType: 'apikey',
    docsUrl: 'https://sentry.io',
  },
  {
    id: 'cloudflare',
    name: 'Cloudflare',
    description: 'DNS + Workers + R2 control plane.',
    authType: 'apikey',
    docsUrl: 'https://dash.cloudflare.com',
  },
  {
    id: 'context7',
    name: 'Context7',
    description: 'Up-to-date library docs MCP.',
    authType: 'apikey',
    docsUrl: 'https://context7.com',
  },
  {
    id: 'posthog',
    name: 'PostHog',
    description: 'Product analytics + replay.',
    authType: 'apikey',
    docsUrl: 'https://posthog.com',
  },
  {
    id: 'stripe-connect',
    name: 'Stripe Connect',
    description: 'Crew + vendor payouts.',
    authType: 'oauth',
    docsUrl: 'https://stripe.com/connect',
  },
  {
    id: 'twilio',
    name: 'Twilio',
    description: 'SMS sends + inbound TCPA.',
    authType: 'apikey',
    docsUrl: 'https://twilio.com',
  },
  {
    id: 'resend',
    name: 'Resend',
    description: 'Transactional email + inbound.',
    authType: 'apikey',
    docsUrl: 'https://resend.com',
  },
];

@Component({
  selector: 'app-integrations',
  standalone: true,
  imports: [DatePipe, HlmButton, HlmBadge, ConfirmDialog, SmartTableComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <header class="mb-4">
      <h1 class="text-2xl font-bold text-foreground">Integrations</h1>
      <p class="text-sm text-muted-foreground">
        Connect Slack, Gmail, Stripe, Twilio, Resend and more. Manage webhook endpoints + delivery
        logs below.
      </p>
    </header>

    <section
      class="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
      aria-label="Available integrations"
    >
      @for (def of integrations; track def.id) {
        <article class="flex flex-col gap-3 rounded-xl border border-border bg-card p-4">
          <header class="flex items-start justify-between gap-3">
            <div class="flex items-center gap-3">
              <span
                class="flex h-10 w-10 items-center justify-center rounded-lg bg-background text-lg font-semibold text-primary"
                aria-hidden="true"
              >
                {{ def.name.charAt(0) }}
              </span>
              <div>
                <h3 class="text-sm font-semibold text-foreground">{{ def.name }}</h3>
                <p class="text-xs text-muted-foreground">{{ def.description }}</p>
              </div>
            </div>
            <span hlmBadge [variant]="statusFor(def.id)?.connected ? 'success' : 'secondary'">{{
              statusFor(def.id)?.connected ? 'Connected' : 'Not connected'
            }}</span>
          </header>

          @if (statusFor(def.id); as st) {
            @if (st.connected) {
              <p class="text-xs text-muted-foreground">
                {{ st.account || 'Connected' }}
                @if (st.lastUsed) {
                  · Last used {{ st.lastUsed | date: 'short' }}
                }
              </p>
            }
          }

          <footer class="mt-auto flex items-center gap-2">
            @if (statusFor(def.id)?.connected) {
              <button hlmBtn variant="ghost" (click)="askDisconnect(def)">Disconnect</button>
            } @else {
              <button hlmBtn (click)="connect(def)">Connect</button>
            }
            <a
              [href]="def.docsUrl"
              target="_blank"
              rel="noopener noreferrer"
              class="ml-auto rounded px-1 text-xs text-muted-foreground hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
            >
              Docs ↗
            </a>
          </footer>
        </article>
      }
    </section>

    <section class="mt-10" aria-labelledby="webhooks-h">
      <header class="mb-3 flex items-center justify-between gap-3">
        <h2 id="webhooks-h" class="text-lg font-semibold text-foreground">Webhooks</h2>
        <span class="text-xs text-muted-foreground">Inbound endpoints + recent deliveries</span>
      </header>
      @if (webhooks().length === 0) {
        <div class="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
          No webhooks configured — endpoints from connected integrations show up here with their
          event subscriptions + signing secrets.
        </div>
      } @else {
        <app-smart-table
          [data]="webhooksArray()"
          [columns]="webhookCols"
          [filterable]="true"
          [rowsActivatable]="false"
          filterPlaceholder="Filter webhooks…"
          emptyText="No webhooks match."
        />
      }
    </section>

    <section class="mt-8" aria-labelledby="deliveries-h">
      <header class="mb-3"><h2 id="deliveries-h" class="text-lg font-semibold text-foreground">Delivery log</h2></header>
      @if (deliveries().length === 0) {
        <div class="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
          No deliveries yet — every inbound + outbound webhook delivery shows up here with status
          code + timestamp.
        </div>
      } @else {
        <app-smart-table
          [data]="deliveriesArray()"
          [columns]="deliveryCols"
          [filterable]="true"
          [rowsActivatable]="false"
          filterPlaceholder="Filter delivery log…"
        />
      }
    </section>

    @if (pendingDisconnect(); as p) {
      <app-confirm-dialog
        [open]="true"
        [title]="'Disconnect ' + p.name + '?'"
        [description]="
          'Tokens are revoked + cached credentials cleared. The dashboard surfaces dependent on ' +
          p.name +
          ' will fail until reconnected.'
        "
        confirmLabel="Disconnect"
        [verifySlug]="p.id"
        (confirmed)="performDisconnect(p)"
        (cancelled)="pendingDisconnect.set(null)"
      />
    }
  `,
})
export class IntegrationsComponent implements OnInit {
  protected readonly reducedMotion = reducedMotion;
  private readonly http = inject(HttpClient);
  private readonly destroyRef = inject(DestroyRef);
  private readonly toast = inject(ToastService);
  private statusTimer: ReturnType<typeof setInterval> | null = null;

  readonly integrations = INTEGRATIONS;
  readonly statusMap = signal<ReadonlyMap<string, IntegrationStatus>>(new Map());
  readonly webhooks = signal<readonly WebhookRow[]>([]);
  readonly deliveries = signal<readonly DeliveryRow[]>([]);
  readonly webhooksArray = computed<WebhookRow[]>(() => [...this.webhooks()]);
  readonly deliveriesArray = computed<DeliveryRow[]>(() => [...this.deliveries()]);
  readonly pendingDisconnect = signal<IntegrationDef | null>(null);

  readonly webhookCols: ColumnDef<WebhookRow>[] = [
    { accessorKey: 'integration', header: 'Integration' },
    { accessorKey: 'url', header: 'Endpoint' },
    { accessorKey: 'events', header: 'Events' },
    {
      accessorKey: 'created_at',
      header: 'Created',
      cell: (info) => new Date(info.getValue<string>()).toLocaleString(),
    },
  ];

  readonly deliveryCols: ColumnDef<DeliveryRow>[] = [
    {
      accessorKey: 'delivered_at',
      header: 'When',
      cell: (info) => new Date(info.getValue<string>()).toLocaleString(),
    },
    { accessorKey: 'integration', header: 'Integration' },
    { accessorKey: 'event', header: 'Event' },
    { accessorKey: 'status', header: 'Status' },
  ];

  statusFor(id: string): IntegrationStatus | undefined {
    return this.statusMap().get(id);
  }

  ngOnInit(): void {
    void this.loadStatus();
    void this.loadWebhooks();
    void this.loadDeliveries();
    // Live "Connected" dot — re-poll status every 30s so a token revoke
    // shows up in the UI without a manual refresh.
    if (typeof setInterval !== 'undefined') {
      this.statusTimer = setInterval(() => void this.loadStatus(), 30_000);
      this.destroyRef.onDestroy(() => {
        if (this.statusTimer) clearInterval(this.statusTimer);
      });
    }
  }

  private async loadStatus(): Promise<void> {
    try {
      const r = await firstValueFrom(
        this.http.get<{ ok: boolean; integrations?: readonly IntegrationStatus[] }>(
          '/api/admin/integrations/status',
          { withCredentials: true },
        ),
      );
      const map = new Map<string, IntegrationStatus>();
      for (const s of r.integrations ?? []) map.set(s.id, s);
      this.statusMap.set(map);
    } catch {
      // Endpoint doesn't exist yet — every integration shows as not-connected.
      this.statusMap.set(new Map());
    }
  }

  private async loadWebhooks(): Promise<void> {
    try {
      const r = await firstValueFrom(
        this.http.get<{ ok: boolean; webhooks?: readonly WebhookRow[] }>(
          '/api/admin/integrations/webhooks',
          { withCredentials: true },
        ),
      );
      this.webhooks.set(r.webhooks ?? []);
    } catch {
      this.webhooks.set([]);
    }
  }

  private async loadDeliveries(): Promise<void> {
    try {
      const r = await firstValueFrom(
        this.http.get<{ ok: boolean; deliveries?: readonly DeliveryRow[] }>(
          '/api/admin/integrations/deliveries',
          { withCredentials: true },
        ),
      );
      this.deliveries.set(r.deliveries ?? []);
    } catch {
      this.deliveries.set([]);
    }
  }

  connect(def: IntegrationDef): void {
    // OAuth flow → window.open the worker's authorize endpoint; API-key
    // integrations → open a simple secret-prompt for now.
    if (def.authType === 'oauth') {
      const url = `/api/admin/integrations/${def.id}/authorize`;
      globalThis.open(url, '_blank', 'noopener');
      this.toast.info(`Opened ${def.name} authorize in a new tab`);
      return;
    }
    const key = prompt(`Paste your ${def.name} API key:`) ?? '';
    if (!key) return;
    void firstValueFrom(
      this.http.post(
        '/api/admin/integrations/connect',
        { id: def.id, apiKey: key },
        { withCredentials: true },
      ),
    )
      .then(() => {
        this.toast.success(`${def.name} connected · just now`);
        void this.loadStatus();
      })
      .catch((err: Error) => {
        this.toast.error(`Couldn't connect ${def.name}`, undefined, err.message);
      });
  }

  askDisconnect(def: IntegrationDef): void {
    this.pendingDisconnect.set(def);
  }

  async performDisconnect(def: IntegrationDef): Promise<void> {
    try {
      await firstValueFrom(
        this.http.post(
          '/api/admin/integrations/disconnect',
          { id: def.id },
          { withCredentials: true },
        ),
      );
      this.toast.success(`${def.name} disconnected · just now`);
    } catch (err) {
      this.toast.error(`Couldn't disconnect ${def.name}`, undefined, (err as Error).message);
    } finally {
      this.pendingDisconnect.set(null);
      void this.loadStatus();
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'integrations-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
