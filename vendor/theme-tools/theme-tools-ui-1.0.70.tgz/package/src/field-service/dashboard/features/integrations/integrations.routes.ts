import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { Route } from '@angular/router';

export const INTEGRATIONS_ROUTES: Route[] = [
  {
    path: '',
    loadComponent: () => import('./integrations.component').then((m) => m.IntegrationsComponent),
  },
];
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'integrations-routes',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
