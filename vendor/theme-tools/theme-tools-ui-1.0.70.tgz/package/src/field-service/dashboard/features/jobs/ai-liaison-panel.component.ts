import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * AiLiaisonPanelComponent — AI-mediated "message customer" (Deliverable B, idea #4).
 *
 * The crew types a plain message (or taps a quick-intent chip); the AI liaison
 * rewrites it into a polished, on-brand, customer-facing message and relays it.
 * The crew sees the drafted message + whether the AI or the deterministic floor
 * produced it, then it's confirmed sent. Protects the brand (no raw venting to
 * customers) + crew privacy (no direct number exchange). Reuses AiLiaisonService,
 * which the worker backs with a deterministic templated floor so the surface
 * never dead-ends when the model is unavailable (prod runs keyless).
 *
 * Standalone + signals + OnPush + zoneless-safe. brand orange. Mobile-first.
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  inject,
  input,
  signal,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { AiLiaisonService, type LiaisonIntent } from '../../core/ai-liaison.service';

interface QuickIntent {
  readonly key: LiaisonIntent;
  readonly label: string;
}

const QUICK_INTENTS: readonly QuickIntent[] = [
  { key: 'on_my_way', label: 'On my way' },
  { key: 'running_late', label: 'Running late' },
  { key: 'arrived', label: 'Arrived' },
  { key: 'need_access', label: 'Need access' },
  { key: 'almost_done', label: 'Almost done' },
];

@Component({
  selector: 'app-ai-liaison',
  standalone: true,
  imports: [FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section
      data-testid="ai-liaison"
      class="rounded-xl border border-border bg-card p-4"
      aria-label="Message customer"
    >
      <div class="mb-2 flex items-center gap-2">
        <span
          class="flex h-6 w-6 items-center justify-center rounded-full bg-primary/15 text-primary"
          aria-hidden="true"
          >✦</span
        >
        <h3 class="text-sm font-semibold text-foreground">Message customer</h3>
        <span class="ml-auto text-[10px] uppercase tracking-wider text-muted-foreground"
          >AI-assisted</span
        >
      </div>
      <p class="mb-3 text-xs text-muted-foreground">
        Type a quick note — we polish it and send it to the customer. Your number stays private.
      </p>

      <div class="mb-3 flex flex-wrap gap-2">
        @for (qi of quickIntents; track qi.key) {
          <button
            type="button"
            (click)="send(qi.key, '')"
            [disabled]="pending()"
            class="min-h-[36px] rounded-full border border-border px-3 text-xs font-medium text-foreground transition-colors hover:bg-accent/50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring disabled:opacity-50"
            [attr.data-testid]="'liaison-intent-' + qi.key"
          >
            {{ qi.label }}
          </button>
        }
      </div>

      <label class="sr-only" [attr.for]="'liaison-text'">Message to customer</label>
      <textarea
        id="liaison-text"
        [(ngModel)]="draft"
        rows="2"
        maxlength="600"
        placeholder="e.g. Running 15 late, traffic on McCarter"
        data-testid="liaison-input"
        class="w-full resize-none rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
      ></textarea>

      <div class="mt-2 flex items-center justify-end">
        <button
          type="button"
          (click)="send('custom', draft())"
          [disabled]="pending() || draft().trim().length === 0"
          data-testid="liaison-send"
          class="inline-flex min-h-[44px] items-center justify-center rounded-lg bg-primary px-4 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring disabled:opacity-50"
        >
          <span class="min-w-[7ch] text-center">{{ pending() ? 'Sending…' : 'Send' }}</span>
        </button>
      </div>

      @if (sentMessage(); as m) {
        <div
          class="mt-3 rounded-lg border border-primary/30 bg-primary/5 p-3"
          role="status"
          data-testid="liaison-sent"
        >
          <p class="text-[10px] uppercase tracking-wider text-primary">
            Sent to customer{{ aiUsed() ? ' · polished by AI' : '' }}
          </p>
          <p class="mt-1 text-sm text-foreground">{{ m }}</p>
        </div>
      }
      @if (errorMsg(); as e) {
        <p class="mt-3 text-xs text-destructive" role="alert">{{ e }}</p>
      }
    </section>
  `,
})
export class AiLiaisonPanelComponent {
  private readonly liaison = inject(AiLiaisonService);
  private readonly destroyRef = inject(DestroyRef);

  readonly gigId = input.required<string>();
  /** Optional revised ETA (minutes) carried on on_my_way / running_late intents. */
  readonly etaMinutes = input<number | undefined>(undefined);

  readonly quickIntents = QUICK_INTENTS;
  readonly draft = signal('');
  readonly pending = signal(false);
  readonly sentMessage = signal<string | null>(null);
  readonly aiUsed = signal(false);
  readonly errorMsg = signal<string | null>(null);

  send(intent: LiaisonIntent, text: string): void {
    if (this.pending()) return;
    const gigId = this.gigId();
    if (!gigId) return;
    this.pending.set(true);
    this.errorMsg.set(null);
    const eta =
      intent === 'on_my_way' || intent === 'running_late' ? this.etaMinutes() : undefined;
    this.liaison
      .relay$(gigId, intent, text, eta)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((res) => {
        this.pending.set(false);
        if (res.ok && res.message) {
          this.sentMessage.set(res.message);
          this.aiUsed.set(Boolean(res.aiUsed));
          if (intent === 'custom') this.draft.set('');
        } else {
          this.errorMsg.set(
            res.error === 'unavailable'
              ? 'Messaging is not available right now.'
              : 'Could not send — try again.',
          );
        }
      });
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'ai-liaison-panel-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
