import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * JobDetailComponent — smartphone-first crew Job Detail page (/dashboard/jobs/:id,
 * Deliverable B). The single most-used crew screen: phone-first, one-tap everything.
 *
 * Integrates the top-12 job-detail features:
 *   1  embedded keyless Google map of the destination (<app-address-map>)
 *   2  specially-crafted job-details table (<app-job-details-table>)
 *   3  sticky safe-area one-tap action bar (Directions · Call · Message · Start/End · Photos)
 *   4  AI-mediated "message customer" (<app-ai-liaison> — crew↔AI↔customer, deterministic floor)
 *   5  one-tap Google/Apple directions (native maps app)
 *   6  GPS check-in gate + Start/End stamps (POST check-in + start)
 *   7  day-of contact card (masked call/text + operator hotline)
 *   8  one-tap masked call (tel: to the masked line)
 *   9  before/after photo capture — gates Start (≥1 before) + Complete (≥1 after)
 *   10 lifecycle timeline (offer → paid) via <bcl-status-timeline>
 *   11 running-late (+15/+30/+60) + scope-change quick actions (auto-notify customer)
 *   12 on-site collect / pay summary (<bcl-terminal-checkout-card> + earnings line)
 *
 * Flag-gated by featureFlagGuard('crew_job_detail_v2') at the route. Deep-linkable
 * from an offer/email link (the ?token= handoff is the worker /api/gig/deep-link
 * seam, separate). Standalone + signals + OnPush + zoneless-safe; strict, no `any`.
 * Data spine: GET /api/work/gigs/:id (transparency envelope) + /:id/photos. All
 * lifecycle mutations reuse the existing work-gigs endpoints.
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  inject,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ActivatedRoute } from '@angular/router';
import { GeolocationService } from '../../core/geolocation.service';
import { HlmCardImports, HlmBadge, HlmButton, HlmSkeleton } from '../../shared/ui-spartan';
import {
  StatusTimelineComponent,
  type RideStatusStep,
  type RideStatusTransition,
} from '../_shared/status-timeline.component';
import { TerminalCheckoutCardComponent } from '../_shared/terminal-checkout-card.component';
import { JobPhotosCardComponent } from '../_shared/job-photos-card.component';
import { money } from '@theme.tools/billing/field-service/money';
import { AddressMapComponent } from '../_shared/address-map.component';
import { GigOfferCardComponent, type GigOffer } from '../_shared/gig-offer-card.component';
import { AiLiaisonPanelComponent } from './ai-liaison-panel.component';
import { JobDetailsTableComponent, type JobDetailRow } from './job-details-table.component';
import { RateCustomerComponent } from './rate-customer.component';

/**
 * Offer window (seconds) — mirrors the worker `OFFER_TIMEOUT_S` default (30s).
 * The transparency envelope carries no `expiresAt`, so the crew-facing countdown
 * is anchored to the first moment we observe the `invited` claim in this session.
 */
const OFFER_TIMEOUT_S = 30;

/** GET /api/work/gigs/:id transparency envelope (subset consumed here). */
interface GigTransparency {
  readonly gigId: string;
  readonly claimStatus: string;
  readonly pay: {
    readonly centsPerHour: number;
    readonly estimatedTotalCents: number;
    readonly rushBonusCents: number;
    readonly shiftLeadBonusCents?: number;
    readonly hoursEstimated: number;
  };
  readonly location: {
    readonly cityLevel: string;
    readonly streetAddress: string | null;
    readonly zip: string | null;
    readonly lat: number | null;
    readonly lng: number | null;
  };
  readonly scopeSummary: string | null;
  readonly customerNotes: string | null;
  readonly crewFilled: number;
  readonly crewNeeded: number;
  /** fire-147 — server-computed: this crew is the gig's designated shift lead. */
  readonly isShiftLead?: boolean;
  readonly needsDriver: boolean;
  readonly needsHauling: boolean;
  readonly startAt: string;
  /** SCAN-13 — customer reviewee_id (booking id) the crew rates via POST /:gigId. */
  readonly bookingId?: string;
  /** SCAN-13 — true once THIS crew has rated the customer on this gig. */
  readonly ratedCustomer?: boolean;
  readonly customer: { readonly ratingAvg: number | null; readonly priorJobCount: number };
  /**
   * SCAN-42 — purchased inventory-insurance coverage bound to THIS booking
   * (the `inventory_insurance` feature's per-booking `inventory_bindings` row),
   * surfaced to the crew only when the `crew_job_coverage` flag is on. Absent or
   * null = no active added coverage (or the flag is dark) → the Coverage row is
   * omitted. A mover seeing "Insured up to $X" is a real care/liability signal.
   */
  readonly coverage?: { readonly coverageCents: number; readonly tier: string } | null;
}

interface PhotoStatus {
  readonly beforeCount: number;
  readonly afterCount: number;
  readonly canComplete: boolean;
  /** GP-05 mirror: how many of each are required for Start / Complete (1 when the
   * day-of gates flag is OFF, 4 when ON — the worker decides and sends it). */
  readonly beforeRequired: number;
  readonly afterRequired: number;
  readonly beforeRemaining: number;
  readonly afterRemaining: number;
  /** True when the ≥N before-photo precondition for Start is met (always true when
   * the flag is OFF — Start has no photo gate then). */
  readonly canStartPhotos: boolean;
  /** True when the day-of execution gates flag is ON (drives the mirrored copy). */
  readonly gatesEnforced: boolean;
}

/** Map the worker claim status → the shared 6-step timeline step. */
function claimToStep(claimStatus: string): RideStatusStep {
  switch (claimStatus) {
    case 'invited':
      return 'requested';
    case 'accepted':
    case 'confirmed':
      return 'matched';
    case 'checked_in':
      return 'working';
    case 'completed':
      return 'complete';
    default:
      return 'matched';
  }
}

@Component({
  selector: 'app-job-detail',
  standalone: true,
  imports: [
    ...HlmCardImports,
    HlmBadge,
    HlmButton,
    HlmSkeleton,
    StatusTimelineComponent,
    TerminalCheckoutCardComponent,
    JobPhotosCardComponent,
    AddressMapComponent,
    GigOfferCardComponent,
    AiLiaisonPanelComponent,
    JobDetailsTableComponent,
    RateCustomerComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="mx-auto max-w-xl pb-28" data-testid="job-detail">
      @if (loading()) {
        <!-- fire-79: first-load skeleton. Before GET /api/work/gigs/:id resolves tx() is null, so the
             header + details table + action bar would flash a bare "Job {id}" / empty state on spotty
             crew connectivity. Mirrors the sibling JobsComponent first-load skeleton. -->
        <div hlmCard data-testid="job-detail-loading" class="mt-4">
          <div hlmCardContent class="space-y-3 py-5">
            <div hlmSkeleton class="h-5 w-1/2"></div>
            <div hlmSkeleton class="h-4 w-1/3"></div>
            <div hlmSkeleton class="h-28 w-full"></div>
            <div hlmSkeleton class="h-11 w-full"></div>
          </div>
        </div>
      } @else {
      <!-- Deep-linked crew with a PENDING (invited) offer: the offer card is the
           dominant top surface — countdown + Accept + Decline. Gated on
           offerPending() so a normal accepted/working job view is unchanged. The
           card presents; THIS page owns the network call (the real first-Y-wins
           /accept + /decline), reflecting its in-flight state via [busy]. -->
      @if (offerPending()) {
        <section data-testid="job-offer-banner" class="mb-4" aria-label="Pending job offer">
          <div
            class="mb-3 rounded-2xl border-l-4 border-primary bg-primary/5 px-4 py-3"
            data-testid="job-offer-headline"
          >
            <p class="text-xs font-semibold uppercase tracking-wide text-primary">
              You've got a job offer
            </p>
            <p class="mt-0.5 text-sm text-muted-foreground">
              Respond before the timer runs out — first to accept wins the job.
            </p>
          </div>
          <bcl-gig-offer-card
            [offer]="offerModel()"
            [busy]="offerPendingHttp()"
            [selfManaged]="false"
            (accepted)="acceptOffer()"
            (declined)="declineOffer()"
            (expired)="onOfferExpired()"
          />
          @if (offerError(); as e) {
            <p class="mt-2 text-center text-xs text-destructive" role="alert">{{ e }}</p>
          }
        </section>
      }

      @if (offerDeclined()) {
        <div
          class="my-10 rounded-2xl border border-border bg-card px-6 py-10 text-center"
          data-testid="job-offer-declined"
        >
          <p class="text-base font-semibold text-foreground">Offer declined</p>
          <p class="mt-1 text-sm text-muted-foreground">
            No problem — we'll offer this job to the next available crew. You can head back to your
            jobs list.
          </p>
        </div>
      } @else {
      <header class="mb-3 flex items-start justify-between gap-3">
        <div class="min-w-0">
          <h1 class="text-xl font-bold text-foreground">Job {{ gigId() }}</h1>
          <p class="truncate text-sm text-muted-foreground">{{ windowLabel() }}</p>
        </div>
        <span hlmBadge [variant]="statusVariant()">{{ statusLabel() }}</span>
      </header>

      <bcl-status-timeline [current]="step()" [transitions]="timelineTransitions()" />

      @if (loadError()) {
        <div
          class="my-4 flex items-center justify-between gap-3 rounded-xl border border-destructive/40 bg-destructive/5 px-4 py-3"
          role="alert"
        >
          <p class="text-sm text-foreground">Couldn't load this job — {{ loadError() }}</p>
          <button
            type="button"
            (click)="reload()"
            class="rounded-md border border-border px-3 py-1 text-xs text-muted-foreground hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
          >
            Try again
          </button>
        </div>
      }

      @if (address(); as addr) {
        <div class="mt-4">
          <app-address-map [address]="addr" height="12rem" />
        </div>
      }

      <div hlmCard class="mt-4">
        <div hlmCardHeader><h3 hlmCardTitle>Details</h3></div>
        <div hlmCardContent>
          <app-job-details-table [rows]="detailRows()" />
        </div>
      </div>

      <!-- Day-of contact card (idea #7 + #8: masked call/text + operator hotline) -->
      <div hlmCard class="mt-4" data-testid="day-of-contacts">
        <div hlmCardHeader><h3 hlmCardTitle>Day-of contacts</h3></div>
        <div hlmCardContent class="flex flex-wrap gap-2">
          @if (maskedCustomerTel(); as tel) {
            <a
              [href]="'tel:' + tel"
              data-testid="call-customer"
              class="inline-flex min-h-[44px] items-center gap-2 rounded-lg border border-border px-4 text-sm font-medium text-foreground hover:bg-accent/50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
              >📞 Call customer</a
            >
            <a
              [href]="'sms:' + tel"
              class="inline-flex min-h-[44px] items-center gap-2 rounded-lg border border-border px-4 text-sm font-medium text-foreground hover:bg-accent/50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
              >💬 Text customer</a
            >
          } @else {
            <p class="text-xs text-muted-foreground">
              Customer contact unlocks on the job day (a masked line — your number stays private).
            </p>
          }
          @if (operatorTel(); as op) {
            <a
              [href]="'tel:' + op"
              class="inline-flex min-h-[44px] items-center gap-2 rounded-lg border border-border px-4 text-sm font-medium text-foreground hover:bg-accent/50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
              >🎧 Dispatch</a
            >
          }
        </div>
      </div>

      <!-- AI-mediated customer messaging (idea #4) -->
      <div class="mt-4">
        <app-ai-liaison [gigId]="gigId()" [etaMinutes]="lateEta()" />
      </div>

      <!-- GPS check-in gate + before/after photos (ideas #6 + #9) -->
      <div hlmCard class="mt-4">
        <div hlmCardHeader>
          <h3 hlmCardTitle>Arrival &amp; proof</h3>
          <p hlmCardDescription>{{ photoHint() }}</p>
        </div>
        <div hlmCardContent>
          @if (!checkedIn()) {
            <button
              hlmBtn
              type="button"
              (click)="checkIn()"
              [disabled]="checkinPending()"
              data-testid="check-in"
              class="w-full"
            >
              <span class="min-w-[9ch] text-center">{{
                checkinPending() ? 'Checking in…' : "I'm here — check in"
              }}</span>
            </button>
            @if (checkinMsg(); as m) {
              <p class="mt-2 text-xs text-muted-foreground" role="status">{{ m }}</p>
            }
            @if (checkinError(); as e) {
              <p
                class="mt-2 text-xs font-medium text-destructive"
                role="alert"
                data-testid="check-in-error"
              >
                {{ e }}
              </p>
            }
          } @else {
            <p class="text-sm text-foreground">
              ✓ Checked in{{ startedAt() ? ' · work started' : '' }}.
            </p>
          }

          <div class="mt-4">
            <bcl-job-photos-card [gigId]="gigId()" (progress)="onPhotoProgress()" />
          </div>
          <p data-testid="photo-verification" class="mt-2 text-xs text-muted-foreground">
            {{ photoStatus().beforeCount }}/{{ photoStatus().beforeRequired }} before ·
            {{ photoStatus().afterCount }}/{{ photoStatus().afterRequired }} after —
            {{ photoGateHint() }}
          </p>
          @if (startBlockMsg(); as m) {
            <p
              class="mt-2 rounded-lg bg-destructive/10 px-3 py-2 text-xs text-destructive"
              role="alert"
              data-testid="start-blocked"
            >
              {{ m }}
            </p>
          }
          @if (completeBlockMsg(); as m) {
            <p
              class="mt-2 rounded-lg bg-destructive/10 px-3 py-2 text-xs text-destructive"
              role="alert"
              data-testid="complete-blocked"
            >
              {{ m }}
            </p>
          }
        </div>
      </div>

      <!-- Running-late + scope-change (idea #11) -->
      <div hlmCard class="mt-4">
        <div hlmCardHeader><h3 hlmCardTitle>Update the customer</h3></div>
        <div hlmCardContent>
          <p class="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
            Running late
          </p>
          @if (minutesBehind(); as behind) {
            <div
              class="mb-3 flex flex-wrap items-center justify-between gap-2 rounded-lg border border-bcl-accent/40 bg-bcl-accent/10 px-3 py-2"
              data-testid="late-suggest"
            >
              <span class="text-sm font-semibold text-bcl-accent">
                ⏰ You're ~{{ behind }} min past start
              </span>
              <button
                hlmBtn
                type="button"
                (click)="runningLate(suggestedLateMin())"
                [disabled]="latePending()"
                data-testid="late-suggest-notify"
                class="min-h-[40px]"
              >
                Notify customer · +{{ suggestedLateMin() }} min
              </button>
            </div>
          }
          <div class="mb-4 flex flex-wrap gap-2">
            @for (m of [15, 30, 60]; track m) {
              <button
                hlmBtn
                variant="outline"
                type="button"
                (click)="runningLate(m)"
                [disabled]="latePending()"
                [attr.data-testid]="'late-' + m"
                class="min-h-[44px]"
              >
                +{{ m }} min
              </button>
            }
          </div>
          <p class="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
            Scope changed
          </p>
          <div class="flex flex-wrap gap-2">
            @for (s of scopeOptions; track s.reason) {
              <button
                hlmBtn
                variant="outline"
                type="button"
                (click)="scopeChange(s.reason)"
                [disabled]="scopePending()"
                class="min-h-[44px]"
              >
                {{ s.label }}
              </button>
            }
          </div>
          @if (updateMsg(); as m) {
            <p class="mt-3 text-xs text-primary" role="status" data-testid="update-ack">{{ m }}</p>
          }
          @if (updateErr(); as e) {
            <p class="mt-3 text-xs text-destructive" role="alert" data-testid="update-err">{{ e }}</p>
          }
        </div>
      </div>

      <!-- On-site collect / pay summary (idea #12) -->
      <div hlmCard class="mt-4" data-testid="pay-summary">
        <div hlmCardHeader><h3 hlmCardTitle>Payment</h3></div>
        <div hlmCardContent>
          <p class="text-sm text-foreground">
            Your estimated pay for this job:
            <span class="font-mono font-semibold text-primary">{{ payLabel() }}</span>
          </p>
          @if (tx()?.isShiftLead) {
            <p
              class="mt-2 inline-flex items-center gap-1.5 rounded-full border border-bcl-accent/40 bg-bcl-accent/10 px-3 py-1 text-xs font-semibold text-bcl-accent"
              data-testid="shift-lead-chip"
              role="status"
            >
              <span aria-hidden="true">👤</span> You're the crew lead@if (shiftLeadBonusLabel(); as bonus) {&nbsp;· +{{ bonus }} lead bonus}
            </p>
          }
          @if (canCollect()) {
            <div class="mt-4">
              <bcl-terminal-checkout-card
                [bookingId]="tx()?.bookingId ?? gigId()"
                [defaultAmountCents]="tx()?.pay?.estimatedTotalCents ?? 0"
              />
            </div>
          } @else {
            <p class="mt-1 text-xs text-muted-foreground">
              Collection unlocks once you've checked in on site.
            </p>
          }
        </div>
      </div>

      <!-- SCAN-13 — crew rates the customer once the job is complete. Wires the
           LIVE POST /api/work/reviews/:gigId (the customer-to-crew direction has
           long shipped; this closes the crew-to-customer half). Hidden until the
           gig is completed AND this crew has not already rated (server ratedCustomer). -->
      @if (showRateCustomer()) {
        <div class="mt-4" data-testid="rate-customer-slot">
          <app-rate-customer [gigId]="gigId()" (rated)="onCustomerRated()" />
        </div>
      }
      }
      }
    </div>

    <!-- Sticky safe-area one-tap action bar (idea #3) — the dominant button is the
         current lifecycle step's action. Suppressed while an offer is pending or
         just declined: a crew that hasn't accepted has no Start/Complete action. -->
    @if (!offerPending() && !offerDeclined() && !loading()) {
    <nav
      data-testid="job-action-bar"
      aria-label="Job actions"
      class="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 backdrop-blur"
      style="padding-bottom: max(0.5rem, env(safe-area-inset-bottom));"
    >
      <div class="mx-auto flex max-w-xl items-center gap-2 px-3 py-2">
        <a
          [href]="directionsAvailable() ? directionsUrl() : null"
          [attr.aria-disabled]="directionsAvailable() ? null : 'true'"
          [attr.tabindex]="directionsAvailable() ? null : -1"
          [class.pointer-events-none]="!directionsAvailable()"
          [class.opacity-50]="!directionsAvailable()"
          target="_blank"
          rel="noopener"
          data-testid="directions"
          aria-label="Open directions"
          class="flex min-h-[48px] flex-1 flex-col items-center justify-center rounded-lg bg-accent/40 text-[11px] font-medium text-foreground hover:bg-accent/60 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        >
          <span aria-hidden="true" class="text-base">🧭</span>
          Directions
        </a>
        @if (maskedCustomerTel(); as tel) {
          <a
            [href]="'tel:' + tel"
            aria-label="Call customer"
            class="flex min-h-[48px] flex-1 flex-col items-center justify-center rounded-lg bg-accent/40 text-[11px] font-medium text-foreground hover:bg-accent/60 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
          >
            <span aria-hidden="true" class="text-base">📞</span>
            Call
          </a>
        }
        <!-- Context-aware primary action: check-in before arrival → Start → Complete. -->
        @if (!checkedIn()) {
          <button
            hlmBtn
            type="button"
            (click)="checkIn()"
            [disabled]="checkinPending()"
            data-testid="action-primary"
            class="min-h-[48px] flex-[1.4]"
          >
            <span class="min-w-[8ch] text-center">Check in</span>
          </button>
        } @else if (!startedAt()) {
          <button
            hlmBtn
            type="button"
            (click)="startJob()"
            [disabled]="!canStart() || startPending()"
            data-testid="job-start"
            aria-label="Start work"
            class="min-h-[48px] flex-[1.4]"
          >
            <span class="min-w-[8ch] text-center">{{
              startPending() ? 'Starting…' : 'Start'
            }}</span>
          </button>
        } @else {
          <button
            hlmBtn
            type="button"
            (click)="completeJob()"
            [disabled]="!canComplete() || completePending()"
            data-testid="job-complete"
            aria-label="Complete job"
            class="min-h-[48px] flex-[1.4] bg-emerald-500 text-white hover:bg-emerald-500/90"
          >
            <span class="min-w-[8ch] text-center">{{
              completePending() ? 'Ending…' : 'End'
            }}</span>
          </button>
        }
      </div>
    </nav>
    }
  `,
})
export class JobDetailComponent {
  private readonly route = inject(ActivatedRoute);
  private readonly http = inject(HttpClient);
  private readonly geo = inject(GeolocationService);
  private readonly destroyRef = inject(DestroyRef);

  readonly gigId = signal<string>('');
  readonly tx = signal<GigTransparency | null>(null);
  /** fire-79: first-load gate — true until the initial gig fetch resolves (or errors). Starts true so
   *  the skeleton shows on boot; never re-set true on poll re-fetches (mirrors JobsComponent). */
  readonly loading = signal<boolean>(true);
  readonly loadError = signal<string | null>(null);
  readonly photoStatus = signal<PhotoStatus>({
    beforeCount: 0,
    afterCount: 0,
    canComplete: false,
    beforeRequired: 1,
    afterRequired: 1,
    beforeRemaining: 1,
    afterRemaining: 1,
    canStartPhotos: true,
    gatesEnforced: false,
  });
  readonly startedAt = signal<string | null>(null);
  readonly lateEta = signal<number | undefined>(undefined);
  /**
   * SCAN-64: timestamped ride transitions from GET /api/ride/:id/timeline
   * (flag `crew_job_timeline`). Empty when the flag is dark (endpoint 404s) or the
   * ride has no state row yet — the stepper then renders with no per-step time.
   */
  readonly timelineTransitions = signal<readonly RideStatusTransition[]>([]);
  /** GP-05: server-surfaced block on the Start action (e.g. "You must be at the job
   * site to start" 412) — cleared on a successful start or re-check-in. */
  readonly startBlockMsg = signal<string | null>(null);
  /** GP-05: server-surfaced block on the Complete action (e.g. "Add N more after-photos"). */
  readonly completeBlockMsg = signal<string | null>(null);

  readonly checkinPending = signal(false);
  readonly startPending = signal(false);
  readonly completePending = signal(false);
  readonly latePending = signal(false);
  readonly scopePending = signal(false);
  readonly checkinMsg = signal<string | null>(null);
  /** A FAILED check-in (vs the neutral out-of-range prompt in checkinMsg) — rendered as an
   * assertive role="alert" error so a crew member can't miss it on the arrival gate (a missed
   * failure → they think they're checked in, then the GPS gate blocks Start). */
  readonly checkinError = signal<string | null>(null);
  readonly updateMsg = signal<string | null>(null);
  /** fire-150 — assertive (role=alert) counterpart to updateMsg: FAILED notifies route here so a
   * failed "running late"/scope-change is never shown in success-green. */
  readonly updateErr = signal<string | null>(null);

  // ── Crew offer (invited claim) ────────────────────────────────────────────
  /** Set once, when the first `invited` claim is observed — anchors the 30s ring. */
  readonly offerExpiresAt = signal<number | null>(null);
  /** In-flight flag for the real accept/decline POST (drives the card's [busy]). */
  readonly offerPendingHttp = signal(false);
  /** True after a successful decline — swaps the body for the declined empty state. */
  readonly offerDeclined = signal(false);
  /** True once the countdown drains — accept/decline are locked. */
  readonly offerExpiredState = signal(false);
  readonly offerError = signal<string | null>(null);

  /**
   * A pending offer = the crew has an `invited` claim on this gig AND hasn't
   * declined it. The whole offer-card block is gated on this, so a normal
   * accepted/working/completed job view is completely unchanged.
   */
  readonly offerPending = computed(
    () => this.tx()?.claimStatus === 'invited' && !this.offerDeclined(),
  );

  /**
   * The `GigOffer` the shared card renders, built from the transparency envelope.
   * The envelope carries no `expiresAt`, so we anchor a 30s window to first
   * observation (`offerExpiresAt`). Null until both the gig + the anchor exist.
   */
  readonly offerModel = computed<GigOffer | null>(() => {
    const t = this.tx();
    const exp = this.offerExpiresAt();
    if (!t || t.claimStatus !== 'invited' || exp == null) return null;
    const svc: string[] = [];
    if (t.needsDriver) svc.push('Driving');
    if (t.needsHauling) svc.push('Hauling');
    const serviceLabel = svc.length ? `${svc.join(' · ')} crew` : 'Labor crew';
    return {
      gigId: t.gigId,
      bookingId: t.gigId,
      serviceLabel,
      pickup: t.location.cityLevel || 'Newark, NJ',
      dropoff: null,
      etaMinutes: Math.max(0, Math.round(t.pay.hoursEstimated * 60)),
      payoutCents: t.pay.estimatedTotalCents,
      expiresAt: exp,
    };
  });

  readonly scopeOptions = [
    { reason: 'Job is bigger than booked — add an hour', label: 'Add an hour' },
    { reason: 'Needs an extra crew member', label: 'Add crew' },
    { reason: 'Extra hauling / disposal load', label: 'Add hauling' },
  ] as const;

  // A gig has an address once the crew has accepted (the worker only returns the
  // street address post-accept); before that we show the city-level location.
  readonly address = computed(() => this.tx()?.location.streetAddress ?? null);
  readonly checkedIn = computed(() => {
    const s = this.tx()?.claimStatus;
    return s === 'checked_in' || s === 'completed';
  });
  readonly canCollect = computed(() => this.checkedIn());
  // Start unlocks once checked in AND the before-photo precondition is met.
  // `canStartPhotos` is server-authoritative: it is true when the flag is OFF (no
  // photo gate on Start) and requires >= beforeRequired (4) when the flag is ON.
  readonly canStart = computed(() => this.checkedIn() && this.photoStatus().canStartPhotos);
  readonly canComplete = computed(() => this.photoStatus().canComplete);
  readonly step = computed<RideStatusStep>(() => {
    const s = this.tx()?.claimStatus;
    if (!s) return 'matched';
    if (s === 'checked_in' && this.startedAt()) return 'working';
    return claimToStep(s);
  });

  readonly statusLabel = computed(() => {
    if (this.tx()?.claimStatus === 'completed') return 'Complete';
    if (this.startedAt()) return 'Working';
    if (this.checkedIn()) return 'On site';
    return 'Upcoming';
  });
  readonly statusVariant = computed<'default' | 'success' | 'warning'>(() =>
    this.tx()?.claimStatus === 'completed' ? 'success' : this.checkedIn() ? 'default' : 'warning',
  );

  /**
   * SCAN-13 — show the crew's "Rate this customer" card ONLY on a completed gig
   * the crew hasn't yet rated. `ratedCustomer` is server-authoritative (from GET
   * /api/work/gigs/:id), so after a submit + reload the card self-hides. The card
   * also manages its own optimistic "done" state, so it never double-submits.
   */
  readonly showRateCustomer = computed(
    () => this.tx()?.claimStatus === 'completed' && this.tx()?.ratedCustomer !== true,
  );

  /** After the crew rates the customer, reload so `ratedCustomer` flips + the card retires. */
  onCustomerRated(): void {
    this.reload();
  }

  readonly windowLabel = computed(() => {
    const at = this.tx()?.startAt;
    if (!at) return 'Loading…';
    const d = new Date(at);
    return Number.isNaN(d.getTime())
      ? at
      : d.toLocaleString(undefined, {
          weekday: 'short',
          month: 'short',
          day: 'numeric',
          hour: 'numeric',
          minute: '2-digit',
        });
  });

  /** fire-141 — minutes past the scheduled start when the crew HASN'T started yet (≥5), so the
   * "Running late" card auto-surfaces a one-tap notify instead of making the crew eyeball the
   * clock + pick a preset. Mirrors maskedCustomerTel's Date.now()-in-computed pattern; recomputes
   * on load/reload (a notify PROMPT, not a live ticker). null → no prompt (on time / already started). */
  readonly minutesBehind = computed<number | null>(() => {
    const at = this.tx()?.startAt;
    if (!at || this.startedAt()) return null;
    const startMs = new Date(at).getTime();
    if (Number.isNaN(startMs)) return null;
    const mins = Math.floor((Date.now() - startMs) / 60_000);
    return mins >= 5 ? mins : null;
  });
  /** The nearest running-late preset (15/30/60) at or above how far behind we are. */
  readonly suggestedLateMin = computed<number>(() => {
    const behind = this.minutesBehind() ?? 0;
    return behind <= 15 ? 15 : behind <= 30 ? 30 : 60;
  });

  readonly payLabel = computed(() => {
    const t = this.tx();
    if (!t) return '—';
    return `${money(t.pay.estimatedTotalCents)} (${money(t.pay.centsPerHour)}/hr)`;
  });

  /** fire-147 — formatted shift-lead bonus for the "you're the crew lead" chip (null when none). */
  readonly shiftLeadBonusLabel = computed<string | null>(() => {
    const c = this.tx()?.pay?.shiftLeadBonusCents;
    return c && c > 0 ? money(c) : null;
  });

  // Masked contact: unlocked day-of only. The worker returns no raw number by
  // design; the operator hotline is a build var surfaced via the transparency
  // payload is not present, so we use the app-level operator alert line when set.
  readonly maskedCustomerTel = computed<string | null>(() => {
    // Only surface a dial affordance on the job day (claim accepted + within 24h).
    const t = this.tx();
    if (!t) return null;
    const start = new Date(t.startAt).getTime();
    const dayOf = Number.isFinite(start) && start - Date.now() < 24 * 60 * 60 * 1000;
    // The customer proxy line rides on the same masked number pattern; until the
    // worker exposes it we return null (privacy-safe) — the card copy explains.
    return dayOf ? null : null;
  });
  readonly operatorTel = signal<string | null>(null);

  readonly directionsUrl = computed(() => {
    const addr = this.address() ?? this.tx()?.location.cityLevel ?? '';
    const q = encodeURIComponent(addr);
    // Universal Google Maps directions URL — opens the native app on mobile,
    // resolves to Apple Maps on iOS when set as default handler.
    return q ? `https://www.google.com/maps/dir/?api=1&destination=${q}` : '#';
  });

  /** fire-151 — true only when a real destination exists; gates the Directions button so it's
   * never a dead-tap (href='#' opens a blank tab) before the job's address/city is known. */
  readonly directionsAvailable = computed(() => this.directionsUrl() !== '#');

  readonly detailRows = computed<readonly JobDetailRow[]>(() => {
    const t = this.tx();
    if (!t) return [];
    const services: string[] = [];
    if (t.needsDriver) services.push('Driving');
    if (t.needsHauling) services.push('Hauling');
    const rows: JobDetailRow[] = [
      { label: 'Service', value: services.length ? services.join(' · ') : 'Labor crew' },
      { label: 'Scope', value: t.scopeSummary ?? t.customerNotes ?? '—' },
      { label: 'Crew', value: `${t.crewFilled} of ${t.crewNeeded} filled` },
      {
        label: 'Est. hours',
        value: `${t.pay.hoursEstimated}h (1-hr minimum)`,
      },
      { label: 'Your pay', value: this.payLabel(), emphasize: true },
      { label: 'Window', value: this.windowLabel() },
      {
        label: 'Address',
        value: t.location.streetAddress ?? `${t.location.cityLevel} (unlocks on accept)`,
      },
    ];
    if (t.customer.priorJobCount > 0 || t.customer.ratingAvg != null) {
      const rating = t.customer.ratingAvg != null ? `${t.customer.ratingAvg.toFixed(1)}★ · ` : '';
      rows.push({
        label: 'Customer',
        value: `${rating}${t.customer.priorJobCount} prior job${t.customer.priorJobCount === 1 ? '' : 's'}`,
      });
    }
    // SCAN-42 — when the customer bound inventory insurance on this booking (and the
    // crew_job_coverage flag is on), tell the crew the goods are insured so they can
    // handle with extra care. Whole-dollar from the server cents (never recomputed
    // as a money charge — this is an informational coverage limit). Omitted when
    // there's no active coverage or the flag is dark.
    if (t.coverage && t.coverage.coverageCents > 0) {
      const limit = (t.coverage.coverageCents / 100).toLocaleString('en-US', {
        style: 'currency',
        currency: 'USD',
        maximumFractionDigits: 0,
      });
      rows.push({ label: 'Coverage', value: `Insured up to ${limit} · ${t.coverage.tier}` });
    }
    return rows;
  });

  readonly photoHint = computed(() => {
    const p = this.photoStatus();
    const b = p.beforeRequired;
    const a = p.afterRequired;
    return this.checkedIn()
      ? `Add ${b} before photo${b === 1 ? '' : 's'} to start, ${a} after photo${a === 1 ? '' : 's'} to finish.`
      : 'Check in on site, then capture before/after photos.';
  });
  // Mirrors the worker gate exactly — "Add N more before/after-photos" or the
  // all-clear. Under the flag the thresholds are 4/4; off, they are 1/1.
  readonly photoGateHint = computed(() => {
    const p = this.photoStatus();
    if (p.beforeRemaining > 0)
      return `add ${p.beforeRemaining} more before-photo${p.beforeRemaining === 1 ? '' : 's'} to start`;
    if (p.afterRemaining > 0)
      return `add ${p.afterRemaining} more after-photo${p.afterRemaining === 1 ? '' : 's'} to finish`;
    return 'ready to complete';
  });

  constructor() {
    this.route.paramMap.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((params) => {
      const id = params.get('id') ?? '';
      this.gigId.set(id);
      if (id) {
        this.loadGig(id);
        this.loadPhotos(id);
        this.loadTimeline(id);
      }
    });
  }

  reload(): void {
    const id = this.gigId();
    if (id) {
      this.loadGig(id);
      this.loadPhotos(id);
      this.loadTimeline(id);
    }
  }

  /**
   * Accept the pending offer via the REAL first-Y-wins endpoint the deep-linked
   * crew hits. On success re-fetch the gig — `claimStatus` flips to `accepted`,
   * `offerPending()` goes false, the card unmounts, and the normal accepted job
   * detail (address, action bar, photos) renders. A `crew_full` 409 (someone
   * else won) surfaces as an inline message + also clears the offer on re-fetch.
   */
  acceptOffer(): void {
    if (this.offerPendingHttp() || this.offerExpiredState()) return;
    this.offerPendingHttp.set(true);
    this.offerError.set(null);
    this.http
      .post<{ ok: boolean; status?: string }>(
        `/api/work/gigs/${encodeURIComponent(this.gigId())}/accept`,
        {},
        { withCredentials: true },
      )
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: () => {
          this.offerPendingHttp.set(false);
          // Re-fetch: the transparency claimStatus is now the source of truth
          // (accepted → offer surface clears + accepted view renders).
          this.reload();
        },
        error: (e: { status?: number; error?: { code?: string } }) => {
          this.offerPendingHttp.set(false);
          if (e.status === 409) {
            this.offerError.set('This job just filled — offering it to the next crew.');
            this.reload();
          } else {
            this.offerError.set("Couldn't accept — try again.");
          }
        },
      });
  }

  /**
   * Decline the pending offer. On success swap to the declined empty state (the
   * body + sticky action bar suppress) so the crew isn't left on a dead job view.
   */
  declineOffer(): void {
    if (this.offerPendingHttp() || this.offerExpiredState()) return;
    this.offerPendingHttp.set(true);
    this.offerError.set(null);
    this.http
      .post<{ ok: boolean }>(
        `/api/work/gigs/${encodeURIComponent(this.gigId())}/decline`,
        {},
        { withCredentials: true },
      )
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: () => {
          this.offerPendingHttp.set(false);
          this.offerDeclined.set(true);
        },
        error: () => {
          this.offerPendingHttp.set(false);
          this.offerError.set("Couldn't decline — try again.");
        },
      });
  }

  /** Countdown drained (card emitted (expired)) — lock the decision. */
  onOfferExpired(): void {
    this.offerExpiredState.set(true);
  }

  private loadGig(id: string): void {
    this.http
      .get<{ transparency?: GigTransparency }>(`/api/work/gigs/${encodeURIComponent(id)}`, {
        withCredentials: true,
      })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (res) => {
          this.loading.set(false);
          if (res.transparency) {
            this.tx.set(res.transparency);
            this.loadError.set(null);
            if (res.transparency.claimStatus === 'invited') {
              // Anchor the countdown to first observation; keep it stable across
              // re-fetches so the ring doesn't reset on a poll.
              if (this.offerExpiresAt() == null) {
                this.offerExpiresAt.set(Date.now() + OFFER_TIMEOUT_S * 1000);
              }
            } else {
              // Claim moved past `invited` (accepted elsewhere / by us) — the
              // offer surface clears and the normal job view takes over.
              this.offerExpiresAt.set(null);
              this.offerExpiredState.set(false);
            }
          } else {
            this.loadError.set('not available');
          }
        },
        error: (e: { status?: number }) => {
          this.loading.set(false);
          this.loadError.set(e.status === 404 ? 'no invite on this job' : 'network error');
        },
      });
  }

  private loadPhotos(id: string): void {
    this.http
      .get<Partial<PhotoStatus>>(`/api/work/gigs/${encodeURIComponent(id)}/photos`, {
        withCredentials: true,
      })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (res) => {
          const beforeCount = res.beforeCount ?? 0;
          const afterCount = res.afterCount ?? 0;
          // Fields below are GP-05 additions; when the worker predates them (or the
          // flag is off it still sends them) they default to the legacy 1/1 gate.
          const beforeRequired = res.beforeRequired ?? 1;
          const afterRequired = res.afterRequired ?? 1;
          this.photoStatus.set({
            beforeCount,
            afterCount,
            canComplete: Boolean(res.canComplete),
            beforeRequired,
            afterRequired,
            beforeRemaining: res.beforeRemaining ?? Math.max(0, beforeRequired - beforeCount),
            afterRemaining: res.afterRemaining ?? Math.max(0, afterRequired - afterCount),
            canStartPhotos: res.canStartPhotos ?? true,
            gatesEnforced: Boolean(res.gatesEnforced),
          });
        },
        error: () => undefined,
      });
  }

  /**
   * SCAN-64: fetch the timestamped ride transitions (flag `crew_job_timeline`).
   * The endpoint 404s while the flag is dark, so a miss (any error) leaves the
   * transitions empty and the stepper renders exactly as before — no per-step
   * time. `:id` is the gig id; the worker resolves the ride via the gig's booking.
   */
  private loadTimeline(id: string): void {
    this.http
      .get<{
        ok: boolean;
        state: RideStatusStep | 'cancelled';
        transitions: RideStatusTransition[];
      }>(`/api/ride/${encodeURIComponent(id)}/timeline`, { withCredentials: true })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (res) => this.timelineTransitions.set(res?.transitions ?? []),
        // Dark flag (404) / not-a-party (403) / no ride row — no timeline, no error UI.
        error: () => this.timelineTransitions.set([]),
      });
  }

  /**
   * A before/after photo was just uploaded from the card — re-fetch the full gate
   * payload so the Start/Complete buttons + "Add N more …" copy reflect the new
   * counts immediately (the card's own `canComplete` omits the GP-05 gate fields).
   */
  onPhotoProgress(): void {
    const id = this.gigId();
    if (id) this.loadPhotos(id);
    // A fresh photo may satisfy the Start gate the crew was blocked on — clear the stale block.
    this.startBlockMsg.set(null);
    this.completeBlockMsg.set(null);
  }

  /** GPS check-in gate (idea #6) — grabs one position, posts to /check-in. */
  checkIn(): void {
    if (this.checkinPending()) return;
    this.checkinPending.set(true);
    this.checkinMsg.set(null);
    this.checkinError.set(null);
    const post = (lat?: number, lng?: number, confirmed = false): void => {
      this.http
        .post<{ ok: boolean; requiresConfirmation?: boolean; distanceMeters?: number }>(
          `/api/work/gigs/${encodeURIComponent(this.gigId())}/check-in`,
          { lat, lng, confirmed },
          { withCredentials: true },
        )
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe({
          next: (res) => {
            this.checkinPending.set(false);
            if (res.requiresConfirmation) {
              this.checkinMsg.set(
                `You're ~${res.distanceMeters ?? '?'}m from the job. Tap again to confirm you're on site.`,
              );
              // A second tap confirms the out-of-range override.
              this.pendingConfirm = true;
              return;
            }
            this.pendingConfirm = false;
            this.reload();
          },
          error: () => {
            this.checkinPending.set(false);
            // A FAILED check-in is an assertive error (not the neutral checkinMsg status) so the
            // crew notices it on the arrival gate — offline-aware when the device has no signal.
            this.checkinError.set(
              typeof navigator !== 'undefined' && navigator.onLine === false
                ? 'You’re offline — reconnect, then check in again.'
                : 'Check-in failed — try again.',
            );
          },
        });
    };
    const confirmed = this.pendingConfirm;
    // Best-effort single GPS read; the worker still gates on the geofence.
    if (typeof navigator !== 'undefined' && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (p) => post(p.coords.latitude, p.coords.longitude, confirmed),
        () => post(undefined, undefined, confirmed),
        { enableHighAccuracy: true, timeout: 8000, maximumAge: 30_000 },
      );
    } else {
      post(undefined, undefined, confirmed);
    }
  }
  private pendingConfirm = false;

  /**
   * Start work (idea #6 + GP-05). Requires check-in and — under the day-of gates
   * flag — the crew on-site AND >= 4 before-photos. The server re-gates and returns
   * a typed 412 (`not_at_job_site` / `before_photos_required`) whose `message` we
   * surface verbatim so the crew knows exactly what to do next. The button is
   * already disabled until `canStart()`, so a 412 here is the belt-and-suspenders
   * server truth (e.g. the crew drifted off-site since the last photos load).
   */
  startJob(): void {
    if (this.startPending()) return;
    this.startPending.set(true);
    this.startBlockMsg.set(null);
    this.http
      .post<{ ok: boolean }>(
        `/api/work/gigs/${encodeURIComponent(this.gigId())}/start`,
        {},
        { withCredentials: true },
      )
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: () => {
          this.startPending.set(false);
          this.startedAt.set(new Date().toISOString());
        },
        error: (e: { status?: number; error?: { code?: string; message?: string } }) => {
          this.startPending.set(false);
          const code = e.error?.code;
          if (e.status === 412 && (code === 'not_at_job_site' || code === 'before_photos_required')) {
            this.startBlockMsg.set(
              e.error?.message ??
                (code === 'not_at_job_site'
                  ? 'You must be at the job site to start.'
                  : 'Add more before-photos to start.'),
            );
            // Refresh the mirrored counts so the card reflects the server truth.
            this.loadPhotos(this.gigId());
          } else {
            this.startBlockMsg.set('Could not start — try again.');
          }
        },
      });
  }

  /**
   * Complete (idea #9 gate + GP-05). The server enforces the after-photo floor
   * (>=1 baseline, >=4 under the day-of gates flag) and returns a typed 412
   * (`after_photos_required` / `photos_required`) whose message we surface.
   */
  completeJob(): void {
    if (this.completePending()) return;
    this.completePending.set(true);
    this.completeBlockMsg.set(null);
    this.http
      .post<{ ok: boolean }>(
        `/api/work/gigs/${encodeURIComponent(this.gigId())}/complete`,
        {},
        { withCredentials: true },
      )
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: () => {
          this.completePending.set(false);
          this.reload();
        },
        error: (e: { status?: number; error?: { code?: string; message?: string } }) => {
          this.completePending.set(false);
          const code = e.error?.code;
          if (e.status === 412 && (code === 'after_photos_required' || code === 'photos_required')) {
            this.completeBlockMsg.set(e.error?.message ?? 'Add more after-photos to finish.');
            this.loadPhotos(this.gigId());
          } else {
            this.completeBlockMsg.set('Could not complete — try again.');
          }
        },
      });
  }

  /** Running-late quick action (idea #11) — auto-notifies the customer. */
  runningLate(minutes: number): void {
    if (this.latePending()) return;
    this.latePending.set(true);
    this.lateEta.set(minutes);
    this.http
      .post<{ ok: boolean }>(
        `/api/work/gigs/${encodeURIComponent(this.gigId())}/running-late`,
        { reason: `Running about ${minutes} minutes behind`, etaMinutes: minutes },
        { withCredentials: true },
      )
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: () => {
          this.latePending.set(false);
          this.updateErr.set(null);
          this.updateMsg.set(`Customer notified — +${minutes} min.`);
        },
        error: () => {
          this.latePending.set(false);
          this.updateMsg.set(null);
          this.updateErr.set('Could not notify — try again.');
        },
      });
  }

  /** Scope-change quick action (idea #11) — customer reviews + approves added scope. */
  scopeChange(reason: string): void {
    if (this.scopePending()) return;
    this.scopePending.set(true);
    this.http
      .post<{ ok: boolean }>(
        `/api/work/gigs/${encodeURIComponent(this.gigId())}/scope-change`,
        { reason },
        { withCredentials: true },
      )
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: () => {
          this.scopePending.set(false);
          this.updateErr.set(null);
          this.updateMsg.set('Scope change sent — awaiting customer approval.');
        },
        error: () => {
          this.scopePending.set(false);
          this.updateMsg.set(null);
          this.updateErr.set('Could not send scope change — try again.');
        },
      });
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'job-detail-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
