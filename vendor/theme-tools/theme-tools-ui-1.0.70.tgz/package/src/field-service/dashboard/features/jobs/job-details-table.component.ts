import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * JobDetailsTableComponent — the specially-crafted crew Job Details table
 * (Deliverable B, idea #2). A scannable two-column (label · value) table of
 * everything the crew needs before + on arrival: service, scope, crew, hours +
 * 1-hr min, pay ($50/hr · your split), window + arrival, address, access notes,
 * recurring cadence. One authoritative table beats scattered fields — a busy
 * crew reads it in ~10 seconds.
 *
 * Pure presentational: takes an already-fetched `rows` input (the parent maps
 * the /api/work/gigs/:id transparency envelope into label/value pairs). Money
 * values arrive pre-formatted from the server number — never recomputed here
 * (per the money-label = earn-timing rule). Standalone + OnPush.
 */
import { ChangeDetectionStrategy, Component, input } from '@angular/core';

export interface JobDetailRow {
  readonly label: string;
  readonly value: string;
  /** When true, render the value in the brand accent + mono (money/pay rows). */
  readonly emphasize?: boolean;
}

@Component({
  selector: 'app-job-details-table',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div hidden data-testid="job-details-table"></div>
    <table
      class="w-full border-collapse overflow-hidden rounded-xl text-sm"
      aria-label="Job details"
    >
      <tbody>
        @for (row of rows(); track row.label) {
          <tr class="border-b border-border last:border-0">
            <th
              scope="row"
              class="w-2/5 py-2.5 pr-3 text-left align-top text-xs font-medium uppercase tracking-wide text-muted-foreground"
            >
              {{ row.label }}
            </th>
            <td
              class="py-2.5 align-top text-foreground"
              [class.font-mono]="row.emphasize"
              [class.tabular-nums]="row.emphasize"
              [class.text-primary]="row.emphasize"
              [class.font-semibold]="row.emphasize"
            >
              {{ row.value }}
            </td>
          </tr>
        }
      </tbody>
    </table>
  `,
})
export class JobDetailsTableComponent {
  readonly rows = input.required<readonly JobDetailRow[]>();
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'job-details-table-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
