import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * JobHistoryComponent — the crew Job History portal subpage (SCAN-01), the
 * searchable, month-grouped record of EVERY completed + cancelled job a crew
 * member worked. Route: /jobs/history (flag `crew_job_history`, guarded by
 * featureFlagCanMatch — off => the route declines the match and this never
 * mounts). The existing flat /jobs list only shows the 20 most recent completed
 * gigs with no search + no cancelled; this is the durable IA layer 1099
 * contractors need for disputes/taxes/prior-address lookups.
 *
 * Data: GET /api/work/gigs/history (worker-session gated + flag-gated server-side).
 *   → { ok, months:[{monthLabel,monthKey,earnedCents,entries[]}], summary, hasMore }
 * A `q` query param filters by address substring (debounced, server-side).
 *
 * RxJS-first: a search-term subject (debounced) + a reload trigger →
 * switchMap(HttpClient GET) → signal, per [[rxjs-first-angular]]. 4-state via
 * StateBlockComponent (loading skeleton / empty launchpad / error+retry / ready).
 * The dashboard build CANNOT import src/shared, so the row/month shapes are local
 * interfaces mirroring the server's Zod contract (src/shared/job-history.ts) and
 * `formatUsd` mirrors its pure `historyUsd`; the server is the source of truth,
 * the client only renders what it returns.
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  inject,
  signal,
} from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { takeUntilDestroyed, toObservable } from '@angular/core/rxjs-interop';
import { RouterLink } from '@angular/router';
import {
  Subject,
  merge,
  of,
  debounceTime,
  distinctUntilChanged,
  startWith,
  switchMap,
  map,
  catchError,
} from 'rxjs';
import {
  HlmCardImports,
  HlmBadge,
  HlmInput,
  StateBlockComponent,
  type SurfaceState,
} from '../../shared/ui-spartan';
import { routeFade, reducedMotion } from '../../shared/animations';

/** One terminal job — mirrors src/shared/job-history.ts JobHistoryEntry. */
interface HistoryEntry {
  readonly gigId: string;
  readonly status: 'completed' | 'cancelled';
  readonly atMs: number;
  readonly dateLabel: string;
  readonly address: string;
  readonly baseCents: number;
  readonly tipCents: number;
  readonly totalCents: number;
}

/** A month bucket — mirrors src/shared/job-history.ts JobHistoryMonth. */
interface HistoryMonth {
  readonly monthLabel: string;
  readonly monthKey: string;
  readonly entries: readonly HistoryEntry[];
  readonly earnedCents: number;
}

/** Response envelope — mirrors src/shared/job-history.ts JobHistoryResult. */
interface HistoryResult {
  readonly ok: boolean;
  readonly months: readonly HistoryMonth[];
  readonly summary: {
    readonly completedCount: number;
    readonly cancelledCount: number;
    readonly lifetimeEarnedCents: number;
  };
  readonly hasMore: boolean;
}

/** Pure: cents → "$N,NNN.NN" — mirrors src/shared/job-history.ts historyUsd. */
export function formatUsd(cents: number): string {
  return `$${((cents || 0) / 100).toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

/** Pure: short gig ref — mirrors src/shared/job-history.ts historyGigRef. */
export function formatGigRef(gigId: string): string {
  return gigId ? `#${gigId.slice(-6).toUpperCase()}` : '#------';
}

@Component({
  selector: 'app-job-history',
  standalone: true,
  imports: [...HlmCardImports, HlmBadge, HlmInput, StateBlockComponent, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <div class="mx-auto max-w-3xl" data-testid="job-history">
      <header class="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div class="min-w-0">
          <nav class="mb-1 text-xs text-muted-foreground" aria-label="Breadcrumb">
            <a
              routerLink="/jobs"
              class="rounded hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
              >Jobs</a
            >
            <span aria-hidden="true"> / </span>
            <span class="text-foreground">History</span>
          </nav>
          <h1 class="text-2xl font-bold text-foreground">Job history</h1>
          <p class="text-sm text-muted-foreground">
            Every job you've completed or that was cancelled, newest first.
          </p>
        </div>
        <div class="text-right">
          <p class="font-mono text-lg font-semibold tabular-nums text-primary">
            {{ formatMoney(summary().lifetimeEarnedCents) }}
          </p>
          <p class="text-xs text-muted-foreground">
            {{ summary().completedCount }} completed · {{ summary().cancelledCount }} cancelled
          </p>
        </div>
      </header>

      <div class="mb-4">
        <label class="sr-only" for="job-history-search">Search jobs by address</label>
        <input
          id="job-history-search"
          hlmInput
          type="search"
          inputmode="search"
          autocomplete="off"
          placeholder="Search by address…"
          data-testid="history-search"
          [value]="term()"
          (input)="onSearch($any($event.target).value)"
          class="w-full"
        />
      </div>

      <app-state-block
        [state]="state()"
        [emptyTitle]="term() ? 'No jobs match that search' : 'No job history yet'"
        [emptyHint]="
          term()
            ? 'Try a different address or clear the search.'
            : 'Once you finish your first job, it shows up here with your earnings.'
        "
        [errorDetail]="loadError() ?? ''"
        (retry)="reload()"
      >
        <div class="flex flex-col gap-6">
          @for (month of months(); track month.monthKey) {
            <section data-testid="history-month-group">
              <div class="mb-2 flex items-baseline justify-between gap-3">
                <h2 class="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                  {{ month.monthLabel }}
                </h2>
                <span class="font-mono text-sm tabular-nums text-primary">{{
                  formatMoney(month.earnedCents)
                }}</span>
              </div>
              <ul class="divide-y divide-border rounded-xl border border-border">
                @for (job of month.entries; track job.gigId) {
                  <li>
                    <a
                      [routerLink]="['/jobs', job.gigId]"
                      class="flex min-h-[44px] items-center gap-3 px-4 py-3 transition-colors hover:bg-accent/40 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                      [attr.aria-label]="
                        job.dateLabel +
                        ' — ' +
                        (job.address || 'address unavailable') +
                        ' — ' +
                        (job.status === 'completed' ? formatMoney(job.totalCents) : 'cancelled')
                      "
                    >
                      <div class="min-w-0 flex-1">
                        <p class="truncate text-sm font-medium text-foreground">
                          {{ job.address || 'Address unavailable' }}
                        </p>
                        <p class="truncate text-xs text-muted-foreground">
                          {{ job.dateLabel }} · {{ ref(job.gigId) }}
                        </p>
                      </div>
                      @if (job.status === 'completed') {
                        <span
                          class="font-mono text-sm tabular-nums text-foreground"
                          data-testid="history-job-total"
                          >{{ formatMoney(job.totalCents) }}</span
                        >
                      } @else {
                        <span hlmBadge variant="outline" data-testid="history-job-cancelled"
                          >Cancelled</span
                        >
                      }
                    </a>
                  </li>
                }
              </ul>
            </section>
          }
          @if (hasMore()) {
            <p class="text-center text-xs text-muted-foreground" data-testid="history-has-more">
              Showing your most recent jobs. Narrow the search to find older ones.
            </p>
          }
        </div>
      </app-state-block>
    </div>
  `,
})
export class JobHistoryComponent {
  protected readonly reducedMotion = reducedMotion;
  private readonly http = inject(HttpClient);
  private readonly destroyRef = inject(DestroyRef);

  protected readonly ref = formatGigRef;
  protected readonly formatMoney = formatUsd;

  /** Debounced free-text address search — drives the server-side `q` filter. */
  readonly term = signal('');
  private readonly reload$ = new Subject<void>();

  private readonly result = signal<HistoryResult | null>(null);
  readonly loading = signal(true);
  readonly loadError = signal<string | null>(null);

  readonly months = computed<readonly HistoryMonth[]>(() => this.result()?.months ?? []);
  readonly hasMore = computed(() => this.result()?.hasMore ?? false);
  readonly summary = computed(
    () =>
      this.result()?.summary ?? {
        completedCount: 0,
        cancelledCount: 0,
        lifetimeEarnedCents: 0,
      },
  );

  /** 4-state for StateBlockComponent, derived from loading/error/result. */
  readonly state = computed<SurfaceState>(() => {
    if (this.loading()) return 'loading';
    if (this.loadError()) return 'error';
    if (this.months().length === 0) return 'empty';
    return 'ready';
  });

  constructor() {
    // A debounced term change OR an explicit reload re-fetches. distinctUntilChanged
    // dedupes identical terms; switchMap cancels an in-flight request. A 401/404
    // (not signed in as crew / flag dark) degrades to honest-empty; a 5xx surfaces
    // an error with retry.
    merge(
      toObservable(this.term).pipe(debounceTime(300), distinctUntilChanged()),
      this.reload$.pipe(map(() => this.term())),
    )
      .pipe(
        startWith(this.term()),
        switchMap((q) => {
          this.loading.set(true);
          this.loadError.set(null);
          const url = q
            ? `/api/work/gigs/history?q=${encodeURIComponent(q)}`
            : '/api/work/gigs/history';
          return this.http.get<HistoryResult>(url, { withCredentials: true }).pipe(
            map((res) => ({ kind: 'ok' as const, res })),
            catchError((err: HttpErrorResponse) => {
              // Dark flag (404) or unauthenticated (401) → honest empty, not an error.
              if (err.status === 404 || err.status === 401 || err.status === 0) {
                return of({ kind: 'empty' as const });
              }
              return of({ kind: 'error' as const, status: err.status });
            }),
          );
        }),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe((outcome) => {
        this.loading.set(false);
        if (outcome.kind === 'ok') {
          this.result.set(outcome.res);
          this.loadError.set(null);
        } else if (outcome.kind === 'empty') {
          this.result.set({
            ok: true,
            months: [],
            summary: { completedCount: 0, cancelledCount: 0, lifetimeEarnedCents: 0 },
            hasMore: false,
          });
          this.loadError.set(null);
        } else {
          this.loadError.set(`Couldn't load your history (error ${outcome.status}).`);
        }
      });
  }

  protected onSearch(value: string): void {
    this.term.set(value);
  }

  protected reload(): void {
    this.reload$.next();
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'job-history-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
