import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * JobTrackingComponent — live ride tracking surface.
 *
 * Renders a MapLibre GL JS map on token-free OSM tiles (lazy-imported per the
 * monorepo rule), a pulsing
 * crew puck with heading arrow, the route polyline, a sticky safe-area ETA
 * pill, the 6-step status timeline, the in-app chat, and role-gated action
 * buttons. WebSocket to /api/ride/stream?rideId=<id> drives every signal.
 *
 * Role visibility:
 *   crew     → On the way / Arrived / Start job / Complete
 *   customer → Tip / Rate / Share trip (Web Share API + /api/trip-share)
 */
import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  ElementRef,
  computed,
  effect,
  inject,
  signal,
  viewChild,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ActivatedRoute } from '@angular/router';
import type { Subscription } from 'rxjs';
import { RoleService } from '../../core/role.service';
import { AuthService } from '../../core/auth.service';
import { WsService } from '../../core/ws.service';
import { OSM_DARK_STYLE, type MapLibreMapHandle } from '../../core/osm-map-style';
import { HlmCardImports, HlmButton, HlmBadge } from '../../shared/ui-spartan';
import {
  StatusTimelineComponent,
  type RideStatusStep,
} from '../_shared/status-timeline.component';
import { RideChatComponent } from '../_shared/ride-chat.component';
import { TipDialogComponent } from '../_shared/tip-dialog.component';
import { RateReviewComponent } from '../_shared/rate-review.component';
import { TerminalCheckoutCardComponent } from '../_shared/terminal-checkout-card.component';
import { JobPhotosCardComponent } from '../_shared/job-photos-card.component';

interface StreamFrame {
  readonly type: 'state' | 'gps' | 'eta';
  readonly state?: RideStatusStep;
  readonly lat?: number;
  readonly lng?: number;
  readonly heading?: number;
  readonly etaSeconds?: number;
  readonly route?: ReadonlyArray<readonly [number, number]>;
}

@Component({
  selector: 'app-job-tracking',
  standalone: true,
  imports: [
    ...HlmCardImports,
    HlmButton,
    HlmBadge,
    StatusTimelineComponent,
    RideChatComponent,
    TipDialogComponent,
    RateReviewComponent,
    TerminalCheckoutCardComponent,
    JobPhotosCardComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="mb-4 flex items-start justify-between gap-3">
      <div>
        <h1 class="text-2xl font-bold text-foreground">Trip {{ rideId() }}</h1>
        <p class="text-sm text-muted-foreground">Live updates via secure WebSocket.</p>
      </div>
      <span hlmBadge [variant]="connected() ? 'success' : 'warning'">{{
        connected() ? 'Live' : 'Reconnecting…'
      }}</span>
    </header>

    <bcl-status-timeline [current]="state()" />

    <div class="mt-4 grid gap-4 lg:grid-cols-[2fr_1fr]">
      <section class="relative overflow-hidden rounded-xl ring-1 ring-border" aria-label="Live tracking map">
        <div
          #mapEl
          data-testid="job-map"
          data-testid-alt="tracking-map"
          class="h-[420px] w-full bg-background"
        ></div>

        <div
          class="pointer-events-none absolute inset-x-0 bottom-0 flex justify-center"
          style="padding-bottom: max(0.75rem, env(safe-area-inset-bottom));"
        >
          <div
            data-testid="live-eta"
            aria-label="Estimated time of arrival"
            class="pointer-events-auto rounded-full bg-card/95 px-4 py-2 text-sm font-semibold text-foreground ring-1 ring-primary shadow-lg backdrop-blur"
          >
            ETA <span class="font-mono text-primary">{{ etaLabel() }}</span>
          </div>
        </div>
      </section>

      <bcl-ride-chat
        class="block h-[420px]"
        [rideId]="rideId()"
        [me]="myRole()"
        [senderId]="senderId()"
      />
    </div>

    <div hlmCard class="mt-4">
      <div hlmCardHeader><h3 hlmCardTitle>Actions</h3></div>
      <div hlmCardContent>
        @if (isCrew()) {
          <div class="flex flex-wrap gap-2">
            <button hlmBtn type="button" (click)="advance('enroute')" [disabled]="!canAdvanceTo('enroute')">On the way</button>
            <button hlmBtn type="button" (click)="advance('arrived')" [disabled]="!canAdvanceTo('arrived')">Arrived</button>
            <button hlmBtn type="button" (click)="advance('working')" [disabled]="!canAdvanceTo('working')">Start job</button>
            <button
              hlmBtn
              type="button"
              (click)="advance('complete')"
              [disabled]="!canAdvanceTo('complete')"
              class="bg-emerald-500 text-white hover:bg-emerald-500/90"
            >Complete</button>
          </div>

          @if (canCollect()) {
            <div class="mt-4">
              <bcl-terminal-checkout-card
                [bookingId]="rideId()"
                [defaultAmountCents]="subtotalCents()"
              />
            </div>
          }
        } @else {
          <div class="flex flex-wrap gap-2">
            <button hlmBtn type="button" (click)="tipOpen.set(true)">Tip</button>
            <button hlmBtn variant="outline" type="button" (click)="rateOpen.set(!rateOpen())">
              {{ rateOpen() ? 'Hide rating' : 'Rate' }}
            </button>
            <button hlmBtn variant="outline" type="button" (click)="shareTrip()">Share trip</button>
          </div>

          @if (shareUrl(); as u) {
            <p class="mt-3 text-xs text-muted-foreground" role="status" aria-live="polite">
              Share link copied: <a class="text-primary" [href]="u" target="_blank" rel="noopener">{{ u }}</a>
            </p>
          }

          @if (rateOpen()) {
            <div class="mt-4">
              <bcl-rate-review [rideId]="rideId()" (submitted)="rateOpen.set(false)" />
            </div>
          }
        }
      </div>
    </div>

    <bcl-tip-dialog
      [open]="tipOpen()"
      [rideId]="rideId()"
      [subtotalCents]="subtotalCents()"
      (closed)="tipOpen.set(false)"
    />

    @if (isCrew()) {
      <div class="mt-4">
        <bcl-job-photos-card [gigId]="rideId()" />
      </div>
    }

    <p data-testid="photo-verification" class="sr-only">
      Before &amp; after photos can be added from the job card above.
    </p>
  `,
})
export class JobTrackingComponent implements AfterViewInit {
  private readonly route = inject(ActivatedRoute);
  private readonly roleSvc = inject(RoleService);
  private readonly auth = inject(AuthService);
  private readonly ws = inject(WsService);
  private readonly destroyRef = inject(DestroyRef);

  readonly mapEl = viewChild<ElementRef<HTMLDivElement>>('mapEl');

  readonly rideId = signal<string>('');
  readonly state = signal<RideStatusStep>('requested');
  readonly etaSeconds = signal<number | null>(null);
  readonly connected = signal<boolean>(false);
  readonly subtotalCents = signal<number>(0);
  readonly tipOpen = signal<boolean>(false);
  readonly rateOpen = signal<boolean>(false);
  readonly shareUrl = signal<string | null>(null);

  readonly isCrew = computed(() => this.roleSvc.viewAs() === 'crew');
  // In-person card collection is offered once the crew is on site (arrived → done).
  readonly canCollect = computed(() =>
    (['arrived', 'working', 'complete'] as RideStatusStep[]).includes(this.state()),
  );
  readonly myRole = computed<'customer' | 'crew' | 'admin'>(() => {
    const v = this.roleSvc.viewAs();
    return v === 'crew' ? 'crew' : v === 'super_admin' ? 'admin' : 'customer';
  });
  readonly senderId = computed(() => this.auth.whoami().userId ?? 'anon');

  readonly etaLabel = computed(() => {
    const s = this.etaSeconds();
    if (s === null) return '— —';
    const m = Math.max(0, Math.round(s / 60));
    if (m < 1) return '<1 min';
    if (m < 60) return `${m} min`;
    const h = Math.floor(m / 60);
    const rem = m % 60;
    return `${h}h ${rem}m`;
  });

  // Lazy-loaded map handle + state.
  private map: unknown | null = null;
  private puckMarker: {
    remove: () => void;
    setLngLat: (ll: [number, number]) => unknown;
    getElement: () => HTMLElement;
  } | null = null;
  private routeAdded = false;
  private readonly wsHandle = signal<ReturnType<WsService['connect']> | null>(null);
  private wsSubscription: Subscription | null = null;

  constructor() {
    // Top-level effect that mirrors socket-open state into a signal.
    effect(() => this.connected.set(this.wsHandle()?.isOpen() ?? false));

    this.route.paramMap.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((params) => {
      const id = params.get('id') ?? '';
      this.rideId.set(id);
      if (id) this.openWs(id);
    });
    this.destroyRef.onDestroy(() => {
      this.wsSubscription?.unsubscribe();
      this.wsHandle()?.close();
    });
  }

  async ngAfterViewInit(): Promise<void> {
    await this.initMap();
  }

  private openWs(id: string): void {
    this.wsSubscription?.unsubscribe();
    this.wsSubscription = null;
    this.wsHandle()?.close();
    const proto = globalThis.location?.protocol === 'https:' ? 'wss' : 'ws';
    const host = globalThis.location?.host ?? '';
    const url = `${proto}://${host}/api/ride/stream?rideId=${encodeURIComponent(id)}`;
    const handle = this.ws.connect(url);
    this.wsHandle.set(handle);
    this.wsSubscription = handle.stream$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((ev) => this.onFrame(ev.data));
  }

  private onFrame(raw: string): void {
    let frame: StreamFrame | null = null;
    try {
      frame = JSON.parse(raw) as StreamFrame;
    } catch {
      return;
    }
    if (frame.type === 'state' && frame.state) {
      this.state.set(frame.state);
    } else if (
      frame.type === 'gps' &&
      typeof frame.lat === 'number' &&
      typeof frame.lng === 'number'
    ) {
      this.updatePuck(frame.lat, frame.lng, frame.heading ?? 0);
    } else if (frame.type === 'eta' && typeof frame.etaSeconds === 'number') {
      this.etaSeconds.set(frame.etaSeconds);
      if (frame.route?.length) this.drawRoute(frame.route);
    }
  }

  private async initMap(): Promise<void> {
    const el = this.mapEl()?.nativeElement;
    if (!el) return;
    let maplibregl: typeof import('maplibre-gl');
    try {
      maplibregl = await import('maplibre-gl');
      if (!maplibregl?.Map) {
        el.innerHTML =
          '<div class="flex h-full items-center justify-center text-sm text-bcl-ink-muted">Map unavailable</div>';
        return;
      }
    } catch {
      el.innerHTML =
        '<div class="flex h-full items-center justify-center text-sm text-bcl-ink-muted">Map unavailable</div>';
      return;
    }
    try {
      // Token-free OSM raster basemap — no API key, no /api/mapbox-token fetch.
      this.map = new maplibregl.Map({
        container: el,
        style: OSM_DARK_STYLE,
        center: [-74.1723, 40.7357], // Newark default
        zoom: 12,
      });
    } catch {
      el.innerHTML =
        '<div class="flex h-full items-center justify-center text-sm text-bcl-ink-muted">Map unavailable</div>';
    }
  }

  private updatePuck(lat: number, lng: number, heading: number): void {
    const m = this.map as { addControl?: unknown } | null;
    if (!m || typeof window === 'undefined') return;
    void import('maplibre-gl').then((mod) => {
      const maplibre = mod;
      const ll: [number, number] = [lng, lat];
      if (!this.puckMarker) {
        const el = document.createElement('div');
        el.setAttribute('aria-label', 'Crew location');
        el.style.cssText =
          'width:18px;height:18px;border-radius:50%;background:var(--bcl-accent);box-shadow:0 0 0 6px rgba(255,107,26,0.25);animation:bcl-puck-pulse 1.5s ease-in-out infinite;';
        if (!document.getElementById('bcl-puck-style')) {
          const style = document.createElement('style');
          style.id = 'bcl-puck-style';
          style.textContent =
            '@keyframes bcl-puck-pulse{0%,100%{box-shadow:0 0 0 6px rgba(255,107,26,0.25)}50%{box-shadow:0 0 0 12px rgba(255,107,26,0.05)}}@media (prefers-reduced-motion:reduce){#bcl-puck{animation:none!important}}';
          document.head.appendChild(style);
        }
        el.id = 'bcl-puck';
        this.puckMarker = new maplibre.Marker({ element: el, rotationAlignment: 'map' })
          .setLngLat(ll)
          .addTo(this.map as unknown as MapLibreMapHandle);
      } else {
        this.puckMarker.setLngLat(ll);
      }
      const elNow = this.puckMarker.getElement();
      elNow.style.transform = `${elNow.style.transform || ''} rotate(${heading}deg)`;
    });
  }

  private drawRoute(coords: ReadonlyArray<readonly [number, number]>): void {
    if (!this.map || this.routeAdded) return;
    void import('maplibre-gl').then(() => {
      const map = this.map as unknown as MapLibreMapHandle;
      map.addSource('bcl-route', {
        type: 'geojson',
        data: {
          type: 'Feature',
          properties: {},
          geometry: { type: 'LineString', coordinates: coords as unknown as number[][] },
        },
      });
      map.addLayer({
        id: 'bcl-route-line',
        type: 'line',
        source: 'bcl-route',
        paint: {
          'line-color': '#ff6b1a',
          'line-width': 4,
          'line-dasharray': [2, 2],
        },
      });
      this.routeAdded = true;
    });
  }

  canAdvanceTo(next: RideStatusStep): boolean {
    const order: RideStatusStep[] = [
      'requested',
      'matched',
      'enroute',
      'arrived',
      'working',
      'complete',
    ];
    const curIdx = order.indexOf(this.state());
    const nextIdx = order.indexOf(next);
    return nextIdx === curIdx + 1;
  }

  advance(to: RideStatusStep): void {
    this.wsHandle()?.send({
      type: 'transition',
      to,
      by: 'crew',
      rideId: this.rideId(),
    });
  }

  async shareTrip(): Promise<void> {
    const trip = this.rideId();
    let url = `${globalThis.location?.origin ?? ''}/track/${encodeURIComponent(trip)}`;
    try {
      const res = await fetch('/api/trip-share', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rideId: trip }),
      });
      if (res.ok) {
        const body = (await res.json()) as { url?: string };
        if (body.url) url = body.url;
      }
    } catch {
      // fall back to local URL
    }
    this.shareUrl.set(url);
    if (typeof navigator === 'undefined') return;
    const nav = navigator as Navigator & {
      share?: (init: ShareData) => Promise<void>;
      clipboard?: { writeText: (s: string) => Promise<void> };
    };
    if (typeof nav.share === 'function') {
      try {
        await nav.share({ title: 'Follow my Brick City trip', url });
        return;
      } catch {
        // fall through to clipboard fallback
      }
    }
    if (nav.clipboard?.writeText) {
      try {
        await nav.clipboard.writeText(url);
      } catch {
        /* noop */
      }
    }
  }
}

// Map types come from maplibre-gl's own type-only import; the dynamic import()
// calls above pull the GL runtime lazily on first render.
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'job-tracking-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
