import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { Route } from '@angular/router';
import { featureFlagCanMatch } from '../../core/feature-flag-guard';

export const JOBS_ROUTES: Route[] = [
  {
    path: '',
    loadComponent: () => import('./jobs.component').then((m) => m.JobsComponent),
  },
  // SCAN-01 — crew Job History portal subpage (flag: crew_job_history). MUST be
  // declared BEFORE the `:id` routes below so "history" is never captured as a
  // gig id (static-route-before-dynamic). featureFlagCanMatch declines the match
  // when the flag is off, so the route doesn't exist from the user's perspective
  // (never redirects/403s a real path) — the server's GET /api/work/gigs/history
  // is independently 404-dark.
  {
    path: 'history',
    canMatch: [featureFlagCanMatch('crew_job_history')],
    loadComponent: () => import('./job-history.component').then((m) => m.JobHistoryComponent),
  },
  // Smartphone-first crew Job Detail page (flag: crew_job_detail_v2). It shares
  // the `:id` path with the legacy JobTrackingComponent below; featureFlagCanMatch
  // declines the match when the flag is off, so the router falls through to the
  // live-tracking surface. Deep-linkable from an offer/email link.
  {
    path: ':id',
    canMatch: [featureFlagCanMatch('crew_job_detail_v2')],
    loadComponent: () => import('./job-detail.component').then((m) => m.JobDetailComponent),
  },
  {
    path: ':id',
    loadComponent: () => import('./job-tracking.component').then((m) => m.JobTrackingComponent),
  },
];
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'jobs-routes',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
