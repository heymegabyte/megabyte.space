import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * RateCustomerComponent — SCAN-13: the crew-facing "Rate this customer" card.
 *
 * Closes the two-sided rating loop's crew side. The customer→crew direction has
 * long shipped (bcl-rate-review → POST /api/ratings/submit); the crew→customer
 * SUBMISSION endpoint (`POST /api/work/reviews/:gigId`, writes the `reviews` table
 * `direction='worker_to_customer'`) was LIVE + unflagged but had ZERO crew-UI
 * caller — a built-but-unwired latent defect per [[interconnectedness]]. This
 * component is that missing caller. It mirrors bcl-rate-review's proven a11y shape
 * (ARIA radiogroup star picker with roving tabindex + arrow-key nav, optional
 * note) so the two rating surfaces feel identical, and RECYCLES the live endpoint
 * rather than the dead `two_way_mutual_rating`-gated `/api/mutual-rating/submit`
 * duplicate (whose flag was deleted in migration 0123 → dark-forever).
 *
 * Shown by JobDetailComponent ONLY once the gig is `completed` AND the crew has
 * not already rated the customer (the parent gates on the GET /api/work/gigs/:id
 * `ratedCustomer` field). On a duplicate submit the endpoint 409s `already_reviewed`
 * (belt-and-suspenders); a `not_completed` 409 or 401 surfaces a plain message.
 * Standalone + signals + OnPush + zoneless-safe; strict, no `any`.
 */
import { ChangeDetectionStrategy, Component, computed, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { focusRadioAtIndex, nextRadioIndex, rovingTabIndex } from '@theme.tools/i18n-a11y/field-service/radio-keynav';

/** Optional flag reasons — mirror the worker `ratingSchema.flagKind` enum exactly. */
const FLAGS = [
  { value: '', label: 'No issue' },
  { value: 'no_show', label: 'No-show' },
  { value: 'rude', label: 'Rude' },
  { value: 'unsafe', label: 'Unsafe' },
  { value: 'property_damage', label: 'Property damage' },
  { value: 'quality', label: 'Quality' },
  { value: 'other', label: 'Other' },
] as const;

type FlagValue = (typeof FLAGS)[number]['value'];

/** Outcome the parent listens for → refresh the gig so the card self-hides. */
export type RateCustomerOutcome = 'rated' | 'already' | 'not_completed' | 'error';

@Component({
  selector: 'app-rate-customer',
  standalone: true,
  imports: [FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section
      class="rounded-xl border border-border bg-card p-5"
      aria-label="Rate this customer"
      data-testid="crew-rate-customer"
    >
      @if (done()) {
        <div class="flex items-center gap-2" role="status" data-testid="crew-rate-customer-done">
          <span aria-hidden="true" class="text-xl text-primary">★</span>
          <p class="text-sm font-medium text-foreground">
            {{ doneLabel() }}
          </p>
        </div>
      } @else {
        <h3 class="text-base font-semibold text-foreground">Rate this customer</h3>
        <p class="mt-1 text-sm text-muted-foreground">
          Your rating helps match great customers with the right crew. It's private to the team.
        </p>

        <div
          class="mt-4 flex items-center gap-2"
          role="radiogroup"
          aria-label="Customer stars"
          (keydown)="onStarKey($event)"
        >
          @for (n of starList; track n; let i = $index) {
            <button
              type="button"
              role="radio"
              [attr.aria-checked]="rating() === n"
              [attr.aria-label]="n + ' stars'"
              [attr.tabindex]="rove(i)"
              (click)="rating.set(n)"
              [attr.data-testid]="'crew-star-' + n"
              class="min-h-[44px] min-w-[44px] rounded-lg text-2xl transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
              [class.text-primary]="rating() >= n"
              [class.text-muted-foreground]="rating() < n"
            >
              ★
            </button>
          }
        </div>

        <label class="mt-4 block">
          <span class="text-xs uppercase tracking-wider text-muted-foreground">Flag an issue</span>
          <select
            [(ngModel)]="flagKind"
            class="mt-1 min-h-[44px] w-full rounded-lg border border-border bg-background px-3 text-sm text-foreground focus:outline-none focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
            data-testid="crew-rate-flag"
            aria-label="Flag an issue with this customer"
          >
            @for (f of flagOptions; track f.value) {
              <option [value]="f.value">{{ f.label }}</option>
            }
          </select>
        </label>

        <label class="mt-4 block">
          <span class="text-xs uppercase tracking-wider text-muted-foreground">Note (optional)</span>
          <textarea
            [(ngModel)]="note"
            rows="3"
            maxlength="800"
            class="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground focus:outline-none focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
            placeholder="Anything the team should know about this customer?"
            data-testid="crew-rate-note"
          ></textarea>
        </label>

        @if (errorMsg(); as m) {
          <p class="mt-3 text-sm text-destructive" role="alert" data-testid="crew-rate-error">
            {{ m }}
          </p>
        }

        <button
          type="button"
          (click)="submit()"
          [disabled]="pending() || rating() === 0"
          class="mt-4 min-h-[44px] w-full rounded-lg bg-primary px-4 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
          data-testid="crew-rate-submit"
        >
          <span class="inline-block min-w-[14ch] text-center">{{
            pending() ? 'Submitting…' : 'Submit rating'
          }}</span>
        </button>
      }
    </section>
  `,
})
export class RateCustomerComponent {
  /** The gig id — the customer is rated via POST /api/work/reviews/:gigId. */
  readonly gigId = input.required<string>();
  /** Emitted after any terminal outcome so the parent can refresh + self-hide. */
  readonly rated = output<RateCustomerOutcome>();

  readonly starList = [1, 2, 3, 4, 5] as const;
  readonly flagOptions = FLAGS;

  readonly rating = signal<0 | 1 | 2 | 3 | 4 | 5>(0);
  readonly pending = signal<boolean>(false);
  readonly done = signal<boolean>(false);
  readonly errorMsg = signal<string | null>(null);
  private readonly outcome = signal<RateCustomerOutcome | null>(null);
  flagKind: FlagValue = '';
  note = '';

  readonly doneLabel = computed(() =>
    this.outcome() === 'already'
      ? 'You already rated this customer.'
      : `Thanks — you rated this customer ${this.rating() || ''}★.`.trim(),
  );

  /** Index of the tab stop: the selected star, or the first star when unrated. */
  private readonly activeStarIndex = computed(() => {
    const r = this.rating();
    return r === 0 ? 0 : r - 1;
  });

  /** Roving tabindex for the star at `i`: 0 for the active star, else -1. */
  rove(i: number): 0 | -1 {
    return rovingTabIndex(i, this.activeStarIndex());
  }

  /** ARIA radio-group arrow/Home/End navigation across the 5 stars. */
  onStarKey(event: KeyboardEvent): void {
    const next = nextRadioIndex(this.activeStarIndex(), this.starList.length, event.key);
    if (next === null) return;
    event.preventDefault();
    const star = this.starList[next];
    if (star === undefined) return;
    this.rating.set(star);
    focusRadioAtIndex(event.currentTarget as HTMLElement, next);
  }

  async submit(): Promise<void> {
    if (this.pending() || this.rating() === 0) return;
    this.pending.set(true);
    this.errorMsg.set(null);
    const body: {
      stars: number;
      body?: string;
      flagKind?: Exclude<FlagValue, ''>;
    } = { stars: this.rating() };
    const trimmed = this.note.trim();
    if (trimmed) body.body = trimmed;
    if (this.flagKind) body.flagKind = this.flagKind;

    try {
      const res = await fetch(`/api/work/reviews/${encodeURIComponent(this.gigId())}`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (res.ok) {
        this.outcome.set('rated');
        this.done.set(true);
        this.rated.emit('rated');
        return;
      }
      // Typed, non-throwing failure envelopes from the live endpoint.
      const code = await res
        .json()
        .then((j: { code?: string }) => j.code ?? '')
        .catch(() => '');
      if (res.status === 409 && code === 'already_reviewed') {
        this.outcome.set('already');
        this.done.set(true);
        this.rated.emit('already');
        return;
      }
      if (res.status === 409 && code === 'not_completed') {
        this.errorMsg.set('This job isn’t marked complete yet — you can rate once it finishes.');
        this.rated.emit('not_completed');
        return;
      }
      if (res.status === 401) {
        this.errorMsg.set('Please sign in again to rate this customer.');
        this.rated.emit('error');
        return;
      }
      this.errorMsg.set('Couldn’t submit your rating — please try again.');
      this.rated.emit('error');
    } catch {
      this.errorMsg.set('Network hiccup — please try again.');
      this.rated.emit('error');
    } finally {
      this.pending.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'rate-customer-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
