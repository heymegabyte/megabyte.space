import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * LogsComponent — real-time audit-log stream over WebSocket.
 *
 * Opens `wss://<host>/api/admin/logs/stream` via `core/ws.service.ts`. New
 * rows append to an in-memory ring (cap 10k); the BclTable virtualises the
 * render so the DOM only paints the visible window.
 *
 * Filter pipeline (computed signal): rows → actor-text → action-set →
 * severity-chips → time-range → tenant.
 *
 * Pause/resume just stops appending — the socket stays open so we don't
 * miss anything when the user un-pauses (rows arriving during pause are
 * dropped to keep the buffer small; the cursor on the server side keeps
 * the back-end honest).
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  OnDestroy,
  OnInit,
  computed,
  effect,
  inject,
  signal,
} from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { type ColumnDef } from '@tanstack/angular-table';
import { WsService, type WsHandle } from '../../core/ws.service';
import { routeFade, reducedMotion } from '../../shared/animations';
import { HlmButton, HlmInput, HlmSwitch, SmartTableComponent } from '../../shared/ui-spartan';

/** Max rows painted at once — a live audit tail shows the newest window. */
const RENDER_CAP = 300;

interface AuditRowWire {
  id: string;
  created_at: string;
  entity_type: string;
  entity_id: string;
  action: string;
  detail: string;
}

interface AuditRow extends Record<string, unknown> {
  readonly id: string;
  readonly created_at: string;
  readonly entity_type: string;
  readonly entity_id: string;
  readonly action: string;
  readonly detail: string;
  readonly severity: 'info' | 'warn' | 'error';
}

type Severity = 'info' | 'warn' | 'error';

const BUFFER_CAP = 10_000;
const AUTOSCROLL_KEY = 'bcl_logs_autoscroll';

function readAutoscroll(): boolean {
  try {
    const raw = globalThis.localStorage?.getItem(AUTOSCROLL_KEY);
    return raw === null || raw === undefined ? true : raw === '1';
  } catch {
    return true;
  }
}

function writeAutoscroll(v: boolean): void {
  try {
    globalThis.localStorage?.setItem(AUTOSCROLL_KEY, v ? '1' : '0');
  } catch {
    /* tolerate */
  }
}

function inferSeverity(row: AuditRowWire): Severity {
  const a = row.action.toLowerCase();
  if (
    a.includes('error') ||
    a.includes('failed') ||
    a.includes('rollback') ||
    a.includes('refund')
  ) {
    return 'error';
  }
  if (
    a.includes('warn') ||
    a.includes('disabled') ||
    a.includes('kill_switch') ||
    a.includes('blocked')
  ) {
    return 'warn';
  }
  return 'info';
}

@Component({
  selector: 'app-logs',
  standalone: true,
  imports: [ReactiveFormsModule, HlmButton, HlmInput, HlmSwitch, SmartTableComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <header class="mb-4 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
      <div>
        <h1 class="text-2xl font-bold text-foreground">Live audit logs</h1>
        <p class="text-sm text-muted-foreground">
          Streaming /api/admin/logs/stream via WebSocket. 10,000-row ring buffer; oldest rows fall off.
        </p>
      </div>
      <div class="flex items-center gap-3">
        <span
          class="inline-flex items-center gap-2 text-xs"
          [class.text-emerald-300]="isConnected()"
          [class.text-muted-foreground]="!isConnected()"
          aria-live="polite"
        >
          <span
            class="h-2 w-2 rounded-full"
            [class.bg-emerald-400]="isConnected()"
            [class.bg-muted-foreground]="!isConnected()"
            aria-hidden="true"
          ></span>
          {{ isConnected() ? 'Connected' : 'Reconnecting…' }}
        </span>
        <button hlmBtn variant="ghost" (click)="exportCsv()" [disabled]="filtered().length === 0">
          Export CSV
        </button>
        <button hlmBtn [variant]="paused() ? 'default' : 'secondary'" (click)="togglePause()">
          {{ paused() ? 'Resume' : 'Pause' }}
        </button>
      </div>
    </header>

    <section class="mb-4 grid grid-cols-1 gap-3 md:grid-cols-5" aria-label="Filters">
      <label class="block">
        <span class="mb-1 block text-xs font-medium text-muted-foreground">Actor / entity</span>
        <input hlmInput type="search" [formControl]="actorCtrl" placeholder="user-id, booking-id…" class="h-9 w-full" aria-label="Filter by actor or entity ID" />
      </label>
      <label class="block">
        <span class="mb-1 block text-xs font-medium text-muted-foreground">Action</span>
        <input hlmInput type="search" [formControl]="actionCtrl" placeholder="booking_created, refund_…" class="h-9 w-full" aria-label="Filter by action" />
      </label>
      <fieldset class="block">
        <legend class="mb-1 block text-xs font-medium text-muted-foreground">Severity</legend>
        <div class="flex gap-1" role="group">
          @for (sev of severities; track sev) {
            <button
              type="button"
              role="checkbox"
              [attr.aria-checked]="severitySet().has(sev)"
              (click)="toggleSeverity(sev)"
              class="rounded-full px-3 py-1 text-xs ring-1 transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
              [class]="severityChipClass(sev)"
            >
              {{ sev }}
            </button>
          }
        </div>
      </fieldset>
      <label class="block">
        <span class="mb-1 block text-xs font-medium text-muted-foreground">From</span>
        <input hlmInput type="datetime-local" [formControl]="fromCtrl" class="h-9 w-full" aria-label="Range start" />
      </label>
      <label class="block">
        <span class="mb-1 block text-xs font-medium text-muted-foreground">To</span>
        <input hlmInput type="datetime-local" [formControl]="toCtrl" class="h-9 w-full" aria-label="Range end" />
      </label>
    </section>

    <div class="mb-3 flex items-center justify-between text-xs text-muted-foreground">
      <span>
        {{ filtered().length }} / {{ rows().length }} rows
        @if (filtered().length > renderCap) {
          · showing latest {{ renderCap }}
        }
      </span>
      <hlm-switch [(checked)]="autoScroll" label="Auto-scroll to bottom" ariaLabel="Auto-scroll to newest" />
    </div>

    @if (rows().length === 0) {
      <div class="rounded-xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">
        Waiting for events — no audit rows have arrived yet. The stream is hot; when an action
        happens, it lands here.
      </div>
    } @else {
      <app-smart-table
        [data]="capped()"
        [columns]="cols"
        [filterable]="false"
        [rowsActivatable]="false"
        emptyText="No rows match the active filters."
      />
    }
  `,
})
export class LogsComponent implements OnInit, OnDestroy {
  protected readonly reducedMotion = reducedMotion;
  private readonly ws = inject(WsService);
  private readonly destroyRef = inject(DestroyRef);
  private handle: WsHandle | null = null;

  readonly severities: readonly Severity[] = ['info', 'warn', 'error'];

  readonly rows = signal<readonly AuditRow[]>([]);
  readonly paused = signal<boolean>(false);
  readonly autoScroll = signal<boolean>(readAutoscroll());
  readonly isConnected = signal<boolean>(false);

  readonly actorCtrl = new FormControl<string>('', { nonNullable: true });
  readonly actionCtrl = new FormControl<string>('', { nonNullable: true });
  readonly fromCtrl = new FormControl<string>('', { nonNullable: true });
  readonly toCtrl = new FormControl<string>('', { nonNullable: true });

  readonly actorText = signal<string>('');
  readonly actionText = signal<string>('');
  readonly fromText = signal<string>('');
  readonly toText = signal<string>('');
  readonly severitySet = signal<ReadonlySet<Severity>>(new Set<Severity>(this.severities));

  readonly renderCap = RENDER_CAP;

  readonly cols: ColumnDef<AuditRow>[] = [
    {
      accessorKey: 'created_at',
      header: 'Time',
      cell: (info) => new Date(info.getValue<string>()).toLocaleString(),
    },
    { accessorKey: 'severity', header: 'Sev' },
    { accessorKey: 'entity_type', header: 'Type' },
    { accessorKey: 'action', header: 'Action' },
    { accessorKey: 'entity_id', header: 'Entity ID' },
    { accessorKey: 'detail', header: 'Detail' },
  ];

  readonly filtered = computed<readonly AuditRow[]>(() => {
    const actor = this.actorText().trim().toLowerCase();
    const action = this.actionText().trim().toLowerCase();
    const sevs = this.severitySet();
    const from = this.fromText() ? new Date(this.fromText()).toISOString() : '';
    const to = this.toText() ? new Date(this.toText()).toISOString() : '';
    return this.rows().filter((r) => {
      if (!sevs.has(r.severity)) return false;
      if (actor && !`${r.entity_id} ${r.detail}`.toLowerCase().includes(actor)) return false;
      if (action && !r.action.toLowerCase().includes(action)) return false;
      if (from && r.created_at < from) return false;
      if (to && r.created_at > to) return false;
      return true;
    });
  });

  /** Newest RENDER_CAP rows (mutable copy for SmartTable) — a live tail shows
   *  the most recent window; full set stays queryable via the filters. */
  readonly capped = computed<AuditRow[]>(() => {
    const f = this.filtered();
    return (f.length > RENDER_CAP ? f.slice(-RENDER_CAP) : [...f]);
  });

  constructor() {
    this.actorCtrl.valueChanges
      .pipe(takeUntilDestroyed())
      .subscribe((v) => this.actorText.set(v ?? ''));
    this.actionCtrl.valueChanges
      .pipe(takeUntilDestroyed())
      .subscribe((v) => this.actionText.set(v ?? ''));
    this.fromCtrl.valueChanges
      .pipe(takeUntilDestroyed())
      .subscribe((v) => this.fromText.set(v ?? ''));
    this.toCtrl.valueChanges.pipe(takeUntilDestroyed()).subscribe((v) => this.toText.set(v ?? ''));

    // Mirror the handle's isOpen into our own signal so the template can read it.
    effect(() => {
      if (this.handle) {
        this.isConnected.set(this.handle.isOpen());
      }
    });

    // Persist the auto-scroll preference so a power-user's choice survives reloads.
    effect(() => {
      writeAutoscroll(this.autoScroll());
    });
  }

  ngOnInit(): void {
    const proto = globalThis.location?.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = globalThis.location?.host ?? '';
    const url = `${proto}//${host}/api/admin/logs/stream`;
    this.handle = this.ws.connect(url);
    this.handle.stream$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((ev) => {
      this.ingest(ev.data);
    });
  }

  ngOnDestroy(): void {
    this.handle?.close();
    this.handle = null;
  }

  private ingest(data: string): void {
    if (this.paused()) return;
    let msg: { kind?: string; row?: AuditRowWire } | null = null;
    try {
      msg = JSON.parse(data);
    } catch {
      return;
    }
    if (!msg || msg.kind !== 'row' || !msg.row) return;
    const wire = msg.row;
    const next: AuditRow = {
      id: wire.id,
      created_at: wire.created_at,
      entity_type: wire.entity_type,
      entity_id: wire.entity_id,
      action: wire.action,
      detail: wire.detail,
      severity: inferSeverity(wire),
    };
    const cur = this.rows();
    const merged = [...cur, next];
    const trimmed = merged.length > BUFFER_CAP ? merged.slice(-BUFFER_CAP) : merged;
    this.rows.set(trimmed);
  }

  togglePause(): void {
    this.paused.update((p) => !p);
  }

  toggleSeverity(s: Severity): void {
    const cur = new Set(this.severitySet());
    if (cur.has(s)) cur.delete(s);
    else cur.add(s);
    this.severitySet.set(cur);
  }

  severityChipClass(s: Severity): string {
    const active = this.severitySet().has(s);
    if (!active) {
      return 'bg-background text-muted-foreground ring-border hover:text-foreground';
    }
    if (s === 'error') return 'bg-red-500/15 text-red-300 ring-red-400/30';
    if (s === 'warn') return 'bg-amber-500/15 text-amber-300 ring-amber-400/30';
    return 'bg-primary/15 text-primary ring-primary/30';
  }

  exportCsv(): void {
    const rows = this.filtered();
    const header = ['time', 'severity', 'entity_type', 'entity_id', 'action', 'detail'];
    const esc = (v: string): string => (/[",\n\r]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v);
    const body = rows
      .map((r) =>
        [r.created_at, r.severity, r.entity_type, r.entity_id, r.action, r.detail]
          .map((v) => esc(String(v ?? '')))
          .join(','),
      )
      .join('\n');
    const csv = `${header.join(',')}\n${body}\n`;
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `audit-logs-${new Date().toISOString().slice(0, 19)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'logs-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
