import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { Route } from '@angular/router';

export const LOGS_ROUTES: Route[] = [
  {
    path: '',
    loadComponent: () => import('./logs.component').then((m) => m.LogsComponent),
  },
];
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'logs-routes',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
