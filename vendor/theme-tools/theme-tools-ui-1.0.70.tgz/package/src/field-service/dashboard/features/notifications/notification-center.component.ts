import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * NotificationCenterComponent — the standalone full-history notification center
 * (CONVERGENCE_SPEC §"Novu" → "Notification center: full history view — filter by
 * category, mark-read/unread, archive, deep-link"). The bell dropdown is the
 * glanceable inbox; this page is the durable record.
 *
 * Backed by the same `/api/dashboard/notifications` worker surface as the bell:
 *  - `GET ?limit=50` (active) / `?limit=50&include=archived` (archive tab)
 *  - `POST /:id/read` · `/:id/unread` · `/:id/archive` · `/:id/unarchive` · `/read-all`
 *
 * Filtering (category chips) + search + day-grouping reuse the shared pure
 * helpers (`notification-grouping.ts`, `notification-categories.ts`) so the bell
 * and the center can never diverge. Guest-safe: the feed endpoint returns an
 * empty list for signed-out callers, so no authed-fetch console error.
 */
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  type OnInit,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import {
  NOTIFICATION_CATEGORIES,
  DEFAULT_NOTIFICATION_PREFS,
  normalizeNotificationPrefs,
  isKindEnabled,
  toggleKind,
  applyCategoryPrefs,
  summarizeFilter,
  type NotificationKind,
  type NotificationPrefs,
} from '@theme.tools/notifications/field-service/notification-categories';
import {
  groupByDay,
  searchNotifications,
  type NotificationItem,
} from '@theme.tools/notifications/field-service/notification-grouping';
import { RovingTablistDirective } from '../_shared/roving-tablist.directive';
import { routeFade, reducedMotion } from '../../shared/animations';

type Tab = 'active' | 'archive';

@Component({
  selector: 'app-notification-center',
  standalone: true,
  imports: [RovingTablistDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <section class="mx-auto w-full max-w-3xl px-4 py-6" data-testid="notification-center">
      <header class="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p class="font-mono text-[11px] uppercase tracking-wider text-bcl-accent">Inbox</p>
          <h1 class="text-2xl font-bold text-bcl-ink">Notifications</h1>
        </div>
        <button
          type="button"
          (click)="markAllRead()"
          [disabled]="unreadCount() === 0"
          class="rounded-lg px-3 py-1.5 text-sm font-medium text-bcl-ink-muted ring-1 ring-bcl-border transition-all duration-[333ms] hover:-translate-y-0.5 hover:text-bcl-ink disabled:opacity-40 disabled:hover:translate-y-0 focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
        >
          Mark all read
        </button>
      </header>

      <!-- Tabs: active vs archive -->
      <div class="mb-4 inline-flex rounded-lg bg-bcl-bg-elev p-1 ring-1 ring-bcl-border" role="tablist" bclRovingTablist aria-label="Notification view">
        @for (t of tabs; track t.id) {
          <button
            type="button"
            role="tab"
            [attr.aria-selected]="tab() === t.id"
            (click)="setTab(t.id)"
            class="rounded-md px-3 py-1.5 text-sm font-medium transition-all duration-[333ms] focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
            [class.bg-bcl-accent]="tab() === t.id"
            [class.text-bcl-bg]="tab() === t.id"
            [class.text-bcl-ink-muted]="tab() !== t.id"
            [class.hover:text-bcl-ink]="tab() !== t.id"
          >
            {{ t.label }}
          </button>
        }
      </div>

      <!-- Search + category filter chips -->
      <div class="mb-4 space-y-3">
        <label class="block">
          <span class="sr-only">Search notifications</span>
          <input
            type="search"
            [value]="query()"
            (input)="query.set($any($event.target).value)"
            placeholder="Search notifications…"
            class="w-full rounded-lg bg-bcl-bg-elev px-3 py-2 text-sm text-bcl-ink ring-1 ring-bcl-border placeholder:text-bcl-ink-muted focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
            data-testid="notification-search"
          />
        </label>
        <ul class="flex flex-wrap gap-2" role="list" aria-label="Filter by category">
          @for (cat of categories; track cat.kind) {
            <li>
              <button
                type="button"
                role="switch"
                [attr.aria-checked]="categoryEnabled(cat.kind)"
                [attr.aria-label]="cat.label + ': ' + cat.description"
                (click)="toggleCategory(cat.kind)"
                class="rounded-full px-3 py-1 text-xs font-medium ring-1 transition-all duration-[333ms] hover:-translate-y-0.5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
                [class.bg-bcl-accent]="categoryEnabled(cat.kind)"
                [class.text-bcl-bg]="categoryEnabled(cat.kind)"
                [class.ring-bcl-accent]="categoryEnabled(cat.kind)"
                [class.bg-transparent]="!categoryEnabled(cat.kind)"
                [class.text-bcl-ink-muted]="!categoryEnabled(cat.kind)"
                [class.ring-bcl-border]="!categoryEnabled(cat.kind)"
              >
                {{ cat.label }}
              </button>
            </li>
          }
        </ul>

        <!--
          SCAN-23 · WCAG 4.1.3 Status Messages (AA). When a filter chip is toggled or the
          search query changes, the visible list updates but sighted-only — a screen-reader
          user hears nothing. This polite live region announces the filtered result summary
          (count + active-filter context) WITHOUT moving focus. Driven by the filterSummary()
          computed, so it re-announces only when the derived summary string actually changes
          (never mid-load, never on an unchanged filter). Visible AND SR (a subtle status
          line doubles as sighted feedback), suppressed while the feed is loading.
        -->
        @if (!loading()) {
          <p
            role="status"
            aria-live="polite"
            aria-atomic="true"
            data-testid="notification-filter-status"
            class="font-mono text-[11px] uppercase tracking-wide text-bcl-ink-muted"
          >
            {{ filterSummary() }}
          </p>
        }
      </div>

      <!-- Feed -->
      @if (loading()) {
        <div class="space-y-2" aria-hidden="true">
          @for (i of [1, 2, 3, 4, 5]; track i) {
            <div class="h-16 animate-pulse rounded-lg bg-bcl-bg-elev"></div>
          }
        </div>
      } @else if (error()) {
        <div class="rounded-xl bg-bcl-bg-elev px-6 py-10 text-center ring-1 ring-bcl-border" data-testid="notification-load-error">
          <p class="text-sm font-medium text-bcl-ink" role="alert">Notifications couldn't load.</p>
          <p class="mt-1 text-xs text-bcl-ink-muted">Check your connection and try again.</p>
          <button
            type="button"
            (click)="load()"
            class="mt-4 rounded-lg bg-bcl-accent px-3 py-2 text-sm font-semibold text-bcl-bg focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
          >Try again</button>
        </div>
      } @else if (groups().length === 0) {
        <div class="rounded-xl bg-bcl-bg-elev px-6 py-16 text-center ring-1 ring-bcl-border" data-testid="notification-empty">
          <p class="text-sm font-medium text-bcl-ink">
            {{ tab() === 'archive' ? 'Nothing archived.' : "You're all caught up." }}
          </p>
          <p class="mt-1 text-xs text-bcl-ink-muted">
            {{
              tab() === 'archive'
                ? 'Items you archive will show up here.'
                : 'New bookings, gigs, and payments will appear here.'
            }}
          </p>
        </div>
      } @else {
        <div class="overflow-hidden rounded-xl bg-bcl-bg-elev ring-1 ring-bcl-border">
          @for (group of groups(); track group.label) {
            <p class="bg-bcl-bg/40 px-4 py-2 font-mono text-[10px] uppercase tracking-wide text-bcl-ink-muted">
              {{ group.label }}
            </p>
            <ol class="divide-y divide-bcl-border">
              @for (n of group.items; track n.id) {
                <li class="px-4 py-3 transition-colors duration-[333ms] hover:bg-white/5" [class.bg-bcl-accent\/5]="!n.read">
                  <div class="flex items-start gap-3">
                    <button type="button" (click)="open(n)" class="flex flex-1 items-start gap-3 text-left focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring">
                      <span
                        aria-hidden="true"
                        class="mt-1.5 inline-block size-2 shrink-0 rounded-full"
                        [class.bg-bcl-accent]="!n.read"
                        [class.bg-bcl-ink-muted]="n.read"
                      ></span>
                      <span class="min-w-0 flex-1">
                        <span class="block text-sm font-medium text-bcl-ink">{{ n.title }}</span>
                        @if (n.subtitle) {
                          <span class="block text-xs text-bcl-ink-muted">{{ n.subtitle }}</span>
                        }
                        <span class="mt-0.5 block font-mono text-[10px] uppercase text-bcl-ink-muted">{{ n.kind }}</span>
                      </span>
                    </button>
                  </div>
                  <div class="mt-2 flex flex-wrap items-center gap-3 pl-5 text-[11px]">
                    @if (tab() === 'active') {
                      @if (!n.read) {
                        <button type="button" (click)="markRead(n)" class="text-bcl-ink-muted transition-colors duration-[333ms] hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring">
                          Mark read
                        </button>
                      } @else {
                        <button type="button" (click)="markUnread(n)" class="text-bcl-ink-muted transition-colors duration-[333ms] hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring">
                          Mark unread
                        </button>
                      }
                      <button type="button" (click)="archive(n)" class="text-bcl-ink-muted transition-colors duration-[333ms] hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring">
                        Archive
                      </button>
                    } @else {
                      <button type="button" (click)="unarchive(n)" class="text-bcl-accent transition-colors duration-[333ms] hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring">
                        Restore
                      </button>
                    }
                  </div>
                </li>
              }
            </ol>
          }
        </div>
      }
    </section>
  `,
})
export class NotificationCenterComponent implements OnInit {
  /** Bound to host [@.disabled] — skips the route-entrance fade for reduced-motion users. */
  protected readonly reducedMotion = reducedMotion;
  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);

  readonly tab = signal<Tab>('active');
  readonly query = signal<string>('');
  readonly loading = signal<boolean>(true);
  readonly error = signal<boolean>(false);
  readonly items = signal<readonly NotificationItem[]>([]);
  readonly prefs = signal<NotificationPrefs>(DEFAULT_NOTIFICATION_PREFS);

  readonly categories = NOTIFICATION_CATEGORIES;
  readonly tabs: readonly { id: Tab; label: string }[] = [
    { id: 'active', label: 'Inbox' },
    { id: 'archive', label: 'Archived' },
  ];

  /** Category-filtered, search-filtered, day-grouped feed for the active tab. */
  readonly groups = computed(() =>
    groupByDay(searchNotifications(applyCategoryPrefs(this.items(), this.prefs()), this.query())),
  );
  readonly unreadCount = computed(
    () => applyCategoryPrefs(this.items(), this.prefs()).filter((i) => !i.read).length,
  );

  /**
   * SCAN-23 · The polite-live-region text: a plain-language summary of the CURRENT
   * filtered result set — matching count + which filters are narrowing it. Delegates
   * to the shared `summarizeFilter()` helper (SSOT for the wording, also used by the
   * bell — SCAN-54) so the two notification surfaces can never diverge. Recomputes
   * (and thus re-announces to screen readers via the `aria-live` region) only when the
   * count, the active category filters, the search query, or the tab changes; an
   * unchanged filter yields the identical string, so no spurious announcement fires.
   */
  readonly filterSummary = computed<string>(() => {
    const matched = searchNotifications(
      applyCategoryPrefs(this.items(), this.prefs()),
      this.query(),
    );
    return summarizeFilter(this.categories, this.prefs(), matched.length, {
      query: this.query(),
      archived: this.tab() === 'archive',
    });
  });

  ngOnInit(): void {
    void this.loadPrefs();
    void this.load();
  }

  setTab(t: Tab): void {
    if (this.tab() === t) return;
    this.tab.set(t);
    void this.load();
  }

  /** Fetch the full feed for the current tab (active vs archive). */
  async load(): Promise<void> {
    this.loading.set(true);
    this.error.set(false);
    const url =
      this.tab() === 'archive'
        ? '/api/dashboard/notifications?limit=50&include=archived'
        : '/api/dashboard/notifications?limit=50';
    try {
      const resp = await firstValueFrom(
        this.http.get<{ ok: boolean; items: NotificationItem[] }>(url, { withCredentials: true }),
      );
      const list = resp?.items ?? [];
      // Archive tab shows ONLY archived items; active tab shows the rest.
      const filtered =
        this.tab() === 'archive' ? list.filter((i) => i.archived) : list.filter((i) => !i.archived);
      this.items.set(filtered);
    } catch {
      this.items.set([]);
      this.error.set(true);
    } finally {
      this.loading.set(false);
    }
  }

  private async loadPrefs(): Promise<void> {
    try {
      const resp = await firstValueFrom(
        this.http.get<{ ok: boolean; mutedKinds?: unknown }>(
          '/api/dashboard/notifications/prefs',
          { withCredentials: true },
        ),
      );
      this.prefs.set(normalizeNotificationPrefs(resp));
    } catch {
      this.prefs.set(DEFAULT_NOTIFICATION_PREFS);
    }
  }

  open(n: NotificationItem): void {
    if (!n.read) this.markRead(n);
    if (n.href) void this.router.navigateByUrl(n.href);
  }

  markRead(n: NotificationItem): void {
    this.patch(n.id, (i) => ({ ...i, read: true }));
    this.post(`${encodeURIComponent(n.id)}/read`);
  }

  markUnread(n: NotificationItem): void {
    this.patch(n.id, (i) => ({ ...i, read: false }));
    this.post(`${encodeURIComponent(n.id)}/unread`);
  }

  archive(n: NotificationItem): void {
    this.items.update((list) => list.filter((i) => i.id !== n.id));
    this.post(`${encodeURIComponent(n.id)}/archive`);
  }

  unarchive(n: NotificationItem): void {
    this.items.update((list) => list.filter((i) => i.id !== n.id));
    this.post(`${encodeURIComponent(n.id)}/unarchive`);
  }

  markAllRead(): void {
    this.items.update((list) => list.map((i) => ({ ...i, read: true })));
    this.post('read-all');
  }

  categoryEnabled(kind: NotificationKind): boolean {
    return isKindEnabled(this.prefs(), kind);
  }

  toggleCategory(kind: NotificationKind): void {
    const next = toggleKind(this.prefs(), kind);
    this.prefs.set(next);
    void firstValueFrom(
      this.http.put('/api/dashboard/notifications/prefs', next, { withCredentials: true }),
    ).catch(() => undefined);
  }

  /** Optimistically map one item in place by id. */
  private patch(id: string, fn: (i: NotificationItem) => NotificationItem): void {
    this.items.update((list) => list.map((i) => (i.id === id ? fn(i) : i)));
  }

  /** Fire-and-forget a control POST; failures leave the optimistic state. */
  private post(path: string): void {
    void firstValueFrom(
      this.http.post(`/api/dashboard/notifications/${path}`, {}, { withCredentials: true }),
    ).catch(() => undefined);
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'notification-center-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
