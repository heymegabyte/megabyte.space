import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { Route } from '@angular/router';

export const QUOTES_ROUTES: Route[] = [
  {
    path: '',
    pathMatch: 'full',
    loadComponent: () => import('./quotes.component').then((m) => m.QuotesComponent),
  },
  {
    path: 'new',
    loadComponent: () => import('./quote-detail.component').then((m) => m.QuoteDetailComponent),
  },
  {
    path: ':id',
    loadComponent: () => import('./quote-detail.component').then((m) => m.QuoteDetailComponent),
  },
];
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'quotes-routes',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
