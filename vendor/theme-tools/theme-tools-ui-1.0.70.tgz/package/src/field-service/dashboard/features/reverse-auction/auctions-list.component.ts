import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * AuctionsListComponent — unified reverse-auction view.
 *
 * Persona-aware:
 *   - Crew: sees open auctions in their service area + can bid
 *   - Customer: sees their own auctions + status
 *   - Super-admin: sees both lists + a "Force-close winner" action
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  effect,
  inject,
  signal,
  untracked,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { DecimalPipe } from '@angular/common';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { catchError, finalize, of } from 'rxjs';
import { RouterLink } from '@angular/router';
import { RoleService } from '../../core/role.service';
import { AuthService } from '../../core/auth.service';
import { routeFade, reducedMotion } from '../../shared/animations';

interface Auction {
  readonly id: string;
  readonly service_zip: string;
  readonly preferred_date: string;
  readonly preferred_window: string;
  readonly crew_size: number;
  readonly hours: number;
  readonly max_rate_cents: number;
  readonly notes?: string | null;
  readonly status: string;
  readonly expires_at: string;
  readonly created_at: string;
  readonly bid_count?: number;
}

@Component({
  selector: 'app-auctions-list',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <header class="bcl-rise mb-6 rounded-2xl border border-bcl-border bcl-grain p-6">
      <p class="bcl-eyebrow mb-2">Reverse-Auction Marketplace</p>
      <h1 class="font-display text-3xl font-extrabold tracking-tight text-bcl-ink">
        @if (persona() === 'customer') {
          Get a better deal on Sun / Mon
        } @else if (persona() === 'crew') {
          Open auctions in your area
        } @else {
          Reverse-auction overview
        }
      </h1>
      <p class="mt-2 max-w-2xl text-sm text-bcl-ink-muted">
        @if (persona() === 'customer') {
          Post an off-peak job and let crews compete. Lowest-bid wins. Eligible windows: Sun
          11am-2pm + Mon 11am-2pm. Save up to 20%.
        } @else {
          Crews bid DOWN on slow-day jobs. Lowest bid at or below the customer's max wins.
          Highest-rated crew gets a 25-cent tiebreak bonus.
        }
      </p>
    </header>

    @if (needsAuth()) {
      <div
        class="rounded-2xl border border-dashed border-bcl-border p-10 text-center"
        data-testid="auctions-signin"
      >
        <p class="text-2xl" aria-hidden="true">🛎️</p>
        <p class="mt-2 text-base font-semibold text-bcl-ink">Sign in to use the marketplace</p>
        <p class="mx-auto mt-1 max-w-md text-sm text-bcl-ink-muted">
          Post an off-peak job or bid on one — log in and your auctions appear here.
        </p>
        <a
          [routerLink]="['/login']"
          [queryParams]="{ as: 'customer', next: '/auctions' }"
          class="mt-4 inline-flex items-center justify-center rounded-md bg-bcl-accent px-4 py-2 text-sm font-extrabold text-bcl-bg focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        >
          Sign in →
        </a>
      </div>
    } @else {
      @if (persona() === 'customer' || persona() === 'super_admin') {
        <section class="bcl-glass bcl-fade-in mb-6 p-5">
          <h2 class="font-display text-lg font-extrabold mb-3">Post a new auction</h2>
          <form (submit)="postAuction($event)" class="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <label class="flex flex-col gap-1">
              <span class="bcl-eyebrow">ZIP</span>
              <input
                type="text"
                [(ngModel)]="form.serviceZip"
                name="serviceZip"
                required
                maxlength="5"
                pattern="\\d{5}"
                placeholder="07102"
                class="rounded-md border border-bcl-border bg-bcl-bg-elev/60 px-3 py-2 text-sm text-bcl-ink"
              />
            </label>
            <label class="flex flex-col gap-1">
              <span class="bcl-eyebrow">Date (Sun or Mon)</span>
              <input
                type="date"
                [(ngModel)]="form.preferredDate"
                name="preferredDate"
                required
                class="rounded-md border border-bcl-border bg-bcl-bg-elev/60 px-3 py-2 text-sm text-bcl-ink"
              />
            </label>
            <label class="flex flex-col gap-1">
              <span class="bcl-eyebrow">Window</span>
              <select
                [(ngModel)]="form.preferredWindow"
                name="preferredWindow"
                required
                class="rounded-md border border-bcl-border bg-bcl-bg-elev/60 px-3 py-2 text-sm text-bcl-ink"
              >
                <option value="11:00-13:00">11am-1pm</option>
                <option value="11:00-14:00">11am-2pm</option>
                <option value="12:00-14:00">12pm-2pm</option>
              </select>
            </label>
            <label class="flex flex-col gap-1">
              <span class="bcl-eyebrow">Crew size</span>
              <select
                [(ngModel)]="form.crewSize"
                name="crewSize"
                class="rounded-md border border-bcl-border bg-bcl-bg-elev/60 px-3 py-2 text-sm text-bcl-ink"
              >
                <option [ngValue]="1">1 person</option>
                <option [ngValue]="2">2 people</option>
                <option [ngValue]="3">3 people</option>
                <option [ngValue]="4">4 people</option>
              </select>
            </label>
            <label class="flex flex-col gap-1">
              <span class="bcl-eyebrow">Hours</span>
              <select
                [(ngModel)]="form.hours"
                name="hours"
                class="rounded-md border border-bcl-border bg-bcl-bg-elev/60 px-3 py-2 text-sm text-bcl-ink"
              >
                <option [ngValue]="2">2hr</option>
                <option [ngValue]="3">3hr</option>
                <option [ngValue]="4">4hr</option>
                <option [ngValue]="6">6hr</option>
                <option [ngValue]="8">8hr</option>
              </select>
            </label>
            <label class="flex flex-col gap-1">
              <span class="bcl-eyebrow">Max rate ($/hr/person)</span>
              <input
                type="number"
                [(ngModel)]="form.maxRateDollars"
                name="maxRateDollars"
                min="25"
                max="80"
                class="rounded-md border border-bcl-border bg-bcl-bg-elev/60 px-3 py-2 text-sm text-bcl-ink"
              />
            </label>
            <button
              type="submit"
              [disabled]="posting()"
              class="sm:col-span-2 lg:col-span-3 inline-flex items-center justify-center rounded-md bg-bcl-accent px-4 py-2 text-lg font-extrabold text-bcl-bg disabled:cursor-wait"
            >
              {{ posting() ? 'Posting…' : 'Post auction →' }}
            </button>
          </form>
          @if (postError()) {
            <p class="mt-3 text-sm text-amber-300">{{ postError() }}</p>
          }
          @if (postedId()) {
            <p class="mt-3 text-sm text-emerald-300">
              Posted! Auction ID:
              <code class="font-mono">{{ postedId() }}</code>
            </p>
          }
        </section>
      }

      <section>
        <h2 class="font-display text-lg font-extrabold mb-3">
          {{
            persona() === 'customer'
              ? 'Your auctions'
              : persona() === 'crew'
                ? 'Open + bidding auctions'
                : 'Auction queue'
          }}
        </h2>
        @if (loading()) {
          <p class="text-sm text-bcl-ink-muted">Loading…</p>
        } @else if (error()) {
          <div class="rounded-xl border border-red-400/40 p-4" data-testid="auction-load-error">
            <p class="text-sm text-red-300" role="alert">{{ error() }}</p>
            <button
              type="button"
              (click)="fetch()"
              class="mt-3 rounded-md bg-bcl-accent px-3 py-2 text-sm font-bold text-bcl-bg focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
            >
              Try again
            </button>
          </div>
        } @else if (auctions().length === 0) {
          <p
            class="rounded-2xl border border-bcl-border bg-bcl-bg-elev/40 p-6 text-sm text-bcl-ink-muted"
          >
            No open auctions right now. They appear here as customers post them.
          </p>
        } @else {
          <ul class="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            @for (a of auctions(); track a.id) {
              <li class="bcl-glass bcl-fade-in p-5">
                <div class="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <p class="font-mono text-xs text-bcl-ink-muted">{{ a.id.slice(0, 14) }}…</p>
                    <h3 class="font-display text-base font-extrabold text-bcl-ink">
                      {{ a.service_zip }} · {{ a.preferred_date }}
                    </h3>
                  </div>
                  <span
                    class="rounded-full bg-bcl-accent/20 px-2 py-0.5 text-[11px] font-mono uppercase tracking-wider text-bcl-accent"
                  >
                    {{ a.status }}
                  </span>
                </div>
                <p class="text-sm text-bcl-ink-muted">
                  {{ a.preferred_window }} · {{ a.crew_size }}-person · {{ a.hours }}hr
                </p>
                <p class="mt-2 text-sm text-bcl-ink">
                  Max:
                  <strong class="text-bcl-accent"
                    >\${{ a.max_rate_cents / 100 | number }}/hr/person</strong
                  >
                </p>
                @if (persona() === 'super_admin') {
                  <p class="mt-1 text-xs text-bcl-ink-muted">
                    {{ a.bid_count ?? 0 }} pending bid{{ (a.bid_count ?? 0) === 1 ? '' : 's' }}
                  </p>
                }
                @if (persona() === 'crew') {
                  <form (submit)="placeBid($event, a)" class="mt-3 flex gap-2">
                    <input
                      type="number"
                      [value]="bidDrafts()[a.id] ?? a.max_rate_cents / 100"
                      (input)="setBidDraft(a.id, $event)"
                      min="25"
                      [max]="a.max_rate_cents / 100"
                      class="flex-1 rounded-md border border-bcl-border bg-bcl-bg-elev/60 px-2 py-1 text-sm text-bcl-ink"
                    />
                    <button
                      type="submit"
                      [disabled]="actionId() === a.id"
                      class="rounded-md bg-bcl-accent px-3 py-1 text-xs font-extrabold text-bcl-bg"
                    >
                      {{ actionId() === a.id ? 'Bidding…' : 'Bid' }}
                    </button>
                  </form>
                }
                @if (persona() === 'customer' && (a.status === 'open' || a.status === 'bidding')) {
                  <button
                    type="button"
                    (click)="cancelAuction(a)"
                    [disabled]="actionId() === a.id"
                    class="mt-3 rounded-md border border-bcl-border px-3 py-2 text-xs font-bold text-bcl-ink disabled:opacity-60 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                  >
                    {{ actionId() === a.id ? 'Cancelling…' : 'Cancel auction' }}
                  </button>
                }
                @if (persona() === 'super_admin' && a.status === 'bidding') {
                  <button
                    type="button"
                    (click)="acceptAuction(a)"
                    [disabled]="actionId() === a.id"
                    class="mt-3 rounded-md bg-bcl-accent px-3 py-2 text-xs font-extrabold text-bcl-bg disabled:opacity-60 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                  >
                    {{ actionId() === a.id ? 'Selecting…' : 'Select winner' }}
                  </button>
                }
                @if (actionError()[a.id]; as message) {
                  <p class="mt-2 text-xs text-red-300" role="alert">{{ message }}</p>
                }
                @if (actionSuccess()[a.id]; as message) {
                  <p class="mt-2 text-xs text-emerald-300" role="status">{{ message }}</p>
                }
              </li>
            }
          </ul>
        }
      </section>
    }
  `,
  imports: [FormsModule, DecimalPipe, RouterLink],
})
export class AuctionsListComponent {
  protected readonly reducedMotion = reducedMotion;
  private readonly http = inject(HttpClient);
  private readonly destroyRef = inject(DestroyRef);
  private readonly role = inject(RoleService);
  private readonly auth = inject(AuthService);

  readonly auctions = signal<Auction[]>([]);
  readonly loading = signal(false);
  readonly error = signal<string | null>(null);
  readonly persona = computed(() => this.role.viewAs());

  /**
   * /dashboard/auctions has no role guard, so the shell renders for a guest.
   * `/api/reverse-auction/open` 401s a signed-out visitor → a red console error.
   * Skip every fetch when signed out; show a sign-in affordance instead.
   */
  protected readonly needsAuth = computed(() => !this.auth.authenticated());

  readonly form = {
    serviceZip: '07102',
    preferredDate: this.nextSunday(),
    preferredWindow: '11:00-14:00',
    crewSize: 2,
    hours: 3,
    maxRateDollars: 45,
  };
  readonly posting = signal(false);
  readonly postError = signal<string | null>(null);
  readonly postedId = signal<string | null>(null);
  readonly bidDrafts = signal<Record<string, number>>({});
  readonly actionId = signal<string | null>(null);
  readonly actionError = signal<Record<string, string>>({});
  readonly actionSuccess = signal<Record<string, string>>({});

  constructor() {
    let wasAuthed = !this.needsAuth();
    effect(() => {
      const now = !this.needsAuth();
      if (now && !wasAuthed) {
        untracked(() => this.fetch());
      }
      wasAuthed = now;
    });
    this.fetch();
  }

  private nextSunday(): string {
    const d = new Date();
    const dayOffset = (7 - d.getDay()) % 7 || 7;
    d.setDate(d.getDate() + dayOffset);
    return d.toISOString().slice(0, 10);
  }

  setBidDraft(id: string, evt: Event): void {
    const v = Number((evt.target as HTMLInputElement).value);
    this.bidDrafts.update((d) => ({ ...d, [id]: v }));
  }

  fetch(): void {
    // Signed out → skip the authed fetch (no console 401); sign-in state shows.
    if (this.needsAuth()) {
      this.auctions.set([]);
      this.loading.set(false);
      return;
    }
    this.loading.set(true);
    this.error.set(null);
    const endpoint =
      this.persona() === 'customer'
        ? '/api/reverse-auction/mine'
        : this.persona() === 'super_admin'
          ? '/api/reverse-auction/admin'
          : '/api/reverse-auction/open';
    this.http
      .get<{ ok: boolean; auctions: Auction[] }>(endpoint, {
        withCredentials: true,
      })
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError((err: { status?: number }) => {
          this.error.set(
            err.status === 404
              ? 'Flag reverse_auction is off.'
              : err.status === 401
                ? 'Sign in as crew or admin to see open auctions.'
                : 'Auctions could not load. Check your connection and try again.',
          );
          return of({ ok: false, auctions: [] as Auction[] });
        }),
        finalize(() => this.loading.set(false)),
      )
      .subscribe((r) => this.auctions.set(r.auctions ?? []));
  }

  postAuction(evt: Event): void {
    evt.preventDefault();
    this.posting.set(true);
    this.postError.set(null);
    this.postedId.set(null);
    const body = {
      serviceZip: this.form.serviceZip,
      preferredDate: this.form.preferredDate,
      preferredWindow: this.form.preferredWindow,
      crewSize: this.form.crewSize,
      hours: this.form.hours,
      maxRateCentsPerPerson: Math.round(this.form.maxRateDollars * 100),
    };
    this.http
      .post<{ ok: boolean; id?: string; error?: string; detail?: string }>(
        '/api/reverse-auction/post',
        body,
        { withCredentials: true },
      )
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError((err: { status?: number; error?: { error?: string; detail?: string } }) =>
          of({
            ok: false,
            error: err.error?.error ?? `HTTP ${err.status}`,
            detail: err.error?.detail,
          }),
        ),
        finalize(() => this.posting.set(false)),
      )
      .subscribe((raw) => {
        const r = raw as {
          ok: boolean;
          id?: string;
          error?: string;
          detail?: string;
        };
        if (r.ok && r.id) {
          this.postedId.set(r.id);
          this.fetch();
        } else {
          this.postError.set(
            r.error === 'not_off_peak'
              ? `Not eligible: ${r.detail ?? 'try a Sunday or Monday 11am-2pm window'}.`
              : r.error === 'unauthorized'
                ? 'Sign in to post.'
                : r.error === 'rate_limited'
                  ? 'Too many auctions were posted recently. Try again later.'
                  : (r.error ?? 'Failed to post.'),
          );
        }
      });
  }

  placeBid(evt: Event, a: Auction): void {
    evt.preventDefault();
    const rate = this.bidDrafts()[a.id] ?? a.max_rate_cents / 100;
    this.beginAction(a.id);
    this.http
      .post<{ ok?: boolean; error?: string }>(
        '/api/reverse-auction/bid',
        {
          auctionId: a.id,
          rateCentsPerPerson: Math.round(rate * 100),
        },
        { withCredentials: true },
      )
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError((err: { error?: { error?: string } }) =>
          of({ ok: false, error: err.error?.error ?? 'connection_failed' }),
        ),
        finalize(() => this.actionId.set(null)),
      )
      .subscribe((result) => {
        if (result?.ok) {
          this.actionSuccess.update((state) => ({ ...state, [a.id]: 'Bid placed.' }));
          this.fetch();
        } else {
          this.actionError.update((state) => ({
            ...state,
            [a.id]: this.bidError(result?.error),
          }));
        }
      });
  }

  cancelAuction(a: Auction): void {
    this.mutateAuction(
      a,
      `/api/reverse-auction/cancel/${encodeURIComponent(a.id)}`,
      'Auction cancelled.',
    );
  }

  acceptAuction(a: Auction): void {
    this.mutateAuction(
      a,
      `/api/reverse-auction/accept/${encodeURIComponent(a.id)}`,
      'Winner selected.',
    );
  }

  private mutateAuction(a: Auction, url: string, success: string): void {
    this.beginAction(a.id);
    this.http
      .post<{ ok?: boolean; error?: string }>(url, {}, { withCredentials: true })
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError((err: { error?: { error?: string } }) =>
          of({ ok: false, error: err.error?.error ?? 'connection_failed' }),
        ),
        finalize(() => this.actionId.set(null)),
      )
      .subscribe((result) => {
        if (result.ok) {
          this.actionSuccess.update((state) => ({ ...state, [a.id]: success }));
          this.fetch();
        } else {
          this.actionError.update((state) => ({
            ...state,
            [a.id]:
              result.error === 'no_qualifying_bids'
                ? 'No qualifying bids are available.'
                : 'That action could not be completed. Refresh and try again.',
          }));
        }
      });
  }

  private beginAction(id: string): void {
    this.actionId.set(id);
    this.actionError.update((state) => ({ ...state, [id]: '' }));
    this.actionSuccess.update((state) => ({ ...state, [id]: '' }));
  }

  private bidError(error: string | undefined): string {
    switch (error) {
      case 'already_bid':
        return 'You already bid on this auction.';
      case 'bid_above_max':
        return 'Your bid must be at or below the customer’s maximum.';
      case 'expired':
      case 'not_biddable':
        return 'This auction is no longer accepting bids.';
      case 'rate_limited':
        return 'Too many bids were placed recently. Try again later.';
      default:
        return 'Bid could not be placed. Check your connection and try again.';
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'auctions-list-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
