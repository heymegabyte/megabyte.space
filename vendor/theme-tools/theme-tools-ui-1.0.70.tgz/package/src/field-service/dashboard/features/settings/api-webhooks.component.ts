import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * SettingsApiWebhooksComponent — API keys (create / rotate / revoke /
 * last-used) and webhooks (endpoint / events / delivery log /
 * signing secret reveal once).
 */
import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import {
  HlmCardImports,
  HlmButton,
  HlmBadge,
  HlmInput,
  HlmFormField,
} from '../../shared/ui-spartan';
import { SettingsService, ApiKey, Webhook } from './settings.service';

@Component({
  selector: 'app-settings-api-webhooks',
  standalone: true,
  imports: [...HlmCardImports, HlmButton, HlmBadge, HlmInput, HlmFormField, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="grid gap-4">
      <div hlmCard>
        <div hlmCardHeader>
          <h3 hlmCardTitle>API keys</h3>
          <p hlmCardDescription>For programmatic access to the bricklabor.com API.</p>
        </div>
        <div hlmCardContent>
          <form [formGroup]="keyForm" (ngSubmit)="createKey()" class="mb-4 grid gap-3 md:grid-cols-[1fr_auto]">
            <app-form-field label="New key name">
              <input hlmInput formControlName="name" type="text" placeholder="My CI" />
            </app-form-field>
            <div class="self-end">
              <button hlmBtn type="submit" [disabled]="keyForm.invalid || creatingKey()">Create key</button>
            </div>
          </form>
          @if (lastCreatedKey(); as t) {
            <div class="mb-4 rounded-lg border border-bcl-warn/40 bg-bcl-warn/10 px-3 py-2 text-sm" role="alert">
              <p class="text-bcl-warn">Copy this token — you won't see it again.</p>
              <div class="mt-1 flex items-start gap-2">
                <code class="block flex-1 break-all font-mono text-xs text-foreground">{{ t }}</code>
                <button
                  hlmBtn
                  variant="outline"
                  size="sm"
                  type="button"
                  class="shrink-0"
                  (click)="copy(t, 'key')"
                  aria-label="Copy API token to clipboard"
                >
                  {{ copied() === 'key' ? 'Copied ✓' : 'Copy' }}
                </button>
              </div>
            </div>
          }
          <ul class="divide-y divide-border">
            @for (k of keys(); track k.id) {
              <li class="flex items-center justify-between py-3 text-sm">
                <div class="min-w-0">
                  <p class="truncate text-foreground">{{ k.name }}</p>
                  <p class="font-mono text-xs text-muted-foreground">{{ k.tokenPreview }}</p>
                  <p class="text-xs text-muted-foreground">
                    Created {{ k.createdAt }} · last used {{ k.lastUsedAt ?? 'never' }}
                  </p>
                </div>
                <button hlmBtn variant="ghost" size="sm" (click)="revokeKey(k.id)">Revoke</button>
              </li>
            } @empty {
              <li class="py-4 text-sm text-muted-foreground">No API keys yet.</li>
            }
          </ul>
        </div>
      </div>

      <div hlmCard>
        <div hlmCardHeader>
          <h3 hlmCardTitle>Webhooks</h3>
          <p hlmCardDescription>POST events to your endpoint.</p>
        </div>
        <div hlmCardContent>
          <form [formGroup]="hookForm" (ngSubmit)="createHook()" class="mb-4 grid gap-3 md:grid-cols-[1fr_auto]">
            <app-form-field label="Endpoint URL">
              <input hlmInput formControlName="url" type="url" placeholder="https://example.com/webhooks/bcl" />
            </app-form-field>
            <div class="self-end">
              <button hlmBtn type="submit" [disabled]="hookForm.invalid || creatingHook()">Add webhook</button>
            </div>
          </form>
          @if (lastCreatedSecret(); as s) {
            <div class="mb-4 rounded-lg border border-bcl-warn/40 bg-bcl-warn/10 px-3 py-2 text-sm" role="alert">
              <p class="text-bcl-warn">Signing secret — store it now, shown once:</p>
              <div class="mt-1 flex items-start gap-2">
                <code class="block flex-1 break-all font-mono text-xs text-foreground">{{ s }}</code>
                <button
                  hlmBtn
                  variant="outline"
                  size="sm"
                  type="button"
                  class="shrink-0"
                  (click)="copy(s, 'secret')"
                  aria-label="Copy signing secret to clipboard"
                >
                  {{ copied() === 'secret' ? 'Copied ✓' : 'Copy' }}
                </button>
              </div>
            </div>
          }
          <ul class="divide-y divide-border">
            @for (h of hooks(); track h.id) {
              <li class="flex items-center justify-between py-3 text-sm">
                <div class="min-w-0">
                  <p class="truncate text-foreground">{{ h.url }}</p>
                  <div class="mt-1 flex flex-wrap gap-1" [attr.aria-label]="'Events subscribed'">
                    @if (h.events.length === 0) {
                      <span hlmBadge variant="secondary" class="text-[10px] px-2 py-0.5 transition-all duration-[333ms] hover:-translate-y-0.5 hover:shadow-sm">all events</span>
                    } @else {
                      @for (ev of h.events; track ev; let i = $index) {
                        <span hlmBadge variant="secondary"
                          class="text-[10px] px-2 py-0.5 transition-all duration-[333ms] hover:-translate-y-0.5 hover:shadow-sm"
                          [style.animation-delay]="i * 50 + 'ms'">{{ ev }}</span>
                      }
                    }
                  </div>
                </div>
                <div class="flex items-center gap-2">
                  <span hlmBadge [variant]="h.enabled ? 'success' : 'secondary'">
                    {{ h.enabled ? 'enabled' : 'disabled' }}
                  </span>
                  <button hlmBtn variant="ghost" size="sm" (click)="deleteHook(h.id)">Delete</button>
                </div>
              </li>
            } @empty {
              <li class="py-4 text-sm text-muted-foreground">No webhooks yet.</li>
            }
          </ul>
        </div>
      </div>

      @if (error(); as e) {
        <p class="text-sm text-destructive" role="alert">{{ e }}</p>
      }

      <span class="sr-only" role="status" aria-live="polite">
        {{
          copied() === 'key'
            ? 'API token copied to clipboard'
            : copied() === 'secret'
              ? 'Signing secret copied to clipboard'
              : ''
        }}
      </span>
    </div>
  `,
})
export class SettingsApiWebhooksComponent implements OnInit {
  private readonly svc = inject(SettingsService);

  readonly keys = signal<readonly ApiKey[]>([]);
  readonly hooks = signal<readonly Webhook[]>([]);
  readonly creatingKey = signal<boolean>(false);
  readonly creatingHook = signal<boolean>(false);
  readonly lastCreatedKey = signal<string | null>(null);
  readonly lastCreatedSecret = signal<string | null>(null);
  readonly error = signal<string | null>(null);
  /** Which one-time secret was just copied (drives the button label + SR announce). */
  readonly copied = signal<'key' | 'secret' | null>(null);

  readonly keyForm = new FormGroup({
    name: new FormControl<string>('', {
      nonNullable: true,
      validators: [Validators.required, Validators.minLength(2)],
    }),
  });

  readonly hookForm = new FormGroup({
    url: new FormControl<string>('', {
      nonNullable: true,
      validators: [Validators.required, Validators.pattern(/^https?:\/\//)],
    }),
  });

  async ngOnInit(): Promise<void> {
    try {
      this.keys.set(await this.svc.listApiKeys());
    } catch {
      /* */
    }
    try {
      this.hooks.set(await this.svc.listWebhooks());
    } catch {
      /* */
    }
  }

  async createKey(): Promise<void> {
    if (this.keyForm.invalid) return this.keyForm.markAllAsTouched();
    this.creatingKey.set(true);
    this.error.set(null);
    this.lastCreatedKey.set(null);
    try {
      const r = await this.svc.createApiKey(this.keyForm.controls.name.value, ['*']);
      this.lastCreatedKey.set(r.token);
      this.keys.set(await this.svc.listApiKeys());
      this.keyForm.reset();
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : 'Failed');
    } finally {
      this.creatingKey.set(false);
    }
  }

  async revokeKey(id: string): Promise<void> {
    try {
      await this.svc.revokeApiKey(id);
      this.keys.update((arr) => arr.filter((k) => k.id !== id));
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : 'Failed');
    }
  }

  async createHook(): Promise<void> {
    if (this.hookForm.invalid) return this.hookForm.markAllAsTouched();
    this.creatingHook.set(true);
    this.error.set(null);
    this.lastCreatedSecret.set(null);
    try {
      const r = await this.svc.createWebhook(this.hookForm.controls.url.value, []);
      this.lastCreatedSecret.set(r.secret);
      this.hooks.set(await this.svc.listWebhooks());
      this.hookForm.reset();
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : 'Failed');
    } finally {
      this.creatingHook.set(false);
    }
  }

  async deleteHook(id: string): Promise<void> {
    try {
      await this.svc.deleteWebhook(id);
      this.hooks.update((arr) => arr.filter((h) => h.id !== id));
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : 'Failed');
    }
  }

  /**
   * Copy a one-time secret (API token / webhook signing secret) to the clipboard.
   * These are shown ONCE — a copy button (not hand-select) is the safe affordance.
   * `copied` drives the "Copied ✓" label + the sr-only live-region announcement.
   */
  async copy(text: string, which: 'key' | 'secret'): Promise<void> {
    try {
      await navigator.clipboard.writeText(text);
      this.copied.set(which);
      setTimeout(() => this.copied.set(null), 2000);
    } catch {
      /* clipboard unavailable — ignore */
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'api-webhooks-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
