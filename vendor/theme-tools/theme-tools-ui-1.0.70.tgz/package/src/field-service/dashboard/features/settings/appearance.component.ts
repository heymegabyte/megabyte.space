import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * SettingsAppearanceComponent — theme, density, accent color.
 * Persists locally via `bcl_theme_v1` localStorage key.
 */
import { ChangeDetectionStrategy, Component, OnInit, effect, signal } from '@angular/core';
import { HlmCardImports } from '../../shared/ui-spartan';

type ThemeMode = 'light' | 'dark' | 'system';
type Density = 'comfortable' | 'compact';

const STORAGE_KEY = 'bcl_theme_v1';

interface ThemeState {
  readonly mode: ThemeMode;
  readonly density: Density;
  readonly accent: string;
}

const DEFAULT_STATE: ThemeState = {
  mode: 'system',
  density: 'comfortable',
  accent: '#ff6b1a',
};

@Component({
  selector: 'app-settings-appearance',
  standalone: true,
  imports: [...HlmCardImports],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="grid gap-4">
      <div hlmCard>
        <div hlmCardHeader>
          <h3 hlmCardTitle>Theme</h3>
          <p hlmCardDescription>Light, dark, or follow OS.</p>
        </div>
        <div hlmCardContent>
          <div class="flex flex-wrap gap-2">
            @for (m of modes; track m) {
              <button
                type="button"
                (click)="setMode(m)"
                class="rounded-lg px-3 py-2 text-sm font-medium ring-1 transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                [class.bg-primary]="state().mode === m"
                [class.text-primary-foreground]="state().mode === m"
                [class.bg-muted]="state().mode !== m"
                [class.text-foreground]="state().mode !== m"
                [class.ring-border]="state().mode !== m"
                [attr.aria-pressed]="state().mode === m"
              >
                {{ m }}
              </button>
            }
          </div>
        </div>
      </div>

      <div hlmCard>
        <div hlmCardHeader>
          <h3 hlmCardTitle>Density</h3>
          <p hlmCardDescription>Comfortable for tablets, compact for big screens.</p>
        </div>
        <div hlmCardContent>
          <div class="flex gap-2">
            @for (d of densities; track d) {
              <button
                type="button"
                (click)="setDensity(d)"
                class="rounded-lg px-3 py-2 text-sm font-medium ring-1 transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                [class.bg-primary]="state().density === d"
                [class.text-primary-foreground]="state().density === d"
                [class.bg-muted]="state().density !== d"
                [class.text-foreground]="state().density !== d"
                [class.ring-border]="state().density !== d"
                [attr.aria-pressed]="state().density === d"
              >
                {{ d }}
              </button>
            }
          </div>
        </div>
      </div>

      <div hlmCard>
        <div hlmCardHeader>
          <h3 hlmCardTitle>Accent color</h3>
          <p hlmCardDescription>Picks the cyan/violet/etc. brand accent.</p>
        </div>
        <div hlmCardContent>
          <div class="flex flex-wrap items-center gap-3">
            @for (c of presets; track c) {
              <button
                type="button"
                (click)="setAccent(c)"
                [style.background]="c"
                [attr.aria-label]="'Use accent ' + c"
                class="h-9 w-9 rounded-full ring-1 ring-border focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
                [class.outline]="state().accent === c"
                [class.outline-2]="state().accent === c"
                [class.outline-foreground]="state().accent === c"
              ></button>
            }
            <input
              type="color"
              [value]="state().accent"
              (input)="setAccent($any($event.target).value)"
              class="h-9 w-12 rounded-lg ring-1 ring-border"
              aria-label="Custom accent color"
            />
          </div>
        </div>
      </div>
    </div>
  `,
})
export class SettingsAppearanceComponent implements OnInit {
  readonly modes: readonly ThemeMode[] = ['light', 'dark', 'system'];
  readonly densities: readonly Density[] = ['comfortable', 'compact'];
  readonly presets = ['#ff6b1a', '#ff8a47', '#f59e0b', '#22c55e', '#8b5cf6', '#ef4444'];

  readonly state = signal<ThemeState>(DEFAULT_STATE);

  constructor() {
    effect(() => this.persist(this.state()));
  }

  ngOnInit(): void {
    try {
      const raw = globalThis.localStorage?.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<ThemeState>;
        this.state.set({ ...DEFAULT_STATE, ...parsed });
      }
    } catch {
      // ignore
    }
    this.applyToDom(this.state());
  }

  setMode(m: ThemeMode): void {
    this.state.update((s) => ({ ...s, mode: m }));
    this.applyToDom(this.state());
  }
  setDensity(d: Density): void {
    this.state.update((s) => ({ ...s, density: d }));
    this.applyToDom(this.state());
  }
  setAccent(a: string): void {
    this.state.update((s) => ({ ...s, accent: a }));
    this.applyToDom(this.state());
  }

  private persist(s: ThemeState): void {
    try {
      globalThis.localStorage?.setItem(STORAGE_KEY, JSON.stringify(s));
    } catch {
      // ignore
    }
  }

  private applyToDom(s: ThemeState): void {
    try {
      const doc = globalThis.document;
      if (!doc) return;
      const root = doc.documentElement;
      const resolved =
        s.mode === 'system'
          ? globalThis.matchMedia?.('(prefers-color-scheme: dark)').matches
            ? 'dark'
            : 'light'
          : s.mode;
      root.classList.toggle('dark', resolved === 'dark');
      root.dataset['density'] = s.density;
      root.style.setProperty('--bcl-accent', s.accent);
    } catch {
      // ignore
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'appearance-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
