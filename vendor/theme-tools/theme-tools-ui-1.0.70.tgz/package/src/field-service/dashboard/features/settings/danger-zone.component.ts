import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * SettingsDangerZoneComponent — export data, delete account.
 */
import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { HlmCardImports, HlmButton, HlmSpinner, ConfirmDialog } from '../../shared/ui-spartan';
import { SettingsService } from './settings.service';

@Component({
  selector: 'app-settings-danger-zone',
  standalone: true,
  imports: [...HlmCardImports, HlmButton, HlmSpinner, ConfirmDialog],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="grid gap-4">
      <div hlmCard>
        <div hlmCardHeader>
          <h3 hlmCardTitle>Export your data</h3>
          <p hlmCardDescription>A complete JSON archive of your account — ready to download in seconds.</p>
        </div>
        <div hlmCardContent>
          <button hlmBtn (click)="exportData()" [disabled]="exporting()">
            @if (exporting()) { <app-spinner [size]="16" /> Building… } @else { Export my data }
          </button>
          @if (exportUrl(); as url) {
            <p class="mt-2 text-sm text-bcl-success">
              Your archive is ready —
              <a [href]="url" download class="font-semibold underline hover:no-underline" data-testid="data-export-download">
                download it
              </a>
              (link valid 7 days).
            </p>
          }
        </div>
      </div>

      <div hlmCard>
        <div hlmCardHeader>
          <h3 hlmCardTitle>Delete account</h3>
          <p hlmCardDescription>Permanent. We retain audit + billing records per our privacy policy.</p>
        </div>
        <div hlmCardContent>
          <button hlmBtn variant="destructive" (click)="deleteOpen.set(true)">Delete account</button>
        </div>
      </div>

      @if (error(); as e) {
        <p class="text-sm text-destructive" role="alert">{{ e }}</p>
      }

      <app-confirm-dialog
        [open]="deleteOpen()"
        title="Delete account permanently?"
        description="This cannot be undone. Bookings, payouts, and audit history are removed except as required by law."
        confirmLabel="Delete forever"
        verifySlug="DELETE"
        (confirmed)="confirmDelete()"
        (cancelled)="deleteOpen.set(false)"
      />
    </div>
  `,
})
export class SettingsDangerZoneComponent {
  private readonly svc = inject(SettingsService);

  readonly deleteOpen = signal<boolean>(false);
  readonly exporting = signal<boolean>(false);
  readonly exportUrl = signal<string | null>(null);
  readonly error = signal<string | null>(null);

  async exportData(): Promise<void> {
    this.exporting.set(true);
    this.error.set(null);
    try {
      const r = await this.svc.requestDataExport();
      this.exportUrl.set(r.downloadUrl);
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : 'Failed');
    } finally {
      this.exporting.set(false);
    }
  }

  async confirmDelete(): Promise<void> {
    try {
      await this.svc.deleteAccount('DELETE');
      globalThis.location.assign('/');
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : 'Failed');
      this.deleteOpen.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'danger-zone-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
