import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * SettingsDataRightsComponent — CCPA + GDPR self-service surface on the live
 * Angular /dashboard. Angular port of the React `customer/DataRights`.
 *
 * Backends (all resolve under /api/data-rights):
 *   GET  /status        → { requests: RequestRow[] }
 *   POST /export {kind} → { ok, id, status }; download via GET /export?id=<id>
 *   POST /delete {confirm} → { ok, id, cancelWindowEndsAt }
 *   POST /cancel-delete {id}
 *
 * Self-gates: 401 → "sign in" notice (the customer surface only). Dark-cockpit
 * Spartan styling. Pure helpers (statusTone/formatLocal/downloadUrl/isCancellable)
 * are unit-tested in data-rights.component.spec.ts.
 */
import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { HlmCardImports, HlmButton, HlmSpinner, StateBlockComponent } from '../../shared/ui-spartan';

export interface DataRightsRequest {
  readonly id: string;
  readonly kind: 'ccpa' | 'gdpr' | 'manual';
  readonly status: 'pending' | 'processing' | 'ready' | 'delivered' | 'cancelled';
  readonly cancel_window_ends_at: string | null;
  readonly requested_at: string;
  readonly fulfilled_at: string | null;
}

/** Pure: badge tone for a request status. */
export function statusTone(status: DataRightsRequest['status']): 'ready' | 'cancelled' | 'pending' {
  if (status === 'ready' || status === 'delivered') return 'ready';
  if (status === 'cancelled') return 'cancelled';
  return 'pending';
}

/** Pure: a pending delete with a live cancel window can be cancelled. */
export function isCancellable(r: DataRightsRequest): boolean {
  return r.status === 'pending' && !!r.cancel_window_ends_at;
}

/** Pure: download URL for a ready export. */
export function downloadUrl(id: string): string {
  return `/api/data-rights/export?id=${encodeURIComponent(id)}`;
}

/** Pure: locale-format an ISO timestamp, tolerant of junk. */
export function formatLocal(iso: string | null): string {
  if (!iso) return '';
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return iso;
  return new Date(t).toLocaleString();
}

@Component({
  selector: 'app-settings-data-rights',
  standalone: true,
  imports: [...HlmCardImports, HlmButton, HlmSpinner, StateBlockComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="grid gap-4" data-testid="data-rights">
      <div hlmCard>
        <div hlmCardHeader>
          <h3 hlmCardTitle>Data rights</h3>
          <p hlmCardDescription>
            Download everything we hold about you, or ask us to delete it. We honor CCPA + GDPR
            within 30 days.
          </p>
        </div>
        <div hlmCardContent>
          @if (signedOut()) {
            <app-state-block state="empty" emptyTitle="Sign in to manage your data" emptyHint="Your data-rights tools appear once you're signed in." />
          } @else {
            <div class="grid gap-4 sm:grid-cols-2">
              <div class="rounded-lg border border-bcl-border bg-bcl-bg-elev p-4">
                <h4 class="font-semibold text-bcl-ink">Download my data</h4>
                <p class="mt-1 text-sm text-bcl-ink-muted">
                  JSON bundle of every booking, review, incident, and session tied to your account.
                </p>
                <button hlmBtn class="mt-3" [disabled]="working() === 'export'" (click)="startExport()">
                  @if (working() === 'export') { <app-spinner [size]="16" /> Requesting… }
                  @else { Request export }
                </button>
              </div>
              <div class="rounded-lg border border-destructive/40 bg-destructive/5 p-4">
                <h4 class="font-semibold text-bcl-ink">Delete my data</h4>
                <p class="mt-1 text-sm text-bcl-ink-muted">
                  Anonymizes every row tied to your account after a 30-day cancellation window.
                </p>
                @if (!confirmingDelete()) {
                  <button hlmBtn variant="destructive" class="mt-3" (click)="confirmingDelete.set(true)">
                    Start delete
                  </button>
                } @else {
                  <p class="mt-3 text-sm text-destructive">Irreversible after 30 days. Continue?</p>
                  <div class="mt-2 flex gap-2">
                    <button hlmBtn variant="destructive" [disabled]="working() === 'delete'" (click)="startDelete()">
                      {{ working() === 'delete' ? 'Scheduling…' : 'Yes, delete' }}
                    </button>
                    <button hlmBtn variant="ghost" (click)="confirmingDelete.set(false)">Cancel</button>
                  </div>
                }
              </div>
            </div>

            @if (notice(); as n) {
              <p class="mt-4 rounded-md border border-bcl-accent/40 bg-bcl-accent/10 px-3 py-2 text-sm text-bcl-accent" role="status">
                {{ n }}
              </p>
            }

            <h4 class="mt-6 mb-2 font-semibold text-bcl-ink">Your requests</h4>
            @if (loading()) {
              <app-spinner [size]="20" />
            } @else if (requests().length === 0) {
              <p class="text-sm text-bcl-ink-muted">No data-rights requests yet.</p>
            } @else {
              <ul class="grid gap-2">
                @for (r of requests(); track r.id) {
                  <li class="rounded-md border border-bcl-border bg-bcl-bg-elev p-3 text-sm">
                    <div class="flex flex-wrap items-center justify-between gap-2">
                      <span class="font-mono text-xs text-bcl-ink-muted">{{ r.id.slice(0, 10) }}</span>
                      <span class="text-xs text-bcl-ink-muted">{{ r.kind }}</span>
                      <span
                        class="rounded-full px-2 py-0.5 text-xs"
                        [class.bg-bcl-success\/30]="tone(r.status) === 'ready'"
                        [class.text-bcl-success]="tone(r.status) === 'ready'"
                        [class.bg-bcl-bg]="tone(r.status) === 'cancelled'"
                        [class.text-bcl-ink-muted]="tone(r.status) === 'cancelled'"
                        [class.bg-bcl-warn\/30]="tone(r.status) === 'pending'"
                        [class.text-bcl-warn]="tone(r.status) === 'pending'"
                      >{{ r.status }}</span>
                      @if (tone(r.status) === 'ready') {
                        <a class="text-xs text-bcl-accent underline" [href]="url(r.id)" data-testid="dr-download">Download</a>
                      }
                      @if (cancellable(r)) {
                        <button hlmBtn variant="ghost" class="text-xs" (click)="cancelDelete(r.id)">Cancel delete</button>
                      }
                    </div>
                    <p class="mt-1 text-xs text-bcl-ink-muted">
                      Requested {{ fmt(r.requested_at) }}
                      @if (r.cancel_window_ends_at) { · cancellable until {{ fmt(r.cancel_window_ends_at) }} }
                    </p>
                  </li>
                }
              </ul>
            }
          }

          @if (error(); as e) {
            <p class="mt-4 text-sm text-destructive" role="alert">{{ e }}</p>
          }
        </div>
      </div>
    </div>
  `,
})
export class SettingsDataRightsComponent implements OnInit {
  readonly requests = signal<DataRightsRequest[]>([]);
  readonly loading = signal(true);
  readonly signedOut = signal(false);
  readonly working = signal<'export' | 'delete' | null>(null);
  readonly confirmingDelete = signal(false);
  readonly notice = signal<string>('');
  readonly error = signal<string>('');

  // expose pure helpers to the template
  readonly tone = statusTone;
  readonly cancellable = isCancellable;
  readonly url = downloadUrl;
  readonly fmt = formatLocal;

  ngOnInit(): void {
    void this.reload();
  }

  async reload(): Promise<void> {
    this.error.set('');
    try {
      const res = await fetch('/api/data-rights/status', { credentials: 'include' });
      if (res.status === 401) {
        this.signedOut.set(true);
        this.loading.set(false);
        return;
      }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = (await res.json().catch(() => null)) as { requests?: DataRightsRequest[] } | null;
      this.requests.set(data?.requests ?? []);
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : 'Failed to load');
    } finally {
      this.loading.set(false);
    }
  }

  async startExport(): Promise<void> {
    this.working.set('export');
    this.notice.set('');
    try {
      const res = await fetch('/api/data-rights/export', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ kind: 'ccpa' }),
      });
      const data = (await res.json().catch(() => null)) as { ok?: boolean; id?: string; error?: string } | null;
      if (!data?.ok) throw new Error(data?.error ?? 'export_failed');
      this.notice.set(`Export started (id ${data.id}). Refresh in a moment, then use Download below.`);
      await this.reload();
    } catch (e) {
      this.notice.set(`Error: ${e instanceof Error ? e.message : 'failed'}`);
    } finally {
      this.working.set(null);
    }
  }

  async startDelete(): Promise<void> {
    this.working.set('delete');
    this.notice.set('');
    try {
      const res = await fetch('/api/data-rights/delete', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ confirm: true }),
      });
      const data = (await res.json().catch(() => null)) as { ok?: boolean; cancelWindowEndsAt?: string; error?: string } | null;
      if (!data?.ok) throw new Error(data?.error ?? 'delete_failed');
      this.notice.set(`Delete scheduled. Cancel any time before ${formatLocal(data.cancelWindowEndsAt ?? '')}.`);
      await this.reload();
    } catch (e) {
      this.notice.set(`Error: ${e instanceof Error ? e.message : 'failed'}`);
    } finally {
      this.working.set(null);
      this.confirmingDelete.set(false);
    }
  }

  async cancelDelete(id: string): Promise<void> {
    this.working.set('delete');
    try {
      await fetch('/api/data-rights/cancel-delete', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      await this.reload();
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : 'Failed');
    } finally {
      this.working.set(null);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'data-rights-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
