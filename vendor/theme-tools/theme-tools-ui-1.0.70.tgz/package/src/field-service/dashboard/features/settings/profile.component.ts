import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * SettingsProfileComponent — name / email / phone / avatar / timezone / language.
 */
import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  computed,
  inject,
  signal,
} from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import {
  HlmCardImports,
  HlmButton,
  HlmInput,
  HlmFormField,
  HlmSpinner,
} from '../../shared/ui-spartan';
import { SettingsService } from './settings.service';
import { AuthService } from '../../core/auth.service';

interface ProfileFormShape {
  readonly name: FormControl<string>;
  readonly email: FormControl<string>;
  readonly phone: FormControl<string>;
  readonly avatarUrl: FormControl<string>;
  readonly timezone: FormControl<string>;
  readonly language: FormControl<string>;
}

@Component({
  selector: 'app-settings-profile',
  standalone: true,
  imports: [
    ...HlmCardImports,
    HlmButton,
    HlmInput,
    HlmFormField,
    HlmSpinner,
    ReactiveFormsModule,
    RouterLink,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div hlmCard>
      <div hlmCardHeader>
        <h3 hlmCardTitle>Profile</h3>
        <p hlmCardDescription>Visible to teammates and customers.</p>
      </div>
      <div hlmCardContent>
        @if (needsAuth()) {
          <div class="py-6 text-center" data-testid="profile-signin">
            <p class="text-base font-semibold text-foreground">Sign in to edit your profile</p>
            <p class="mx-auto mt-1 max-w-md text-sm text-muted-foreground">
              Log in to view and update your name, contact details, and preferences.
            </p>
            <a
              hlmBtn
              class="mt-4"
              [routerLink]="['/login']"
              [queryParams]="{ as: 'customer', next: '/settings' }"
            >
              Sign in →
            </a>
          </div>
        } @else if (loaded()) {
          <form [formGroup]="form" (ngSubmit)="save()" class="grid gap-4 md:max-w-xl">
            <app-form-field label="Display name">
              <input hlmInput formControlName="name" type="text" autocomplete="name" />
            </app-form-field>
            <app-form-field label="Email">
              <input hlmInput formControlName="email" type="email" autocomplete="email" />
            </app-form-field>
            <app-form-field label="Phone">
              <input hlmInput formControlName="phone" type="tel" autocomplete="tel" />
              <p class="mt-1 text-xs text-muted-foreground">For SMS notifications</p>
            </app-form-field>
            <app-form-field label="Avatar URL">
              <input hlmInput formControlName="avatarUrl" type="url" />
            </app-form-field>
            <div class="grid gap-4 md:grid-cols-2">
              <app-form-field label="Timezone">
                <select
                  formControlName="timezone"
                  class="h-10 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                >
                  @for (tz of timezones; track tz) {
                    <option [value]="tz">{{ tz }}</option>
                  }
                </select>
              </app-form-field>
              <app-form-field label="Language">
                <select
                  formControlName="language"
                  class="h-10 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                >
                  <option value="en">English</option>
                  <option value="es">Español</option>
                  <option value="pt">Português</option>
                </select>
              </app-form-field>
            </div>
            @if (savedAt(); as ts) {
              <p class="text-xs text-bcl-success">Saved {{ ts }}</p>
            }
            @if (error(); as e) {
              <p class="text-sm text-destructive" role="alert">{{ e }}</p>
            }
            <div>
              <button hlmBtn type="submit" [disabled]="form.invalid || saving()">
                @if (saving()) { <app-spinner [size]="16" /> Saving… } @else { Save profile }
              </button>
            </div>
          </form>
        } @else {
          <p class="text-sm text-muted-foreground">Loading…</p>
        }
      </div>
    </div>
  `,
})
export class SettingsProfileComponent implements OnInit {
  private readonly svc = inject(SettingsService);
  private readonly auth = inject(AuthService);

  /**
   * /dashboard/settings has no role guard, so the shell renders for a guest.
   * `/api/settings/profile` 401s a signed-out visitor → a red console error.
   * Skip the load when signed out; show a sign-in affordance instead.
   */
  protected readonly needsAuth = computed(() => !this.auth.authenticated());

  readonly loaded = signal<boolean>(false);
  readonly saving = signal<boolean>(false);
  readonly error = signal<string | null>(null);
  readonly savedAt = signal<string | null>(null);

  readonly timezones = [
    'America/New_York',
    'America/Chicago',
    'America/Denver',
    'America/Los_Angeles',
    'America/Anchorage',
    'Pacific/Honolulu',
    'UTC',
    'Europe/London',
    'Europe/Berlin',
  ] as const;

  readonly form = new FormGroup<ProfileFormShape>({
    name: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),
    email: new FormControl<string>('', {
      nonNullable: true,
      validators: [Validators.required, Validators.email],
    }),
    phone: new FormControl<string>('', { nonNullable: true }),
    avatarUrl: new FormControl<string>('', { nonNullable: true }),
    timezone: new FormControl<string>('America/New_York', { nonNullable: true }),
    language: new FormControl<string>('en', { nonNullable: true }),
  });

  async ngOnInit(): Promise<void> {
    // Signed out → skip the authed load (no console 401); sign-in state shows.
    if (this.needsAuth()) return;
    try {
      const p = await this.svc.getProfile();
      this.form.patchValue({
        name: p.name,
        email: p.email,
        phone: p.phone,
        avatarUrl: p.avatarUrl ?? '',
        timezone: p.timezone,
        language: p.language,
      });
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : 'Failed to load');
    } finally {
      this.loaded.set(true);
    }
  }

  async save(): Promise<void> {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.saving.set(true);
    this.error.set(null);
    try {
      const v = this.form.getRawValue();
      await this.svc.saveProfile({
        ...v,
        avatarUrl: v.avatarUrl || null,
      });
      this.savedAt.set(new Date().toLocaleTimeString());
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : 'Save failed');
    } finally {
      this.saving.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'profile-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
