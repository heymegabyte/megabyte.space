import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * SettingsSecurityComponent — password change, TOTP enrollment, active
 * sessions w/ revoke, passkeys list, SSO config.
 */
import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import {
  HlmCardImports,
  HlmButton,
  HlmBadge,
  HlmInput,
  HlmFormField,
  HlmSpinner,
} from '../../shared/ui-spartan';
import { SettingsService, ActiveSession } from './settings.service';

@Component({
  selector: 'app-settings-security',
  standalone: true,
  imports: [...HlmCardImports, HlmButton, HlmBadge, HlmInput, HlmFormField, HlmSpinner, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="grid gap-4">
      <div hlmCard>
        <div hlmCardHeader>
          <h3 hlmCardTitle>Sign-in</h3>
          <p hlmCardDescription>Passwordless by design.</p>
        </div>
        <div hlmCardContent>
          <p class="text-sm text-muted-foreground">
            Brick Labor uses <strong class="text-foreground">passwordless sign-in</strong> — a
            one-time code or magic link sent to your email/phone each time. There's no password to
            change. To add a second factor, set up an authenticator app below.
          </p>
        </div>
      </div>

      <div hlmCard>
        <div hlmCardHeader>
          <h3 hlmCardTitle>Two-factor (TOTP)</h3>
          <p hlmCardDescription>Use an authenticator app.</p>
        </div>
        <div hlmCardContent>
          @if (!totpQr()) {
            <button hlmBtn (click)="startTotp()" [disabled]="totpStarting()">
              @if (totpStarting()) { <app-spinner [size]="16" /> Enabling… } @else { Enable TOTP }
            </button>
          } @else {
            <div class="grid gap-3 md:grid-cols-[160px_minmax(0,1fr)]">
              <div [innerHTML]="totpQr()" class="rounded-lg bg-white p-2" aria-label="TOTP QR code"></div>
              <div>
                <p class="mb-2 text-sm text-muted-foreground">
                  Scan the QR with your authenticator app, then enter the 6-digit code.
                </p>
                <p class="mb-3 break-all font-mono text-xs text-muted-foreground">Secret: {{ totpSecret() }}</p>
                <form [formGroup]="totpForm" (ngSubmit)="verifyTotp()" class="flex items-end gap-2">
                  <app-form-field label="6-digit code">
                    <input
                      hlmInput
                      formControlName="code"
                      inputmode="numeric"
                      pattern="[0-9]{6}"
                      maxlength="6"
                      class="w-32 text-center font-mono text-base tracking-widest"
                    />
                  </app-form-field>
                  <button hlmBtn type="submit" [disabled]="totpForm.invalid || totpVerifying()">Verify</button>
                </form>
                @if (totpError(); as e) {
                  <p class="mt-2 text-sm text-destructive" role="alert">{{ e }}</p>
                }
                @if (totpDone()) {
                  <p class="mt-2 text-sm text-bcl-success">TOTP enabled.</p>
                }
              </div>
            </div>
          }
        </div>
      </div>

      <div hlmCard>
        <div hlmCardHeader>
          <h3 hlmCardTitle>Passkeys</h3>
          <p hlmCardDescription>WebAuthn credentials.</p>
        </div>
        <div hlmCardContent>
          <p class="text-sm text-muted-foreground">
            Passkey management is handled inline at sign-in. Existing keys:
          </p>
          <p class="mt-1 text-sm text-foreground">{{ passkeyCount() }} on file</p>
        </div>
      </div>

      <div hlmCard>
        <div hlmCardHeader>
          <h3 hlmCardTitle>Active sessions</h3>
          <p hlmCardDescription>Sign out any device.</p>
        </div>
        <div hlmCardContent>
          @if (sessionsError(); as e) {
            <p class="mb-3 text-sm text-destructive" role="alert">{{ e }}</p>
          }
          <ul class="divide-y divide-border">
            @for (s of sessions(); track s.id) {
              <li class="flex items-center justify-between py-3">
                <div class="min-w-0">
                  <p class="truncate text-sm text-foreground">{{ s.userAgent }}</p>
                  <p class="text-xs text-muted-foreground">{{ s.ip }} · since {{ s.createdAt }}</p>
                </div>
                <div class="flex shrink-0 items-center gap-2">
                  @if (s.current) {
                    <span hlmBadge variant="success">This device</span>
                  } @else {
                    <button hlmBtn variant="ghost" size="sm" (click)="revokeSession(s.id)">Revoke</button>
                  }
                </div>
              </li>
            } @empty {
              <li class="py-4 text-sm text-muted-foreground">No active sessions.</li>
            }
          </ul>
        </div>
      </div>

    </div>
  `,
})
export class SettingsSecurityComponent implements OnInit {
  private readonly svc = inject(SettingsService);

  readonly totpStarting = signal<boolean>(false);
  readonly totpVerifying = signal<boolean>(false);
  readonly totpQr = signal<string | null>(null);
  readonly totpSecret = signal<string | null>(null);
  readonly totpError = signal<string | null>(null);
  readonly totpDone = signal<boolean>(false);

  readonly sessions = signal<readonly ActiveSession[]>([]);
  readonly sessionsError = signal<string | null>(null);
  readonly passkeyCount = signal<number>(0);

  readonly totpForm = new FormGroup({
    code: new FormControl<string>('', {
      nonNullable: true,
      validators: [Validators.required, Validators.pattern(/^[0-9]{6}$/)],
    }),
  });

  async ngOnInit(): Promise<void> {
    try {
      this.sessions.set(await this.svc.listSessions());
    } catch (e) {
      this.sessionsError.set(
        e instanceof Error ? `Couldn't load sessions: ${e.message}` : "Couldn't load sessions.",
      );
    }
  }


  async startTotp(): Promise<void> {
    this.totpStarting.set(true);
    this.totpError.set(null);
    try {
      const r = await this.svc.startTotpEnrollment();
      this.totpQr.set(r.qrSvg);
      this.totpSecret.set(r.secret);
    } catch (e) {
      this.totpError.set(e instanceof Error ? e.message : 'Failed');
    } finally {
      this.totpStarting.set(false);
    }
  }

  async verifyTotp(): Promise<void> {
    if (this.totpForm.invalid) return this.totpForm.markAllAsTouched();
    this.totpVerifying.set(true);
    this.totpError.set(null);
    try {
      await this.svc.verifyTotp(this.totpForm.controls.code.value);
      this.totpDone.set(true);
    } catch (e) {
      this.totpError.set(e instanceof Error ? e.message : 'Invalid code');
    } finally {
      this.totpVerifying.set(false);
    }
  }

  async revokeSession(id: string): Promise<void> {
    this.sessionsError.set(null);
    try {
      await this.svc.revokeSession(id);
      this.sessions.update((arr) => arr.filter((s) => s.id !== id));
    } catch (e) {
      // A destructive action must never fail silently — the device would look
      // revoked-pending while still active.
      this.sessionsError.set(
        e instanceof Error ? `Couldn't revoke session: ${e.message}` : "Couldn't revoke session.",
      );
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'security-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
