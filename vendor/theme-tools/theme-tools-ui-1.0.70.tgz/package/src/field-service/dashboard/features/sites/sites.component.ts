import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * SitesComponent — saved addresses & properties.
 *
 * Lists every saved address the user has booked from (customer view) OR
 * every active customer site (super-admin view). Each card shows recent
 * activity, a tiny SVG request-rate sparkline pulled from
 * `/api/admin/live-ops/metrics`, and a CTA to rebook OR open the customer's
 * profile.
 *
 * Loading uses skeleton cards matching the live card geometry (not a
 * generic spinner). Empty state offers a CTA. Errors surface via
 * <bcl-error-panel> with retry + report.
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  OnDestroy,
  OnInit,
  computed,
  effect,
  inject,
  signal,
  untracked,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { HlmBadge, HlmButton, HlmSkeleton } from '../../shared/ui-spartan';
import { routeFade, reducedMotion } from '../../shared/animations';
import { RoleService } from '../../core/role.service';
import { AuthService } from '../../core/auth.service';

interface SiteRow {
  readonly id: string;
  readonly label: string;
  readonly address: string;
  readonly city: string;
  readonly lastBookingAt: string | null;
  readonly totalBookings: number;
  readonly trend: readonly number[];
}

interface SitesResp {
  readonly ok: boolean;
  readonly sites?: readonly SiteRow[];
  readonly error?: string;
}

const POLL_MS = 60_000;

@Component({
  selector: 'app-sites',
  standalone: true,
  imports: [RouterLink, HlmBadge, HlmButton, HlmSkeleton],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <header class="mb-6 flex flex-wrap items-start justify-between gap-3">
      <div>
        <h1 class="text-2xl font-bold text-foreground">Sites</h1>
        <p class="mt-1 text-sm text-muted-foreground">{{ subtitle() }}</p>
      </div>
      @if (!loading() && sites().length > 0) {
        <span hlmBadge variant="default">{{ sites().length }} site{{ sites().length === 1 ? '' : 's' }}</span>
      }
    </header>

    @if (loadError(); as err) {
      <div
        class="flex items-center justify-between gap-3 rounded-xl border border-destructive/40 bg-destructive/5 px-4 py-3"
        role="alert"
      >
        <p class="text-sm text-foreground">Couldn't load sites — {{ err }}</p>
        <button hlmBtn variant="outline" size="sm" (click)="refresh()">Try again</button>
      </div>
    } @else if (loading()) {
      <div class="grid gap-3 sm:grid-cols-2 lg:grid-cols-3" aria-label="Loading sites">
        @for (i of [1, 2, 3, 4, 5, 6]; track i) {
          <article class="rounded-xl border border-border bg-card p-4">
            <div hlmSkeleton class="h-5 w-3/5"></div>
            <div hlmSkeleton class="mt-2 h-3.5 w-4/5"></div>
            <div hlmSkeleton class="mt-4 h-10 w-full"></div>
            <div hlmSkeleton class="mt-3 h-3 w-2/5"></div>
          </article>
        }
      </div>
    } @else if (needsAuth()) {
      <div class="rounded-xl border border-dashed border-border p-10 text-center" data-testid="sites-signin">
        <p class="text-2xl" aria-hidden="true">📍</p>
        <p class="mt-2 text-base font-semibold text-foreground">Sign in to see your sites</p>
        <p class="mx-auto mt-1 max-w-md text-sm text-muted-foreground">
          Log in to see every address you've booked from and rebook in one tap.
        </p>
        <a hlmBtn class="mt-4" [routerLink]="['/login']" [queryParams]="{ as: 'customer', next: '/sites' }">
          Sign in →
        </a>
      </div>
    } @else if (sites().length === 0) {
      <div class="rounded-xl border border-dashed border-border p-10 text-center">
        <p class="text-2xl" aria-hidden="true">📍</p>
        <p class="mt-2 text-base font-semibold text-foreground">No saved sites yet</p>
        <p class="mx-auto mt-1 max-w-md text-sm text-muted-foreground">{{ emptyBody() }}</p>
        <a hlmBtn class="mt-4" routerLink="/quotes/new">Book your first job →</a>
      </div>
    } @else {
      <div class="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        @for (s of sites(); track s.id) {
          <article
            class="group relative flex flex-col gap-3 rounded-xl border border-border bg-card p-4 transition-all duration-[333ms] hover:-translate-y-0.5 hover:border-primary focus-within:border-primary focus-within:ring-2 focus-within:ring-ring/40"
            [attr.data-testid]="'site-card-' + s.id"
          >
            <header class="flex items-start justify-between gap-2">
              <div class="min-w-0">
                <h2 class="truncate text-sm font-semibold text-foreground">{{ s.label }}</h2>
                <p class="truncate text-xs text-muted-foreground">
                  {{ s.address }}{{ s.city ? ', ' + s.city : '' }}
                </p>
              </div>
              <span hlmBadge variant="secondary">{{ s.totalBookings }}</span>
            </header>

            <!-- Sparkline: last 14 days of request rate. SVG so no lib. -->
            @if (s.trend.length > 0) {
              <svg
                viewBox="0 0 120 32"
                preserveAspectRatio="none"
                class="h-8 w-full text-primary"
                role="img"
                [attr.aria-label]="'Last ' + s.trend.length + ' day activity sparkline'"
              >
                <polyline
                  fill="none"
                  stroke="currentColor"
                  stroke-width="1.5"
                  stroke-linejoin="round"
                  stroke-linecap="round"
                  [attr.points]="sparkPoints(s.trend)"
                />
              </svg>
            }

            <footer class="flex items-center justify-between text-xs text-muted-foreground">
              <span>
                @if (s.lastBookingAt) {
                  Last booked {{ formatAgo(s.lastBookingAt) }}
                } @else {
                  No bookings yet
                }
              </span>
              <a
                [routerLink]="['/quotes', 'new']"
                [queryParams]="{ site: s.id }"
                [attr.aria-label]="'Rebook from ' + s.label"
                class="rounded-md border border-border bg-background px-2 py-1 transition-colors duration-[333ms] hover:border-primary hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring before:absolute before:inset-0 before:rounded-xl before:content-['']"
              >
                Book →
              </a>
            </footer>
          </article>
        }
      </div>
    }
  `,
})
export class SitesComponent implements OnInit, OnDestroy {
  protected readonly reducedMotion = reducedMotion;
  private readonly http = inject(HttpClient);
  private readonly role = inject(RoleService);
  private readonly auth = inject(AuthService);
  private readonly destroyRef = inject(DestroyRef);
  private timer: ReturnType<typeof setInterval> | null = null;

  /**
   * A guest reaching /dashboard/sites (the route has no role guard, so the
   * shell renders for everyone) must NOT fire the authed `/api/customer/sites`
   * fetch — the worker correctly 401s it, leaking a degraded "couldn't load"
   * panel. When signed out we skip the request and show a sign-in affordance.
   */
  protected readonly needsAuth = computed(() => !this.auth.authenticated());

  readonly sites = signal<readonly SiteRow[]>([]);
  readonly loading = signal<boolean>(true);
  readonly loadError = signal<string | null>(null);

  readonly subtitle = computed(() =>
    this.role.viewAs() === 'super_admin'
      ? 'Active customer sites — request volume + last touch.'
      : "Addresses you've booked from. Tap a card to rebook in one tap.",
  );

  readonly emptyBody = computed(() =>
    this.role.viewAs() === 'super_admin'
      ? 'Once customers book, their sites appear here grouped by address.'
      : 'After your first booking, your address is saved here so you can rebook in one tap.',
  );

  constructor() {
    let wasAuthed = !this.needsAuth();
    effect(() => {
      const now = !this.needsAuth();
      if (now && !wasAuthed) {
        untracked(() => {
          void this.refresh();
        });
      }
      wasAuthed = now;
    });
  }

  ngOnInit(): void {
    void this.refresh();
    // Only poll for an authenticated user — a guest interval would fire 401s.
    if (typeof setInterval !== 'undefined') {
      this.timer = setInterval(() => {
        if (!this.needsAuth()) void this.refresh();
      }, POLL_MS);
    }
  }

  ngOnDestroy(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  async refresh(): Promise<void> {
    this.loadError.set(null);
    // Signed out → skip the authed fetch (no console 401); show sign-in state.
    if (this.needsAuth()) {
      this.sites.set([]);
      this.loading.set(false);
      return;
    }
    try {
      const resp = await firstValueFrom(
        this.http.get<SitesResp>('/api/customer/sites', { withCredentials: true }),
      );
      this.sites.set(resp?.sites ?? []);
    } catch (err) {
      // `/api/customer/sites` EXISTS (derived from bookings), so a 404 is a
      // routing/mount REGRESSION — surface it as an error + retry, never the
      // false "No saved sites yet" empty (which tells a customer their saved
      // addresses vanished). Every load failure now shows the error panel.
      const status = (err as { status?: number }).status;
      this.loadError.set(
        status === 404
          ? 'the sites service is temporarily unavailable'
          : ((err as Error).message ?? 'network error'),
      );
      this.sites.set([]);
    } finally {
      this.loading.set(false);
    }
  }

  sparkPoints(trend: readonly number[]): string {
    if (trend.length === 0) return '';
    const max = Math.max(1, ...trend);
    const step = 120 / Math.max(1, trend.length - 1);
    return trend
      .map((v, i) => `${(i * step).toFixed(1)},${(32 - (v / max) * 28 - 2).toFixed(1)}`)
      .join(' ');
  }

  formatAgo(iso: string): string {
    const t = new Date(iso).getTime();
    if (Number.isNaN(t)) return iso;
    const diffMs = Date.now() - t;
    const days = Math.floor(diffMs / 86_400_000);
    if (days <= 0) return 'today';
    if (days === 1) return 'yesterday';
    if (days < 7) return `${days}d ago`;
    if (days < 30) return `${Math.floor(days / 7)}w ago`;
    return `${Math.floor(days / 30)}mo ago`;
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'sites-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
