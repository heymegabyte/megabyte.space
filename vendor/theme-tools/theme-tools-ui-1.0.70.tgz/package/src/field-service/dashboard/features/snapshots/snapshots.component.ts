import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * SnapshotsComponent — Worker version history + rollback.
 *
 * Lists `/api/admin/snapshots`. Clicking a row opens a side drawer with the
 * version metadata + a "Rollback to this version" button gated by the typed-
 * slug confirm dialog (`<bcl-confirm-dialog>`).
 *
 * The active version is marked with a `<bcl-status-pill state="paid">` (green
 * tone we already wire up for "all good") and disabled for rollback.
 */
import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  computed,
  inject,
  signal,
} from '@angular/core';
import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { type ColumnDef } from '@tanstack/angular-table';
import {
  HlmButton,
  HlmBadge,
  HlmDialog,
  HlmSkeleton,
  SmartTableComponent,
  ConfirmDialog,
  ToastService,
} from '../../shared/ui-spartan';

interface SnapshotRow extends Record<string, unknown> {
  readonly versionId: string;
  readonly number: number;
  readonly timestamp: string | null;
  readonly author: string;
  readonly message: string;
  readonly source: string;
  readonly status: 'active' | 'historical';
}

interface SnapshotsResp {
  readonly ok: boolean;
  readonly snapshots?: readonly SnapshotRow[];
  readonly activeVersionId?: string | null;
  readonly error?: string;
}

@Component({
  selector: 'app-snapshots',
  standalone: true,
  imports: [
    DatePipe,
    HlmButton,
    HlmBadge,
    HlmDialog,
    HlmSkeleton,
    SmartTableComponent,
    ConfirmDialog,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="mb-4 flex items-start justify-between gap-3">
      <div>
        <h1 class="text-2xl font-bold text-foreground">Worker snapshots</h1>
        <p class="text-sm text-muted-foreground">
          Every wrangler deploy lands as a new version. Roll back to any historical version in one click.
        </p>
      </div>
      <button hlmBtn variant="secondary" (click)="refresh()">Refresh</button>
    </header>

    @if (loadError(); as err) {
      <div
        class="mb-4 flex items-center justify-between gap-3 rounded-xl border border-destructive/40 bg-destructive/5 px-4 py-3"
        role="alert"
      >
        <p class="text-sm text-foreground">Couldn't load snapshots — {{ err }}</p>
        <button hlmBtn variant="outline" size="sm" (click)="refresh()">Try again</button>
      </div>
    }

    @if (loading()) {
      <div class="space-y-2" aria-busy="true" aria-label="Loading snapshots" data-testid="snapshots-loading">
        @for (row of [1, 2, 3, 4]; track row) {
          <div class="flex items-center gap-3 rounded-xl border border-border p-4">
            <div hlmSkeleton class="h-4 w-1/3"></div>
            <div hlmSkeleton class="h-3 w-24"></div>
          </div>
        }
      </div>
    } @else if (loadError()) {
      <!-- the error+retry box above is the content on a failed load; render nothing here so the
           "no version history" empty can never misread a FETCH FAILURE as "no history" (fire-127). -->
    } @else if (rows().length === 0) {
      <div class="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
        No snapshots returned — either Cloudflare credentials are unset or the worker has no version
        history yet.
      </div>
    } @else {
      <app-smart-table
        [data]="rowsArray()"
        [columns]="cols"
        [filterable]="true"
        filterPlaceholder="Filter by version, author, message…"
        emptyText="No snapshots match the filter."
        (rowActivate)="openRow($event)"
      />
    }

    <app-dialog [open]="selected() !== null" (openChange)="onDialogOpenChange($event)" ariaLabel="Snapshot detail">
      @if (selected(); as sel) {
        <h2 class="mb-4 text-lg font-semibold text-foreground">Snapshot detail</h2>
        <dl class="mb-4 grid grid-cols-3 gap-y-2 text-sm">
          <dt class="text-muted-foreground">Version</dt>
          <dd class="col-span-2 font-mono text-foreground">{{ sel.versionId }}</dd>
          <dt class="text-muted-foreground">Number</dt>
          <dd class="col-span-2 text-foreground">#{{ sel.number }}</dd>
          <dt class="text-muted-foreground">When</dt>
          <dd class="col-span-2 text-foreground">{{ sel.timestamp ? (sel.timestamp | date: 'medium') : '—' }}</dd>
          <dt class="text-muted-foreground">Author</dt>
          <dd class="col-span-2 text-foreground">{{ sel.author }}</dd>
          <dt class="text-muted-foreground">Source</dt>
          <dd class="col-span-2 text-foreground">{{ sel.source }}</dd>
          <dt class="text-muted-foreground">Status</dt>
          <dd class="col-span-2">
            <span hlmBadge [variant]="sel.status === 'active' ? 'success' : 'secondary'">{{
              sel.status === 'active' ? 'Active' : 'Historical'
            }}</span>
          </dd>
          <dt class="text-muted-foreground">Message</dt>
          <dd class="col-span-2 text-foreground">{{ sel.message || '—' }}</dd>
        </dl>
        <div class="flex justify-end gap-2">
          <button hlmBtn variant="ghost" (click)="closeRow()">Close</button>
          @if (sel.status !== 'active') {
            <button hlmBtn variant="destructive" (click)="askRollback()">Rollback to this version</button>
          }
        </div>
      }
    </app-dialog>

    @if (selected(); as sel) {
      <app-confirm-dialog
        [open]="confirming()"
        title="Roll back the worker?"
        [description]="
          'This sets the active deployment to ' +
          sel.versionId +
          '. The change is queued via the Cloudflare API and applies within seconds.'
        "
        confirmLabel="Roll back"
        [verifySlug]="'rollback ' + sel.number"
        (confirmed)="performRollback()"
        (cancelled)="confirming.set(false)"
      />
    }
  `,
})
export class SnapshotsComponent implements OnInit {
  private readonly http = inject(HttpClient);
  private readonly toast = inject(ToastService);

  readonly rows = signal<readonly SnapshotRow[]>([]);
  /** Mutable copy for SmartTable's data input. */
  readonly rowsArray = computed<SnapshotRow[]>(() => [...this.rows()]);
  readonly selected = signal<SnapshotRow | null>(null);
  readonly confirming = signal<boolean>(false);
  readonly loading = signal<boolean>(false);
  readonly loadError = signal<string | null>(null);

  readonly cols: ColumnDef<SnapshotRow>[] = [
    {
      accessorKey: 'timestamp',
      header: 'Time',
      cell: (info) => {
        const v = info.getValue<string | null>();
        return v ? new Date(v).toLocaleString() : '—';
      },
    },
    { accessorKey: 'number', header: '#', cell: (info) => `#${info.getValue<number>()}` },
    {
      accessorKey: 'versionId',
      header: 'Version ID',
      cell: (info) => info.getValue<string>().slice(0, 8) + '…',
    },
    { accessorKey: 'author', header: 'Author' },
    { accessorKey: 'message', header: 'Message' },
    {
      accessorKey: 'status',
      header: 'Status',
      cell: (info) => (info.getValue<string>() === 'active' ? 'Active' : 'Historical'),
    },
  ];

  ngOnInit(): void {
    void this.refresh();
  }

  onDialogOpenChange(open: boolean): void {
    if (!open) this.closeRow();
  }

  async refresh(): Promise<void> {
    this.loading.set(true);
    this.loadError.set(null);
    try {
      const r = await firstValueFrom(
        this.http.get<SnapshotsResp>('/api/admin/snapshots', { withCredentials: true }),
      );
      if (!r.ok) {
        this.loadError.set(r.error ?? 'Failed to load snapshots');
        this.rows.set([]);
      } else {
        this.rows.set(r.snapshots ?? []);
      }
    } catch (err) {
      this.loadError.set(`Failed to load snapshots: ${(err as Error).message}`);
      this.rows.set([]);
    } finally {
      this.loading.set(false);
    }
  }

  openRow(row: SnapshotRow): void {
    this.selected.set(row);
  }

  closeRow(): void {
    this.selected.set(null);
    this.confirming.set(false);
  }

  askRollback(): void {
    this.confirming.set(true);
  }

  async performRollback(): Promise<void> {
    const sel = this.selected();
    if (!sel) return;
    try {
      await firstValueFrom(
        this.http.post<{ ok: boolean; error?: string }>(
          '/api/admin/snapshots/rollback',
          { version_id: sel.versionId, message: `Rollback via dashboard to #${sel.number}` },
          { withCredentials: true },
        ),
      );
      this.confirming.set(false);
      this.selected.set(null);
      this.toast.success(`Rolled back to #${sel.number} · just now`);
      this.refresh();
    } catch (err) {
      const msg = (err as Error).message;
      this.loadError.set(`Rollback failed: ${msg}`);
      this.toast.error('Rollback failed — try again', undefined, msg);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'snapshots-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
