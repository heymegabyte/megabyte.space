import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * SqlComponent — direct D1 SQL console (super-admin only).
 *
 * READ-ONLY by default. A regex on the client blocks destructive keywords
 * (INSERT/UPDATE/DELETE/DROP/ALTER/TRUNCATE/CREATE/PRAGMA/ATTACH/DETACH/
 * REPLACE/REINDEX/VACUUM). To run a destructive query, the user flips the
 * `--write` toggle, which:
 *   1. shows the confirm dialog
 *   2. computes the SHA-256 confirmHash (first 12 hex)
 *   3. POSTs `mode:'write'` + `confirmHash` to the server
 * The server re-checks both gates so a malicious client can't bypass.
 *
 * Local-only state:
 *   - last 20 queries → localStorage `bcl_sql_history`
 *   - saved queries → POST `/api/admin/sql/saved` for cross-device sync
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  OnInit,
  computed,
  inject,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';
import { type ColumnDef } from '@tanstack/angular-table';
import {
  HlmButton,
  HlmSwitch,
  SmartTableComponent,
  ConfirmDialog,
  ToastService,
} from '../../shared/ui-spartan';
import { routeFade, reducedMotion } from '../../shared/animations';
import { AuthService } from '../../core/auth.service';

const DESTRUCTIVE_RE =
  /\b(insert|update|delete|drop|alter|truncate|create|pragma|attach|detach|replace|reindex|vacuum)\b/i;

const HISTORY_KEY = 'bcl_sql_history';
const HISTORY_CAP = 20;

interface ExecuteResp {
  readonly ok: boolean;
  readonly mode?: 'read' | 'write';
  readonly columns?: readonly string[];
  readonly rows?: readonly Record<string, unknown>[];
  readonly rowCount?: number;
  readonly rowsAffected?: number;
  readonly truncated?: boolean;
  readonly executionMs?: number;
  readonly error?: string;
  readonly code?: string;
  readonly confirmHash?: string;
}

interface SavedQuery extends Record<string, unknown> {
  readonly id: string;
  readonly user_id: string;
  readonly name: string;
  readonly query: string;
  readonly created_at: number;
}

async function sha256Hex(s: string): Promise<string> {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s));
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

@Component({
  selector: 'app-sql',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    HlmButton,
    HlmSwitch,
    SmartTableComponent,
    ConfirmDialog,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <header class="mb-4">
      <h1 class="text-2xl font-bold text-foreground">D1 SQL console</h1>
      <p class="text-sm text-muted-foreground">
        Read-only by default. Flip the write toggle and confirm to run mutations. Every query is
        audit-logged.
      </p>
    </header>

    <div class="grid grid-cols-12 gap-4">
      <section class="col-span-12 flex flex-col gap-3 lg:col-span-9">
        <label for="sql-editor" class="block text-xs font-medium text-muted-foreground">SQL</label>
        <textarea
          id="sql-editor"
          [formControl]="sqlCtrl"
          rows="8"
          spellcheck="false"
          autocorrect="off"
          autocapitalize="off"
          class="block w-full rounded-md border border-input bg-background px-3 py-2 font-mono text-sm text-foreground ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
          placeholder="SELECT id, action, created_at FROM audit_logs ORDER BY created_at DESC LIMIT 50"
          aria-label="SQL editor"
          (keydown)="onEditorKey($event)"
        ></textarea>

        <div class="flex flex-wrap items-center gap-3">
          <hlm-switch
            [(checked)]="writeMode"
            label="--write (destructive)"
            ariaLabel="Enable write-mode (destructive operations)"
          />
          <button hlmBtn (click)="run()" [disabled]="running() || !sqlCtrl.value.trim()">
            {{ running() ? 'Running…' : 'Run' }}
          </button>
          <button hlmBtn variant="secondary" (click)="askSave()">Save query</button>
          @if (lastDurationMs() !== null) {
            <span class="text-xs text-muted-foreground">
              {{ lastDurationMs() }} ms · {{ resultRowCount() }} rows
            </span>
          }
        </div>

        @if (error(); as err) {
          <p role="alert" class="rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive ring-1 ring-destructive/30">
            {{ err }}
          </p>
        }

        @if (clientBlock()) {
          <p role="alert" class="rounded-lg bg-amber-500/10 px-3 py-2 text-sm text-amber-300 ring-1 ring-amber-400/30">
            Destructive keyword detected. Flip --write to run.
          </p>
        }

        @if (resultColumns().length > 0) {
          <app-smart-table
            [data]="resultTableRows()"
            [columns]="resultTableCols()"
            [filterable]="true"
            [rowsActivatable]="false"
            filterPlaceholder="Filter result rows…"
            emptyText="Result set was empty."
          />
        } @else if (resultWriteAffected() !== null) {
          <p class="rounded-lg bg-emerald-500/10 px-3 py-2 text-sm text-emerald-300 ring-1 ring-emerald-400/30">
            ✓ Write succeeded — {{ resultWriteAffected() }} row(s) affected.
          </p>
        } @else if (lastDurationMs() === null) {
          <div class="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
            No query yet — write a SELECT above and hit Run. Cmd+Enter / Ctrl+Enter also runs.
          </div>
        }
      </section>

      <aside class="col-span-12 flex flex-col gap-4 lg:col-span-3">
        <section class="rounded-xl border border-border bg-card p-3" aria-labelledby="history-h">
          <h2 id="history-h" class="mb-2 text-sm font-semibold text-foreground">Recent (local)</h2>
          @if (history().length === 0) {
            <p class="text-xs text-muted-foreground">No history yet on this device.</p>
          } @else {
            <ul class="flex flex-col gap-1">
              @for (q of history(); track $index) {
                <li>
                  <button
                    type="button"
                    (click)="loadInto(q)"
                    class="block w-full truncate rounded px-2 py-1 text-left font-mono text-xs text-muted-foreground hover:bg-accent hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                    [title]="q"
                  >
                    {{ q }}
                  </button>
                </li>
              }
            </ul>
          }
        </section>

        <section class="rounded-xl border border-border bg-card p-3" aria-labelledby="saved-h">
          <h2 id="saved-h" class="mb-2 text-sm font-semibold text-foreground">Saved queries</h2>
          @if (saved().length === 0) {
            <p class="text-xs text-muted-foreground">Save a query to reuse it across devices.</p>
          } @else {
            <ul class="flex flex-col gap-1">
              @for (s of saved(); track s.id) {
                <li class="flex items-center gap-1">
                  <button
                    type="button"
                    (click)="loadInto(s.query)"
                    class="flex-1 truncate rounded px-2 py-1 text-left text-xs text-foreground hover:bg-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                    [title]="s.query"
                  >
                    {{ s.name }}
                  </button>
                  <button
                    type="button"
                    (click)="deleteSaved(s.id)"
                    class="rounded px-1 text-muted-foreground hover:text-destructive focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                    [attr.aria-label]="'Delete saved query ' + s.name"
                  >
                    ×
                  </button>
                </li>
              }
            </ul>
          }
        </section>
      </aside>
    </div>

    <app-confirm-dialog
      [open]="askingWrite()"
      title="Run destructive SQL?"
      description="This query mutates data. Type RUN to confirm. Action will be audit-logged with your user."
      confirmLabel="Execute write"
      [verifySlug]="'RUN'"
      (confirmed)="confirmRunWrite()"
      (cancelled)="askingWrite.set(false)"
    />

    <app-confirm-dialog
      [open]="savingDialog()"
      title="Save this query"
      description="Give your query a memorable name. Saved per-user; visible to other super-admins."
      confirmLabel="Save"
      [verifySlug]="null"
      (confirmed)="performSave()"
      (cancelled)="savingDialog.set(false)"
    />
  `,
})
export class SqlComponent implements OnInit {
  private readonly http = inject(HttpClient);
  private readonly auth = inject(AuthService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly toast = inject(ToastService);
  protected readonly reducedMotion = reducedMotion;

  readonly sqlCtrl = new FormControl<string>(
    'SELECT id, action, created_at FROM audit_logs ORDER BY created_at DESC LIMIT 20',
    { nonNullable: true },
  );
  readonly writeMode = signal<boolean>(false);
  readonly running = signal<boolean>(false);
  readonly askingWrite = signal<boolean>(false);
  readonly savingDialog = signal<boolean>(false);

  readonly resultColumns = signal<readonly string[]>([]);
  readonly resultRows = signal<readonly Record<string, unknown>[]>([]);
  readonly resultRowCount = signal<number>(0);
  readonly resultWriteAffected = signal<number | null>(null);
  readonly lastDurationMs = signal<number | null>(null);
  readonly error = signal<string | null>(null);

  readonly history = signal<readonly string[]>([]);
  readonly saved = signal<readonly SavedQuery[]>([]);

  readonly clientBlock = computed<boolean>(() => {
    const sql = this.sqlCtrl.value?.trim() ?? '';
    if (!sql) return false;
    return !this.writeMode() && DESTRUCTIVE_RE.test(sql);
  });

  readonly resultTableCols = computed<ColumnDef<Record<string, unknown>>[]>(() =>
    this.resultColumns().map((c) => ({
      accessorKey: c,
      header: c,
      cell: (info) => formatCell(info.getValue()),
    })),
  );
  readonly resultTableRows = computed<Record<string, unknown>[]>(() => [...this.resultRows()]);

  ngOnInit(): void {
    this.history.set(readHistory());
    void this.loadSaved();
  }

  async run(): Promise<void> {
    const sql = (this.sqlCtrl.value ?? '').trim();
    if (!sql) return;
    this.error.set(null);
    if (this.clientBlock()) {
      this.error.set('Destructive keyword detected — flip --write to opt in.');
      return;
    }
    if (this.writeMode() && DESTRUCTIVE_RE.test(sql)) {
      this.askingWrite.set(true);
      return;
    }
    await this.doRun('read');
  }

  async confirmRunWrite(): Promise<void> {
    this.askingWrite.set(false);
    await this.doRun('write');
  }

  private async doRun(mode: 'read' | 'write'): Promise<void> {
    const sql = (this.sqlCtrl.value ?? '').trim();
    this.running.set(true);
    this.resultColumns.set([]);
    this.resultRows.set([]);
    this.resultRowCount.set(0);
    this.resultWriteAffected.set(null);
    try {
      let confirmHash: string | undefined;
      if (mode === 'write') {
        confirmHash = (await sha256Hex(sql.replace(/;\s*$/, ''))).slice(0, 12);
      }
      const r = await firstValueFrom(
        this.http.post<ExecuteResp>(
          '/api/admin/sql/execute',
          { sql, mode, confirmHash },
          { withCredentials: true },
        ),
      );
      if (!r.ok) {
        this.error.set(r.error ?? 'Execution failed');
      } else {
        this.lastDurationMs.set(r.executionMs ?? 0);
        if (mode === 'read') {
          this.resultColumns.set(r.columns ?? []);
          this.resultRows.set(r.rows ?? []);
          this.resultRowCount.set(r.rowCount ?? 0);
        } else {
          this.resultWriteAffected.set(r.rowsAffected ?? 0);
        }
      }
      pushHistory(sql);
      this.history.set(readHistory());
    } catch (err) {
      this.error.set(`Run failed: ${(err as Error).message}`);
    } finally {
      this.running.set(false);
    }
  }

  loadInto(q: string): void {
    this.sqlCtrl.setValue(q);
  }

  onEditorKey(e: KeyboardEvent): void {
    const isRun = (e.metaKey || e.ctrlKey) && e.key === 'Enter';
    if (isRun) {
      e.preventDefault();
      void this.run();
    }
  }

  askSave(): void {
    this.savingDialog.set(true);
  }

  async performSave(): Promise<void> {
    const sql = (this.sqlCtrl.value ?? '').trim();
    if (!sql) return;
    const name = prompt('Save query as:') ?? '';
    if (!name) {
      this.savingDialog.set(false);
      return;
    }
    const userId = this.auth.whoami().userId ?? 'anon';
    try {
      await firstValueFrom(
        this.http.post<{ ok: boolean; id?: string }>(
          '/api/admin/sql/saved',
          { user_id: userId, name, query: sql },
          { withCredentials: true },
        ),
      );
      this.savingDialog.set(false);
      this.toast.success(`Saved query "${name}" · just now`);
      await this.loadSaved();
    } catch (err) {
      const msg = (err as Error).message;
      this.error.set(`Save failed: ${msg}`);
      this.toast.error('Save failed', undefined, msg);
      this.savingDialog.set(false);
    }
  }

  async deleteSaved(id: string): Promise<void> {
    // Optimistic delete — revert on failure.
    const prev = this.saved();
    this.saved.set(prev.filter((s) => s.id !== id));
    try {
      await firstValueFrom(
        this.http.delete(`/api/admin/sql/saved/${id}`, { withCredentials: true }),
      );
      this.toast.success('Saved query deleted');
    } catch (err) {
      const msg = (err as Error).message;
      this.saved.set(prev);
      this.error.set(`Delete failed: ${msg}`);
      this.toast.error('Delete failed — reverted', undefined, msg);
    }
  }

  private async loadSaved(): Promise<void> {
    const userId = this.auth.whoami().userId ?? '';
    try {
      const r = await firstValueFrom(
        this.http.get<{ ok: boolean; queries?: readonly SavedQuery[] }>(
          `/api/admin/sql/saved?user_id=${encodeURIComponent(userId)}`,
          { withCredentials: true },
        ),
      );
      this.saved.set(r.queries ?? []);
    } catch {
      this.saved.set([]);
    }
  }
}

function formatCell(v: unknown): string {
  if (v === null || v === undefined) return '';
  if (typeof v === 'object') {
    try {
      return JSON.stringify(v);
    } catch {
      return String(v);
    }
  }
  return String(v);
}

function readHistory(): readonly string[] {
  try {
    const raw = globalThis.localStorage?.getItem(HISTORY_KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw) as unknown;
    if (Array.isArray(arr))
      return arr.filter((x): x is string => typeof x === 'string').slice(0, HISTORY_CAP);
    return [];
  } catch {
    return [];
  }
}

function pushHistory(sql: string): void {
  try {
    const cur = readHistory().filter((q) => q !== sql);
    const next = [sql, ...cur].slice(0, HISTORY_CAP);
    globalThis.localStorage?.setItem(HISTORY_KEY, JSON.stringify(next));
  } catch {
    /* tolerate */
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'sql-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
