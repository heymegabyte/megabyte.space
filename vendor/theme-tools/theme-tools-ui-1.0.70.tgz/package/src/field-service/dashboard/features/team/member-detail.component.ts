import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * TeamMemberDetailComponent — role permissions + audit log for one member.
 *
 * Uses withComponentInputBinding so `:id` becomes a typed input.
 */
import { ChangeDetectionStrategy, Component, OnInit, inject, input, signal } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { HlmCardImports, HlmBadge, HlmButton, ConfirmDialog } from '../../shared/ui-spartan';
import { BclRoleBadgeComponent, BclRole } from '../_shared/role-badge.component';
import { TeamService, TeamMember, AuditEntry } from './team.service';

@Component({
  selector: 'app-team-member-detail',
  standalone: true,
  imports: [
    ...HlmCardImports,
    HlmBadge,
    HlmButton,
    BclRoleBadgeComponent,
    ConfirmDialog,
    ReactiveFormsModule,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (loading()) {
      <p class="text-sm text-muted-foreground">Loading…</p>
    } @else if (member(); as m) {
      <div class="grid gap-4 lg:grid-cols-3">
        <div hlmCard class="lg:col-span-1">
          <div hlmCardHeader><h3 hlmCardTitle>Profile</h3></div>
          <div hlmCardContent>
            <div class="flex items-center gap-3">
              @if (m.avatarUrl) {
                <img [src]="m.avatarUrl" [alt]="m.displayName" class="h-12 w-12 rounded-full ring-1 ring-border" />
              } @else {
                <div class="flex h-12 w-12 items-center justify-center rounded-full bg-muted text-sm font-semibold text-muted-foreground ring-1 ring-border">
                  {{ initials(m.displayName || m.email) }}
                </div>
              }
              <div class="min-w-0">
                <p class="truncate text-base font-semibold text-foreground">{{ m.displayName || m.email }}</p>
                <p class="truncate text-sm text-muted-foreground">{{ m.email }}</p>
              </div>
            </div>
            <dl class="mt-4 space-y-2 text-sm">
              <div class="flex items-center justify-between">
                <dt class="text-muted-foreground">Role</dt>
                <dd><bcl-role-badge [role]="m.role" /></dd>
              </div>
              <div class="flex items-center justify-between">
                <dt class="text-muted-foreground">Status</dt>
                <dd><span hlmBadge [variant]="m.status === 'active' ? 'success' : 'warning'">{{ m.status }}</span></dd>
              </div>
              <div class="flex items-center justify-between">
                <dt class="text-muted-foreground">Last active</dt>
                <dd class="text-foreground">{{ m.lastActiveAt ?? 'never' }}</dd>
              </div>
            </dl>
          </div>
        </div>
        <div hlmCard class="lg:col-span-2">
          <div hlmCardHeader>
            <h3 hlmCardTitle>Permissions</h3>
            <p hlmCardDescription>Change role applies account-wide</p>
          </div>
          <div hlmCardContent>
            <label class="block text-sm font-medium text-muted-foreground">Role</label>
            <select
              [formControl]="roleCtrl"
              class="mt-1 h-10 w-full max-w-xs rounded-md border border-input bg-background px-3 text-sm text-foreground ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            >
              <option value="owner">Owner</option>
              <option value="admin">Admin</option>
              <option value="member">Member</option>
              <option value="viewer">Viewer</option>
              <option value="customer">Customer</option>
              <option value="crew">Crew</option>
              <option value="super_admin">Super Admin</option>
            </select>
            <div class="mt-4 flex gap-2">
              <button hlmBtn [disabled]="saving() || roleCtrl.value === m.role" (click)="saveRole()">Save role</button>
              <button hlmBtn variant="destructive" (click)="askRemove()">Remove from team</button>
            </div>
            @if (error(); as e) {
              <p class="mt-3 text-sm text-destructive" role="alert">{{ e }}</p>
            }
          </div>
        </div>
      </div>
      <div hlmCard class="mt-4">
        <div hlmCardHeader>
          <h3 hlmCardTitle>Audit log</h3>
          <p hlmCardDescription>Last 50 actions</p>
        </div>
        <div hlmCardContent>
          <ul class="divide-y divide-border">
            @for (a of audit(); track a.id) {
              <li class="flex justify-between py-2 text-sm">
                <div class="min-w-0">
                  <p class="font-medium text-foreground">{{ a.action }}</p>
                  <p class="text-xs text-muted-foreground">{{ a.detail }}</p>
                </div>
                <p class="text-xs text-muted-foreground">{{ a.at }}</p>
              </li>
            } @empty {
              <li class="py-4 text-sm text-muted-foreground">No activity yet.</li>
            }
          </ul>
        </div>
      </div>
      <app-confirm-dialog
        [open]="confirmOpen()"
        title="Remove team member"
        description="They will lose all access immediately. Their audit history is retained."
        confirmLabel="Remove"
        verifySlug="REMOVE"
        (confirmed)="confirmRemove()"
        (cancelled)="confirmOpen.set(false)"
      />
    } @else if (error(); as e) {
      <p class="text-sm text-destructive">{{ e }}</p>
    }
  `,
})
export class TeamMemberDetailComponent implements OnInit {
  readonly id = input.required<string>();

  private readonly svc = inject(TeamService);
  private readonly router = inject(Router);

  readonly loading = signal<boolean>(true);
  readonly saving = signal<boolean>(false);
  readonly error = signal<string | null>(null);
  readonly member = signal<TeamMember | null>(null);
  readonly audit = signal<readonly AuditEntry[]>([]);
  readonly confirmOpen = signal<boolean>(false);
  readonly roleCtrl = new FormControl<BclRole>('member', { nonNullable: true });

  async ngOnInit(): Promise<void> {
    this.loading.set(true);
    const r = await this.svc.loadMember(this.id());
    if (r) {
      this.member.set(r.member);
      this.audit.set(r.audit);
      this.roleCtrl.setValue(r.member.role);
    }
    this.loading.set(false);
  }

  async saveRole(): Promise<void> {
    const m = this.member();
    if (!m) return;
    this.saving.set(true);
    this.error.set(null);
    try {
      await this.svc.updateRole(m.id, this.roleCtrl.value);
      this.member.set({ ...m, role: this.roleCtrl.value });
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : 'Failed');
    } finally {
      this.saving.set(false);
    }
  }

  askRemove(): void {
    this.confirmOpen.set(true);
  }

  async confirmRemove(): Promise<void> {
    const m = this.member();
    if (!m) return;
    try {
      await this.svc.remove(m.id);
      this.confirmOpen.set(false);
      void this.router.navigate(['/team']);
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : 'Failed');
    }
  }

  initials(s: string): string {
    return (
      s
        .split(/\s+/)
        .slice(0, 2)
        .map((p) => p[0]?.toUpperCase() ?? '')
        .join('') || '?'
    );
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'member-detail-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
