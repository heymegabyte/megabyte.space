import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * TeamComponent — section shell with header + nav tabs + outlet.
 */
import { ChangeDetectionStrategy, Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { HlmButton } from '../../shared/ui-spartan';
import { RovingTablistDirective } from '../_shared/roving-tablist.directive';
import { routeFade, reducedMotion } from '../../shared/animations';

@Component({
  selector: 'app-team',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, HlmButton, RovingTablistDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <header class="mb-4 flex items-start justify-between gap-3">
      <div>
        <h1 class="text-2xl font-bold text-foreground">Team</h1>
        <p class="text-sm text-muted-foreground">
          Members, roles, invites, and per-member audit history.
        </p>
      </div>
      <a hlmBtn routerLink="./invite">Invite member</a>
    </header>
    <nav
      class="mb-6 flex flex-wrap gap-1 border-b border-border"
      role="tablist"
      bclRovingTablist
      aria-label="Team sections"
    >
      <a
        #dirTab="routerLinkActive"
        [routerLink]="['.']"
        [routerLinkActiveOptions]="{ exact: true }"
        routerLinkActive="border-primary text-foreground"
        class="-mb-px border-b-2 border-transparent px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        role="tab"
        [attr.aria-selected]="dirTab.isActive"
        >Directory</a
      >
      <a
        #inviteTab="routerLinkActive"
        [routerLink]="['.', 'invite']"
        routerLinkActive="border-primary text-foreground"
        class="-mb-px border-b-2 border-transparent px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        role="tab"
        [attr.aria-selected]="inviteTab.isActive"
        >Invite</a
      >
    </nav>
    <router-outlet />
  `,
})
export class TeamComponent {
  protected readonly reducedMotion = reducedMotion;
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'team-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
