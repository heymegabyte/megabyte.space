import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { Route } from '@angular/router';

/**
 * Team surfaces — member directory, invite flow, per-member detail.
 */
export const TEAM_ROUTES: Route[] = [
  {
    path: '',
    loadComponent: () => import('./team.component').then((m) => m.TeamComponent),
    children: [
      {
        path: '',
        pathMatch: 'full',
        loadComponent: () => import('./directory.component').then((m) => m.TeamDirectoryComponent),
      },
      {
        path: 'invite',
        loadComponent: () => import('./invite.component').then((m) => m.TeamInviteComponent),
      },
      {
        path: ':id',
        loadComponent: () =>
          import('./member-detail.component').then((m) => m.TeamMemberDetailComponent),
      },
    ],
  },
];
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'team-routes',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
