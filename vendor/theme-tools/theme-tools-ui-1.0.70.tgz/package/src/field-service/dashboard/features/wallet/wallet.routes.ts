import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
/**
 * Wallet lazy routes (GP-09). /dashboard/wallet is gated by
 * featureFlagGuard('wallet_balance_menu') — dark by default, so the route
 * redirects to '/' until the flag is promoted from /dashboard. The
 * `validate-orphaned-flag-guards.mjs` build gate enforces the flag stays live.
 *
 * Open to every persona: the WalletComponent switches surface by role (crew →
 * cash out, customer → add money) from the role-aware /api/wallet/summary.
 */
import { Route } from '@angular/router';
import { featureFlagGuard } from '../../core/feature-flag-guard';

export const WALLET_ROUTES: Route[] = [
  {
    path: '',
    canActivate: [featureFlagGuard('wallet_balance_menu')],
    loadComponent: () => import('./wallet.component').then((m) => m.WalletComponent),
  },
];
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'wallet-routes',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
