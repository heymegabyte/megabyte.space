import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * MobileNavDrawerComponent — the phone/tablet (<md) surfacing of the gorgeous
 * sidebar nav. The desktop sidebar is `hidden md:flex`, so below md the primary
 * nav previously wasn't reachable at all (only Cmd+K). This slides the SAME
 * `<app-sidebar-nav>` in from the left in a branded sheet with a dimmed
 * backdrop — so mobile users get the identical icons + active-rail + grouping.
 *
 * Interaction contract: opens via `open()`/`toggle()` (driven by the topbar
 * hamburger), closes on backdrop click, Escape, or a nav link tap (navigation
 * dismisses it). Reduced-motion safe; focus moves into the panel on open and is
 * restored to the opener on close. strictTemplates-safe throughout.
 */
import { ChangeDetectionStrategy, Component, inject, input, signal } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { A11yModule } from '@angular/cdk/a11y';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { DestroyRef } from '@angular/core';
import { filter } from 'rxjs';
import { SidebarNavComponent } from './sidebar-nav.component';
import type { ShellNavItem } from '../ui-spartan/shell/app-shell.component';

@Component({
  selector: 'app-mobile-nav-drawer',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [SidebarNavComponent, A11yModule],
  host: {
    class: 'contents md:hidden',
    '(document:keydown.escape)': 'close()',
    '(window:bcl:toggle-mobile-nav)': 'onToggleEvent($event)',
  },
  template: `
    @if (isOpen()) {
      <div class="bcl-mnav fixed inset-0 z-50 md:hidden" role="dialog" aria-modal="true" aria-label="Navigation menu">
        <!-- backdrop -->
        <button
          type="button"
          class="bcl-mnav-scrim absolute inset-0 bg-black/60 backdrop-blur-sm"
          aria-label="Close navigation menu"
          data-testid="mobile-nav-backdrop"
          (click)="close()"
        ></button>
        <!-- panel -->
        <div
          #panel
          tabindex="-1"
          data-testid="mobile-nav-panel"
          cdkTrapFocus
          [cdkTrapFocusAutoCapture]="true"
          class="bcl-mnav-panel absolute inset-y-0 left-0 flex w-[82vw] max-w-[19rem] flex-col
                 border-r border-border bg-[hsl(var(--sidebar))] shadow-2xl outline-none"
        >
          <div class="flex h-14 shrink-0 items-center justify-between px-4">
            <span class="text-sm font-bold tracking-tight text-foreground">{{ appName() }}</span>
            <button
              type="button"
              class="grid h-9 w-9 place-items-center rounded-lg text-muted-foreground transition
                     hover:bg-accent hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
              aria-label="Close navigation menu"
              data-testid="mobile-nav-close"
              (click)="close()"
            >
              <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                <path d="M6 6l12 12M18 6 6 18" />
              </svg>
            </button>
          </div>
          <app-sidebar-nav [navItems]="navItems()" class="min-h-0 flex-1" />
        </div>
      </div>
    }
  `,
  styles: [
    `
      @supports (transition-behavior: allow-discrete) {
        .bcl-mnav-scrim {
          opacity: 1;
          transition: opacity 0.22s var(--bcl-ease-out, cubic-bezier(0.16, 1, 0.3, 1));
        }
        .bcl-mnav-panel {
          transform: translateX(0);
          transition: transform 0.28s var(--bcl-ease-out, cubic-bezier(0.16, 1, 0.3, 1));
        }
        @starting-style {
          .bcl-mnav-scrim {
            opacity: 0;
          }
          .bcl-mnav-panel {
            transform: translateX(-100%);
          }
        }
      }
      @media (prefers-reduced-motion: reduce) {
        .bcl-mnav-scrim,
        .bcl-mnav-panel {
          transition: none;
        }
      }
    `,
  ],
})
export class MobileNavDrawerComponent {
  readonly navItems = input<ShellNavItem[]>([]);
  readonly appName = input<string>('Brick Labor');

  protected readonly isOpen = signal(false);
  private readonly destroyRef = inject(DestroyRef);
  private opener: HTMLElement | null = null;

  constructor() {
    // Any completed navigation closes the drawer (a link tap dismisses it).
    inject(Router)
      .events.pipe(
        filter((e): e is NavigationEnd => e instanceof NavigationEnd),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe(() => this.isOpen.set(false));
    // Focus-into-open is handled by `cdkTrapFocus [cdkTrapFocusAutoCapture]` on the
    // panel (SCAN-63) — the shared CDK a11y kit captures focus INTO the drawer and
    // traps Tab/Shift+Tab, honoring aria-modal="true". `close()` restores focus to
    // the opener.
  }

  /** Window-event bridge from the shell's hamburger (decoupled — no shared
   *  import). The event `detail` carries the trigger element for focus return. */
  protected onToggleEvent(ev: Event): void {
    const trigger = (ev as CustomEvent).detail;
    this.toggle(trigger instanceof HTMLElement ? trigger : undefined);
  }

  /** Open the drawer, remembering the trigger so focus can be restored. */
  open(trigger?: HTMLElement): void {
    this.opener = trigger ?? (document.activeElement as HTMLElement | null);
    this.isOpen.set(true);
  }

  toggle(trigger?: HTMLElement): void {
    if (this.isOpen()) this.close();
    else this.open(trigger);
  }

  close(): void {
    if (!this.isOpen()) return;
    this.isOpen.set(false);
    // Restore focus to the opener (WCAG 2.4.3).
    const opener = this.opener;
    if (opener && typeof opener.focus === 'function') {
      queueMicrotask(() => opener.focus());
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'mobile-nav-drawer-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
