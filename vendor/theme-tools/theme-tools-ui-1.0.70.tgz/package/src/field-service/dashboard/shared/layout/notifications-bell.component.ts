import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * NotificationsBell — top-nav bell, backed by the CF-native notification engine.
 *
 * The bell polls `/api/dashboard/notifications` every 30s. That endpoint merges
 * the caller's persona-derived booking/gig items WITH the in-app rows the
 * homegrown notification engine (`notification-orchestration`) writes to the D1
 * `notification_inbox` table — where `services/notify.ts::notify()` now fans out
 * every workflow (the retirement of Novu cloud). One feed, one poll, one unread
 * badge; per-category filters, read/snooze/mark-all controls, and Web Push
 * enable. No external notification SDK, no third-party realtime socket, no
 * client-side app identifier — the inbox is entirely first-party D1.
 */
import {
  ChangeDetectionStrategy,
  Component,
  type ElementRef,
  OnDestroy,
  OnInit,
  computed,
  inject,
  signal,
  viewChild,
} from '@angular/core';
import { OverlayModule } from '@angular/cdk/overlay';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import {
  NOTIFICATION_CATEGORIES,
  DEFAULT_NOTIFICATION_PREFS,
  normalizeNotificationPrefs,
  isKindEnabled,
  toggleKind,
  applyCategoryPrefs,
  summarizeFilter,
  type NotificationKind,
  type NotificationPrefs,
} from '@theme.tools/notifications/field-service/notification-categories';
import { groupByDay, type NotificationItem } from '@theme.tools/notifications/field-service/notification-grouping';

export type { NotificationItem };

const POLL_MS = 30_000;

@Component({
  selector: 'app-notifications-bell',
  standalone: true,
  imports: [OverlayModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <button
      type="button"
      cdkOverlayOrigin
      #trigger="cdkOverlayOrigin"
      #triggerBtn
      (click)="open.update((v) => !v)"
      class="relative inline-flex items-center justify-center rounded-lg bg-bcl-bg-elev w-9 h-9 text-bcl-ink ring-1 ring-bcl-border hover:bg-white/5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
      [attr.aria-expanded]="open()"
      [attr.aria-label]="
        unread() > 0
          ? 'Notifications, ' + unread() + ' unread'
          : 'Notifications'
      "
    >
      <svg
        aria-hidden="true"
        focusable="false"
        width="18"
        height="18"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
      >
        <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
        <path d="M13.73 21a2 2 0 0 1-3.46 0" />
      </svg>
      @if (unread() > 0) {
        <span
          aria-hidden="true"
          class="absolute -top-1 -right-1 inline-flex min-w-[18px] h-[18px] items-center justify-center rounded-full bg-bcl-accent px-1 font-mono text-[10px] font-bold text-bcl-bg ring-2 ring-bcl-bg"
        >
          {{ unread() > 99 ? '99+' : unread() }}
        </span>
      }
    </button>

    <ng-template
      cdkConnectedOverlay
      [cdkConnectedOverlayOrigin]="trigger"
      [cdkConnectedOverlayOpen]="open()"
      [cdkConnectedOverlayHasBackdrop]="true"
      cdkConnectedOverlayBackdropClass="bg-transparent"
      [cdkConnectedOverlayPositions]="[
        { originX: 'end', originY: 'bottom', overlayX: 'end', overlayY: 'top', offsetY: 8 }
      ]"
      (backdropClick)="open.set(false)"
      (overlayKeydown)="onOverlayKeydown($event)"
    >
      <!--
        SCAN-55 · This dropdown is a NON-MODAL popover, not a dialog. The CDK
        cdkConnectedOverlay closes on backdrop (outside) click, traps no focus,
        and leaves the page behind interactive — so role="dialog"/aria-modal
        (a modal focus-trap contract) is wrong AND axe flags dialog on <aside>
        (aria-allowed-role). The correct role for a labelled non-modal
        notification popover is a region landmark, keeping the aria-label.
      -->
      <aside
        role="region"
        aria-label="Notifications"
        data-testid="bell-panel"
        class="w-[380px] max-w-[92vw] max-h-[70vh] overflow-hidden rounded-xl bg-bcl-bg-elev ring-1 ring-bcl-border shadow-2xl flex flex-col"
      >
        <header class="flex items-center justify-between border-b border-bcl-border px-4 py-3">
          <h2 class="text-sm font-semibold text-bcl-ink">Notifications</h2>
          <div class="flex items-center gap-2">
            @if (!pushEnabled() && pushSupported()) {
              <button
                type="button"
                (click)="enablePush()"
                class="text-xs text-bcl-accent hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
                aria-label="Enable push notifications"
              >
                Enable push
              </button>
            }
            <button
              type="button"
              (click)="prefsOpen.update((v) => !v)"
              class="text-xs transition-colors duration-[333ms] hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
              [class.text-bcl-accent]="prefsOpen()"
              [class.text-bcl-ink-muted]="!prefsOpen()"
              [attr.aria-expanded]="prefsOpen()"
              aria-label="Notification category filters"
            >
              Filter
            </button>
            <button
              type="button"
              (click)="markAllRead()"
              [disabled]="unread() === 0"
              class="text-xs text-bcl-ink-muted hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent disabled:opacity-40"
            >
              Mark all read
            </button>
          </div>
        </header>

        @if (prefsOpen()) {
          <section
            class="border-b border-bcl-border bg-bcl-bg/30 px-4 py-3"
            aria-label="Notification categories"
          >
            <p class="mb-2 font-mono text-[10px] uppercase tracking-wide text-bcl-ink-muted">
              Show categories
            </p>
            <ul class="flex flex-wrap gap-2" role="list">
              @for (cat of categories; track cat.kind) {
                <li>
                  <button
                    type="button"
                    role="switch"
                    [attr.aria-checked]="categoryEnabled(cat.kind)"
                    [attr.aria-label]="cat.label + ': ' + cat.description"
                    (click)="toggleCategory(cat.kind)"
                    class="rounded-full px-3 py-1 text-xs font-medium ring-1 transition-all duration-[333ms] hover:-translate-y-0.5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
                    [class.bg-bcl-accent]="categoryEnabled(cat.kind)"
                    [class.text-bcl-bg]="categoryEnabled(cat.kind)"
                    [class.ring-bcl-accent]="categoryEnabled(cat.kind)"
                    [class.bg-transparent]="!categoryEnabled(cat.kind)"
                    [class.text-bcl-ink-muted]="!categoryEnabled(cat.kind)"
                    [class.ring-bcl-border]="!categoryEnabled(cat.kind)"
                  >
                    {{ cat.label }}
                  </button>
                </li>
              }
            </ul>

            <!--
              SCAN-54 · WCAG 4.1.3 Status Messages (AA). Toggling a category chip
              re-filters the feed but sighted-only — a screen-reader user hears
              nothing. This polite live region announces the filtered result
              summary (count + "filtered to N of M categories") WITHOUT moving
              focus. Driven by the filterSummary() computed off the SHARED
              summarizeFilter() helper (same wording as the notification-center,
              SCAN-23), so it re-announces only when the derived summary actually
              changes. Visible AND SR (a subtle status line doubles as sighted
              feedback).
            -->
            <p
              role="status"
              aria-live="polite"
              aria-atomic="true"
              data-testid="bell-filter-status"
              class="mt-2 font-mono text-[10px] uppercase tracking-wide text-bcl-ink-muted"
            >
              {{ filterSummary() }}
            </p>
          </section>
        }

        <ol class="flex-1 overflow-y-auto divide-y divide-bcl-border">
          @if (groupedItems().length === 0) {
            <li class="px-4 py-10 text-center text-sm text-bcl-ink-muted">
              You're all caught up.
            </li>
          } @else {
            @for (group of groupedItems(); track group.label) {
              <li class="bg-bcl-bg/30 px-4 py-2 font-mono text-[10px] uppercase tracking-wide text-bcl-ink-muted">
                {{ group.label }}
              </li>
              @for (n of group.items; track n.id) {
                <li
                  class="px-4 py-3 hover:bg-white/5"
                  [class.bg-bcl-accent\/5]="!n.read"
                >
                  <button
                    type="button"
                    (click)="activate(n)"
                    class="flex w-full items-start gap-3 rounded-md text-left focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
                  >
                    <span
                      aria-hidden="true"
                      class="mt-1 inline-block size-2 rounded-full"
                      [class.bg-bcl-accent]="!n.read"
                      [class.bg-bcl-ink-muted]="n.read"
                    ></span>
                    <span class="flex-1 min-w-0">
                      <span class="block text-sm font-medium text-bcl-ink truncate">{{ n.title }}</span>
                      @if (n.subtitle) {
                        <span class="block text-xs text-bcl-ink-muted truncate">{{ n.subtitle }}</span>
                      }
                      <span class="block text-[10px] font-mono uppercase text-bcl-ink-muted mt-0.5">{{ n.kind }}</span>
                    </span>
                  </button>
                  <div class="mt-2 flex items-center gap-3 pl-5 text-[11px]">
                    @if (!n.read) {
                      <button type="button" (click)="markRead(n)" class="text-bcl-ink-muted hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent">
                        Mark read
                      </button>
                    }
                    <button type="button" (click)="snooze(n)" class="text-bcl-ink-muted hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent">
                      Snooze 1h
                    </button>
                  </div>
                </li>
              }
            }
          }
        </ol>

        <footer class="border-t border-bcl-border px-4 py-2.5 text-center">
          <button
            type="button"
            (click)="viewAll()"
            class="text-xs font-medium text-bcl-accent transition-colors duration-[333ms] hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
          >
            View all notifications
          </button>
        </footer>
      </aside>
    </ng-template>
  `,
})
export class NotificationsBellComponent implements OnInit, OnDestroy {
  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);

  readonly open = signal<boolean>(false);
  /** The bell trigger button — focus returns here when the popover closes via keyboard. */
  private readonly triggerBtn = viewChild<ElementRef<HTMLButtonElement>>('triggerBtn');
  readonly items = signal<readonly NotificationItem[]>([]);
  readonly pushEnabled = signal<boolean>(false);
  readonly pushSupported = signal<boolean>(false);

  /** Whether the per-category preferences panel is expanded inside the dropdown. */
  readonly prefsOpen = signal<boolean>(false);
  /** The caller's muted-category set, loaded from `/api/dashboard/notifications/prefs`. */
  readonly prefs = signal<NotificationPrefs>(DEFAULT_NOTIFICATION_PREFS);
  /** Catalog for the toggle chips — exposed to the template. */
  readonly categories = NOTIFICATION_CATEGORIES;

  /** Items in still-visible categories (muted categories dropped). */
  readonly visibleItems = computed(() => applyCategoryPrefs(this.items(), this.prefs()));
  readonly unread = computed(() => this.visibleItems().filter((i) => !i.read).length);
  readonly groupedItems = computed(() => groupByDay(this.visibleItems()));

  /**
   * SCAN-54 · The polite-live-region text for the bell's category filter — the
   * SIBLING of the SCAN-23 notification-center region, sharing the same
   * `summarizeFilter()` helper (one source of truth). Announces the filtered result
   * summary (visible count + "filtered to N of M categories") whenever a category
   * chip toggles. The bell has no search/tabs, so no query/archived context. A
   * `computed`, so it re-announces ONLY when the derived string changes. WCAG 4.1.3.
   */
  readonly filterSummary = computed<string>(() =>
    summarizeFilter(this.categories, this.prefs(), this.visibleItems().length),
  );

  private pollTimer: ReturnType<typeof setInterval> | undefined;
  private lastSeen: string | null = null;

  ngOnInit(): void {
    this.detectPushSupport();
    void this.loadPrefs();
    void this.refresh();
    this.pollTimer = setInterval(() => void this.refresh(), POLL_MS);
  }

  ngOnDestroy(): void {
    if (this.pollTimer) clearInterval(this.pollTimer);
  }

  async refresh(): Promise<void> {
    try {
      const url = this.lastSeen
        ? `/api/dashboard/notifications?since=${encodeURIComponent(this.lastSeen)}`
        : '/api/dashboard/notifications';
      const resp = await firstValueFrom(
        this.http.get<{ ok: boolean; items: NotificationItem[] }>(url, { withCredentials: true }),
      );
      if (resp?.items) {
        // Merge by id, newest items win.
        const map = new Map<string, NotificationItem>();
        for (const old of this.items()) map.set(old.id, old);
        for (const fresh of resp.items) map.set(fresh.id, fresh);
        const merged = [...map.values()].sort((a, b) => Date.parse(b.at) - Date.parse(a.at));
        this.items.set(merged.slice(0, 50));
        this.lastSeen = new Date().toISOString();
      }
    } catch {
      // Silent — leave existing items in place.
    }
  }

  activate(n: NotificationItem): void {
    this.markRead(n);
    if (n.href) {
      this.open.set(false);
      void this.router.navigateByUrl(n.href);
    }
  }

  markRead(n: NotificationItem): void {
    this.items.update((list) => list.map((i) => (i.id === n.id ? { ...i, read: true } : i)));
    void firstValueFrom(
      this.http.post(
        '/api/dashboard/notifications/' + encodeURIComponent(n.id) + '/read',
        {},
        { withCredentials: true },
      ),
    ).catch(() => undefined);
  }

  snooze(n: NotificationItem): void {
    this.items.update((list) => list.filter((i) => i.id !== n.id));
    void firstValueFrom(
      this.http.post(
        '/api/dashboard/notifications/' + encodeURIComponent(n.id) + '/snooze',
        { minutes: 60 },
        { withCredentials: true },
      ),
    ).catch(() => undefined);
  }

  markAllRead(): void {
    this.items.update((list) => list.map((i) => ({ ...i, read: true })));
    void firstValueFrom(
      this.http.post('/api/dashboard/notifications/read-all', {}, { withCredentials: true }),
    ).catch(() => undefined);
  }

  /** Close the dropdown and open the full-history notification center. */
  viewAll(): void {
    this.open.set(false);
    void this.router.navigateByUrl('/notifications');
  }

  /**
   * SCAN-55 · Escape dismisses the non-modal popover (WCAG APG keyboard
   * expectation for a dismissible overlay) and returns focus to the bell
   * trigger so keyboard users aren't stranded. The overlay traps no focus, so
   * this is the only keyboard-close path we need; outside-click still closes via
   * the backdrop.
   */
  onOverlayKeydown(event: KeyboardEvent): void {
    if (event.key === 'Escape' && this.open()) {
      event.preventDefault();
      this.open.set(false);
      this.triggerBtn()?.nativeElement.focus();
    }
  }

  /** Whether a category is currently shown (not muted). */
  categoryEnabled(kind: NotificationKind): boolean {
    return isKindEnabled(this.prefs(), kind);
  }

  /**
   * Flip a category on/off — optimistic local update, then persist to the bell's
   * `/prefs` endpoint. A failed write leaves the optimistic state (the next load
   * reconciles); the feed re-filters instantly via the `visibleItems` computed.
   */
  toggleCategory(kind: NotificationKind): void {
    const next = toggleKind(this.prefs(), kind);
    this.prefs.set(next);
    void firstValueFrom(
      this.http.put('/api/dashboard/notifications/prefs', next, { withCredentials: true }),
    ).catch(() => undefined);
  }

  /**
   * Load the caller's muted-category preferences. Best-effort: a failure leaves
   * the neutral default (nothing muted) so the feed shows everything.
   */
  private async loadPrefs(): Promise<void> {
    try {
      const resp = await firstValueFrom(
        this.http.get<{ ok: boolean; mutedKinds?: unknown }>(
          '/api/dashboard/notifications/prefs',
          { withCredentials: true },
        ),
      );
      this.prefs.set(normalizeNotificationPrefs(resp));
    } catch {
      this.prefs.set(DEFAULT_NOTIFICATION_PREFS);
    }
  }

  async enablePush(): Promise<void> {
    if (!this.pushSupported()) return;
    try {
      const reg = await navigator.serviceWorker.ready;
      const vapidResp = await firstValueFrom(
        this.http.get<{ key: string }>('/api/push/vapid-public', { withCredentials: true }),
      );
      const key = vapidResp?.key;
      if (!key) return;
      const sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        // Cast to BufferSource — Uint8Array<ArrayBufferLike> doesn't satisfy
        // the strict ArrayBuffer requirement on older lib.dom typings.
        applicationServerKey: urlBase64ToUint8Array(key) as unknown as BufferSource,
      });
      await firstValueFrom(
        this.http.post('/api/push/register', sub.toJSON(), { withCredentials: true }),
      );
      this.pushEnabled.set(true);
    } catch {
      this.pushEnabled.set(false);
    }
  }

  private detectPushSupport(): void {
    const supported =
      typeof navigator !== 'undefined' &&
      'serviceWorker' in navigator &&
      'PushManager' in (globalThis as { PushManager?: unknown });
    this.pushSupported.set(supported);
    if (supported && Notification?.permission === 'granted') {
      this.pushEnabled.set(true);
    }
  }
}

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const raw = atob(base64);
  const output = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) output[i] = raw.charCodeAt(i);
  return output;
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'notifications-bell-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
