import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * RoleSwitcherComponent — the navbar persona switcher.
 *
 * Renders ONLY for a multi-role identity (super-admin holds all three; a genuine
 * dual customer+crew holds two) — a plain single-role user sees nothing
 * (`role.canSwitchRole()`). Selecting a persona drives `RoleService.switchRole`,
 * which flips the server-authoritative view-as AND routes to that persona's
 * dashboard home, so the whole dashboard visibly becomes that role's view.
 *
 * Brand-orange, OnPush + signals, CDK-overlay dropdown with the shared roving
 * menu a11y kit (Esc/Tab close + focus-restore, arrow-key roving, aria-checked
 * on the active persona) — matches AccountMenuComponent so the topbar controls
 * feel like one system. Brian req 2026-09-29.
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  ElementRef,
  computed,
  inject,
  signal,
  viewChild,
} from '@angular/core';
import { OverlayModule } from '@angular/cdk/overlay';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import type { DashboardRole } from '../../core/auth.service';
import { RoleService } from '../../core/role.service';
import { RovingMenuDirective } from '../../features/_shared/roving-menu.directive';

/** Human labels for each persona, in the switcher's display order. */
const ROLE_LABELS: ReadonlyArray<{ role: DashboardRole; label: string; hint: string }> = [
  { role: 'customer', label: 'Customer', hint: 'Bookings, quotes & your account' },
  { role: 'crew', label: 'Crew', hint: 'Jobs board & earnings' },
  { role: 'super_admin', label: 'Super admin', hint: 'Operations, dispatch & dev tools' },
];

@Component({
  selector: 'app-role-switcher',
  standalone: true,
  imports: [OverlayModule, RovingMenuDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (role.canSwitchRole()) {
      <button
        #triggerBtn
        type="button"
        cdkOverlayOrigin
        #trigger="cdkOverlayOrigin"
        (click)="open.update((v) => !v)"
        class="inline-flex items-center gap-2 rounded-full border border-bcl-accent/40 bg-bcl-accent/10 px-3 py-1.5 text-xs font-semibold text-bcl-accent transition max-[399px]:gap-1 max-[399px]:px-2
               hover:bg-bcl-accent/20 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-bcl-accent"
        [attr.aria-expanded]="open()"
        aria-haspopup="menu"
        [attr.aria-label]="'Switch role view. Currently viewing as ' + activeLabel()"
        data-testid="role-switcher"
      >
        <span
          class="inline-block size-1.5 shrink-0 rounded-full bg-bcl-accent"
          aria-hidden="true"
        ></span>
        <span class="font-mono uppercase tracking-wider text-[10px] text-bcl-ink-muted max-[399px]:hidden"
          >Viewing as</span
        >
        <span class="min-w-[5.5rem] text-left max-[399px]:hidden">{{ activeLabel() }}</span>
        <svg
          viewBox="0 0 24 24"
          width="14"
          height="14"
          fill="none"
          stroke="currentColor"
          stroke-width="2.5"
          stroke-linecap="round"
          stroke-linejoin="round"
          aria-hidden="true"
          class="shrink-0 opacity-70"
        >
          <path d="m6 9 6 6 6-6" />
        </svg>
      </button>

      <ng-template
        cdkConnectedOverlay
        [cdkConnectedOverlayOrigin]="trigger"
        [cdkConnectedOverlayOpen]="open()"
        [cdkConnectedOverlayHasBackdrop]="true"
        cdkConnectedOverlayBackdropClass="bg-transparent"
        [cdkConnectedOverlayPositions]="[
          { originX: 'end', originY: 'bottom', overlayX: 'end', overlayY: 'top', offsetY: 8 },
        ]"
        (backdropClick)="open.set(false)"
      >
        <ul
          role="menu"
          bclRovingMenu
          (dismiss)="onDismiss()"
          aria-label="Switch role view"
          class="mt-1 min-w-72 rounded-xl bg-bcl-bg-elev p-1 ring-1 ring-bcl-border shadow-2xl"
        >
          <li
            class="px-3 py-2 border-b border-bcl-border mb-1 font-mono text-[10px] uppercase tracking-wide text-bcl-ink-muted"
          >
            View the dashboard as
          </li>
          @for (opt of options(); track opt.role) {
            <li>
              <button
                role="menuitemradio"
                type="button"
                [attr.aria-checked]="opt.role === role.viewAs()"
                [disabled]="role.viewAsPending()"
                (click)="select(opt.role)"
                [attr.data-testid]="'role-option-' + opt.role"
                class="flex w-full items-start justify-between gap-3 rounded-lg px-3 py-2 text-left hover:bg-white/5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent disabled:opacity-50"
                [class.bg-bcl-accent]="opt.role === role.viewAs()"
                [class.text-black]="opt.role === role.viewAs()"
              >
                <span class="min-w-0">
                  <span class="block text-sm font-semibold">{{ opt.label }}</span>
                  <span
                    class="block text-xs"
                    [class.text-black]="opt.role === role.viewAs()"
                    [class.text-bcl-ink-muted]="opt.role !== role.viewAs()"
                    >{{ opt.hint }}</span
                  >
                </span>
                @if (opt.role === role.viewAs()) {
                  <svg
                    viewBox="0 0 24 24"
                    width="18"
                    height="18"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="3"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    aria-hidden="true"
                    class="mt-0.5 shrink-0"
                  >
                    <path d="M20 6 9 17l-5-5" />
                  </svg>
                }
              </button>
            </li>
          }
        </ul>
      </ng-template>
    }
  `,
})
export class RoleSwitcherComponent {
  protected readonly role = inject(RoleService);
  private readonly destroyRef = inject(DestroyRef);

  readonly open = signal(false);

  /** The trigger — focus returns here when the menu is dismissed by keyboard. */
  private readonly triggerBtn = viewChild<ElementRef<HTMLButtonElement>>('triggerBtn');

  /** The persona options this identity can actually switch to, in display order. */
  protected readonly options = computed(() => {
    const available = this.role.availableRoles();
    return ROLE_LABELS.filter((o) => available.includes(o.role));
  });

  /** Label of the currently-active (view-as) persona for the trigger. */
  protected readonly activeLabel = computed(() => {
    const active = this.role.viewAs();
    return ROLE_LABELS.find((o) => o.role === active)?.label ?? 'Customer';
  });

  protected onDismiss(): void {
    this.open.set(false);
    this.triggerBtn()?.nativeElement.focus();
  }

  /** Flip to a persona (view-as POST + route to its home), then close the menu. */
  protected select(role: DashboardRole): void {
    if (role === this.role.viewAs()) {
      this.open.set(false);
      return;
    }
    this.open.set(false);
    this.role
      .switchRole(role)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({ error: () => undefined });
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'role-switcher-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
