import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
/**
 * WalletButtonComponent — GP-09 top-of-sidebar wallet button (flag:
 * wallet_balance_menu). A ~50px-tall, full-sidebar-width, brand-orange
 * gradient button showing the signed-in user's balance + one useful stat,
 * linking to /dashboard/wallet.
 *
 * Gorgeous + accessible: an orange gradient face, animated hover (lift + glow),
 * active (press-down), and a focus-visible ring — all `motion-reduce:` safe.
 * Self-gates on the flag (returns null when off) AND on a resolvable wallet
 * (hidden while unauthorized / unavailable) so it never renders an empty shell.
 *
 * BUG-03 (2026-09-29): this button is globally mounted in app.ts, so it renders
 * on the UNAUTHENTICATED /dashboard shell too. The FETCH is therefore gated — not
 * just the render — on (authenticated AND wallet flag ON) so it is SKIPPED
 * entirely pre-auth / flag-dark; otherwise `GET /api/wallet/summary` 404s (flag
 * off) / 401s (no session) and logs a first-party console error on the public
 * shell. Never fetch-then-404. An effect() fires the fetch exactly once, the
 * moment both conditions first hold (whoami hydrates + flags arrive async).
 *
 * strictTemplates-safe throughout (every nullable is read as `stats().x` off a
 * pure, always-defined derivation).
 */
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  effect,
  inject,
  signal,
} from '@angular/core';
import { RouterLink } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { DestroyRef } from '@angular/core';
import { AuthService } from '../../core/auth.service';
import { FeatureFlagService } from '../../core/feature-flag.service';
import {
  WalletService,
  walletButtonStats,
  type Wallet,
} from '../../core/wallet.service';

@Component({
  selector: 'app-wallet-button',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink],
  host: { class: 'block px-3 pt-3' },
  template: `
    @if (flags.isOn('wallet_balance_menu')() && wallet(); as w) {
      <a
        routerLink="/wallet"
        data-testid="wallet-button"
        [attr.aria-label]="'Wallet — ' + stats().headline + ' ' + stats().label"
        class="group relative flex h-[50px] w-full items-center gap-3 overflow-hidden rounded-xl px-3.5
               text-left text-white shadow-[0_2px_10px_-2px_rgba(255,107,26,0.55)]
               ring-1 ring-white/10 transition
               duration-200 ease-out
               hover:-translate-y-0.5 hover:shadow-[0_8px_22px_-4px_rgba(255,107,26,0.7)] hover:ring-white/25
               active:translate-y-0 active:shadow-[0_2px_8px_-2px_rgba(255,107,26,0.6)]
               focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-[hsl(var(--sidebar))]
               motion-reduce:transition-none motion-reduce:hover:translate-y-0
               bg-[linear-gradient(120deg,var(--bcl-accent),var(--bcl-accent-2))]"
      >
        <!-- animated sheen sweep on hover (transform/opacity only; reduced-motion safe) -->
        <span
          aria-hidden="true"
          class="pointer-events-none absolute inset-0 -translate-x-full bg-[linear-gradient(105deg,transparent,rgba(255,255,255,0.35),transparent)]
                 transition-transform duration-700 ease-out group-hover:translate-x-full
                 motion-reduce:hidden"
        ></span>
        <span
          aria-hidden="true"
          class="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-white/15 text-base ring-1 ring-white/20"
          >💰</span
        >
        <span class="min-w-0 flex-1 leading-tight">
          <span class="block truncate text-[15px] font-bold tabular-nums" data-testid="wallet-headline">{{
            stats().headline
          }}</span>
          <span class="block truncate text-[11px] font-medium text-white/80">{{ stats().sub }}</span>
        </span>
        <span
          aria-hidden="true"
          class="shrink-0 text-white/70 transition-transform duration-200 group-hover:translate-x-0.5 motion-reduce:transition-none"
          >→</span
        >
      </a>
    }
  `,
})
export class WalletButtonComponent {
  protected readonly flags = inject(FeatureFlagService);
  private readonly auth = inject(AuthService);
  private readonly svc = inject(WalletService);
  private readonly destroyRef = inject(DestroyRef);

  protected readonly wallet = signal<Wallet | null>(null);
  /** Pure, always-defined derivation → strictTemplates never dereferences null. */
  protected readonly stats = computed(() => walletButtonStats(this.wallet()));

  /** Guards against a second fetch if the gate flips true again after the first. */
  private fetched = false;

  constructor() {
    // BUG-03: gate the FETCH on (authenticated AND wallet flag ON) — both hydrate
    // asynchronously (whoami app-initializer + the 60s flag poll). This effect
    // fires the fetch exactly once, the moment both first hold; on the
    // unauthenticated shell OR when the flag is dark the fetch is SKIPPED
    // entirely, so `GET /api/wallet/summary` never 404s/401s on the public shell.
    // The template's flag+wallet render-gate still hides the button until data.
    effect(() => {
      const gated = this.auth.authenticated() && this.flags.isOn('wallet_balance_menu')();
      if (!gated || this.fetched) return;
      this.fetched = true;
      this.svc
        .summary$()
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe((r) => {
          if (r.ok && r.wallet) this.wallet.set(r.wallet);
        });
    });
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'wallet-button-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
