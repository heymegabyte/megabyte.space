import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * ConfirmDialog — destructive-action confirmation, the Spartan replacement for
 * the deprecated bcl-confirm-dialog. Wraps HlmDialog (CDK focus-trap + Esc +
 * backdrop) and keeps the same API (open/title/description/confirmLabel/
 * verifySlug + confirmed/cancelled) so the ~6 consumers migrate by swapping the
 * import + selector. When verifySlug is set, the confirm button stays disabled
 * until the operator types the slug exactly (case-insensitive).
 *
 * Usage:
 *   <app-confirm-dialog [open]="open()" title="Remove card"
 *      description="This can't be undone." confirmLabel="Remove"
 *      (confirmed)="remove()" (cancelled)="open.set(false)" />
 */
import { ChangeDetectionStrategy, Component, computed, input, output, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { HlmDialog } from './hlm-dialog.component';
import { HlmButton } from '../button/hlm-button';
import { HlmInput } from '../input/hlm-input';

@Component({
  selector: 'app-confirm-dialog',
  standalone: true,
  imports: [HlmDialog, HlmButton, HlmInput, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <app-dialog [open]="open()" (openChange)="onOpenChange($event)" [ariaLabel]="title()">
      <h2 class="mb-2 text-lg font-semibold text-foreground" data-testid="confirm-title">{{ title() }}</h2>
      <p class="mb-4 text-sm text-muted-foreground">{{ description() }}</p>
      @if (verifySlug(); as slug) {
        <label class="mb-1 block text-xs font-medium text-muted-foreground">
          Type <span class="font-mono text-foreground">{{ slug }}</span> to confirm
        </label>
        <input
          hlmInput
          type="text"
          [formControl]="verifyCtrl"
          class="mb-4"
          autocomplete="off"
          spellcheck="false"
          [attr.aria-label]="'Type ' + slug + ' to confirm'"
        />
      }
      <div class="flex justify-end gap-2">
        <button hlmBtn variant="ghost" (click)="cancelled.emit()" data-testid="confirm-cancel">Cancel</button>
        <button
          hlmBtn
          variant="destructive"
          [disabled]="!canConfirm()"
          (click)="confirmed.emit()"
          data-testid="confirm-ok"
        >
          {{ confirmLabel() }}
        </button>
      </div>
    </app-dialog>
  `,
})
export class ConfirmDialog {
  readonly open = input.required<boolean>();
  readonly title = input.required<string>();
  readonly description = input.required<string>();
  readonly confirmLabel = input<string>('Delete');
  readonly verifySlug = input<string | null>(null);

  readonly confirmed = output<void>();
  readonly cancelled = output<void>();

  readonly verifyCtrl = new FormControl<string>('', { nonNullable: true });
  readonly typed = signal<string>('');

  readonly canConfirm = computed<boolean>(() => {
    const slug = this.verifySlug();
    if (!slug) return true;
    return this.typed().trim().toLowerCase() === slug.toLowerCase();
  });

  constructor() {
    this.verifyCtrl.valueChanges
      .pipe(takeUntilDestroyed())
      .subscribe((v) => this.typed.set(v ?? ''));
  }

  protected onOpenChange(open: boolean): void {
    if (!open) this.cancelled.emit();
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'confirm-dialog-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
