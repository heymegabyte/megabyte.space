import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * HlmDialog — modal dialog on Angular CDK (FocusTrap + a11y), NOT the alpha
 * brain portal (CDK is the sanctioned overlay/a11y primitive per the rules, and
 * brain itself sits on it). Conditional-render overlay + centered panel:
 *   - backdrop click + Esc close (unless [disableClose])
 *   - cdkTrapFocus + auto-capture focus on open; restores on close
 *   - role=dialog + aria-modal + aria-labelledby
 *
 * Usage:
 *   <app-dialog [open]="open()" (openChange)="open.set($event)" ariaLabel="Confirm">
 *     <h2 dialogTitle>Title</h2>
 *     <p>body…</p>
 *     <div class="mt-4 flex justify-end gap-2">
 *       <button hlmBtn variant="outline" (click)="open.set(false)">Cancel</button>
 *       <button hlmBtn (click)="confirm()">Confirm</button>
 *     </div>
 *   </app-dialog>
 */
import { ChangeDetectionStrategy, Component, effect, input, output } from '@angular/core';
import { CdkTrapFocus } from '@angular/cdk/a11y';

@Component({
  selector: 'app-dialog',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CdkTrapFocus],
  host: { '[attr.data-open]': 'open()' },
  template: `
    @if (open()) {
      <div
        class="fixed inset-0 z-[90] bg-black/60 backdrop-blur-sm"
        data-testid="dialog-backdrop"
        (click)="onBackdrop()"
      ></div>
      <div
        class="fixed left-1/2 top-1/2 z-[91] w-full max-w-lg -translate-x-1/2 -translate-y-1/2 rounded-xl border border-border bg-card p-6 text-card-foreground shadow-2xl"
        role="dialog"
        aria-modal="true"
        [attr.aria-label]="ariaLabel() || null"
        data-testid="dialog-panel"
        cdkTrapFocus
        [cdkTrapFocusAutoCapture]="true"
        (keydown.escape)="onEscape()"
      >
        <ng-content />
      </div>
    }
  `,
})
export class HlmDialog {
  readonly open = input<boolean>(false);
  readonly disableClose = input<boolean>(false);
  readonly ariaLabel = input<string>('');
  readonly openChange = output<boolean>();

  private previouslyFocused: HTMLElement | null = null;

  constructor() {
    // Remember the trigger so focus can be restored when the dialog closes.
    effect(() => {
      if (this.open()) {
        this.previouslyFocused = (typeof document !== 'undefined'
          ? (document.activeElement as HTMLElement | null)
          : null);
      } else if (this.previouslyFocused) {
        this.previouslyFocused.focus?.();
        this.previouslyFocused = null;
      }
    });
  }

  protected onBackdrop(): void {
    if (!this.disableClose()) this.openChange.emit(false);
  }
  protected onEscape(): void {
    if (!this.disableClose()) this.openChange.emit(false);
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'hlm-dialog-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
