import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * StateBlockComponent — the design-system 4-state system (per the
 * spartan-ui-design-system rule). Every data surface routes through one of:
 *   loading → skeleton rows
 *   empty   → empty-state with an optional first-action CTA
 *   error   → error panel with a retry affordance + correlation id
 *   ready   → projected content (<ng-content>)
 *
 * Usage:
 *   <app-state-block [state]="state()" [emptyTitle]="'No bookings yet'"
 *      [errorDetail]="err()" (retry)="reload()">
 *     <!-- ready content -->
 *   </app-state-block>
 */
import { ChangeDetectionStrategy, Component, computed, input, output } from '@angular/core';
import { HlmSkeleton } from '../skeleton/hlm-skeleton';
import { HlmButton } from '../button/hlm-button';

export type SurfaceState = 'loading' | 'empty' | 'error' | 'ready';

@Component({
  selector: 'app-state-block',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [HlmSkeleton, HlmButton],
  template: `
    @switch (state()) {
      @case ('loading') {
        <div class="flex flex-col gap-3 p-2" data-testid="state-loading" aria-busy="true">
          @for (row of skeletonRows(); track row) {
            <div hlmSkeleton class="h-12 w-full"></div>
          }
        </div>
      }
      @case ('empty') {
        <div
          class="flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-border p-10 text-center"
          data-testid="state-empty"
        >
          <p class="text-base font-semibold text-foreground">{{ emptyTitle() }}</p>
          @if (emptyHint()) {
            <p class="max-w-sm text-sm text-muted-foreground">{{ emptyHint() }}</p>
          }
          @if (emptyCta()) {
            <button hlmBtn size="sm" (click)="emptyAction.emit()">{{ emptyCta() }}</button>
          }
        </div>
      }
      @case ('error') {
        <div
          class="flex flex-col items-center justify-center gap-3 rounded-xl border border-destructive/40 bg-destructive/5 p-10 text-center"
          data-testid="state-error"
          role="alert"
        >
          <p class="text-base font-semibold text-foreground">{{ errorTitle() }}</p>
          <p class="max-w-sm text-sm text-muted-foreground">{{ errorDetail() || defaultError }}</p>
          @if (correlationId()) {
            <p class="font-mono text-xs text-muted-foreground">ref: {{ correlationId() }}</p>
          }
          <button hlmBtn variant="outline" size="sm" (click)="retry.emit()">Try again</button>
        </div>
      }
      @default {
        <ng-content />
      }
    }
  `,
})
export class StateBlockComponent {
  readonly state = input<SurfaceState>('loading');
  readonly skeletonCount = input<number>(4);
  readonly emptyTitle = input<string>('Nothing here yet');
  readonly emptyHint = input<string>('');
  readonly emptyCta = input<string>('');
  readonly errorTitle = input<string>("That didn't load");
  readonly errorDetail = input<string>('');
  readonly correlationId = input<string>('');

  readonly retry = output<void>();
  readonly emptyAction = output<void>();

  protected readonly defaultError = 'Something went sideways. Try again, or call (855) 82LABOR.';
  protected readonly skeletonRows = computed(() =>
    Array.from({ length: Math.max(1, this.skeletonCount()) }, (_, i) => i),
  );
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'state-block-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
