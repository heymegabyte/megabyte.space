import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * cn — the class-merge helper every Spartan/helm primitive composes on.
 * clsx resolves conditional class maps; tailwind-merge dedupes conflicting
 * Tailwind utilities (last-wins) so consumer `class` overrides beat variant
 * defaults. (Spartan's brain/core no longer re-exports this in alpha.701, so
 * we own it — one util for the whole ui-spartan layer.)
 */
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}

/** Alias used by some helm sources; identical behavior. */
export const hlm = cn;
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'cn',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
