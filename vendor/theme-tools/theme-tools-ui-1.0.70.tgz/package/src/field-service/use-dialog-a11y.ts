/**
 * Shared dialog/drawer accessibility glue — the ONE React kit every modal,
 * panel, and slide-in drawer reuses for the ARIA Authoring Practices dialog
 * pattern: focus moves INTO the surface on open, returns to the trigger on
 * close, body scroll locks while open, and Tab/Shift+Tab cycle stays trapped
 * inside (using the pure {@link trapBoundaryTarget} math in
 * `shared/focus-trap`). axe-core cannot detect any of these interaction gaps,
 * so this kit is the only guard — extracted from `AiChat` so the floating chat
 * panel and the mobile nav drawer share one implementation instead of each
 * re-deriving it (per `repo-folder-hygiene` / extend-don't-duplicate).
 *
 * Pairs with `use-modal-motion.ts` (entrance/exit timing) — this owns focus +
 * scroll, that owns the animated dismissal.
 */
import { useEffect, type KeyboardEvent, type MutableRefObject } from 'react';
import { FOCUSABLE_SELECTOR, nextTrapTarget } from "./focus-trap.js";

/**
 * Move focus into an open dialog and restore it to the trigger on close.
 *
 * On open: remembers the currently-focused element, then (after a 60ms tick so
 * the surface has painted) focuses the first node matching `focusSelector`. On
 * close: returns focus to the remembered trigger so keyboard users land back
 * where they were (WCAG 2.4.3 / 2.4.11).
 *
 * @param open - whether the dialog is currently open
 * @param panelRef - ref to the dialog container queried for the focus target
 * @param lastFocusRef - mutable ref holding the pre-open `activeElement`
 * @param focusSelector - CSS selector for the initial focus target (defaults to the first focusable)
 * @example
 * useFocusManagement(open, panelRef, lastFocusRef);                // focus first control
 * useFocusManagement(open, panelRef, lastFocusRef, 'textarea, [autofocus]'); // AiChat input
 */
export function useFocusManagement<T extends HTMLElement>(
  open: boolean,
  panelRef: { readonly current: T | null },
  lastFocusRef: MutableRefObject<HTMLElement | null>,
  focusSelector: string = FOCUSABLE_SELECTOR,
): void {
  useEffect(() => {
    if (open) {
      // Child effects can focus the dialog's initial control before this parent
      // effect runs. Never overwrite an already-captured trigger with an element
      // inside the panel, or close would "restore" focus into the hidden dialog.
      const active = document.activeElement as HTMLElement | null;
      if (active && !panelRef.current?.contains(active)) lastFocusRef.current = active;
      const t = window.setTimeout(() => {
        const target = panelRef.current?.querySelector<HTMLElement>(focusSelector);
        target?.focus();
      }, 60);
      return () => window.clearTimeout(t);
    }
    lastFocusRef.current?.focus?.();
  }, [open, panelRef, lastFocusRef, focusSelector]);
}

/**
 * Lock body scroll while an open dialog covers the viewport — but only below
 * `lockBelowPx` so a desktop side-panel that doesn't cover the page leaves
 * scrolling intact. Restores the prior `overflow` on close.
 *
 * @param open - whether the dialog is currently open
 * @param lockBelowPx - max viewport width (px) at which to lock (default 640)
 * @example
 * useBodyScrollLock(open);          // lock only on phones (≤640px) — AiChat
 * useBodyScrollLock(open, 768);     // lock on phone + tablet — mobile nav drawer
 */
export function useBodyScrollLock(open: boolean, lockBelowPx: number = 640): void {
  useEffect(() => {
    if (!open) return;
    if (!window.matchMedia(`(max-width: ${lockBelowPx}px)`).matches) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open, lockBelowPx]);
}

/**
 * Build the `onKeyDown` handler that traps Tab/Shift+Tab inside a dialog. A
 * `fixed`/`absolute` surface leaves the page behind its backdrop focusable, so
 * Tab from the last control would silently escape. This drives focus EXPLICITLY
 * on every Tab (never trusting the browser's natural advance) via the strict
 * {@link nextTrapTarget} math — a transformed/late-DOM dialog's "natural"
 * previous/next tabbable can otherwise resolve to an element OUTSIDE the visually
 * overlapping dialog (SCAN-21: Shift+Tab escaped to the AiChat FAB on mobile).
 * Wrapping (first↔last) and pull-back of already-escaped focus are preserved.
 *
 * @param panelRef - ref to the dialog container whose focusables are cycled
 * @returns a keydown handler to spread onto the dialog container
 * @example
 * const onKeyDown = useTabTrap(panelRef);
 * <div role="dialog" aria-modal="true" ref={panelRef} onKeyDown={onKeyDown}>…</div>
 */
export function useTabTrap<T extends HTMLElement>(
  panelRef: { readonly current: T | null },
): (e: KeyboardEvent<HTMLElement>) => void {
  return (e: KeyboardEvent<HTMLElement>) => {
    if (e.key !== 'Tab' || !panelRef.current) return;
    const focusables = Array.from(
      panelRef.current.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR),
    );
    const activeIndex = focusables.indexOf(document.activeElement as HTMLElement);
    const target = nextTrapTarget(focusables, activeIndex, e.shiftKey);
    if (target) {
      e.preventDefault();
      target.focus();
    }
  };
}
